import UnorderedEndgameTest
namespace PEqualNP.Outside.L_meta_670_aux.UnorderedFormula.FiniteP2U2
open LiveCheck TightFormula
def state : List Sig := (ops (phase (raw.getD 0 zero)) (phase (raw.getD 3 zero))).getD 2 zero :: inputs

end PEqualNP.Outside.L_meta_670_aux.UnorderedFormula.FiniteP2U2
