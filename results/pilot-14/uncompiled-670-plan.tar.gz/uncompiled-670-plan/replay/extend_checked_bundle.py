#!/usr/bin/env python3
"""Extend an immutable source bundle with checked custom module import closures."""
import argparse, collections, datetime, hashlib, json, re, shutil, tarfile
from pathlib import Path
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--base',required=True,type=Path)
parser.add_argument('--dest',required=True,type=Path)
parser.add_argument('--root',action='append',default=[])
parser.add_argument('--search-dir',action='append',default=[],type=Path)
args=parser.parse_args()
scratch=Path('/tmp/oec/pequalnp-pilot-14')
base=args.base.resolve();dest=args.dest.resolve()
if dest.exists():raise SystemExit('Destination already exists; select a new version.')
if scratch not in dest.parents:raise SystemExit('Destination must be inside the named scratch job.')
manifest=json.loads((base/'manifest.json').read_text())
cat=collections.defaultdict(list)
for directory in ['assembly','lower-bound','sat-proof','toolchain','replay','replay/theta','counterexample','projection','status-review','force-context']:
    d=scratch/directory
    if d.exists():
        for path in d.glob('*.lean'):cat[path.stem].append(path)
for directory in args.search_dir:
    d=directory.resolve()
    if scratch not in d.parents:raise SystemExit('Search directory must be inside the named scratch job.')
    for path in d.glob('*.lean'):
        if path not in cat[path.stem]:cat[path.stem].append(path)
existing={e['module']:e for e in manifest['modules']}
order=list(manifest['build_order']);external=set(manifest['external_imports']);new={};visiting=set()
def visit(name):
    if name in existing or name in new:return
    if name.startswith(('Mathlib','Batteries','PEqualNP','Lean','Std','Init')):
        external.add(name);return
    if name in visiting:raise RuntimeError('Import cycle: '+name)
    if len(cat[name])!=1:raise RuntimeError('Missing or ambiguous custom module: '+name)
    visiting.add(name);path=cat[name][0];data=path.read_bytes();olean=path.with_suffix('.olean')
    if not olean.is_file():raise RuntimeError('No checked artifact yet: '+name)
    if path.stat().st_mtime_ns>olean.stat().st_mtime_ns:raise RuntimeError('Source newer than checked artifact: '+name)
    imports=re.findall(r'^\s*(?:public\s+)?import\s+([\w.]+)',data.decode(),re.M)
    for child in imports:visit(child)
    entry={'module':name,'source':str(path),'copy':'modules/'+name+'.lean','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'imports':imports,'olean_sha256':hashlib.sha256(olean.read_bytes()).hexdigest(),'source_mtime_ns':path.stat().st_mtime_ns,'olean_mtime_ns':olean.stat().st_mtime_ns}
    new[name]=(entry,data);order.append(name);visiting.remove(name)
for root in args.root:visit(root)
for name,entry in existing.items():
    if hashlib.sha256((base/entry['copy']).read_bytes()).hexdigest()!=entry['sha256']:raise RuntimeError('Frozen base source changed: '+name)
for entry,data in new.values():
    if Path(entry['source']).read_bytes()!=data:raise RuntimeError('Source mutated during snapshot: '+entry['module'])
shutil.copytree(base,dest)
for entry,data in new.values():(dest/entry['copy']).write_bytes(data)
manifest['created_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
manifest['previous_bundle_manifest_sha256']=hashlib.sha256((base/'manifest.json').read_bytes()).hexdigest()
manifest['roots']=list(dict.fromkeys(manifest['roots']+args.root))
manifest['build_order']=order
manifest['modules']=list(existing.values())+[new[n][0] for n in order if n in new]
manifest['external_imports']=sorted(external)
manifest['warnings']=[]
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(dest/'build-order.txt').write_text('\n'.join(order)+'\n')
(dest/'SHA256SUMS').write_text('\n'.join(e['sha256']+'  '+e['copy'] for e in manifest['modules'])+'\n')
readme=(dest/'README.md').read_text()
readme=re.sub(r'All \d+ sources',f'All {len(order)} sources',readme)
readme+='\n## Versioned additions\n\nThis version adds the checked source closures rooted at: '+', '.join(args.root)+'. The earlier archive remains unchanged. All new module source timestamps precede their compiled artifacts, and their source bytes were rechecked after copying. The manifest records the prior bundle manifest hash.\n'
(dest/'README.md').write_text(readme)
(dest/'closure-audit.txt').write_text(f'SOURCE-CLOSURE AUDIT PASS: {len(order)} custom modules. Frozen earlier sources and every new source hash verified; all imports resolve in topological order or to listed external modules. New sources match originals after snapshot and predate their checked artifacts. See manifest for exact roots, hashes and preserved Smoke provenance. No Lean build was repeated to extend this source snapshot.\n')
files=sorted(p for p in dest.rglob('*') if p.is_file() and p.name!='BUNDLE-SHA256SUMS')
(dest/'BUNDLE-SHA256SUMS').write_text('\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(dest)) for p in files)+'\n')
archive=dest.with_name(dest.name+'.tar.gz')
with tarfile.open(archive,'w:gz') as tar:tar.add(dest,arcname=dest.name)
print(json.dumps({'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256((dest/'manifest.json').read_bytes()).hexdigest(),'modules':len(order),'new_modules':list(new)},indent=2))
