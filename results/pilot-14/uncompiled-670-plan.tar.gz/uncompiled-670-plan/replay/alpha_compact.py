from pathlib import Path
import re,collections,hashlib,json
r=Path('/tmp/oec/pequalnp-pilot-14');o=r/'assembly-alpha';o.mkdir(exist_ok=True)
p=r/'assembly-slim-certified/Candidate.lean';source=p.read_text();own='PEqualNP.Outside.L_meta_670_aux'
def uncomment(s):
 out=[];i=0;depth=0
 while i<len(s):
  if s.startswith('/-',i):depth+=1;i+=2;continue
  if depth and s.startswith('-/',i):depth-=1;i+=2;continue
  if not depth and s.startswith('--',i):
   j=s.find('\n',i);i=len(s)if j<0 else j;continue
  c=s[i]
  if not depth or c=='\n':out.append(c)
  i+=1
 assert depth==0
 return ''.join(out)
s=uncomment(source);tokens=set(re.findall(r"[A-Za-z_][A-Za-z0-9_']*",s));counts=collections.Counter(re.findall(r'[A-Za-z_][A-Za-z0-9_]*',s))
nss=sorted(set(re.findall(r'namespace '+re.escape(own)+r'\.([A-Za-z0-9_]+)',s)),key=lambda n:(-(len(n)-3)*counts[n],n))
nsmap={n:f'N{i:02}' for i,n in enumerate(nss)}
assert not set(nsmap.values())&tokens
external={'BitVec','Finset','List','Nat','Bool','Option','Function','Set','Classical','Lean','Mathlib','Prod','Equiv','Fin'}
defs=set(re.findall(r"^(?:private )?(?:noncomputable )?(?:def|lemma|theorem|abbrev|inductive|structure)\s+([A-Za-z_][A-Za-z0-9_]*)(?=[ \t:{(])",s,re.M))
helpers=[];excluded=[]
for n in defs:
 if len(n)<13 or counts[n]<2 or n in nsmap:continue
 prefixes=set(re.findall(r'\b([A-Za-z_][A-Za-z0-9_]*)\.'+re.escape(n)+r'\b',s))
 if prefixes&external:excluded.append((n,sorted(prefixes&external)));continue
 helpers.append(n)
helpers.sort(key=lambda n:(-(len(n)-4)*counts[n],n))
hmap={n:f'h{i:03}'for i,n in enumerate(helpers)}
assert not set(hmap.values())&tokens

def renamed(t,m):
 pattern=re.compile(r"(?<![\w'])('''PLACEHOLDER''')(?![\w'])".replace("'''PLACEHOLDER'''",'|'.join(map(re.escape,sorted(m,key=len,reverse=True)))))
 return pattern.sub(lambda a:m[a.group()],t)
def wrapped(t):
 imports=[];body=[]
 for l in t.splitlines():
  if l.startswith('import '):imports.append(l);continue
  if l in ['namespace '+own,'end '+own]:continue
  if l.startswith('namespace '+own+'.'):l='namespace '+l[len('namespace '+own+'.'):]
  if l.startswith('end '+own+'.'):l='end '+l[len('end '+own+'.'):]
  if l.strip():body.append(l)
 return '\n'.join(imports)+'\nnamespace '+own+'\n'+'\n'.join(body)+'\nend '+own+'\n'
ns=wrapped(renamed(s,nsmap));full=wrapped(renamed(s,nsmap|hmap))
(o/'Namespaces.lean').write_text(ns);(o/'Candidate.lean').write_text(full)
record={'source':str(p),'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'namespaces':nsmap,'helpers':hmap,'excluded_helpers':excluded,'variants':{}}
for n,t in [('Namespaces',ns),('Candidate',full)]:
 record['variants'][n]={'bytes':len(t.encode()),'lines':len(t.splitlines()),'sha256':hashlib.sha256(t.encode()).hexdigest(),'saved':len(source.encode())-len(t.encode()),'headroom':524288-len(t.encode())}
 print(n,record['variants'][n])
 assert not any(x in t for x in ['_root_','"','sorry','native_decide','axiom','@['])
(o/'renaming.json').write_text(json.dumps(record,indent=2)+'\n')
(o/'README.txt').write_text('Source-only alpha-renaming candidates. No compiler or checker result is claimed. Namespaces.lean changes own namespace identifiers, wraps helpers in the one required outer namespace, and removes comments/blank lines. Candidate.lean additionally shortens selected own long declaration identifiers. All original files are preserved. renaming.json records exact reversible identifier mappings and source hashes. Compile and independently audit before using either candidate.\n')
print('namespace count',len(nsmap),'helper count',len(hmap),'excluded',excluded)
