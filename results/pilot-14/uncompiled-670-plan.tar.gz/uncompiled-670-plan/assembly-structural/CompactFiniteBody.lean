namespace PEqualNP.Outside.L_meta_670_aux.CompactRepresentativeChecks
open LiveCheck TightFormula UnorderedFormula
open UnorderedRepresentativeFamily

def hard (p : Fin 6) (u : Fin 4) (d : Fin 10) : Bool :=
  ((0x440000000000000000000000000000000100000 >>> (40*p.val+10*u.val+d.val)) &&& 1) == 1

def duplicate (p : Fin 6) (u : Fin 4) (d : Fin 10) : List Sig :=
  (state p u).getD d.val zero :: state p u

set_option maxRecDepth 20000 in
set_option maxHeartbeats 0 in
lemma split_children (p : Fin 6) (u : Fin 4) (d : Fin 10)
    (i : Fin (UnorderedPairs.steps (duplicate p u d)).length) :
    hard p u d = false ∨
      ((unionSep true (UnorderedPairs.steps (duplicate p u d))[i] == top) &&
        UnorderedFormula.test 3 (UnorderedPairs.steps (duplicate p u d))[i]) = false := by
  fin_cases p <;> fin_cases u <;> fin_cases d
  all_goals first
    | exact Or.inl (by decide +kernel)
    | apply Or.inr
      fin_cases i <;> decide +kernel

lemma split_duplicate (p : Fin 6) (u : Fin 4) (d : Fin 10) (hh : hard p u d = true) :
    UnorderedFormula.test 4 (duplicate p u d) = false := by
  apply test_succ_false 3 (duplicate p u d)
  · simp [duplicate, state, inputs]
  · intro i
    exact (split_children p u d i).resolve_left (by simp [hh])

set_option maxRecDepth 20000 in
set_option maxHeartbeats 0 in
lemma all_duplicates (p : Fin 6) (u : Fin 4) (d : Fin 10) :
    UnorderedFormula.test 4 (duplicate p u d) = false := by
  fin_cases p <;> fin_cases u <;> fin_cases d
  all_goals first
    | apply split_duplicate
      decide +kernel
    | decide +kernel

set_option maxRecDepth 20000 in
set_option maxHeartbeats 0 in
lemma all_consume (p : Fin 6) (u : Fin 4)
    (i : Fin (UnorderedPairs.steps (state p u)).length) :
    ((unionSep true (UnorderedPairs.steps (state p u))[i] == top) &&
      UnorderedFormula.testOne 3 (UnorderedPairs.steps (state p u))[i]) = false := by
  fin_cases p <;> fin_cases u <;> fin_cases i <;> decide +kernel

set_option maxRecDepth 20000 in
set_option maxHeartbeats 0 in
lemma all_keep (p : Fin 6) (u : Fin 4)
    (i : Fin (UnorderedPairs.keepSteps (state p u)).length) :
    ((unionSep true (UnorderedPairs.keepSteps (state p u))[i] == top) &&
      UnorderedFormula.test 3 (UnorderedPairs.keepSteps (state p u))[i]) = false := by
  fin_cases p <;> fin_cases u <;> fin_cases i <;> decide +kernel

lemma all_cases (p : Fin 6) (u : Fin 4) : UnorderedFormula.testOne 4 (state p u) = false := by
  apply testOne_succ_false 3 (state p u)
  · simp [state, inputs]
  · intro i
    have hi : i.val < 10 := by simpa [state, inputs] using i.isLt
    have h := all_duplicates p u ⟨i.val, hi⟩
    simpa only [duplicate, List.getD_eq_getElem?_getD,
      List.getElem?_eq_getElem i.isLt, Option.getD_some] using h
  · exact all_consume p u
  · exact all_keep p u

end PEqualNP.Outside.L_meta_670_aux.CompactRepresentativeChecks
