-- PhaseOperands
namespace PEqualNP.Outside.L_meta_670_aux.TightFormula
open LiveCheck

def phase (a : Sig) : Sig := if a.1.getLsbD 63 then neg a else a
lemma phase_neg (a : Sig) : phase (neg a) = phase a := by
  unfold phase neg
  simp only [BitVec.getLsbD_not, BitVec.not_not]
  cases h : a.1.getLsbD 63 <;> simp [h]
lemma phase_sign (a : Sig) : a = phase a ∨ a = neg (phase a) := by
  unfold phase
  split <;> simp [neg, BitVec.not_not]
lemma phase_sep (a : Sig) : sep true (phase a) = sep true a := by
  unfold phase
  split
  · apply BitVec.eq_of_getLsbD_eq
    intro i hi
    simp only [sep, neg, ite_true, BitVec.getLsbD_xor, BitVec.getLsbD_not, hi]
    cases a.1.getLsbD i <;> cases a.2.getLsbD i <;> decide
  · rfl

def ops (a b : Sig) : List Sig :=
  [phase (bin false a b), phase (bin false a (neg b)),
   phase (bin false (neg a) b), phase (bin false (neg a) (neg b))]
lemma op_mem (d : Bool) (a b : Sig) : phase (bin d a b) ∈ ops (phase a) (phase b) := by
  have hand {x y : Sig} (hx : x = phase a ∨ x = neg (phase a))
      (hy : y = phase b ∨ y = neg (phase b)) :
      phase (bin false x y) ∈ ops (phase a) (phase b) := by
    rcases hx with rfl | rfl <;> rcases hy with rfl | rfl <;> simp [ops]
  cases d
  · exact hand (phase_sign a) (phase_sign b)
  · rw [← phase_neg (bin true a b)]
    have e : neg (bin true a b) = bin false (neg a) (neg b) := by
      simp [neg, bin, BitVec.not_or]
    rw [e]
    exact hand (by simpa only [phase_neg] using phase_sign (neg a))
      (by simpa only [phase_neg] using phase_sign (neg b))

def singles {α : Type} : List α → List (α × List α)
  | [] => []
  | a :: rest => (a, rest) :: (singles rest).map (fun (b, bs) => (b, a :: bs))
lemma pick_one {α : Type} {a : α} {ws : List α} (h : a ∈ ws) :
    ∃ rest, (a, rest) ∈ singles ws ∧ ws.Perm (a :: rest) := by
  induction ws with
  | nil => simp at h
  | cons x xs ih =>
    rcases List.mem_cons.mp h with e | h
    · subst x; exact ⟨xs, by simp [singles], .refl _⟩
    · obtain ⟨rest, hm, hp⟩ := ih h
      refine ⟨x :: rest, List.mem_cons_of_mem _ (List.mem_map.mpr ⟨(a, rest), hm, rfl⟩), ?_⟩
      exact (hp.cons x).trans (.swap _ _ _)
end PEqualNP.Outside.L_meta_670_aux.TightFormula

-- RetainedClasses
namespace PEqualNP.Outside.L_meta_670_aux.TightFormula
open LiveCheck
open LiteralBinary

def inputs : List Sig := (List.finRange 9).map fun i => phase (raw.getD i.val zero)
lemma inputs_eq : inputs = raw.map phase := by decide +kernel
lemma inputs_nodup : inputs.Nodup := by decide +kernel
lemma literal_phase_index {a : Sig} (ha : a ∈ literals) :
    phase a = phase (raw.getD (index a).val zero) := by
  have h : literals.all (fun a => phase a == phase (raw.getD (index a).val zero)) = true := by decide +kernel
  exact beq_iff_eq.mp (List.all_eq_true.mp h a ha)
lemma every_class {k t : Nat} {U : Finset Sig} {a b : Sig} {d : Bool}
    (ha : a ∈ literals) (hb : b ∈ literals) (hne : a ≠ b)
    (hu : ∀ z ∈ U, z ∈ literals) (h : Live k t (insert (bin d a b) U)) :
    ∀ i : Fin 9, ∃ z ∈ U, index z = i := by
  intro i
  by_contra hn
  have absent : ∀ z ∈ U, index z ≠ i := by
    intro z hz hi
    exact hn ⟨z, hz, hi⟩
  apply binary_missing i ha hb hne d
  apply BitVec.eq_of_getLsbD_eq
  intro j hj
  obtain ⟨z,hz,hs⟩ := LiveCheck.live_sep h j hj
  have hx := LiveCheck.sep_weaken t z j hj hs
  rcases Finset.mem_insert.mp hz with rfl | hz
  · simp only [BitVec.getLsbD_or,hx,Bool.true_or,top,
      BitVec.getLsbD_allOnes,hj,decide_true]
  · have hm := congrArg (fun x : B => x.getLsbD j)
      (outside_mask i (hu z hz) (absent z hz))
    simp only [BitVec.getLsbD_or,hx,Bool.true_or] at hm
    simp only [BitVec.getLsbD_or,← hm,Bool.or_true,top,
      BitVec.getLsbD_allOnes,hj,decide_true]
end PEqualNP.Outside.L_meta_670_aux.TightFormula

-- RetainedExtension
namespace PEqualNP.Outside.L_meta_670_aux.TightFormula
open LiveCheck LiteralBinary
lemma literal_phase_mem {a : Sig} (ha : a ∈ literals) : phase a ∈ inputs := by
  rw [literal_phase_index ha]
  exact List.mem_map.mpr ⟨index a, by simp, rfl⟩
lemma retained_extension {k t : Nat} {U : Finset Sig} {a b : Sig} {d : Bool}
    (ha : a ∈ literals) (hb : b ∈ literals) (hne : a ≠ b)
    (hu : ∀ z ∈ U, z ∈ literals) (h : Live k t (insert (bin d a b) U))
    (hc : U.card ≤ 10) : ∃ extra : List Sig, extra.length ≤ 1 ∧ extra ⊆ inputs ∧
      (U.toList.map phase).Perm (extra ++ inputs) := by
  have sub : inputs ⊆ U.toList.map phase := by
    intro z hz
    obtain ⟨i, hi, rfl⟩ := List.mem_map.mp hz
    obtain ⟨a, ha, hi⟩ := every_class ha hb hne hu h i
    exact List.mem_map.mpr ⟨a, Finset.mem_toList.mpr ha,
      by rw [literal_phase_index (hu a ha), hi]⟩
  obtain ⟨w, pw, hw⟩ := inputs_nodup.subperm sub
  obtain ⟨extra, he⟩ := hw.exists_perm_append
  have hp : (U.toList.map phase).Perm (extra ++ inputs) :=
    (he.trans (pw.append_right extra)).trans (List.perm_append_comm)
  refine ⟨extra, ?_, ?_, hp⟩
  · have hl := hp.length_eq
    simp only [List.length_map, Finset.length_toList, List.length_append] at hl
    have hin : inputs.length = 9 := by simp [inputs]
    omega
  · intro z hz
    have hm := hp.mem_iff.mpr (List.mem_append_left inputs hz)
    obtain ⟨a, ha, rfl⟩ := List.mem_map.mp hm
    exact literal_phase_mem (hu a (Finset.mem_toList.mp ha))
end PEqualNP.Outside.L_meta_670_aux.TightFormula

-- UnorderedPairs
namespace PEqualNP.Outside.L_meta_670_aux.UnorderedPairs

open LiveCheck TightFormula

def pairs {α : Type} : List α → List (α × α × List α)
  | [] => []
  | a :: xs => (singles xs).map (fun (b,r) => (a,b,r)) ++
      (pairs xs).map (fun (b,c,r) => (b,c,a :: r))

lemma pair_mem {α : Type} {v r : List α} {a b : α}
    (hp : v.Perm (a :: b :: r)) :
    ∃ s, ((a,b,s) ∈ pairs v ∨ (b,a,s) ∈ pairs v) ∧ s.Perm r := by
  classical
  induction v generalizing r with
  | nil => have h := hp.length_eq; simp at h
  | cons x xs ih =>
      by_cases hxa : x = a
      · subst x
        have hx : xs.Perm (b :: r) := List.Perm.cons_inv hp
        obtain ⟨s,hm,hs⟩ := pick_one (hx.mem_iff.mpr (by simp : b ∈ b :: r))
        refine ⟨s,Or.inl ?_,List.Perm.cons_inv (hs.symm.trans hx)⟩
        exact List.mem_append_left _ (List.mem_map.mpr ⟨(b,s),hm,rfl⟩)
      · by_cases hxb : x = b
        · subst x
          have hx : xs.Perm (a :: r) :=
            List.Perm.cons_inv (hp.trans (List.Perm.swap b a r))
          obtain ⟨s,hm,hs⟩ := pick_one (hx.mem_iff.mpr (by simp : a ∈ a :: r))
          refine ⟨s,Or.inr ?_,List.Perm.cons_inv (hs.symm.trans hx)⟩
          exact List.mem_append_left _ (List.mem_map.mpr ⟨(a,s),hm,rfl⟩)
        · have hxr : x ∈ r := by
            have hx := hp.mem_iff.mp (List.mem_cons_self : x ∈ x :: xs)
            simpa only [List.mem_cons,hxa,hxb,false_or] using hx
          obtain ⟨r₀,_,hr⟩ := pick_one hxr
          have hx : xs.Perm (a :: b :: r₀) := by
            apply List.Perm.cons_inv
            exact (hp.trans ((hr.cons b).cons a)).trans
              (((List.Perm.swap x b r₀).cons a).trans (List.Perm.swap x a (b :: r₀)))
          obtain ⟨s,hm,hs⟩ := ih hx
          refine ⟨x :: s,?_,(hs.cons x).trans hr.symm⟩
          rcases hm with hm | hm
          · exact Or.inl (List.mem_append_right _
              (List.mem_map.mpr ⟨(a,b,s),hm,rfl⟩))
          · exact Or.inr (List.mem_append_right _
              (List.mem_map.mpr ⟨(b,a,s),hm,rfl⟩))

lemma and_comm (a b : Sig) : bin false a b = bin false b a := by
  simp [bin,BitVec.and_comm]

lemma ops_swap_mem {a b z : Sig} (h : z ∈ ops a b) : z ∈ ops b a := by
  simp only [ops,List.mem_cons,List.not_mem_nil,or_false] at h ⊢
  rcases h with h | h | h | h
  · exact Or.inl (h.trans (congrArg phase (and_comm a b)))
  · exact Or.inr (Or.inr (Or.inl (h.trans (congrArg phase (and_comm a (neg b))))))
  · exact Or.inr (Or.inl (h.trans (congrArg phase (and_comm (neg a) b))))
  · exact Or.inr (Or.inr (Or.inr (h.trans (congrArg phase (and_comm (neg a) (neg b))))))

def steps (v : List Sig) : List (List Sig) :=
  (pairs v).flatMap fun (a,b,r) => (ops a b).map fun z => z :: r

lemma step_mem {v r : List Sig} {a b z : Sig}
    (hp : v.Perm (a :: b :: r)) (hz : z ∈ ops a b) :
    ∃ w ∈ steps v, w.Perm (z :: r) := by
  obtain ⟨s,hm,hs⟩ := pair_mem hp
  refine ⟨z :: s,?_,hs.cons z⟩
  rcases hm with hm | hm
  · exact List.mem_flatMap.mpr ⟨(a,b,s),hm,List.mem_map.mpr ⟨z,hz,rfl⟩⟩
  · exact List.mem_flatMap.mpr ⟨(b,a,s),hm,List.mem_map.mpr ⟨z,ops_swap_mem hz,rfl⟩⟩

def keepSteps (v : List Sig) : List (List Sig) :=
  (pairs v).flatMap fun (a,b,r) => (ops a b).flatMap fun z =>
    [z :: a :: r,z :: b :: r]

lemma keep_step_mem {v r : List Sig} {a b z : Sig}
    (hp : v.Perm (a :: b :: r)) (hz : z ∈ ops a b) (keep : Bool) :
    ∃ w ∈ keepSteps v, w.Perm (z :: (if keep then a else b) :: r) := by
  obtain ⟨s,hm,hs⟩ := pair_mem hp
  refine ⟨z :: (if keep then a else b) :: s,?_,(hs.cons _).cons z⟩
  rcases hm with hm | hm
  · exact List.mem_flatMap.mpr ⟨(a,b,s),hm,List.mem_flatMap.mpr
      ⟨z,hz,by cases keep <;> simp⟩⟩
  · exact List.mem_flatMap.mpr ⟨(b,a,s),hm,List.mem_flatMap.mpr
      ⟨z,ops_swap_mem hz,by cases keep <;> simp⟩⟩

end PEqualNP.Outside.L_meta_670_aux.UnorderedPairs

-- UnorderedFormula
namespace PEqualNP.Outside.L_meta_670_aux.UnorderedFormula
open LiveCheck TightFormula

def test : Nat → List Sig → Bool
  | 0, _ => true
  | n+1, v => decide (v.length ≤ 1) ||
      (UnorderedPairs.steps v).any fun w => (unionSep true w == top) && test n w

lemma cover {k t S} (h : Live k t S) {v : List Sig}
    (hp : v.Perm (S.toList.map phase)) : unionSep true v = top := by
  apply BitVec.eq_of_getLsbD_eq
  intro j hj
  obtain ⟨a, ha, hs⟩ := LiveCheck.live_sep h j hj
  have ht := LiveCheck.sep_weaken t a j hj hs
  have hm : phase a ∈ v := hp.mem_iff.mpr (List.mem_map.mpr ⟨a, Finset.mem_toList.mpr ha, rfl⟩)
  have hu := (LiveCheck.mem_unionSep true v j).mpr ⟨phase a, hm, by simpa only [phase_sep] using ht⟩
  simpa only [top, BitVec.getLsbD_allOnes, hj, decide_true] using hu

lemma tight_test {k t S} (h : Live k t S) (ht : S.card + t = k+1) :
    ∀ n v, v.Perm (S.toList.map phase) → test n v = true := by
  induction h with
  | stop =>
    intro n v hp
    have hl : v.length = 1 := by simpa using hp.length_eq
    cases n <;> simp [test, hl]
  | @unary k t U a ha hf tail ih =>
    have hn : neg a ∉ U := fun hm => hf (Finset.mem_insert_of_mem hm)
    have hs := LiveCheck.live_size tail
    rw [Finset.card_insert_of_notMem hn] at hs
    have hu : a ∉ U := by
      intro hm
      rw [Finset.insert_eq_of_mem hm] at ht
      omega
    have ht' : (insert (neg a) U).card + t = k+1 := by
      rw [Finset.card_insert_of_notMem hu] at ht
      rw [Finset.card_insert_of_notMem hn]
      omega
    intro n v hp
    apply ih ht' n v
    have p₁ := (Finset.toList_insert hu).map phase
    have p₂ := (Finset.toList_insert hn).map phase
    simp only [List.map_cons, phase_neg] at p₁ p₂
    exact hp.trans (p₁.trans p₂.symm)
  | @binary k t U a b d ha hb hab hf tail ih =>
    have hn : bin d a b ∉ U := fun hm => hf (Finset.mem_insert_of_mem (Finset.mem_insert_of_mem hm))
    have hs := LiveCheck.live_size tail
    rw [Finset.card_insert_of_notMem hn] at hs
    have hu : a ∉ insert b U := by
      intro hm
      rw [Finset.insert_eq_of_mem hm] at ht
      have hc := Finset.card_insert_le b U
      omega
    have hv : b ∉ U := by
      intro hm
      rw [Finset.insert_eq_of_mem hm] at ht
      have hc := Finset.card_insert_le a U
      omega
    have ht' : (insert (bin d a b) U).card + t = k+1 := by
      rw [Finset.card_insert_of_notMem hu, Finset.card_insert_of_notMem hv] at ht
      rw [Finset.card_insert_of_notMem hn]
      omega
    intro n v hp
    cases n with
    | zero => rfl
    | succ n =>
      have p₁ := (Finset.toList_insert hu).map phase
      have p₂ := (Finset.toList_insert hv).map phase
      have p : v.Perm (phase a :: phase b :: U.toList.map phase) := by
        exact hp.trans (p₁.trans (p₂.cons (phase a)))
      obtain ⟨w, hw, hpw⟩ := UnorderedPairs.step_mem p (op_mem d a b)
      have hq : w.Perm ((insert (bin d a b) U).toList.map phase) :=
        hpw.trans ((Finset.toList_insert hn).map phase).symm
      simp only [test, Bool.or_eq_true]
      right
      exact List.any_eq_true.mpr ⟨w, hw, by simp [cover tail hq, ih ht' n w hq]⟩
def testOne : Nat → List Sig → Bool
  | 0, _ => true
  | n+1, v => decide (v.length ≤ 1) ||
      v.any (fun a => test (n+1) (a :: v)) ||
      (UnorderedPairs.steps v).any (fun w => (unionSep true w == top) && testOne n w) ||
      (UnorderedPairs.keepSteps v).any (fun w => (unionSep true w == top) && test n w)

lemma one_test {k t S} (h : Live k t S) (ht : S.card + t = k) :
    ∀ n v, v.Perm (S.toList.map phase) → testOne n v = true := by
  induction h with
  | stop =>
    intro n v hp
    have hl : v.length = 1 := by simpa using hp.length_eq
    cases n <;> simp [testOne, hl]
  | @unary k t U a ha hf tail ih =>
    have hn : neg a ∉ U := fun hm => hf (Finset.mem_insert_of_mem hm)
    intro n v hp
    by_cases hu : a ∈ U
    · have ht' : (insert (neg a) U).card + t = k+1 := by
        rw [Finset.insert_eq_of_mem hu] at ht
        rw [Finset.card_insert_of_notMem hn]
        omega
      have hv : v.Perm (U.toList.map phase) := by
        simpa only [Finset.insert_eq_of_mem hu] using hp
      have hm : phase a ∈ v :=
        hv.mem_iff.mpr (List.mem_map.mpr ⟨a, Finset.mem_toList.mpr hu, rfl⟩)
      have hq : (phase a :: v).Perm ((insert (neg a) U).toList.map phase) := by
        have p := (Finset.toList_insert hn).map phase
        simp only [List.map_cons, phase_neg] at p
        exact (hv.cons (phase a)).trans p.symm
      cases n with
      | zero => rfl
      | succ n =>
        simp only [testOne, Bool.or_eq_true]
        exact Or.inl (Or.inl (Or.inr (List.any_eq_true.mpr
          ⟨phase a, hm, tight_test tail ht' (n+1) _ hq⟩)))
    · have ht' : (insert (neg a) U).card + t = k := by
        rw [Finset.card_insert_of_notMem hu] at ht
        rw [Finset.card_insert_of_notMem hn]
        omega
      apply ih ht' n v
      have p₁ := (Finset.toList_insert hu).map phase
      have p₂ := (Finset.toList_insert hn).map phase
      simp only [List.map_cons, phase_neg] at p₁ p₂
      exact hp.trans (p₁.trans p₂.symm)
  | @binary k t U a b d ha hb hab hf tail ih =>
    have hn : bin d a b ∉ U := fun hm =>
      hf (Finset.mem_insert_of_mem (Finset.mem_insert_of_mem hm))
    have hs := LiveCheck.live_size tail
    rw [Finset.card_insert_of_notMem hn] at hs
    intro n v hp
    cases n with
    | zero => rfl
    | succ n =>
      by_cases hau : a ∈ U
      · have hbu : b ∉ U := by
          intro hbU
          rw [Finset.insert_eq_of_mem hbU, Finset.insert_eq_of_mem hau] at ht
          omega
        have hai : a ∈ insert b U := Finset.mem_insert_of_mem hau
        have ht' : (insert (bin d a b) U).card + t = k+1 := by
          rw [Finset.insert_eq_of_mem hai, Finset.card_insert_of_notMem hbu] at ht
          rw [Finset.card_insert_of_notMem hn]
          omega
        have hpU : U.toList.Perm (a :: (U.erase a).toList) := by
          simpa only [Finset.insert_erase hau] using
            (Finset.toList_insert (Finset.notMem_erase a U))
        have p : v.Perm (phase b :: phase a :: (U.erase a).toList.map phase) := by
          rw [Finset.insert_eq_of_mem hai] at hp
          exact hp.trans (((Finset.toList_insert hbu).map phase).trans
            ((hpU.map phase).cons (phase b)))
        obtain ⟨w, hw, hpw⟩ := UnorderedPairs.keep_step_mem p (op_mem d b a) false
        have he : bin d b a = bin d a b := by cases d <;> simp [bin, BitVec.and_comm, BitVec.or_comm]
        have hq : w.Perm ((insert (bin d a b) U).toList.map phase) := by
          simp only [Bool.false_eq_true, ↓reduceIte, he] at hpw
          exact (hpw.trans ((hpU.map phase).symm.cons _)).trans
            ((Finset.toList_insert hn).map phase).symm
        simp only [testOne, Bool.or_eq_true]
        exact Or.inr (List.any_eq_true.mpr ⟨w, hw,
          by simp [cover tail hq, tight_test tail ht' n w hq]⟩)
      · by_cases hbu : b ∈ U
        · have hai : a ∉ insert b U := by simpa [Finset.mem_insert, hab] using hau
          have ht' : (insert (bin d a b) U).card + t = k+1 := by
            rw [Finset.insert_eq_of_mem hbu, Finset.card_insert_of_notMem hau] at ht
            rw [Finset.card_insert_of_notMem hn]
            omega
          have hpU : U.toList.Perm (b :: (U.erase b).toList) := by
            simpa only [Finset.insert_erase hbu] using
              (Finset.toList_insert (Finset.notMem_erase b U))
          have p : v.Perm (phase a :: phase b :: (U.erase b).toList.map phase) := by
            rw [Finset.insert_eq_of_mem hbu] at hp
            exact hp.trans (((Finset.toList_insert hau).map phase).trans
              ((hpU.map phase).cons (phase a)))
          obtain ⟨w, hw, hpw⟩ := UnorderedPairs.keep_step_mem p (op_mem d a b) false
          have hq : w.Perm ((insert (bin d a b) U).toList.map phase) := by
            simp only [Bool.false_eq_true, ↓reduceIte] at hpw
            exact (hpw.trans ((hpU.map phase).symm.cons _)).trans
              ((Finset.toList_insert hn).map phase).symm
          simp only [testOne, Bool.or_eq_true]
          exact Or.inr (List.any_eq_true.mpr ⟨w, hw,
            by simp [cover tail hq, tight_test tail ht' n w hq]⟩)
        · have hai : a ∉ insert b U := by simpa [Finset.mem_insert, hab] using hau
          have ht' : (insert (bin d a b) U).card + t = k := by
            rw [Finset.card_insert_of_notMem hai, Finset.card_insert_of_notMem hbu] at ht
            rw [Finset.card_insert_of_notMem hn]
            omega
          have p : v.Perm (phase a :: phase b :: U.toList.map phase) := by
            exact hp.trans (((Finset.toList_insert hai).map phase).trans
              (((Finset.toList_insert hbu).map phase).cons (phase a)))
          obtain ⟨w, hw, hpw⟩ := UnorderedPairs.step_mem p (op_mem d a b)
          have hq : w.Perm ((insert (bin d a b) U).toList.map phase) :=
            hpw.trans ((Finset.toList_insert hn).map phase).symm
          simp only [testOne, Bool.or_eq_true]
          exact Or.inl (Or.inr (List.any_eq_true.mpr ⟨w, hw,
            by simp [cover tail hq, ih ht' n w hq]⟩))
lemma any_false_fin {α : Type} (xs : List α) (f : α → Bool)
    (h : ∀ i : Fin xs.length, f xs[i] = false) : xs.any f = false := by
  apply List.any_eq_false.mpr
  intro a ha
  obtain ⟨i, hi⟩ := List.mem_iff_get.mp ha
  have hx : xs[i] = a := hi
  have he := h i
  rw [hx] at he
  simp only [he, Bool.false_eq_true, not_false_eq_true]

lemma testOne_succ_false (n : Nat) (v : List Sig)
    (hl : ¬v.length ≤ 1)
    (hd : ∀ i : Fin v.length, test (n+1) (v[i] :: v) = false)
    (hc : ∀ i : Fin (UnorderedPairs.steps v).length,
      ((unionSep true (UnorderedPairs.steps v)[i] == top) && testOne n (UnorderedPairs.steps v)[i]) = false)
    (hk : ∀ i : Fin (UnorderedPairs.keepSteps v).length,
      ((unionSep true (UnorderedPairs.keepSteps v)[i] == top) && test n (UnorderedPairs.keepSteps v)[i]) = false) :
    testOne (n+1) v = false := by
  have h₁ := any_false_fin v (fun a => test (n+1) (a :: v)) hd
  have h₂ := any_false_fin (UnorderedPairs.steps v) (fun w => (unionSep true w == top) && testOne n w) hc
  have h₃ := any_false_fin (UnorderedPairs.keepSteps v) (fun w => (unionSep true w == top) && test n w) hk
  simp only [testOne, h₁, h₂, h₃, hl, decide_false, Bool.false_or]

lemma test_succ_false (n : Nat) (v : List Sig)
    (hl : ¬v.length ≤ 1)
    (hc : ∀ i : Fin (UnorderedPairs.steps v).length,
      ((unionSep true (UnorderedPairs.steps v)[i] == top) && test n (UnorderedPairs.steps v)[i]) = false) :
    test (n+1) v = false := by
  have h₁ := any_false_fin (UnorderedPairs.steps v) (fun w => (unionSep true w == top) && test n w) hc
  simp only [test, h₁, hl, decide_false, Bool.false_or]

end PEqualNP.Outside.L_meta_670_aux.UnorderedFormula

-- UnorderedEmbedding
namespace PEqualNP.Outside.L_meta_670_aux.UnorderedFormula
open LiveCheck TightFormula

lemma test_implies_one {n : Nat} {v : List Sig} : test n v = true → testOne n v = true := by
  induction n generalizing v with
  | zero => intro _; rfl
  | succ n ih =>
    intro h
    simp only [test, Bool.or_eq_true] at h
    simp only [testOne, Bool.or_eq_true]
    rcases h with h | h
    · exact Or.inl (Or.inl (Or.inl h))
    · obtain ⟨w, hw, hc⟩ := List.any_eq_true.mp h
      simp only [Bool.and_eq_true] at hc
      obtain ⟨hc, ht⟩ := hc
      exact Or.inl (Or.inr (List.any_eq_true.mpr
        ⟨w, hw, by simp only [hc, ih ht, Bool.true_and]⟩))

end PEqualNP.Outside.L_meta_670_aux.UnorderedFormula

-- FirstOrbit
namespace PEqualNP.Outside.L_meta_670_aux.FirstOrbit
open LiveCheck LiteralBinary

lemma literal_sign {a : Sig} (ha : a ∈ literals) :
    a = raw.getD (LiteralBinary.index a).val zero ∨
      a = neg (raw.getD (LiteralBinary.index a).val zero) := by
  have hc : literals.all (fun a =>
      (a == raw.getD (LiteralBinary.index a).val zero) ||
      (a == neg (raw.getD (LiteralBinary.index a).val zero))) = true := by
    decide +kernel
  simpa only [Bool.or_eq_true, beq_iff_eq] using List.all_eq_true.mp hc a ha

lemma raw_literal : ∀ i : Fin 9, raw.getD i.val zero ∈ literals := by decide +kernel

lemma signed_indices : ∀ i : Fin 9,
    LiteralBinary.index (raw.getD i.val zero) = i ∧
      LiteralBinary.index (neg (raw.getD i.val zero)) = i := by decide +kernel

lemma action_literal (g : Fin 12) {a : Sig} (ha : a ∈ literals) :
    action g a ∈ literals := by
  rcases literal_sign ha with h | h
  · rw [h, ← rawImage_eq]
    exact raw_literal _
  · rw [h, action_neg, ← rawImage_eq]
    exact neg_literal (raw_literal _)

lemma action_index (g : Fin 12) {a : Sig} (ha : a ∈ literals) :
    LiteralBinary.index (action g a) = rawSym g (LiteralBinary.index a) := by
  rcases literal_sign ha with h | h
  · conv_lhs => rw [h, ← rawImage_eq]
    exact (signed_indices _).1
  · conv_lhs => rw [h, action_neg, ← rawImage_eq]
    exact (signed_indices _).2

lemma bin_swap (d : Bool) (a b : Sig) : bin d a b = bin d b a := by
  cases d <;> simp [bin, BitVec.and_comm, BitVec.or_comm]

lemma constant_pair (d : Bool) (a : Sig) : ¬ proper (bin d a (neg a)) := by
  cases d <;> simp [bin, neg, proper, zero, one, top]

lemma indices_distinct {a b : Sig} {d : Bool}
    (ha : a ∈ literals) (hb : b ∈ literals) (hab : a ≠ b)
    (hp : proper (bin d a b)) : LiteralBinary.index a ≠ LiteralBinary.index b := by
  intro hi
  obtain ha' | ha' := literal_sign ha
  · obtain hb' | hb' := literal_sign hb
    · exact hab (ha'.trans (by simpa [← hi] using hb'.symm))
    · have hb'' : b = neg a := by rw [hb', ← hi, ← ha']
      rw [hb''] at hp
      exact constant_pair d a hp
  · obtain hb' | hb' := literal_sign hb
    · have ha'' : a = neg b := by rw [ha', hi, ← hb']
      rw [bin_swap, ha''] at hp
      exact constant_pair d b hp
    · exact hab (ha'.trans (by simpa [← hi] using hb'.symm))

lemma live_proper {k t : Nat} {S : Finset Sig} (h : Live k t S) :
    ∀ a ∈ S, proper a := by
  induction h with
  | stop =>
      have hp : proper target := by unfold proper target zero one top; decide
      simpa using hp
  | unary ha hf tail ih =>
      simpa using And.intro ha (fun a h => ih a (Finset.mem_insert_of_mem h))
  | binary ha hb hab hf tail ih =>
      simp only [Finset.forall_mem_insert]
      exact ⟨ha, hb, fun a h => ih a (Finset.mem_insert_of_mem h)⟩

lemma first_cut {k t : Nat} {U : Finset Sig} {a b : Sig} {d : Bool}
    (ha : a ∈ literals) (hb : b ∈ literals) (hab : a ≠ b)
    (hu : ∀ z ∈ U, z ∈ literals) (hf : bin d a b ∉ U)
    (h : Live k t (insert (bin d a b) U)) :
    ∃ a' b' : Sig, ∃ U' : Finset Sig,
      a' ∈ literals ∧ b' ∈ literals ∧ a' ≠ b' ∧
      (LiteralBinary.index a', LiteralBinary.index b') ∈ pairReps ∧
      (∀ z ∈ U', z ∈ literals) ∧ U'.card = U.card ∧
      bin d a' b' ∉ U' ∧ Live k t (insert (bin d a' b') U') := by
  have hi := indices_distinct ha hb hab (live_proper h _ (Finset.mem_insert_self _ _))
  obtain ⟨g, hg⟩ := pair_orbits (LiteralBinary.index a) (LiteralBinary.index b) hi
  have htail : Live k t (insert (bin d (action g a) (action g b)) (U.image (action g))) := by
    simpa only [Finset.image_insert, action_bin] using live_action h g
  have hual : ∀ z ∈ U.image (action g), z ∈ literals := by
    intro z hz
    obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp hz
    exact action_literal g (hu x hx)
  have hc : (U.image (action g)).card = U.card := Finset.card_image_of_injective _ (action_injective g)
  have hne : action g a ≠ action g b := fun he => hab (action_injective g he)
  have hf' : bin d (action g a) (action g b) ∉ U.image (action g) := by
    rw [← action_bin]
    intro hx
    obtain ⟨z, hz, he⟩ := Finset.mem_image.mp hx
    exact hf ((action_injective g he) ▸ hz)
  rcases hg with hg | hg
  · refine ⟨action g a, action g b, U.image (action g), action_literal g ha,
      action_literal g hb, hne, ?_, hual, hc, hf', htail⟩
    simpa only [action_index g ha, action_index g hb] using hg
  · refine ⟨action g b, action g a, U.image (action g), action_literal g hb,
      action_literal g ha, Ne.symm hne, ?_, hual, hc, ?_, ?_⟩
    · simpa only [action_index g ha, action_index g hb] using hg
    · simpa only [bin_swap d (action g b) (action g a)] using hf'
    · simpa only [bin_swap d (action g b) (action g a)] using htail

end PEqualNP.Outside.L_meta_670_aux.FirstOrbit

-- UnorderedEndgame
namespace PEqualNP.Outside.L_meta_670_aux.UnorderedEndgame
open LiveCheck LiteralBinary TightFormula
lemma one_duplicate {n : Nat} {a : Sig} {v : List Sig}
    (ha : a ∈ v) (ht : UnorderedFormula.test (n+1) (a :: v) = true) :
    UnorderedFormula.testOne (n+1) v = true := by
  simp only [UnorderedFormula.testOne, Bool.or_eq_true]
  exact Or.inl (Or.inl (Or.inr (List.any_eq_true.mpr ⟨a, ha, ht⟩)))
lemma first_cut_impossible {k t : Nat} {U : Finset Sig} {a b : Sig} {d : Bool}
    (ha' : a ∈ literals) (hb' : b ∈ literals) (hab : a ≠ b)
    (hu : ∀ z ∈ U, z ∈ literals) (tail : Live k t (insert (bin d a b) U))
    (fresh : bin d a b ∉ U) (hk : k ≤ t+10)
    (checkedOne : UnorderedFormula.testOne 4 (phase (bin d a b) :: inputs) = false) : False := by
  have hsize := LiveCheck.live_size tail
  rw [Finset.card_insert_of_notMem fresh] at hsize
  have huc : U.card ≤ 10 := by omega
  obtain ⟨extra, he, hm, hp⟩ := retained_extension ha' hb' hab hu tail huc
  have hc : U.card = extra.length + 9 := by
    have hl := hp.length_eq
    simpa only [List.length_map, Finset.length_toList, List.length_append,
      inputs, List.length_map, List.length_finRange] using hl
  have falseResult := checkedOne
  cases extra with
  | nil =>
    simp only [List.nil_append] at hp
    have hq : (phase (bin d a b) :: inputs).Perm
        ((insert (bin d a b) U).toList.map phase) :=
      (hp.symm.cons _).trans ((Finset.toList_insert fresh).map phase).symm
    have ht' : UnorderedFormula.testOne 4 (phase (bin d a b) :: inputs) = true := by
      by_cases heq : k = t+10
      · apply UnorderedFormula.one_test tail _ 4 _ hq
        rw [Finset.card_insert_of_notMem fresh]
        simp only [List.length_nil, Nat.zero_add] at hc
        omega
      · apply UnorderedFormula.test_implies_one
        apply UnorderedFormula.tight_test tail _ 4 _ hq
        rw [Finset.card_insert_of_notMem fresh]
        simp only [List.length_nil, Nat.zero_add] at hc
        omega
    rw [falseResult] at ht'
    cases ht'
  | cons x xs =>
    cases xs with
    | cons y ys => simp only [List.length_cons] at he; omega
    | nil =>
      have hx : x ∈ inputs := hm (by simp)
      simp only [List.cons_append, List.nil_append] at hp
      have ht : (insert (bin d a b) U).card + t = k+1 := by
        rw [Finset.card_insert_of_notMem fresh]
        simp only [List.length_cons, List.length_nil] at hc
        omega
      have hq : (x :: phase (bin d a b) :: inputs).Perm
          ((insert (bin d a b) U).toList.map phase) :=
        ((List.Perm.swap _ _ _).trans (hp.symm.cons _)).trans
          ((Finset.toList_insert fresh).map phase).symm
      have ht' := UnorderedFormula.tight_test tail ht 4 _ hq
      have hh := one_duplicate (List.mem_cons_of_mem _ hx) ht'
      rw [falseResult] at hh
      cases hh

lemma lower_twelve_by_cuts
    (cuts : ∀ (k t : Nat) (U : Finset Sig) (a b : Sig) (d : Bool),
      a ∈ literals → b ∈ literals → a ≠ b → (∀ z ∈ U, z ∈ literals) →
      Live k t (insert (bin d a b) U) → bin d a b ∉ U → k ≤ t+10 → False)
    {k t S} (h : Live k t S) :
    (∀ a ∈ S, a ∈ literals) → t+12 ≤ k := by
  induction h with
  | stop =>
    intro hs
    exact False.elim (target_not_literal (hs target (by simp)))
  | @unary k t U a ha hf tail ih =>
    intro hs
    have hh := ih (fun z hz => by
      rcases Finset.mem_insert.mp hz with rfl | hz
      · exact neg_literal (hs a (Finset.mem_insert_self _ _))
      · exact hs z (Finset.mem_insert_of_mem hz))
    omega
  | @binary k t U a b d ha hb hab hf tail ih =>
    intro hs
    by_contra hn
    have hu : ∀ z ∈ U, z ∈ literals :=
      fun z hz => hs z (Finset.mem_insert_of_mem (Finset.mem_insert_of_mem hz))
    have ha' := hs a (Finset.mem_insert_self _ _)
    have hb' := hs b (Finset.mem_insert_of_mem (Finset.mem_insert_self _ _))
    exact cuts k t U a b d ha' hb' hab hu tail
      (fun hz => hf (Finset.mem_insert_of_mem (Finset.mem_insert_of_mem hz))) (by omega)
lemma lower_twelve_representatives
    (checkedReps : ∀ p ∈ LiveCheck.pairReps,
      ∀ z ∈ ops (phase (raw.getD p.1.val zero)) (phase (raw.getD p.2.val zero)),
        UnorderedFormula.testOne 4 (z :: inputs) = false)
    {k t S} (h : Live k t S) (hs : ∀ a ∈ S, a ∈ literals) : t+12 ≤ k := by
  apply lower_twelve_by_cuts _ h hs
  intro k t U a b d ha hb hab hu tail fresh hk
  obtain ⟨a', b', U', ha', hb', hab', hp, hu', hc, hf', ht'⟩ :=
    FirstOrbit.first_cut ha hb hab hu fresh tail
  have hm := op_mem d a' b'
  rw [literal_phase_index ha', literal_phase_index hb'] at hm
  exact first_cut_impossible ha' hb' hab' hu' ht' hf' hk
    (checkedReps (index a', index b') hp _ hm)

lemma high_nots
    (checkedReps : ∀ p ∈ LiveCheck.pairReps,
      ∀ z ∈ ops (phase (raw.getD p.1.val zero)) (phase (raw.getD p.2.val zero)),
        UnorderedFormula.testOne 4 (z :: inputs) = false)
    {t : Nat} (ht : 4 ≤ t) : Impossible 15 t raw := by
  intro k hk h
  have hb := lower_twelve_representatives checkedReps h
    (fun a ha => List.mem_append_left _ (List.mem_toFinset.mp ha))
  omega

end PEqualNP.Outside.L_meta_670_aux.UnorderedEndgame
