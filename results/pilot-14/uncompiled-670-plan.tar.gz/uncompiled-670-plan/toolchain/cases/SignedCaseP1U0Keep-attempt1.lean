import SignedCaseP1U0Common
import UnorderedFirst02U0Keep
namespace PEqualNP.Outside.L_meta_670_aux.UnorderedFormula.FiniteP1U0
open LiveCheck TightFormula
set_option maxRecDepth 20000 in
set_option maxHeartbeats 0 in
lemma keep (i : Fin (UnorderedPairs.keepSteps state).length) :
    ((unionSep true (UnorderedPairs.keepSteps state)[i] == top) &&
      UnorderedFormula.test 3 (UnorderedPairs.keepSteps state)[i]) = false := by
  have hs : state = UnorderedFirst02U0.state := by
    rw [state,inputs_eq]
    rfl
  simpa only [hs] using (UnorderedFirst02U0.keep_checked
    ⟨i.val,by simpa only [hs] using i.isLt⟩)

end PEqualNP.Outside.L_meta_670_aux.UnorderedFormula.FiniteP1U0
