import Lean

open Lean

def samePre : Syntax.Preresolved → Syntax.Preresolved → Bool
  | .namespace a, .namespace b => a == b
  | .decl a fs, .decl b gs => a == b && fs == gs
  | _, _ => false

def samePres : List Syntax.Preresolved → List Syntax.Preresolved → Bool
  | [], [] => true
  | a :: as, b :: bs => samePre a b && samePres as bs
  | _, _ => false

partial def sameSyntax : Syntax → Syntax → Bool
  | .missing, .missing => true
  | .atom _ a, .atom _ b => a == b
  | .ident _ ra a pa, .ident _ rb b pb =>
      ra.toString == rb.toString && a == b && samePres pa pb
  | .node _ ka as, .node _ kb bs =>
      ka == kb && as.size == bs.size &&
        (List.range as.size).all (fun i => sameSyntax as[i]! bs[i]!)
  | _, _ => false

def checkMessages (messages : MessageLog) : IO Unit := do
  if messages.hasErrors then
    for message in messages.toList do
      IO.eprintln (← message.toString)
    throw (IO.userError "Parser errors prevent an AST comparison")

def parseFile (env : Environment) (path : String) : IO (Array Syntax) := do
  let source ← IO.FS.readFile path
  let input := Parser.mkInputContext source path
  let (header, initial, messages) ← Parser.parseHeader input
  checkMessages messages
  let mut result := #[header.raw]
  let mut state := initial
  let mut context : Parser.ParserModuleContext := { env, options := {} }
  let mut scopes : List Name := []
  repeat
    let (command, next, messages) := Parser.parseCommand input context state {}
    checkMessages messages
    result := result.push command
    if Parser.isTerminalCommand command then break
    if next.pos == state.pos then
      throw (IO.userError "Parser made no progress")
    if command.isOfKind ``Parser.Command.namespace then
      scopes := context.currNamespace :: scopes
      context := { context with currNamespace := context.currNamespace ++ command[1].getId }
    else if command.isOfKind ``Parser.Command.section then
      scopes := context.currNamespace :: scopes
    else if command.isOfKind ``Parser.Command.end then
      match scopes with
      | old :: rest =>
          context := { context with currNamespace := old }
          scopes := rest
      | [] => throw (IO.userError "Unmatched namespace or section end")
    state := next
  if !scopes.isEmpty then
    throw (IO.userError "Unclosed namespace or section")
  return result

unsafe def main (args : List String) : IO UInt32 := do
  let [leftPath, rightPath] := args
    | IO.eprintln "Expected two source paths"; return 2
  initSearchPath (← findSysroot)
  enableInitializersExecution
  let env ← importModules #[{ module := `Mathlib }, { module := `PEqualNP.Defs }] {}
  let left ← parseFile env leftPath
  let right ← parseFile env rightPath
  unless left.size == right.size do
    IO.eprintln s!"Different command counts: {left.size}, {right.size}"
    return 1
  for index in [:left.size] do
    unless sameSyntax left[index]! right[index]! do
      IO.eprintln s!"Different AST at command {index}: {left[index]!.getKind}, {right[index]!.getKind}"
      return 1
  IO.println s!"PASS: all {left.size} command ASTs match, ignoring only SourceInfo and raw substring offsets"
  return 0
