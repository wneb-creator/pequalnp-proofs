import SignedCaseP3U3Common
namespace PEqualNP.Outside.L_meta_670_aux.UnorderedFormula.FiniteP3U3
open LiveCheck TightFormula
def duplicate0 : List Sig := state[0] :: state
set_option maxRecDepth 20000 in
set_option maxHeartbeats 0 in
lemma duplicate0_children (i : Fin (UnorderedPairs.steps duplicate0).length) :
    ((unionSep true (UnorderedPairs.steps duplicate0)[i] == top) &&
      UnorderedFormula.test 3 (UnorderedPairs.steps duplicate0)[i]) = false := by
  fin_cases i <;> decide +kernel

lemma duplicate0_excluded : UnorderedFormula.test 4 duplicate0 = false :=
  test_succ_false 3 duplicate0 (by decide +kernel) duplicate0_children

end PEqualNP.Outside.L_meta_670_aux.UnorderedFormula.FiniteP3U3
