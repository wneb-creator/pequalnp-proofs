import SignedCaseP3U3Common
namespace PEqualNP.Outside.L_meta_670_aux.UnorderedFormula.FiniteP3U3
open LiveCheck TightFormula
def duplicate4 : List Sig := state[4] :: state
set_option maxRecDepth 20000 in
set_option maxHeartbeats 0 in
lemma duplicate4_children (i : Fin (UnorderedPairs.steps duplicate4).length) :
    ((unionSep true (UnorderedPairs.steps duplicate4)[i] == top) &&
      UnorderedFormula.test 3 (UnorderedPairs.steps duplicate4)[i]) = false := by
  fin_cases i <;> decide +kernel

lemma duplicate4_excluded : UnorderedFormula.test 4 duplicate4 = false :=
  test_succ_false 3 duplicate4 (by decide +kernel) duplicate4_children

end PEqualNP.Outside.L_meta_670_aux.UnorderedFormula.FiniteP3U3
