import SignedCaseP3U3Duplicates
import SignedCaseP3U3Consume
import SignedCaseP3U3Keep
namespace PEqualNP.Outside.L_meta_670_aux.UnorderedFormula.FiniteP3U3
open LiveCheck TightFormula
lemma excluded : UnorderedFormula.testOne 4 state = false :=
  testOne_succ_false 3 state (by decide +kernel) duplicates consume keep

end PEqualNP.Outside.L_meta_670_aux.UnorderedFormula.FiniteP3U3
