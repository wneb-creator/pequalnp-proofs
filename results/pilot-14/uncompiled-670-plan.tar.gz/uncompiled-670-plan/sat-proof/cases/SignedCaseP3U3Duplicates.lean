import SignedCaseP3U3Common
import SignedCaseP3U3Dup0
import SignedCaseP3U3Dup4
namespace PEqualNP.Outside.L_meta_670_aux.UnorderedFormula.FiniteP3U3
open LiveCheck TightFormula
set_option maxRecDepth 20000 in
set_option maxHeartbeats 0 in
lemma duplicates (i : Fin state.length) :
    UnorderedFormula.test 4 (state[i] :: state) = false := by
  fin_cases i
  · exact duplicate0_excluded
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · exact duplicate4_excluded
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel

end PEqualNP.Outside.L_meta_670_aux.UnorderedFormula.FiniteP3U3
