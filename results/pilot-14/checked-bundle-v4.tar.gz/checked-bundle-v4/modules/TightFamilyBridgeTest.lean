import TightFirstData
namespace PEqualNP.Outside.L_meta_670_aux.TightFormula
open LiveCheck LiteralBinary
lemma from_cases (h : ∀ i j u, firstCase i j u = false) :
    ∀ a ∈ literals, ∀ b ∈ literals, ∀ d,
      test 3 (phase (bin d a b) :: inputs) = false := by
  intro a ha b hb d
  have hg := op_mem d a b
  rw [literal_phase_index ha, literal_phase_index hb] at hg
  simp only [ops, List.mem_cons, List.not_mem_nil, or_false] at hg
  rcases hg with he | he | he | he
  · rw [he]; exact h (index a) (index b) 0
  · rw [he]; exact h (index a) (index b) 1
  · rw [he]; exact h (index a) (index b) 2
  · rw [he]; exact h (index a) (index b) 3
lemma high_nots_eleven (checked : ∀ i j u, firstCase i j u = false)
    {t : Nat} (ht : 5 ≤ t) : Impossible 15 t raw := by
  intro k hk h
  have hb := lower_eleven (from_cases checked) h
    (fun a ha => List.mem_append_left _ (List.mem_toFinset.mp ha))
  omega
end PEqualNP.Outside.L_meta_670_aux.TightFormula
