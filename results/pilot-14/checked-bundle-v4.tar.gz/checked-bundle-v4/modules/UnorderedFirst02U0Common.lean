import UnorderedEmbeddingTest

namespace PEqualNP.Outside.L_meta_670_aux.UnorderedFirst02U0
open LiveCheck TightFormula

def state : List Sig := phase (bin false (phase raw0) (phase raw2)) :: raw.map phase
def duplicate (i : Nat) : List Sig := state.getD i zero :: state
def consume43 : List Sig := (UnorderedPairs.steps state).getD 43 []

lemma state_length : state.length = 10 := by decide +kernel
lemma consume_length : (UnorderedPairs.steps state).length = 180 := by decide +kernel
lemma keep_length : (UnorderedPairs.keepSteps state).length = 360 := by decide +kernel
lemma consume43_length : consume43.length = 9 := by decide +kernel
lemma duplicate_length (i : Nat) : (duplicate i).length = 11 := by
  simp only [duplicate,List.length_cons,state_length]

end PEqualNP.Outside.L_meta_670_aux.UnorderedFirst02U0
