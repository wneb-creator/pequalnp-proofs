import SignedCaseP1U0Common
import UnorderedFirst02U0Keep
namespace PEqualNP.Outside.L_meta_670_aux.UnorderedFormula.FiniteP1U0
open LiveCheck TightFormula
set_option maxRecDepth 20000 in
set_option maxHeartbeats 0 in
lemma keep (i : Fin (UnorderedPairs.keepSteps state).length) :
    ((unionSep true (UnorderedPairs.keepSteps state)[i] == top) &&
      UnorderedFormula.test 3 (UnorderedPairs.keepSteps state)[i]) = false := by
  exact UnorderedFirst02U0.keep_checked i

end PEqualNP.Outside.L_meta_670_aux.UnorderedFormula.FiniteP1U0
