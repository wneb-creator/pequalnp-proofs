import UnorderedEndgameTest
namespace PEqualNP.Outside.L_meta_670_aux.UnorderedRepresentativeFamily
open LiveCheck TightFormula

def state (p : Fin 6) (u : Fin 4) : List Sig :=
  let q := pairReps.getD p.val (0, 0)
  (ops (phase (raw.getD q.1.val zero)) (phase (raw.getD q.2.val zero))).getD u.val zero :: inputs

lemma pair_reps_length : pairReps.length = 6 := by decide +kernel

lemma checkedReps_of_fin
    (h : ∀ (p : Fin 6) (u : Fin 4), UnorderedFormula.testOne 4 (state p u) = false) :
    ∀ p ∈ pairReps,
      ∀ z ∈ ops (phase (raw.getD p.1.val zero)) (phase (raw.getD p.2.val zero)),
        UnorderedFormula.testOne 4 (z :: inputs) = false := by
  intro p hp z hz
  obtain ⟨ip, hip⟩ := List.mem_iff_get.mp hp
  have hi : ip.val < 6 := by simpa only [pair_reps_length] using ip.isLt
  let i : Fin 6 := ⟨ip.val, hi⟩
  have he : pairReps.getD i.val (0, 0) = p := by
    simp only [i, List.getD_eq_getElem?_getD, List.getElem?_eq_getElem ip.isLt, Option.getD_some]
    exact hip
  obtain ⟨ju, hju⟩ := List.mem_iff_get.mp hz
  have hj : ju.val < 4 := by simpa only [ops, List.length_cons, List.length_nil] using ju.isLt
  let j : Fin 4 := ⟨ju.val, hj⟩
  have hz' : (ops (phase (raw.getD p.1.val zero)) (phase (raw.getD p.2.val zero))).getD j.val zero = z := by
    change (ops (phase (raw.getD p.1.val zero)) (phase (raw.getD p.2.val zero))).getD ju.val zero = z
    rw [List.getD_eq_getElem?_getD]
    rw [List.getElem?_eq_getElem ju.isLt]
    exact hju
  have hh := h i j
  dsimp only [state] at hh
  rw [he, hz'] at hh
  exact hh

end PEqualNP.Outside.L_meta_670_aux.UnorderedRepresentativeFamily
