#!/usr/bin/env python3
"""Verify a frozen source bundle and rebuild selected Lean roots in dependency order."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--lean-dir', type=Path, required=True, help='The pinned pequalnp-proofs/lean directory')
parser.add_argument('--root', action='append', default=[], help='Root module to rebuild; repeat to select several (default: all bundled roots)')
parser.add_argument('--verify-only', action='store_true', help='Verify source and external-file hashes without compiling')
args = parser.parse_args()
bundle = Path(__file__).resolve().parent
manifest = json.loads((bundle / 'manifest.json').read_text())
lean_dir = args.lean_dir.resolve()
modules = {entry['module']: entry for entry in manifest['modules']}
errors = []
for entry in modules.values():
    path = bundle / entry['copy']
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != entry['sha256']:
        errors.append('Bundled source hash mismatch: ' + entry['module'])
for entry in manifest['external_repo_files']:
    path = lean_dir.parent / entry['path']
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != entry['sha256']:
        errors.append('Pinned external file hash mismatch: ' + entry['path'])
roots = args.root or manifest['roots']
for root in roots:
    if root not in modules:
        errors.append('Unknown bundled root: ' + root)
if errors:
    print('\n'.join(errors), file=sys.stderr)
    sys.exit(1)
print('Verified all bundled sources and pinned project files.')
if args.verify_only:
    sys.exit(0)
needed = set()
def visit(module):
    if module not in modules or module in needed:
        return
    needed.add(module)
    for child in modules[module]['imports']:
        visit(child)
for root in roots:
    visit(root)
module_dir = bundle / 'modules'
log_dir = bundle / 'rebuild-logs'
log_dir.mkdir(exist_ok=True)
process_env = os.environ.copy()
process_env['LEAN_PATH'] = str(module_dir) + os.pathsep + process_env.get('LEAN_PATH', '')
for module in manifest['build_order']:
    if module not in needed:
        continue
    source = bundle / modules[module]['copy']
    output = source.with_suffix('.olean')
    log = log_dir / (module + '.log')
    print('Building ' + module + '; complete output: ' + str(log), flush=True)
    with log.open('wb') as stream:
        result = subprocess.run(['lake', 'env', 'lean', '-R', str(module_dir), '-o', str(output), str(source)], cwd=lean_dir, env=process_env, stdout=stream, stderr=subprocess.STDOUT)
    if result.returncode:
        print('Build failed for ' + module + ' (exit ' + str(result.returncode) + '). See the complete log.', file=sys.stderr)
        sys.exit(result.returncode)
print('Built selected roots: ' + ', '.join(roots))
