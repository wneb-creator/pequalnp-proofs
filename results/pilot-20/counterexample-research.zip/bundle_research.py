import datetime
import hashlib
import json
import shutil
from pathlib import Path

base=Path('/tmp/oec/pequalnp-pilot-20/search')
dest=Path('/tmp/oec/pequalnp-pilot-20/research-bundle/counterexample-search')
dest.mkdir(parents=True,exist_ok=True)
paths=sorted(p for p in base.rglob('*') if p.is_file() and not p.is_symlink())
selected=[]
for p in paths:
    rel=p.relative_to(base)
    keep=p.suffix in {'.py','.cpp','.stdout','.stderr','.sol','.gates','.extra'}
    if p.suffix=='.json':
        keep=('65' in p.name and not p.name.endswith('.meta.json')) or p.name in {
            'local64-missing.json','shannon64-missing.json','shannon64-canonical.json',
            'c6-8.json','environment-interruption.json','final-search-summary.json'} or any(tag in p.name for tag in ['-config.json','-seed.json','-free.json','-extra.json','-model.json'])
    if p.suffix=='.json' and ('local-core' in rel.parts or any(part.startswith('pair-cegar-') for part in rel.parts) or p.name.startswith('local-core-k2-') or p.name=='unsafe-core7-global66-validated.json') and not p.name.endswith('.meta.json'):keep=True
    if p.name=='README.md':keep=True
    if p.name.endswith('.status.json') or p.name=='unsafe-clause-seed-calibration.json':keep=True
    if rel.parts[:2]==('or-bound','bundle'):keep=True
    if not keep:continue
    if p.stat().st_size>4*1024*1024:
        raise RuntimeError(('unexpected large selected artifact',str(p),p.stat().st_size))
    q=dest/rel;q.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(p,q)
    selected.append(q)
for name in ['plane_automorphism.py','plane-automorphism.json']:
    p=base.parent/name
    q=dest/'symmetry'/name;q.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(p,q);selected.append(q)
stats={}
for name in ['local-batch1.stdout','local-batch2.stdout','local-core-batch.stdout','local-core-resumed.stdout','pair-cegar-751.stdout','pair-cegar-752.stdout','pair-cegar-763.stdout']:
    p=base/name
    if p.exists():
        counts={}
        rows=0
        pair_rounds=[]
        for line in p.read_text().splitlines():
            try:r=json.loads(line)
            except json.JSONDecodeError:continue
            if 'iteration' in r:pair_rounds.append(r)
            if 'returncode' in r:
                rows+=1;k=str(r['returncode']);counts[k]=counts.get(k,0)+1
        stats[name]=dict(completed_solver_calls=rows,return_codes=counts)
        if name.startswith('pair-cegar-'):
            stats[name]=dict(completed_rounds=len(pair_rounds),pair_candidates=sum(r['pair_candidate'] for r in pair_rounds),best_active=min((r['active'] for r in pair_rounds),default=None))
readme=f'''L-meta-1482 counterexample-search research snapshot

Snapshot UTC: {datetime.datetime.now(datetime.timezone.utc).isoformat()}
No proof or refutation of the posted at-most64-gate statement was found in these searches.
The preserved65-gate witnesses are valid upper bounds only. The main task independently
formalized the global witness in Lean; these native computations alone are not Lean proofs.

Validated witnesses (only the specifically named files below):
Other archived search states, including names containing65, may fail function or
derivative criteria; their names alone do not identify valid witnesses. Re-run the
validator and inspect all reported failures. Physical validators require last-gate output.
- shannon65-regression.json: global shared-F construction,65 gates,13AND+52OR,
  target(0,0), pivot2; shannon65-full.json also includes exact v/w and singleton tables.
- or-bound/shannon65-local-allflags.json: two-star localized construction,65 gates;
  double incidences exactly(0,0),(0,4),(0,10). No shared OR subexpression is needed.
- validate.py and validate_all.py independently check distinct earlier wires, all52
  minimal true assignments, all704 maximal false assignments, and formal derivatives.
  A monotone circuit matching those756 assignments matches all2^26 assignments.
- core6-global65-validated.json: a distinct65-gate construction with14AND+51OR,
  double incidences(0,4),(0,10),(0,12), independently validated on allcriticalinputs.
- unsafe-core7-global66-validated.json:66-gate seed withone unsafeAND; independently
  verified allcriticaltests and all52flags, bad(0,4),(0,10),(0,12).
- Negative near-seeds named *64-missing* deliberately miss an incidence and are NOT witnesses.

Methods and limits:
- search.cpp: bit-parallel mutation/annealing over all756 critical inputs, then four
  parallel52-bit singleton/derivative masks; any correctly computed double incidence
  is eligible. It interleaves spare gates, counts only the active cone, and supports
  neutral swaps/associative rotations and an optional explicit seed gate list.
- search_pairs.cpp and pair_cegar.py:352-row pair-only relaxation, all52flags,
  plus monotone semantic merging and runtime truth-preservation checks. Each
  pair-only64 candidate is archived, checked onall756criticals, and anyviolated
  maximalfalse closures are added for the next round. The completed9rounds made
  534642688 mutations and foundno64 pairmodel, so noCEGAR refinement was triggered.
  This does not prove a pair-matrix lower bound. Native diagnostic only.
- synthesis.py: one-hot binary earlier-wire choices, a<b, AND/OR semantics, exact
  selected-flag derivative equations, optional AND count, optional topological-order
  symmetry, optional physically signed initial phases, and fixed/free gate lists.
  Default104-row global instances are relaxations of all critical tests. Any SAT
  model requires independent full validation and refinement of missed negative rows.
- Initial global64, fixed48-prefix,13-AND full-phase, canonical13-AND, and12-AND
  branches each reached a600-second limit with UNKNOWN. No UNSAT conclusion follows.
- Several600-second annealing runs exceeded a billion combined mutations without
  a64 witness. Later superseded variants were intentionally interrupted; logs retain
  their actual state and do not claim exhaustive coverage.
- sat64-unrestricted-long:planned1800-second global64 run, no AND-count bound, no
  topological ordering restriction, initialized from the localized near-witness.
  The environment transition around01:37-01:38UTC killed this process before a
  terminal verdict: UNKNOWN/interrupted. Complete partialstdout/stderr are retained.
  It was not rerun. The first pair-only round and one local-type solve were also
  interrupted; environment-interruption.json records the exact saved states.
- local_resynth.py: delete one of65 gates, redirect to an operand, free a small graph
  neighborhood, fix and constant-fold the rest; refine any SAT model against all
  critical negatives. Batch1 uses48 attempts,width9,20seconds/solve; batch2 uses the
  localized seed with24 attempts,width6,10seconds/solve. Current counts: {json.dumps(stats)}.
- Native local solver return codes:10=SAT on that encoded subset,20=UNSAT for that
  fixed-neighborhood instance,0=UNKNOWN/time limit. Only a full validated64 model
  would refute the gap. A restricted UNSAT result is not a proof of the posted statement.

Calibrations:
- local_synthesis.py/local_core_batch.py run the nine compressed local incidence
  types with all minimaltrue/maximalfalse inputs and an existential double flag
  across every local edge. Each core has fixed preprocessing OR groups; these
  restrictions do not cover arbitrary fullplane circuits. Budget120seconds/type.
  The5-input two-star core has no5-gate double witness (nativeUNSAT); an independent
  exhaustive enumeration by lemma_search checked101,606,400 five-gate netlists.
  Positivecontrols:5-gate ordinary and6-gate privateedge-double areSAT and checked
  on all32 valuations;6-gate commonedge-double isnativeUNSAT.
- C6 dual≤4free-OR-AND gates wasnativeUNSAT; C12dual≤10 wasUNKNOWN after60seconds,
  both under disjoint-input normalization forfunction-only existence, not derivatives.
- C6=K3,3 minus diagonal:≤7 total gates UNSAT;8 gates SAT and independently checked
  on all64 valuations. These are native solver results, not Lean-checked lower bounds.
- Free-OR C6:2AND UNSAT,3AND SAT. C12 with5AND was UNKNOWN unrestricted at60seconds,
  then UNSAT under a separately justified disjoint-input normalization.
- Free-OR plane12AND was UNKNOWN after300seconds. A13AND double-reread branch with
  selector sum≤78 is a restricted physical-cost search, planned for1800seconds; its
  exact status and limits are recorded in or-bound/README.md and complete logs.
- A final700-second14AND/shared-OR branch requires an unsafeAND, using the exact
 704 maximalfalse evaluations. See itsconfig,status,andfullstdout/stderr; it is
 a restricted search family, not an exhaustive64 encoding. The predicate was
 independently calibrated on safe65 and unsafe66 seeds using8192false closures.
- Disjoint-input normalization must NOT be used when preserving double reread.
- Supplied part-preserving plane automorphism was independently checked on169 pairs;
  with translations and multiplier3, explicit permutations for all52 flags were
  independently checked to send their flag to(0,0). This symmetry is computationally
  checked, not a Lean theorem. Distinct-wire legality and the recurrence form are
  invariant under such input relabeling.

This bundle intentionally omits giant DIMACS inputs, binaries, and intermediate
semantic-variable maps. Source, seed, free-list, extra-negative, and config files
allow regeneration. Scripts evolved during early experiments; the preserved source
is the latest version, while complete logs preserve actual earlier limits/results.
This is the final frozen snapshot. All search runs stopped by01:58:50UTC.
The final unsafe-AND branch returned UNKNOWN at its700-second limit.
No64-gate witness, even for the pair-only relaxation, was found.
See final-search-summary.json for consolidated outcomes and exact scopes.
'''
(dest/'README.txt').write_text(readme)
selected.append(dest/'README.txt')
manifest=[]
for p in sorted(set(selected)):
    b=p.read_bytes()
    manifest.append(dict(path=str(p.relative_to(dest)),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(dict(destination=str(dest),files=len(manifest),bytes=sum(x['bytes'] for x in manifest),local_status=stats)))
