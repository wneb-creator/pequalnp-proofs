import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
data = json.loads(path.read_text())
gates = data['gates']
assert all(op in (0, 1) and 0 <= a < 26 + i and 0 <= b < 26 + i and a != b
           for i, (a, b, op) in enumerate(gates))
inc = [[(p - l) % 13 in (0, 1, 3, 9) for l in range(13)] for p in range(13)]

def evaluate(bits):
    wires = [bool(bits >> i & 1) for i in range(26)]
    for a, b, op in gates:
        wires.append(wires[a] or wires[b] if op else wires[a] and wires[b])
    return wires

maxzeros = set()
for ps in range(1 << 13):
    ls = sum(1 << l for l in range(13) if not any(ps >> p & 1 and inc[p][l] for p in range(13)))
    pt = sum(1 << p for p in range(13) if not any(ls >> l & 1 and inc[p][l] for l in range(13)))
    maxzeros.add(pt | (ls << 13))
minones = {(1 << p) | (1 << (13 + l)) for p in range(13) for l in range(13) if inc[p][l]}
badones = [x for x in minones if not evaluate(x)[-1]]
badzeros = [x for x in maxzeros if evaluate(x)[-1]]
bp, bl = evaluate(1), evaluate(1 << 13)
v = [i == 13 for i in range(26)]
w = [i == 0 for i in range(26)]
for a, b, op in gates:
    v.append(v[a] or v[b] if op else (bp[a] and v[b]) or (v[a] and bp[b]))
    w.append(w[a] or w[b] if op else (bl[a] and w[b]) or (w[a] and bl[b]))
used = {25 + len(gates)}
active = 0
for j in range(len(gates) - 1, -1, -1):
    if 26 + j in used:
        active += 1
        used.update(gates[j][:2])
print(json.dumps(dict(file=str(path), slots=len(gates), active=active,
                     minones=len(minones), maxzeros=len(maxzeros),
                     wrong_minones=badones, wrong_maxzeros=badzeros,
                     v_output=v[-1], w_output=w[-1]), sort_keys=True))
