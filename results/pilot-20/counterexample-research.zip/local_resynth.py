import argparse
import json
import random
import subprocess
import sys
from pathlib import Path

ap=argparse.ArgumentParser()
ap.add_argument('--attempts',type=int,default=48)
ap.add_argument('--seconds',type=int,default=20)
ap.add_argument('--seed',type=int,default=1)
ap.add_argument('--width',type=int,default=9)
ap.add_argument('--input')
args=ap.parse_args()
base=Path('/tmp/oec/pequalnp-pilot-20/search')
work=base/f'local-seed{args.seed}'
work.mkdir(exist_ok=True)
solver='/tmp/oec/pequalnp-pilot-20/toolchain/lean-4.36.0-linux/bin/cadical'
seeddata=json.loads(Path(args.input).read_text()) if args.input else json.loads((base/'shannon65-regression.json').read_text())
original=seeddata['gates']
rng=random.Random(args.seed)
targets=seeddata.get('double_edges') or [(p,l) for p in range(13) for l in range(13)
         if (p-l)%13 in (0,1,3,9) and (2-l)%13 not in (0,1,3,9)]

def delete_gate(which,side):
    ren={i:i for i in range(26)}
    out=[]; oldnew={}
    for j,(a,b,o) in enumerate(original):
        a,b=ren[a],ren[b]
        if j==which or a==b:
            ren[26+j]=(a,b)[side] if j==which else a
        else:
            oldnew[j]=len(out)
            out.append([a,b,o]);ren[26+j]=25+len(out)
    assert ren[90]==25+len(out)
    while len(out)<64:
        out.insert(len(out)-1,[0,1,1])
    assert len(out)==64
    return out,oldnew

def neighborhood(g,oldnew,deleted,width):
    adj=[set() for _ in g]
    for j,(a,b,o) in enumerate(g):
        for w in (a,b):
            if w>=26:
                k=w-26;adj[j].add(k);adj[k].add(j)
    near=[]
    for j,(a,b,o) in enumerate(original):
        if j in oldnew and (a==26+deleted or b==26+deleted):near.append(oldnew[j])
    for w in original[deleted][:2]:
        if w>=26 and w-26 in oldnew:near.append(oldnew[w-26])
    near.append(min(deleted,63))
    near=list(dict.fromkeys(near))
    chosen=set(near[:width])
    while len(chosen)<width:
        cand=set().union(*(adj[j] for j in chosen))-chosen
        if not cand:cand=set(range(64))-chosen
        chosen.add(rng.choice(sorted(cand)))
    if rng.randrange(3)==0:
        chosen.remove(rng.choice(sorted(chosen)))
        chosen.add(rng.choice([j for j in range(64) if j not in chosen]))
    return sorted(chosen)

def run_logged(command,name):
    with (work/(name+'.stdout')).open('w') as out,(work/(name+'.stderr')).open('w') as err:
        return subprocess.run(command,stdout=out,stderr=err,cwd='/workspace/pequalnp-proofs').returncode

for attempt in range(args.attempts):
    deleted=rng.randrange(64)
    side=rng.randrange(2)
    g,mapping=delete_gate(deleted,side)
    free=neighborhood(g,mapping,deleted,args.width)
    p,l=targets[rng.randrange(len(targets))]
    name=f'run{args.seed}-{attempt:03d}'
    seed=work/(name+'-seed.json');seed.write_text(json.dumps(dict(gates=g)))
    frees=work/(name+'-free.json');frees.write_text(json.dumps(free))
    config=dict(deleted=deleted,side=side,free=free,point=p,line=l)
    (work/(name+'-config.json')).write_text(json.dumps(config))
    extra=[]
    for roundid in range(4):
        prefix=work/'current'
        exfile=work/(name+'-extra.json');exfile.write_text(json.dumps(extra))
        gen=[sys.executable,str(base/'synthesis.py'),str(prefix),'--slots','64',
             '--fix',str(seed),'--phase',str(seed),'--free-list',str(frees),
             '--point',str(p),'--line',str(l),'--extra',str(exfile)]
        label=f'{name}-r{roundid}'
        rc=run_logged(gen,label+'-generation')
        if rc:raise RuntimeError(('generator',rc,label))
        sol=work/(label+'.sol')
        rc=run_logged([solver,'-t',str(args.seconds),'-q','-w',str(sol),str(prefix.with_suffix('.cnf'))],label)
        print(json.dumps(dict(attempt=attempt,round=roundid,returncode=rc,**config)),flush=True)
        if rc not in (0,10,20):raise RuntimeError(('solver',rc,label))
        if rc!=10:break
        # Decode while the matching metadata still describes this model.
        prefix.with_suffix('.sol').write_text(sol.read_text())
        rc=run_logged([sys.executable,str(base/'decode.py'),str(prefix)],label+'-decode')
        if rc:raise RuntimeError(('decode',rc,label))
        model=work/(label+'-model.json')
        rc=run_logged([sys.executable,str(base/'validate_all.py'),str(prefix.with_suffix('.json')),str(model)],label+'-validation')
        if rc:raise RuntimeError(('validate',rc,label))
        checked=json.loads(model.read_text())
        if not checked['wrong_minones'] and not checked['wrong_maxzeros'] and checked['double_edges']:
            print('WITNESS '+str(model),flush=True)
            raise SystemExit(0)
        assert not checked['wrong_minones']
        extra=sorted(set(extra+checked['wrong_maxzeros']))
        print(json.dumps(dict(refinement=label,extra_zeros=len(extra),double_count=len(checked['double_edges']))),flush=True)
print('BATCH DONE',flush=True)
