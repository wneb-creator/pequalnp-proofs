import argparse
import json
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('source')
parser.add_argument('prefix')
parser.add_argument('--target-p',type=int,default=0)
parser.add_argument('--target-l',type=int,default=0)
parser.add_argument('--shared-or',type=int,nargs=2)
args=parser.parse_args()
source=json.loads(Path(args.source).read_text())
n=26
forms=[{i} for i in range(n)]
ands=[]
for a,b,op in source['gates']:
    if op:
        forms.append(forms[a]|forms[b])
    else:
        ands.append([sorted(forms[a]),sorted(forms[b])])
        forms.append({n+len(ands)-1})
output=source.get('output',n+len(source['gates'])-1)
assert all(s>=n for s in forms[output])
chosen=sorted(s-n for s in forms[output])
shared_symbol=n+len(ands)
if args.shared_or:
    pair=set(args.shared_or)
    assert len(pair)==2
    ands=[[sorted((set(side)-pair)|{shared_symbol}) if pair<=set(side) else side
           for side in gate] for gate in ands]
prefix=Path(args.prefix)
shared_meta=dict(symbol=shared_symbol,inputs=args.shared_or) if args.shared_or else None
prefix.with_suffix('.fixed.json').write_text(json.dumps(dict(gates=ands,outputs=chosen,shared_or=shared_meta)))
selectors=[]
truth=[]
next_id=2
available=list(range(n))
wire_labels=[]
for i,gate in enumerate(ands):
    if args.shared_or and shared_symbol not in available and all(s in available for s in args.shared_or):
        available.append(shared_symbol)
    wire_labels.append(available.copy())
    selected=[]
    for side in gate:
        assert set(side)<=set(available)
        ids=list(range(next_id,next_id+len(available)))
        next_id+=len(available)
        truth.extend(s for j,s in zip(available,ids) if j in side)
        selected.append(ids)
    selectors.append(selected)
    available.append(n+i)
outputs=list(range(next_id,next_id+len(ands)))
truth.extend(outputs[i] for i in chosen)
prefix.with_suffix('.meta.json').write_text(json.dumps(dict(
    n=n,k=len(ands),gates=selectors,outputs=outputs,double_reread=True,
    target_p=args.target_p,target_l=args.target_l,wire_labels=wire_labels,shared_or=shared_meta)))
prefix.with_suffix('.sol').write_text('s SATISFIABLE\nv '+' '.join(map(str,truth))+' 0\n')
print(json.dumps(dict(and_count=len(ands),selected_count=sum(len(s) for g in ands for s in g)+len(chosen),explicit_or_count=int(bool(args.shared_or)))))
