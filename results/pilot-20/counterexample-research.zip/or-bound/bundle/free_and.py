import argparse
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('prefix')
parser.add_argument('--cycle', type=int, default=12)
parser.add_argument('--ands', type=int, default=5)
parser.add_argument('--plane', action='store_true')
parser.add_argument('--disjoint', action='store_true')
parser.add_argument('--double-reread', action='store_true')
parser.add_argument('--ordered', action='store_true')
parser.add_argument('--max-selected', type=int)
parser.add_argument('--fix-prefix', type=int, default=0)
parser.add_argument('--fixed-model')
parser.add_argument('--phase-model')
parser.add_argument('--full-phase', action='store_true')
parser.add_argument('--dual', action='store_true')
parser.add_argument('--target-p', type=int, default=0)
parser.add_argument('--target-l', type=int, default=0)
parser.add_argument('--shared-or', type=int, nargs=2)
parser.add_argument('--require-unsafe-and', action='store_true')
args = parser.parse_args()
n = 26 if args.plane else args.cycle
k = args.ands
edges = ([(p, 13+l) for p in range(13) for l in range(13)
          if (p-l) % 13 in (0, 1, 3, 9)] if args.plane else
         [(i, (i + 1) % n) for i in range(n)])
positive = [(1 << a) | (1 << b) for a, b in edges]
if args.plane:
    negatives = set()
    for ps in range(1 << 13):
        ls = sum(1 << l for l in range(13)
                 if not any(ps >> p & 1 and (p, 13+l) in edges for p in range(13)))
        qs = sum(1 << p for p in range(13)
                 if not any(ls >> l & 1 and (p, 13+l) in edges for l in range(13)))
        negatives.add(qs | (ls << 13))
    negative = sorted(negatives)
else:
    independent = [s for s in range(1 << n)
                   if not any(s >> a & 1 and s >> b & 1 for a, b in edges)]
    negative = [s for s in independent if all(
        s >> i & 1 or any((s >> j & 1) and (i, j) in edges + [(b,a) for a,b in edges]
                          for j in range(n)) for i in range(n))]
if args.dual:
    full = (1 << n)-1
    positive, negative = [full ^ s for s in negative], [full ^ s for s in positive]
tests = positive + negative
nv = 1
clauses = [[1]]

def new(prefer=None):
    global nv
    nv += 1
    return -nv if prefer else nv

def clause(*ls):
    if 1 in ls:
        return
    ls = list(dict.fromkeys(x for x in ls if x != -1))
    present=set(ls)
    if any(-x in present for x in ls):
        return
    clauses.append(ls)

def expected(literal):
    return literal == 1 or literal < -1

def conjunction(a, b):
    if a == -1 or b == -1:
        return -1
    if a == 1:
        return b
    if b == 1 or a == b:
        return a
    v = new(expected(a) and expected(b) if args.full_phase else None)
    clause(-v, a)
    clause(-v, b)
    clause(v, -a, -b)
    return v

def disjunction(xs):
    xs = list(dict.fromkeys(x for x in xs if x != -1))
    if 1 in xs:
        return 1
    if not xs:
        return -1
    if len(xs) == 1:
        return xs[0]
    v = new(any(expected(x) for x in xs) if args.full_phase else None)
    for x in xs:
        clause(-x, v)
    clause(-v, *xs)
    return v

def exclusive_or(a, b):
    if a == b:
        return -1
    if a == -b:
        return 1
    if a == -1:
        return b
    if b == -1:
        return a
    if a == 1:
        return -b
    if b == 1:
        return -a
    v = new(expected(a) != expected(b) if args.full_phase else None)
    clause(a, b, -v)
    clause(-a, -b, -v)
    clause(a, -b, v)
    clause(-a, b, v)
    return v

def at_most(literals, limit):
    bits = [-1] * len(literals).bit_length()
    for literal in literals:
        carry = literal
        for i, old in enumerate(bits):
            bits[i] = exclusive_or(old, carry)
            carry = conjunction(old, carry)
    for j, bit in enumerate(bits):
        if not (limit >> j & 1):
            clause(-bit, *[-bits[i] if limit >> i & 1 else bits[i]
                           for i in range(j+1, len(bits))])

def selected_or(sels, vals):
    return disjunction([conjunction(s, v) for s, v in zip(sels, vals)])

vals = [[1 if s >> i & 1 else -1 for i in range(n)] for s in tests]
sing_p = [1 if i == args.target_p else -1 for i in range(n)]
sing_l = [1 if i == 13+args.target_l else -1 for i in range(n)]
dp = sing_p.copy()
dl = sing_l.copy()
gates = []
gate_wire_labels = []
wire_labels = list(range(n))
shared_symbol = n+k
shared_added = False

def install_shared():
    global shared_added
    if args.shared_or and not shared_added and all(s in wire_labels for s in args.shared_or):
        a,b = [wire_labels.index(s) for s in args.shared_or]
        for vs in vals:
            vs.append(disjunction([vs[a],vs[b]]))
        if args.double_reread:
            for vs in (sing_p,sing_l,dp,dl):
                vs.append(disjunction([vs[a],vs[b]]))
        wire_labels.append(shared_symbol)
        shared_added = True

fixed = None
if args.fixed_model:
    fixed = json.loads(Path(args.fixed_model).read_text())['gates']
phase = json.loads(Path(args.phase_model).read_text()) if args.phase_model else None
install_shared()
for i in range(k):
    gate_wire_labels.append(wire_labels.copy())
    a = [new(phase is not None and j in phase['gates'][i][0]) for j in wire_labels]
    b = [new(phase is not None and j in phase['gates'][i][1]) for j in wire_labels]
    gates.append([a, b])
    if i < args.fix_prefix:
        assert fixed is not None
        for side, old in zip((a,b), fixed[i]):
            for j, selector in zip(wire_labels,side):
                clause(selector if j in old else -selector)
    if args.disjoint:
        for x, y in zip(a, b):
            clause(-x, -y)
    if args.ordered:
        # Put the side with the smaller first selected wire on the left.
        # If the first wires coincide, this restricted ordering is not applied;
        # retaining that possibility is essential without disjoint normalization.
        for j, y in enumerate(b):
            clause(-y, *a[:j+1])
    for vs in vals:
        vs.append(conjunction(selected_or(a, vs), selected_or(b, vs)))
    if args.double_reread:
        assert args.plane
        ap = selected_or(a, sing_p)
        bp = selected_or(b, sing_p)
        al = selected_or(a, sing_l)
        bl = selected_or(b, sing_l)
        da = selected_or(a, dp)
        db = selected_or(b, dp)
        ea = selected_or(a, dl)
        eb = selected_or(b, dl)
        dp.append(disjunction([conjunction(al, db), conjunction(da, bl)]))
        dl.append(disjunction([conjunction(ap, eb), conjunction(ea, bp)]))
        sing_p.append(conjunction(ap, bp))
        sing_l.append(conjunction(al, bl))
    wire_labels.append(n+i)
    install_shared()
assert not args.shared_or or shared_added
output_indices = [wire_labels.index(n+i) for i in range(k)]
outs = [new(phase is not None and j in phase['outputs']) for j in range(k)]
for i, vs in enumerate(vals):
    v = selected_or(outs, [vs[j] for j in output_indices])
    clause(v if i < len(positive) else -v)
if args.double_reread:
    clause(-selected_or(outs, [dp[j] for j in output_indices]))
    clause(-selected_or(outs, [dl[j] for j in output_indices]))
if args.require_unsafe_and:
    clause(*[vs[j] for vs in vals[len(positive):] for j in output_indices])
if args.max_selected is not None:
    at_most([s for g in gates for side in g for s in side] + outs,
            args.max_selected)
prefix = Path(args.prefix)
with prefix.with_suffix('.cnf').open('w') as f:
    f.write(f'p cnf {nv} {len(clauses)}\n')
    for cl in clauses:
        f.write(' '.join(map(str, cl)) + ' 0\n')
prefix.with_suffix('.meta.json').write_text(json.dumps(dict(
    n=n, k=k, edges=edges, positives=positive, negatives=negative,
    gates=gates, outputs=outs, double_reread=args.double_reread,
    dual=args.dual,
    target_p=args.target_p,target_l=args.target_l,
    wire_labels=gate_wire_labels,
    shared_or=dict(symbol=shared_symbol,inputs=args.shared_or) if args.shared_or else None,
    require_unsafe_and=args.require_unsafe_and,
    variables=nv, clauses=len(clauses))))
print(json.dumps(dict(n=n, k=k, positives=len(positive), negatives=len(negative),
                      variables=nv, clauses=len(clauses))))
