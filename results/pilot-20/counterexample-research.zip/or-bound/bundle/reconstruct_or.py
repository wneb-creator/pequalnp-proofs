import argparse
import collections
import itertools
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('prefix')
args = parser.parse_args()
prefix = Path(args.prefix)
meta = json.loads(prefix.with_suffix('.meta.json').read_text())
solution = prefix.with_suffix('.sol').read_text()
assert 's SATISFIABLE' in solution
true = {int(s) for line in solution.splitlines() if line.startswith('v ')
        for s in line[2:].split() if int(s) > 0}
n, k = meta['n'], meta['k']
target_p, target_l = meta.get('target_p',0), meta.get('target_l',0)
labels=meta.get('wire_labels',[list(range(n+i)) for i in range(k)])
targets = [{labels[i][j] for j,s in enumerate(side) if (abs(s) in true) == (s > 0)}
           for i,gate in enumerate(meta['gates']) for side in gate]
targets.append({n+i for i,s in enumerate(meta['outputs']) if (abs(s) in true) == (s > 0)})
explicit_shared=meta.get('shared_or')
or_definitions = ({explicit_shared['symbol']:tuple(explicit_shared['inputs'])}
                  if explicit_shared else {})
unshared_or_count = sum(max(0,len(s)-1) for s in targets)+len(or_definitions)
next_symbol = n+k+len(or_definitions)
while True:
    frequencies = collections.Counter(pair for target in targets
                                     for pair in itertools.combinations(sorted(target), 2))
    if not frequencies:
        break
    pair, count = max(frequencies.items(), key=lambda item: (item[1], tuple(-s for s in item[0])))
    if count < 2:
        break
    symbol = next_symbol
    next_symbol += 1
    or_definitions[symbol] = pair
    for target in targets:
        if set(pair) <= target:
            target.difference_update(pair)
            target.add(symbol)

gates = []
symbol_cache = {i: i for i in range(n)}
sum_cache = {}
binary_cache = {}
active = set()
duplicate_repairs = 0

def binary(a, b, op):
    global duplicate_repairs
    if a is None or b is None:
        if op:
            return b if a is None else a
        return None
    if a == b and op:
        return a
    if a == b:
        duplicate_repairs += 1
        if a >= n:
            # Recompute the argument on a distinct wire, retaining its formula.
            copy = n + len(gates)
            gates.append(gates[a-n].copy())
            b = copy
        else:
            # a*(a+z) has the same truth value and the same two tested first
            # coefficients as a*a when z is neither target input.
            z = next(i for i in range(n) if i not in (a, target_p, 13+target_l))
            b = binary(a, z, 1)
    key = (min(a, b), max(a, b), op)
    if not op:
        result = n + len(gates)
        gates.append(list(key))
        return result
    if key not in binary_cache:
        binary_cache[key] = n + len(gates)
        gates.append(list(key))
    return binary_cache[key]

def emit_sum(symbols):
    key = frozenset(symbols)
    if key not in sum_cache:
        values = [emit_symbol(s) for s in sorted(symbols)]
        values = list(dict.fromkeys(v for v in values if v is not None))
        if not values:
            result = None
        else:
            result = values[0]
            for v in values[1:]:
                result = binary(result, v, 1)
        sum_cache[key] = result
    return sum_cache[key]

def emit_symbol(symbol):
    if symbol in symbol_cache:
        return symbol_cache[symbol]
    assert symbol not in active, ('cyclic dependency', symbol)
    active.add(symbol)
    if symbol < n + k:
        i = symbol - n
        result = binary(emit_sum(targets[2*i]), emit_sum(targets[2*i+1]), 0)
    else:
        a, b = or_definitions[symbol]
        result = binary(emit_symbol(a), emit_symbol(b), 1)
    active.remove(symbol)
    symbol_cache[symbol] = result
    return result

output = emit_sum(targets[-1])
assert output is not None
used={output}
for i in range(len(gates)-1,-1,-1):
    if n+i in used:
        used.update(gates[i][:2])
renaming={i:i for i in range(n)}
compact=[]
for i,(a,b,op) in enumerate(gates):
    if n+i in used:
        renaming[n+i]=n+len(compact)
        compact.append([renaming[a],renaming[b],op])
output=renaming[output]
gates=compact
assert all(a < b < n+i for i, (a,b,op) in enumerate(gates))
assert output==n+len(gates)-1

def eval_circuit(mask):
    values = [bool(mask >> i & 1) for i in range(n)]
    for a, b, op in gates:
        values.append((values[a] or values[b]) if op else (values[a] and values[b]))
    return values[output]

def derivative(variable, at):
    values = [bool(at >> i & 1) for i in range(n)]
    first = [i == variable for i in range(n)]
    for a, b, op in gates:
        values.append((values[a] or values[b]) if op else (values[a] and values[b]))
        first.append((first[a] or first[b]) if op else
                     ((first[a] and values[b]) or (values[a] and first[b])))
    return first[output]

if n == 26:
    count = 0
    for p in range(13):
        for l in range(13):
            if (p-l) % 13 in (0, 1, 3, 9):
                assert eval_circuit((1 << p) | (1 << (13+l)))
                count += 1
    for ps in range(8192):
        ls = sum(1 << l for l in range(13)
                 if all(not (ps >> p & 1) or (p-l) % 13 not in (0,1,3,9)
                        for p in range(13)))
        assert not eval_circuit(ps | (ls << 13))
        count += 1
    derivatives = [derivative(target_p, 1 << (13+target_l)),
                   derivative(13+target_l, 1 << target_p)]
    if meta.get('double_reread'):
        assert derivatives == [False, False]
else:
    count = 1 << n
    for s in range(count):
        if meta.get('dual'):
            truth = all(s >> a & 1 or s >> b & 1 for a,b in meta['edges'])
        else:
            truth = any(s >> a & 1 and s >> b & 1 for a,b in meta['edges'])
        assert eval_circuit(s) == truth
    derivatives = None
result = dict(gates=gates, output=output, n=n, tested=count, derivatives=derivatives,
              target_p=target_p,target_l=target_l,
              and_count=sum(not g[2] for g in gates), or_count=sum(g[2] for g in gates),
              unshared_or_count=unshared_or_count, shared_symbols=len(or_definitions),
              duplicate_repairs=duplicate_repairs)
result['explicit_or_count']=int(bool(explicit_shared))
prefix.with_suffix('.reconstructed.json').write_text(json.dumps(result, indent=2))
print(json.dumps({key: value for key, value in result.items() if key != 'gates'}))
