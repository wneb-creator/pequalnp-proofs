import json
import sys
from pathlib import Path

prefix = Path(sys.argv[1])
meta = json.loads(prefix.with_suffix('.meta.json').read_text())
sol = prefix.with_suffix('.sol').read_text()
assert 's SATISFIABLE' in sol
true = {int(x) for line in sol.splitlines() if line.startswith('v ')
        for x in line[2:].split() if int(x) > 0}
labels=meta.get('wire_labels',[list(range(meta['n']+i)) for i in range(meta['k'])])
gates = [[[labels[i][j] for j,s in enumerate(side) if (abs(s) in true) == (s > 0)]
          for side in g] for i,g in enumerate(meta['gates'])]
outputs = [i for i,s in enumerate(meta['outputs']) if (abs(s) in true) == (s > 0)]
n = meta['n']
def evaluate(s):
    vals = {i:bool(s >> i & 1) for i in range(n)}
    shared=meta.get('shared_or')
    def install_shared():
        if shared and all(i in vals for i in shared['inputs']):
            vals[shared['symbol']]=any(vals[i] for i in shared['inputs'])
    install_shared()
    for j,(a,b) in enumerate(gates):
        vals[n+j]=any(vals[i] for i in a) and any(vals[i] for i in b)
        install_shared()
    return any(vals[n + i] for i in outputs)
if n <= 20:
    tested = 1 << n
    for s in range(tested):
        if meta.get('dual'):
            correct = all(s >> a & 1 or s >> b & 1 for a,b in meta['edges'])
        else:
            correct = any(s >> a & 1 and s >> b & 1 for a,b in meta['edges'])
        assert evaluate(s) == correct, (s, evaluate(s), correct)
else:
    for s in meta['positives']:
        assert evaluate(s)
    for s in meta['negatives']:
        assert not evaluate(s)
    tested = len(meta['positives']) + len(meta['negatives'])
result = dict(n=n,gates=gates,outputs=outputs,tested=tested,shared_or=meta.get('shared_or'))
prefix.with_suffix('.checked.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result))
