# Free-OR search notes for L-meta-1482

This directory contains exploratory finite searches, not a proof of the posted
64-gate impossibility statement. No unrestricted bipartite normalization theorem
was established by the literature investigation.

## Search model and scope

`free_and.py` represents each AND input as an arbitrary OR of input variables and
earlier AND outputs, with a final OR of chosen AND outputs. This collapses OR
chains while retaining their supports. Exact graph-function semantics are
enforced on every minimal true edge assignment and every maximal independent
assignment. For the order-three plane there are 52 and 704 respectively.

The optional `--disjoint` constraint is justified for function/AND-count searches
by replacing `(A OR h) AND (B OR h)` with `(A AND B) OR h`, propagating the extra
OR term to later uses. **It does not preserve formal reread properties.** It is
disabled in every double-reread search.

The optional `--double-reread` constraint uses the exact formal first-linear-part
recurrences at target point 0 and line 0. Both output coefficients must be false.

The optional selector bound counts selected wires in all AND input sums plus
the final output sum. With 13 productive AND gates, nonempty input sums, and a
nonempty output sum, selector count 78 corresponds to at most 51 OR gates when
each sum is computed separately. **This is a restricted heuristic, not an
exhaustive encoding of all 64-gate circuits:** sharing OR subexpressions can
reduce the physical gate count below this naive count. In addition, the
free-OR representation is initially a relaxation of the physical distinct-input
condition, so a SAT model must pass reconstruction and recounting.

`reconstruct_or.py` greedily factors common pairs across the OR input/output
sets, schedules physical gates by dependency order, retains separate AND
computations, checks that each physical gate has two distinct earlier inputs,
and validates the reconstructed circuit independently. Duplicate-input ANDs
are repaired explicitly and their additional physical gates are counted.
For the plane it checks all 52 positive edges and all 8192 point-derived false
closures, as well as the target formal coefficients. `validate_all.py` in the
parent search directory additionally checks all 52 derivative pairs.

The optional `--shared-or 13 26` explicitly retains one OR intermediate
`H = input13 OR AND0`. Its abstract symbol is distinct from all AND symbols and
it becomes available only after AND0. The physical OR is counted separately
from the remaining selector sums. Wire-label metadata records this dependency,
and reconstruction schedules it before its first use. This remains a restricted
search family.

## Calibrations

- C6 with 2 free-OR AND gates: UNSAT.
- C6 with 3 AND gates: SAT, decoded and checked on all 64 valuations.
- C12 with 5 AND gates, unrestricted sides: no verdict at 60 seconds.
- C12 with 5 AND gates and disjoint input supports: UNSAT in 36.16 seconds,
  625307 conflicts. This is a solver result, not a Lean certificate.
- C6 with 3 ANDs and selector bound 11: UNSAT.
- C6 with 3 ANDs and selector bound 12: SAT; reconstruction has 3 ANDs and 5 ORs,
  and matches all 64 valuations.
- The Boolean dual of C6 with 4 free-OR AND gates and disjoint input supports:
  native UNSAT in 0.009 seconds, as run independently by the parent search
  agent. Via De Morgan duality this probes whether exact C6 could have fewer
  than 5 OR gates. This is a computational calibration, not a Lean theorem.
- The Boolean dual of C12 with 10 AND gates and disjoint supports: no verdict
  at 60 seconds, as run by the parent search agent. No general OR lower bound
  follows from these probes.
- Fixed local Shannon model with 13 ANDs, double-reread constraints, signed
  selector phases, and bound 79: SAT; reconstruction has exactly 65 gates and
  passes all 8244 critical-input checks and both target coefficients.
- The optional `--full-phase` setting also phases semantic and cardinality
  auxiliaries from the supplied model. A direct evaluation of its initial
  assignment on the selector-78 instance violates exactly one of its 759880
  clauses (the cardinality bound). This option was prepared without restarting
  the original selector-only-phased run.

## Verified 65-gate candidates

`shannon65-local-allflags.json` is a compact, independently checked physical
circuit. It has 13 ANDs and 52 ORs, with all 65 gates active and all input pairs
distinct. It has no false minimal positives or true maximal negatives. The
double-reread edges are exactly `(0,0)`, `(0,4)`, and `(0,10)`.

Construction: let A be the point-0 star, r be point 2, and N its four-line sum.
Replace `A OR (r AND N)` by `(A OR r) AND (A OR N)`, retaining the other eleven
point stars outside the replacement in the final OR. The local free-OR model
uses selector count 79 and requires 52 ORs even before sharing. The global
Shannon construction normalizes to 63 unshared ORs; reconstruction recovers its
original 52 ORs by 11 common-pair factors.

A second topology from the algebraic agent is preserved as
`core6-global65-shared.reconstructed.json`: 14 ANDs and 51 ORs, targeting `(0,4)`.
Its naive free-OR selector count is **81**, not 80: one repeated pair
`(input13, AND0)` saves an OR. Retaining that pair as the explicit H intermediate
reduces the remaining selector count to 79, plus one physical OR for H. The
fixed65 shared-H encoding is SAT and reconstructs65 gates with both target
coefficients false and all8244 critical evaluations correct.

## Plane runs

- `plane-a12`: 12 AND gates, disjoint supports, all critical inputs, no derivative
  constraint. No verdict at 300 seconds; 285682 conflicts; peak RSS 195.32 MB.
- `plane-a13-reread`: 13 AND gates, double reread, ordered side minima, no
  disjoint constraint. No verdict at 300 seconds; 177829 conflicts; peak RSS
  219.06 MB.
- `plane-a13-reread-s78`: restricted heuristic described above. Generated with
  `--plane --ands 13 --double-reread --ordered --max-selected 78 --phase-model
  shannon65-local.fixed.json`. Solver options are `-t 1800 --phase=false
  --seed=13`. Started approximately 2026-11-24 01:16 UTC. Final status is
  **UNKNOWN / interrupted by the execution-environment transition**. Its process
  session was confirmed missing at01:41:54 UTC, with no solution-status file or
  completion statistics. The unchanged captured partial log is included.
- `plane-a14-shared-s78`: 14 ANDs, target `(0,4)`, explicit shared H, no disjoint
  normalization, full auxiliary phasing, remaining selector bound78. Its seed
  has79, so this searches one naive gate below that65-gate seed while counting
  H's one physical OR. Generated with `--plane --ands 14 --double-reread
  --ordered --target-p 0 --target-l 4 --shared-or 13 26 --max-selected 78
  --phase-model core6-global65-shared.fixed.json --full-phase`. Solver options
  are `-t 1800 --phase=false --seed=14`. Started approximately
  2026-11-24 01:30 UTC. Final status is **UNKNOWN / interrupted by the execution-
  environment transition**, confirmed at01:41:54 UTC by a missing process session
  and no solution-status file or completion statistics. Its unchanged captured
  partial log is included.
  Its initial assignment violates exactly one of926988 clauses. UNSAT would
  concern this restricted family only, not all64-gate circuits.

The source also includes `--require-unsafe-and`: one clause requires an AND
gate to be true on at least one maximal independent input. Monotonicity makes
this equivalent to the existence of an AND-safety violation. This option was
prepared but not used in either interrupted long run. No long run was restarted
after the environment transition.

Preserve the Python sources, this note, complete solver/validation logs, compact
JSON candidates and statuses. The generated DIMACS CNFs are reproducible and
should not be added to the repository.
