import argparse,json,subprocess,sys
from pathlib import Path

ap=argparse.ArgumentParser()
ap.add_argument('--rounds',type=int,default=6)
ap.add_argument('--seconds',type=int,default=120)
ap.add_argument('--seed',type=int,default=751)
ap.add_argument('--input',default='/tmp/oec/pequalnp-pilot-20/search/core6-global65-validated.json')
args=ap.parse_args()
base=Path('/tmp/oec/pequalnp-pilot-20/search')
work=base/f'pair-cegar-{args.seed}'
work.mkdir(exist_ok=True)
seed=json.loads(Path(args.input).read_text())
extra=set();records=[]
for iteration in range(args.rounds):
    prefix=work/f'round{iteration:02d}'
    gatefile=prefix.with_suffix('.gates')
    gatefile.write_text(''.join(' '.join(map(str,g))+'\n' for g in seed['gates']))
    extrafile=prefix.with_suffix('.extra')
    extrafile.write_text(''.join(str(x)+'\n' for x in sorted(extra)))
    command=[str(base/'search-pairs'),str(args.seconds),str(args.seed+iteration),str(prefix),'96',str(gatefile),str(extrafile)]
    with prefix.with_suffix('.stdout').open('w') as out,prefix.with_suffix('.stderr').open('w') as err:
        result=subprocess.run(command,stdout=out,stderr=err)
    assert result.returncode==0,result.returncode
    witness=Path(str(prefix)+'-WITNESS.json')
    chosen=witness if witness.exists() else prefix.with_suffix('.json')
    full=prefix.with_suffix('.validated.json')
    validated=subprocess.run([sys.executable,str(base/'validate_all.py'),str(chosen),str(full)],capture_output=True,text=True)
    prefix.with_suffix('.validate.stdout').write_text(validated.stdout)
    prefix.with_suffix('.validate.stderr').write_text(validated.stderr)
    assert validated.returncode==0,validated.stderr
    data=json.loads(full.read_text())
    record=dict(iteration=iteration,pair_candidate=witness.exists(),active=data['active'],wrong_minones=len(data['wrong_minones']),wrong_maxzeros=len(data['wrong_maxzeros']),double_edges=data['double_edges'],extra_before=len(extra))
    records.append(record)
    (work/'summary.json').write_text(json.dumps(records,indent=2))
    print(json.dumps(record),flush=True)
    if data['active']<=64 and not data['wrong_minones'] and not data['wrong_maxzeros'] and data['double_edges']:
        print('FULL WITNESS '+str(full),flush=True)
        break
    if witness.exists():
        assert not data['wrong_minones'] and data['double_edges']
        extra.update(data['wrong_maxzeros'])
        seed=data
    else:
        # Keep a correct65 seed rather than adopting an arbitrary incomplete result.
        if not data['wrong_minones'] and not data['wrong_maxzeros'] and data['double_edges']:
            seed=data
