import argparse
import json
import random
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument('prefix')
ap.add_argument('--zeros', type=int, default=24)
ap.add_argument('--slots', type=int, default=64)
ap.add_argument('--seed', type=int, default=1)
ap.add_argument('--extra')
ap.add_argument('--fix')
ap.add_argument('--free-from', type=int, default=0)
ap.add_argument('--canonical', action='store_true')
ap.add_argument('--phase')
ap.add_argument('--ands', type=int)
ap.add_argument('--c6', action='store_true')
ap.add_argument('--fixture')
ap.add_argument('--any-derivatives', action='store_true')
ap.add_argument('--no-derivatives', action='store_true')
ap.add_argument('--free-list')
ap.add_argument('--point', type=int, default=0)
ap.add_argument('--line', type=int, default=0)
args = ap.parse_args()
prefix = Path(args.prefix)
rng = random.Random(args.seed)
N = args.slots
if args.fixture:
    fixture = json.loads(Path(args.fixture).read_text())
    nv = len(fixture['original_points'])
    nl = len(fixture['line_groups'])
    nin = fixture['input_count']
    edges = fixture['edges_local']
    pos = fixture['minones']
    zero = set(fixture['maxzeros'])
else:
    nv = 3 if args.c6 else 13
    nl = nv
    nin = 2*nv
    diffs = (1, 2) if args.c6 else (0, 1, 3, 9)
    edges = [[p,l] for p in range(nv) for l in range(nl) if (p-l) % nv in diffs]
    pos = [(1 << p) | (1 << (nv+l)) for p,l in edges]
    zero = set()
    for ps in range(1 << nv):
        ls = sum(1 << l for l in range(nl) if not any(ps >> p & 1 and [p,l] in edges for p in range(nv)))
        pt = sum(1 << p for p in range(nv) if not any(ls >> l & 1 and [p,l] in edges for l in range(nl)))
        zero.add(pt | (ls << nv))
zs = sorted(zero)
rng.shuffle(zs)
tests = pos + [1 << j for j in range(nin)] + zs[:args.zeros]
tests += [(1 << nv)-1, ((1 << nl)-1) << nv]
if args.extra:
    tests += json.loads(Path(args.extra).read_text())
tests = list(dict.fromkeys(tests))
f = prefix.with_suffix('.cnf.tmp').open('w')
vnum = 1
cnum = 0
def new(prefer=None):
    global vnum
    vnum += 1
    return -vnum if prefer is False else vnum
def clause(*ls):
    global cnum
    if 1 in ls:
        return
    ls = tuple(dict.fromkeys(l for l in ls if l != -1))
    ss = set(ls)
    if any(-l in ss for l in ls):
        return
    f.write(' '.join(map(str, ls)) + ' 0\n')
    cnum += 1
def disj(a, b):
    if a == 1 or b == 1: return 1
    if a == -1: return b
    if b == -1 or a == b: return a
    z = new((a > 0 or b > 0) if args.phase else None)
    clause(-a, z); clause(-b, z); clause(a, b, -z)
    return z
def conj(a, b):
    return -disj(-a, -b)
def onehot(sel):
    clause(*sel)
    p = -1
    pref = []
    for s in sel:
        clause(-p, -s)
        p = disj(p, s)
        pref.append(p)
    return pref
def sem(op, a, b):
    if op == 1: return disj(a, b)
    if op == -1: return conj(a, b)
    z = new(((a > 0 or b > 0) if op > 0 else (a > 0 and b > 0)) if args.phase else None)
    clause(-op, -a, z); clause(-op, -b, z); clause(-op, a, b, -z)
    clause(op, a, -z); clause(op, b, -z); clause(op, -a, -b, z)
    return z
def select(sel, wires):
    if all(s in (-1, 1) for s in sel):
        return next(w for s, w in zip(sel, wires) if s == 1)
    preferred = next((w > 0 for s, w in zip(sel, wires) if s > 0), False)
    z = new(preferred if args.phase else None)
    for s, w in zip(sel, wires):
        clause(-s, -z, w); clause(-s, z, -w)
    return z
def choice(op, a, b):
    if op == 1: return a
    if op == -1: return b
    z = new(((a if op > 0 else b) > 0) if args.phase else None)
    clause(-op, -a, z); clause(-op, a, -z)
    clause(op, -b, z); clause(op, b, -z)
    return z

# Variable 1 represents true, including when its negation represents false.
f.write('1 0\n'); cnum += 1
vals = [[1 if x >> j & 1 else -1 for j in range(nin)] for x in tests]
flags = edges if args.any_derivatives else [[args.point,args.line]]
derivatives=[]
for p,l in flags:
    ip,il = tests.index(1 << p), tests.index(1 << (nv+l))
    dp = [1 if j == p else -1 for j in range(nin)]
    dl = [1 if j == nv+l else -1 for j in range(nin)]
    derivatives.append((ip,il,dp,dl))
gmeta = []
fixed = json.loads(Path(args.fix).read_text())['gates'] if args.fix else []
phases = json.loads(Path(args.phase).read_text())['gates'] if args.phase else []
free_set = set(json.loads(Path(args.free_list).read_text())) if args.free_list else None
for j in range(N):
    nw = nin + j
    is_fixed = j < len(fixed) and (j not in free_set if free_set is not None else j < args.free_from)
    if is_fixed:
        fa, fb, fo = fixed[j]
        fa, fb = sorted((fa, fb))
        sa = [1 if k == fa else -1 for k in range(nw-1)]
        sb = [1 if k == fb else -1 for k in range(1, nw)]
    elif j < len(phases):
        pa, pb, po = phases[j]
        pa, pb = sorted((pa, pb))
        sa = [new(k == pa) for k in range(nw-1)]
        sb = [new(k == pb) for k in range(1, nw)]
    else:
        sa = [new() for _ in range(nw-1)]
        sb = [new() for _ in range(nw-1)]
    if is_fixed:
        pref = [1 if k >= fa else -1 for k in range(nw-1)]
        op = 1 if fo else -1
    else:
        pref = onehot(sa)
        onehot(sb)
        for k, s in enumerate(sb, 1):
            clause(-s, pref[k-1])
        op = new(bool(po) if j < len(phases) else None)
    gmeta.append(dict(a=sa, b=sb, op=op, prefa=pref))
    aa, bb = [], []
    for vs in vals:
        a = select(sa, vs[:-1]); b = select(sb, vs[1:])
        aa.append(a); bb.append(b)
        vs.append(sem(op, a, b))
    for ip,il,dp,dl in derivatives:
        dap, dbp = select(sa, dp[:-1]), select(sb, dp[1:])
        dal, dbl = select(sa, dl[:-1]), select(sb, dl[1:])
        dp.append(choice(op, disj(dap, dbp), disj(conj(aa[il], dbp), conj(dap, bb[il]))))
        dl.append(choice(op, disj(dal, dbl), disj(conj(aa[ip], dbl), conj(dal, bb[ip]))))
if args.canonical:
    for left, right in zip(gmeta, gmeta[1:]):
        dep = right['b'][-1]
        for a, b in zip(left['prefa'][:-1], right['prefa'][:-1]):
            clause(a, -b, dep)
if args.ands is not None:
    cnt = [1] + [-1] * (args.ands + 1)
    for g in gmeta:
        cnt = [1] + [disj(cnt[k], conj(cnt[k-1], -g['op'])) for k in range(1, len(cnt))]
    clause(cnt[args.ands])
    clause(-cnt[args.ands+1])
for x, vs in zip(tests, vals):
    clause(vs[-1] if x in pos else -vs[-1])
if not args.no_derivatives:
    if args.any_derivatives:
        clause(*(conj(-dp[-1],-dl[-1]) for ip,il,dp,dl in derivatives))
    else:
        clause(-derivatives[0][2][-1]); clause(-derivatives[0][3][-1])
f.close()
with prefix.with_suffix('.cnf').open('w') as out:
    out.write(f'p cnf {vnum} {cnum}\n')
    with prefix.with_suffix('.cnf.tmp').open() as src:
        while part := src.read(1024 * 1024):
            out.write(part)
prefix.with_suffix('.cnf.tmp').unlink()
prefix.with_suffix('.meta.json').write_text(json.dumps(dict(gates=gmeta, tests=tests, seed=args.seed, inputs=nin, point_count=nv, line_count=nl, edges=edges, fixture=args.fixture, target_flags=flags)))
print(json.dumps(dict(variables=vnum, clauses=cnum, tests=len(tests), slots=N, prefix=str(prefix))))
