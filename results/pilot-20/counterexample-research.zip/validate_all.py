import json
import sys
from pathlib import Path

src = Path(sys.argv[1])
d = json.loads(src.read_text())
g = d['gates']
assert d.get('output',25+len(g)) == 25+len(g), 'validator expects the last gate as output'
assert all(o in (0, 1) and 0 <= a < 26+j and 0 <= b < 26+j and a != b
           for j, (a, b, o) in enumerate(g))
used = {25+len(g)}
for j in range(len(g)-1, -1, -1):
    if 26+j in used:
        used.update(g[j][:2])
ren = {i:i for i in range(26)}
compact = []
for j, (a, b, o) in enumerate(g):
    if 26+j in used:
        compact.append([ren[a], ren[b], o])
        ren[26+j] = 25+len(compact)
g = compact
inc = [[(p-l) % 13 in (0,1,3,9) for l in range(13)] for p in range(13)]
def ev(mask):
    w = [bool(mask >> j & 1) for j in range(26)]
    for a,b,o in g:
        w.append((w[a] or w[b]) if o else (w[a] and w[b]))
    return w
pos = {(1 << p)|(1 << (13+l)) for p in range(13) for l in range(13) if inc[p][l]}
zeros = set()
for ps in range(8192):
    ls = sum(1 << l for l in range(13) if not any(ps >> p & 1 and inc[p][l] for p in range(13)))
    pt = sum(1 << p for p in range(13) if not any(ls >> l & 1 and inc[p][l] for l in range(13)))
    zeros.add(pt | (ls << 13))
wrong_true = [x for x in pos if not ev(x)[-1]]
wrong_false = [x for x in zeros if ev(x)[-1]]
doubles = []
for p in range(13):
    for l in range(13):
        if not inc[p][l]:
            continue
        bp, bl = ev(1 << p), ev(1 << (13+l))
        v = [j == 13+l for j in range(26)]
        w = [j == p for j in range(26)]
        for a,b,o in g:
            v.append((v[a] or v[b]) if o else ((bp[a] and v[b]) or (v[a] and bp[b])))
            w.append((w[a] or w[b]) if o else ((bl[a] and w[b]) or (w[a] and bl[b])))
        if not v[-1] and not w[-1] and ev((1 << p)|(1 << (13+l)))[-1]:
            doubles.append([p,l])
result = dict(active=len(g), wrong_minones=wrong_true, wrong_maxzeros=wrong_false, double_edges=doubles)
if len(sys.argv)>2:
    Path(sys.argv[2]).write_text(json.dumps(dict(gates=g, **result)))
print(json.dumps(result, sort_keys=True))
