import datetime,json,subprocess
from pathlib import Path
base=Path('/tmp/oec/pequalnp-pilot-20/search')
prefix=base/'or-bound/plane-a14-shared-unsafe-s78'
now=datetime.datetime.now(datetime.timezone.utc)
deadline=now.replace(hour=1,minute=59,second=45,microsecond=0)
seconds=min(700,max(1,int((deadline-now).total_seconds())))
solver='/tmp/oec/pequalnp-pilot-20/toolchain/lean-4.36.0-linux/bin/cadical'
command=[solver,'-t',str(seconds),'--phase=false','--seed=24','-w',str(prefix.with_suffix('.sol')),str(prefix.with_suffix('.cnf'))]
status=dict(run=prefix.name,status='RUNNING',started_utc=now.isoformat(),limit_seconds=seconds,model_scope='14 free-OR AND gates, explicit shared OR, selector78, target0,4, at least one unsafeAND; restricted physical-cost heuristic',unsafe_condition='someAND output true on one of704 maximalfalse inputs',solver_arguments=command[1:],generator_source='or-bound/free_and.py',retained_prior_interrupted_logs=True)
statusfile=prefix.with_suffix('.status.json');statusfile.write_text(json.dumps(status,indent=2))
with prefix.with_suffix('.stdout').open('w') as out,prefix.with_suffix('.stderr').open('w') as err:
    result=subprocess.run(command,stdout=out,stderr=err)
status.update(status={0:'UNKNOWN/time_limit',10:'SAT/needs_physical_validation',20:'UNSAT/restricted_model_only'}.get(result.returncode,'ERROR'),returncode=result.returncode,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
statusfile.write_text(json.dumps(status,indent=2))
print(json.dumps(status),flush=True)
