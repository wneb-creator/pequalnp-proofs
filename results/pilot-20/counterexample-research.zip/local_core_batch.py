import argparse
import json
import subprocess
import time
from pathlib import Path

ap=argparse.ArgumentParser()
ap.add_argument('--seconds',type=int,default=120)
ap.add_argument('--only')
ap.add_argument('--resume',action='store_true')
args=ap.parse_args()
base=Path('/tmp/oec/pequalnp-pilot-20/search')
fixtures=Path('/tmp/oec/pequalnp-pilot-20/algebraic/shared-cover/local-types')
work=base/'local-core'
work.mkdir(exist_ok=True)
solver='/tmp/oec/pequalnp-pilot-20/toolchain/lean-4.36.0-linux/bin/cadical'
paths=list(fixtures.glob('*-compressed.json'))
paths.sort(key=lambda p:json.loads(p.read_text())['target_core_cost'])
records=json.loads((work/'summary.json').read_text()) if args.resume and (work/'summary.json').exists() else []
for fp in paths:
    if args.only and args.only not in fp.name:
        continue
    fixture=json.loads(fp.read_text())
    name=fixture['name']
    if args.resume and any(record['name']==name for record in records):continue
    prefix=work/name
    (work/f'{name}.fixture.json').write_text(json.dumps(fixture,indent=2))
    cmd=['python',str(base/'local_synthesis.py'),str(prefix),'--fixture',str(fp),'--slots',str(fixture['target_core_cost']),'--zeros','10000','--any-derivatives','--phase',str(fp)]
    with prefix.with_suffix('.generate.stdout').open('w') as out,prefix.with_suffix('.generate.stderr').open('w') as err:
        subprocess.run(cmd,stdout=out,stderr=err,check=True)
    started=time.monotonic()
    with prefix.with_suffix('.stdout').open('w') as out,prefix.with_suffix('.stderr').open('w') as err:
        result=subprocess.run([solver,'-t',str(args.seconds),'-w',str(prefix.with_suffix('.sol')),str(prefix.with_suffix('.cnf'))],stdout=out,stderr=err)
    record=dict(name=name,gate_bound=fixture['target_core_cost'],input_count=fixture['input_count'],all_flags=fixture['edges_local'],seconds=time.monotonic()-started,returncode=result.returncode,status={0:'UNKNOWN',10:'SAT',20:'UNSAT'}.get(result.returncode,'ERROR'))
    if result.returncode==10:
        subprocess.run(['python',str(base/'decode.py'),str(prefix)],check=True)
        validation=subprocess.run(['python',str(base/'validate_local.py'),str(fp),str(prefix.with_suffix('.json'))],capture_output=True,text=True)
        prefix.with_suffix('.validate.stdout').write_text(validation.stdout)
        prefix.with_suffix('.validate.stderr').write_text(validation.stderr)
        record['validation_returncode']=validation.returncode
        if validation.returncode==0:
            record['validation']=json.loads(validation.stdout)
    records.append(record)
    (work/'summary.json').write_text(json.dumps(records,indent=2))
    print(json.dumps(record),flush=True)
