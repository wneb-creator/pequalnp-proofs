import json
import sys
from pathlib import Path
prefix = Path(sys.argv[1])
meta = json.loads(prefix.with_suffix('.meta.json').read_text())
sol = prefix.with_suffix('.sol').read_text()
assert 's SATISFIABLE' in sol
true = set()
for line in sol.splitlines():
    if line.startswith('v '):
        true.update(x for x in map(int, line[2:].split()) if x > 0)
gates = []
def holds(lit):
    return lit in true if lit > 0 else -lit not in true
for g in meta['gates']:
    a = [j for j,v in enumerate(g['a']) if holds(v)]
    b = [j+1 for j,v in enumerate(g['b']) if holds(v)]
    assert len(a)==len(b)==1 and a[0]<b[0]
    gates.append([a[0],b[0],int(holds(g['op']))])
prefix.with_suffix('.json').write_text(json.dumps(dict(gates=gates)))
print(prefix.with_suffix('.json'))
