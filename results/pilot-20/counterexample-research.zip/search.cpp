#include <array>
#include <algorithm>
#include <bit>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <random>
#include <set>
#include <string>
#include <vector>
using namespace std;
struct Gate { int a,b; bool op; };
struct Sem { array<uint64_t,12> bits{}; uint64_t bp=0,bl=0,dp=0,dl=0; };
vector<uint32_t> tests;
vector<pair<int,int>> flags;
array<Sem,26> in;
int nt;
mt19937_64 rnd;
vector<Gate> star(bool square) {
 vector<Gate> g; vector<int> terms;
 auto add=[&](int a,int b,bool op){g.push_back({a,b,op});return 25+(int)g.size();};
 for(int l=0;l<13;l++) {
  int a=l,b=(l+1)%13,c=(l+3)%13,d=(l+9)%13;
  int s=add(a,b,true);s=add(s,c,true);s=add(s,d,true);
  int t=add(13+l,s,false);
  if(square && l==0) { int u=add(13+l,s,false); t=add(t,u,false); }
  terms.push_back(t);
 }
 int out=terms[0];for(int i=1;i<13;i++)out=add(out,terms[i],true);
 return g;
}
vector<Gate> shannon(bool omit) {
 vector<Gate> g; vector<int> terms;
 auto add=[&](int a,int b,bool op){g.push_back({a,b,op});return 25+(int)g.size();};
 auto lineNeighbors=[](int p){vector<int> ls;for(int l=0;l<13;l++)for(int d:{0,1,3,9})if((l+d)%13==p)ls.push_back(l+13);return ls;};
 for(int p=0;p<13;p++)if(p!=2) {
  auto ns=lineNeighbors(p);int s=ns[0];for(int k=1;k<4;k++)s=add(s,ns[k],true);
  terms.push_back(add(p,s,false));
 }
 int f=terms[0];for(int k=1;k<12;k++)f=add(f,terms[k],true);
 auto ns=lineNeighbors(2);int n=ns[0];for(int k=1;k<(omit?3:4);k++)n=add(n,ns[k],true);
 int a=add(f,2,true),b=add(f,n,true);add(a,b,false);
 return g;
}
struct Result {int bad, deriv, active; double score; uint64_t doubles;};
Result eval(const vector<Gate>&g,array<Sem,256>&s,int start=0) {
 for(int i=0;i<26;i++)s[i]=in[i];
 for(int j=start;j<(int)g.size();j++) {
  auto [a,b,op]=g[j]; auto &x=s[a],&y=s[b],&z=s[26+j];
  for(int k=0;k<12;k++)z.bits[k]=op?(x.bits[k]|y.bits[k]):(x.bits[k]&y.bits[k]);
  z.bp=op?(x.bp|y.bp):(x.bp&y.bp);z.bl=op?(x.bl|y.bl):(x.bl&y.bl);
  z.dp=op?(x.dp|y.dp):((x.bl&y.dp)|(x.dp&y.bl));
  z.dl=op?(x.dl|y.dl):((x.bp&y.dl)|(x.dl&y.bp));
 }
 auto &o=s[25+g.size()];int bad=0;
 for(int i=0;i<nt;i++) { bool v=(o.bits[i/64]>>(i%64))&1;bad+=(v!=(i<52)); }
 uint64_t correct=o.bits[0]&((1ULL<<52)-1),doubles=~(o.dp|o.dl)&correct;
 int deriv=doubles?0:((~(o.dp&o.dl)&correct)?1:2);
 array<bool,256> used{};used[25+g.size()]=true;int active=0;
 for(int j=(int)g.size()-1;j>=0;j--)if(used[j+26]) {active++;used[g[j].a]=used[g[j].b]=true;}
 return {bad,deriv,active,bad*2.0+deriv+active*0.005,doubles};
}
void save(const vector<Gate>&g,Result r,string path) {
 ofstream f(path);f<<"{\"bad\":"<<r.bad<<",\"deriv\":"<<r.deriv<<",\"active\":"<<r.active<<",\"double_mask\":"<<r.doubles<<",\"gates\":[";
 for(int j=0;j<(int)g.size();j++) {if(j)f<<",";f<<"["<<g[j].a<<","<<g[j].b<<","<<(g[j].op?1:0)<<"]";}f<<"]}\n";
}
int main(int argc,char**argv) {
 int seconds=argc>1?stoi(argv[1]):600;uint64_t seed=argc>2?stoull(argv[2]):1;
 string prefix=argc>3?argv[3]:"search";int slots=argc>4?stoi(argv[4]):64;
 vector<Gate> custom;
 if(argc>5) {ifstream f(argv[5]);int a,b,o;while(f>>a>>b>>o)custom.push_back({a,b,(bool)o});}
 rnd.seed(seed);array<int,13> nb;
 for(int l=0;l<13;l++){nb[l]=0;for(int d:{0,1,3,9})nb[l]|=1<<((l+d)%13);}
 for(int l=0;l<13;l++)for(int p=0;p<13;p++)if(nb[l]>>p&1){tests.push_back((1u<<p)|(1u<<(13+l)));flags.push_back({p,l});}
 set<uint32_t> zeros;
 for(int ps=0;ps<(1<<13);ps++) {int ls=0,pt=0;for(int l=0;l<13;l++)if(!(ps&nb[l]))ls|=1<<l;
  for(int p=0;p<13;p++){bool hit=false;for(int l=0;l<13;l++)if((ls>>l&1)&&(nb[l]>>p&1))hit=true;if(!hit)pt|=1<<p;}
  zeros.insert(pt|(ls<<13));
 }
 tests.insert(tests.end(),zeros.begin(),zeros.end());nt=tests.size();
 for(int j=0;j<26;j++) {
  for(int i=0;i<nt;i++)if(tests[i]>>j&1)in[j].bits[i/64]|=1ULL<<(i%64);
  for(int e=0;e<52;e++) {auto [p,l]=flags[e];if(j==p)in[j].bp|=1ULL<<e;if(j==13+l)in[j].bl|=1ULL<<e;}
  in[j].dp=in[j].bp;in[j].dl=in[j].bl;
 }
 cout<<"tests="<<nt<<" slots="<<slots<<" seed="<<seed<<endl;
 auto t0=chrono::steady_clock::now();uint64_t it=0;double best=1e9;vector<Gate> archive;
 for(int restart=0;;restart++) {
  auto g=custom.empty()?shannon(slots==64):custom;
  if((int)g.size()<slots) {
   auto base=g;vector<int> positions(slots-1);for(int k=0;k<slots-1;k++)positions[k]=k;
   shuffle(positions.begin(),positions.end(),rnd);positions.resize(base.size()-1);positions.push_back(slots-1);sort(positions.begin(),positions.end());
   array<int,256> remap{};for(int k=0;k<26;k++)remap[k]=k;
   g.clear();int old=0;
   for(int k=0;k<slots;k++) {
    if(old<(int)positions.size()&&positions[old]==k) {
     auto [a,b,o]=base[old];g.push_back({remap[a],remap[b],o});remap[26+old]=26+k;old++;
    } else {int a=rnd()%(26+k),b=rnd()%(26+k);while(a==b)b=rnd()%(26+k);g.push_back({a,b,(bool)(rnd()%2)});}
   }
  }
  if(restart%3 && !archive.empty())g=archive;
  array<Sem,256>s;Result r=eval(g,s);
  for(int epoch=0;epoch<300000;epoch++,it++) {
   if(it%65536==0&&chrono::duration<double>(chrono::steady_clock::now()-t0).count()>seconds){cout<<"DONE iterations="<<it<<" best="<<best<<endl;return 0;}
   int j=rnd()%g.size();Gate old=g[j];int kind=rnd()%20,start=j,par=-1;Gate oldpar{};
   if(kind<2)swap(g[j].a,g[j].b);
   else if(kind<6) {
    int pw=(rnd()%2)?g[j].a:g[j].b;
    int c=(pw==g[j].a)?g[j].b:g[j].a;
    if(pw<26||c>=pw)continue;
    par=pw-26;if(g[par].op!=g[j].op)continue;
    int uses=0;for(int z=par+1;z<(int)g.size();z++)uses+=(g[z].a==pw)+(g[z].b==pw);
    if(uses!=1)continue;
    oldpar=g[par];int a=oldpar.a,b=oldpar.b;if(rnd()%2)swap(a,b);
    if(a==c)continue;
    g[par]={a,c,g[j].op};g[j]={pw,b,g[j].op};start=par;
   }
   else if(kind<12)g[j].a=rnd()%(26+j);
   else if(kind<18)g[j].b=rnd()%(26+j);
   else g[j].op=!g[j].op;
   if(g[j].a==g[j].b){g[j]=old;continue;}
   auto oldsem=s;Result q=eval(g,s,start);
   double phase=(epoch%50000)/50000.0;
   double temp=0.10+0.6*pow(1-phase,3);
   bool accept=q.score<=r.score || uniform_real_distribution<double>()(rnd)<exp((r.score-q.score)/temp);
   if(accept)r=q;else {g[j]=old;if(par>=0)g[par]=oldpar;s=oldsem;}
   if(r.score<best) {best=r.score;archive=g;save(g,r,prefix+".json");cout<<"BEST i="<<it<<" bad="<<r.bad<<" deriv="<<r.deriv<<" active="<<r.active<<" score="<<r.score<<endl;}
   if(it%65536==0&&r.bad==0&&r.deriv==0&&r.active==65)save(g,r,prefix+"-neutral.json");
   if(r.bad==0&&r.deriv==0&&r.active<=64) {save(g,r,prefix+"-WITNESS.json");cout<<"WITNESS "<<prefix<<endl;return 0;}
  }
 }
}
