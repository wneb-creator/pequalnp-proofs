import json,sys
from pathlib import Path
f=json.loads(Path(sys.argv[1]).read_text())
c=json.loads(Path(sys.argv[2]).read_text())
n=f['input_count']; np=len(f['original_points']); gates=c['gates']; output=c.get('output',n+len(gates)-1)
assert output<n+len(gates)
for i,(a,b,op) in enumerate(gates):
    assert 0<=a<n+i and 0<=b<n+i and a!=b and op in (0,1)
def evaluate(x):
    v=[bool(x>>j&1) for j in range(n)]
    for a,b,op in gates:v.append(v[a] or v[b] if op else v[a] and v[b])
    return v
for x in range(1<<n):
    want=any(x>>p&1 and x>>(np+l)&1 for p,l in f['edges_local'])
    assert evaluate(x)[output]==want,(x,want)
bad=[]
for p,l in f['edges_local']:
    vp=evaluate(1<<p);vl=evaluate(1<<(np+l))
    dp=[j==p for j in range(n)];dl=[j==np+l for j in range(n)]
    for a,b,op in gates:
        dp.append(dp[a] or dp[b] if op else ((dp[a] and vl[b]) or (vl[a] and dp[b])))
        dl.append(dl[a] or dl[b] if op else ((dl[a] and vp[b]) or (vp[a] and dl[b])))
    if not dp[output] and not dl[output]:bad.append([p,l])
print(json.dumps(dict(gates=len(gates),inputs=n,checked_assignments=1<<n,double_flags=bad)))
