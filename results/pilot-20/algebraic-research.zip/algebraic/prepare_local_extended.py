from pathlib import Path
import json
base=Path('/tmp/oec/pequalnp-pilot-20/algebraic')
cat=json.loads((base/'shared-cover/local-types/catalogue.json').read_text())
out=base/'local/extended';out.mkdir(parents=True,exist_ok=True)
for typ in cat['classes']:
 name=typ['name'];points=typ['representative'];k=typ['k']
 for kind in ('core6','dnf'):
  gates=[]
  def gate(op,a,b):
   assert a!=b;gates.append([a,b,op]);return 25+len(gates)
  def ors(xs):
   if len(xs)==1:return xs[0]
   mid=len(xs)//2
   return gate(1,ors(xs[:mid]),ors(xs[mid:]))
  def neigh(p):return [l for l in range(13) if (p-l)%13 in (0,1,3,9)]
  def star(p):return gate(0,p,ors([13+l for l in neigh(p)]))
  if kind=='core6':
   p,q=points[:2];np=set(neigh(p));nq=set(neigh(q));common=sorted(np&nq);assert len(common)==1
   A=ors([13+l for l in sorted(np-nq)]);B=ors([13+l for l in sorted(nq-np)]);c=13+common[0]
   core=[p,q,A,B,c]
   for a,b,op in [[0,2,0],[4,5,1],[0,6,0],[1,7,1],[3,6,1],[8,9,0]]:core.append(gate(op,core[a],core[b]))
   output=ors([core[10]]+[star(p) for p in points[2:]])
   assert len(gates)==5*k
  else:
   terms=[gate(0,p,13+l) for l in range(13) for p in points if l in neigh(p)]
   output=ors(terms);assert len(gates)==8*k-1
  record={'gates':gates,'output':output,'selected_points':points,'target_cost':5*k-1,'type':name,'construction':kind}
  (out/f'{name}-{kind}.json').write_text(json.dumps(record,indent=2))
print(json.dumps({'types':len(cat['classes']),'seeds':2*len(cat['classes'])}))
