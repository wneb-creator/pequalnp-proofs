import argparse
import functools
import json
import random
import time
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--input', required=True)
parser.add_argument('--output-dir', required=True)
parser.add_argument('--seconds', type=float, default=30)
parser.add_argument('--beam', type=int, default=60)
parser.add_argument('--slack', type=int, default=2)
parser.add_argument('--seed', type=int, default=1)
args = parser.parse_args()
rng = random.Random(args.seed)
data = json.loads(Path(args.input).read_text())
outdir = Path(args.output_dir)
outdir.mkdir(parents=True, exist_ok=True)
nodes = [None] * 26
intern = {}
values = []
for i in range(26):
    values.append((i == 0, i == 13, i == 13, i == 0))

def make(op, a, b):
    if a == b:
        return a
    if b < a:
        a, b = b, a
    key = (op, a, b)
    if key in intern:
        return intern[key]
    n = len(nodes)
    nodes.append(key)
    intern[key] = n
    ap, al, av, aw = values[a]
    bp, bl, bv, bw = values[b]
    if op == 0:
        val = (ap and bp, al and bl, (ap and bv) or (av and bp), (al and bw) or (aw and bl))
    else:
        val = (ap or bp, al or bl, av or bv, aw or bw)
    values.append(val)
    return n

refs = list(range(26))
for a, b, op in data['gates']:
    refs.append(make(op, refs[a], refs[b]))
initial = refs[data['output']]

@functools.lru_cache(maxsize=120000)
def cone(n):
    if n < 26:
        return frozenset()
    _, a, b = nodes[n]
    return cone(a) | cone(b) | {n}

def variants(n):
    if n < 26:
        return []
    op, a, b = nodes[n]
    ans = set()
    for c, d in ((a, b), (b, a)):
        if c < 26:
            continue
        cop, u, v = nodes[c]
        if cop == op:
            ans.add(make(op, u, make(op, v, d)))
            ans.add(make(op, v, make(op, u, d)))
        else:
            ans.add(make(cop, make(op, u, d), make(op, v, d)))
            if d == u or d == v:
                ans.add(d)
    if a >= 26 and b >= 26:
        ao, au, av = nodes[a]
        bo, bu, bv = nodes[b]
        if ao == bo == 1 - op:
            for u, v in ((au, av), (av, au)):
                if u == bu:
                    ans.add(make(ao, u, make(op, v, bv)))
                if u == bv:
                    ans.add(make(ao, u, make(op, v, bu)))
    ans.discard(n)
    return list(ans)

def replace(root, old, new):
    memo = {old: new}
    def rec(n):
        if n < 26:
            return n
        if n in memo:
            return memo[n]
        op, a, b = nodes[n]
        ans = make(op, rec(a), rec(b))
        memo[n] = ans
        return ans
    return rec(root)

def export(root):
    order = sorted(cone(root))
    mapping = {i: i for i in range(26)}
    gates = []
    for n in order:
        op, a, b = nodes[n]
        mapping[n] = 26 + len(gates)
        gates.append([mapping[a], mapping[b], op])
    return {'gates': gates, 'output': mapping[root], 'p': 0, 'l': 0}

def validate(candidate):
    inc = lambda p, l: (p - l) % 13 in (0, 1, 3, 9)
    pos = [(1 << p) | (1 << (13 + l)) for p in range(13) for l in range(13) if inc(p, l)]
    neg = set()
    for pm in range(1 << 13):
        lm = sum(1 << l for l in range(13) if all(not inc(p, l) for p in range(13) if pm >> p & 1))
        pm2 = sum(1 << p for p in range(13) if all(not inc(p, l) for l in range(13) if lm >> l & 1))
        neg.add(pm2 | (lm << 13))
    tests = pos + sorted(neg)
    mask = (1 << len(pos)) - 1
    wires = [sum(((t >> i) & 1) << k for k, t in enumerate(tests)) for i in range(26)]
    for a, b, op in candidate['gates']:
        wires.append((wires[a] & wires[b]) if op == 0 else (wires[a] | wires[b]))
    return wires[candidate['output']] == mask, len(pos), len(neg)

start = time.monotonic()
initial_size = len(cone(initial))
assert initial_size == 65
assert not values[initial][2] and not values[initial][3]
assert validate(export(initial))[0]
seen = {initial}
beam = [initial]
best_bad = initial_size
rounds = 0
attempts = 0
counts = {}
print(json.dumps({'initial_size': initial_size, 'initial_values': values[initial]}), flush=True)
while time.monotonic() - start < args.seconds and beam:
    candidates = []
    for root in beam:
        verts = list(cone(root))
        rng.shuffle(verts)
        for n in verts:
            for new in variants(n):
                attempts += 1
                r = replace(root, n, new)
                if r in seen:
                    continue
                seen.add(r)
                count = len(cone(r))
                if count > initial_size + args.slack:
                    continue
                bad = not values[r][2] and not values[r][3]
                counts[(count, bad)] = counts.get((count, bad), 0) + 1
                if bad and count < best_bad:
                    best_bad = count
                    witness = export(r)
                    good, np, nn = validate(witness)
                    witness['validation'] = {'all_critical': good, 'positive_count': np, 'negative_count': nn}
                    (outdir / f'candidate-{count}.json').write_text(json.dumps(witness, indent=2))
                    print(json.dumps({'improvement': count, 'valid': good, 'attempts': attempts}), flush=True)
                    if count <= 64 and good:
                        args.seconds = 0
                        break
                candidates.append((count, bad, rng.random(), r))
            if time.monotonic() - start >= args.seconds:
                break
        if time.monotonic() - start >= args.seconds:
            break
    bads = sorted((c for c in candidates if c[1]), key=lambda c: (c[0], c[2]))
    goods = sorted((c for c in candidates if not c[1]), key=lambda c: (c[0], c[2]))
    selected = bads[:args.beam // 2] + goods[:args.beam // 2]
    if len(selected) < args.beam:
        extra = sorted(candidates, key=lambda c: (c[0], c[2]))
        used = {c[3] for c in selected}
        selected += [c for c in extra if c[3] not in used][:args.beam - len(selected)]
    beam = [c[3] for c in selected]
    rounds += 1
    print(json.dumps({'round': rounds, 'elapsed': round(time.monotonic() - start, 2), 'seen': len(seen), 'nodes': len(nodes), 'attempts': attempts, 'best_bad': best_bad, 'beam': len(beam)}), flush=True)
summary = {'seconds': time.monotonic() - start, 'rounds': rounds, 'seen': len(seen), 'nodes': len(nodes), 'attempts': attempts, 'best_bad': best_bad, 'counts': {f'{n},{b}': v for (n,b),v in counts.items()}}
(outdir / 'summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary), flush=True)
