import json
import subprocess
from pathlib import Path
base = Path('/tmp/oec/pequalnp-pilot-20/algebraic')
results = []
for seed, slack, mode in [(719,3,'truth'), (809,6,'singletons'), (907,10,'full'), (1009,10,'truth'), (1103,3,'singletons'), (1201,6,'full')]:
    dest = base / f'semantic-{seed}'
    with (base/f'semantic-{seed}.stdout').open('w') as out, (base/f'semantic-{seed}.stderr').open('w') as err:
        run = subprocess.run(['python3', str(base/'rewrite_semantic.py'), '--input', '/tmp/oec/pequalnp-pilot-20/search/shannon65-full.json', '--output-dir', str(dest), '--seconds', '30', '--beam', '100', '--slack', str(slack), '--seed', str(seed), '--max-nodes', '1500000', '--semantic-key', mode], stdout=out, stderr=err)
    if run.returncode != 0:
        raise SystemExit(run.returncode)
    result = json.loads((dest/'summary.json').read_text())
    result['seed'] = seed
    result['slack'] = slack
    results.append(result)
    print(json.dumps(result), flush=True)
    if result['best_bad'] <= 64:
        break
(base/'batch-semantic-summary.json').write_text(json.dumps(results, indent=2))
