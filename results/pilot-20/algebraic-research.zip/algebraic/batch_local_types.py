import json,subprocess,sys
from pathlib import Path
base=Path('/tmp/oec/pequalnp-pilot-20/algebraic')
root=base/'local'/'types'
summaries=[]
seeds=sorted(root.glob('*-ordinary.json'))+sorted(root.glob('*-shannon.json'))
for i,seed in enumerate(seeds):
 data=json.loads(seed.read_text());name=seed.stem;out=root/name
 mode='full' if data['construction']=='ordinary' else 'truth'
 freq='0.3' if mode=='full' else '0.12'
 cmd=[sys.executable,str(base/'rewrite_local.py'),'--input',str(seed),'--output-dir',str(out),'--seconds','45','--beam','80','--seed',str(3001+i*47),'--max-nodes','2000000','--semantic-key',mode,'--max-gates',str(data['target_cost']+13),'--cse-frequency',freq,'--insertions','0.65']
 with (root/f'{name}.stdout').open('w') as stdout,(root/f'{name}.stderr').open('w') as stderr:
  result=subprocess.run(cmd,stdout=stdout,stderr=stderr)
 if result.returncode:
  print(json.dumps({'name':name,'exit':result.returncode}),flush=True)
  raise SystemExit(result.returncode)
 summary=json.loads((out/'summary.json').read_text());summary.update(name=name,points=data['selected_points'],target=data['target_cost']);summaries.append(summary)
 (root/'batch-summary.json').write_text(json.dumps(summaries,indent=2))
 print(json.dumps({k:summary[k] for k in ['name','target','best_bad','attempts','seen','seconds']}),flush=True)
 if summary['best_bad']<=data['target_cost']:
  print('CANDIDATE_FOUND',name,flush=True)
  break
