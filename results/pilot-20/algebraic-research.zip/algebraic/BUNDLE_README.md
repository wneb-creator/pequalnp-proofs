# L-meta-1482 bounded algebraic research

This directory contains exploratory searches, complete stdout/stderr, exact
candidate netlists, and independent finite validation. It is **not an exhaustive
lower-bound proof** and currently contains no counterexample with at most64
gates. The verified65-gate boundary construction is maintained separately by
the root agent.

Netlists use26 original inputs and gates `[a,b,op]`, where op0 is AND and op1 is
OR. The small local-type source seeds under `shared-cover/local-types/` are the
exception: their `input_count` and `input_to_global` specify compact inputs.
Globalized versions under `local/types/` use26 inputs.

The early `test/`, `test.stdout`, and `test.stderr` are an INVALID diagnostic
smoke run from an input-order bug. They are preserved for audit only, excluded
from every reported main-batch count, and provide no mathematical evidence.
All subsequent searches fixed the gate order and validate their starting seed.

Main global searches: fixed-edge rewrites, all52-edge derivative bitmasks,
semantic common-subexpression merging,101-gate expanded-DNF seeds with110–140
gate intermediates, and a local-Shannon65-gate seed. Every reported improving
candidate is independently checked on52 minimal positive pairs and704 maximal
negative closures, and its selected formal-derivative witness is recomputed
with ordinary Boolean operations. The Lean monotonicity/critical-input helper
justifies why this finite correctness criterion suffices.

Local searches cover every isomorphism type induced by2–5 point rows, using
ordinary star and Shannon seeds. They add inverse absorption and physical gate
duplication moves. Their target budgets are5k−1. The nine local incidence types
are an exhaustive classification of2366 point subsets; the circuit search
within each type remains bounded and nonexhaustive.

`rewrite_local.py` preserves newly introduced duplicate computations during
search, but its original seed loader hash-conses physical duplicates. The
current canonical seeds contain no duplicate gates, so this does not affect
those runs. `rewrite_local_v2.py` fixes import/restart preservation and must be
used when restarting from a candidate that may contain physical duplicates.

`shared-cover/README.md` proves a restricted65-gate lower bound for one defined
star-first Shannon family. It is not a general circuit theorem. Its finite
cover census and independent support/dependency abstraction check are included.

No CNF files, credentials, or external service data are included. Attempt/state
counts are per run; sums are not deduplicated across runs. Source hashes and
completed-batch summaries are recorded in JSON reports.

The exact C++ checks under `local/core5/` concern the compressed five-input
function `p(A OR c) OR q(B OR c)` with four preprocessing OR gates fixed outside
the core. The complete five-gate census finds no double reread; the complete
six-gate census finds32 ordered physical netlists with private-edge double
rereads. These are positive boundary examples costing10 local/65 global gates,
not64-gate counterexamples. `calibrate.cpp` intentionally stops after its first
six-core-gate example, whereas `census6.cpp` completes the enumeration. The
complete six-gate census subsumes the earlier five-gate census, so its prefix
counts must not be added again as distinct netlists.

`historical-report.json` retains only the first18 global beam runs. `report.json`
is the aggregate for completed main batches and explicitly reports whether any
batch remains in progress. Exact finite censuses, deterministic test fixtures,
and exploratory beam searches are counted separately. The final archive
manifest lists every included source/data/log file with its SHA256 digest.

Compressed fixtures under `shared-cover/local-types/*-compressed.json` use
`line_groups` and fixed preprocessing OR gates instead of `input_to_global`.
See that directory's README for the exact formats and budgets. Spliced global
fixtures have `selected_points` equal to all13 points; their
`local_selected_points` field records the source subset only.

Beam-search `seen` counts are distinct internal DAG root identifiers within each
run, not graph isomorphism classes or certified distinct circuit functions.
Physical-duplication insertions can give equivalent netlists different internal
identifiers. Exact C++ census counts instead count ordered physical gate lists;
topological reorderings are intentionally counted separately.

An execution-environment transition around01:38UTC interrupted the first
`k3-type2-dnf` attempt after its last logged round at43.61seconds. No exit status
or final summary was available; both its driver and worker were absent after
the transition. Its complete available logs/candidates are preserved under
`local/extended/interrupted-0138-k3-type2-dnf*`, and
`transition-interruption.json` records status UNKNOWN and221576 observed
attempts. These partial attempts are excluded from main completed-run totals.
The remaining seven planned runs were resumed from their original seeds;
`resume_local_extended.py` and `local/extended/resume.*` preserve that action.
