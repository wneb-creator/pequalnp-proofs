import json
import subprocess
from pathlib import Path
base = Path('/tmp/oec/pequalnp-pilot-20/algebraic')
folder = base/'expanded'
runs = [
    ('point-balanced', 1709, 110, 'full'),
    ('line-balanced', 1801, 140, 'truth'),
    ('random-left', 1907, 140, 'full'),
    ('point-left', 2003, 120, 'singletons'),
    ('line-left', 2111, 130, 'full'),
    ('random-balanced', 2203, 140, 'truth')]
results = []
for shape, seed, ceiling, mode in runs:
    dest = folder/f'run-{seed}'
    with (folder/f'run-{seed}.stdout').open('w') as out, (folder/f'run-{seed}.stderr').open('w') as err:
        result = subprocess.run(['python3', str(base/'rewrite_expanded_wide.py'), '--input', str(folder/f'seed-{shape}.json'), '--output-dir', str(dest), '--seconds', '90', '--beam', '48', '--max-gates', str(ceiling), '--seed', str(seed), '--max-nodes', '1500000', '--semantic-key', mode], stdout=out, stderr=err)
    if result.returncode:
        raise SystemExit(result.returncode)
    summary = json.loads((dest/'summary.json').read_text())
    summary['seed'] = seed
    summary['seed_shape'] = shape
    results.append(summary)
    print(json.dumps(summary), flush=True)
    if summary['best_bad'] <= 64:
        break
(folder/'batch-summary.json').write_text(json.dumps(results,indent=2)+'\n')
