import argparse
import functools
import json
import random
import time
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--input', required=True)
parser.add_argument('--output-dir', required=True)
parser.add_argument('--seconds', type=float, default=30)
parser.add_argument('--beam', type=int, default=60)
parser.add_argument('--slack', type=int, default=2)
parser.add_argument('--seed', type=int, default=1)
parser.add_argument('--max-nodes', type=int, default=1500000)
parser.add_argument('--semantic-key', choices=['truth', 'singletons', 'full'], default='truth')
parser.add_argument('--max-gates', type=int, default=140)
args = parser.parse_args()
rng = random.Random(args.seed)
data = json.loads(Path(args.input).read_text())
outdir = Path(args.output_dir)
outdir.mkdir(parents=True, exist_ok=True)
nodes = [None] * 26
intern = {}
edges = [(p, l) for p in range(13) for l in range(13) if (p-l)%13 in (0,1,3,9)]
assert len(edges) == 52
negative_tests = set()
for point_mask in range(1 << 13):
    line_mask = sum(1 << l for l in range(13) if all((p-l)%13 not in (0,1,3,9) for p in range(13) if point_mask >> p & 1))
    point_closed = sum(1 << p for p in range(13) if all((p-l)%13 not in (0,1,3,9) for l in range(13) if line_mask >> l & 1))
    negative_tests.add(point_closed | (line_mask << 13))
critical_tests = [(1 << p) | (1 << (13+l)) for p,l in edges] + sorted(negative_tests)
assert len(critical_tests) == 756
truths = [sum(((t >> i) & 1) << k for k,t in enumerate(critical_tests)) for i in range(26)]
edge_mask = (1 << len(edges)) - 1
pmasks = [sum(1 << k for k,(p,l) in enumerate(edges) if p == i) for i in range(13)]
lmasks = [sum(1 << k for k,(p,l) in enumerate(edges) if l == i) for i in range(13)]
values = []
for i in range(26):
    if i < 13:
        values.append((pmasks[i], 0, 0, pmasks[i]))
    else:
        values.append((0, lmasks[i-13], lmasks[i-13], 0))

def bad_mask(n):
    return edge_mask & ~(values[n][2] | values[n][3])

def make(op, a, b):
    if a == b:
        return a
    if b < a:
        a, b = b, a
    key = (op, a, b)
    if key in intern:
        return intern[key]
    n = len(nodes)
    nodes.append(key)
    intern[key] = n
    ap, al, av, aw = values[a]
    bp, bl, bv, bw = values[b]
    if op == 0:
        val = (ap & bp, al & bl, (ap & bv) | (av & bp), (al & bw) | (aw & bl))
    else:
        val = (ap | bp, al | bl, av | bv, aw | bw)
    values.append(val)
    truths.append((truths[a] & truths[b]) if op == 0 else (truths[a] | truths[b]))
    return n

refs = list(range(26))
for a, b, op in data['gates']:
    refs.append(make(op, refs[a], refs[b]))
initial = refs[data['output']]

@functools.lru_cache(maxsize=120000)
def cone(n):
    if n < 26:
        return frozenset()
    _, a, b = nodes[n]
    return cone(a) | cone(b) | {n}

@functools.lru_cache(maxsize=120000)
def flatten_op(n, op):
    if n < 26 or nodes[n][0] != op:
        return (n,)
    _, a, b = nodes[n]
    items = flatten_op(a, op) + flatten_op(b, op)
    return items if len(items) <= 96 else (n,)

def join_op(op, items):
    items = sorted(items)
    if len(items) == 1:
        return items[0]
    mid = len(items) // 2
    return make(op, join_op(op, items[:mid]), join_op(op, items[mid:]))

@functools.lru_cache(maxsize=150000)
def variants(n):
    if n < 26:
        return []
    op, a, b = nodes[n]
    ans = set()
    for c, d in ((a, b), (b, a)):
        if c < 26:
            continue
        cop, u, v = nodes[c]
        if cop == op:
            ans.add(make(op, u, make(op, v, d)))
            ans.add(make(op, v, make(op, u, d)))
        else:
            ans.add(make(cop, make(op, u, d), make(op, v, d)))
            if d == u or d == v:
                ans.add(d)
    if a >= 26 and b >= 26:
        ao, au, av = nodes[a]
        bo, bu, bv = nodes[b]
        if ao == bo == 1 - op:
            for u, v in ((au, av), (av, au)):
                if u == bu:
                    ans.add(make(ao, u, make(op, v, bv)))
                if u == bv:
                    ans.add(make(ao, u, make(op, v, bu)))
    leaves = flatten_op(n, op)
    if 3 <= len(leaves) <= 96:
        groups = {}
        for idx, leaf in enumerate(leaves):
            if leaf >= 26 and nodes[leaf][0] == 1-op:
                _, u, v = nodes[leaf]
                groups.setdefault(u, []).append((idx, v))
                groups.setdefault(v, []).append((idx, u))
        for common, group in groups.items():
            if len(group) < 2:
                continue
            used = {idx for idx,other in group}
            rest = [leaf for idx,leaf in enumerate(leaves) if idx not in used]
            grouped = make(1-op, common, join_op(op, [other for idx,other in group]))
            ans.add(join_op(op, rest + [grouped]))
    ans.discard(n)
    return list(ans)

def replace(root, old, new):
    memo = {old: new}
    def rec(n):
        if n < 26:
            return n
        if n in memo:
            return memo[n]
        op, a, b = nodes[n]
        ans = make(op, rec(a), rec(b))
        memo[n] = ans
        return ans
    return rec(root)

def semantic_normalize(root):
    def key(n):
        if args.semantic_key == 'full':
            return (truths[n], *values[n])
        if args.semantic_key == 'singletons':
            return (truths[n], values[n][0], values[n][1])
        return truths[n]
    mapping = {i:i for i in range(26)}
    representatives = {key(i):i for i in range(26)}
    for n in sorted(cone(root)):
        op, a, b = nodes[n]
        new = make(op, mapping[a], mapping[b])
        k = key(new)
        if k in representatives:
            mapping[n] = representatives[k]
        else:
            representatives[k] = new
            mapping[n] = new
    return mapping[root]

def export(root):
    order = sorted(cone(root))
    mapping = {i: i for i in range(26)}
    gates = []
    for n in order:
        op, a, b = nodes[n]
        mapping[n] = 26 + len(gates)
        gates.append([mapping[a], mapping[b], op])
    bm = bad_mask(root)
    index = (bm & -bm).bit_length() - 1 if bm else 0
    p, l = edges[index]
    return {'gates': gates, 'output': mapping[root], 'p': p, 'l': l, 'double_edges': bm.bit_count()}

def validate(candidate):
    inc = lambda p, l: (p - l) % 13 in (0, 1, 3, 9)
    pos = [(1 << p) | (1 << (13 + l)) for p in range(13) for l in range(13) if inc(p, l)]
    neg = set()
    for pm in range(1 << 13):
        lm = sum(1 << l for l in range(13) if all(not inc(p, l) for p in range(13) if pm >> p & 1))
        pm2 = sum(1 << p for p in range(13) if all(not inc(p, l) for l in range(13) if lm >> l & 1))
        neg.add(pm2 | (lm << 13))
    tests = pos + sorted(neg)
    mask = (1 << len(pos)) - 1
    wires = [sum(((t >> i) & 1) << k for k, t in enumerate(tests)) for i in range(26)]
    for a, b, op in candidate['gates']:
        wires.append((wires[a] & wires[b]) if op == 0 else (wires[a] | wires[b]))
    return wires[candidate['output']] == mask, len(pos), len(neg)

def derivative_check(candidate):
    p, l = candidate['p'], candidate['l']
    pv = [i == p for i in range(26)]
    lv = [i == 13+l for i in range(26)]
    v = lv.copy()
    w = pv.copy()
    for a,b,op in candidate['gates']:
        if op == 0:
            pv.append(pv[a] and pv[b])
            lv.append(lv[a] and lv[b])
            v.append((pv[a] and v[b]) or (v[a] and pv[b]))
            w.append((lv[a] and w[b]) or (w[a] and lv[b]))
        else:
            pv.append(pv[a] or pv[b])
            lv.append(lv[a] or lv[b])
            v.append(v[a] or v[b])
            w.append(w[a] or w[b])
    o = candidate['output']
    return (p-l)%13 in (0,1,3,9) and not v[o] and not w[o]

start = time.monotonic()
initial_size = len(cone(initial))
assert initial_size == len(data['gates'])
assert bad_mask(initial)
assert validate(export(initial))[0]
assert derivative_check(export(initial))
seen = {initial}
beam = [initial]
best_bad = initial_size
rounds = 0
attempts = 0
counts = {}
print(json.dumps({'initial_size': initial_size, 'initial_values': values[initial], 'initial_double_edges': bad_mask(initial).bit_count()}), flush=True)
while time.monotonic() - start < args.seconds and beam and len(nodes) < args.max_nodes:
    candidates = []
    for root in beam:
        verts = list(cone(root))
        rng.shuffle(verts)
        for n in verts:
            for new in variants(n):
                attempts += 1
                r = semantic_normalize(replace(root, n, new))
                if r in seen:
                    continue
                seen.add(r)
                count = len(cone(r))
                if count > args.max_gates:
                    continue
                bad = bool(bad_mask(r))
                counts[(count, bad)] = counts.get((count, bad), 0) + 1
                if bad and count < best_bad:
                    best_bad = count
                    witness = export(r)
                    good, np, nn = validate(witness)
                    assert derivative_check(witness)
                    witness['validation'] = {'all_critical': good, 'positive_count': np, 'negative_count': nn}
                    (outdir / f'candidate-{count}.json').write_text(json.dumps(witness, indent=2))
                    print(json.dumps({'improvement': count, 'valid': good, 'attempts': attempts}), flush=True)
                    if count <= 64 and good:
                        args.seconds = 0
                        break
                candidates.append((count, bad, rng.random(), r))
            if time.monotonic() - start >= args.seconds:
                break
        if time.monotonic() - start >= args.seconds:
            break
    bads = sorted((c for c in candidates if c[1]), key=lambda c: (c[0], c[2]))
    goods = sorted((c for c in candidates if not c[1]), key=lambda c: (c[0], c[2]))
    selected = bads[:args.beam // 3] + goods[:args.beam // 5]
    used = {c[3] for c in selected}
    expansion = sorted(bads, key=lambda c: (-c[0], c[2]))
    selected += [c for c in expansion if c[3] not in used][:args.beam // 6]
    used = {c[3] for c in selected}
    groups = {}
    for c in candidates:
        if c[3] not in used:
            groups.setdefault((c[0], c[1]), []).append(c)
    for group in groups.values():
        rng.shuffle(group)
    while len(selected) < args.beam and groups:
        group_keys = list(groups)
        rng.shuffle(group_keys)
        for key in group_keys:
            selected.append(groups[key].pop())
            if not groups[key]:
                del groups[key]
            if len(selected) >= args.beam:
                break
    if len(selected) < args.beam:
        extra = sorted(candidates, key=lambda c: (c[0], c[2]))
        used = {c[3] for c in selected}
        selected += [c for c in extra if c[3] not in used][:args.beam - len(selected)]
    beam = [c[3] for c in selected]
    rounds += 1
    print(json.dumps({'round': rounds, 'elapsed': round(time.monotonic() - start, 2), 'seen': len(seen), 'nodes': len(nodes), 'attempts': attempts, 'best_bad': best_bad, 'beam': len(beam)}), flush=True)
summary = {'seconds': time.monotonic() - start, 'rounds': rounds, 'seen': len(seen), 'nodes': len(nodes), 'attempts': attempts, 'best_bad': best_bad, 'semantic_key': args.semantic_key, 'initial_size': initial_size, 'max_gates': args.max_gates, 'counts': {f'{n},{b}': v for (n,b),v in counts.items()}}
(outdir / 'summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary), flush=True)
