# A restricted 65-gate lower bound for the Shannon construction

This is a mathematical argument for a restricted circuit family. It is not a
proof of gap L-meta-1482 and does not rule out a general 64-gate circuit. No Lean
formalization is claimed for this note.

Let incidence be `(p-l) mod 13` in `{0,1,3,9}`, take pivot point `r=2`, and let
`N={1,2,6,12}` be its four incident line indices. Let `A` be the incidence
function after deleting point 2. There are 48 remaining edges. The Shannon
construction has factors `F1=A OR r`, `F2=A OR OR(N)`, and final output
`F1 AND F2`.

## Exact family covered

The first factor is computed by the following construction, and only its
actually constructed wires and the original 26 input wires are available to the
second factor.

1. Partition the 48 edges into nonempty stars, using at most one star for each
   chosen point or line center. A star can use a proper subset of that center's
   incident edges.
2. For a k-edge star, OR its k neighbor variables using binary OR gates, then
   AND that result with the center variable. A one-edge star needs just one AND.
3. Combine all star outputs and input r using only binary OR gates. All
   parentheses and all sharing consistent with these instructions are allowed.
4. Compute the second factor by an arbitrary monotone binary-gate continuation
   from those available wires, and add a final binary AND of the two factors.

In particular, arbitrary unused preparatory gates, nonstar factorizations in the
first factor, and mutually interleaved constructions of the two factors are
outside this family. The second factor need not use stars, and may freely reuse
any first-factor wire.

## First-factor cost is at least 60

The twelve edges `(p,p)` for `p != 2` are a matching. Every star center covers at
most one of these edges, so the number s of nonempty stars is at least twelve.

The k-edge star requires k gates: k-1 OR gates and one AND. Distinct point
centers share at most one line neighbor, and distinct line centers share at
most one point neighbor. Thus there is no nontrivial shared neighbor-OR
subexpression across distinct stars. A point-neighbor OR and line-neighbor OR
use disjoint types of input variables and also cannot coincide. In total, the
star computations require at least 48 gates. Combining s distinct star outputs
and r by binary OR requires at least s further gates. Consequently F1 costs at
least 48+s >= 60.

## The second factor needs at least four additional gates

For a wire z, define its N-singleton support to be the subset of the four line
indices in N on whose singleton input z evaluates true. Every wire available
after the first factor has one of the following forms.

* A pure line input or a neighbor-OR for a point-centered star. It is independent
  of all point inputs, and its N-singleton support has size at most one: each
  point other than r shares exactly one incident line with r.
* A point input, point-neighbor OR, star output, or OR aggregate of star outputs
  and r. Its N-singleton support is empty.

Thus every available source has support size at most one, and every source
with nonempty support is independent of point inputs.

The desired second factor has support all four elements of N. An OR gate unions
singleton supports; an AND gate intersects them. Starting from singleton-sized
supports, an output with four distinct support elements requires at least three
OR gates. One way to see this is to prune either input at each AND: the resulting
OR-only output contains the original support and has at most one more distinct
source than its number of OR gates.

If the entire continuation used at most three gates, therefore, all three
would have to be OR gates. Their connected output cone would have at most four
distinct source wires. To cover all four support elements, all four sources
would have to have nonempty support. Every one is point-independent, so their
OR output would also be point-independent.

But F2 is point-dependent: line 0 is outside N, and the singleton line-0 input
has F2 false, whereas adding point 0 makes F2 true through edge `(0,0)`. This is
a contradiction. At least four new gates are necessary.

The final AND therefore gives a total lower bound of 60+4+1=65. The known
point-star Shannon circuit attains 65, so the bound is sharp within this family.

## Finite census and independent abstraction check

`cover_census.py` enumerates all 4096 subsets U of the twelve nonpivot points.
The corresponding canonical cover is the other points together with exactly
the forced lines N(U). It also does this for the outside and inside subgraphs.
`cover-census.json` records the full size histograms and minimizing covers.

* The 48-edge graph has a unique minimum cover of size 12: all nonpivot points.
* Among these canonical covers, the only size-13 cover is all thirteen lines.
  This is not a uniqueness claim among arbitrary size-13 vertex covers: adding
  an extra line to the size-12 point cover also gives such a cover.
* The outside 36-edge graph has minimum 9, attained only by its nine lines.
* The inside 12-edge graph has minimum 4, attained only by its four lines.

`continuation_check.py` separately explores a conservative abstraction of every
possible continuation with up to four gates. Each source records only its
four-bit N-singleton support and whether it may depend on points. Its AND/OR
dependency flag is the OR of the operands' dependency flags, so this is an
overapproximation, never a reason to exclude a real circuit. Even in this
overapproximation, full support together with point dependence first appears at
four gates. Complete program output is preserved in the corresponding stdout
and stderr files.
