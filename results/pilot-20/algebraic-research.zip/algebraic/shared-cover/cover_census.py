import collections
import json
from pathlib import Path

PIVOT = 2
POINTS = tuple(p for p in range(13) if p != PIVOT)
INC = lambda p, l: (p - l) % 13 in (0, 1, 3, 9)
N = tuple(l for l in range(13) if INC(PIVOT, l))
OUT = tuple(l for l in range(13) if l not in N)

def census(lines):
    histogram = collections.Counter()
    minimum = 100
    minimizers = []
    for bits in range(1 << len(POINTS)):
        omitted = [p for j, p in enumerate(POINTS) if bits >> j & 1]
        selected_points = [p for j, p in enumerate(POINTS) if not bits >> j & 1]
        selected_lines = [l for l in lines if any(INC(p, l) for p in omitted)]
        size = len(selected_points) + len(selected_lines)
        histogram[size] += 1
        if size < minimum:
            minimum = size
            minimizers = []
        if size == minimum:
            minimizers.append(dict(points=selected_points, lines=selected_lines))
    return dict(minimum=minimum, histogram=dict(sorted(histogram.items())), minimizers=minimizers)

assert N == (1, 2, 6, 12)
assert all(sum(INC(p, l) for l in N) == 1 for p in POINTS)
assert all(sum(INC(p, l) and INC(q, l) for l in range(13)) == 1
           for p in range(13) for q in range(p))
assert all(sum(INC(p, l) and INC(p, m) for p in range(13)) == 1
           for l in range(13) for m in range(l))

result = dict(
    pivot=PIVOT,
    neighbor_lines=N,
    outside_lines=OUT,
    graph_edges=sum(INC(p, l) for p in POINTS for l in range(13)),
    outside_edges=sum(INC(p, l) for p in POINTS for l in OUT),
    inside_edges=sum(INC(p, l) for p in POINTS for l in N),
    full_cover=census(tuple(range(13))),
    outside_cover=census(OUT),
    inside_cover=census(N),
    diagonal_matching=[[p, p] for p in POINTS],
    scope="Star implementations of the first Shannon factor, followed by a circuit for the second factor and a final AND; not arbitrary circuits.",
    restricted_minimum=65,
)
text = json.dumps(result, indent=2, sort_keys=True)
Path(__file__).with_name("cover-census.json").write_text(text + "\n")
print(text)
