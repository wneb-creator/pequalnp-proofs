import itertools
import json
from pathlib import Path

# A value is (N-singleton support, may depend on point inputs).
# Include both support-empty possibilities to overapproximate every old wire.
initial = frozenset([(0, False), (0, True)] + [(1 << i, False) for i in range(4)])
states = {initial}
counts = []
for depth in range(5):
    found = any((15, True) in state for state in states)
    counts.append(dict(gates=depth, states=len(states), desired_abstract_value=found))
    if found:
        assert depth == 4
        break
    assert depth < 4
    following = set()
    for state in states:
        for a, b in itertools.combinations_with_replacement(sorted(state), 2):
            for support in (a[0] & b[0], a[0] | b[0]):
                value = (support, a[1] or b[1])
                following.add(state | {value})
    states = following

result = dict(
    abstract_sources=sorted(initial),
    stages=counts,
    minimum_gates=4,
    interpretation="Conservative support/dependency abstraction, not a general circuit lower bound.",
)
text = json.dumps(result, indent=2, sort_keys=True)
Path(__file__).with_name("continuation-check.json").write_text(text + "\n")
print(text)
