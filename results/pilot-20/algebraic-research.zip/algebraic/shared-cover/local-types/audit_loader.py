import json
import runpy
import sys
from pathlib import Path

BASE = Path(__file__).parent
source = Path('/tmp/oec/pequalnp-pilot-20/algebraic/local/seed-2-ordinary.json')
data = json.loads(source.read_text())
old_output = data['output']
assert old_output >= 26
data['gates'].append(data['gates'][old_output - 26].copy())
duplicate = 25 + len(data['gates'])
data['gates'].append([old_output, duplicate, 0])
data['output'] = 25 + len(data['gates'])
data['construction'] = 'duplicate_restart_audit'
candidate_path = BASE / 'duplicate-restart.json'
candidate_path.write_text(json.dumps(data, indent=2) + '\n')
sys.argv = ['rewrite_local_v2.py', '--input', str(candidate_path),
            '--output-dir', str(BASE / 'duplicate-restart-run'), '--seconds', '0']
state = runpy.run_path('/tmp/oec/pequalnp-pilot-20/algebraic/rewrite_local_v2.py')
assert state['initial_size'] == len(data['gates']) == 11
assert len(set(state['refs'])) == len(state['refs'])
assert state['bad_mask'](state['initial']).bit_count() == 8

def evaluate(assignment):
    vals = [bool(assignment >> i & 1) for i in range(26)]
    for a, b, op in data['gates']:
        vals.append((vals[a] and vals[b]) if op == 0 else (vals[a] or vals[b]))
    return vals

checked = 0
for bit, (p, l) in enumerate(state['edges']):
    pv = evaluate(1 << p)
    lv = evaluate(1 << (13 + l))
    v = [i == 13 + l for i in range(26)]
    w = [i == p for i in range(26)]
    for a, b, op in data['gates']:
        if op == 0:
            v.append((pv[a] and v[b]) or (v[a] and pv[b]))
            w.append((lv[a] and w[b]) or (w[a] and lv[b]))
        else:
            v.append(v[a] or v[b])
            w.append(w[a] or w[b])
    for wire, internal in enumerate(state['refs']):
        observed = tuple(bool(mask >> bit & 1) for mask in state['values'][internal])
        assert observed == (pv[wire], lv[wire], v[wire], w[wire])
        checked += 1
result = dict(physical_gates_preserved=11, distinct_physical_wires=len(state['refs']),
              checked_wire_edge_states=checked, double_edges=8, result='passed')
(BASE / 'loader-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
