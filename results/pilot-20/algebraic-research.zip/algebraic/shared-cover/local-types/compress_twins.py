import collections
import json
from pathlib import Path

BASE = Path(__file__).parent
catalogue = json.loads((BASE / 'catalogue.json').read_text())
INC = lambda p, l: (p - l) % 13 in (0, 1, 3, 9)
summary = []
for item in catalogue['classes']:
    points = item['representative']
    k = len(points)
    groups = collections.defaultdict(list)
    for l in range(13):
        mask = sum(1 << i for i, p in enumerate(points) if INC(p, l))
        if mask:
            groups[mask].append(l)
    masks = sorted(groups)
    n = k + len(masks)
    preprocessing = sum(len(groups[mask]) - 1 for mask in masks)
    assert all(len(groups[mask]) == 1 or mask.bit_count() == 1 for mask in masks)
    gates = []
    def add(a, b, op):
        assert a != b and 0 <= a < n + len(gates) and 0 <= b < n + len(gates)
        gates.append([a, b, op])
        return n + len(gates) - 1
    terms = []
    for p in range(k):
        neighbors = [k + j for j, mask in enumerate(masks) if mask >> p & 1]
        out = neighbors[0]
        for line in neighbors[1:]:
            out = add(out, line, 1)
        terms.append(add(p, out, 0))
    output = terms[0]
    for term in terms[1:]:
        output = add(output, term, 1)
    assert len(gates) + preprocessing == 5 * k - 1
    edges = [(p, j) for p in range(k) for j, mask in enumerate(masks) if mask >> p & 1]
    ones = [(1 << p) | (1 << (k + j)) for p, j in edges]
    zeros = set()
    for chosen in range(1 << k):
        allowed = [j for j, mask in enumerate(masks) if mask & chosen == 0]
        closed = [p for p in range(k) if all(not (masks[j] >> p & 1) for j in allowed)]
        zeros.add(sum(1 << p for p in closed) | sum(1 << (k + j) for j in allowed))
    tests = ones + sorted(zeros)
    truth = [sum(((assignment >> i) & 1) << t for t, assignment in enumerate(tests)) for i in range(n)]
    wires = truth[:]
    for a, b, op in gates:
        wires.append(wires[a] | wires[b] if op else wires[a] & wires[b])
    assert wires[output] == (1 << len(ones)) - 1
    result = dict(
        name=item['name'], original_points=points, input_count=n,
        line_groups=[groups[mask] for mask in masks], line_group_point_masks=masks,
        gates=gates, output=output,
        fixed_preprocessing_or_gates=preprocessing,
        target_core_cost=len(gates), target_total_local_cost=5 * k - 1,
        edges_local=edges, minones=ones, maxzeros=sorted(zeros),
        input_truth_hex=[hex(value) for value in truth],
        expected_truth_hex=hex((1 << len(ones)) - 1),
        meaning='Each compressed line input is the OR of its original line group; preprocessing is fixed and costs the sum of group size minus one.',
    )
    (BASE / f"{item['name']}-compressed.json").write_text(json.dumps(result, indent=2) + '\n')
    summary.append({key: result[key] for key in ('name', 'original_points', 'input_count',
        'fixed_preprocessing_or_gates', 'target_core_cost', 'target_total_local_cost', 'line_groups')})
(BASE / 'compressed-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
