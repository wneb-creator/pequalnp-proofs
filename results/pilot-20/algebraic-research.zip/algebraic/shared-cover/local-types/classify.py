import collections
import itertools
import json
import time
from pathlib import Path

BASE = Path(__file__).parent
INC = lambda p, l: (p - l) % 13 in (0, 1, 3, 9)

def perm_maps(k):
    result = []
    for perm in itertools.permutations(range(k)):
        masks = []
        for mask in range(1 << k):
            masks.append(sum(1 << perm[i] for i in range(k) if mask >> i & 1))
        result.append((perm, masks))
    return result

def canonical(masks, mappings):
    candidates = ((tuple(sorted(mapping[m] for m in masks)), perm)
                  for perm, mapping in mappings)
    return min(candidates)

def make_seed(points):
    k = len(points)
    lines = [l for l in range(13) if any(INC(p, l) for p in points)]
    n = k + len(lines)
    gates = []
    def gate(a, b, op):
        assert a != b
        wire = n + len(gates)
        assert 0 <= a < wire and 0 <= b < wire
        gates.append([a, b, op])
        return wire
    terms = []
    for pi, p in enumerate(points):
        neighbors = [k + j for j, l in enumerate(lines) if INC(p, l)]
        assert len(neighbors) == 4
        out = neighbors[0]
        for line in neighbors[1:]:
            out = gate(out, line, 1)
        terms.append(gate(pi, out, 0))
    out = terms[0]
    for term in terms[1:]:
        out = gate(out, term, 1)
    assert len(gates) == 5 * k - 1
    return dict(input_count=n, original_points=list(points), original_lines=lines,
                input_to_global=list(points) + [13 + l for l in lines],
                gates=gates, output=out)

def critical_certificate(seed):
    points, lines = seed['original_points'], seed['original_lines']
    k, n = len(points), seed['input_count']
    edges = [(pi, lj) for pi, p in enumerate(points) for lj, l in enumerate(lines) if INC(p, l)]
    ones = [(1 << pi) | (1 << (k + lj)) for pi, lj in edges]
    zeros = set()
    for chosen in range(1 << k):
        zero_lines = [lj for lj, l in enumerate(lines)
                      if not any(chosen >> pi & 1 and INC(p, l) for pi, p in enumerate(points))]
        zero_points = [pi for pi, p in enumerate(points)
                       if not any(INC(p, lines[lj]) for lj in zero_lines)]
        zeros.add(sum(1 << pi for pi in zero_points) + sum(1 << (k + lj) for lj in zero_lines))
    zeros = sorted(zeros)
    tests = ones + zeros
    truth = [sum(((mask >> i) & 1) << ti for ti, mask in enumerate(tests)) for i in range(n)]
    values = truth[:]
    for a, b, op in seed['gates']:
        values.append(values[a] | values[b] if op else values[a] & values[b])
    assert values[seed['output']] == (1 << len(ones)) - 1
    # Direct all-input evaluation is also cheap for these 2--5-point targets.
    # Verify critical closure coverage without depending on the circuit seed.
    for assignment in range(1 << n):
        expected = any((assignment >> pi & 1) and (assignment >> (k + lj) & 1)
                       for pi, lj in edges)
        if expected:
            assert any(assignment & mask == mask for mask in ones)
        else:
            assert any(assignment & mask == assignment for mask in zeros)
    return dict(
        input_count=n, edges_local=edges,
        edges_global=[[points[pi], lines[lj]] for pi, lj in edges],
        minones=ones, maxzeros=zeros,
        input_truth_hex=[hex(x) for x in truth],
        expected_truth_hex=hex((1 << len(ones)) - 1),
        critical_count=len(tests),
        complete_assignment_count=1 << n,
    )

started = time.monotonic()
catalogue = []
for k in range(2, 6):
    mappings = perm_maps(k)
    groups = {}
    for points in itertools.combinations(range(13), k):
        masks = [sum(1 << i for i, p in enumerate(points) if INC(p, l)) for l in range(13)]
        key, permutation = canonical(masks, mappings)
        group = groups.setdefault(key, dict(representative=points, subsets=[]))
        group['subsets'].append(points)
    for index, (signature, group) in enumerate(sorted(groups.items()), start=1):
        points = group['representative']
        name = f'k{k}-type{index}'
        seed = make_seed(points)
        certificate = critical_certificate(seed)
        degree_histogram = dict(sorted(collections.Counter(mask.bit_count() for mask in signature).items()))
        record = dict(
            name=name, k=k, representative=list(points), subset_count=len(group['subsets']),
            canonical_line_masks=list(signature), line_degree_histogram=degree_histogram,
            used_line_count=len(seed['original_lines']), input_count=seed['input_count'],
            star_gate_count=len(seed['gates']), critical_count=certificate['critical_count'],
            minones_count=len(certificate['minones']), maxzeros_count=len(certificate['maxzeros']),
            subsets=group['subsets'],
        )
        (BASE / f'{name}-seed.json').write_text(json.dumps(seed, indent=2) + '\n')
        (BASE / f'{name}-critical.json').write_text(json.dumps(certificate, indent=2) + '\n')
        catalogue.append(record)
summary = dict(
    equivalence='Exact local incidence isomorphism, canonicalizing point permutations and arbitrary line permutations; no ambient automorphism assertion needed.',
    classes=catalogue,
    total_subsets=sum(c['subset_count'] for c in catalogue),
    seconds=time.monotonic() - started,
)
(BASE / 'catalogue.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({**summary, 'classes': [{k: v for k, v in c.items() if k != 'subsets'} for c in catalogue]}, indent=2))
