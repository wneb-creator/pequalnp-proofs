import json
from pathlib import Path

BASE = Path(__file__).parent
core_gates = [[0, 2, 0], [4, 5, 1], [0, 1, 1], [1, 6, 1],
              [7, 8, 0], [3, 6, 1], [9, 10, 0]]
core_output = 11
for j, (a, b, op) in enumerate(core_gates):
    assert op in (0, 1) and a != b and 0 <= a < 5 + j and 0 <= b < 5 + j

def evaluate(mask):
    wires = [bool(mask >> i & 1) for i in range(5)]
    for a, b, op in core_gates:
        wires.append((wires[a] and wires[b]) if op == 0 else (wires[a] or wires[b]))
    return wires

for mask in range(32):
    p, q, a, b, c = [bool(mask >> i & 1) for i in range(5)]
    assert evaluate(mask)[core_output] == ((p and (a or c)) or (q and (b or c)))
assert evaluate(1 << 1)[9]
flags = []
for p, l in [(0, 2), (0, 4), (1, 3), (1, 4)]:
    pv, lv = evaluate(1 << p), evaluate(1 << l)
    v = [i == l for i in range(5)]
    w = [i == p for i in range(5)]
    for a, b, op in core_gates:
        if op == 0:
            v.append((pv[a] and v[b]) or (v[a] and pv[b]))
            w.append((lv[a] and w[b]) or (w[a] and lv[b]))
        else:
            v.append(v[a] or v[b])
            w.append(w[a] or w[b])
    flags.append(dict(point=p, line_group=l, v=v[core_output], w=w[core_output]))
assert {(f['point'], f['line_group']) for f in flags if not f['v'] and not f['w']} == {(0, 2)}

gates = []
def add(a, b, op):
    assert a != b and 0 <= a < 26 + len(gates) and 0 <= b < 26 + len(gates)
    gates.append([a, b, op])
    return 25 + len(gates)

def group(lines):
    out = 13 + lines[0]
    for line in lines[1:]:
        out = add(out, 13 + line, 1)
    return out

refs = [0, 1, group([4, 10, 12]), group([1, 5, 11]), 13]
for a, b, op in core_gates:
    refs.append(add(refs[a], refs[b], op))
assert len(gates) == 11
result = dict(selected_points=[0, 1], gates=gates, output=refs[core_output],
              p=0, l=4, target_cost=9, construction='seven_gate_compressed_unsafe_and_seed',
              core_input_order=['p', 'q', 'A', 'B', 'c'], core_gates=core_gates,
              core_input_mapping=refs[:5], core_full_truth_verified=32,
              core_derivative_flags=flags, singleton_q_true_at_core_and_wire=9)
(BASE / 'unsafe-core7-local11.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(core_truth_assignments=32, core_derivative_flags=flags,
                     local_gate_count=len(gates), local_target=9,
                     singleton_q_true_at_core_and_wire=9), indent=2))
