# Local incidence types and independent validators

These files are deterministic fixtures and checks, not an additional search
batch and not evidence of a 64-gate double-reread circuit.

`classify.py` examines all 2366 subsets of 2--5 points. A type is the multiset of
the thirteen line-neighborhood masks, canonicalized over all permutations of
the selected points. Thus the classification is exact for local incidence
graphs; no claim about extension to ambient plane automorphisms is needed.

| Type | Representative points | Subsets | Compact inputs | Star gates | Critical tests |
| --- | --- | ---: | ---: | ---: | ---: |
| k2-type1 | 0,1 | 78 | 9 | 9 | 12 |
| k3-type1 | 0,1,2 | 234 | 12 | 14 | 20 |
| k3-type2 | 0,1,3 | 52 | 13 | 14 | 20 |
| k4-type1 | 0,1,2,5 | 234 | 14 | 19 | 32 |
| k4-type2 | 0,1,2,3 | 468 | 15 | 19 | 32 |
| k4-type3 | 0,1,3,9 | 13 | 17 | 19 | 32 |
| k5-type1 | 0,1,2,3,6 | 468 | 16 | 24 | 50 |
| k5-type2 | 0,1,2,3,4 | 702 | 17 | 24 | 52 |
| k5-type3 | 0,1,2,3,9 | 117 | 18 | 24 | 51 |

The two 3-point types are noncollinear and collinear. The 4-point types are an
arc, one collinear triple, and a complete line. The 5-point types have one
triple, two triples, and a complete line plus an external point.

`*-seed.json` uses compact inputs: point variables first, then its used line
variables. `input_to_global` maps these to the original 26 inputs. Its gates
are `[a,b,op]`, with op 0 AND and op 1 OR. `*-critical.json` gives all minimal
true pairs and maximal false closures. The closure coverage was checked on
every compact Boolean assignment, 651776 assignments across all nine types.
The ordinary seed outputs were evaluated on all their critical assignments.

`compress_twins.py` additionally groups lines having identical neighborhoods
within the selected point subset. `*-compressed.json` has point variables
followed by these group variables, each interpreted as the OR of the original
lines in `line_groups`. It therefore has no one-to-one `input_to_global` map.
The fixed preprocessing costs `fixed_preprocessing_or_gates`; adding this to
`target_core_cost` gives the original local target 5k-1. These are compact search
fixtures only: no compressed search was performed here. A core double reread
for a point and group propagates to each original line in that group, since
the preprocessing uses only OR gates.

`splice_local.py` takes a globally indexed local candidate, appends the other
point stars, and checks the resulting global circuit. It checks every gate's
distinct earlier operands, the exact local function, the gate-count identity
`global = local + 5(13-k)`, all 52 positive and 704 negative global critical
assignments, and all 52 formal-derivative pairs using direct Boolean singleton
evaluations. It also verifies that precisely the local double rereads survive.
Pass `--require-counterexample` to require at most 64 gates and a double reread.

The ordinary two-point fixture splices to 64 gates with no double reread. The
Shannon fixture splices to 65 gates with three double rereads. Both checks pass;
neither is a counterexample to the posted bound.

`audit_loader.py` tests the repaired physical-duplicate loader. Its artificial
11-gate local fixture retains 37 distinct wires and has eight double rereads;
it exceeds the local budget of nine. All four packed wire quantities were
checked against independent Boolean recurrences at every wire and edge, for
296 wire-edge states. `duplicate-restart-run/summary.json` records zero search
rounds and zero attempts: this is an import audit only.

`expand_core_calibration.py` independently checks the six-gate positive control
from `local/core5/calibrate.stdout` on all 32 core assignments and all four
derivative classes, then expands its grouped inputs at points 0 and 1. Its
ten-gate local circuit splices to `calibration-core6-global65.json`, containing
14 AND and 51 OR gates. This second 65-gate seed passes all 756 global critical
tests and all 52 derivative checks; its double rereads are edges (0,4), (0,10),
and (0,12). It is also above the posted 64-gate bound.
`certify_antichains.py` emits all 91 wires' inclusion-minimal conjunctions in
both natural-bitmask and input-list formats, together with the point-0/line-4
singleton values and both derivative arrays. The final conjunction family is
exactly the 52 incidence pairs. This is finite certificate data for a separate
Lean formalization, not itself a Lean check.

`expand_cnf_seed.py` checks a different nine-gate compressed conjunction-of-
clauses circuit on all 32 core assignments and all four derivative classes.
It expands to `cnf-core9-local13.json`, then `cnf-core9-global68.json`. The latter
passes all 756 global critical tests and all 52 derivative checks, with double
rereads at the six private edges of points 0 and 1. This is a 68-gate search
seed, not a result at the posted bound. These JSON netlists are ordinary Boolean
circuits; no SAT CNF/DIMACS encoding is included.

`expand_unsafe_seed.py` checks a seven-gate compressed circuit whose AND wire 9
is true on singleton q. It expands to `unsafe-core7-local11.json` and then
`unsafe-core7-global66.json`, with 14 AND and 52 OR gates. All 32 core assignments,
four core derivative classes, 756 global critical tests, and 52 global derivative
checks pass. Its three double rereads are (0,4), (0,10), and (0,12). This is an
above-bound fixture, and no extra search run from it is included here.

Complete stdout and stderr for all scripts are retained alongside their JSON
outputs. The parent directory's bounded search totals exclude these fixtures,
classifications, and validator runs.
