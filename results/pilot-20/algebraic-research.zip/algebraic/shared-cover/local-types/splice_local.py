import argparse
import json
from pathlib import Path

parser = argparse.ArgumentParser(description='Independently splice and validate a local incidence circuit.')
parser.add_argument('--input', required=True)
parser.add_argument('--output', required=True)
parser.add_argument('--require-counterexample', action='store_true')
args = parser.parse_args()
data = json.loads(Path(args.input).read_text())

INC = lambda p, l: (p - l) % 13 in (0, 1, 3, 9)
selected = tuple(data['selected_points'])
assert selected and len(set(selected)) == len(selected)
assert all(type(p) is int and 0 <= p < 13 for p in selected)
selected_set = set(selected)
local_gates = [list(gate) for gate in data['gates']]
local_output = data['output']

def legal(gates, output):
    assert type(output) is int and 0 <= output < 26 + len(gates)
    for j, gate in enumerate(gates):
        assert len(gate) == 3 and all(type(v) is int for v in gate)
        a, b, op = gate
        assert op in (0, 1) and a != b
        assert 0 <= a < 26 + j and 0 <= b < 26 + j

def critical(points):
    point_set = set(points)
    positive_edges = [(p, l) for p in points for l in range(13) if INC(p, l)]
    minones = [(1 << p) | (1 << (13 + l)) for p, l in positive_edges]
    maxzeros = set()
    for bits in range(1 << len(points)):
        present_points = [p for j, p in enumerate(points) if bits >> j & 1]
        available_lines = [l for l in range(13) if all(not INC(p, l) for p in present_points)]
        closed_points = [p for p in range(13)
                         if p not in point_set or all(not INC(p, l) for l in available_lines)]
        maxzeros.add(sum(1 << p for p in closed_points)
                     | sum(1 << (13 + l) for l in available_lines))
    return positive_edges, minones, sorted(maxzeros)

def evaluate(gates, assignment):
    wires = [bool(assignment >> i & 1) for i in range(26)]
    for a, b, op in gates:
        wires.append((wires[a] and wires[b]) if op == 0 else (wires[a] or wires[b]))
    return wires

def validate(gates, output, points):
    edges, minones, maxzeros = critical(points)
    wrong_positive = [m for m in minones if not evaluate(gates, m)[output]]
    wrong_negative = [m for m in maxzeros if evaluate(gates, m)[output]]
    assert not wrong_positive and not wrong_negative
    return dict(positive_count=len(minones), negative_count=len(maxzeros),
                wrong_positive=wrong_positive, wrong_negative=wrong_negative), edges

def derivatives(gates, output, edges):
    records = []
    for p, l in edges:
        point_values = evaluate(gates, 1 << p)
        line_values = evaluate(gates, 1 << (13 + l))
        v = [i == 13 + l for i in range(26)]
        w = [i == p for i in range(26)]
        for a, b, op in gates:
            if op == 0:
                v.append((point_values[a] and v[b]) or (v[a] and point_values[b]))
                w.append((line_values[a] and w[b]) or (w[a] and line_values[b]))
            else:
                v.append(v[a] or v[b])
                w.append(w[a] or w[b])
        assert not point_values[output] and not line_values[output]
        records.append(dict(p=p, l=l, v_output=v[output], w_output=w[output],
                            double_reread=not v[output] and not w[output],
                            point_values=point_values, line_values=line_values, v=v, w=w))
    return records

legal(local_gates, local_output)
local_validation, local_edges = validate(local_gates, local_output, selected)
local_derivatives = derivatives(local_gates, local_output, local_edges)
local_bad = {(r['p'], r['l']) for r in local_derivatives if r['double_reread']}

gates = local_gates[:]
def add(a, b, op):
    assert a != b
    output = 26 + len(gates)
    gates.append([a, b, op])
    return output

terms = [local_output]
for p in range(13):
    if p in selected_set:
        continue
    neighbors = [13 + l for l in range(13) if INC(p, l)]
    term = neighbors[0]
    for line in neighbors[1:]:
        term = add(term, line, 1)
    terms.append(add(p, term, 0))
output = terms[0]
for term in terms[1:]:
    output = add(output, term, 1)

assert len(gates) == len(local_gates) + 5 * (13 - len(selected))
assert (len(gates) <= 64) == (len(local_gates) <= 5 * len(selected) - 1)
legal(gates, output)
validation, global_edges = validate(gates, output, tuple(range(13)))
assert validation['positive_count'] == 52 and validation['negative_count'] == 704
global_derivatives = derivatives(gates, output, global_edges)
global_bad = {(r['p'], r['l']) for r in global_derivatives if r['double_reread']}
assert global_bad == local_bad
for record in global_derivatives:
    if record['p'] not in selected_set:
        assert record['v_output'] and record['w_output']
valid_counterexample = len(gates) <= 64 and bool(global_bad)
if args.require_counterexample:
    assert valid_counterexample

result = dict(
    source=str(Path(args.input)), selected_points=list(range(13)),
    local_selected_points=selected, gates=gates, output=output,
    local_gate_count=len(local_gates), global_gate_count=len(gates),
    local_threshold=5 * len(selected) - 1, global_threshold=64,
    local_validation=local_validation, validation=validation,
    double_edges=sorted(global_bad), valid_counterexample=valid_counterexample,
    derivative_flags=[{k: r[k] for k in ('p', 'l', 'v_output', 'w_output', 'double_reread')}
                      for r in global_derivatives],
)
if global_bad:
    chosen = next(r for r in global_derivatives if r['double_reread'])
    result.update({k: chosen[k] for k in ('p', 'l', 'point_values', 'line_values', 'v', 'w')})
Path(args.output).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('source', 'local_selected_points', 'local_gate_count',
    'global_gate_count', 'local_threshold', 'validation', 'double_edges', 'valid_counterexample')},
    indent=2))
