import json
from pathlib import Path

BASE = Path(__file__).parent
source = Path('/tmp/oec/pequalnp-pilot-20/algebraic/local/core5/calibrate.stdout')
lines = [json.loads(line) for line in source.read_text().splitlines() if line.strip()]
core = lines[0]
assert lines[-1]['gate_limit'] == 6 and lines[-1]['found'] and not lines[-1]['complete']
cg = core['candidate_gates']
co = core['output']
assert len(cg) == 6 and co == 10
for j, (a, b, op) in enumerate(cg):
    assert op in (0, 1) and 0 <= a < b < 5 + j

def evaluate(assignment):
    wires = [bool(assignment >> i & 1) for i in range(5)]
    for a, b, op in cg:
        wires.append(wires[a] | wires[b] if op else wires[a] & wires[b])
    return wires

truth = []
for assignment in range(32):
    p, q, a, b, c = [bool(assignment >> i & 1) for i in range(5)]
    expected = (p and (a or c)) or (q and (b or c))
    observed = evaluate(assignment)[co]
    assert observed == expected
    truth.append(observed)

edges = [(0, 2), (0, 4), (1, 3), (1, 4)]
flags = []
for p, l in edges:
    pv, lv = evaluate(1 << p), evaluate(1 << l)
    v = [i == l for i in range(5)]
    w = [i == p for i in range(5)]
    for a, b, op in cg:
        if op == 0:
            v.append((pv[a] and v[b]) or (v[a] and pv[b]))
            w.append((lv[a] and w[b]) or (w[a] and lv[b]))
        else:
            v.append(v[a] or v[b])
            w.append(w[a] or w[b])
    flags.append(dict(point=p, line_group=l, v=v[co], w=w[co]))
bad_mask = sum(1 << j for j, flag in enumerate(flags) if not flag['v'] and not flag['w'])
assert bad_mask == core['bad_classes'] == 1

inc = lambda p, l: (p - l) % 13 in (0, 1, 3, 9)
p_lines = {l for l in range(13) if inc(0, l)}
q_lines = {l for l in range(13) if inc(1, l)}
shared = sorted(p_lines & q_lines)
a_lines, b_lines = sorted(p_lines - q_lines), sorted(q_lines - p_lines)
assert shared == [0] and a_lines == [4, 10, 12] and b_lines == [1, 5, 11]
gates = []
def add(a, b, op):
    assert a != b and 0 <= a < 26 + len(gates) and 0 <= b < 26 + len(gates)
    gates.append([a, b, op])
    return 25 + len(gates)
def group(original_lines):
    result = 13 + original_lines[0]
    for l in original_lines[1:]:
        result = add(result, 13 + l, 1)
    return result
refs = [0, 1, group(a_lines), group(b_lines), 13 + shared[0]]
for a, b, op in cg:
    refs.append(add(refs[a], refs[b], op))
assert len(gates) == 10
result = dict(
    selected_points=[0, 1], gates=gates, output=refs[co], p=0, l=4,
    target_cost=9, construction='six_gate_compressed_core_positive_calibration',
    source=str(source), core_gates=cg, core_input_mapping=refs[:5],
    core_full_truth_verified=32, core_derivative_flags=flags,
    local_and_gates=sum(g[2] == 0 for g in gates),
    local_or_gates=sum(g[2] == 1 for g in gates),
)
(BASE / 'calibration-core6-local10.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('selected_points', 'target_cost',
    'construction', 'core_full_truth_verified', 'core_derivative_flags',
    'local_and_gates', 'local_or_gates')}, indent=2))
