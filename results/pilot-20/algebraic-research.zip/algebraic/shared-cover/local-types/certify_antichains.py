import json
from pathlib import Path

BASE = Path(__file__).parent
data = json.loads((BASE / 'calibration-core6-global65.json').read_text())
assert data['p'] == 0 and data['l'] == 4
families = [[1 << i] for i in range(26)]

def minimal(terms):
    kept = []
    for term in sorted(set(terms), key=lambda x: (x.bit_count(), x)):
        if not any(old & term == old for old in kept):
            kept.append(term)
    return sorted(kept)

for a, b, op in data['gates']:
    terms = families[a] + families[b] if op else [x | y for x in families[a] for y in families[b]]
    families.append(minimal(terms))
expected = sorted((1 << p) | (1 << (13 + l)) for p in range(13) for l in range(13)
                  if (p - l) % 13 in (0, 1, 3, 9))
assert len(families) == 91 and families[data['output']] == expected
for i, terms in enumerate(families):
    assert any(term & (1 << 0) == term for term in terms) == data['point_values'][i]
    assert any(term & (1 << (13 + 4)) == term for term in terms) == data['line_values'][i]
assert not data['v'][data['output']] and not data['w'][data['output']]
data['wire_minterm_masks'] = families
data['wire_minterm_inputs'] = [
    [[i for i in range(26) if term >> i & 1] for term in terms] for terms in families]
data['antichain_format'] = 'Natural bitmask per conjunction; each wire family is OR of its inclusion-minimal conjunctions.'
data['and_count'] = sum(op == 0 for a, b, op in data['gates'])
data['or_count'] = sum(op == 1 for a, b, op in data['gates'])
output = BASE / 'calibration-core6-certificates.json'
output.write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps(dict(certificate=str(output), wire_count=len(families),
    output_terms=len(expected), p=data['p'], l=data['l'],
    and_count=data['and_count'], or_count=data['or_count'],
    max_wire_terms=max(map(len, families))), indent=2))
