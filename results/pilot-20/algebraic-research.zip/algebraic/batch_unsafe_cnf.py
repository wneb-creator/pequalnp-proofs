import json,subprocess,sys
from pathlib import Path
base=Path('/tmp/oec/pequalnp-pilot-20/algebraic');root=base/'unsafe-cnf'
seed=base/'shared-cover/local-types/cnf-core9-global68.json'
summaries=[]
for i,(preserve,mode,maxgates,freq) in enumerate([(True,'full',80,0.1),(False,'full',80,0.25),(True,'singletons',100,0.1),(False,'truth',100,0.2)]):
 name=f'run-{i+1}';out=root/name
 cmd=[sys.executable,str(base/'rewrite_unsafe.py'),'--input',str(seed),'--output-dir',str(out),'--seconds','45','--beam','72','--seed',str(7001+i*67),'--max-nodes','1200000','--semantic-key',mode,'--max-gates',str(maxgates),'--cse-frequency',str(freq),'--insertions','0.25']
 if preserve:cmd.append('--require-unsafe')
 with (root/f'{name}.stdout').open('w') as stdout,(root/f'{name}.stderr').open('w') as stderr:
  result=subprocess.run(cmd,stdout=stdout,stderr=stderr)
 if result.returncode:
  print(json.dumps({'name':name,'exit':result.returncode}),flush=True);raise SystemExit(result.returncode)
 summary=json.loads((out/'summary.json').read_text());summary.update(name=name,target=64,require_unsafe_and=preserve,heuristic_scope='Preserve a reachable AND true on a maximal independent input' if preserve else 'No unsafe-AND preservation constraint');summaries.append(summary)
 (root/'batch-summary.json').write_text(json.dumps(summaries,indent=2))
 print(json.dumps({k:summary[k] for k in ['name','require_unsafe_and','best_bad','attempts','seen','seconds']}),flush=True)
 if summary['best_bad']<=64:
  print('CANDIDATE_FOUND',name,flush=True);break
