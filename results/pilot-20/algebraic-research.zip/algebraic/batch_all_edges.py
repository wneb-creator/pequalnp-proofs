import json
import subprocess
from pathlib import Path
base = Path('/tmp/oec/pequalnp-pilot-20/algebraic')
results = []
for seed, slack in [(101,3), (211,4), (307,6), (401,8), (503,10), (601,12)]:
    dest = base / f'all-edges-{seed}'
    with (base/f'all-edges-{seed}.stdout').open('w') as out, (base/f'all-edges-{seed}.stderr').open('w') as err:
        run = subprocess.run(['python3', str(base/'rewrite_all_edges.py'), '--input', '/tmp/oec/pequalnp-pilot-20/search/shannon65-full.json', '--output-dir', str(dest), '--seconds', '35', '--beam', '100', '--slack', str(slack), '--seed', str(seed), '--max-nodes', '1500000'], stdout=out, stderr=err)
    if run.returncode != 0:
        raise SystemExit(run.returncode)
    result = json.loads((dest/'summary.json').read_text())
    result['seed'] = seed
    result['slack'] = slack
    results.append(result)
    print(json.dumps(result), flush=True)
    if result['best_bad'] <= 64:
        break
(base/'batch-all-edges-summary.json').write_text(json.dumps(results, indent=2))
