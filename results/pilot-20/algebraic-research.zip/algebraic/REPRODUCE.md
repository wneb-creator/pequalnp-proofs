# Reproducing the bounded searches

The engines used by the reported main batches are retained, with the explicitly
versioned fixes described in BUNDLE_README.md. The invalid early diagnostic
smoke predates the input-order fix and is retained only as logs, not as a
reproducible result. Batch drivers retain the
original scratch paths as provenance. The original65-gate global Shannon input
is bundled at `inputs/shannon65-full.json`; its original path was
`/tmp/oec/pequalnp-pilot-20/search/shannon65-full.json`. Local, expanded-DNF,
unsafe-CNF, and later boundary seeds are included beside their batch sources or
under `shared-cover/local-types/`.

Each rewrite engine accepts `--input`, `--output-dir`, `--seconds`, `--beam`,
`--seed`, and its source-specific optional flags. To reproduce a reported main-batch run elsewhere,
invoke its exact archived engine using the arguments listed in the archived
batch driver or `one-off-invocations.json`, replacing only the input/output filesystem locations. Source
hashes and exact per-run summary paths are recorded in report.json; the final
manifest hashes every included artifact. Wall-clock bounded beam exploration
can stop at a different round on different hardware, so equal seeds do not
promise identical final counters.

The exact compressed-core enumerators require a C++17 compiler. They were built
with `c++ -O3 -std=c++17 SOURCE.cpp -o PROGRAM`. `enumerate.cpp` exhausts through
five core gates; `census6.cpp` exhausts through six. `calibrate.cpp` stops after
its first six-gate positive boundary witness and is intentionally nonexhaustive.
Compiler version output and complete build/run logs are included under
`local/core5/`.

The pure Python independent validators and splice tools under
`shared-cover/local-types/` document their command-line usage in source. They
validate Boolean semantics and formal derivative recurrences independently of
the search engines. No external SAT solver, CNF, network access, or credential is
needed for this bundle.
