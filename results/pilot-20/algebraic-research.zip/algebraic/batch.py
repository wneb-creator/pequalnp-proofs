import json
import subprocess
from pathlib import Path
base = Path('/tmp/oec/pequalnp-pilot-20/algebraic')
results = []
for seed in [11, 23, 37, 41, 59, 71]:
    dest = base / f'run-{seed}'
    with (base/f'run-{seed}.stdout').open('w') as out, (base/f'run-{seed}.stderr').open('w') as err:
        run = subprocess.run(['python3', str(base/'rewrite.py'), '--input', '/tmp/oec/pequalnp-pilot-20/search/shannon65-full.json', '--output-dir', str(dest), '--seconds', '35', '--beam', '80', '--slack', '3', '--seed', str(seed), '--max-nodes', '1500000'], stdout=out, stderr=err)
    if run.returncode != 0:
        raise SystemExit(run.returncode)
    result = json.loads((dest/'summary.json').read_text())
    result['seed'] = seed
    results.append(result)
    print(json.dumps(result), flush=True)
    if result['best_bad'] <= 64:
        break
(base/'batch-summary.json').write_text(json.dumps(results, indent=2))
