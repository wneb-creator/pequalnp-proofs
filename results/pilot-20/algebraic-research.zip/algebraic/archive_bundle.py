from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import datetime,hashlib,json
root=Path(__file__).parent
report=json.loads((root/'report.json').read_text())
assert report['all_main_batches_complete'], 'Refusing final archive while a main batch is incomplete.'
allowed={'.py','.cpp','.json','.md','.stdout','.stderr','.txt'}
for p in root.rglob('*'):
 assert not p.is_symlink(), f'Symlink must be reviewed: {p.name}'
 assert p.suffix.lower() not in {'.cnf','.dimacs'}, f'CNF must not be archived: {p.name}'
files=sorted(p for p in root.rglob('*') if p.is_file() and p.suffix in allowed and p.name!='MANIFEST.json')
entries=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
manifest={'format':1,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive_prefix':'algebraic/','scope':report['archive_scope'],'all_main_batches_complete':True,'report_sha256':hashlib.sha256((root/'report.json').read_bytes()).hexdigest(),'files':entries}
manifest_bytes=(json.dumps(manifest,indent=2)+'\n').encode()
(root/'MANIFEST.json').write_bytes(manifest_bytes)
external_manifest=root.parent/'algebraic-research.manifest.json';external_manifest.write_bytes(manifest_bytes)
dest=root.parent/'algebraic-research-final.zip'
with ZipFile(dest,'w',compression=ZIP_DEFLATED) as z:
 for p in files+[root/'MANIFEST.json']:
  z.write(p,'algebraic/'+str(p.relative_to(root)))
meta={'archive':str(dest),'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'manifest':str(external_manifest),'manifest_sha256':hashlib.sha256(manifest_bytes).hexdigest(),'manifest_files':len(entries),'archive_files':len(entries)+1,'source_data_log_bytes':sum(x['bytes'] for x in entries),'main_completed_runs':report['total_main_completed_runs'],'main_beam_attempts':report['total_main_beam_attempts'],'result':report['result']}
(root.parent/'algebraic-research.metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta))
