from pathlib import Path
import datetime,hashlib,json
root=Path(__file__).parent
old=root/'report.json';historical=root/'historical-report.json'
if not historical.exists():historical.write_text(old.read_text())
def group(name,path,expected,scope,single=False):
 p=root/path
 rows=([json.loads(p.read_text())] if single else json.loads(p.read_text())) if p.exists() else []
 return {'name':name,'scope':scope,'summary_file':path,'expected_runs':expected,'completed_runs':len(rows),'complete_batch':len(rows)==expected,'attempts':sum(x['attempts'] for x in rows),'summed_states_not_cross_run_deduplicated':sum(x['seen'] for x in rows),'sum_run_seconds_not_wall_time':sum(x['seconds'] for x in rows),'best_global_double_gate_count':min(x['best_bad'] for x in rows) if scope=='global26-input target' and rows else None,'runs':[{'name':x.get('name',str(x.get('seed',i))),'target':x.get('target',64),'best_bad':x['best_bad'],'attempts':x['attempts'],'seen':x['seen'],'seconds':x['seconds'],'nodes':x['nodes'],'status':'successful bounded run; not exhaustive','require_unsafe_and':x.get('require_unsafe_and',False),'heuristic_scope':x.get('heuristic_scope')} for i,x in enumerate(rows)]}
groups=[
 group('fixed target incidence','batch-summary.json',6,'global26-input target'),
 group('all52 incidences','batch-all-edges-summary.json',6,'global26-input target'),
 group('semantic CSE','batch-semantic-summary.json',6,'global26-input target'),
 group('expanded DNF','expanded/batch-summary.json',6,'global26-input target'),
 group('local-Shannon65 seed','local-shannon-run/summary.json',1,'global26-input target',True),
 group('global minimal-cone CSE','local-shannon-global-cse/summary.json',1,'global26-input target',True),
 group('nine local types ordinary and Shannon','local/types/batch-summary.json',18,'selected-point local subfunctions'),
 group('nine local types new core and DNF','local/extended/batch-summary.json',18,'selected-point local subfunctions'),
 group('unsafe-AND CNF seed','unsafe-cnf/batch-summary.json',4,'global26-input target'),
]
complete=all(g['complete_batch'] for g in groups)
meeting=[(g['name'],x['name']) for g in groups for x in g['runs'] if x['best_bad']<=x['target']]
core5=json.loads((root/'local/core5/enumerate.stdout').read_text().splitlines()[-1])
core6=json.loads((root/'local/core5/census6.stdout').read_text().splitlines()[-1])
report={'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive_scope':'algebraic exploration and independent local certificates; no Lean proof of L-meta-1482','all_main_batches_complete':complete,'counterexample_at_target_budget_found':bool(meeting),'meeting_budget_runs':meeting,'result':'No at-most64-gate global counterexample found; verified boundary constructions use65 gates.' if not meeting else 'Candidate found; independent verification required.','groups':groups,'total_main_beam_attempts':sum(g['attempts'] for g in groups),'total_main_completed_runs':sum(g['completed_runs'] for g in groups),'exact_compressed_core':{'scope':'fiveinputs[p,q,A,B,c] with fixed4OR preprocessing for the two-row target; not all uncompressed local circuits','gate5':core5,'gate6':core6,'unique_netlists_through6_in_complete_census':sum(x['circuits'] for x in core6['depths']),'interpretation':'No≤5-core-gate double reread;32 ordered six-core-gate boundary netlists. Six-core-gate found:true means10 local/65 global gates after expansion, not a target-budget counterexample.'},'classification':{'point_subsets':2366,'local_incidence_types':9,'exhaustive':'point-subset incidence classification only, not circuit search'},'one_off_invocations_file':'one-off-invocations.json', 'smokes_and_controls':'Excluded from main beam totals: invalid earlytest, all valid smoke tests, exact-core censuses/calibration, deterministic splices/loader tests. All retained with their own logs.','termination':'Each listed beam run exited successfully with a summary after a time, node, or beam bound. Completed bounded runs establish no lower bound. The six-gate calibrate.cpp positive control intentionally stops after its first boundary witness; its complete:false does not denote a failure.','interrupted_attempts':[json.loads((root/'local/extended/transition-interruption.json').read_text())], 'historical_report':'historical-report.json covers only the first18 global runs and is retained for traceability.','source_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file() and p.suffix in {'.py','.cpp'}}}
old.write_text(json.dumps(report,indent=2))
print(json.dumps({'all_main_batches_complete':complete,'completed_runs':report['total_main_completed_runs'],'main_beam_attempts':report['total_main_beam_attempts'],'counterexample_at_target_budget_found':bool(meeting)}))
