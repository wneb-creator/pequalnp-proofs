import json,subprocess,sys
from pathlib import Path
base=Path('/tmp/oec/pequalnp-pilot-20/algebraic')
root=base/'local'/'extended'
summaries=[]
seeds=sorted(root.glob('*-core6.json'))+sorted(root.glob('*-dnf.json'))
for i,seed in enumerate(seeds):
 data=json.loads(seed.read_text());name=seed.stem;out=root/name;k=len(data['selected_points'])
 mode='full' if data['construction']=='core6' else 'singletons'
 cmd=[sys.executable,str(base/'rewrite_local_v2.py'),'--input',str(seed),'--output-dir',str(out),'--seconds','45','--beam','80','--seed',str(5003+i*59),'--max-nodes','1800000','--semantic-key',mode,'--max-gates',str(8*k+15),'--cse-frequency','0.25','--insertions','0.6']
 with (root/f'{name}.stdout').open('w') as stdout,(root/f'{name}.stderr').open('w') as stderr:
  result=subprocess.run(cmd,stdout=stdout,stderr=stderr)
 if result.returncode:
  print(json.dumps({'name':name,'exit':result.returncode}),flush=True)
  raise SystemExit(result.returncode)
 summary=json.loads((out/'summary.json').read_text());summary.update(name=name,points=data['selected_points'],target=data['target_cost']);summaries.append(summary)
 (root/'batch-summary.json').write_text(json.dumps(summaries,indent=2))
 print(json.dumps({k:summary[k] for k in ['name','target','best_bad','attempts','seen','seconds']}),flush=True)
 if summary['best_bad']<=data['target_cost']:
  print('CANDIDATE_FOUND',name,flush=True)
  break
