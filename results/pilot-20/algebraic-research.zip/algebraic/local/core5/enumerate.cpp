#include <array>
#include <chrono>
#include <cstdint>
#include <iostream>

struct Value { std::uint32_t truth; unsigned cp, cl, v, w; };
struct Gate { unsigned a, b, op; };
std::array<Value,10> wires;
std::array<Gate,5> gates;
std::array<std::uint64_t,6> visited{}, correct{}, bad{};
std::uint32_t target;
bool found = false;

void visit(unsigned depth) {
  const unsigned count = 5+depth;
  for (unsigned a=0;a<count;a++) for (unsigned b=a+1;b<count;b++) {
    const Value x=wires[a], y=wires[b];
    for (unsigned op=0;op<2;op++) {
      Value z;
      if (op==0) z={x.truth&y.truth,x.cp&y.cp,x.cl&y.cl,
                    (x.cp&y.v)|(x.v&y.cp),(x.cl&y.w)|(x.w&y.cl)};
      else z={x.truth|y.truth,x.cp|y.cp,x.cl|y.cl,x.v|y.v,x.w|y.w};
      wires[count]=z; gates[depth]={a,b,op}; ++visited[depth+1];
      if (z.truth==target) {
        ++correct[depth+1];
        const unsigned mask=15u & ~(z.v|z.w);
        if(mask) {
          ++bad[depth+1]; found=true;
          std::cout << "{\"candidate_gates\":[";
          for(unsigned j=0;j<=depth;j++) {
            if(j) std::cout << ',';
            std::cout << '[' << gates[j].a << ',' << gates[j].b << ',' << gates[j].op << ']';
          }
          std::cout << "],\"output\":" << count << ",\"bad_classes\":" << mask << "}\n";
          return;
        }
      }
      if(depth+1<5) visit(depth+1);
      if(found) return;
    }
  }
}
int main() {
  const auto start=std::chrono::steady_clock::now();
  const unsigned cp[5]={3,12,0,0,0};
  const unsigned cl[5]={0,0,1,4,10};
  for(unsigned i=0;i<5;i++) {
    std::uint32_t truth=0;
    for(unsigned assignment=0;assignment<32;assignment++)
      if((assignment>>i)&1u) truth|=(std::uint32_t(1)<<assignment);
    wires[i]={truth,cp[i],cl[i],cl[i],cp[i]};
  }
  target=(wires[0].truth&(wires[2].truth|wires[4].truth))|
         (wires[1].truth&(wires[3].truth|wires[4].truth));
  visit(0);
  const auto elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
  std::cout << "{\"input_order\":[\"p\",\"q\",\"A\",\"B\",\"c\"],\"edge_classes\":[[0,2],[0,4],[1,3],[1,4]],\"input_count\":5,\"gate_limit\":5,\"complete\":" << (found?"false":"true") << ",\"found\":" << (found?"true":"false") << ",\"seconds\":" << elapsed << ",\"depths\":[";
  for(unsigned d=1;d<=5;d++) {
    if(d>1) std::cout << ',';
    std::cout << "{\"depth\":" << d << ",\"circuits\":" << visited[d] << ",\"correct\":" << correct[d] << ",\"bad\":" << bad[d] << '}';
  }
  std::cout << "]}\n";
}
