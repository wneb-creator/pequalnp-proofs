import PEqualNP.Defs

namespace PEqualNP.Outside.L_meta_2962_aux

open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity PEqualNP.MetaComplexity.NestedCover
  PEqualNP.Core PEqualNP.TopForm

abbrev eqGraph : SimpleGraph (Fin 4) := SimpleGraph.fromRel fun a b =>
  (a = 0 ∧ b = 1) ∨ (a = 0 ∧ b = 2) ∨ (a = 3 ∧ b = 1)

def eqCircuit : Circuit :=
  ⟨[⟨.and, [3, 1]⟩, ⟨.or, [1, 2]⟩, ⟨.or, [0, 4]⟩,
    ⟨.and, [6, 5]⟩, ⟨.and, [0, 5]⟩, ⟨.or, [8, 4]⟩], 9⟩

lemma eq_ao : IsAO2 4 eqCircuit := by decide +kernel
lemma eq_fixed : IsLiftFixedPoint eqGraph eqCircuit := by decide +kernel
lemma eq_correct : circuitFun 4 eqCircuit = graphFun eqGraph ∅ := by
  funext x
  revert x
  decide +kernel
lemma eq_mc : maximalCores eqGraph eqCircuit = {3} := by decide +kernel
lemma eq_D : (maximalCores eqGraph eqCircuit).biUnion (gammaE eqGraph eqCircuit) =
  {s(0, 1), s(0, 2), s(1, 3)} := by decide +kernel
lemma eq_U : (maximalCores eqGraph eqCircuit).biUnion (coneSet 4 eqCircuit) =
  {0, 1, 2, 3} := by decide +kernel

lemma eq_bipartite : ∀ u v : Fin 4, eqGraph.Adj u v →
    decide (u = 0 ∨ u = 3) ≠ decide (v = 0 ∨ v = 3) := by decide +kernel
lemma eq_no4 : NoFourCycle eqGraph := by decide +kernel
lemma eq_cover : IsMinCover eqGraph ({0, 1} : Finset (Fin 4)) := by
  unfold IsMinCover SimpleGraph.IsVertexCover
  decide +kernel
lemma eq_deleted_cover : IsMinCover (eqGraph.deleteEdges
    (((maximalCores eqGraph eqCircuit).biUnion (gammaE eqGraph eqCircuit) : Finset (Sym2 (Fin 4))) :
      Set (Sym2 (Fin 4)))) ∅ := by
  rw [eq_D]
  unfold IsMinCover SimpleGraph.IsVertexCover
  decide +kernel

end PEqualNP.Outside.L_meta_2962_aux
