import itertools
import json
import resource
import subprocess
import sys
import time
from pathlib import Path
from common1342 import ROOT,N,EDGES,boundary_rows,audit

SOLVER='/tmp/oec/pequalnp-pilot-46/toolchain/lean-4.36.0-linux/bin/cadical'


class CNF:
    def __init__(self):self.n=0;self.clauses=[]
    def var(self):self.n+=1;return self.n
    def cl(self,*xs):self.clauses.append(xs)
    def conjunction(self,a,b):
        v=self.var();self.cl(-v,a);self.cl(-v,b);self.cl(v,-a,-b);return v
    def disjunction(self,xs):
        v=self.var()
        for x in xs:self.cl(-x,v)
        self.cl(-v,*xs);return v
    def selected_or(self,ss,vs):
        terms=[]
        for s,v in zip(ss,vs):
            if isinstance(v,bool):
                if v:terms.append(s)
            else:terms.append(self.conjunction(s,v))
        return self.disjunction(terms)
    def atmost(self,lits,k):
        if k>=len(lits):return
        if k<0:self.cl();return
        previous=[]
        for lit in lits:
            row=[self.var() for _ in range(k+1)]
            self.cl(-lit,row[0])
            for j,v in enumerate(previous):self.cl(-v,row[j])
            for j in range(k):
                if j<len(previous):self.cl(-previous[j],-lit,row[j+1])
            self.cl(-row[k]);previous=row
    def dump(self,p):
        with p.open('w') as f:
            f.write(f'p cnf {self.n} {len(self.clauses)}\n')
            for xs in self.clauses:f.write(' '.join(map(str,xs))+' 0\n')


def compile_macro(macro,final):
    gs=[];wires=list(range(N));known={frozenset([i]):i for i in range(N)}
    def join(indices):
        wanted=frozenset(indices)
        if wanted in known:return known[wanted]
        remaining=set(wanted);parts=[]
        while remaining:
            subset=max((s for s in known if s<=wanted and s&remaining),key=lambda s:(len(s&remaining),len(s)))
            parts.append((subset,known[subset]));remaining-=subset
        covered,wire=parts[0]
        for subset,part in parts[1:]:
            covered=covered|subset
            if covered in known:wire=known[covered]
            else:
                gs.append(('or',wire,part));wire=N+len(gs)-1;known[covered]=wire
        known[wanted]=wire
        return wire
    for i,(a,b) in enumerate(macro):
        av,bv=join(a),join(b)
        gs.append(('and',av,bv));wires.append(N+len(gs)-1)
        known[frozenset([N+i])]=wires[-1]
    out=join(final)
    return gs,out


def solve(count=6,seconds=300,units=None):
    c=CNF();selectors=[]
    for i in range(count):
        a=[c.var() for _ in range(N+i)];b=[c.var() for _ in range(N+i)]
        c.cl(*a);c.cl(*b)
        eq=c.var();c.cl(eq)
        for av,bv in zip(reversed(a),reversed(b)):
            c.cl(-eq,-av,bv);nxt=c.var()
            c.cl(-eq,av,bv,nxt);c.cl(-eq,-av,-bv,nxt)
            c.cl(-nxt,eq);c.cl(-nxt,-av,bv);c.cl(-nxt,av,-bv);eq=nxt
        selectors.append((a,b))
    final=[c.var() for _ in range(N+count)];c.cl(*final)
    ordered=selectors[1:] if units else selectors
    for (a,b),(aa,bb) in zip(ordered,ordered[1:]):
        for j in range(len(a)):
            c.cl(-a[j],*(aa[j:]+bb[j:]));c.cl(-b[j],*(aa[j:]+bb[j:]))
    if units:
        choices=[c.var() for _ in units];c.cl(*choices)
        for a,b in itertools.combinations(choices,2):c.cl(-a,-b)
        for selector,(left,right) in zip(choices,units):
            left,right=sorted([left,right],key=lambda xs:sum(1<<j for j in xs))
            for j in range(N):
                c.cl(-selector,selectors[0][0][j] if j in left else -selectors[0][0][j])
                c.cl(-selector,selectors[0][1][j] if j in right else -selectors[0][1][j])
    negative=[[] for _ in range(count)]
    for x,target in boundary_rows():
        vs=[bool(x>>i&1) for i in range(N)]
        for i,(a,b) in enumerate(selectors):
            v=c.conjunction(c.selected_or(a,vs),c.selected_or(b,vs));vs.append(v)
            if not target:negative[i].append(v)
        out=c.selected_or(final,vs);c.cl(out if target else -out)
    below=[]
    for vals in negative:
        b=c.var();below.append(b)
        for v in vals:c.cl(-b,-v)
        c.cl(b,*vals)
    c.atmost([-b for b in below],2);c.atmost(below,count-2)
    name=f'macro-{count}and-exact2junk'+('-prefix5' if units else '');cnf=ROOT/(name+'.cnf');log=ROOT/(name+'.log');c.dump(cnf)
    print('START',name,'variables',c.n,'clauses',len(c.clauses),'rows',len(boundary_rows()),flush=True)
    def limits():
        resource.setrlimit(resource.RLIMIT_AS,(768*1024**2,768*1024**2))
        resource.setrlimit(resource.RLIMIT_CPU,(seconds+5,seconds+5))
    start=time.monotonic()
    with log.open('w') as f:
        try:r=subprocess.run([SOLVER,'-t',str(seconds),str(cnf)],stdout=f,stderr=subprocess.STDOUT,preexec_fn=limits,timeout=seconds+10)
        except subprocess.TimeoutExpired:f.write('\nOUTER TIMEOUT\n');r=subprocess.CompletedProcess([],124)
    print('FINISH',name,'status',r.returncode,'seconds',round(time.monotonic()-start,3),flush=True)
    if r.returncode!=10:return
    text=log.read_text();model={int(v) for line in text.splitlines() if line.startswith('v ') for v in line[2:].split() if int(v)>0}
    pick=lambda ss:[j for j,v in enumerate(ss) if v in model]
    macro=[(pick(a),pick(b)) for a,b in selectors];last=pick(final)
    gs,out=compile_macro(macro,last);checked=audit(gs,out)
    assert not checked['false_positives'] and not checked['false_negatives']
    assert len(checked['junk_ands'])==2
    witness={'macro':macro,'final':last,'gates':gs,**checked}
    (ROOT/(name+'-witness.json')).write_text(json.dumps(witness,indent=2))
    print('FULL_TRUTH_VALID',json.dumps(witness),flush=True)


if __name__=='__main__':
    units=None
    if len(sys.argv)>3:units=[r['unit'] for r in json.loads(Path(sys.argv[3]).read_text())]
    solve(int(sys.argv[1]),int(sys.argv[2]),units)
