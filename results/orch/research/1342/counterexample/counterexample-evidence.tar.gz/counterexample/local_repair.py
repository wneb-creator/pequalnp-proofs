import itertools
import json
import resource
import subprocess
import sys
import time
from pathlib import Path
from common1342 import ROOT,N,target,boundary_rows,boundary_example,audit,effective
from macro_two_junk import CNF,SOLVER

INPUT_MASKS=[sum(bool(x>>i&1)<<x for x in range(1<<N)) for i in range(N)]

def masks(gs):
    vs=INPUT_MASKS.copy()
    for op,a,b in gs:vs.append(vs[a]&vs[b] if op=='and' else vs[a]|vs[b])
    return vs


def tiny(gs,out,name):
    wanted=sum(target(x)<<x for x in range(1<<N));vs=masks(gs);checked=0
    hits=[]
    for a in range(len(vs)):
        for b in range(a,len(vs)):
            for op in ['and','or']:
                checked+=1;v=vs[a]&vs[b] if op=='and' else vs[a]|vs[b]
                if v==wanted:hits.append((gs+[(op,a,b)],len(vs),'one-extension'))
    rewrites=0
    for i in range(len(gs)):
        for a in range(N+i):
            for b in range(a,N+i):
                for op in ['and','or']:
                    rewrites+=1;candidate=gs.copy();candidate[i]=(op,a,b);values=masks(candidate)
                    if wanted in values:
                        hits.append((candidate,values.index(wanted),'one-rewrite-and-output'))
    results=[]
    for candidate,output,kind in hits:
        r=audit(candidate,output)
        assert not r['false_positives'] and not r['false_negatives']
        clean,co=effective(candidate,output);reduced=audit(clean,co)
        assert not reduced['false_positives'] and not reduced['false_negatives']
        results.append({'kind':kind,'gates':candidate,**r,
                        'effective':{'gates':clean,**reduced},'target_size_met':len(clean)<=21})
    summary={'seed':name,'extensions_checked':checked,'one_gate_rewrites_checked':rewrites,'hits':results}
    (ROOT/(name+'-tiny-audit.json')).write_text(json.dumps(summary,indent=2))
    print('TINY',name,'extensions',checked,'rewrites',rewrites,'hits',len(hits),flush=True)
    for result in results:print('POSTED_WITNESS' if result['target_size_met'] else 'FULL_TRUTH_CANDIDATE',json.dumps(result),flush=True)


def repair(seed_path,changes,seconds):
    seed=json.loads(seed_path.read_text())
    variants=[[('or' if op==1 or op=='or' else 'and',a,b) for op,a,b in variant['gates']]
              for variant in seed.get('variants',[seed])]
    gs=variants[0]
    count=len(gs);c=CNF();selectors=[];changed=[]
    def one(length):
        row=[c.var() for _ in range(length)];c.cl(*row)
        for a,b in itertools.combinations(row,2):c.cl(-a,-b)
        return row
    def equate(selector,a,b):
        if isinstance(b,bool):c.cl(-selector,a if b else -a)
        else:c.cl(-selector,-a,b);c.cl(-selector,a,-b)
    choice=one(len(variants))
    for i in range(len(gs)):
        size=N+i;a,b=one(size),one(size);op=c.var();change=c.var();changed.append(change)
        for j in range(size):
            for k in range(j):c.cl(-a[j],-b[k])
        for variant_index,(selector,variant) in enumerate(zip(choice,variants)):
            if i in seed.get('variants',[seed])[variant_index].get('locked_indices',[]):c.cl(-selector,-change)
            oldop,olda,oldb=variant[i];olda,oldb=sorted([olda,oldb])
            c.cl(-selector,change,a[olda]);c.cl(-selector,change,b[oldb]);c.cl(-selector,change,op if oldop=='or' else -op)
        if i<seed.get('locked_prefix',0):c.cl(-change)
        selectors.append((a,b,op))
    c.atmost(changed,changes)
    output=one(count);negative=[[] for _ in gs]
    for x,expected in boundary_rows():
        values=[bool(x>>i&1) for i in range(N)]
        for i,(a,b,op) in enumerate(selectors):
            av,bv,v=c.var(),c.var(),c.var()
            for j in range(N+i):equate(a[j],av,values[j]);equate(b[j],bv,values[j])
            c.cl(op,-av,-bv,v);c.cl(op,av,-v);c.cl(op,bv,-v)
            c.cl(-op,av,bv,-v);c.cl(-op,-av,v);c.cl(-op,-bv,v)
            values.append(v)
            if not expected:negative[i].append(v)
        for i,s in enumerate(output):c.cl(-s,values[N+i] if expected else -values[N+i])
    dirty=[]
    for i,vals in enumerate(negative):
        below=c.var();d=c.var();dirty.append(d);op=selectors[i][2]
        for v in vals:c.cl(-below,-v)
        c.cl(below,*vals)
        c.cl(-d,-op);c.cl(-d,-below);c.cl(d,op,below)
    c.atmost(dirty,2);c.atmost([-d for d in dirty],count-2)
    name=seed_path.stem+f'-local{changes}-junk2';cnf=ROOT/(name+'.cnf');log=ROOT/(name+'.log');c.dump(cnf)
    print('START',name,'variables',c.n,'clauses',len(c.clauses),flush=True)
    def limits():
        resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
        resource.setrlimit(resource.RLIMIT_CPU,(seconds+5,seconds+5))
    start=time.monotonic()
    with log.open('w') as f:
        try:r=subprocess.run([SOLVER,'-t',str(seconds),str(cnf)],stdout=f,stderr=subprocess.STDOUT,preexec_fn=limits,timeout=seconds+10)
        except subprocess.TimeoutExpired:f.write('\nOUTER TIMEOUT\n');r=subprocess.CompletedProcess([],124)
    print('FINISH',name,'status',r.returncode,'seconds',round(time.monotonic()-start,3),flush=True)
    if r.returncode==10:
        text=log.read_text();model={int(v) for line in text.splitlines() if line.startswith('v ') for v in line[2:].split() if int(v)>0}
        pick=lambda ss:next(j for j,v in enumerate(ss) if v in model)
        candidate=[('or' if op in model else 'and',pick(a),pick(b)) for a,b,op in selectors]
        out=N+pick(output);checked=audit(candidate,out)
        assert not checked['false_positives'] and not checked['false_negatives'] and len(checked['junk_ands'])==2
        selected_variant=pick(choice);original=variants[selected_variant]
        assert sum((op,*sorted([a,b]))!=(oldop,*sorted([olda,oldb])) for (op,a,b),(oldop,olda,oldb) in zip(candidate,original))<=changes
        reduced,reduced_out=effective(candidate,out)
        reduced_audit=audit(reduced,reduced_out)
        assert not reduced_audit['false_positives'] and not reduced_audit['false_negatives']
        result={'gates':candidate,**checked,'seed_variant':selected_variant,'effective':{'gates':reduced,**reduced_audit}};(ROOT/(name+'-witness.json')).write_text(json.dumps(result,indent=2))
        print('FULL_TRUTH_WITNESS',json.dumps(result),flush=True)
    return r.returncode


if __name__=='__main__':
    if sys.argv[1]=='tiny':
        gs,out,_=boundary_example();tiny(gs,out,'boundary1006')
        path=Path(sys.argv[2]);r=json.loads(path.read_text())
        gs=[('or' if op==1 else 'and',a,b) for op,a,b in r['gates']];tiny(gs,r['output'],path.stem)
    else:repair(Path(sys.argv[1]),int(sys.argv[2]),int(sys.argv[3]))
