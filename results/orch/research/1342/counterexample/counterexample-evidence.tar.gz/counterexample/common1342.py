import itertools
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
N = 11
EDGES = [(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
         (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]


def target(x):
    return any(x >> a & x >> b & 1 for a,b in EDGES)


def boundary_rows():
    positives = [(1 << a) | (1 << b) for a,b in EDGES]
    negatives = [x for x in range(1 << N) if not target(x)
                 and all(target(x | (1 << i)) for i in range(N) if not x >> i & 1)]
    return [(x, True) for x in positives] + [(x, False) for x in negatives]


def evaluate(gs, output, x):
    values = [bool(x >> i & 1) for i in range(N)]
    for op,a,b in gs:
        assert 0 <= a < len(values) and 0 <= b < len(values)
        values.append(values[a] and values[b] if op == 'and' else values[a] or values[b])
    return values[output], values


def audit(gs, output):
    positives,negatives = [],[]
    junk = set()
    for x in range(1 << N):
        value, values = evaluate(gs,output,x)
        if value and not target(x):positives.append(x)
        if target(x) and not value:negatives.append(x)
        if not target(x):
            junk |= {i for i,(op,a,b) in enumerate(gs) if op=='and' and values[N+i]}
    return {'size':len(gs),'output':output,'and_count':sum(op=='and' for op,a,b in gs),
            'junk_ands':sorted(junk),'false_positives':positives,'false_negatives':negatives,
            'missing_edges':[(a,b) for a,b in EDGES if not evaluate(gs,output,(1<<a)|(1<<b))[0]]}


def effective(gs,output):
    rows=[x for x,_ in boundary_rows()]
    columns=[sum(bool(x>>i&1)<<j for j,x in enumerate(rows)) for i in range(N)]
    representatives={column:i for i,column in enumerate(columns)}
    mapping={i:i for i in range(N)};result=[]
    for i,(op,a,b) in enumerate(gs):
        column=columns[a]&columns[b] if op=='and' else columns[a]|columns[b]
        columns.append(column)
        if column in representatives:mapping[N+i]=representatives[column]
        else:
            result.append((op,mapping[a],mapping[b]));wire=N+len(result)-1
            mapping[N+i]=wire;representatives[column]=wire
    output=mapping[output];used=set()
    def visit(w):
        if w<N or w in used:return
        used.add(w);_,a,b=result[w-N];visit(a);visit(b)
    visit(output);mapping={i:i for i in range(N)};clean=[]
    for i,(op,a,b) in enumerate(result):
        if N+i in used:
            clean.append((op,mapping[a],mapping[b]));mapping[N+i]=N+len(clean)-1
    return clean,mapping[output]


def canonical(cover, assignments=None):
    gs=[];stars=[];assigned={v:[] for v in cover}
    for i,(a,b) in enumerate(EDGES):
        center = assignments[i] if assignments is not None else a if a in cover else b
        assert center in cover and center in [a,b]
        assigned[center].append(b if center==a else a)
    for center,leaves in assigned.items():
        if not leaves:continue
        out=leaves[0]
        for leaf in leaves[1:]:
            gs.append(('or',out,leaf));out=N+len(gs)-1
        gs.append(('and',center,out));stars.append(N+len(gs)-1)
    out=stars[0]
    for star in stars[1:]:
        gs.append(('or',out,star));out=N+len(gs)-1
    return gs,out


def boundary_example():
    left_vars=[[7,10],[2],[0],[8],[4,8],[3]]
    left_gates=[[],[],[],[0],[],[]]
    right_vars=[[6,9],[5,10],[9,10],[4,5],[1],[6,7]]
    right_gates=[[],[0],[],[],[0],[]]
    gs=[];ands=[]
    def join(items):
        out=items[0]
        for item in items[1:]:
            gs.append(('or',out,item));out=N+len(gs)-1
        return out
    for a,ag,b,bg in zip(left_vars,left_gates,right_vars,right_gates):
        av=join(a+[ands[i] for i in ag]);bv=join(b+[ands[i] for i in bg])
        gs.append(('and',av,bv));ands.append(N+len(gs)-1)
    out=join([ands[i] for i in [1,2,3,4,5]])
    return gs,out,ands


if __name__=='__main__':
    covers=next(cs for k in range(N+1) if (cs:=[list(S) for S in itertools.combinations(range(N),k)
                if all(a in S or b in S for a,b in EDGES)]))
    seeds=[]
    for cover in covers:
        gs,out=canonical(cover);r=audit(gs,out)
        assert not r['false_positives'] and not r['false_negatives'] and len(gs)==22
        seeds.append({'cover':cover,'gates':gs,'output':out})
    (ROOT/'canonical-seeds.json').write_text(json.dumps(seeds,indent=2))
    gs,out,ands=boundary_example();r=audit(gs,out)
    assert len(r['false_positives'])+len(r['false_negatives'])==39
    (ROOT/'boundary1006-audit.json').write_text(json.dumps({'gates':gs,**r},indent=2))
    print('canonical covers',len(covers),'size',len(covers[0]),'boundary rows',len(boundary_rows()))
    print('L1006',json.dumps(r))
