import itertools,json,math,time,random
from pathlib import Path
from sympy.polys.rings import ring
from sympy.polys.domains import QQ

base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/tracezero')
start=time.monotonic()
coords=[(i,j) for i in range(4) for j in range(i,4)]
diags=[i for i,(a,b) in enumerate(coords) if a==b]
edges=[i for i,(a,b) in enumerate(coords) if a!=b]
exps=[(a,d-a) for d in (2,3,4) for a in range(d+1)]

def mul(a,b,R):
 out={}
 for ea,ca in a.items():
  for eb,cb in b.items():
   e=(ea[0]+eb[0],ea[1]+eb[1]);out[e]=out.get(e,R.zero)+ca*cb
 return out

def evaluate(p,values):
 return sum(int(c)*math.prod(v**power for v,power in zip(values,e)) for e,c in p.items())

def permanent(M):
 return sum(math.prod(M[i][p[i]] for i in range(4)) for p in itertools.permutations(range(4)))

reports=[]
for kind,pivot in [('rank2',None),('rank1-incident',1),('rank1-disjoint',5)]:
 n=12 if kind=='rank2' else 10
 R,*xs=ring(','.join('x'+str(i) for i in range(n)),QQ)
 B=[[R.zero,R.zero] for _ in coords]
 B[0][0]=R.one
 if kind=='rank2':
  B[4][1]=R.one
  B[7]=xs[:2]
  B[9]=[-R.one-xs[0],-R.one-xs[1]]
  for k,c in enumerate(edges[:-1]):B[c]=xs[2+2*k:4+2*k]
  B[edges[-1]]=[-sum(B[c][j] for c in edges[:-1]) for j in range(2)]
 else:
  B[4][0]=xs[0];B[7][0]=xs[1];B[9][0]=-R.one-xs[0]-xs[1]
  B[pivot][1]=R.one
  dep=max(c for c in edges if c!=pivot)
  free=[c for c in edges if c not in (pivot,dep)]
  for k,c in enumerate(free):B[c]=xs[2+2*k:4+2*k]
  B[dep]=[-sum(B[c][j] for c in edges if c!=dep) for j in range(2)]
 assert all(sum(B[c][j] for c in diags)==0 and sum(B[c][j] for c in edges)==0 for j in range(2))
 M=[[{(0,0):R.one} for _ in range(4)] for _ in range(4)]
 for c,(i,j) in enumerate(coords):M[i][j]=M[j][i]={(0,0):R.one,(1,0):B[c][0],(0,1):B[c][1]}
 coeff={}
 for p in itertools.permutations(range(4)):
  term={(0,0):R.one}
  for i in range(4):term=mul(term,M[i][p[i]],R)
  for e,v in term.items():coeff[e]=coeff.get(e,R.zero)+v
 assert coeff[(0,0)]==24 and coeff[(1,0)]==0 and coeff[(0,1)]==0
 polys=[coeff[e] for e in exps]
 assert all(c.denominator==1 for p in polys for c in p.values())
 for prime in (0,101):
  path=base/(kind+'-p'+str(prime)+'.ms')
  path.write_text(','.join(str(x) for x in xs)+'\n'+str(prime)+'\n'+',\n'.join(str(p).replace('**','^') for p in polys)+'\n')
 checks=0;rng=random.Random(231891+n+(pivot or 0));assignments=[]
 for _ in range(8):
  values=[rng.randint(-3,3) for i in range(n)]
  entries=[[evaluate(p,values) for p in row] for row in B]
  cv=[evaluate(p,values) for p in polys]
  for t,u in [(0,0),(1,0),(0,1),(-1,1),(2,-1),(-2,3),(1,2),(3,-2),(2,2),(-3,-1)]:
   concrete=[[1]*4 for _ in range(4)]
   for c,(i,j) in enumerate(coords):concrete[i][j]=concrete[j][i]=1+t*entries[c][0]+u*entries[c][1]
   actual=permanent(concrete)
   predicted=24+sum(v*t**e[0]*u**e[1] for e,v in zip(exps,cv))
   assert actual==predicted,(kind,values,t,u,actual,predicted)
   checks+=1
  assignments.append(values)
 record={'name':kind,'variables':[str(x) for x in xs],'pivot_edge':pivot,'basis_coefficients':[[str(p) for p in row] for row in B],'generator_parameter_exponents':[list(e) for e in exps],'generators':[str(p) for p in polys],'terms':sum(len(p) for p in polys),'polynomial_degrees':[max(map(sum,p),default=0) for p in polys],'direct_permanent_checks':checks,'audit_assignments':assignments}
 reports.append(record)
 print(json.dumps({k:record[k] for k in ('name','terms','polynomial_degrees','direct_permanent_checks')}),flush=True)
coverage='Every nonhollow trace-zero two-plane has diagonal image rank one or two. At rank two choose any two independent diagonal coordinate restrictions; S4 takes their indices to 0,1 and GL2 normalizes them. At rank one choose a nonzero diagonal coordinate and take its index to 0. Normalize a basis A,B with A00=1 and B hollow. Choose a nonzero off-diagonal coordinate of B, normalize it to 1 and subtract its A value times B. The S3 stabilizer of vertex0 has two edge orbits, incident01 and disjoint12. Trace and sum-entry equations eliminate the stated diagonal and edge coordinates.'
manifest={'status':'PASS','scope':'Complete three-chart cover of nonhollow symmetric trace-zero two-planes on which permanent(J+T)=24; no claim of empty or finite solution locus','coordinates':[list(v) for v in coords],'coverage_argument':coverage,'charts':reports,'seconds':time.monotonic()-start}
(base/'charts-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'status':'PASS','charts':3,'checks':sum(r['direct_permanent_checks'] for r in reports),'seconds':manifest['seconds']}),flush=True)
