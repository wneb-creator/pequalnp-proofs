import sympy as s,itertools,json
from pathlib import Path
base=Path('/tmp/oec/pequalnp-pilot-78')
vs=s.symbols('a b c d e f x y z');a,b,c,d,e,f,x,y,z=vs
Q,C,P=[s.sympify(v,locals=dict(zip(map(str,vs),vs))).subs(c,-a-b).expand() for v in (base/'construct_search/hadamard-polynomials.txt').read_text().splitlines()]
vs=(a,b,d,e,f,x,y,z)
M=s.Matrix([[0,x,y,z],[x,a,d,e],[y,d,b,f],[z,e,f,-a-b]])
D=s.expand(M.det())
I=[a*a+b*b+(a+b)**2,d*d+e*e+f*f,x*x+y*y+z*z,d*z+e*y+f*x]
basis=[P]+[u*v for i,u in enumerate(I) for v in I[i:]]
labels=['P']+[str((i,j)) for i in range(4) for j in range(i,4)]
ps=[s.Poly(s.expand(p),*vs) for p in basis];target=s.Poly(D,*vs)
monoms=sorted(set(target.monoms()).union(*(set(p.monoms()) for p in ps)))
A=s.Matrix([[p.coeff_monomial(m) for p in ps] for m in monoms]);rhs=s.Matrix([target.coeff_monomial(m) for m in monoms])
report={'coefficient_matrix_shape':list(A.shape),'matrix_rank':A.rank(),'augmented_rank':A.row_join(rhs).rank(),'solution':str(s.linsolve((A,rhs))),'basis':labels,'scope':'exact invariant-span test on trace-zero tangent slice only'}
print(json.dumps(report,indent=2));(base/'geometry_search/tracezero/invariant-identities.json').write_text(json.dumps(report,indent=2)+'\n')
