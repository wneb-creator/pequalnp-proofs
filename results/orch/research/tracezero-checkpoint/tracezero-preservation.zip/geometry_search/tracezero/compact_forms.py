import sympy as s,json
from pathlib import Path
base=Path('/tmp/oec/pequalnp-pilot-78')
a,b,c,d,e,f,x,y,z=s.symbols('a b c d e f x y z')
B0,B1,D0,D1,D2,P0,P1,P2=s.symbols('B0 B1 D0 D1 D2 P0 P1 P2')
B=[B0,B1,-B0-B1];D=[D0,D1,D2];P=[P0,P1,P2]
subs={a:B[0],b:B[1],c:B[2],x:(P[0]-D[0])/2,y:(P[1]-D[1])/2,z:(P[2]-D[2])/2,f:(3*D[0]-P[0])/2,e:(3*D[1]-P[1])/2,d:(3*D[2]-P[2])/2}
Q,C,V=[s.expand(s.sympify(t).subs(subs,simultaneous=True)) for t in (base/'construct_search/hadamard-polynomials.txt').read_text().splitlines()]
Q0=sum(v*v for v in B)+3*sum(v*v for v in D)-sum(v*v for v in P)
C0=s.prod(B)+sum(b*d*d for b,d in zip(B,D))+s.prod(p-d for p,d in zip(P,D))-2*s.prod(p-2*d for p,d in zip(P,D))
assert s.expand(Q-Q0)==0
assert s.expand(C-C0)==0
R=s.expand(16*V-Q**2)
groups={}
for (i,j),expr in s.Poly(R,B0,B1).terms():groups[str((i,j))]=str(s.factor(expr))
report={'quadratic':str(Q),'cubic_compact':str(C0),'quartic_residual_16P_minus_Q2':str(R),'quartic_residual_by_B_degrees':groups,'scope':'exact symbolic identities on trace-zero tangent space'}
(base/'geometry_search/tracezero/compact-forms.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
