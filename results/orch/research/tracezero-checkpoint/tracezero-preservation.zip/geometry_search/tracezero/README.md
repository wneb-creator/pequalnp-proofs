# Trace-zero research checkpoint

This checkpoint is research toward L-gct-231, not a proof or refutation of its three-dimensional statement.

The auxiliary assertion that every complex trace-zero two-dimensional permanent-flat is hollow is false. `star-tracezero-certificate.json` specifies a squarefree degree-sixteen polynomial F, rational polynomials u(e), b(e), and two symmetric matrices A,V. Any complex root e gives a nonhollow trace-zero plane with permanent(J+wA+zV)=24. A is the basic star direction, and V11=1 proves independence. Exact direct permanent residues and an independent 24-term audit are included. F remains irreducible over Q and Q(sqrt(-3)). The child's alternative degree-eight invariant representation is also included, with all denominator nonvanishing certificates and an exact comparison to the degree-sixteen construction. These examples do not extend the target to dimension three.

The three original charts cover every nonhollow trace-zero two-plane: one chart for diagonal rank two and two charts for diagonal rank one (incident and disjoint hollow pivots). The chart manifest contains the coverage argument and all coordinate formulas. The rank-one charts have an independent complete symbolic permanent audit. The independently generated Hadamard rank-two chart has fewer terms and its own direct checks.

The original rank-two rational Singular standard-basis calculation terminated with `Singular error: no more memory`, exit 14, after 270.596 seconds under a 512 MiB address-space cap. Its complete stdout is losslessly compressed and the result records its original hash. This failure gives no algebraic conclusion. The Hadamard F101 probe also ended inconclusively at its time limit. Subsequent active calculations are outside this frozen checkpoint.

The finite-field census files cover F5,F7,F11,F13,F17,F19,F23 and include source, execution diagnostics, direct permanent audits, and canonical bases. They are evidence only; neither the presence nor absence of rational points over these fields decides the complex locus. The global trace-zero classification, uniform diagonal-rank-two obstruction, and diagonal-rank-three branch remain open.

Python reproducers require SymPy. The census uses the included C++ source and its documented wrapper. Native algebra probes used Singular 4.4.1 with one thread; the wrappers give exact flags and resource limits. Paths in scripts retain their original scratch root. The archive manifest retains original relative paths and SHA256 hashes so the source/audit dependencies can be relocated together.
