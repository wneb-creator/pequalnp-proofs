import sympy as s,itertools,json,time
from pathlib import Path
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/tracezero')
start=time.monotonic();u,b,e,z,w=s.symbols('u b e z w')
A=s.Matrix([[0,1,-1,0],[1,0,0,0],[-1,0,0,0],[0,0,0,0]])
V=s.Matrix([[u,b,b,-2*b-1-2*e],[b,1,1,e],[b,1,1,e],[-2*b-1-2*e,e,e,-u-2]])
poly=s.Poly(s.expand(sum(s.prod(1+z*V[i,p[i]] for i in range(4)) for p in itertools.permutations(range(4)))-24),z)
inputs=[poly.coeff_monomial(z**k) for k in (2,3,4)]
G=s.groebner(inputs,u,b,e,order='lex',domain=s.QQ)
assert len(G.polys)==3
gu,gb,ge=[p.as_expr() for p in G.polys]
F=s.Poly(ge,e).clear_denoms()[1].primitive()[1]
usol=s.cancel(s.solve(gu,u)[0]);bsol=s.cancel(s.solve(gb,b)[0])
assert usol.free_symbols<=set([e]) and bsol.free_symbols<=set([e])
qring=s.QQ.poly_ring(e)
denu,nu=s.fraction(usol)[1],s.fraction(usol)[0]
denb,nb=s.fraction(bsol)[1],s.fraction(bsol)[0]
assert denu.is_Integer and denb.is_Integer
uP=s.Poly(usol,e,domain=s.QQ);bP=s.Poly(bsol,e,domain=s.QQ)
def mulmod(p,q):return (p*q).rem(F)
one=s.Poly(1,e,domain=s.QQ);zero=s.Poly(0,e,domain=s.QQ)
def evalmod(expr):
 out=zero
 for (i,j,k),coeff in s.Poly(expr,u,b,e).terms():
  term=s.Poly(coeff,e,domain=s.QQ)
  for _ in range(i):term=mulmod(term,uP)
  for _ in range(j):term=mulmod(term,bP)
  term=mulmod(term,s.Poly(e**k,e,domain=s.QQ));out=(out+term).rem(F)
 return out
residues=[evalmod(expr).as_expr() for expr in inputs]
assert residues==[0,0,0]
# Independent direct Ryser formula for a two-parameter permanent.
M=s.ones(4)+z*V+w*A
ryser=0
for bits in range(1,16):
 cols=[j for j in range(4) if bits>>j&1]
 ryser+=(-1)**(4-len(cols))*s.prod(sum(M[i,j] for j in cols) for i in range(4))
actual=s.Poly(s.expand(ryser-24),z,w)
coeff_residues={str(exp):str(evalmod(coeff).as_expr()) for exp,coeff in actual.terms()}
assert set(coeff_residues.values())<={'0'}
fq=s.factor_list(F.as_expr(),e)
fomega=s.factor_list(F.as_expr(),e,extension=s.sqrt(-3))
ftwo=s.factor_list(F.as_expr(),e,extension=s.sqrt(2))
report={'scope':'Counterexample to auxiliary claim that every constant-permanent trace-zero complex two-plane is hollow; NOT a counterexample or proof for L-gct-231','construction':'Choose any complex root e of F. Set u=u(e), b=b(e). The displayed symmetric A,V are independent since A11=0 and V11=1. Their span is trace-zero, nonhollow, and permanent(J+wA+zV)=24 for all w,z. It contains the basic star line A.','F':str(F.as_expr()),'degree':F.degree(),'u':str(usol),'b':str(bsol),'A':[[str(x) for x in row] for row in A.tolist()],'V':[[str(x) for x in row] for row in V.tolist()],'source_coefficients':list(map(str,inputs)),'source_groebner_basis':list(map(str,(gu,gb,ge))),'substitution_residues':list(map(str,residues)),'independent_ryser_residues':coeff_residues,'factorization_Q':str(fq),'factorization_Qomega':str(fomega),'factorization_Qsqrt2':str(ftwo),'squarefree_gcd':str(s.gcd(F,F.diff()).as_expr()),'seconds':time.monotonic()-start}
(base/'star-tracezero-certificate.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
