from pathlib import Path
from itertools import permutations
import sympy as S
import json
import resource
resource.setrlimit(resource.RLIMIT_AS,(512*2**20,512*2**20))
resource.setrlimit(resource.RLIMIT_CPU,(60,65))
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero')
u,v,b,e,h,z=S.symbols('u v b e h z')
A=S.Matrix([[0,1,-1,0],[1,0,0,0],[-1,0,0,0],[0,0,0,0]])
V=S.Matrix([[u,b,b,-2*b-2*e-v],[b,v,v,e],[b,v,v,e],[-2*b-2*e-v,e,e,-u-2*v]])
M=S.ones(4)+h*A+z*V
direct=S.Poly(S.expand(sum(S.prod(M[i,j] for i,j in enumerate(p)) for p in permutations(range(4)))-24),h,z)
assert all(ih==0 and iz in (2,3,4) for (ih,iz),coef in direct.terms())
assert S.trace(A)==S.trace(V)==0
s,r,d=S.symbols('s r d');R,U,W=S.symbols('R U W')
F=3*s**8-24*s**7+52*s**6+144*s**5-844*s**4+288*s**3+1888*s**2-384*s-960
D=s**4-6*s**3+20*s**2-16
N=s**6-10*s**5+36*s**4-40*s**3-104*s**2+32*s+32
Rv=N/D
Uv=4*(s**5-2*s**4-18*s**3-52*s**2+72*s+80)/((s-2)*D)
Wv=-2*(s**6-7*s**5+26*s**4-22*s**3-84*s**2+56*s+80)/((s-2)*D)
def invariant(expr):
 result=0
 for (er,ed),coefficient in S.Poly(expr,r,d).terms():
  assert (er-ed)%2==0
  k=min(er,ed)
  result+=coefficient*W**k*R**((er-k)//2)*U**((ed-k)//2)
 return S.expand(result)
relations=[]
for degree in (2,3,4):
 expr=S.expand(direct.coeff_monomial(z**degree).subs({u:d-1,v:1,b:(s+r)/2,e:(s-r)/2},simultaneous=True))
 rel=S.factor(S.together(invariant(expr).subs({R:Rv,U:Uv,W:Wv})).as_numer_denom()[0])
 quotient,remainder=S.div(rel,F,s)
 assert remainder==0
 relations.append({'degree':degree,'cleared_numerator':str(rel),'F_multiplier':str(quotient)})
square=S.factor(S.together(Wv**2-Uv*Rv).as_numer_denom()[0])
quotient,remainder=S.div(square,F,s)
assert remainder==0
coprime={}
for name,poly in {'s_minus_2':s-2,'denominator':D,'R_numerator':N}.items():
 aa,bb,g=S.gcdex(F,poly,s)
 assert g==1 and S.expand(aa*F+bb*poly)==1
 coprime[name]={'polynomial':str(poly),'F_multiplier':str(aa),'polynomial_multiplier':str(bb)}
roots=[]
for root in S.nroots(F,maxsteps=100):
 if abs(S.im(root))<1e-10:
  roots.append({'s':float(S.re(root)),'R':float(Rv.subs(s,S.re(root))),'U':float(Uv.subs(s,S.re(root))),'W':float(Wv.subs(s,S.re(root)))})
report={'status':'PASS','direct_24_term_permanent_mixed_coefficients_zero':True,'trace_zero':True,'F':str(F),'R':str(Rv),'U':str(Uv),'W':str(Wv),'direct_permanent_remainder_certificates':relations,'W_squared_minus_U_R_F_multiplier':str(quotient),'denominator_coprimality_bezout':coprime,'approximate_real_roots':roots,'construction':'Choose any complex root s of F, nonzero r with r^2=R(s), delta=W(s)/r. Then u=delta-1,v=1,b=(s+r)/2,e=(s-r)/2. span(A,V) is a trace-zero nonhollow permanent-flat of dimension two. Nonzero v proves independence from hollow A.'}
(base/'star-tracezero-degree8-independent-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','direct_coefficients':[(list(mon),str(coef)) for mon,coef in direct.terms()],'real_roots':roots,'F':str(F)}),flush=True)
