from pathlib import Path
import sympy as S
import json
import time
import resource

resource.setrlimit(resource.RLIMIT_AS, (512*2**20,512*2**20))
resource.setrlimit(resource.RLIMIT_CPU, (60,65))
start=time.monotonic()
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero')
raw=Path('/tmp/oec/pequalnp-pilot-78/construct_search/hadamard-polynomials.txt')
a,b,c,d,e,f,x,y,z=S.symbols('a b c d e f x y z')
p=S.symbols('p1:4'); D=S.symbols('D1:4')
subs={c:-a-b,x:(p[0]-D[0])/2,y:(p[1]-D[1])/2,z:(p[2]-D[2])/2,
      f:(3*D[0]-p[0])/2,e:(3*D[1]-p[1])/2,d:(3*D[2]-p[2])/2}
q,C,P=[S.expand(S.sympify(line).subs(subs,simultaneous=True)) for line in raw.read_text().splitlines()]
zero={v:0 for v in D}
q0=q.subs(zero); C0=S.factor(C.subs(zero)); P0=S.factor(P.subs(zero))
ratio=S.cancel(P0/q0**2)
assert not ratio.free_symbols
Delta=S.expand(P-ratio*q*q)
print('q=',q,flush=True)
print('C0=',C0,flush=True)
print('P0/q0^2=',ratio,flush=True)
print('C-D-degrees',flush=True)
for degree in range(4):
 expr=S.Add(*(coef*S.prod(v**k for v,k in zip(D,mon)) for mon,coef in S.Poly(C,*D).terms() if sum(mon)==degree))
 print(degree,S.factor(expr),flush=True)
print('P-ratio*q^2-D-degrees',flush=True)
parts=[]
for degree in range(1,5):
 expr=S.Add(*(coef*S.prod(v**k for v,k in zip(D,mon)) for mon,coef in S.Poly(Delta,*D).terms() if sum(mon)==degree))
 parts.append(str(S.factor(expr)))
 print(degree,S.factor(expr),flush=True)
(base/'trace-zero-rankone-invariants.json').write_text(json.dumps({'q':str(q),'C':str(C),'P':str(P),'hollow_ratio':str(ratio),'quartic_difference_D_parts':parts,'seconds':time.monotonic()-start},indent=2)+'\n')
