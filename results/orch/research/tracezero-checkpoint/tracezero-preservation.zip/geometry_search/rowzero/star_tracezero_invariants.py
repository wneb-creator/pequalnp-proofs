from pathlib import Path
import sympy as S
import json
import resource
resource.setrlimit(resource.RLIMIT_AS,(512*2**20,512*2**20))
resource.setrlimit(resource.RLIMIT_CPU,(60,65))
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero')
data=json.loads(Path('/tmp/oec/pequalnp-pilot-78/geometry_search/tracezero/star-line-tracezero.json').read_text())
u,v,b,e=S.symbols('u v b e');s,r,d=S.symbols('s r d');R,U,W=S.symbols('R U W')
polys=[S.expand(S.sympify(x).subs({u:d-1,v:1,b:(s+r)/2,e:(s-r)/2},simultaneous=True)) for x in data['polys']]
polys=[S.Poly(x,s,r,d).clear_denoms()[1].primitive()[1].as_expr() for x in polys]
def invariant(x):
 out=0
 for (er,ed),coef in S.Poly(x,r,d).terms():
  assert (er-ed)%2==0
  k=min(er,ed)
  out += coef*W**k*R**((er-k)//2)*U**((ed-k)//2)
 return S.expand(out)
inv=list(map(invariant,polys))
print('POLYS_IN_U_R_W',inv,flush=True)
sol=S.solve(inv[:2],(U,W),dict=True)[0]
print('LINEAR_SOL',sol,flush=True)
F=S.factor(S.together(inv[2].subs(sol)).as_numer_denom()[0])
G=S.factor(S.together((W*W-U*R).subs(sol)).as_numer_denom()[0])
print('F',F,flush=True);print('G',G,flush=True)
res=S.factor(S.resultant(F,G,R));print('RESULTANT',res,flush=True)
comb=S.factor(S.Poly(F,R).LC()*G-S.Poly(G,R).LC()*F)
print('LINEAR_COMBO',comb,flush=True)
if S.degree(comb,R)==1:
 rsol=S.solve(comb,R)[0]
 print('R_SOL',S.factor(rsol),flush=True)
 print('U_SOL',S.factor(sol[U].subs(R,rsol)),flush=True)
 print('W_SOL',S.factor(sol[W].subs(R,rsol)),flush=True)
out={'substitution':'v=1,u=d-1,b=(s+r)/2,e=(s-r)/2; U=d^2,R=r^2,W=d*r', 'invariant_polys':list(map(str,inv)),'linear_solution':{str(k):str(vv) for k,vv in sol.items()},'F':str(F),'G':str(G),'resultant':str(res),'linear_combination':str(comb)}
(base/'star-tracezero-invariants.json').write_text(json.dumps(out,indent=2)+'\n')
