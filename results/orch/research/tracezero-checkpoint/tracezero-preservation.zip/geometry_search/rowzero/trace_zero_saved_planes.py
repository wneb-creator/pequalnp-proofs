from pathlib import Path
from itertools import permutations
from collections import Counter, defaultdict
import hashlib
import json
import sys
import time

start = time.monotonic()
source = Path('/tmp/oec/pequalnp-pilot-78/finitefield')
output = Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero')
upper = [(i, j) for i in range(4) for j in range(i, 4)]
index = {pair: k for k, pair in enumerate(upper)}
diag = [index[(i, i)] for i in range(4)]
perms = list(permutations(range(4)))
edge_perms = [[index[tuple(sorted((s[i], s[j]))) ] for i, j in upper] for s in perms]

def rref(rows, p):
    a = [[int(x) % p for x in row] for row in rows]
    if not a:
        return (), ()
    rank = 0
    pivots = []
    for col in range(len(a[0])):
        pivot = next((j for j in range(rank, len(a)) if a[j][col]), None)
        if pivot is None:
            continue
        a[rank], a[pivot] = a[pivot], a[rank]
        inv = pow(a[rank][col], -1, p)
        a[rank] = [(inv * x) % p for x in a[rank]]
        for j in range(len(a)):
            if j != rank and a[j][col]:
                c = a[j][col]
                a[j] = [(x-c*y) % p for x, y in zip(a[j], a[rank])]
        pivots.append(col)
        rank += 1
        if rank == len(a):
            break
    return tuple(tuple(row) for row in a[:rank]), tuple(pivots)

def matrix(row):
    return [[row[index[tuple(sorted((i, j)))]] for j in range(4)] for i in range(4)]

def nullspace(rows, p):
    reduced, pivots = rref(rows, p)
    free = [j for j in range(4) if j not in pivots]
    result = []
    for col in free:
        v = [0]*4
        v[col] = 1
        for row, pivot in zip(reduced, pivots):
            v[pivot] = -row[col] % p
        result.append(v)
    return result

def canonical(plane, p):
    return min(rref([[v[k] for k in perm] for v in plane], p)[0] for perm in edge_perms)

def permanent_coefficients(plane, p):
    a, b = map(matrix, plane)
    total = defaultdict(int)
    for perm in perms:
        poly = {(0, 0): 1}
        for i, j in enumerate(perm):
            new = defaultdict(int)
            for (x, y), value in poly.items():
                new[x, y] += value
                new[x+1, y] += value*a[i][j]
                new[x, y+1] += value*b[i][j]
            poly = new
        for monomial, value in poly.items():
            total[monomial] += value
    total[0, 0] -= 24
    return {str(k): v % p for k, v in total.items() if v % p}

def features(plane, p):
    matrices = list(map(matrix, plane))
    kernel = nullspace(matrices[0]+matrices[1], p)
    rows_zero = [i for i in range(4) if all(m[i][j] == 0 for m in matrices for j in range(4))]
    directions = []
    for t in range(p):
        directions.append([(x+t*y) % p for x, y in zip(*plane)])
    directions.append(list(plane[1]))
    return {
        'diagonal_rank': len(rref([[v[k] for k in diag] for v in plane], p)[0]),
        'common_kernel_dimension': len(kernel),
        'common_kernel_basis': kernel,
        'common_kernel_basis_sum_norm': [[sum(v) % p, sum(x*x for x in v) % p] for v in kernel],
        'coordinate_zero_rows': rows_zero,
        'direction_rank_histogram': dict(sorted(Counter(len(rref(matrix(v), p)[0]) for v in directions).items())),
    }

report = {'coordinate_order': upper, 'scope': 'classification of saved planes only; no new plane enumeration', 'fields': {}}
fields = list(map(int, sys.argv[1:])) if len(sys.argv)>1 else [5,7,11,13]
for p in fields:
    path = source / f'f{p}-2planes.json' if p in (5,7,11,13) else Path('/tmp/oec/pequalnp-pilot-78/construct_search/net_normal_form') / f'tracezero-f{p}-2planes.json'
    raw = path.read_bytes()
    data = json.loads(raw)
    assert isinstance(data, list)
    assert all(len(plane) == 2 and all(len(row) == 10 for row in plane) for plane in data)
    all_planes = {rref(plane, p)[0] for plane in data}
    assert len(all_planes) == len(data)
    assert all(len(plane) == 2 for plane in all_planes)
    trace_zero = [plane for plane in all_planes if all(sum(v[k] for k in diag) % p == 0 for v in plane)]
    hollow = [plane for plane in trace_zero if all(v[k] == 0 for v in plane for k in diag)]
    extra = [plane for plane in trace_zero if plane not in hollow]
    assert all(not permanent_coefficients(plane, p) for plane in trace_zero)
    groups = defaultdict(list)
    for plane in extra:
        groups[canonical(plane, p)].append(plane)
    orbits = []
    for representative, members in sorted(groups.items()):
        orbit = {rref([[v[k] for k in perm] for v in representative], p)[0] for perm in edge_perms}
        assert orbit == set(members)
        f = features(representative, p)
        orbits.append({'size': len(members), 'representative': representative, **f})
    f = {
        'input_sha256': hashlib.sha256(raw).hexdigest(),
        'saved_plane_count': len(all_planes),
        'trace_zero_plane_count': len(trace_zero),
        'hollow_plane_count': len(hollow),
        'trace_zero_nonhollow_count': len(extra),
        'nonhollow_S4_orbit_count': len(orbits),
        'nonhollow_orbits': orbits,
        'all_trace_zero_planes_verified_by_direct_24_term_permanent': True,
        'all_nonhollow_orbits_complete_in_saved_census': True,
    }
    report['fields'][str(p)] = f
    print(json.dumps({'p': p, **{k: v for k, v in f.items() if k not in {'input_sha256', 'nonhollow_orbits'}}, 'orbits': orbits}), flush=True)
report['seconds'] = time.monotonic()-start
name = 'trace-zero-saved-planes.json' if len(sys.argv)==1 else 'trace-zero-saved-planes-'+ '-'.join(map(str,fields)) + '.json'
(output / name).write_text(json.dumps(report, indent=2)+'\n')
