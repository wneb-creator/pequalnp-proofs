from pathlib import Path
from itertools import permutations
import sympy as S
import json
import hashlib
import resource
resource.setrlimit(resource.RLIMIT_AS,(512*2**20,512*2**20))
resource.setrlimit(resource.RLIMIT_CPU,(60,65))
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero')
path=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/tracezero/star-tracezero-certificate.json')
raw=path.read_bytes();data=json.loads(raw)
u,b,e,z,h=S.symbols('u b e z h')
F=S.Poly(S.sympify(data['F']),e,domain=S.QQ)
up=S.Poly(S.sympify(data['u']),e,domain=S.QQ)
bp=S.Poly(S.sympify(data['b']),e,domain=S.QQ)
ep=S.Poly(e,e,domain=S.QQ)
zero=S.Poly(0,e,domain=S.QQ)
one=S.Poly(1,e,domain=S.QQ)
def mul(a,b): return (a*b).rem(F)
def power(a,n):
 result=one
 while n:
  if n&1: result=mul(result,a)
  a=mul(a,a);n//=2
 return result
def substitute(expr,variables,values):
 result=zero
 for mon,coeff in S.Poly(expr,*variables).terms():
  term=S.Poly(coeff,e,domain=S.QQ)
  for value,exponent in zip(values,mon): term=mul(term,power(value,exponent))
  result=(result+term).rem(F)
 return result
A=S.Matrix([[0,1,-1,0],[1,0,0,0],[-1,0,0,0],[0,0,0,0]])
V=S.Matrix([[u,b,b,-2*b-2*e-1],[b,1,1,e],[b,1,1,e],[-2*b-2*e-1,e,e,-u-2]])
assert A==S.Matrix([[S.sympify(x) for x in row] for row in data['A']])
assert V==S.Matrix([[S.sympify(x) for x in row] for row in data['V']])
M=S.ones(4)+z*V+h*A
per=S.Poly(S.expand(sum(S.prod(M[i,j] for i,j in enumerate(p)) for p in permutations(range(4)))-24),z,h)
for mon,coef in per.terms(): assert substitute(coef,[u,b,e],[up,bp,ep])==zero
assert S.trace(A)==S.trace(V)==0
assert A==A.T and V==V.T and A[1,1]==0 and V[1,1]==1
s=S.symbols('s')
ours=json.loads((base/'star-tracezero-degree8-independent-audit.json').read_text())
sp=(bp+ep).rem(F)
assert substitute(S.sympify(ours['F']),[s],[sp])==zero
checks={}
for name,actual in {'R':power(bp-ep,2),'U':power(up+one,2),'W':mul(up+one,bp-ep)}.items():
 numerator,denominator=S.fraction(S.cancel(S.sympify(ours[name])))
 num=substitute(numerator,[s],[sp]);den=substitute(denominator,[s],[sp])
 assert mul(den,actual)==num
 checks[name]=True
report={'status':'PASS','input_sha256':hashlib.sha256(raw).hexdigest(),'scope':data['scope'],'parent_displayed_matrices_verified':True,'independent_24_term_permanent_mod_F_zero':True,'trace_zero_symmetric_independent':True,'degree8_quotient_polynomial_and_three_invariants_agree':checks,'degree16_nonconstant_and_squarefree':F.degree()==16 and S.gcd(F,F.diff()).degree()==0}
(base/'parent-star-tracezero-independent-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
