from pathlib import Path
import json,itertools,hashlib,time,resource
import sympy as S
resource.setrlimit(resource.RLIMIT_AS,(512*2**20,512*2**20))
resource.setrlimit(resource.RLIMIT_CPU,(60,65))
base=Path('/tmp/oec/pequalnp-pilot-78/trace_chart_audit')
source=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/tracezero/charts-manifest.json')
manifest=json.loads(source.read_text());coords=[tuple(c) for c in manifest['coordinates']]
index={c:i for i,c in enumerate(coords)}
perms=list(itertools.permutations(range(4)))
charts=[c for c in manifest['charts'] if c['name'].startswith('rank1')]
def mul(p,q):
 out={}
 for a,x in p.items():
  for b,y in q.items():
   e=tuple(i+j for i,j in zip(a,b));out[e]=out.get(e,0)+x*y
 return {e:x for e,x in out.items() if x}
records=[];parsed={}
for c in charts:
 started=time.monotonic();xs=S.symbols(' '.join(c['variables']));n=len(xs);zero=(0,)*(n+2)
 basis=[[S.sympify(x,locals=dict(zip(c['variables'],xs))) for x in row] for row in c['basis_coefficients']]
 generators=[S.Poly(S.sympify(x,locals=dict(zip(c['variables'],xs))),xs) for x in c['generators']]
 entries={}
 for ij,row in zip(coords,basis):
  entry={zero:1}
  for k,pol in enumerate(row):
   for e,co in S.Poly(pol,xs).terms():
    assert co.q==1
    mon=e+((1,0) if k==0 else (0,1));entry[mon]=entry.get(mon,0)+int(co)
  entries[ij]=entries[ij[::-1]]=entry
 total={}
 for pm in perms:
  prod={zero:1}
  for i in range(4):prod=mul(prod,entries[i,pm[i]])
  for e,co in prod.items():total[e]=total.get(e,0)+co
 total[zero]-=24;total={e:co for e,co in total.items() if co}
 groups={}
 for e,co in total.items():groups.setdefault(e[-2:],{})[e[:-2]]=co
 exps=list(map(tuple,c['generator_parameter_exponents']))
 checks=[]
 for ex,g in zip(exps,generators):
  expected={m:int(co) for m,co in g.terms() if co};actual=groups.pop(ex,{})
  assert actual==expected,(c['name'],ex,'exact coefficient mismatch')
  checks.append({'parameter_exponent':ex,'terms':len(actual),'exact_match':True})
 assert not groups,(c['name'],'unlisted nonzero coefficients',groups)
 trace=[S.expand(sum(basis[i][j] for i in [0,4,7,9])) for j in range(2)]
 offsum=[S.expand(sum(basis[i][j] for i in [1,2,3,5,6,8])) for j in range(2)]
 assert trace==[0,0] and offsum==[0,0]
 assert [basis[i][1] for i in [0,4,7,9]]==[0,0,0,0]
 assert basis[0][0]==1 and basis[c['pivot_edge']]==[0,1]
 records.append({'chart':c['name'],'status':'PASS','variables':n,'generators':checks,'trace_zero':True,'tangent_entry_sum_zero':True,'diagonal_rank_exactly_one':True,'basis_independence_for_all_parameters':True,'seconds':time.monotonic()-started})
 parsed[c['name']]=(xs,basis,generators,c)
 print(c['name'],'exact symbolic direct24term coefficient audit PASS',flush=True)

field=7;planes=json.loads(Path('/tmp/oec/pequalnp-pilot-78/finitefield/f7-2planes.json').read_text())
planes=[P for P in planes if all(sum(v[i] for i in [0,4,7,9])%field==0 for v in P) and any(v[i]%field for v in P for i in [0,4,7,9])]
mapped=[]
for number,P in enumerate(planes):
 hits=[]
 for pm in perms:
  permuted=[[row[index[tuple(sorted((pm[i],pm[j])))]]%field for i,j in coords] for row in P]
  X,Y=permuted
  if not X[0]:X,Y=Y,X
  if not X[0]:continue
  scale=pow(X[0],-1,field);A=[x*scale%field for x in X]
  B=[(y-Y[0]*a)%field for y,a in zip(Y,A)]
  assert all(B[i]==0 for i in [0,4,7,9])
  for name,(xs,basis,gens,c) in parsed.items():
   edge=c['pivot_edge']
   if not B[edge]:continue
   inv=pow(B[edge],-1,field);BB=[x*inv%field for x in B]
   AA=[(a-A[edge]*b)%field for a,b in zip(A,BB)]
   values={}
   for i,row in enumerate(basis):
    for j,expr in enumerate(row):
     if expr in xs:values[expr]=(AA,BB)[j][i]
   assert len(values)==len(xs)
   assert all(int(expr.subs(values))%field==(AA,BB)[j][i] for i,row in enumerate(basis) for j,expr in enumerate(row))
   assert all(int(g.as_expr().subs(values))%field==0 for g in gens)
   hits.append({'chart':name,'permutation':pm,'parameter_values':[values[x] for x in xs]})
  if hits:break
 assert hits,(number,'uncovered finite plane')
 mapped.append({'plane_index':number,'plane':P,'chart_hits':hits})
 print('F7 plane',number,'covered by',[h['chart'] for h in hits],flush=True)
report={'status':'PASS','reviewer':'status_review','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'scope':'Exact symbolic direct24term permanent coefficient verification and complete rank-one trace-zero chart coverage, plus normalization of all eight saved F7 nonhollow trace-zero planes','coverage_argument':'For any rank-one nonzero diagonal image choose a nonzero diagonal coordinate, relabel it to00, normalize A00=1 and kill every diagonal of B. The nonzero hollow B has a nonzero edge. S3 fixing0 moves that edge to01 or12; scale B to pivot1 and subtract A-pivot times B. Trace and tangent entry sum then give exactly the manifest parameterization. Both chart normalizations force independence and diagonal image rank one for every parameter assignment.','charts':records,'finite_field':field,'finite_corpus_count':len(planes),'finite_corpus_mappings':mapped,'limitations':'This proves chart correctness and coverage, not emptiness over characteristic zero or existence of any complex nonhollow trace-zero plane.'}
(base/'rank1-independent-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print('overall PASS',flush=True)
