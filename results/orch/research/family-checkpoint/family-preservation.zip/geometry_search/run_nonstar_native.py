from pathlib import Path
import subprocess,resource,json,time,sys
base=Path('/tmp/oec/pequalnp-pilot-78');job=base/'geometry_search/nonstar_nets';stem=sys.argv[1]
def limit():
 resource.setrlimit(resource.RLIMIT_AS,(512*2**20,512*2**20));resource.setrlimit(resource.RLIMIT_CPU,(55,58));resource.setrlimit(resource.RLIMIT_FSIZE,(32*2**20,32*2**20));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
start=time.monotonic()
with (job/(stem+'.stdout')).open('w') as out,(job/(stem+'.stderr')).open('w') as err:
 try:
  p=subprocess.run([str(base/'numeric/singular/bin/Singular'),'--quiet','--no-tty','--no-rc','--no-shell','--cpus=1','--threads=1','--flint-threads=1',str(job/(stem+'.sing'))],stdin=subprocess.DEVNULL,stdout=out,stderr=err,env={'LD_LIBRARY_PATH':str(base/'numeric/singular/lib')+':'+str(base/'numeric/cas/lib'),'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'},preexec_fn=limit,timeout=60)
  result=p.returncode
 except subprocess.TimeoutExpired:result='timeout'
r={'name':stem,'exit':result,'seconds':time.monotonic()-start};(job/(stem+'.result.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
