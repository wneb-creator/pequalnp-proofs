from pathlib import Path
import json,sympy as s,itertools
b=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/nonstar_nets');D=json.loads((b/'plane2-normalized.json').read_text());t=s.symbols('t');field=s.QQ.frac_field(t)
entries=[e for key in ['basis','change'] for row in D[key] for e in row]+[e for gram in D['grams'] for row in gram for e in row];den=None
for e in entries:
 c=field.from_sympy(s.sympify(e));den=c.denom if den is None else den.lcm(c.denom)
det=field.from_sympy(s.sympify(D['determinant']));bad=den*det.numer
r={'bad_polynomial_factored':str(s.factor(bad.as_expr())),'denominator_lcm_factored':str(s.factor(den.as_expr())),'determinant_factored':str(s.factor(field.to_sympy(det))),'all_entries_checked':len(entries)}
(b/'plane2-chart-exceptions.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
C=s.Matrix([[1,0,-1,1,-2,1],[0,1,-1,-1,-1,2]]);edges=[(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)];lookup={e:i for i,e in enumerate(edges)};out=[]
for perm in itertools.permutations(range(4)):
 E=C[:,[lookup[tuple(sorted((perm[i],perm[j])))] for i,j in edges]];M=E[:,[0,1]]
 if M.det()!=0 and M*C==E:
  a=M[0,0]+t*M[1,0];bb=M[0,1]+t*M[1,1];out.append({'permutation':list(perm),'change':str(M),'newa':str(a),'newt':str(s.cancel(bb/a))})
assert len(out)==3
(b/'plane2-stabilizer.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
