import sympy as s,itertools,json,time,resource
from pathlib import Path
from sympy.polys.rings import ring
from sympy.polys.matrices import DomainMatrix
resource.setrlimit(resource.RLIMIT_AS,(512*2**20,512*2**20));resource.setrlimit(resource.RLIMIT_CPU,(110,115))
start=time.monotonic();job=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/nonstar_nets');data=json.loads((job/'plane2-normalized.json').read_text());t=s.symbols('t');field=s.QQ.frac_field(t);PR,k,l,m=ring('k,l,m',field)
polys=[PR.from_expr(s.sympify(e.replace('^','**'))) for e in data['equations']];shifts=[(0,0,0),(1,0,0),(0,1,0),(0,0,1)];columns=[(i,shift) for i in range(6) for shift in shifts]
monoms=sorted({tuple(a+b for a,b in zip(e,shift)) for i,shift in columns for e in polys[i]},key=lambda e:(sum(e),e));lookup={e:i for i,e in enumerate(monoms)}
mat=[[field.zero for _ in columns] for e in monoms]
for j,(i,shift) in enumerate(columns):
 for e,c in polys[i].items():mat[lookup[tuple(a+b for a,b in zip(e,shift))]][j]+=c
M=DomainMatrix.from_list(mat,field);print('MATRIX',M.shape,flush=True)
num=s.Matrix([[field.to_sympy(v).subs(t,2) for v in row] for row in mat]);piv=list(num.rref()[1]);print('NUMERIC PIVOTS',piv,flush=True);assert len(piv)==len(monoms)
A=M.extract(list(range(len(monoms))),piv);b=DomainMatrix.from_list([[field.one if e==(0,0,0) else field.zero] for e in monoms],field);aug=A.hstack(b);den,anum=aug.clear_denoms_rowwise(convert=True);n=len(monoms);AA=anum.extract(list(range(n)),list(range(n)));bb=anum.extract(list(range(n)),[n]);print('POLYNOMIAL SOLVE START',AA.domain,flush=True)

cs=s.symbols('c0:'+str(n));alg=AA.to_Matrix();rhs=bb.to_Matrix();lines=[str(s.Poly(s.expand(sum(alg[i,j]*cs[j] for j in range(n))-rhs[i,0]),*cs,t).clear_denoms()[1].as_expr()).replace('**','^') for i in range(n)]
script='ring R=(0,t),('+','.join(map(str,cs))+'),dp;\nshort=0;option(redSB);\nideal I='+','.join(lines)+';\nideal G=std(I);\nprint("BASIS_SIZE");size(G);print("DIMENSION");dim(G);list sol;for(int j=1;j<=nvars(basering);j++){sol[j]=reduce(var(j),G);print("SOLUTION");print(sol[j]);}\nfor(int i=1;i<=size(I);i++){poly r=I[i];for(int h=1;h<=nvars(basering);h++){r=subst(r,var(h),sol[h]);}print("RESIDUAL");print(r);}quit;\n'
(job/'plane2-macaulay-linear.sing').write_text(script)
(job/'plane2-macaulay-linear-metadata.json').write_text(json.dumps({'selected_columns':piv,'columns':[(i,list(e)) for i,e in columns],'monomials':monoms,'number_equations':n},indent=2)+'\n')
print('NATIVE_INPUT_READY',len(script),flush=True)
