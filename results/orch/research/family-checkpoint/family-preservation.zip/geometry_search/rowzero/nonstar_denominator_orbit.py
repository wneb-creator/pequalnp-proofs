from pathlib import Path
import sympy as S,json,time,resource
resource.setrlimit(resource.RLIMIT_AS,(512*2**20,512*2**20));resource.setrlimit(resource.RLIMIT_CPU,(58,60))
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero');start=time.monotonic()
t=S.symbols('t')
data=json.loads((base.parent/'nonstar_nets/plane2-macaulay-verified.json').read_text())
D=S.sympify(data['common_denominator'],locals={'t':t});num,den=S.fraction(S.cancel(D))
N=S.Poly(num,t,domain=S.QQ);Q=S.Poly(den,t,domain=S.QQ)
B=S.Poly(t*(t-1)*(t+1)*(t+2)*(2*t+1)*(t*t+t+1)*(6*t*t-2*t-1)*(t**3+3*t*t-1),t,domain=S.QQ)
P=N*Q*B
print('RAW_DEGREES',N.degree(),Q.degree(),B.degree(),flush=True)
P=P.sqf_part().monic()
print('SQUAREFREE_DEGREE',P.degree(),flush=True)
f=P.transform(S.Poly(-t-1,t),S.Poly(t,t)).sqf_part().monic()
g=P.transform(S.Poly(-1,t),S.Poly(t+1,t)).sqf_part().monic()
G12=S.gcd(P,f);G=S.gcd(G12,g)
conservative=S.gcd(S.gcd(P,f*S.Poly(t,t)),g*S.Poly(t+1,t)).monic()
print('GCD_DEGREES',G12.degree(),G.degree(),conservative.degree(),flush=True)
print('EXACT_GCD',S.factor(G.as_expr()),flush=True)
print('CONSERVATIVE_GCD',S.factor(conservative.as_expr()),flush=True)
known=S.Poly(t*(t+1)*(t-1)*(t+2)*(2*t+1)*(t*t+t+1)*(t**3+3*t*t-1),t,domain=S.QQ)
extra=S.exquo(conservative,S.gcd(conservative,known)).monic()
assert S.rem(P,conservative).is_zero
assert S.rem(f*S.Poly(t,t),conservative).is_zero
assert S.rem(g*S.Poly(t+1,t),conservative).is_zero
report={'status':'PASS','raw_degrees':[N.degree(),Q.degree(),B.degree()],
 'squarefree_bad':str(P.as_expr()),'transform1':str(f.as_expr()),'transform2':str(g.as_expr()),
 'gcd':str(G.as_expr()),'conservative_gcd':str(conservative.as_expr()),
 'gcd_factored':str(S.factor(conservative.as_expr())),'extra_factor':str(S.factor(extra.as_expr())),
 'scope':'conservative transforms include Mobius denominator roots t=0,-1',
 'seconds':time.monotonic()-start}
(base/'nonstar-denominator-orbit.json').write_text(json.dumps(report,indent=2)+'\n')
print('EXTRA',report['extra_factor'],flush=True);print('DONE',report['seconds'],flush=True)
