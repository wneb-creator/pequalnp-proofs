from pathlib import Path
import sympy as S,json,time
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero');start=time.monotonic()
k,mu,T,w=S.symbols('k mu T w');local={str(v):v for v in [k,mu,T,w]}
line=next(v for v in (base/'bipartite-reduced-row.sing').read_text().splitlines() if v.startswith('ideal I='))
P0,P1,P2,_=[S.sympify(e.replace('^','**'),locals=local) for e in line[8:-1].split(',')]
C=S.sympify(json.loads((base/'bipartite-extra-row.json').read_text())['polynomial'],locals=local)
L=[S.expand(2*P1-k*P2),S.expand(C-(T+1)*(7*k-18)*P2),S.expand(2*P0-k*k*(9*k*k-8)*(T+1)**2*P2)]
assert all(S.degree(e,mu)<=1 for e in L)
coeff=[[S.factor(S.Poly(e,mu).coeff_monomial(mu)),S.factor(S.Poly(e,mu).coeff_monomial(1))] for e in L]
for i,c in enumerate(coeff):print('LINEAR',i,c,flush=True)
det=[]
for i,j in [(0,1),(0,2),(1,2)]:
 value=S.factor(coeff[i][0]*coeff[j][1]-coeff[j][0]*coeff[i][1]);det.append(value)
 print('DET',i,j,value,flush=True)
(base/'bipartite-linear-reduction.json').write_text(json.dumps({'linears':list(map(str,L)),'determinants':list(map(str,det))},indent=2)+'\n')
print('DONE',time.monotonic()-start,flush=True)
