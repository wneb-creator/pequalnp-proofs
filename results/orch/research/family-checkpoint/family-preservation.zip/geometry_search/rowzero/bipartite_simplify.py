from pathlib import Path
import sympy as S,itertools,json,time,resource
resource.setrlimit(resource.RLIMIT_AS,(512*2**20,512*2**20))
resource.setrlimit(resource.RLIMIT_CPU,(58,60))
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero')
t,M,P,Q,X,Y,U=S.symbols('t M P Q X Y U')
p=(P+X)/2;s=(P-X)/2;q=(Q+Y)/2;r=(Q-Y)/2
k=(t*t-1)**2/(4*t*t)
C=(P-U)/2;D=(Q+k*U)/2
a=t-1;b=t*(t-1);e=t+1;f=-t*(t+1)
F2=S.factor(M*M+f*f*p*q+e*e*p*r+b*b*q*s+a*a*r*s+2*D*(p*e*f+s*a*b)+2*C*(q*b*f+r*a*e))
print('QUARTIC_QUAD',S.collect(S.expand(F2),[P,Q,X,Y,U]),flush=True)
for v in [P,Q,X,Y,U]:print('PART',v,S.factor(S.diff(F2,v)),flush=True)
G=S.hessian(F2,[P,Q,X,Y,U])/2
print('KERNEL',G.nullspace(),flush=True)
# Since M remains free, use X,Y,U and set P=Q=0 for the nondegenerate part if valid.
print('PRINCIPAL',S.factor(G.extract([2,3,4],[2,3,4]).det()),flush=True)
print('SUBFORM',S.factor(F2.subs({P:0,Q:0})),flush=True)
