from pathlib import Path
import sympy as S,json,itertools,time,resource,sys
from sympy.polys.rings import ring
from sympy.polys.domains import QQ
resource.setrlimit(resource.RLIMIT_AS,(512*2**20,512*2**20));resource.setrlimit(resource.RLIMIT_CPU,(58,60))
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero');start=time.monotonic();tag=sys.argv[1] if len(sys.argv)>1 else 'cubic'
t,k,l,m=S.symbols('t k l m');local={'t':t,'k':k,'l':l,'m':m}
data=json.loads((base/f'nonstar-exception-{tag}.json').read_text())
cert=json.loads((base/f'nonstar-{tag}-certificate-d3.json').read_text())
Q,tt,kk,ll,mm=ring('t,k,l,m',QQ)
parseq=lambda e:Q.from_expr(S.sympify(e,locals=local))
actual=sum((parseq(a)*parseq(b) for a,b in zip(cert['inputs'],cert['integer_certificates'])),Q.zero)
actual+=parseq(cert['parameter_multiplier'])*parseq(cert['parameter_polynomial'])
assert actual==int(cert['target'])
print('INTEGER_CERTIFICATE_PASS',flush=True)
minpoly=t**3+3*t*t-1 if tag=='cubic' else t*t+t+1
F=QQ.algebraic_field((S.Poly(minpoly,t),t));alpha=F([1,0])
def cv(text):
 e=S.sympify(text,locals=local)
 return sum((F.from_sympy(c)*alpha**p[0] for p,c in S.Poly(e,t).terms()),F.zero)
R,K,L,M,a,b,u,z=ring('k,l,m,a,b,u,z',F)
def parsegraph(text):
 e=S.sympify(text,locals=local)
 return R.from_dict({powers+(0,0,0,0):cv(c) for powers,c in S.Poly(e,k,l,m).terms()})
B=[[cv(e) for e in row] for row in data['basis']]
C=[[cv(e) for e in row] for row in data['change']]
actualbasis=[[sum((B[i][j]*C[j][h] for j in range(5)),F.zero) for h in range(5)] for i in range(10)]
canonical=[K*b,-K*a,a,b,L*a+M*b]
entries=[sum((coef*x for coef,x in zip(row,canonical)),R.zero) for row in actualbasis]
coords=list(itertools.combinations_with_replacement(range(4),2));edges=list(itertools.combinations(range(4),2))
hs=[F.one,alpha,-1-alpha,1-alpha,-2-alpha,1+2*alpha]
mat=[[R.one for j in range(4)] for i in range(4)]
for (i,j),h in zip(edges,hs):mat[i][j]+=u*h;mat[j][i]+=u*h
for (i,j),e in zip(coords,entries):
 mat[i][j]+=z*e
 if i!=j:mat[j][i]+=z*e
permanent=R.zero
for mask in range(16):
 subset=[j for j in range(4) if mask>>j&1]
 term=R.one
 for i in range(4):term*=sum((mat[i][j] for j in subset),R.zero)
 permanent+=(-1)**(4-len(subset))*term
for eu in range(4):
 coef=R.from_dict({p[:-2]+(0,0):c for p,c in permanent.items() if p[-2:]==(eu,1)})
 assert coef==0
for eu in range(3):
 coef=R.from_dict({p[:-2]+(0,0):c for p,c in permanent.items() if p[-2:]==(eu,2)})
 expected=R.zero if eu==2 else sum((parsegraph(data['graph_equations'][3*eu+j])*mon for j,mon in enumerate([a*a,a*b,b*b])),R.zero)
 assert coef==expected
report={'status':'PASS','integer_certificate_identity':True,'exact_ryser_over_number_field':tag,
 'four_linear_coefficients':True,'six_graph_equations':True,'quartic_graph_quadric_zero':True,
 'seconds':time.monotonic()-start}
(base/f'nonstar-{tag}-independent-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
