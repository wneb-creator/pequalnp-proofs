from pathlib import Path
import sympy as S,itertools,json,time,resource
resource.setrlimit(resource.RLIMIT_AS,(512*2**20,512*2**20))
resource.setrlimit(resource.RLIMIT_CPU,(58,60))
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero')
start=time.monotonic()
t,u,z=S.symbols('t u z')
vs=S.symbols('v0:10')
coords=list(itertools.combinations_with_replacement(range(4),2))
edges=list(itertools.combinations(range(4),2))
H=S.zeros(4);V=S.zeros(4)
hs=[t-1,t*(t-1),0,0,t+1,-t*(t+1)]
for (i,j),v in zip(edges,hs):H[i,j]=H[j,i]=v
for (i,j),v in zip(coords,vs):V[i,j]=V[j,i]=v
P=S.Poly(S.expand(sum(S.prod(1+u*H[i,j]+z*V[i,j] for i,j in enumerate(pm)) for pm in itertools.permutations(range(4)))-24),u,z)
assert all(P.coeff_monomial(u**i)==0 for i in range(5))
lin=[S.factor(P.coeff_monomial(u**i*z)) for i in range(4)]
for i,e in enumerate(lin):print('LIN',i,e,flush=True)
A=S.linear_eq_to_matrix(lin+[vs[1]],vs)[0]
N=A.nullspace();assert len(N)==6
basis=S.Matrix.hstack(*N)
denoms=sorted(set(str(S.factor(S.denom(v))) for v in basis))
print('DENOMS',denoms,flush=True)
print('BASIS',basis,flush=True)
xs=S.symbols('x0:6');sub=dict(zip(vs,basis*S.Matrix(xs)))
quad=[S.factor(P.coeff_monomial(u**i*z*z).subs(sub)) for i in range(3)]
extra=[S.factor(P.coeff_monomial(z**3).subs(sub)),S.factor(P.coeff_monomial(u*z**3).subs(sub)),S.factor(P.coeff_monomial(z**4).subs(sub))]
for i,q in enumerate(quad):
 print('QUAD',i,q,flush=True)
 print('SAMPLE RANK',i,S.hessian(q,xs).subs(t,2).rank(),flush=True)
for i,e in enumerate(extra):print('EXTRA',i,e,flush=True)
report={'scope':'explicit bipartite support c=d=0 only','H':list(map(str,hs)),'coords':coords,
 'linear':list(map(str,lin)),'basis':[[str(v) for v in row] for row in basis.tolist()],
 'denominators':denoms,'quadrics':list(map(str,quad)),'extra':list(map(str,extra)),
 'seconds':time.monotonic()-start}
(base/'bipartite-net.json').write_text(json.dumps(report,indent=2)+'\n')
print('DONE',report['seconds'],flush=True)
