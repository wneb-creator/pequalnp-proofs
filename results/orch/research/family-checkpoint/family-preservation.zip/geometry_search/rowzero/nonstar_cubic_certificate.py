from pathlib import Path
import sympy as S,itertools,json,time,resource,sys,math
from sympy.polys.matrices import DomainMatrix
from sympy.polys.rings import ring
resource.setrlimit(resource.RLIMIT_AS,(512*2**20,512*2**20));resource.setrlimit(resource.RLIMIT_CPU,(58,60))
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero');start=time.monotonic();degree=int(sys.argv[1]);tag=sys.argv[2] if len(sys.argv)>2 else 'cubic'
t,k,l,m=S.symbols('t k l m');f=t**3+3*t*t-1 if tag=='cubic' else t*t+t+1
field=S.QQ.algebraic_field((S.Poly(f,t),t));alpha=field([1,0])
def convert(e):return sum((field.from_sympy(c)*alpha**p[0] for p,c in S.Poly(e,t).terms()),field.zero)
data=json.loads((base/f'nonstar-exception-{tag}.json').read_text())
inputs=[S.Poly(S.sympify(e,locals={'t':t,'k':k,'l':l,'m':m}),t,k,l,m).clear_denoms()[1].primitive()[1].as_expr() for e in data['graph_equations']]
polys=[]
for e in inputs:polys.append({p:convert(c) for p,c in S.Poly(e,k,l,m).terms()})
def monomials(maxdegree):
 return [(a,b,d-a-b) for d in range(maxdegree+1) for a in range(d+1) for b in range(d-a+1)]
mons=monomials(degree);index={p:i for i,p in enumerate(mons)};cols=[];description=[]
for i,p in enumerate(polys):
 for shift in monomials(degree-max(map(sum,p))):
  cols.append({index[tuple(a+b for a,b in zip(mon,shift))]:c for mon,c in p.items()})
  description.append((i,shift))
n=len(cols);rows={}
for j,col in enumerate(cols):
 for i,c in col.items():rows.setdefault(i,{})[j]=c
rows.setdefault(index[(0,0,0)],{})[n]=field.one
mat=DomainMatrix(rows,(len(mons),n+1),field)
print('MATRIX',len(mons),n,flush=True)
rr,pivots=mat.rref()
if n in pivots:print('NO_SOLUTION',degree,flush=True);sys.exit(0)
rowlist=rr.to_list();solution=[field.zero]*n
for i,j in enumerate(pivots):solution[j]=rowlist[i][n]
cert=[S.Integer(0)]*len(inputs)
for c,(i,powers) in zip(solution,description):cert[i]+=field.to_sympy(c)*k**powers[0]*l**powers[1]*m**powers[2]
cert=list(map(S.expand,cert))
denom=math.lcm(*(int(c.q) for e in cert for c in S.Poly(e,t,k,l,m).coeffs()))
cert=[S.expand(denom*e) for e in cert]
difference=S.expand(sum(a*b for a,b in zip(inputs,cert))-denom)
quotient,remainder=S.div(difference,f,t)
assert S.expand(remainder)==0
assert S.expand(sum(a*b for a,b in zip(inputs,cert))-quotient*f)==denom
report={'status':'PASS','scope':tag+' exceptional parameter graph over constant-diagonal space',
 'variables':['t','k','l','m'],'parameter_polynomial':str(f),'inputs':list(map(str,inputs)),
 'integer_certificates':list(map(str,cert)),'parameter_multiplier':str(-quotient),
 'target':str(denom),'degree':degree,'terms':[len(S.Poly(e,t,k,l,m).terms()) if e else 0 for e in cert],
 'seconds':time.monotonic()-start}
text=json.dumps(report,indent=2)+'\n';(base/f'nonstar-{tag}-certificate-d{degree}.json').write_text(text)
print(json.dumps({'status':'PASS','bytes':len(text),'terms':report['terms'],'target':str(denom),'seconds':report['seconds']}),flush=True)
