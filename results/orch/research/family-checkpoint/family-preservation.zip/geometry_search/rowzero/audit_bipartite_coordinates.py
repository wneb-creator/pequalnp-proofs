from pathlib import Path
import sympy as S,itertools,json,time
from sympy.polys.rings import ring
from sympy.polys.domains import QQ
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero');start=time.monotonic()
t,U,V,Z,W,R,N=S.symbols('t U V Z W R N');xs=[U,V,Z,W,R,N]
local={str(x):x for x in [t]+xs}
data=json.loads((base/'bipartite-canonical.json').read_text())
entries=[S.sympify(e,locals=local) for e in data['entries']]
quadrics=[S.sympify(e,locals=local) for e in data['quadrics']]
coords=list(itertools.combinations_with_replacement(range(4),2))
samples=[2,-2,3,-3,S.Rational(1,2),S.Rational(-1,2),S.Rational(3,2)]
P,*gens=ring('U,V,Z,W,R,N,h,z',QQ);h,z=gens[-2:]
reports=[]
for tv in samples:
    H=S.zeros(4)
    for (i,j),a in zip(itertools.combinations(range(4),2),[tv-1,tv*(tv-1),0,0,tv+1,-tv*(tv+1)]):H[i,j]=H[j,i]=a
    M=[[P.one+h*int(H[i,j]) if H[i,j].is_Integer else P.one+h*QQ(H[i,j].p,H[i,j].q) for j in range(4)] for i in range(4)]
    for (i,j),e in zip(coords,entries):
        value=P.from_expr(e.subs(t,tv))
        M[i][j]+=z*value
        if i!=j:M[j][i]+=z*value
    permanent=P.zero
    for mask in range(16):
        subset=[j for j in range(4) if mask>>j&1]
        term=P.one
        for i in range(4):term*=sum((M[i][j] for j in subset),P.zero)
        permanent+=(-1)**(4-len(subset))*term
    for eh in range(4):
        actual=P.from_dict({powers[:-2]+(0,0):c for powers,c in permanent.items() if powers[-2:]==(eh,1)})
        assert actual==0
    for eh in range(3):
        actual=P.from_dict({powers[:-2]+(0,0):c for powers,c in permanent.items() if powers[-2:]==(eh,2)})
        assert actual==P.from_expr(quadrics[eh].subs(t,tv))
    reports.append({'t':str(tv),'all_four_linear_coefficients':True,'three_quadrics':True})
    print(json.dumps(reports[-1]),flush=True)
# Exact symbolic ruling-swap identity under vertex permutation (0 1)(2 3).
matrix=S.zeros(4)
for (i,j),e in zip(coords,entries):matrix[i,j]=matrix[j,i]=e
perm=[1,0,3,2];M=matrix.extract(perm,perm);tt=(t+1)/(t-1)
PP=M[0,0]+M[3,3];QQv=M[1,1]+M[2,2]
XX=M[0,0]-M[3,3];YY=M[1,1]-M[2,2]
new=[PP-2*M[0,3],(tt*tt-1)*XX+tt*YY,(tt*tt-1)*XX+4*tt*YY,
     (tt*tt-1)**2*(PP-QQv)/2+(tt**4-1)*(tt*tt-1)*XX/(4*tt)-(tt**4-1)*YY/2]
kappa=(t*t-1)**2/(4*t*t)
expected=[-kappa*U,Z/(t-1)**2,4*V/(t-1)**2,-4*W/(kappa*(t-1)**4)]
assert all(S.cancel(a-b)==0 for a,b in zip(new,expected))
report={'status':'PASS','method':'Exact Ryser polynomial at seven rational parameters plus exact symbolic ruling-swap identity',
 'samples':reports,'ruling_swap_exact':True,'seconds':time.monotonic()-start}
(base/'bipartite-coordinate-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','seconds':report['seconds']}),flush=True)
