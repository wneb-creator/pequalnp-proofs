from pathlib import Path
import sympy as S,itertools,json,time,resource
resource.setrlimit(resource.RLIMIT_AS,(512*2**20,512*2**20))
resource.setrlimit(resource.RLIMIT_CPU,(58,60))
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero')
start=time.monotonic();t,z,h=S.symbols('t z h')
U,V,Z,W,R,N=S.symbols('U V Z W R N');xs=(U,V,Z,W,R,N)
T2=t*t-1;k=T2*T2/(4*t*t)
X=(4*V-Z)/(3*T2);Y=(Z-V)/(3*t)
delta=(2*W-(t**4-1)*T2*X/(2*t)+(t**4-1)*Y)/(T2*T2)
P=(R+delta)/2;Q=(R-delta)/2
p=(P+X)/2;s=(P-X)/2;q=(Q+Y)/2;r=(Q-Y)/2
C=(P-U)/2;D=(Q+k*U)/2;m=T2*X+2*t*Y
L=-N-P-Q-(k-1)*U/2
B=(m-(t-1)*L-t*(t-1)*N)/2;F=L-B
entries=[p,0,B,C,q,D,N,r,F,s]
entries=[S.cancel(v) for v in entries]
coords=list(itertools.combinations_with_replacement(range(4),2))
edges=list(itertools.combinations(range(4),2))
H=S.zeros(4)
for (i,j),v in zip(edges,[t-1,t*(t-1),0,0,t+1,-t*(t+1)]):H[i,j]=H[j,i]=v
vs=S.symbols('v0:10');M=S.zeros(4)
for (i,j),v in zip(coords,vs):M[i,j]=M[j,i]=v
full=S.Poly(S.expand(sum(S.prod(1+h*H[i,j]+z*M[i,j] for i,j in enumerate(pm)) for pm in itertools.permutations(range(4)))-24),h,z)
basis=S.Matrix([[S.diff(v,x) for x in xs] for v in entries])
for i in range(4):
 lin=full.coeff_monomial(h**i*z)
 assert all(S.cancel(v)==0 for v in (S.Matrix([[S.diff(lin,v) for v in vs]])*basis))
quad=[];mats=[]
for i in range(3):
 g=S.hessian(full.coeff_monomial(h**i*z*z),vs)/2
 mat=basis.T*g*basis
 mat=mat.applyfunc(lambda v:S.factor(S.cancel(v)))
 mats.append(mat)
 form=S.Add(*[mat[j,j]*xs[j]**2 for j in range(6)],*[2*mat[j,k]*xs[j]*xs[k] for j in range(6) for k in range(j+1,6)])
 quad.append(form)
 print('FORM',i,S.factor(form.subs({U:0,V:0,Z:0,W:0})),flush=True)
 print('MATRIX',i,mat,flush=True)
assert S.cancel(quad[2]-(V*Z-U*W))==0
qrad=[S.factor(form.subs({U:0,V:0,Z:0,W:0})) for form in quad[:2]]
print('RADICAL RESULTANT',S.factor(S.resultant(qrad[0],qrad[1],N)),flush=True)
rad_sub=dict(zip(vs,[S.factor(v.subs({U:0,V:0,Z:0,W:0})) for v in entries]))
rad_extra=[]
for eh,ez in [(0,3),(1,3),(0,4)]:
 value=S.factor(full.coeff_monomial(h**eh*z**ez).subs(rad_sub))
 rad_extra.append(value)
 print('RADICAL EXTRA',eh,ez,value,flush=True)
 print('RADICAL EXTRA RESULTANT',eh,ez,S.factor(S.resultant(qrad[0],value,R)),flush=True)
report={'scope':'bipartite t!=0,1,-1','variables':list(map(str,xs)),
 'entries':list(map(str,entries)),'quadrics':list(map(str,quad)),
 'matrices':[[[str(v) for v in row] for row in mat.tolist()] for mat in mats],
 'radical_forms':list(map(str,qrad)),'radical_extra':list(map(str,rad_extra)), 'seconds':time.monotonic()-start}
(base/'bipartite-canonical.json').write_text(json.dumps(report,indent=2)+'\n')
print('DONE',report['seconds'],flush=True)
