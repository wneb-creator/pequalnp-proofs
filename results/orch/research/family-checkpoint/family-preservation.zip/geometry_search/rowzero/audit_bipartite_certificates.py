from pathlib import Path
import sympy as S,json,time,sys
from sympy.polys.rings import ring
from sympy.polys.domains import QQ
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero');start=time.monotonic()
tag=sys.argv[1]
data=json.loads((base/('bipartite-certificate-'+tag+'.inputs.json')).read_text())
variables=data['variables'];R,*gens=ring(','.join(variables),QQ)
local=dict(zip(variables,S.symbols(' '.join(variables))))
parse=lambda text:R.from_expr(S.sympify(text.replace('^','**'),locals=local))
eq=[parse(p) for p in data['equations']]
lines=(base/('bipartite-certificate-'+tag+'.stdout')).read_text().splitlines()
assert lines[-2:]==['RESIDUAL','0']
index=lines.index('CERTIFICATE')+1
cert=[]
for j in range(len(eq)):
 assert lines[index:index+2]==['ENTRY',str(j+1)]
 cert.append(parse(lines[index+2]));index+=3
target=parse(lines[lines.index('TARGET')+1]) if 'TARGET' in lines else R.one
assert sum((e*c for e,c in zip(eq,cert)),R.zero)==target
report={'status':'PASS','tag':tag,'identity':'sum(input_i*certificate_i)=target over QQ','target':str(target),
 'certificate_term_counts':list(map(len,cert)),'seconds':time.monotonic()-start}
(base/('bipartite-certificate-'+tag+'-audit.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
