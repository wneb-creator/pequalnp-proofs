from pathlib import Path
import sympy as S,json,time,resource,os,subprocess,sys
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero');numeric=base.parents[1]/'numeric'
t,k,n1,mu,T,w=S.symbols('t k n1 mu T w');local={str(x):x for x in [t,k,n1]}
data=json.loads((base/'bipartite-eliminated.json').read_text())
tag=sys.argv[1];item=next(x for x in data if x['tag']==tag)
equations=[]
for text in item['equations']:
 n1value=mu/(t*(t-1)*(t*t-1)) if tag=='rowinf' else mu/((t-1)*(t*t-1)**2)
 e=S.cancel(S.sympify(text,locals=local).subs(n1,n1value))
 factors=S.factor_list(S.fraction(e)[0],t,k,mu)[1]
 e=S.prod(f**n for f,n in factors if f not in [t,t-1,t+1,t*t+1,k])
 poly=S.Poly(S.expand(e),t,k,mu)
 assert all(p[0]%2==0 for p,c in poly.terms())
 e=S.Add(*[c*T**(p[0]//2)*k**p[1]*mu**p[2] for p,c in poly.terms()])
 equations.append(e)
 print('POLY',tag,S.factor(e),flush=True)
if tag=='rowinf':
 extra=json.loads((base/('bipartite-extra-'+tag+'.json')).read_text())['polynomial']
 equations.append(S.sympify(extra,locals={str(v):v for v in [k,mu,T]}))
 equations.append(w*T*(T-1)*(T+1)-1)
else:equations.append(w*k*T*(T-1)*(T+1)-1)
name='bipartite-reduced-'+tag
initial='ideal I='+','.join(str(e).replace('**','^') for e in equations)+';\n'
if len(sys.argv)>2 and sys.argv[2]=='extra':
 extra=json.loads((base/('bipartite-extra-'+tag+'.json')).read_text())['polynomial']
 old=(base/(name+'.stdout')).read_text().splitlines()
 assert old[:5]==['BASIS_SIZE','35','DIMENSION','0','BASIS']
 initial='ideal B='+','.join(old[5:])+';\npoly f='+extra.replace('**','^')+';\nf=reduce(f,B);\nideal I=B,f;\n'
 name+='-extra'
ringvars='mu,T,w' if tag=='rowinf' else 'k,mu,T,w'
script='ring r=0,('+ringvars+'),dp;\noption(redSB);\n'+initial+'ideal G=std(I);\nshort=0;print("BASIS_SIZE");size(G);print("DIMENSION");dim(G);print("BASIS");for(int ii=1;ii<=size(G);ii++){print(string(G[ii]));}quit;\n'
(base/(name+'.sing')).write_text(script)
env=os.environ.copy();env['LD_LIBRARY_PATH']=str(numeric/'singular/lib')+':'+str(numeric/'cas/lib')
env['OPENBLAS_NUM_THREADS']='1';env['OMP_NUM_THREADS']='1'
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(512*2**20,512*2**20))
 resource.setrlimit(resource.RLIMIT_CPU,(58,60))
 resource.setrlimit(resource.RLIMIT_FSIZE,(16*2**20,16*2**20))
 resource.setrlimit(resource.RLIMIT_CORE,(0,0))
start=time.monotonic()
with (base/(name+'.stdout')).open('w') as out,(base/(name+'.stderr')).open('w') as err:
 try:
  process=subprocess.run([str(numeric/'singular/bin/Singular'),'--quiet','--no-tty','--no-rc','--no-shell','--cpus=1','--threads=1','--flint-threads=1',str(base/(name+'.sing'))],stdin=subprocess.DEVNULL,stdout=out,stderr=err,env=env,preexec_fn=limits,timeout=60)
  code=process.returncode
 except subprocess.TimeoutExpired:code='timeout'
result={'tag':tag,'seconds':time.monotonic()-start,'exit':code}
(base/(name+'.result.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
