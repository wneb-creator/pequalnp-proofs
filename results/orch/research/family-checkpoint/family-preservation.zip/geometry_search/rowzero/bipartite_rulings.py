from pathlib import Path
import sympy as S,json,itertools,resource,time
resource.setrlimit(resource.RLIMIT_AS,(512*2**20,512*2**20))
resource.setrlimit(resource.RLIMIT_CPU,(58,60))
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero')
data=json.loads((base/'bipartite-canonical.json').read_text())
t,U,V,Z,W,R,N=S.symbols('t U V Z W R N')
a,b,l,r0,r1,n0,n1=S.symbols('a b l r0 r1 n0 n1')
variables=[r0,r1,n0,n1]
quad=[S.sympify(q,locals={str(v):v for v in [t,U,V,Z,W,R,N]}) for q in data['quadrics'][:2]]
reports=[]
for tag,p in [('row',[l*a,l*b,a,b]),('col',[l*a,a,l*b,b]),('rowinf',[a,b,0,0]),('colinf',[a,0,b,0])]:
 sub=dict(zip([U,V,Z,W],p));sub[R]=r0*a+r1*b;sub[N]=n0*a+n1*b
 coeff=[]
 for q in quad:
  poly=S.Poly(S.expand(q.subs(sub)),a,b)
  coeff.append([S.factor(S.cancel(poly.coeff_monomial(mon))) for mon in [a*a,a*b,b*b]])
 lin,rhs=S.linear_eq_to_matrix(coeff[1],variables)
 print('TAG',tag,flush=True)
 print('LINEAR',lin,rhs,flush=True)
 print('MINORS',[(str(v),S.factor(lin[:,list(inds)].det())) for inds in itertools.combinations(range(4),3) for v in [inds]],flush=True)
 eq=[S.Poly(S.fraction(S.cancel(q))[0],l,r0,r1,n0,n1,t).primitive()[1].as_expr() for qs in coeff for q in qs]
 reports.append({'tag':tag,'parameters':list(map(str,[l,r0,r1,n0,n1])),
   'substitution':dict((str(k),str(v)) for k,v in sub.items()),
   'equations':list(map(str,eq)), 'q1':list(map(str,coeff[1]))})
(base/'bipartite-rulings.json').write_text(json.dumps(reports,indent=2)+'\n')
