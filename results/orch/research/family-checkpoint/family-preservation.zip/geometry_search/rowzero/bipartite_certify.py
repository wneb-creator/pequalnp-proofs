from pathlib import Path
import json,os,sys,subprocess,resource,time
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero');numeric=base.parents[1]/'numeric'
tag=sys.argv[1];name='bipartite-certificate-'+tag
source_tag='row' if tag in ['rowshort','rowordered'] else tag
if tag in ['palindrome','palplain']:
 data=json.loads((base/'bipartite-palindrome.inputs.json').read_text())
 variables=data['variables'];ring='ring r=0,('+','.join(variables)+'),dp;'
 equations=[e.replace('**','^') for e in data['equations']]
 if tag=='palplain':variables=variables[:2];ring='ring r=0,('+','.join(variables)+'),dp;';equations=equations[:4]
else:
 source=(base/('bipartite-reduced-'+source_tag+'.sing')).read_text().splitlines()
 ring=source[0]
 line=next(s for s in source if s.startswith('ideal I='))
 equations=line[8:-1].split(',')
 variables=['k','mu','T','w'] if source_tag=='row' else ['mu','T','w']
if source_tag=='row':equations.append(json.loads((base/'bipartite-extra-row.json').read_text())['polynomial'].replace('**','^'))
if tag=='rowshort':equations=[equations[i] for i in [2,1,4,3]]
if tag=='rowordered':equations=[equations[i] for i in [2,1,4,3,0]]
(base/(name+'.inputs.json')).write_text(json.dumps({'variables':variables,'equations':equations},indent=2)+'\n')
script=ring+'\noption(redSB);\nideal I='+','.join(equations)+';\nmatrix C;ideal G=liftstd(I,C);\nshort=0;print("BASIS_SIZE");size(G);print("BASIS");print(G);\n'
script+='if(size(G)==1 && deg(G[1])==0 && G[1]!=0){matrix D=lift(G,ideal(1));matrix W=C*D;print("CERTIFICATE");for(int ii=1;ii<=nrows(W);ii++){print("ENTRY");ii;print(string(W[ii,1]));}print("RESIDUAL");print(matrix(I)*W-matrix(ideal(1)));}\nquit;\n'
if tag=='palplain':
 script=ring+'\noption(redSB);\nideal I='+','.join(equations)+';\nideal G=std(I);short=0;print("BASIS_SIZE");size(G);print("DIMENSION");dim(G);print("BASIS");print(G);\n'
 script+='poly f=k*(v*v-4);int exponent=0;for(int ee=1;ee<=16;ee++){if(reduce(f^ee,G)==0){exponent=ee;break;}}print("EXPONENT");exponent;if(exponent>0){poly target=f^exponent;matrix W=lift(I,ideal(target));print("TARGET");print(string(target));print("CERTIFICATE");for(int ii=1;ii<=nrows(W);ii++){print("ENTRY");ii;print(string(W[ii,1]));}print("RESIDUAL");print(matrix(I)*W-matrix(ideal(target)));}\nquit;\n'
(base/(name+'.sing')).write_text(script)
env=os.environ.copy();env['LD_LIBRARY_PATH']=str(numeric/'singular/lib')+':'+str(numeric/'cas/lib')
env['OPENBLAS_NUM_THREADS']='1';env['OMP_NUM_THREADS']='1'
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(512*2**20,512*2**20));resource.setrlimit(resource.RLIMIT_CPU,(58,60))
 resource.setrlimit(resource.RLIMIT_FSIZE,(16*2**20,16*2**20));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
start=time.monotonic()
with (base/(name+'.stdout')).open('w') as out,(base/(name+'.stderr')).open('w') as err:
 try:
  process=subprocess.run([str(numeric/'singular/bin/Singular'),'--quiet','--no-tty','--no-rc','--no-shell','--cpus=1','--threads=1','--flint-threads=1',str(base/(name+'.sing'))],stdin=subprocess.DEVNULL,stdout=out,stderr=err,env=env,preexec_fn=limits,timeout=60)
  code=process.returncode
 except subprocess.TimeoutExpired:code='timeout'
result={'tag':tag,'seconds':time.monotonic()-start,'exit':code}
(base/(name+'.result.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
