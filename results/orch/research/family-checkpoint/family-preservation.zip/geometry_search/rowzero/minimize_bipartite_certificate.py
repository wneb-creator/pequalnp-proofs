from pathlib import Path
import sympy as S,json,time,resource,sys
from sympy.polys.rings import ring
from sympy.polys.domains import ZZ,QQ
from sympy.polys.matrices import DomainMatrix
resource.setrlimit(resource.RLIMIT_AS,(512*2**20,512*2**20));resource.setrlimit(resource.RLIMIT_CPU,(58,60))
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero');start=time.monotonic()
degree=int(sys.argv[1]);target_name=sys.argv[2] if len(sys.argv)>2 else 'k5'
k,v,y=S.symbols('k v y');local={'k':k,'v':v}
data=json.loads((base/'bipartite-palindrome.inputs.json').read_text())
ring0,kk,yy=ring('k,y',ZZ)
polys=[ring0.from_expr(S.expand(S.sympify(e,locals=local).subs(v,y-2))) for e in data['equations'][:4]]
target=kk**5 if target_name=='k5' else yy**2
mons=[(a,d-a) for d in range(degree+1) for a in range(d+1)]
index={p:i for i,p in enumerate(mons)}
columns=[];description=[]
for j,p in enumerate(polys):
    bound=degree-max(map(sum,p))
    for d in range(bound+1):
        for a in range(d+1):
            shift=(a,d-a)
            columns.append({index[(x+a,z+d-a)]:int(c) for (x,z),c in p.items()})
            description.append((j,shift))
n=len(columns);rows={}
for j,col in enumerate(columns):
    for i,c in col.items():rows.setdefault(i,{})[j]=ZZ(c)
for mon,c in target.items():rows.setdefault(index[mon],{})[n]=ZZ(c)
matrix=DomainMatrix(rows,(len(mons),n+1),ZZ)
print(json.dumps({'degree':degree,'target':target_name,'rows':len(mons),'unknowns':n}),flush=True)
reduced,denom,pivots=matrix.rref_den(method='FF')
if n in pivots:
    report={'status':'NO_SOLUTION_AT_DEGREE','degree':degree,'target':target_name,'seconds':time.monotonic()-start}
else:
    coeffs=[S.Rational(0)]*n
    rr=reduced.to_Matrix()
    for i,pivot in enumerate(pivots):coeffs[pivot]=S.Rational(rr[i,n],int(denom))
    certificates=[S.Integer(0)]*4
    for coeff,(j,(a,b)) in zip(coeffs,description):certificates[j]+=coeff*k**a*y**b
    assert S.expand(sum(p.as_expr()*c for p,c in zip(polys,certificates))-target.as_expr())==0
    report={'status':'PASS','degree':degree,'target':str(target),'variables':['k','y'],
        'substitution':'y=v+2','inputs':[str(p) for p in polys],
        'certificates':list(map(str,certificates)),
        'term_counts':[len(S.Poly(c,k,y).terms()) if c else 0 for c in certificates],
        'seconds':time.monotonic()-start}
    text=json.dumps(report,indent=2)+'\n'
    name=f'bipartite-minimal-{target_name}-d{degree}.json'
    (base/name).write_text(text)
    print(json.dumps({'certificate_file':name,'bytes':len(text),'terms':sum(report['term_counts'])}),flush=True)
print(json.dumps({key:value for key,value in report.items() if key in ['status','degree','target','seconds']}),flush=True)
