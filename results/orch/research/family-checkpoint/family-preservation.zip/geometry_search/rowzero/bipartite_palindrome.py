from pathlib import Path
import sympy as S,json,time
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero');start=time.monotonic()
k,mu,T,w,v=S.symbols('k mu T w v');local={str(x):x for x in [k,mu,T,w,v]}
data=json.loads((base/'bipartite-linear-reduction.json').read_text())
polys=[S.sympify(e,locals=local) for e in data['determinants']]
L1=S.sympify(data['linears'][0],locals=local)
line=next(v for v in (base/'bipartite-reduced-row.sing').read_text().splitlines() if v.startswith('ideal I='))
P2=S.sympify(line[8:-1].split(',')[2].replace('^','**'),locals=local)
polys.append(S.resultant(L1,P2,mu))
reduced=[];source=[]
for poly in polys:
 coeff,factors=S.factor_list(poly,T,k)
 f=S.prod(a**n for a,n in factors if a not in [k,T,T-1,T+1])
 ff=S.Poly(f,T);degree=ff.degree();assert degree%2==0
 assert S.expand(T**degree*f.subs(T,1/T)-f)==0
 mid=degree//2;cheb=[S.Integer(2),v]
 for i in range(2,mid+1):cheb.append(S.expand(v*cheb[-1]-cheb[-2]))
 out=ff.coeff_monomial(T**mid)+sum(ff.coeff_monomial(T**i)*cheb[mid-i] for i in range(mid))
 out=S.Poly(S.expand(out),k,v).primitive()[1].as_expr()
 reduced.append(out);source.append(str(f))
 print('CORE',S.factor(out),flush=True)
report={'variables':['k','v','w'],'substitution':'v=T+1/T',
        'equations':list(map(str,reduced))+['w*k*(v*v-4)-1'],
        'palindromic_sources':source}
(base/'bipartite-palindrome.inputs.json').write_text(json.dumps(report,indent=2)+'\n')
print('DONE',time.monotonic()-start,flush=True)
