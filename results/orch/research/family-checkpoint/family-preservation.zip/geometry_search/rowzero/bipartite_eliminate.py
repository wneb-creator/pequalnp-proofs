from pathlib import Path
import sympy as S,json,time,resource
resource.setrlimit(resource.RLIMIT_AS,(512*2**20,512*2**20))
resource.setrlimit(resource.RLIMIT_CPU,(58,60))
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero')
t,l,r0,r1,n0,n1,k=S.symbols('t l r0 r1 n0 n1 k')
symbols={str(v):v for v in [t,l,r0,r1,n0,n1]}
data=json.loads((base/'bipartite-rulings.json').read_text())
reports=[];start=time.monotonic()
for item in data:
 eq=[S.sympify(e,locals=symbols) for e in item['equations']]
 eq=[S.factor(e.subs(l,k*t/((t*t-1)*(t*t+1)))) for e in eq]
 mat,rhs=S.linear_eq_to_matrix(eq[3:],[r0,r1,n0])
 sol=mat.inv()*rhs
 sol=[S.factor(S.cancel(v)) for v in sol]
 sub=dict(zip([r0,r1,n0],sol))
 reduced=[]
 for e in eq[:3]:
  value=S.factor(S.cancel(e.subs(sub)))
  numerator,denom=S.fraction(value)
  numerator=S.Poly(numerator,k,n1,t).primitive()[1].as_expr()
  reduced.append(numerator)
 rec={'tag':item['tag'],'parameter_change':'l=k*t/((t^2-1)*(t^2+1))',
 'solutions':dict((str(a),str(b)) for a,b in sub.items()),
 'equations':list(map(str,reduced))}
 reports.append(rec)
 print('TAG',item['tag'],'SOL',sub,flush=True)
 for q in reduced:print('REDUCED',S.factor(q),flush=True)
 (base/'bipartite-eliminated.json').write_text(json.dumps(reports,indent=2)+'\n')
print('DONE',time.monotonic()-start,flush=True)
