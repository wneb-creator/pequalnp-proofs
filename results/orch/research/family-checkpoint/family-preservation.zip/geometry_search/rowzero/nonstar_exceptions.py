from pathlib import Path
import sympy as S,itertools,json,sys,time,resource
from sympy.polys.matrices import DomainMatrix
resource.setrlimit(resource.RLIMIT_AS,(512*2**20,512*2**20));resource.setrlimit(resource.RLIMIT_CPU,(58,60))
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero');start=time.monotonic()
tag=sys.argv[1];t,u,z=S.symbols('t u z')
if tag in ['cubic','quadratic']:
 minpoly=t**3+3*t*t-1 if tag=='cubic' else t*t+t+1
 field=S.QQ.algebraic_field((S.Poly(minpoly,t),t));alpha=field([1,0])
else:field=S.QQ;alpha=field(int(tag))
def convert(expr):
    num,den=S.fraction(S.cancel(expr))
    def polynomial(e):
        return sum((field.from_sympy(S.Rational(c))*alpha**powers[0] for powers,c in S.Poly(e,t).terms()),field.zero)
    return polynomial(num)/polynomial(den)
def dm(matrix):return DomainMatrix([[convert(e) for e in row] for row in matrix.tolist()],matrix.shape,field)
def expr(e):return field.to_sympy(e)
def serialize(mat):return [[str(expr(e)) for e in row] for row in mat.to_list()]
vs=S.symbols('v0:10');coords=list(itertools.combinations_with_replacement(range(4),2));edges=list(itertools.combinations(range(4),2))
H=S.zeros(4);V=S.zeros(4)
hs=[1,t,-1-t,1-t,-2-t,1+2*t]
for (i,j),v in zip(edges,hs):H[i,j]=H[j,i]=v
for (i,j),v in zip(coords,vs):V[i,j]=V[j,i]=v
P=S.Poly(S.expand(sum(S.prod(1+u*H[i,j]+z*V[i,j] for i,j in enumerate(pm)) for pm in itertools.permutations(range(4)))-24),u,z)
lin=[P.coeff_monomial(u**i*z) for i in range(4)]
A=dm(S.linear_eq_to_matrix(lin,vs)[0]);rank=A.rank()
A=A.vstack(dm(S.eye(10)[1,:]));BD=A.nullspace(divide_last=True).transpose()
GS=[BD.transpose()*dm(S.hessian(P.coeff_monomial(u**i*z*z),vs)/2)*BD for i in range(3)]
RD=GS[2].nullspace(divide_last=True).transpose()
KD=BD.extract([0,4,7,9],list(range(BD.shape[1]))).nullspace(divide_last=True).transpose()
record={'tag':tag,'linear_rank':rank,'quotient_dim':BD.shape[1],'quadratic_ranks':[g.rank() for g in GS],
 'quartic_radical_dim':RD.shape[1],'hollow_dim':KD.shape[1],
 'basis':serialize(BD),'grams':[serialize(g) for g in GS],'radical':serialize(RD),
 'radical_q0':serialize(RD.transpose()*GS[0]*RD),'radical_q1':serialize(RD.transpose()*GS[1]*RD),
 'hollow':serialize(KD),'hollow_q2':serialize(KD.transpose()*GS[2]*KD)}
print(json.dumps({k:record[k] for k in ['tag','linear_rank','quotient_dim','quadratic_ranks','quartic_radical_dim','hollow_dim','radical_q0','radical_q1','hollow_q2']}),flush=True)
if BD.shape[1]==5 and RD.shape[1]==1 and GS[2].rank()==4:
    GD=GS[2]
    diag=BD.extract([0,4,7,9],list(range(5)))
    dif=diag.extract([1,2,3],list(range(5)))-diag.extract([0,0,0],list(range(5)))
    ED=dif.nullspace(divide_last=True).transpose()
    print('CONSTANT_DIAGONAL_DIM',ED.shape[1],'Q2_RANK',(ED.transpose()*GD*ED).rank(),flush=True)
    assert ED.shape==(5,3) and (ED.transpose()*GD*ED).is_zero_matrix
    for inds in itertools.combinations(range(3),2):
        candidate=ED.extract(list(range(5)),list(inds))
        if candidate.hstack(RD).rank()==3:KD=candidate;break
    else:raise AssertionError('No constant-diagonal complement')
    record['constant_diagonal']=serialize(ED)
    record['isotropic_complement']=serialize(KD)
    pair=KD.transpose()*GD
    for inds in itertools.combinations(range(5),2):
        C=pair.extract([0,1],list(inds))
        if C.det()!=field.zero:break
    else:raise AssertionError('No dual pairing')
    CI=C.inv().to_list();rows=[[field.zero]*2 for _ in range(5)]
    for j,i in enumerate(inds):rows[i]=CI[j]
    DD=DomainMatrix(rows,(5,2),field)
    DD=DD-KD*(DD.transpose()*GD*DD).scalarmul(field(1)/field(2))
    TD=KD.hstack(DD,RD);assert TD.det()!=field.zero
    expected=dm(S.Matrix([[0,0,1,0,0],[0,0,0,1,0],[1,0,0,0,0],[0,1,0,0,0],[0,0,0,0,0]]))
    assert TD.transpose()*GD*TD==expected
    NG=[TD.transpose()*g*TD for g in GS]
    record['change']=serialize(TD);record['canonical_grams']=[serialize(g) for g in NG]
    from sympy.polys.rings import ring
    ring0,k,l,m=ring('k,l,m',field)
    ca=[ring0.zero,-k,ring0.one,ring0.zero,l];cb=[k,ring0.zero,ring0.zero,ring0.one,m]
    eq=[]
    for g in NG[:2]:
        mat=g.to_list()
        eq.extend([sum(ca[i]*ca[j]*mat[i][j] for i in range(5) for j in range(5)),
          2*sum(ca[i]*cb[j]*mat[i][j] for i in range(5) for j in range(5)),
          sum(cb[i]*cb[j]*mat[i][j] for i in range(5) for j in range(5))])
    def polynomial_text(p):
        return str(S.expand(sum(expr(c)*S.Symbol('k')**a*S.Symbol('l')**b*S.Symbol('m')**c0 for (a,b,c0),c in p.items())))
    record['graph_equations']=[polynomial_text(p) for p in eq]
    print('GRAPH_READY',len(eq),flush=True)
record['seconds']=time.monotonic()-start
(base/('nonstar-exception-'+tag+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print('DONE',record['seconds'],flush=True)
