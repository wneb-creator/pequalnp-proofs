# Exceptional parameters of the second nonstar hollow plane

Family: H=(1,t,-1-t,1-t,-2-t,1+2t), in edge order01,02,03,12,13,23.
All statements here are exact algebraic calculations, not Lean theorems.
They apply within the global branch where a hypothetical three-dimensional flat
has diagonal projection of rank2, hence one-dimensional hollow kernel spanned by H.

## Parameters0 and1

At either parameter the four compatibility equations for another direction have
rank4. After imposing gauge V01=0, the compatible quotient has dimension5.
The quadratic coefficients of per(J+uH+zV)-24 have ranks:

    t=0: [5,2,3],
    t=1: [5,3,3].

The last quadratic, coefficient u^2z^2, has a two-dimensional radical. In the
following radical basis its first quadratic restricts to -16*b^2, and its middle
quadratic vanishes. Coordinate order is00,01,02,03,11,12,13,22,23,33.

    t=0:
    A=(0,0,0,-1,0,0,0,0,1,0),
    B=(1,0,1,2,1,0,-5,1,0,1).

    t=1:
    A=(0,0,0,0,0,0,-1,0,1,0),
    B=(1,0,0,-5,1,1,2,1,0,1).

Thus the radical's quadratic-null line is exactly the hollow line spanned by A.
An isotropic two-dimensional extension quotient projects to at most a line in
the nondegenerate three-dimensional quotient of the last quadratic. It therefore
meets the radical nontrivially. Its first quadratic forces the intersection into
the line spanned by A. This supplies a second hollow direction independent of H
(A01=0 while H01=1), contradicting diagonal rank2.

Exact basis and Gram data: nonstar-exception-0.json and nonstar-exception-1.json.
The other parameters in the corresponding stabilizer orbits are handled by the
parent's permutation/parameter action, not by separate calculations here.

## Cubic parameter field

Assume f(t)=t^3+3t^2-1=0. This irreducible cubic is used as an exact number field;
the final certificate is an ordinary rational polynomial identity with f as an
additional hypothesis, so it applies to every complex root.

The compatible quotient again has dimension5, and the three quadratic ranks are
[5,4,4]. The last quadratic has a one-dimensional radical lying in the hollow
two-dimensional subspace. Its first quadratic on the chosen radical generator is
-4(t^2+t+1)/3, which is nonzero modulo f.

The hollow two-space cannot serve as the nondegenerate Witt two-space here:
it contains the radical. Instead use the entire constant-diagonal three-space E.
It is totally isotropic for the last quadratic. Choose two vectors of E independent
modulo the radical, construct their dual Witt pair, and append the radical.
The resulting Gram matrix is

    [[0,0,1,0,0], [0,0,0,1,0], [1,0,0,0,0],
     [0,1,0,0,0], [0,0,0,0,0]].

The graph chart has generators (0,-k,1,0,l) and(k,0,0,1,m). Its six remaining
quadratic coefficient equations appear in nonstar-exception-cubic.json.

Graph coverage explicitly uses the previously established equal-diagonal
obstruction and the global diagonal-rank2 assumption: any extension quotient
meeting E contains a valid constant-diagonal direction; the equal-diagonal result
forces it hollow, and the one-dimensional hollow kernel plus gauge forces it zero.
Therefore projection to the two dual Witt coordinates is invertible. Avoiding
the quartic radical alone would not establish this coverage.

A degree3 Macaulay solve over QQ[t]/(f), with matrix20x24, gives an exact
certificate from the six graph equations. Clearing denominators and reducing the
field coefficients yields an integer polynomial identity

    sum_i Fi(t,k,l,m)*Ci(t,k,l,m) + f(t)*C0(t,k,l,m) = D,

where

    D=112495985411207348194196886095215223320910158422206839190688.

The complete7581-byte certificate is nonstar-cubic-certificate-d3.json.
It has54 monomials among the six graph multipliers; the sixth multiplier is zero.
The identity was independently multiplied in a QQ polynomial ring. Separately,
the complete graph was substituted into the permanent and checked by the Ryser
subset formula over the cubic field, verifying every linear compatibility
coefficient, all six graph coefficients, and the identically zero last quadratic.
Report: nonstar-cubic-independent-audit.json. No Lean build was performed.

## Primitive cube-root parameter field

The all-entry chart audit also identifies t^2+t+1=0 as a genuine chart pole.
It is fixed by the order-three stabilizer and cannot be removed by that action.
The same direct computation over QQ[t]/(t^2+t+1), again using the full
constant-diagonal space, gives quotient dimension5 and quadratic ranks[4,3,4].
The quartic radical has dimension1, with q0 value(16-64t)/3 on its chosen
generator. The six graph equations have a degree3 Macaulay certificate,
again from a20x24 matrix, with integer target23051120090381208255800664.
Its complete2725-byte certificate is nonstar-quadratic-certificate-d3.json,
with36 graph-multiplier monomials. Exact QQ multiplication and an independent
Ryser permanent computation over the quadratic field both pass; report:
nonstar-quadratic-independent-audit.json.

## Complete denominator-orbit audit

Parent's verified generic20-term certificate is recorded in
geometry_search/nonstar_nets/plane2-macaulay-verified.json. Its denominator D
has degree159. Multiply it by the complete chart-pole product

    B=t(t-1)(t+1)(t+2)(2t+1)(t^2+t+1)(6t^2-2t-1)(t^3+3t^2-1).

The squarefree product has degree171. Transform it by t, -(t+1)/t, and
-1/(t+1), clearing denominators. Include t and t+1 in the latter two bad
polynomials conservatively, so undefined Mobius values count as bad charts.
Their exact monic gcd is

    t(t-1)(t+1)(t+2)(2t+1)(t^2+t+1)(t^3+3t^2-1)/2.

There are no further exceptional factors. Besides exact rational gcd and
division computations, the result was independently audited by reducing the
three primitive quotient polynomials modulo101. Their leading coefficients
remain nonzero and their common gcd is1; Gauss lemma and degree preservation
therefore exclude any additional common rational factor. Files:
nonstar-denominator-orbit.json and
nonstar-denominator-orbit-independent-audit.json.

Together with the parent's verified parameter/permutation action, the generic
certificate and the four exceptional orbits handled here give uniform coverage
of this hollow plane family within the diagonal-rank2 branch. This is an exact
algebraic closure of the branch; its Lean formalization is still separate.
