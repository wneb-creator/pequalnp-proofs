from pathlib import Path
import sympy as S,itertools,json,time,resource,sys
resource.setrlimit(resource.RLIMIT_AS,(512*2**20,512*2**20));resource.setrlimit(resource.RLIMIT_CPU,(58,60))
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero');start=time.monotonic()
t,U,V,Z,W,R,N,l,r0,r1,n0,n1,k,mu,T=S.symbols('t U V Z W R N l r0 r1 n0 n1 k mu T')
local={str(x):x for x in [t,U,V,Z,W,R,N,l,r0,r1,n0,n1,k,mu,T]}
data=json.loads((base/'bipartite-canonical.json').read_text())
elim=json.loads((base/'bipartite-eliminated.json').read_text())
tag=sys.argv[1]
item=next(x for x in elim if x['tag']==tag) if tag!='rowzero' else None
change={n1:mu/((t-1)*(t*t-1)**2),l:k*t/((t*t-1)*(t*t+1))}
if tag=='rowinf':change[n1]=mu/(t*(t-1)*(t*t-1))
rr=S.sympify(item['solutions']['r1'],locals=local).subs(change) if item else -3/(t*t-1)**2
nn=change[n1]
projection={'row':[0,change[l],0,1],'col':[0,0,change[l],1],'rowzero':[0,0,0,1],'rowinf':[0,1,0,0]}[tag]
sub=dict(zip([U,V,Z,W],projection));sub[R]=rr;sub[N]=nn
entries=[S.factor(S.cancel(S.sympify(e,locals=local).subs(sub))) for e in data['entries']]
denom=S.lcm([S.denom(e) for e in entries]);entries=[S.cancel(e*denom) for e in entries]
coords=list(itertools.combinations_with_replacement(range(4),2));mat=S.zeros(4)
for (i,j),v in zip(coords,entries):mat[i,j]=mat[j,i]=v
cubic=0
for rows in itertools.combinations(range(4),3):
 for cols in itertools.combinations(range(4),3):
  cubic+=sum(S.prod(mat[rows[i],cols[p[i]]] for i in range(3)) for p in itertools.permutations(range(3)))
value=S.factor(S.expand(cubic))
print('RAW FACTORED',value,flush=True)
factors=S.factor_list(value,t,k,mu)[1]
value=S.prod(f**n for f,n in factors if f not in [t,t-1,t+1,t*t+1,k])
poly=S.Poly(S.expand(value),t,k,mu)
assert all(p[0]%2==0 for p,c in poly.terms())
value=S.Add(*[c*T**(p[0]//2)*k**p[1]*mu**p[2] for p,c in poly.terms()])
(base/('bipartite-extra-'+tag+'.json')).write_text(json.dumps({'tag':tag,'polynomial':str(value),'scope':'second projected basis direction cubic coefficient; requires saturated denominators'},indent=2)+'\n')
print('POLYNOMIAL',S.factor(value),flush=True)
q0=S.factor(S.cancel(S.sympify(data['quadrics'][0],locals=local).subs(sub)))
print('Q0_SECOND',q0,flush=True)
print('DONE',time.monotonic()-start,flush=True)
