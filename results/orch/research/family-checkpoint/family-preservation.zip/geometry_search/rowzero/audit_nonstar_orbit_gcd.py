from pathlib import Path
import sympy as S,json,time
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero');start=time.monotonic()
t=S.symbols('t');data=json.loads((base/'nonstar-denominator-orbit.json').read_text())
parse=lambda e:S.Poly(S.sympify(e,locals={'t':t}),t,domain=S.QQ)
G=parse(data['conservative_gcd'])
polys=[parse(data['squarefree_bad']),parse(data['transform1'])*S.Poly(t,t),parse(data['transform2'])*S.Poly(t+1,t)]
quotients=[]
for P in polys:
 q,r=S.div(P,G);assert r.is_zero
 quotients.append(q.clear_denoms()[1].primitive()[1])
for prime in [101,103,107,109,113,127]:
 if any(int(q.LC())%prime==0 for q in quotients):continue
 reduced=[S.Poly(q.as_expr(),t,modulus=prime) for q in quotients]
 gcd=S.gcd(S.gcd(reduced[0],reduced[1]),reduced[2])
 if gcd.degree()==0:break
else:raise AssertionError('No modular coprimality witness found')
report={'status':'PASS','divisibility_exact_over_QQ':True,'modular_coprimality_prime':prime,
 'quotient_leading_coefficients_nonzero_mod_prime':True,'quotient_degrees':[q.degree() for q in quotients],
 'modular_gcd':str(gcd.as_expr()),'conclusion':'the stated conservative gcd is exact over QQ by Gauss lemma and degree-preserving reduction',
 'seconds':time.monotonic()-start}
(base/'nonstar-denominator-orbit-independent-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
