import sympy as s,itertools,json,sys,time
from pathlib import Path
from sympy.polys.matrices import DomainMatrix
import resource
resource.setrlimit(resource.RLIMIT_AS,(512*2**20,512*2**20))
resource.setrlimit(resource.RLIMIT_CPU,(110,115))
job=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/nonstar_nets');job.mkdir(exist_ok=True)
name=sys.argv[1];t=s.symbols('t');hs={'plane1':[1,1,-2,0,t,-t],'plane2':[1,t,-1-t,1-t,-2-t,1+2*t]}[name]
coords=list(itertools.combinations_with_replacement(range(4),2));edges=[ij for ij in coords if ij[0]<ij[1]]
H=s.zeros(4)
for (i,j),v in zip(edges,hs):H[i,j]=H[j,i]=v
v=s.symbols('v0:10');V=s.zeros(4)
for (i,j),vv in zip(coords,v):V[i,j]=V[j,i]=vv
u,z=s.symbols('u z');P=s.Poly(s.expand(sum(s.prod(1+u*H[i,j]+z*V[i,j] for i,j in enumerate(pm)) for pm in itertools.permutations(range(4)))-24),u,z)
assert all(P.coeff_monomial(u**i)==0 for i in range(5))
lin=[P.coeff_monomial(u**i*z) for i in range(4)];A=s.linear_eq_to_matrix(lin,v)[0]
print('LINEAR RANK',A.rank(),flush=True)

from sympy.polys.rings import ring
field=s.QQ.frac_field(t)
def dm(M):return DomainMatrix.from_Matrix(M).convert_to(field)
A=A.col_join(s.eye(10)[1,:]);BD=dm(A).nullspace(divide_last=True).transpose();B=BD.to_Matrix();print('BASIS_READY',B.shape,flush=True)
GDS=[BD.transpose()*dm(s.hessian(P.coeff_monomial(u**i*z*z),v)/2)*BD for i in range(3)]
print('RANKS',[g.rank() for g in GDS],flush=True);GD=GDS[2];G=GD.to_Matrix()
RD=GD.nullspace(divide_last=True).transpose();assert RD.shape==(5,1);ratio=(BD*RD).to_list()[0][0];RD=RD.scalarmul(1/ratio)
KD=dm(B[[0,4,7,9],:]).nullspace(divide_last=True).transpose();assert KD.shape==(5,2)
pair=KD.transpose()*GD
for inds in itertools.combinations(range(5),2):
 C=pair.extract([0,1],list(inds))
 if C.det()!=0:break
D=s.zeros(5,2);CI=C.inv().to_Matrix()
for j,i in enumerate(inds):D[i,:]=CI[j,:]
DD=dm(D);DD=DD-KD*(DD.transpose()*GD*DD).scalarmul(field(1)/field(2))
TD=KD.hstack(DD,RD);det=TD.det();print('DET',s.factor(field.to_sympy(det)),flush=True)
canon=(TD.transpose()*GD*TD).to_Matrix();assert canon==s.Matrix([[0,0,1,0,0],[0,0,0,1,0],[1,0,0,0,0],[0,1,0,0,0],[0,0,0,0,0]])
NG=[TD.transpose()*g*TD for g in GDS];print('CANONICAL_READY',flush=True)
PR,k,l,m=ring('k,l,m',field);ca=[PR.zero,-k,PR.one,PR.zero,l];cb=[k,PR.zero,PR.zero,PR.one,m];eq=[]
for gdm in NG[:2]:
 gg=gdm.to_list()
 eq.extend([sum(ca[i]*ca[j]*gg[i][j] for i in range(5) for j in range(5)),2*sum(ca[i]*cb[j]*gg[i][j] for i in range(5) for j in range(5)),sum(cb[i]*cb[j]*gg[i][j] for i in range(5) for j in range(5))])
print('EQUATION TERMS',[len(e) for e in eq],flush=True)
script='ring R=(0,t),(k,l,m),dp;\noption(redSB);\nideal I='+','.join(str(e).replace('**','^') for e in eq)+';\nideal G=std(I);\nprint("BASIS_SIZE");size(G);print("DIMENSION");dim(G);print("BASIS");print(G);\nif(size(G)==1 && G[1]==1){matrix C=lift(I,ideal(1));for(int j=1;j<=nrows(C);j++){print("CERT");print(C[j,1]);}print("RESIDUAL");poly residual=-1;for(int h=1;h<=nrows(C);h++){residual=residual+I[h]*C[h,1];}print(residual);}\nquit;\n'
(job/(name+'-normalized.sing')).write_text(script)
record={'name':name,'H':[str(v) for v in hs],'basis':[[str(v) for v in row] for row in B.tolist()],'change':[[str(v) for v in row] for row in TD.to_Matrix().tolist()],'grams':[[[str(v) for v in row] for row in g.to_Matrix().tolist()] for g in NG],'equations':[str(e) for e in eq],'determinant':str(field.to_sympy(det))}
(job/(name+'-normalized.json')).write_text(json.dumps(record,indent=2)+'\n')
