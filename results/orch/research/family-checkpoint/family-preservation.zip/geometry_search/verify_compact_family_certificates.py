from pathlib import Path
import sympy as s,json,time
from sympy.polys.rings import ring
from sympy.polys.domains import QQ
base=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/rowzero');reports=[]
for name in ['bipartite-minimal-integer-certificate.json','nonstar-cubic-certificate-d3.json','nonstar-quadratic-certificate-d3.json']:
 start=time.monotonic();d=json.loads((base/name).read_text());R,*gens=ring(','.join(d['variables']),QQ);local=dict(zip(d['variables'],s.symbols(' '.join(d['variables']))));parse=lambda p:R.from_expr(s.sympify(str(p),locals=local))
 value=sum((parse(a)*parse(b) for a,b in zip(d['inputs'],d['integer_certificates'])),R.zero)
 if 'parameter_polynomial' in d:value+=parse(d['parameter_polynomial'])*parse(d['parameter_multiplier']);target=parse(d['target'])
 else:target=parse(d['multiplier'])*parse('k**5')
 assert value==target
 reports.append({'file':name,'status':'PASS','terms':sum(len(parse(v)) for v in d['integer_certificates']),'seconds':time.monotonic()-start})
print(json.dumps(reports,indent=2));(base.parent/'compact-family-certificate-audit.json').write_text(json.dumps(reports,indent=2)+'\n')
