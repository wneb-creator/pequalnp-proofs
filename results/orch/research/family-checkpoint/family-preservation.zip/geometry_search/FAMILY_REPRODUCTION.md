# Frozen algebraic family artifacts

These artifacts prove restricted family obstructions by exact algebraic identities. They do not prove or refute the full posted complex statement, and they are not a substitute for Lean checking. The global problem remains open.

The archive preserves original relative paths under /tmp/oec/pequalnp-pilot-78. Extract there to reproduce the scripts without changing their fixed base paths. It contains complete stdout and stderr for the included probes, including superseded attempts; a failed or incomplete probe is not evidence. Final conclusions are identified below.

## Scope

* Nonstar family1 H=(1,1,-2,0,t,-t), t nonzero: the compatibility quotient has a rank-three quartic quadratic and a two-dimensional radical with constant diagonals. In the diagonal-rank-two branch, any candidate extension intersects this radical and supplies a forbidden second hollow direction. The t=0 and projective-infinity directions are stars and are outside this bundle's family1 calculation.
* Nonstar family2 H=(1,t,-1-t,1-t,-2-t,1+2t): a verified generic rational-function certificate, three-permutation denominator audit, and four exceptional-orbit calculations cover every projective parameter in the diagonal-rank-two branch. See rowzero/NONSTAR_EXCEPTIONS.md.
* Bipartite family H=(t-1,t(t-1),0,0,t+1,-t(t+1)), t not0,1,-1: exact coordinate changes, ruling classification, boundary identities and verified certificates exclude a three-flat containing this direction. See rowzero/BIPARTITE_OBSTRUCTION.md. Reduction of every triangle-free support to this family or a star is a separate statement.

The nonstar graph coverage uses diagonal rank exactly2, its one-dimensional hollow kernel, and the equal-diagonal obstruction. It does not follow merely from avoiding the quartic radical.

For completeness, the equal-diagonal obstruction is elementary: write a symmetric direction as rJ+W with W hollow, let S be its six edge sum, R its opposite-edge pairing, and C its cubic coefficient. The four homogeneous coefficients are
96r+12S; 144r²+36rS+2S²+4R; 96r³+36r²S+4rS²+8rR+C; 24r⁴+12r³S+2r²S²+4r²R+rC+R². Their vanishing gives S=-8r, R=4r², and then8r⁴=0, so r=0. This argument is also Lean checked in the separately preserved ConstantDiagonal component.

## Main final artifacts

* nonstar_nets/plane1-regular.json and nonstar-plane1-regular.stdout: basis, rank-three Gram matrix, nonzero minor and radical.
* nonstar_nets/plane2-normalized.json: exact generic basis, canonical change and six graph equations.
* nonstar_nets/plane2-macaulay-verified.json: independently verified degree-three certificate with at most20 generator-monomial slots. The first five generators give a20x20 rational-function linear solve. Its large degree159 denominator is covered by the exact orbit audit, not ignored.
* nonstar_nets/plane2-chart-exceptions.json and plane2-stabilizer.json: complete chart poles and exact parameter action.
* rowzero/nonstar-denominator-orbit.json and its independent audit: exact gcd and independent modular coprimality witness.
* rowzero/nonstar-cubic-certificate-d3.json and nonstar-quadratic-certificate-d3.json: explicit integer identities, including the parameter-polynomial multiplier; their inputs were independently checked against Ryser permanents.
* rowzero/bipartite-minimal-integer-certificate.json:85-term integer-cleared generic certificate; rowzero/bipartite-certificate-rowinf.inputs.json/.stdout contains the21-term infinity certificate.

## Reproduction

Python3 with SymPy is sufficient to verify the final certificate identities. From the job scratch directory:

    python geometry_search/verify_compact_family_certificates.py
    python geometry_search/audit_plane2_macaulay.py
    python geometry_search/rowzero/audit_nonstar_cubic.py cubic
    python geometry_search/rowzero/audit_nonstar_cubic.py quadratic
    python geometry_search/rowzero/audit_nonstar_orbit_gcd.py
    python geometry_search/rowzero/audit_bipartite_certificates.py rowinf

The corresponding full diagnostics are included. The generic plane2 audit additionally factors large polynomials and may take substantially longer than its initial exact-identity check.

To regenerate inputs, use nonstar_regular_basis.py plane1, nonstar_line_net_normalized.py plane2, nonstar_macaulay_native.py, and nonstar_auxiliary.py. The native Macaulay linear solve is run by run_nonstar_native.py plane2-macaulay-linear, which expects the already-installed Singular binary and its shared libraries under numeric/. Native CAS installation binaries are runtime dependencies, not copied into this mathematical archive. The full native input, output, resource limits and return status are preserved. All remaining file dependencies used by the family scripts are included at their original relative paths.

An alternative univariate optimization was explored but is not part of the final family2 coverage certificate. The generic20-slot certificate and the denominator-orbit proof are the preserved final route.
