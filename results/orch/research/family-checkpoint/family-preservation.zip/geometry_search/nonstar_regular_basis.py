import sympy as s,itertools,json,sys,time
from pathlib import Path
import resource
resource.setrlimit(resource.RLIMIT_AS,(512*2**20,512*2**20))
resource.setrlimit(resource.RLIMIT_CPU,(110,115))
job=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/nonstar_nets');job.mkdir(exist_ok=True)
name=sys.argv[1];t=s.symbols('t');hs={'plane1':[1,1,-2,0,t,-t],'plane2':[1,t,-1-t,1-t,-2-t,1+2*t]}[name]
coords=list(itertools.combinations_with_replacement(range(4),2));edges=[ij for ij in coords if ij[0]<ij[1]]
H=s.zeros(4)
for (i,j),v in zip(edges,hs):H[i,j]=H[j,i]=v
v=s.symbols('v0:10');V=s.zeros(4)
for (i,j),vv in zip(coords,v):V[i,j]=V[j,i]=vv
u,z=s.symbols('u z');P=s.Poly(s.expand(sum(s.prod(1+u*H[i,j]+z*V[i,j] for i,j in enumerate(pm)) for pm in itertools.permutations(range(4)))-24),u,z)
assert all(P.coeff_monomial(u**i)==0 for i in range(5))
lin=[P.coeff_monomial(u**i*z) for i in range(4)];A=s.linear_eq_to_matrix(lin,v)[0]
print('LINEAR RANK',A.rank(),flush=True)

print('LINEAR_MATRIX',A,flush=True)
chosen=None
for piv in itertools.combinations([i for i in range(10) if i!=1],4):
 det=s.factor(A[:,piv].det())
 if det and len(s.Poly(det,t).terms())==1:
  chosen=piv;print('MONOMIAL PIVOT',piv,det,flush=True);break
assert chosen is not None
free=[i for i in range(10) if i not in chosen and i!=1]
B=s.zeros(10,5)
for j,i in enumerate(free):B[i,j]=1
sol=-A[:,chosen].inv()*A[:,free]
for j,i in enumerate(chosen):B[i,:]=sol[j,:]
B=B.applyfunc(s.cancel);print('BASIS',B,flush=True)
G0=s.hessian(P.coeff_monomial(u*u*z*z),v)/2
G=(B.T*G0*B).applyfunc(s.factor);print('Q2 GRAM',G,flush=True)
print('RANK',G.rank(),flush=True)
rad=G.nullspace();print('RADICAL',[(B*r).applyfunc(s.factor) for r in rad],flush=True)
nums=[s.fraction(s.factor(G.extract(I,J).det()))[0] for I in itertools.combinations(range(5),3) for J in itertools.combinations(range(5),3)]
print('MINOR_GCD',s.factor(s.gcd_list(nums)),flush=True)
(job/(name+'-regular.json')).write_text(json.dumps({'pivot':[int(v) for v in chosen],'free':free,'basis':[[str(v) for v in row] for row in B.tolist()],'gram':[[str(v) for v in row] for row in G.tolist()],'radical':[[str(s.factor(v)) for v in B*r] for r in rad]},indent=2)+'\n')
