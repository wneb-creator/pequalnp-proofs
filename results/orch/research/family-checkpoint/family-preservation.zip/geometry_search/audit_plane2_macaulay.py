import sympy as s,json,time,resource
from pathlib import Path
from sympy.polys.rings import ring
resource.setrlimit(resource.RLIMIT_AS,(512*2**20,512*2**20));resource.setrlimit(resource.RLIMIT_CPU,(110,115))
start=time.monotonic();job=Path('/tmp/oec/pequalnp-pilot-78/geometry_search/nonstar_nets');t=s.symbols('t');field=s.QQ.frac_field(t);PR,k,l,m=ring('k,l,m',field)
D=json.loads((job/'plane2-normalized.json').read_text());polys=[PR.from_expr(s.sympify(e)) for e in D['equations']];meta=json.loads((job/'plane2-macaulay-linear-metadata.json').read_text());lines=(job/'plane2-macaulay-linear.stdout').read_text().splitlines();ss=[lines[i+1] for i,v in enumerate(lines) if v=='SOLUTION'];assert len(ss)==20
coefs=[field.from_sympy(s.sympify(e.replace('^','**'))) for e in ss];print('PARSED',time.monotonic()-start,flush=True)
mult=[PR.zero]*6
for j,c in zip(meta['selected_columns'],coefs):
 gi,e=meta['columns'][j];mult[gi]+=PR.from_dict({tuple(e):c})
assert sum(a*b for a,b in zip(mult,polys))==PR.one;print('EXACT_IDENTITY_PASS',time.monotonic()-start,flush=True)
d=coefs[0].denom.ring.one
for c in coefs:d=d.lcm(c.denom)
factor=s.factor(d.as_expr());print('COMMON_DENOMINATOR',factor,flush=True)
factored=[]
for i,c in enumerate(coefs):
 f=s.factor(c.numer.as_expr())/s.factor(c.denom.as_expr());factored.append(str(f));print('COEFFICIENT',i,'chars',len(str(f)),flush=True)
r={'status':'PASS','degree_bound':3,'number_terms':20,'common_denominator':str(factor),'selected_columns':meta['selected_columns'],'columns':meta['columns'],'coefficients_factored':factored,'identity':'sum_i coefficient_i*monomial_i*generator_i=1 overQ(t)[k,l,m]','seconds':time.monotonic()-start}
(job/'plane2-macaulay-verified.json').write_text(json.dumps(r,indent=2)+'\n');print('PASS',time.monotonic()-start,flush=True)
