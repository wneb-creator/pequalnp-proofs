#!/usr/bin/env python3
import argparse
import itertools
import json
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--case', choices=['and_edge', 'and_nonedge', 'or_edge', 'or_nonedge', 'not'], required=True)
parser.add_argument('--seconds', type=int, default=180)
parser.add_argument('--seed', type=int, default=0)
parser.add_argument('--max-nots', type=int, default=4)
parser.add_argument('--full', action='store_true')
args = parser.parse_args()
root = Path(__file__).parent
solver = root / 'cadical/build/cadical'
n, s = 10, 19
A = (1 << n) + n + s + 2
edges = [(0,1),(1,2),(2,3),(3,4),(4,0),(0,5),(1,6),(2,7),(3,8),(4,9),(5,7),(7,9),(9,6),(6,8),(8,5)]
edges_arg = ','.join(str(a)+str(b) for a,b in edges)
target = lambda r: any((r>>a)&1 and (r>>b)&1 for a,b in edges)
positive = [r for r in range(1 << n) if target(r)]
negative = [r for r in range(1 << n) if not target(r)]
rows = set(range(1<<n)) if args.full else set(
    [r for r in positive if not any(q != r and q & r == q for q in positive)] +
    [r for r in negative if not any(q != r and q & r == r for q in negative)])
run = root / (args.case + ('-full' if args.full else '-cegar') + '-seed' + str(args.seed) + '-not' + str(args.max_nots))
run.mkdir(exist_ok=True)
def ix(kd,j,a): return (kd*(s+1)+j)*A+a+1
op,sa,sb = {'and_edge':(0,0,1), 'and_nonedge':(0,0,2), 'or_edge':(1,0,1),
            'or_nonedge':(1,0,2), 'not':(3,0,0)}[args.case]
extras = [[ix(0,0,op)], [ix(1,0,sa)], [ix(2,0,sb)]]
notvars = [ix(0,j,3) for j in range(s)]
extras.append(notvars)
extras += [[-v for v in subset] for subset in itertools.combinations(notvars,args.max_nots+1)]
for iteration in range(20):
    start=time.monotonic()
    prefix=run/('round-'+str(iteration))
    cnf=prefix.with_suffix('.cnf')
    with prefix.with_suffix('.generate.log').open('w') as log:
        subprocess.run(['python3', str(root/'gennot-selected.py'), str(n),str(s),edges_arg,
                        str(cnf),'rows',','.join(map(str,sorted(rows)))],stdout=log,stderr=subprocess.STDOUT,check=True)
    text=cnf.read_text()
    header,body=text.split('\n',1)
    p,typ,nv,nc=header.split()
    cnf.write_text(f'p cnf {nv} {int(nc)+len(extras)}\n'+body+
                   ''.join(' '.join(map(str,c))+' 0\n' for c in extras))
    logpath=prefix.with_suffix('.solver.log')
    with logpath.open('w') as log:
        result=subprocess.run([str(solver),'--seed='+str(args.seed),'-t',str(args.seconds),str(cnf)],
                              stdout=log,stderr=subprocess.STDOUT)
    print(json.dumps({'case':args.case,'iteration':iteration,'rows':len(rows),'solver_exit':result.returncode,
                      'elapsed':round(time.monotonic()-start,2),'log':str(logpath)}),flush=True)
    output=logpath.read_text()
    if result.returncode != 10:
        break
    model={int(v) for line in output.splitlines() if line.startswith('v ') for v in line[2:].split() if int(v)>0}
    ops=[]
    for j in range(s):
        oi=next(o for o in range(4) if ix(0,j,o) in model)
        a=next(k for k in range(n+j+1) if ix(1,j,k) in model)
        b=next(k for k in range(n+j+1) if ix(2,j,k) in model)
        ops.append((oi,a,b))
    out=next(k for k in range(n+s+1) if ix(6,0,k) in model)
    mismatches=[]
    for r in range(1<<n):
        ws=[bool((r>>k)&1) for k in range(n)]
        for oi,a,b in ops:
            va=ws[a] if a<len(ws) else False
            vb=ws[b] if b<len(ws) else False
            ws.append(va and vb if oi==0 else va or vb if oi==1 else True if oi==2 else not va)
        value=ws[out] if out<len(ws) else False
        if value != target(r): mismatches.append(r)
    witness={'n':n,'gates':ops,'out':out,'mismatches':mismatches}
    prefix.with_suffix('.model.json').write_text(json.dumps(witness,indent=2)+'\n')
    print(json.dumps({'case':args.case,'iteration':iteration,'counterexamples':len(mismatches)}),flush=True)
    if not mismatches:
        print('FULL COUNTEREXAMPLE FOUND',flush=True)
        break
    rows.update(mismatches)
