#!/usr/bin/env python3
import argparse
import itertools
import json
from pathlib import Path
import random
import subprocess
import time

parser=argparse.ArgumentParser()
parser.add_argument('--seconds',type=int,default=30)
parser.add_argument('--window',type=int,default=5)
parser.add_argument('--rounds',type=int,default=100)
parser.add_argument('--seed',type=int,default=1)
parser.add_argument('--template',type=int,choices=[584,587],default=587)
args=parser.parse_args()
root=Path(__file__).parent
run=root/('local-'+str(args.template)+'-w'+str(args.window)+'-seed'+str(args.seed))
run.mkdir(exist_ok=True)
templates={
584:[(1,9,5),(1,0,9),(1,0,6),(1,7,3),(0,1,12),(1,6,5),(1,11,3),(1,13,1),(1,14,2),(0,12,15),(0,4,16),(0,19,11),(1,7,21),(0,18,17),(1,20,23),(1,3,15),(0,25,8),(0,22,10),(1,27,26),(1,24,28)],
587:[(1,7,3),(1,1,5),(1,1,9),(1,3,6),(1,1,10),(1,5,9),(1,13,5),(0,11,0),(1,9,0),(1,18,3),(0,12,6),(0,2,14),(0,15,7),(0,8,16),(1,22,20),(0,4,19),(1,23,17),(1,21,26),(1,25,27),(1,24,28)]}
base=templates[args.template]
edges=[(0,1),(1,2),(2,3),(3,4),(4,0),(0,5),(1,6),(2,7),(3,8),(4,9),(5,7),(7,9),(9,6),(6,8),(8,5)]
def target(r): return any((r>>a)&1 and (r>>b)&1 for a,b in edges)
def evaluate(gates,r):
    ws=[bool((r>>k)&1) for k in range(10)]
    for op,a,b in gates:
        va,vb=ws[a],ws[b]
        ws.append(va and vb if op==0 else va or vb if op==1 else not va if op==2 else va)
    return ws[-1]
assert all(evaluate(base,r)==target(r) for r in range(1024))
random.seed(args.seed)
seen=set()
for trial in range(args.rounds):
    if trial<20:
        start=trial
        selected=tuple(sorted((start+k)%20 for k in range(args.window)))
    else:
        selected=tuple(sorted(random.sample(range(20),args.window)))
    if selected in seen: continue
    seen.add(selected)
    st=time.monotonic()
    clauses=[]; variables={}; nv=0
    def var(*key):
        global nv
        if key not in variables:
            nv+=1; variables[key]=nv
        return variables[key]
    def neg(x): return not x if isinstance(x,bool) else -x
    def add(*xs):
        if True in [x for x in xs if isinstance(x,bool)]: return
        ys=list(dict.fromkeys(x for x in xs if not isinstance(x,bool)))
        if any(-x in ys for x in ys): return
        clauses.append(ys)
    def onehot(vs):
        add(*vs)
        for a,b in itertools.combinations(vs,2): add(-a,-b)
    for j in selected:
        onehot([var('op',j,o) for o in range(4)])
        for side in range(2): onehot([var('src',j,side,k) for k in range(10+j)])
        for a in range(10+j):
            for b in range(a):
                add(-var('src',j,0,a),-var('src',j,1,b),var('op',j,2),var('op',j,3))
        for o in [2,3]:
            for k in range(10+j):
                add(-var('op',j,o),-var('src',j,0,k),var('src',j,1,k))
    onehot([var('op',j,3) for j in selected])
    add(*[var('op',j,2) for j in selected])
    for r in range(1024):
        ws=[bool((r>>k)&1) for k in range(10)]
        for j,(op,a,b) in enumerate(base):
            if j not in selected and isinstance(ws[a],bool) and isinstance(ws[b],bool):
                ws.append(ws[a] and ws[b] if op==0 else ws[a] or ws[b]); continue
            w=var('w',j,r)
            if j in selected:
                u,v=var('u',j,r),var('v',j,r)
                for side,pin in [(0,u),(1,v)]:
                    for k,source in enumerate(ws):
                        selector=var('src',j,side,k)
                        add(-selector,-pin,source); add(-selector,pin,neg(source))
                o0,o1,o2,o3=[var('op',j,o) for o in range(4)]
                add(-o0,-w,u); add(-o0,-w,v); add(-o0,w,-u,-v)
                add(-o1,w,-u); add(-o1,w,-v); add(-o1,-w,u,v)
                add(-o2,w,u); add(-o2,-w,-u)
                add(-o3,-w,u); add(-o3,w,-u)
            else:
                u,v=ws[a],ws[b]
                if op==0:
                    add(-w,u); add(-w,v); add(w,neg(u),neg(v))
                else:
                    add(w,neg(u)); add(w,neg(v)); add(-w,u,v)
            ws.append(w)
        add(ws[-1] if target(r) else neg(ws[-1]))
    prefix=run/('trial-'+str(trial))
    cnf=prefix.with_suffix('.cnf')
    with cnf.open('w') as f:
        f.write(f'p cnf {nv} {len(clauses)}\n')
        for c in clauses: f.write(' '.join(map(str,c))+' 0\n')
    logfile=prefix.with_suffix('.solver.log')
    with logfile.open('w') as f:
        result=subprocess.run([str(root/'cadical/build/cadical'),'-t',str(args.seconds),'--seed='+str(args.seed),str(cnf)],stdout=f,stderr=subprocess.STDOUT)
    info={'trial':trial,'selected':selected,'vars':nv,'clauses':len(clauses),'solver_exit':result.returncode,'elapsed':round(time.monotonic()-st,2)}
    print(json.dumps(info),flush=True)
    prefix.with_suffix('.info.json').write_text(json.dumps(info)+'\n')
    if result.returncode==10:
        model={int(v) for l in logfile.read_text().splitlines() if l.startswith('v ') for v in l[2:].split() if int(v)>0}
        gates=[]
        for j,gate in enumerate(base):
            if j in selected:
                o=next(o for o in range(4) if variables['op',j,o] in model)
                a=next(k for k in range(10+j) if variables['src',j,0,k] in model)
                b=next(k for k in range(10+j) if variables['src',j,1,k] in model)
                gates.append((o,a,b))
            else: gates.append(gate)
        mismatches=[r for r in range(1024) if evaluate(gates,r)!=target(r)]
        prefix.with_suffix('.witness.json').write_text(json.dumps({'gates':gates,'mismatches':mismatches},indent=2)+'\n')
        print('FULL COUNTEREXAMPLE FOUND' if not mismatches else 'ENCODING BUG',flush=True)
        break
    cnf.unlink()
