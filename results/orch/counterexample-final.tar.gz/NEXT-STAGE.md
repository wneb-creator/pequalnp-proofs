# L-meta-2592 counterexample search

All results below are bounded computational observations, not Lean proofs.

## Completed searches

- Full-table local resynthesis around checked witness L_meta_587, replacing one gate by COPY and allowing NOT within five selected gates: 40 windows, 31 UNSAT, 9 timed out, no SAT. Each trial used all 1024 input rows and a 10-second solver limit.
- Broad 19-gate synthesis used 30 boundary rows first. First-NOT and first-AND-edge cases produced models, but verification found 872 and 314 wrong full-table rows. The enlarged CEGAR rounds remain paused.
- L_meta_584 has an eight-gate core at indices 0,1,2,5,9,11,12,17. With inputs a=x0,b=x5,c=x6,d=x7,e=x9, its exposed outputs are a∨e, a∨c, b∨c, and ab∨bd∨de∨ec. Seven-gate synthesis of all four outputs, requiring at least one NOT, is UNSAT on all 32 rows: 0.04 seconds with the three OR outputs fixed first, 1.71 seconds fully free.

## Next search order

1. Extend the eight-gate shared core by gate 4, 6, or 15 of L_meta_584. These produce nine-to-eight replacements with six boundary inputs. Then try ten-to-nine windows including two of those gates. Extract all boundary input wires and all exposed outputs, and require exact agreement on every boundary assignment. A replacement valid on this stronger boundary domain is valid in the complete circuit.
2. Resume broad synthesis in the first-OR-nonedge case. Both checked 20-gate witnesses begin with an OR of nonadjacent vertices. The five automorphism cases are AND-edge, AND-nonedge, OR-edge, OR-nonedge, NOT-input.
3. Use --max-nots 3 once the 16-binary-gate bound is checked, and --max-nots 2 after the 17-binary-gate bound. These restrictions improve the counterexample search but are not themselves evidence for either lower bound. Existing broad script supports the parameter. Prefer all 1024 rows directly or retain full-table CEGAR verification.
4. Optional separate route: synthesize 17 or 18 binary AND gates with complemented wires free. If SAT, choose each node's polarity (AND versus De Morgan OR) to minimize explicit NOT wires. An 18-binary-gate witness with at most one explicit NOT, or 17 with at most two, refutes the target. This route is not yet implemented.

## Reproduction and preservation

Solver is official arminbiere/cadical commit e4d9bd93af444c6575a908a24da2c4130cb2a1c7, built with ./configure and make -j2. Source acquisition was through github.com only. Full solver outputs are retained.

Preserve search.py, local_search.py, core_search.py, gennot-selected.py, NEXT-STAGE.md, summary.json, all top-level *.log, and each run directory's *.log/*.json. The archive counterexample-artifacts.tar.gz contains these, plus an SHA-256 manifest. CNF files and the solver clone/build are omitted because the scripts regenerate them. paused-pids.json records live local processes only and is not a portable reproduction input.

Commands for next broad rounds (one solver worker at a time):

    python3 search.py --case or_nonedge --full --max-nots 3 --seconds 600
    python3 search.py --case or_nonedge --full --max-nots 2 --seconds 600

The first command's NOT cap is provisional until the 16-floor proof compiles; the second requires the 17-floor proof. Both remain sound counterexample searches independently of those proofs; neither timeout nor UNSAT under a cap proves the unrestricted posted statement.

## Update 2026-11-25T14:34:25.317816+00:00

The signed-wire AIG route is implemented in aig_search.py. It supports explicit NOT budgets, free-complement mode, the full Petersen target, vertex9 deletion, and adjacent/nonadjacent anti-diagonal projections. The encoding passed a known20-gate zero-NOT witness check against58552 clauses on30 rows. The exact vertex9-deleted signed15 query timed out after300 seconds; full18-binary plus at most1-NOT synthesis is currently running.

lift_search.py applies all120 Petersen automorphisms to both checked20-gate witnesses, specializes the variable mapped to9 tofalse, and simplifies constants/copies. Direct normalization produced84 distinct16-gate templates. A bounded two-level algebraic rewrite expanded this to108, including mixed-product circuits. Exhaustive two-reader lifting found no counterexample:924 eligible positive-reader choices and1608 full paired clamp tests. All eligible A wires imply f0;24 have an AND farther downstream. Detailed templates and eligible-profile.json are preserved.

The three9-to8 local shared-core extensions were UNSAT. Five10-to9 windows timed out at60 seconds; two remaining windows are paused. Existing process IDs remain recorded locally.

## Search pause 2026-11-25T14:44:56.130360+00:00

Root reported that the desk returned no such live lease. Every owned search driver and solver was stopped with SIGSTOP; all twelve listed processes are in state T. No new search is authorized pending the coordinator decision. pause-state.txt and paused-pids.json record their state.

The six-input C6/pair-OR core query with ten gates and one or two NOTs was UNSAT in62.6 seconds when the three pair OR outputs were fixed first. The broader seven-input core, adding c and asking for q_i=c OR ai OR bi plus H in13 gates, is paused with no verdict. Its128-row known14-gate core check passed before search. Both decompositions reconstruct a full19-gate Petersen candidate and check1024 rows if SAT. These are computational observations, not Lean proofs.

Known20-gate Petersen circuits are upper bounds only; the full monotone lower-bound sibling remains open. No global optimality claim is made for Petersen. The16-gate optimality references in this record concern the separate vertex-deleted nine-input function.

## Final cleanup 2026-11-25T14:49:38.560326+00:00

Root instructed final termination after reacquisition returned another pilot lease twice. All six owned drivers were killed while stopped, preventing new child launches. Their six owned CaDiCaL solvers received SIGTERM followed by SIGCONT solely to flush termination logs. All exited; no solver needed SIGKILL. Exited solver processes may temporarily appear as zombies awaiting their adopter to reap them; none can execute or launch work. cleanup-state.json records process identities and final status. No search, proof or desk call was started during cleanup.

Complete flushed solver logs are included. solver-verdicts.json indexes their reported status. Unfinished queries were terminated without a checked result. The earlier paused-process file is retained as historical data only.
