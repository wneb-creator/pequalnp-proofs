#!/usr/bin/env python3
import argparse
import itertools
import json
from pathlib import Path
import time

parser=argparse.ArgumentParser()
parser.add_argument('--rewrite',action='store_true')
parser.add_argument('--limit',type=int,default=0)
args=parser.parse_args()
root=Path(__file__).parent
run=root/('lift-rewrite' if args.rewrite else 'lift-simple');run.mkdir(exist_ok=True)
edges=[(0,1),(1,2),(2,3),(3,4),(4,0),(0,5),(1,6),(2,7),(3,8),(4,9),(5,7),(7,9),(9,6),(6,8),(8,5)]
adj=[{b if a==v else a for a,b in edges if a==v or b==v} for v in range(10)]
templates={
584:[(1,9,5),(1,0,9),(1,0,6),(1,7,3),(0,1,12),(1,6,5),(1,11,3),(1,13,1),(1,14,2),(0,12,15),(0,4,16),(0,19,11),(1,7,21),(0,18,17),(1,20,23),(1,3,15),(0,25,8),(0,22,10),(1,27,26),(1,24,28)],
587:[(1,7,3),(1,1,5),(1,1,9),(1,3,6),(1,1,10),(1,5,9),(1,13,5),(0,11,0),(1,9,0),(1,18,3),(0,12,6),(0,2,14),(0,15,7),(0,8,16),(1,22,20),(0,4,19),(1,23,17),(1,21,26),(1,25,27),(1,24,28)]}
MASK=(1<<512)-1
INPUTS=[sum(1<<r for r in range(512) if (r>>i)&1) for i in range(9)]
def graph(r,last):
    bits=[bool((r>>i)&1) for i in range(9)]+[last]
    return any(bits[a] and bits[b] for a,b in edges)
F0=sum(1<<r for r in range(512) if graph(r,False))
F1=sum(1<<r for r in range(512) if graph(r,True))
SENSITIVE=F1&~F0
def signatures(gates,positive=0,negative=0):
    vals=INPUTS.copy()
    for j,(op,a,b) in enumerate(gates):
        va=MASK if (positive>>(2*j))&1 else 0 if (negative>>(2*j))&1 else vals[a]
        vb=MASK if (positive>>(2*j+1))&1 else 0 if (negative>>(2*j+1))&1 else vals[b]
        vals.append(va&vb if op==0 else va|vb)
    out=MASK if (positive>>(2*len(gates)))&1 else 0 if (negative>>(2*len(gates)))&1 else vals[-1]
    return vals,out
def prune(gates,out):
    needed=set()
    def visit(w):
        if w<9 or w-9 in needed:return
        needed.add(w-9)
        visit(gates[w-9][1]);visit(gates[w-9][2])
    visit(out)
    remap={i:i for i in range(9)};new=[]
    for j,(op,a,b) in enumerate(gates):
        if j in needed:
            remap[9+j]=9+len(new);new.append((op,remap[a],remap[b]))
    return new,remap[out]
def normalize(gates,out):
    vals=INPUTS.copy();first={v:i for i,v in enumerate(vals)};first[0]=-1
    remap={i:i for i in range(9)};remap[-1]=-1;new=[]
    for j,(op,a,b) in enumerate(gates):
        a,b=remap[a],remap[b]
        va=vals[a] if a>=0 else 0;vb=vals[b] if b>=0 else 0
        value=va&vb if op==0 else va|vb
        if value in first:remap[9+j]=first[value];continue
        assert a>=0 and b>=0
        a,b=sorted([a,b]);remap[9+j]=9+len(new)
        first[value]=9+len(new);new.append((op,a,b));vals.append(value)
    return prune(new,remap[out])
def automorphisms(mapping=None):
    mapping={} if mapping is None else mapping
    if len(mapping)==10:
        yield tuple(mapping[i] for i in range(10));return
    v=max((v for v in range(10) if v not in mapping),key=lambda v:sum(w in mapping for w in adj[v]))
    for w in range(10):
        if w in mapping.values():continue
        if all((u in adj[v])==(mapping[u] in adj[w]) for u in mapping):
            mapping[v]=w;yield from automorphisms(mapping);del mapping[v]
def restrict(base,permutation):
    remap={i:(permutation[i] if permutation[i]!=9 else -1) for i in range(10)};gs=[]
    for j,(op,a,b) in enumerate(base):
        gs.append((op,remap[a],remap[b]));remap[10+j]=9+j
    return normalize(gs,remap[29])[0]
def rewrite(gates):
    while len(gates)>16:
        vals,out=signatures(gates);m=len(gates)
        cones=[0]*9
        for j,(op,a,b) in enumerate(gates):cones.append(cones[a]|cones[b]|(1<<j))
        best=None;bestcost=m
        for j,(oldop,olda,oldb) in enumerate(gates):
            rootwire=9+j;target=vals[rootwire]
            req=0
            def visit(w):
                nonlocal req
                if w<9 or w==rootwire or (req>>(w-9))&1:return
                req|=1<<(w-9);visit(gates[w-9][1]);visit(gates[w-9][2])
            visit(9+m-1)
            pairs=[]
            for a in range(rootwire):
                for b in range(a,rootwire):
                    cone=cones[a]|cones[b]
                    for op in range(2):
                        value=vals[a]&vals[b] if op==0 else vals[a]|vals[b]
                        cost=1+(req|cone).bit_count()
                        if value==target and cost<bestcost:
                            candidate=gates.copy();candidate[j]=(op,a,b)
                            reduced=normalize(candidate,9+m-1)[0]
                            if len(reduced)<bestcost:best=reduced;bestcost=len(reduced)
                        if 2+(req|cone).bit_count()<bestcost:pairs.append((value,op,a,b,cone))
            for value,op,a,b,cone in pairs:
                for c in range(rootwire):
                    if 2+(req|cone|cones[c]).bit_count()>=bestcost:continue
                    for outer in range(2):
                        final=value&vals[c] if outer==0 else value|vals[c]
                        if final!=target:continue
                        candidate=gates[:j]+[(op,a,b),(outer,rootwire,c)]
                        for op2,a2,b2 in gates[j+1:]:candidate.append((op2,a2+(a2>=rootwire),b2+(b2>=rootwire)))
                        reduced=normalize(candidate,9+m)[0]
                        if len(reduced)<bestcost:best=reduced;bestcost=len(reduced)
            if bestcost<=16:break
        if best is None:break
        assert signatures(best)[1]==F0
        gates=best
    return gates
def subsets(positions):
    for mask in range(1,1<<len(positions)):
        yield sum(1<<p for i,p in enumerate(positions) if (mask>>i)&1)
def full_circuit(gates,A,apos,B,bpos):
    out=[];out.append((2,9,9));mapping={i:i for i in range(9)};ra=rb=None
    def readers(w):
        nonlocal ra,rb
        if w==A:ra=10+len(out);out.append((1,9,mapping[w]))
        if w==B:rb=10+len(out);out.append((0,10,mapping[w]))
    for w in range(9):readers(w)
    for j,(op,a,b) in enumerate(gates):
        aa=ra if (apos>>(2*j))&1 else rb if (bpos>>(2*j))&1 else mapping[a]
        bb=ra if (apos>>(2*j+1))&1 else rb if (bpos>>(2*j+1))&1 else mapping[b]
        assert aa is not None and bb is not None
        mapping[9+j]=10+len(out);out.append((op,aa,bb));readers(9+j)
    final=ra if (apos>>(2*len(gates)))&1 else rb if (bpos>>(2*len(gates)))&1 else mapping[9+len(gates)-1]
    errors=[]
    for r in range(1024):
        ws=[bool((r>>i)&1) for i in range(10)]
        for op,a,b in out:ws.append(ws[a] and ws[b] if op==0 else ws[a] or ws[b] if op==1 else not ws[a])
        wanted=any(ws[a] and ws[b] for a,b in edges)
        if ws[final]!=wanted:errors.append(r)
    return {'gates':out,'output':final,'mismatches':errors}
permutations=list(automorphisms());assert len(permutations)==120
seen=set();hist={};stats={'automorphisms':120,'variants':0,'size16':0,'A_choices':0,'B_candidates':0,'full_clamps':0,'found':False}
start=time.monotonic()
for template,base in templates.items():
    for permutation in permutations:
        gates=restrict(base,permutation)
        if args.rewrite and len(gates)>16:gates=rewrite(gates)
        key=tuple(gates)
        if key in seen:continue
        seen.add(key);stats['variants']+=1;hist[len(gates)]=hist.get(len(gates),0)+1
        assert signatures(gates)[1]==F0
        if len(gates)!=16:continue
        stats['size16']+=1;index=stats['size16']
        (run/f'template-{index}.json').write_text(json.dumps({'source':template,'permutation':permutation,'gates':gates},indent=2)+'\n')
        vals,_=signatures(gates);uses=[[] for _ in vals]
        for j,(op,a,b) in enumerate(gates):uses[a].append(2*j);uses[b].append(2*j+1)
        uses[-1].append(2*len(gates))
        for A in range(len(vals)):
            if vals[A]&SENSITIVE:continue
            for apos in subsets(uses[A]):
                stats['A_choices']+=1;avals,upper=signatures(gates,apos,0)
                if F1&~upper:continue
                bad=upper&~F1
                for B in range(len(vals)):
                    if bad&~avals[B]:continue
                    stats['B_candidates']+=1
                    for bpos in subsets(uses[B]):
                        if apos&bpos:continue
                        stats['full_clamps']+=1
                        if signatures(gates,apos,bpos)[1]!=F1:continue
                        witness=full_circuit(gates,A,apos,B,bpos)
                        witness.update(template=index,A=A,A_positions=apos,B=B,B_positions=bpos)
                        (run/'witness.json').write_text(json.dumps(witness,indent=2)+'\n')
                        assert not witness['mismatches'] and len(witness['gates'])==19
                        stats['found']=True;print('FULL 19-GATE COUNTEREXAMPLE VERIFIED',flush=True);break
                    if stats['found']:break
                if stats['found']:break
            if stats['found']:break
        if stats['found'] or (args.limit and stats['size16']>=args.limit):break
    if stats['found'] or (args.limit and stats['size16']>=args.limit):break
stats.update(histogram=hist,elapsed=round(time.monotonic()-start,2))
(run/'summary.json').write_text(json.dumps(stats,indent=2)+'\n');print(json.dumps(stats),flush=True)
