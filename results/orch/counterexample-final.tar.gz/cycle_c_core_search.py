#!/usr/bin/env python3
import argparse
import itertools
import json
from pathlib import Path
import subprocess
import time

parser=argparse.ArgumentParser()
parser.add_argument('--seconds',type=int,default=300)
parser.add_argument('--seed',type=int,default=0)
parser.add_argument('--fixed-ors',action='store_true')
args=parser.parse_args()
root=Path(__file__).parent
run=root/('cycle-c-core13'+('-fixed' if args.fixed_ors else '-free')+'-seed'+str(args.seed))
run.mkdir(exist_ok=True)
n,s=7,13
def target(r):
    bits=[bool((r>>i)&1) for i in range(6)]
    aa=bits[0::2];bb=bits[1::2]
    H=any(aa[i] and bb[j] for i in range(3) for j in range(3) if i!=j)
    return [bool((r>>6)&1) or aa[i] or bb[i] for i in range(3)]+[H]
original_core=[(1,0,1),(1,6,7),(1,2,3),(1,6,9),(1,4,5),(1,6,11),(1,3,5),(0,0,13),(1,1,5),(0,2,15),(1,1,3),(0,4,17),(1,14,16),(1,19,18)]
def run_circuit(n,gates,out,r):
    wires=[bool((r>>i)&1) for i in range(n)]
    for op,a,b in gates:
        u=wires[a] if a<len(wires) else False
        v=wires[b] if b<len(wires) else False
        wires.append(u and v if op==0 else u or v if op==1 else not u)
    return [wires[o] if o<len(wires) else False for o in out]
assert all(run_circuit(7,original_core,[8,10,12,20],r)==target(r) for r in range(128))
variables={}; clauses=[]; nv=0
def var(*key):
    global nv
    if key not in variables:
        nv+=1;variables[key]=nv
    return variables[key]
def add(*lits): clauses.append(list(lits))
def onehot(vs):
    add(*vs)
    for a,b in itertools.combinations(vs,2): add(-a,-b)
for j in range(s):
    onehot([var('op',j,o) for o in range(3)])
    for side in range(2): onehot([var('src',j,side,k) for k in range(n+j+1)])
    for a in range(n+j+1):
        for b in range(a): add(-var('src',j,0,a),-var('src',j,1,b),var('op',j,2))
        add(-var('op',j,2),-var('src',j,0,a),var('src',j,1,a))
    if args.fixed_ors and j<6:
        a,b=[(0,1),(6,7),(2,3),(6,9),(4,5),(6,11)][j]
        add(var('op',j,1));add(var('src',j,0,a));add(var('src',j,1,b))
add(*[var('op',j,2) for j in range(s)])
for js in itertools.combinations(range(s),3):add(*[-var('op',j,2) for j in js])
for output in range(4):
    onehot([var('out',output,k) for k in range(n+s+1)])
    if args.fixed_ors and output<3: add(var('out',output,n+2*output+1))
for r in range(128):
    for j in range(s):
        w,u,v=var('w',j,r),var('u',j,r),var('v',j,r)
        for side,pin in [(0,u),(1,v)]:
            for k in range(n+j+1):
                source=var('src',j,side,k)
                if k<n:
                    add(-source,pin if (r>>k)&1 else -pin)
                elif k<n+j:
                    previous=var('w',k-n,r)
                    add(-source,-pin,previous);add(-source,pin,-previous)
                else: add(-source,-pin)
        o0,o1,o2=[var('op',j,o) for o in range(3)]
        add(-o0,-w,u);add(-o0,-w,v);add(-o0,w,-u,-v)
        add(-o1,w,-u);add(-o1,w,-v);add(-o1,-w,u,v)
        add(-o2,w,u);add(-o2,-w,-u)
    for output,wanted in enumerate(target(r)):
        for k in range(n+s+1):
            selector=var('out',output,k)
            if k<n:
                if bool((r>>k)&1)!=wanted:add(-selector)
            elif k<n+s:
                w=var('w',k-n,r);add(-selector,w if wanted else -w)
            elif wanted:add(-selector)
cnf=run/'core.cnf'
with cnf.open('w') as f:
    f.write(f'p cnf {nv} {len(clauses)}\n')
    for c in clauses:f.write(' '.join(map(str,c))+' 0\n')
info={'vars':nv,'clauses':len(clauses),'seconds':args.seconds,'seed':args.seed,'fixed_ors':args.fixed_ors}
(run/'parameters.json').write_text(json.dumps(info,indent=2)+'\n')
print(json.dumps(info),flush=True)
start=time.monotonic()
with (run/'solver.log').open('w') as f:
    result=subprocess.run([str(root/'cadical/build/cadical'),'-t',str(args.seconds),'--seed='+str(args.seed),str(cnf)],stdout=f,stderr=subprocess.STDOUT)
print(json.dumps({'exit':result.returncode,'elapsed':round(time.monotonic()-start,2)}),flush=True)
if result.returncode==10:
    model={int(v) for l in (run/'solver.log').read_text().splitlines() if l.startswith('v ') for v in l[2:].split() if int(v)>0}
    gates=[]
    for j in range(s):
        op=next(o for o in range(3) if variables['op',j,o] in model)
        a=next(k for k in range(n+j+1) if variables['src',j,0,k] in model)
        b=next(k for k in range(n+j+1) if variables['src',j,1,k] in model)
        gates.append((op,a,b))
    outputs=[next(k for k in range(n+s+1) if variables['out',o,k] in model) for o in range(4)]
    mismatches=[r for r in range(128) if run_circuit(7,gates,outputs,r)!=target(r)]
    witness={'gates':gates,'outputs':outputs,'mismatches':mismatches}
    (run/'core-witness.json').write_text(json.dumps(witness,indent=2)+'\n')
    assert not mismatches, 'encoding/model extraction error'
    new=[]
    helper_map={i:v for i,v in enumerate([0,3,8,1,2,5,9])}
    for j,(op,a,b) in enumerate(gates):
        helper_map[7+j]=10+j
        new.append((op,helper_map[a],helper_map[b]))
    computed=[helper_map[o] for o in outputs]
    stars=[]
    for i,y in enumerate([4,6,7]):
        t=10+len(new);new.append((0,y,computed[i]));stars.append(t)
    final=computed[3]
    for t in stars:
        q=10+len(new);new.append((1,final,t));final=q
    edges=[(0,1),(1,2),(2,3),(3,4),(4,0),(0,5),(1,6),(2,7),(3,8),(4,9),(5,7),(7,9),(9,6),(6,8),(8,5)]
    errors=[]
    for r in range(1024):
        wanted=any((r>>a)&1 and (r>>b)&1 for a,b in edges)
        if run_circuit(10,new,[final],r)[0]!=wanted:errors.append(r)
    full={'n':10,'gates':new,'output':final,'not_count':sum(op==2 for op,a,b in new),'mismatches':errors}
    (run/'full-witness.json').write_text(json.dumps(full,indent=2)+'\n')
    assert not errors and len(new)==19
    print('FULL 19-GATE COUNTEREXAMPLE VERIFIED ON 1024 ROWS',flush=True)
