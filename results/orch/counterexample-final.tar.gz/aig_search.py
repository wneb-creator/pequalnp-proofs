#!/usr/bin/env python3
import argparse
import itertools
import json
from pathlib import Path
import subprocess
import time

parser=argparse.ArgumentParser()
parser.add_argument('--gates',type=int,default=18)
parser.add_argument('--not-budget',type=int,default=1)
parser.add_argument('--seconds',type=int,default=600)
parser.add_argument('--seed',type=int,default=0)
parser.add_argument('--first-pair',choices=['edge','nonedge','free'],default='nonedge')
parser.add_argument('--boundary',action='store_true')
parser.add_argument('--projection',choices=['none','adjacent','nonadjacent','delete9'],default='none')
parser.add_argument('--self-check',action='store_true')
args=parser.parse_args()
if args.self_check:
    args.gates=20;args.not_budget=0;args.projection='none';args.first_pair='free';args.boundary=True
root=Path(__file__).parent
n,s=(10 if args.projection=='none' else 9),args.gates
if args.projection!='none':args.first_pair='free'
edges=[(0,1),(1,2),(2,3),(3,4),(4,0),(0,5),(1,6),(2,7),(3,8),(4,9),(5,7),(7,9),(9,6),(6,8),(8,5)]
def target(r):
    if args.projection=='none':
        bits=[bool((r>>i)&1) for i in range(10)]
    elif args.projection=='delete9':
        bits=[bool((r>>i)&1) for i in range(9)]+[False]
    else:
        omitted=1 if args.projection=='adjacent' else 2
        kept=[i for i in range(10) if i!=omitted]
        bits=[False]*10
        for j,i in enumerate(kept):bits[i]=bool((r>>j)&1)
        bits[omitted]=not bits[0]
    return any(bits[a] and bits[b] for a,b in edges)
rows=list(range(1<<n))
if args.boundary:
    pos=[r for r in rows if target(r)];neg=[r for r in rows if not target(r)]
    rows=sorted([r for r in pos if not any(q!=r and q&r==q for q in pos)]+[r for r in neg if not any(q!=r and q&r==r for q in neg)])
tag=f'aig{s}-not{args.not_budget}-{args.first_pair}-{args.projection}-'+('boundary' if args.boundary else 'full')+f'-seed{args.seed}'
run=root/tag;run.mkdir(exist_ok=True)
variables={};clauses=[];nv=0
def var(*key):
    global nv
    if key not in variables:nv+=1;variables[key]=nv
    return variables[key]
def add(*xs):clauses.append(list(xs))
def onehot(vs):
    add(*vs)
    for a,b in itertools.combinations(vs,2):add(-a,-b)
def even_guard(source,fee,vs):
    for assignment in itertools.product([0,1],repeat=len(vs)):
        if sum(assignment)%2:
            add(-source,fee,*[-v if b else v for v,b in zip(vs,assignment)])
for j in range(s):
    pj=var('pol',j)
    for side in range(2):
        onehot([var('src',j,side,k) for k in range(n+j+1)])
        sign=var('sign',j,side)
        for k in range(n+j+1):
            origin=k if k<n+j else n+s
            ps=[sign,pj]+([var('pol',k-n)] if n<=k<n+j else [])
            even_guard(var('src',j,side,k),var('fee',origin),ps)
    for a in range(n+j+1):
        for b in range(a):add(-var('src',j,0,a),-var('src',j,1,b))
        add(-var('src',j,0,a),-var('src',j,1,a),-var('sign',j,0),var('sign',j,1))
if args.first_pair!='free':
    add(var('src',0,0,0));add(var('src',0,1,1 if args.first_pair=='edge' else 2))
for j in range(s-1):
    add(*[var('src',k,side,n+j) for k in range(j+1,s) for side in range(2)])
outsign=var('outsign')
lastpol=var('pol',s-1);lastfee=var('fee',n+s-1)
add(lastfee,-outsign,lastpol);add(lastfee,outsign,-lastpol)
fees=[var('fee',i) for i in range(n+s+1)]
if args.not_budget>=0:
    for vs in itertools.combinations(fees,args.not_budget+1):add(*[-v for v in vs])
for r in rows:
    for j in range(s):
        pins=[]
        for side in range(2):
            raw=var('raw',j,side,r);pin=var('pin',j,side,r);sign=var('sign',j,side)
            for k in range(n+j+1):
                src=var('src',j,side,k)
                if k<n:add(-src,raw if (r>>k)&1 else -raw)
                elif k<n+j:
                    prior=var('w',k-n,r);add(-src,-raw,prior);add(-src,raw,-prior)
                else:add(-src,-raw)
            for x,y,z in itertools.product([0,1],repeat=3):
                if z!=(x^y):add(*[-v if b else v for v,b in zip([raw,sign,pin],[x,y,z])])
            pins.append(pin)
        w=var('w',j,r);u,v=pins
        add(-w,u);add(-w,v);add(w,-u,-v)
    w=var('w',s-1,r)
    if target(r):add(w,outsign);add(-w,-outsign)
    else:add(-w,outsign);add(w,-outsign)
if args.self_check:
    base=[(1,9,5),(1,0,9),(1,0,6),(1,7,3),(0,1,12),(1,6,5),(1,11,3),(1,13,1),(1,14,2),(0,12,15),(0,4,16),(0,19,11),(1,7,21),(0,18,17),(1,20,23),(1,3,15),(0,25,8),(0,22,10),(1,27,26),(1,24,28)]
    pol=[bool(op) for op,a,b in base]
    sources=[sorted([a,b]) for op,a,b in base]
    vals={}
    for r in rows:
        ws=[bool((r>>i)&1) for i in range(10)]
        for op,a,b in base:ws.append(ws[a] and ws[b] if op==0 else ws[a] or ws[b])
        assert ws[-1]==target(r)
        vals[r]=ws
    assignment={}
    for key,v in variables.items():
        if key[0]=='src':
            _,j,side,k=key;value=(sources[j][side]==k)
        elif key[0]=='pol':value=pol[key[1]]
        elif key[0]=='sign':
            _,j,side=key;k=sources[j][side];value=pol[j]^(pol[k-10] if k>=10 else False)
        elif key[0]=='fee':value=False
        elif key[0]=='outsign':value=pol[-1]
        elif key[0]=='w':
            _,j,r=key;value=vals[r][10+j]^pol[j]
        elif key[0] in ['raw','pin']:
            kind,j,side,r=key;k=sources[j][side]
            value=vals[r][k]^(pol[j] if kind=='pin' else pol[k-10] if k>=10 else False)
        else:raise AssertionError(key)
        assignment[v]=value
    bad=[i for i,c in enumerate(clauses) if not any(assignment[abs(l)]==(l>0) for l in c)]
    report={'self_check':'known20gate_monotone_witness','rows':len(rows),'clauses':len(clauses),'failed_clauses':bad[:10],'failure_count':len(bad)}
    (run/'self-check.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report),flush=True)
    assert not bad
    raise SystemExit()
cnf=run/'formula.cnf'
with cnf.open('w') as f:
    f.write(f'p cnf {nv} {len(clauses)}\n')
    for c in clauses:f.write(' '.join(map(str,c))+' 0\n')
info={'projection':args.projection,'inputs':n,'gates':s,'not_budget':args.not_budget,'rows':rows,'first_pair':args.first_pair,'vars':nv,'clauses':len(clauses),'seconds':args.seconds,'seed':args.seed}
(run/'parameters.json').write_text(json.dumps(info,indent=2)+'\n')
print(json.dumps({k:v for k,v in info.items() if k!='rows'}|{'row_count':len(rows)}),flush=True)
start=time.monotonic()
with (run/'solver.log').open('w') as f:
    result=subprocess.run([str(root/'cadical/build/cadical'),'-t',str(args.seconds),'--seed='+str(args.seed),str(cnf)],stdout=f,stderr=subprocess.STDOUT)
print(json.dumps({'exit':result.returncode,'elapsed':round(time.monotonic()-start,2)}),flush=True)
if result.returncode!=10:raise SystemExit()
model={int(v) for l in (run/'solver.log').read_text().splitlines() if l.startswith('v ') for v in l[2:].split() if int(v)>0}
nodes=[]
for j in range(s):
    inputs=[]
    for side in range(2):
        k=next(k for k in range(n+j+1) if variables['src',j,side,k] in model)
        inputs.append((k if k<n+j else n+s,variables['sign',j,side] in model))
    nodes.append(inputs)
output_sign=outsign in model
polarity=[variables['pol',j] in model for j in range(s)]
if args.not_budget<0:
    import numpy as np
    choices=np.arange(1<<s,dtype=np.uint32);cost=np.zeros(1<<s,dtype=np.uint8)
    outgoing=[[] for _ in range(n+s+1)]
    for j,inputs in enumerate(nodes):
        for source,sign in inputs:outgoing[source].append((j,sign))
    for source,uses in enumerate(outgoing):
        actual=((choices>>(source-n))&1) if n<=source<n+s else 0
        bad=np.zeros(1<<s,dtype=np.uint8)
        for j,sign in uses:bad|=(((choices>>j)&1)^sign^actual).astype(np.uint8)
        if source==n+s-1:bad|=(actual^output_sign).astype(np.uint8)
        cost+=bad
    best=int(np.argmin(cost));polarity=[bool((best>>j)&1) for j in range(s)]
    print(json.dumps({'minimum_explicit_nots':int(cost[best]),'polarity':polarity}),flush=True)
new=[];wire={i:(i,False) for i in range(n)};wire[n+s]=(1000000,False);negatives={}
def requested(source,wanted):
    index,actual=wire[source]
    if actual==wanted:return index
    if source not in negatives:
        negatives[source]=n+len(new);new.append((2,index,index))
    return negatives[source]
for j,inputs in enumerate(nodes):
    p=polarity[j]
    a=requested(inputs[0][0],inputs[0][1]^p)
    b=requested(inputs[1][0],inputs[1][1]^p)
    wire[n+j]=(n+len(new),p);new.append((1 if p else 0,a,b))
output=requested(n+s-1,output_sign)
notcount=sum(op==2 for op,a,b in new)
if args.projection=='none' and notcount==0 and len(new)<19:
    new.append((2,0,0));notcount=1
def evaluates(r):
    ws=[bool((r>>i)&1) for i in range(n)]
    for op,a,b in new:
        x=ws[a] if a<len(ws) else False;y=ws[b] if b<len(ws) else False
        ws.append(x and y if op==0 else x or y if op==1 else not x)
    return ws[output]
errors=[r for r in range(1<<n) if evaluates(r)!=target(r)]
witness={'projection':args.projection,'inputs':n,'aig_nodes':nodes,'aig_output_sign':output_sign,'polarity':polarity,'gates':new,'output':output,'not_count':notcount,'mismatches':errors}
(run/'witness.json').write_text(json.dumps(witness,indent=2)+'\n')
print(json.dumps({'actual_size':len(new),'not_count':notcount,'full_table_errors':len(errors)}),flush=True)
if args.projection=='none' and not errors and len(new)<=19 and notcount:
    print('FULL COUNTEREXAMPLE VERIFIED ON 1024 ROWS',flush=True)

if args.projection!='none' and not errors:
    print('PROJECTED SIGNED CIRCUIT VERIFIED ON FULL TABLE',flush=True)
