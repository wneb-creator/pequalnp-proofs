#!/usr/bin/env python3
import argparse
import itertools
import json
from pathlib import Path
import subprocess
import time

parser=argparse.ArgumentParser()
parser.add_argument('--seconds',type=int,default=60)
parser.add_argument('--max-nots',type=int,default=3)
parser.add_argument('--seed',type=int,default=0)
args=parser.parse_args()
root=Path(__file__).parent
base=[(1,9,5),(1,0,9),(1,0,6),(1,7,3),(0,1,12),(1,6,5),(1,11,3),(1,13,1),(1,14,2),(0,12,15),(0,4,16),(0,19,11),(1,7,21),(0,18,17),(1,20,23),(1,3,15),(0,25,8),(0,22,10),(1,27,26),(1,24,28)]
core={0,1,2,5,9,11,12,17}
extensions=[{4},{6},{15},{6,15},{4,6},{4,15},{6,10},{15,16},{4,8},{3,7}]
edges=[(0,1),(1,2),(2,3),(3,4),(4,0),(0,5),(1,6),(2,7),(3,8),(4,9),(5,7),(7,9),(9,6),(6,8),(8,5)]
def evaluate(n,gates,outputs,r):
    ws=[bool((r>>i)&1) for i in range(n)]
    for op,a,b in gates:
        u=ws[a] if a<len(ws) else False;v=ws[b] if b<len(ws) else False
        ws.append(u and v if op==0 else u or v if op==1 else not u)
    return [ws[o] if o<len(ws) else False for o in outputs]
for extension in extensions:
    chosen=core|extension
    boundary=sorted({i for j in chosen for i in base[j][1:] if i<10 or i-10 not in chosen})
    assert all(i<10 for i in boundary), 'boundary cycle requires scheduling analysis'
    exposed=sorted({i for j,g in enumerate(base) if j not in chosen for i in g[1:] if i>=10 and i-10 in chosen} | ({29} if 19 in chosen else set()))
    remap={wire:i for i,wire in enumerate(boundary)}
    small=[]
    for j,(op,a,b) in enumerate(base):
        if j in chosen:
            small.append((op,remap[a],remap[b]));remap[10+j]=len(boundary)+len(small)-1
    small_out=[remap[i] for i in exposed]
    n,s=len(boundary),len(chosen)-1
    truth=[evaluate(n,small,small_out,r) for r in range(1<<n)]
    tag='window-'+','.join(map(str,sorted(extension)))+'-not'+str(args.max_nots)+'-seed'+str(args.seed)
    run=root/tag;run.mkdir(exist_ok=True)
    nv=0;variables={};clauses=[]
    def var(*key):
        global nv
        if key not in variables:nv+=1;variables[key]=nv
        return variables[key]
    def add(*lits):clauses.append(list(lits))
    def onehot(vs):
        add(*vs)
        for a,b in itertools.combinations(vs,2):add(-a,-b)
    for j in range(s):
        onehot([var('op',j,o) for o in range(3)])
        for side in range(2):onehot([var('src',j,side,k) for k in range(n+j+1)])
        for a in range(n+j+1):
            for b in range(a):add(-var('src',j,0,a),-var('src',j,1,b),var('op',j,2))
            add(-var('op',j,2),-var('src',j,0,a),var('src',j,1,a))
    nots=[var('op',j,2) for j in range(s)];add(*nots)
    for vs in itertools.combinations(nots,args.max_nots+1):add(*[-v for v in vs])
    for o in range(len(exposed)):onehot([var('out',o,k) for k in range(n+s+1)])
    for r,wants in enumerate(truth):
        for j in range(s):
            w,u,v=var('w',j,r),var('u',j,r),var('v',j,r)
            for side,pin in [(0,u),(1,v)]:
                for k in range(n+j+1):
                    src=var('src',j,side,k)
                    if k<n:add(-src,pin if (r>>k)&1 else -pin)
                    elif k<n+j:
                        previous=var('w',k-n,r);add(-src,-pin,previous);add(-src,pin,-previous)
                    else:add(-src,-pin)
            o0,o1,o2=[var('op',j,o) for o in range(3)]
            add(-o0,-w,u);add(-o0,-w,v);add(-o0,w,-u,-v)
            add(-o1,w,-u);add(-o1,w,-v);add(-o1,-w,u,v)
            add(-o2,w,u);add(-o2,-w,-u)
        for o,wanted in enumerate(wants):
            for k in range(n+s+1):
                src=var('out',o,k)
                if k<n:
                    if bool((r>>k)&1)!=wanted:add(-src)
                elif k<n+s:
                    w=var('w',k-n,r);add(-src,w if wanted else -w)
                elif wanted:add(-src)
    cnf=run/'formula.cnf'
    with cnf.open('w') as f:
        f.write(f'p cnf {nv} {len(clauses)}\n')
        for c in clauses:f.write(' '.join(map(str,c))+' 0\n')
    info={'extension':sorted(extension),'selected':sorted(chosen),'boundary_inputs':boundary,'exposed_outputs':exposed,'n':n,'gates':s,'rows':len(truth),'max_nots':args.max_nots,'vars':nv,'clauses':len(clauses),'seconds':args.seconds}
    (run/'parameters.json').write_text(json.dumps(info,indent=2)+'\n')
    start=time.monotonic()
    with (run/'solver.log').open('w') as f:
        result=subprocess.run([str(root/'cadical/build/cadical'),'-t',str(args.seconds),'--seed='+str(args.seed),str(cnf)],stdout=f,stderr=subprocess.STDOUT)
    info.update(exit=result.returncode,elapsed=round(time.monotonic()-start,2))
    (run/'result.json').write_text(json.dumps(info,indent=2)+'\n');print(json.dumps(info),flush=True)
    if result.returncode!=10:continue
    model={int(v) for l in (run/'solver.log').read_text().splitlines() if l.startswith('v ') for v in l[2:].split() if int(v)>0}
    gates=[]
    for j in range(s):
        op=next(o for o in range(3) if variables['op',j,o] in model)
        a=next(k for k in range(n+j+1) if variables['src',j,0,k] in model)
        b=next(k for k in range(n+j+1) if variables['src',j,1,k] in model)
        gates.append((op,a,b))
    outputs=[next(k for k in range(n+s+1) if variables['out',o,k] in model) for o in range(len(exposed))]
    errors=[r for r in range(1<<n) if evaluate(n,gates,outputs,r)!=truth[r]]
    (run/'core-witness.json').write_text(json.dumps({'gates':gates,'outputs':outputs,'errors':errors},indent=2)+'\n')
    assert not errors
    new=[];helper={i:wire for i,wire in enumerate(boundary)}
    for j,(op,a,b) in enumerate(gates):
        helper[n+j]=10+j;new.append((op,helper[a],helper[b]))
    old_map={i:i for i in range(10)}
    old_map.update({wire:helper[o] for wire,o in zip(exposed,outputs)})
    for j,(op,a,b) in enumerate(base):
        if j in chosen:continue
        old_map[10+j]=10+len(new);new.append((op,old_map[a],old_map[b]))
    mismatches=[]
    for r in range(1024):
        wanted=any((r>>a)&1 and (r>>b)&1 for a,b in edges)
        if evaluate(10,new,[old_map[29]],r)[0]!=wanted:mismatches.append(r)
    witness={'gates':new,'output':old_map[29],'not_count':sum(op==2 for op,a,b in new),'mismatches':mismatches}
    (run/'full-witness.json').write_text(json.dumps(witness,indent=2)+'\n')
    assert not mismatches and len(new)==19
    print('FULL 19-GATE COUNTEREXAMPLE VERIFIED',flush=True)
    break
