#!/usr/bin/env python3
import argparse
import itertools
import json
from pathlib import Path
import random
import re


def validate(aig):
    n = aig['n']
    assert isinstance(n, int) and n >= 0
    gates = aig['gates']
    for j, pair in enumerate(gates):
        assert len(pair) == 2
        for source, polarity in pair:
            assert isinstance(source, int) and 0 <= source < n + 1 + j
            assert polarity in (0, 1)
    source, polarity = aig['output']
    assert 0 <= source < n + 1 + len(gates) and polarity in (0, 1)


def demands(aig):
    validate(aig)
    n, gates = aig['n'], aig['gates']
    outgoing = [[] for _ in range(n + 1 + len(gates))]
    for j, pair in enumerate(gates):
        for source, polarity in pair:
            outgoing[source].append((j, polarity))
    outgoing[aig['output'][0]].append((-1, aig['output'][1]))
    return outgoing


def cost(aig, orientation):
    n = aig['n']
    outgoing = demands(aig)
    result = 0
    for source, edges in enumerate(outgoing):
        own = (orientation >> (source - n - 1)) & 1 if source > n else 0
        if any((polarity ^ ((orientation >> target) & 1 if target >= 0 else 0)) != own
               for target, polarity in edges):
            result += 1
    return result


def minimize(aig):
    n, gates = aig['n'], aig['gates']
    b = len(gates)
    outgoing = demands(aig)
    bad = [sum(polarity for _, polarity in edges) for edges in outgoing]
    degrees = [len(edges) for edges in outgoing]
    current = sum(value > 0 for value in bad)
    best, best_orientation, orientation = current, 0, 0
    visited = 1
    if best == 0:
        return {'not_count': best, 'orientation': best_orientation, 'visited': visited, 'binary_count': b}
    for step in range(1, 1 << b):
        changed = (step & -step).bit_length() - 1
        source_node = n + 1 + changed
        old_bit = (orientation >> changed) & 1
        old = bad[source_node]
        bad[source_node] = degrees[source_node] - old
        current += (bad[source_node] > 0) - (old > 0)
        for parent, polarity in gates[changed]:
            parent_bit = (orientation >> (parent - n - 1)) & 1 if parent > n else 0
            was_bad = polarity ^ old_bit ^ parent_bit
            old = bad[parent]
            bad[parent] += -1 if was_bad else 1
            current += (bad[parent] > 0) - (old > 0)
        orientation ^= 1 << changed
        visited += 1
        if current < best:
            best, best_orientation = current, orientation
            if best == 0:
                break
    assert cost(aig, best_orientation) == best
    return {'not_count': best, 'orientation': best_orientation, 'visited': visited, 'binary_count': b}


def reconstruct(aig, orientation):
    n = aig['n']
    b = len(aig['gates'])
    false_wire = 2 * n + 2 * b + 2
    gates = []
    available = [{0: i} for i in range(n)] + [{0: false_wire}]

    def get(source, polarity):
        table = available[source]
        if polarity not in table:
            other = table[1 - polarity]
            gates.append(['not', [other]])
            table[polarity] = n + len(gates) - 1
        return table[polarity]

    for j, pair in enumerate(aig['gates']):
        selected = (orientation >> j) & 1
        operands = [get(source, polarity ^ selected) for source, polarity in pair]
        gates.append(['or' if selected else 'and', operands])
        available.append({selected: n + len(gates) - 1})
    output = get(*aig['output'])
    expected = b + cost(aig, orientation)
    assert len(gates) == expected
    assert false_wire >= n + len(gates)
    return {'n': n, 'gates': gates, 'output': output}


def eval_aig(aig, mask):
    wires = [bool(mask >> i & 1) for i in range(aig['n'])] + [False]
    for pair in aig['gates']:
        wires.append(all(wires[source] != bool(polarity) for source, polarity in pair))
    source, polarity = aig['output']
    return wires[source] != bool(polarity)


def eval_circuit(circuit, mask):
    wires = [bool(mask >> i & 1) for i in range(circuit['n'])]
    for operation, inputs in circuit['gates']:
        values = [wires[i] if i < len(wires) else False for i in inputs]
        if operation == 'and': value = all(values)
        elif operation == 'or': value = any(values)
        else: value = not (values[0] if values else False)
        wires.append(value)
    return wires[circuit['output']] if circuit['output'] < len(wires) else False


def from_circuit(circuit):
    n = circuit['n']
    gates, wire_literals = [], [(i, 0) for i in range(n)]
    false_literal = (n, 0)
    for operation, inputs in circuit['gates']:
        values = [wire_literals[i] if i < len(wire_literals) else false_literal for i in inputs]
        if operation == 'not':
            source, polarity = values[0] if values else false_literal
            value = (source, 1 - polarity)
        elif len(values) == 0:
            value = (n, int(operation == 'and'))
        elif len(values) == 1:
            value = values[0]
        else:
            assert len(values) == 2
            negate = int(operation == 'or')
            gates.append([[source, polarity ^ negate] for source, polarity in values])
            value = (n + len(gates), negate)
        wire_literals.append(value)
    output = wire_literals[circuit['output']] if circuit['output'] < len(wire_literals) else false_literal
    return {'n': n, 'gates': gates, 'output': output}


def self_test(witness_path):
    rng = random.Random(2592096)
    cases, rows = 0, 0
    for n in range(0, 5):
        for b in range(0, 9):
            for _ in range(12):
                aig = {'n': n, 'gates': [], 'output': [0, 0]}
                for j in range(b):
                    aig['gates'].append([[rng.randrange(n + 1 + j), rng.randrange(2)] for _ in range(2)])
                aig['output'] = [rng.randrange(n + 1 + b), rng.randrange(2)]
                result = minimize(aig)
                naive = min(cost(aig, mask) for mask in range(1 << b))
                assert result['not_count'] == naive
                circuit = reconstruct(aig, result['orientation'])
                for mask in range(1 << n):
                    assert eval_aig(aig, mask) == eval_circuit(circuit, mask)
                    rows += 1
                cases += 1
    original_cases = 0
    for n in range(1, 5):
        for _ in range(80):
            circuit = {'n': n, 'gates': [], 'output': 0}
            for j in range(rng.randrange(1, 12)):
                operation = rng.choice(['and', 'or', 'not'])
                arity = 1 if operation == 'not' else 2
                circuit['gates'].append([operation, [rng.randrange(n + j + 2) for _ in range(arity)]])
            circuit['output'] = rng.randrange(n + len(circuit['gates']) + 2)
            aig = from_circuit(circuit)
            result = minimize(aig)
            recovered = reconstruct(aig, result['orientation'])
            assert len(recovered['gates']) <= len(circuit['gates'])
            for mask in range(1 << n):
                assert eval_circuit(circuit, mask) == eval_aig(aig, mask) == eval_circuit(recovered, mask)
                rows += 1
            original_cases += 1
    source = Path(witness_path).read_text()
    witness_gates = [[op, [int(a), int(b)]] for op, a, b in re.findall(r'⟨\.(and|or), \[(\d+), (\d+)\]⟩', source)]
    witness = {'n': 10, 'gates': witness_gates, 'output': 29}
    assert len(witness_gates) == 20
    aig = from_circuit(witness)
    result = minimize(aig)
    recovered = reconstruct(aig, result['orientation'])
    assert result['not_count'] == 0 and len(recovered['gates']) == 20
    for mask in range(1024):
        assert eval_circuit(witness, mask) == eval_aig(aig, mask) == eval_circuit(recovered, mask)
        rows += 1
    return {'random_aig_cases': cases, 'random_root_circuits': original_cases, 'truth_rows': rows,
            'known_petersen': result, 'status': 'passed'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('input', nargs='?')
    parser.add_argument('--self-test', metavar='PETERSEN_SOURCE')
    args = parser.parse_args()
    if args.self_test:
        print(json.dumps(self_test(args.self_test), indent=2))
        return
    if not args.input:
        parser.error('provide an AIG JSON path or --self-test')
    aig = json.loads(Path(args.input).read_text())
    result = minimize(aig)
    result['circuit'] = reconstruct(aig, result['orientation'])
    result['truth_table'] = ''.join(str(int(eval_circuit(result['circuit'], x))) for x in range(1 << aig['n']))
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
