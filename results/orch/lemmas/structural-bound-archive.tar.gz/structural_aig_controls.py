import json
from pathlib import Path
import random
import re
import time
from structural_aig_sat import encode, solve, parse_model, check_model, decode, initial_rows, target
from structural_aig_orient import from_circuit, eval_aig, minimize

solver = '/tmp/oec/pequalnp-pilot-96/toolchain/lean-4.36.0-linux/bin/cadical'
root = Path('/tmp/oec/pequalnp-pilot-96')
rng = random.Random(259296)
start = time.monotonic()
checks = []
for test in range(40):
    n = rng.randrange(4)
    b = rng.randrange(1,5)
    aig = {'n': n, 'gates': [], 'output': [n+b,rng.randrange(2)]}
    for j in range(b):
        aig['gates'].append([[rng.randrange(n+1+j),rng.randrange(2)] for _ in range(2)])
    optimum = minimize(aig)['not_count']
    for cap in sorted({max(0,optimum-1),optimum}):
        cnf,selectors,phase = encode(n,b,range(1<<n),lambda m: eval_aig(aig,m),cap,pinned=aig)
        stem = root / ('aig-control-' + str(test) + '-' + str(cap))
        code,text = solve(cnf,solver,5,stem)
        assert code == (10 if cap >= optimum else 20), (test,cap,optimum,code)
        if code == 10:
            model = parse_model(text)
            check_model(cnf,model)
            decoded,_ = decode(n,selectors,phase,model)
            assert all(eval_aig(decoded,m) == eval_aig(aig,m) for m in range(1<<n))
        checks.append({'case':test,'cap':cap,'optimum':optimum,'status':code})
source = Path('/workspace/pequalnp-proofs/results/orch/lemmas/PetersenWitness.lean').read_text()
gates = [[op,[int(a),int(b)]] for op,a,b in re.findall(r'⟨\.(and|or), \[(\d+), (\d+)\]⟩',source)]
assert len(gates) == 20
witness = from_circuit({'n':10,'gates':gates,'output':29})
cnf,selectors,phase = encode(10,20,initial_rows(),target,0,pinned=witness)
code,text = solve(cnf,solver,10,root/'aig-control-petersen20')
assert code == 10
model = parse_model(text)
check_model(cnf,model)
aig,_ = decode(10,selectors,phase,model)
assert all(eval_aig(aig,m) == bool(target(m)) for m in range(1024))
report = {'status':'passed','random_pinned_checks':len(checks),'known_petersen20':{'status':code,'paid_not_cap':0,'all_rows_verified':1024},'wall_seconds':time.monotonic()-start,'checks':checks}
(root/'structural-aig-controls.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k != 'checks'}),flush=True)
