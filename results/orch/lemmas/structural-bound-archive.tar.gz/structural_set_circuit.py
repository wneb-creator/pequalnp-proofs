import json
from itertools import combinations
from pathlib import Path
import time

start=time.monotonic()
pairs=list(combinations(range(4),2))
goals=frozenset(sum(1<<k for k,pair in enumerate(pairs) if i in pair) for i in range(4))
initial=frozenset([0]+[1<<i for i in range(6)])
def generated(state):
    out=set()
    for a,b in combinations(state,2):
        out.update([a|b,a&b,a&~b,b&~a])
    return out-state
def closure(state):
    while True:
        add=generated(state)&goals
        if not add:return state
        state=state|add

layers=[{closure(initial): []}]
found=None
for level in range(4):
    layer=layers[level]
    done=[(state,path) for state,path in layer.items() if goals<=state]
    if done:
        found={'non_goal_count':level,'state':sorted(done[0][0]),'path':done[0][1]}
        break
    if level==3:break
    following={}
    for state,path in layer.items():
        for value in generated(state)-goals:
            nxt=closure(state|{value})
            following.setdefault(nxt,path+[value])
    layers.append(following)
report={'status':'FOUND' if found else 'EXHAUSTED','goals':sorted(goals),'states_by_layer':[len(layer) for layer in layers],'max_goals_by_layer':[max(len(state&goals) for state in layer) for layer in layers],'witness':found,'wall_seconds':time.monotonic()-start}
Path('/tmp/oec/pequalnp-pilot-96/structural-set-circuit.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report),flush=True)
