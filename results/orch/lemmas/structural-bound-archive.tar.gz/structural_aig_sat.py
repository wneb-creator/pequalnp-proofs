#!/usr/bin/env python3
import argparse
from itertools import combinations
import json
from pathlib import Path
import subprocess
import time
from structural_aig_orient import validate, eval_aig, minimize, reconstruct, eval_circuit

EDGES = [(0,1),(1,2),(2,3),(3,4),(4,0),(0,5),(1,6),(2,7),(3,8),(4,9),(5,7),(7,9),(9,6),(6,8),(8,5)]


def target(mask):
    return any(mask >> a & 1 and mask >> b & 1 for a, b in EDGES)


def initial_rows():
    independent = [mask for mask in range(1024) if not target(mask)]
    maximal = [mask for mask in independent if all(mask >> i & 1 or target(mask | 1 << i) for i in range(10))]
    return sorted({0, *(1 << i for i in range(10)), *(1 << a | 1 << b for a, b in EDGES), *maximal})


def neg(literal):
    return not literal if isinstance(literal, bool) else -literal


class CNF:
    def __init__(self):
        self.variables = 0
        self.clauses = []
    def var(self):
        self.variables += 1
        return self.variables
    def add(self, *literals):
        if any(literal is True for literal in literals): return
        self.clauses.append([literal for literal in literals if literal is not False])
    def one(self, literals):
        self.add(*literals)
        for a,b in combinations(literals, 2): self.add(-a,-b)
    def write(self, path):
        with Path(path).open('w') as output:
            output.write('p cnf %d %d\n' % (self.variables, len(self.clauses)))
            for clause in self.clauses: output.write(' '.join(map(str, clause)) + ' 0\n')


def encode(n, b, rows, truth, maximum_not=None, pinned=None, blocks=()):
    assert b >= 1
    cnf = CNF()
    selectors = []
    for j in range(b):
        count = 2 * (n + 1 + j)
        a = [cnf.var() for _ in range(count)]
        c = [cnf.var() for _ in range(count)]
        cnf.one(a); cnf.one(c)
        for high in range(count):
            for low in range(high): cnf.add(-a[high], -c[low])
        selectors.append((a,c))
    output_inverted = cnf.var()
    if maximum_not is not None:
        orientation = [cnf.var() for _ in range(b)]
        paid = [cnf.var() for _ in range(n + 1 + b)]
        for selected in combinations(paid, maximum_not + 1): cnf.add(*(-v for v in selected))
        for j,pair in enumerate(selectors):
            for choices in pair:
                for literal, selected in enumerate(choices):
                    source, polarity = divmod(literal, 2)
                    own = orientation[source - n - 1] if source > n else False
                    downstream = orientation[j]
                    if polarity == 0:
                        cnf.add(-selected, paid[source], neg(own), downstream)
                        cnf.add(-selected, paid[source], own, -downstream)
                    else:
                        cnf.add(-selected, paid[source], own, downstream)
                        cnf.add(-selected, paid[source], neg(own), -downstream)
        cnf.add(paid[-1], -orientation[-1], output_inverted)
        cnf.add(paid[-1], orientation[-1], -output_inverted)
    for mask in rows:
        values = [bool(mask >> i & 1) for i in range(n)] + [False]
        for pair in selectors:
            a,c,v = cnf.var(),cnf.var(),cnf.var()
            for selections, bit in zip(pair,[a,c]):
                for literal, selected in enumerate(selections):
                    source, polarity = divmod(literal,2)
                    value = neg(values[source]) if polarity else values[source]
                    cnf.add(-selected,-bit,value)
                    cnf.add(-selected,bit,neg(value))
            cnf.add(-a,-c,v);cnf.add(a,-v);cnf.add(c,-v)
            values.append(v)
        desired = bool(truth(mask))
        if desired:
            cnf.add(values[-1],output_inverted)
            cnf.add(-values[-1],-output_inverted)
        else:
            cnf.add(-values[-1],output_inverted)
            cnf.add(values[-1],-output_inverted)
    if pinned is not None:
        validate(pinned)
        assert pinned['n'] == n and len(pinned['gates']) == b and pinned['output'][0] == n+b
        for j, pair in enumerate(pinned['gates']):
            literals = sorted(2*source+polarity for source,polarity in pair)
            cnf.add(selectors[j][0][literals[0]])
            cnf.add(selectors[j][1][literals[1]])
        cnf.add(output_inverted if pinned['output'][1] else -output_inverted)
    for assignment in blocks: cnf.add(*assignment)
    return cnf,selectors,output_inverted


def parse_model(text):
    model={}
    for line in text.splitlines():
        if line.startswith('v '):
            for value in map(int,line.split()[1:]):
                if value: model[abs(value)] = value > 0
    return model


def check_model(cnf,model):
    assert all(any(model.get(abs(value),False) == (value > 0) for value in clause) for clause in cnf.clauses)


def decode(n,selectors,output_inverted,model):
    gates=[]
    blocking=[]
    for pair in selectors:
        literals=[]
        for choices in pair:
            selected=[k for k,variable in enumerate(choices) if model.get(variable,False)]
            assert len(selected) == 1
            literal=selected[0]
            literals.append(list(divmod(literal,2)))
            blocking.append(-choices[literal])
        gates.append(literals)
    phase=int(model[output_inverted])
    blocking.append(-output_inverted if phase else output_inverted)
    return {'n':n,'gates':gates,'output':[n+len(gates),phase]},blocking


def solve(cnf,solver,seconds,stem):
    cnf_path=Path(str(stem)+'.cnf');cnf.write(cnf_path)
    with Path(str(stem)+'.stdout').open('w') as out,Path(str(stem)+'.stderr').open('w') as err:
        result=subprocess.run([solver,'-t',str(seconds),str(cnf_path)],stdout=out,stderr=err)
    text=Path(str(stem)+'.stdout').read_text()
    return result.returncode,text


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--solver',required=True)
    parser.add_argument('--binary',type=int,default=15)
    parser.add_argument('--seconds',type=int,default=1200)
    parser.add_argument('--maximum-not',type=int)
    parser.add_argument('--output-prefix',required=True)
    args=parser.parse_args()
    start=time.monotonic();rows=initial_rows();blocks=[];iteration=0
    while time.monotonic()-start < args.seconds:
        iteration+=1
        cnf,selectors,output_inverted=encode(10,args.binary,rows,target,args.maximum_not,blocks=blocks)
        remaining=max(1,int(args.seconds-(time.monotonic()-start)))
        stem=Path(args.output_prefix+'-'+str(iteration).zfill(3))
        print(json.dumps({'iteration':iteration,'rows':len(rows),'variables':cnf.variables,'clauses':len(cnf.clauses),'remaining_seconds':remaining}),flush=True)
        code,text=solve(cnf,args.solver,remaining,stem)
        if code != 10:
            print(json.dumps({'status':'UNSAT_UNCERTIFIED' if code == 20 else 'UNKNOWN','solver_exit':code,'wall_seconds':time.monotonic()-start}),flush=True)
            return
        model=parse_model(text);check_model(cnf,model)
        aig,blocking=decode(10,selectors,output_inverted,model)
        wrong=[mask for mask in range(1024) if eval_aig(aig,mask) != bool(target(mask))]
        Path(str(stem)+'.aig.json').write_text(json.dumps(aig,indent=2))
        if wrong:
            add=sorted(wrong,key=lambda mask:(mask.bit_count(),mask))[:16]
            assert not set(add).intersection(rows)
            rows=sorted(set(rows).union(add))
            print(json.dumps({'status':'REFINE','mismatches':len(wrong),'added':add}),flush=True)
            continue
        optimum=minimize(aig);circuit=reconstruct(aig,optimum['orientation'])
        assert all(eval_circuit(circuit,mask)==bool(target(mask)) for mask in range(1024))
        optimum['circuit']=circuit
        optimum['status']='COUNTEREXAMPLE' if args.binary+max(1,optimum['not_count'])<=19 else 'VALID_AIG_OVER_BUDGET'
        if optimum['status']=='COUNTEREXAMPLE' and optimum['not_count']==0:
            circuit['gates'].append(['not',[]])
            optimum['required_dead_not_added']=True
        assert all(eval_circuit(circuit,mask)==bool(target(mask)) for mask in range(1024))
        optimum['actual_not_count']=sum(operation == 'not' for operation,inputs in circuit['gates'])
        optimum['actual_gate_count']=len(circuit['gates'])
        if optimum['status']=='COUNTEREXAMPLE':
            assert optimum['actual_gate_count'] <= 19 and optimum['actual_not_count'] >= 1
        optimum['verified_rows']=1024
        Path(str(stem)+'.oriented.json').write_text(json.dumps(optimum,indent=2))
        print(json.dumps({k:v for k,v in optimum.items() if k!='circuit'}),flush=True)
        if optimum['status']=='COUNTEREXAMPLE': return
        blocks.append(blocking)
    print(json.dumps({'status':'UNKNOWN','wall_seconds':time.monotonic()-start}),flush=True)


if __name__=='__main__': main()
