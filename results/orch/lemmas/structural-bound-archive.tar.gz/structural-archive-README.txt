Structural-bound research preservation for L-meta-2592

Final search status: INTERRUPTED_LEASE_LOST, UNKNOWN.
The root stopped work after a desk HTTP 410. AIG15 ran from
2026-11-25T14:32:28.545566+00:00 to 2026-11-25T14:41:40.168551+00:00,
551.426 seconds. Its first 41-row query had 2,926 variables and 93,487
clauses. Cadical received SIGINT and returned -2. No model and no UNSAT
verdict were obtained. No complete proof or refutation is claimed.

Exact run command (paths from the original workspace):
python3 structural_aig_sat.py --solver toolchain/lean-4.36.0-linux/bin/cadical --binary 15 --seconds 1200 --output-prefix aig15-search
Run from the extracted scripts directory, supplying the actual solver path
and desired output prefix. The main solver script imports only Python's
standard library plus structural_aig_orient.py. The version and binary hash
of the original solver are in the manifest. No package installation needed.

All initial/final raw orchestration stdout/stderr and full solver stdout/
stderr/CNF are retained. Source controls and audits are also retained.
structural_aig_controls.py uses the original scratch and known-witness paths;
edit paths in a COPY if reproducing outside that layout. Its known-witness
input is included at reference/PetersenWitness.lean. Audit scripts similarly
record their original import paths. These are dependency/path limitations,
not a claim of a portable one-command test bundle.

Research results are finite Python checks, not Lean proofs: new active-group
singleton separation (1,680 cases), cofactor checks, AIG cost reconstruction
and encoding audits, and a tiny singleton-support set-circuit search.
structural_set_circuit.py exhausted 3 non-goal additions without producing
all four K4-star supports. The check is not the missing main circuit bound:
extracting exact guards without inflating gate cost remains unresolved.
