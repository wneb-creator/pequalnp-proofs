Focused cache restoration, 2026-11-25

Restored ordinary genuine cache artifacts for the existing Defs and proof import closure. No memfd keeper, Lean source rebuild, forged trace, changed import, checker change, or toolchain deletion was used.

The preservation set comes from the existing Defs/proof setup JSON: 2,566 modules, including 2,189 Mathlib modules. All 67 recorded Mathlib roots plus Mathlib.Init are present. The selected official get! restored 2,480 cache modules.

The independently reviewed deletion manifest identifies 87,928 regenerable Mathlib build artifacts outside that closure, plus 13,991 exact symlinks recorded by the two former keepers. Both keepers were verified zombies with FDSize 0 and unchanged process start identities. Every entry and preservation-input hash was checked before any unlink, and each file was checked again immediately before unlinking. No source, toolchain, project, Cache helper, or other dependency artifact was eligible.

The complete 51,035,639-byte deletion manifest is preserved losslessly in focused-cache-deletions.json.gz. Its uncompressed SHA256 is 349b6ee10f158fe55dd6d9fb1b7d9c5e0dc64596c52ad736f9731d30f1c020b4. The full applied-path log is also gzip preserved with a separate original-content hash. Root independently removed obsolete SAT scratch files to provide download headroom.

Official get! completed exit 0 in 86 seconds, with complete stdout/stderr in focused-cache-fetch.log. The subsequent audit checked 19,053 artifact paths: zero missing files and zero symlinks. Official lake build --no-build +PEqualNP.Defs passed exit 0 in 5.9 seconds. Official cache clean! then removed 2,480 compressed archives (155,998,951 bytes), leaving 782,061,568 bytes free. Extracted artifacts remain intact. Compile ownership was handed to formalization and then lower_bound for serial short checks.

Primary pinned-source evidence:
- Mathlib Cache/Main.lean lines 251–295: get! passes forceDownload and forceUnpack true and restricts cache hashes to the selected root closure.
- Mathlib Cache/IO.lean lines 475–536: ordinary extraction skipping uses matching trace hashes; force is necessary when a successful trace survives a lost artifact.
- Lean lake/Lake/Build/Module.lean lines 914–930: genuine cached build acceptance requires ilean, generated C, all module olean parts, and IR/signature as applicable. Deleting artifact kinds inside the focused build closure breaks that acceptance.
- Lean Lean/Environment.lean lines 2443–2469: ordinary module imports load olean, server, private, and IR parts. Those runtime files cannot be discarded for the full checker.
- tools/check-lean.mjs lines 155–215: checker builds the native verifier and proof/Defs, runs the verifier, and validates no-build freshness afterward. CheckLemma.lean uses the entire Mathlib library for its statement environment.

Full checker remains deferred until a complete proof. Even the previous keeper manifests alone record 5,368,706,264 bytes of runtime-required artifacts, before runtime files still on disk; adding the preserved 3.1 GiB toolchain exceeds the 7.9 GiB filesystem. Removing generated C/ilean only from modules outside every Lake build closure does not solve that lower bound. Any compressed read-only filesystem idea must be separately reviewed and tested on scratch-only genuine data before real artifacts are moved.
