import datetime,gzip,hashlib,json,os,subprocess,sys,time
from pathlib import Path
job=Path('/tmp/oec/pequalnp-pilot-70');lean=Path('/workspace/pequalnp-proofs/lean');out=job/'sat-review'
raw=gzip.decompress((out/'focused-cache-deletions.json.gz').read_bytes())
assert hashlib.sha256(raw).hexdigest()==(out/'focused-cache-deletions.sha256').read_text().strip()
manifest=json.loads(raw);roots=manifest['cache_roots'];assert len(roots)==68
assert (out/'focused-cache-apply.log').exists()
apply=json.loads((out/'focused-cache-apply.log').read_text());assert apply['status']=='complete'
fs=os.statvfs(lean);free=fs.f_bavail*fs.f_frsize
assert free>=1900000000,('insufficient download headroom',free)
command=[str(lean.parent/'tools/bin/lake'),'exe','cache','get!',*roots]
env=os.environ.copy();env['ELAN_HOME']=str(job/'elan');env['PEQUALNP_REAL_LAKE']=str(job/'elan/bin/lake');env['PATH']=str(job/'elan/bin')+os.pathsep+env.get('PATH','');env['MATHLIB_CACHE_DIR']=str(job/'mathlib-cache');env['MATHLIB_CACHE_PARALLEL_MAX']='4';env['LAKE_ARTIFACT_CACHE']='false'
record={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'free_bytes_before':free,'root_count':len(roots),'parallel_transfers':4}
(out/'focused-cache-fetch-run.json').write_text(json.dumps(record,indent=2)+'\n')
start=time.monotonic()
with (out/'focused-cache-fetch.log').open('xb') as log:
 rc=subprocess.run(command,cwd=lean,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
fs=os.statvfs(lean)
record.update(exit_code=rc,seconds=time.monotonic()-start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),free_bytes_after=fs.f_bavail*fs.f_frsize)
(out/'focused-cache-fetch-result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='command'}),flush=True)
sys.exit(rc)
