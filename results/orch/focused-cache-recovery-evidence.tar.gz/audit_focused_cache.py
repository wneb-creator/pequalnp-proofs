from pathlib import Path
import json,os,datetime
lean=Path('/workspace/pequalnp-proofs/lean');out=Path('/tmp/oec/pequalnp-pilot-70/sat-review')
setup=json.loads((lean/'.lake/build/ir/PEqualNP/Outside/L_meta_2732.setup.json').read_text())
missing=[];symlinks=[];count=0
for module,groups in setup['importArts'].items():
 paths={Path(p) for group in groups for p in group}
 if module.startswith('Mathlib.'):
  olean=Path(groups[0][0]);paths|={olean.with_suffix('.ilean'),olean.with_suffix('.trace'),Path(str(olean).replace('/lib/lean/','/ir/')).with_suffix('.c')}
 for p in paths:
  count+=1
  if p.is_symlink():symlinks.append({'module':module,'path':str(p),'target':os.readlink(p)})
  try:
   if not p.is_file():missing.append({'module':module,'path':str(p),'problem':'not a file'})
  except OSError as e:missing.append({'module':module,'path':str(p),'problem':str(e)})
result={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'modules':len(setup['importArts']),'paths_checked':count,'missing':missing,'symlinks':symlinks}
(out/'focused-cache-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:(len(v) if isinstance(v,list) else v) for k,v in result.items()}))
assert not missing and not symlinks
