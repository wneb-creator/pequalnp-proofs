import argparse,collections,datetime,gzip,hashlib,json,os,re,stat
from pathlib import Path

JOB=Path('/tmp/oec/pequalnp-pilot-70')
LEAN=Path('/workspace/pequalnp-proofs/lean')
BUILD=LEAN/'.lake/packages/mathlib/.lake/build'
SETS=[BUILD/'lib/lean',BUILD/'ir']
OUT=JOB/'sat-review'
SUFFIXES=sorted(['.olean.private.hash','.olean.server.hash','.olean.private','.olean.server','.ir.sig.hash','.ir.sig','.olean.hash','.ilean.hash','.ir.hash','.trace','.olean','.ilean','.ir','.extra','.c.hash','.c','.c.o.export.trace','.c.o.export.hash','.c.o.export','.c.o.trace','.c.o.hash','.c.o','.setup.json','.ltar'],key=len,reverse=True)

def inputs():
 paths=[LEAN/'.lake/build/ir/PEqualNP/Defs.setup.json',LEAN/'.lake/build/ir/PEqualNP/Outside/L_meta_2732.setup.json']
 keep=set();digests={}
 for path in paths:
  raw=path.read_bytes();d=json.loads(raw);assert isinstance(d['importArts'],dict)
  keep.update(d['importArts']);digests[str(path)]=hashlib.sha256(raw).hexdigest()
 roots=json.loads((JOB/'formalization/defs-imports.json').read_text())['mathlib']+['Mathlib.Init']
 assert len(roots)==68 and set(roots)<=keep
 assert sum(x.startswith('Mathlib.') for x in keep)==2189
 return keep,roots,digests

def classify(path,base):
 rel=path.relative_to(base)
 if not (rel.parts[0]=='Mathlib' or rel.name.startswith('Mathlib.')):return None
 s=rel.as_posix()
 for suffix in SUFFIXES:
  if s.endswith(suffix):return s[:-len(suffix)].replace('/','.'),suffix
 return None

def dead_keeper_state():
 states={}
 for pid in ['11987','15721']:
  status={}
  for line in (Path('/proc')/pid/'status').read_text().splitlines():
   key,_,value=line.partition(':');status[key]=value.strip()
  assert status['State'].startswith('Z') and status['FDSize']=='0',pid
  ticks=(Path('/proc')/pid/'stat').read_text().split()[21]
  states[pid]={'state':status['State'],'fd_size':0,'start_ticks':ticks}
 return states

def keeper_links():
 result={}
 for f in ['status.json','aux/status.json']:
  for e in json.loads((JOB/'ram-keeper'/f).read_text())['entries']:
   result[e['path']]=e['target']
 return result

def snapshot(path):
 s=path.lstat()
 return dict(device=s.st_dev,inode=s.st_ino,size=s.st_size,mtime_ns=s.st_mtime_ns,mode=s.st_mode)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['plan','apply']);args=ap.parse_args()
 keep,roots,digests=inputs();dead=dead_keeper_state();links=keeper_links();manifest=OUT/'focused-cache-deletions.json'
 if args.mode=='plan':
  entries=[];summary=collections.Counter();unknown=[]
  for base in SETS:
   for parent,dirs,names in os.walk(base,followlinks=False):
    dirs[:]=[d for d in dirs if not (Path(parent)/d).is_symlink()]
    for name in names:
     path=Path(parent)/name;kind=classify(path,base)
     if kind is None:continue
     module,suffix=kind;s=snapshot(path);reason=None;target=None
     if stat.S_ISLNK(s['mode']):
      target=os.readlink(path)
      if re.fullmatch(r'/proc/(11987|15721)/fd/[0-9]+',target) and links.get(str(path))==target:reason='known_dead_pid_symlink'
     elif stat.S_ISREG(s['mode']) and module not in keep:reason='regenerable_mathlib_artifact_outside_focused_closure'
     if reason:
      entries.append(dict(path=str(path),module=module,suffix=suffix,reason=reason,link_target=target,stat=s))
      summary[reason+'_count']+=1
      if stat.S_ISREG(s['mode']):summary['regular_bytes_to_free']+=s['size']
  result=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope=[str(x) for x in SETS],input_sha256=digests,dead_keeper_state=dead,focused_modules=sorted(keep),cache_roots=roots,summary=dict(summary),entries=entries)
  manifest.write_text(json.dumps(result,indent=2)+'\n')
  print(json.dumps(dict(manifest=str(manifest),input_sha256=digests,dead_keeper_state=dead,focused_modules=len(keep),mathlib_modules=2189,cache_roots=len(roots),summary=dict(summary)),indent=2))
 else:
  raw=manifest.read_bytes() if manifest.exists() else gzip.decompress(Path(str(manifest)+'.gz').read_bytes())
  assert hashlib.sha256(raw).hexdigest()==(OUT/'focused-cache-deletions.sha256').read_text().strip()
  d=json.loads(raw);assert d['input_sha256']==digests and set(d['focused_modules'])==keep and d['dead_keeper_state']==dead
  # Validate every entry before deleting any. No source/toolchain/project path is allowed.
  for e in d['entries']:
   p=Path(e['path']);base=next((b for b in SETS if p.is_relative_to(b)),None);assert base is not None
   assert p.parent.resolve().is_relative_to(base.resolve())
   assert snapshot(p)==e['stat'],str(p)
   assert classify(p,base)==(e['module'],e['suffix'])
   if e['reason']=='known_dead_pid_symlink':
    assert p.is_symlink() and os.readlink(p)==e['link_target'] and re.fullmatch(r'/proc/(11987|15721)/fd/[0-9]+',e['link_target']) and links.get(str(p))==e['link_target']
   else:
    assert e['reason']=='regenerable_mathlib_artifact_outside_focused_closure'
    assert stat.S_ISREG(e['stat']['mode']) and e['module'] not in keep
  with (OUT/'focused-cache-deletions-applied.jsonl').open('x') as log:
   for e in d['entries']:
    p=Path(e['path']);assert snapshot(p)==e['stat'],str(p)
    p.unlink();log.write(json.dumps({'path':str(p),'reason':e['reason']})+'\n')
   log.flush();os.fsync(log.fileno())
  fs=os.statvfs(LEAN)
  print(json.dumps({'deleted_entries':len(d['entries']),'free_bytes_after':fs.f_bavail*fs.f_frsize,'status':'complete'}))
if __name__=='__main__':main()
