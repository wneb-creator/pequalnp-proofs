import json,sys
from pathlib import Path
b=Path('/tmp/oec/pequalnp-pilot-178/gap3566/finite_search');source=Path(sys.argv[1]);h=int(sys.argv[2]);w=json.loads(source.read_text());n=w['n'];E=w['edges'];G=dict(edges=E+[[0,n+1],[1,n+1],[n,n+1]]);gs=w['gates'];K=len(gs);assert 0<=h<K
adj=[set() for _ in range(n)]
for a,c in E:adj[a].add(c);adj[c].add(a)
assert n%2==0 and len(E)==n and all(len(v)==2 for v in adj)
color={0:0};todo=[0]
while todo:
 a=todo.pop()
 for c in adj[a]:
  if c not in color:color[c]=1-color[a];todo.append(c)
  else:assert color[c]!=color[a]
assert len(color)==n and color[0]==color[1] and not adj[0]&adj[1]
left=[a for a in range(n) if color[a]==0];mate={}
def augment(a,seen):
 for c in adj[a]:
  if c in seen:continue
  seen.add(c)
  if c not in mate or augment(mate[c],seen):mate[c]=a;return True
 return False
for a in left:assert augment(a,set())
matching=[[a,c] for c,a in mate.items()]+[[n,n+1]]
for x in range(1<<n):
 vs=[bool(x>>i&1) for i in range(n)]
 for op,a,c in gs:vs.append((vs[a] or vs[c]) if op=='or' else (vs[a] and vs[c]))
 f=bool(any(x>>a&1 and x>>c&1 for a,c in E));B=bool(x&3);helper=vs[n+h];assert vs[-1]==f;assert (not B or helper) and (not helper or B or f)
def cv(i):return i if i<n else i+2
out=[[op,cv(a),cv(c)] for op,a,c in gs];out.extend([['or',n,n+2+h],['and',n+1,n+2+K],['or',n+2+K-1,n+2+K+1]])
for x in range(1<<(n+2)):
 vs=[bool(x>>i&1) for i in range(n+2)]
 for op,a,c in out:vs.append((vs[a] or vs[c]) if op=='or' else (vs[a] and vs[c]))
 assert vs[-1]==bool(any(x>>a&1 and x>>c&1 for a,c in G['edges']))
result=dict(n=n+2,edges=G['edges'],cover=n//2+1,size=len(out),gates=out,all_rows_checked=1<<(n+2),source=str(source),helper=h,matching=matching,vertex_cover=left+[n+1]);target=b/f'c{n}-absorbed-extension-{len(out)}.witness.json';target.write_text(json.dumps(result,indent=2));print(json.dumps({'path':str(target),'size':len(out),'bound':len(E)+3+n//2,'counterexample':len(out)<len(E)+3+n//2}))
