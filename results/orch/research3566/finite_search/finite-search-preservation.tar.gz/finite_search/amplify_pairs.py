import json,sys,itertools
from pathlib import Path
b=Path('/tmp/oec/pequalnp-pilot-178/gap3566/finite_search')
p=Path(sys.argv[1]);d=json.loads(p.read_text());n=d['n'];E=d['edges'];H=d['free_helpers'];gates=d['gates'];h=len(H)
assert all(gates[i]==['or',*pair] for i,pair in enumerate(H))
active=set()
def visit(w):
 if w<n or w-n in active:return
 i=w-n;active.add(i);visit(gates[i][1]);visit(gates[i][2])
visit(n+len(gates)-1)
used=[i for i in range(h) if i in active];keep=sorted(active);nh=len(used);nn=n+2*nh
assert nn<=22, 'Full validation would be too large; use a separate symbolic verifier.'
wire={i:i for i in range(n)};newg=[]
for i in keep:
 op,a,c=gates[i];newg.append([op,wire[a],wire[c]]);wire[n+i]=nn+len(newg)-1
newE=[list(e) for e in E];out=wire[n+len(gates)-1]
for j,i in enumerate(used):
 a,c=H[i];leaf=n+2*j;center=leaf+1;newE.extend([[a,center],[c,center],[leaf,center]])
 newg.append(['or',leaf,wire[n+i]]);g1=nn+len(newg)-1
 newg.append(['and',center,g1]);g2=nn+len(newg)-1
 newg.append(['or',out,g2]);out=nn+len(newg)-1
assert out==nn+len(newg)-1
adj=[set() for _ in range(nn)]
for a,c in newE:adj[a].add(c);adj[c].add(a)
assert all(len(adj[a]&adj[c])<=1 for a,c in itertools.combinations(range(nn),2))
color={}
for start in range(nn):
 if start in color:continue
 color[start]=0;todo=[start]
 while todo:
  a=todo.pop()
  for c in adj[a]:
   if c not in color:color[c]=1-color[a];todo.append(c)
   else:assert color[c]!=color[a]
left=[u for u in range(nn) if color[u]==0];mate={}
def augment(u,seen):
 for v in adj[u]:
  if v in seen:continue
  seen.add(v)
  if v not in mate or augment(mate[v],seen):mate[v]=u;return True
 return False
for u in left:augment(u,set())
matching=[[u,v] for v,u in sorted(mate.items())]
for x in range(1<<nn):
 ws=[bool(x>>j&1) for j in range(nn)]
 for op,a,c in newg:ws.append((ws[a] or ws[c]) if op=='or' else (ws[a] and ws[c]))
 assert ws[-1]==any((x>>a&1) and (x>>c&1) for a,c in newE)
result=dict(name=d['name']+'-amplified',n=nn,edges=newE,size=len(newg),gates=newg,all_rows_checked=1<<nn,used_helper_indices=used,base_witness=p.name,matching=matching,vertex_cover=left,expected_lower=len(newE)+len(matching)-1)
outfile=b/(d['name']+'-amplified-'+str(len(newg))+'.witness.json');outfile.write_text(json.dumps(result,indent=2));print(json.dumps(dict(path=str(outfile),n=nn,edges=len(newE),size=len(newg),helpers=nh,all_rows_checked=1<<nn)))
