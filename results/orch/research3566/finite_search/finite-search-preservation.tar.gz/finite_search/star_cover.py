import itertools,json,sys
from pathlib import Path
b=Path('/tmp/oec/pequalnp-pilot-178/gap3566/finite_search')
for name in sys.argv[1:]:
 spec=json.loads((b/(name+'.json')).read_text());n=spec['n'];E=spec['edges'];cover=min((s for s in range(1<<n) if all((s>>u&1) or (s>>v&1) for u,v in E)),key=int.bit_count);assigned={u:[] for u in range(n) if cover>>u&1}
 for u,v in E:
  if cover>>u&1:assigned[u].append(v)
  else:assigned[v].append(u)
 gs=[];terms=[]
 def gate(op,a,b):gs.append([op,a,b]);return n+len(gs)-1
 for u,ns in assigned.items():
  assert ns
  w=ns[0]
  for v in ns[1:]:w=gate('or',w,v)
  terms.append(gate('and',u,w))
 out=terms[0]
 for w in terms[1:]:out=gate('or',out,w)
 # Greedy canonical topological ordering by maximum already-named operand.
 rename={i:i for i in range(n)};pending=set(range(len(gs)));ordered=[]
 while pending:
  ready=[i for i in pending if gs[i][1] in rename and gs[i][2] in rename]
  i=min(ready,key=lambda i:(max(rename[gs[i][1]],rename[gs[i][2]]),min(rename[gs[i][1]],rename[gs[i][2]]),gs[i][0]))
  op,a,c=gs[i];a,c=sorted([rename[a],rename[c]]);rename[n+i]=n+len(ordered);ordered.append([op,a,c]);pending.remove(i)
 assert rename[out]==n+len(gs)-1
 assert len(gs)==len(E)+cover.bit_count()-1
 for x in range(1<<n):
  ws=[bool(x>>i&1) for i in range(n)]
  for op,a,c in ordered:ws.append((ws[a] or ws[c]) if op=='or' else (ws[a] and ws[c]))
  assert ws[-1]==any((x>>u&1) and (x>>v&1) for u,v in E)
 r=dict(name=name,n=n,edges=E,cover=cover,size=len(gs),gates=ordered,all_rows_checked=1<<n);(b/(name+'-upper.witness.json')).write_text(json.dumps(r,indent=2));print(name,len(gs),cover)
