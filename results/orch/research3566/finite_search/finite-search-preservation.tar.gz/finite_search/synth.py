import itertools,json,sys,resource,subprocess,time
from pathlib import Path
base=Path('/tmp/oec/pequalnp-pilot-178/gap3566/finite_search')
flags=sys.argv[4:];name=sys.argv[1];K=int(sys.argv[2]);spec=json.loads((base/(name+'.json')).read_text());n=spec['n'];E=[tuple(e) for e in spec['edges']]
neg=[x for x in range(1<<n) if not any((x>>a&1) and (x>>b&1) for a,b in E)]
maxneg=[x for x in neg if all(x>>j&1 or any(((x|(1<<j))>>a&1) and ((x|(1<<j))>>b&1) for a,b in E) for j in range(n))]
rows=[(1<<a)|(1<<b) for a,b in E]+maxneg
helper_negative_rows=[]
if 'relaxedhelper' in flags:
 helper_negative_rows=[x for x in range(1<<n) if x&3==0 and not any((x>>a&1) and (x>>b&1) for a,b in E) and all(x>>j&1 or any(((x|(1<<j))>>a&1) and ((x|(1<<j))>>b&1) for a,b in E) for j in range(2,n))]
 for x in [1,2]+helper_negative_rows:
  if x not in rows:rows.append(x)
variables={};clauses=[]
def v(*name):
 name=tuple(name)
 if name not in variables:variables[name]=len(variables)+1
 return variables[name]
def neg(a):return not a if isinstance(a,bool) else -a
def cl(*lits):
 if any(x is True for x in lits):return
 clause=list(dict.fromkeys(x for x in lits if x is not False))
 if any(-x in clause for x in clause):return
 clauses.append(clause)
def eq_if(s,a,b):cl(-s,neg(a),b);cl(-s,a,neg(b))
def val(j,r):return bool(rows[r]>>j&1) if j<n else v('v',j,r)
for i in range(K):
 k=n+i
 for p in ['a','b']:
  names=[v(p,i,j) for j in range(k)]
  cl(*names)
  for a,b in itertools.combinations(names,2):cl(-a,-b)
 for a in range(k):
  for b in range(a):cl(-v('a',i,a),-v('b',i,b))
 for r in range(len(rows)):
  x=v('x',k,r);y=v('y',k,r);o=v('o',i);out=v('v',k,r)
  for j in range(k):eq_if(v('a',i,j),x,val(j,r));eq_if(v('b',i,j),y,val(j,r))
  cl(-o,-x,out);cl(-o,-y,out);cl(-o,x,y,-out)
  cl(o,x,-out);cl(o,y,-out);cl(o,-x,-y,out)
for i in range(K-1):
 if 'flex' not in flags:
  if 'allowunused' not in flags:cl(*(v(p,j,n+i) for j in range(i+1,K) for p in ['a','b']))
  for b in range(n+i):
   for a in range(b):cl(-v('b',i,b),-v('b',i+1,a))
for u in range(n):
 if any(u in e for e in E):cl(*(v(p,j,u) for j in range(K) for p in ['a','b']))
for r,x in enumerate(rows):
 answer=any((x>>a&1) and (x>>b&1) for a,b in E)
 cl(v('v',n+K-1,r) if answer else -v('v',n+K-1,r))
flags=sys.argv[4:]
if 'deep' in flags:
 for i in range(K):
  aa=v('ha',i);bb=v('hb',i);hh=v('hh',i);dd=v('dd',i);oo=v('o',i)
  for j in range(n+i):
   h=False if j<n else v('hh',j-n)
   eq_if(v('a',i,j),aa,h);eq_if(v('b',i,j),bb,h)
  # hh is NOT oo OR aa OR bb; dd is NOT oo AND (aa OR bb).
  cl(oo,hh);cl(-aa,hh);cl(-bb,hh);cl(-hh,-oo,aa,bb)
  cl(-dd,-oo);cl(-dd,aa,bb);cl(oo,-aa,dd);cl(oo,-bb,dd)
 cl(*(v('dd',i) for i in range(K)))
if 'relaxedhelper' in flags:
 for i in range(K):
  ss=v('helper',i)
  for r,x in enumerate(rows):
   if x&3:cl(-ss,v('v',n+i,r))
   elif not any((x>>a&1) and (x>>b&1) for a,b in E):cl(-ss,-v('v',n+i,r))
 cl(*(v('helper',i) for i in range(K)))
if 'forcepair' in flags:
 cl(v('a',0,0));cl(v('b',0,1));cl(v('o',0))
 for u in [0,1]:cl(*(v(p,j,u) for j in range(1,K) for p in ['a','b']))
if 'forcepairs' in flags:
 cl(v('a',0,0));cl(v('b',0,1));cl(v('o',0))
 cl(v('a',1,2));cl(v('b',1,3));cl(v('o',1))
if 'positivegates' in flags or 'boundarygates' in flags:
 for i in range(K):cl(*(v('v',n+i,r) for r in range(len(E))))
if 'boundarygates' in flags:
 for i in range(K):cl(*(-v('v',n+i,r) for r in range(len(E),len(rows))))
if 'irredundant' in flags:
 for i in range(K):
  for r in range(len(rows)):
   aa=v('wa',i,r);bb=v('wb',i,r);xx=v('x',n+i,r);yy=v('y',n+i,r)
   cl(-aa,xx);cl(-aa,-yy);cl(-bb,-xx);cl(-bb,yy)
  cl(*(v('wa',i,r) for r in range(len(rows))))
  cl(*(v('wb',i,r) for r in range(len(rows))))
if 'two_dirty' in flags:
 for i in range(K):
  dd=v('dirty',i);cl(-dd,-v('o',i));cl(-dd,*(v('v',n+i,r) for r in range(len(E),len(rows))))
 cl(*(v('dirty',i) for i in range(K)))
 for i in range(K):cl(-v('dirty',i),*(v('dirty',j) for j in range(K) if i!=j))
if 'topform' in flags:
 for i in range(K):
  cc=v('clean',i);oo=v('o',i);aa=v('tca',i);bb=v('tcb',i);hh=v('tch',i)
  cl(-cc,-oo)
  for r in range(len(E),len(rows)):cl(-cc,-v('v',n+i,r))
  cl(oo,*(v('v',n+i,r) for r in range(len(E),len(rows))),cc)
  for j in range(n+i):
   h=False if j<n else v('tch',j-n)
   eq_if(v('a',i,j),aa,h);eq_if(v('b',i,j),bb,h)
  cl(-cc,hh);cl(-aa,hh);cl(-bb,hh);cl(-hh,cc,aa,bb)
  cl(oo,-aa);cl(oo,-bb)
if 'andfinal' in flags:cl(-v('o',K-1))
for flag in flags:
 if flag.startswith('andcount') or flag.startswith('andmin'):
  target=int(flag[8:] if flag.startswith('andcount') else flag[6:]);assert 0<=target<=K
  def count(i,j):return True if j<=0 else False if j>i else v('count',i,j)
  for i in range(1,K+1):
   for j in range(1,i+1):
    y=count(i,j);a=count(i-1,j);b=-v('o',i-1);c=count(i-1,j-1)
    cl(neg(a),y);cl(neg(b),neg(c),y);cl(-y,a,b);cl(-y,a,c)
  cl(count(K,target))
  if flag.startswith('andcount'):cl(neg(count(K,target+1)))
stem=f'{name}-{K}'+''.join('-'+x for x in flags);cnf=base/(stem+'.cnf');cnf.write_text(f'p cnf {len(variables)} {len(clauses)}\n'+'\n'.join(' '.join(map(str,c))+' 0' for c in clauses)+'\n');(base/(stem+'.vars.json')).write_text(json.dumps({'vars':[(k,x) for k,x in variables.items()],'rows':rows}))
print(json.dumps(dict(name=name,K=K,n=n,edges=len(E),rows=len(rows),vars=len(variables),clauses=len(clauses))),flush=True)
if len(sys.argv)>3 and sys.argv[3]!='-':
 def cap():resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
 t=time.monotonic()
 with (base/(stem+'.solver.log')).open('w') as log:
  r=subprocess.run(['/tmp/oec/pequalnp-pilot-178/toolchain/lean-4.36.0-linux/bin/cadical']+(['--sat'] if 'solver_sat' in flags else [])+['-t',sys.argv[3],str(cnf)],stdout=log,stderr=subprocess.STDOUT,preexec_fn=cap)
 elapsed=time.monotonic()-t;out=(base/(stem+'.solver.log')).read_text();print(dict(exit=r.returncode,elapsed=elapsed),flush=True)
 if r.returncode==10:
  model={int(x) for line in out.splitlines() if line.startswith('v ') for x in line.split()[1:] if int(x)>0};gates=[]
  for i in range(K):
   a=next(j for j in range(n+i) if v('a',i,j) in model);b=next(j for j in range(n+i) if v('b',i,j) in model);op='or' if v('o',i) in model else 'and';gates.append([op,a,b])
  helper=next((i for i in range(K) if variables.get(('helper',i)) in model),None) if 'relaxedhelper' in flags else None
  if 'relaxedhelper' in flags:assert helper is not None
  for x in range(1<<n):
   ws=[bool(x>>j&1) for j in range(n)]
   for op,a,b in gates:ws.append((ws[a] or ws[b]) if op=='or' else (ws[a] and ws[b]))
   assert ws[-1]==any((x>>a&1) and (x>>b&1) for a,b in E)
   if helper is not None:assert (not(x&3) or ws[n+helper]) and (not ws[n+helper] or bool(x&3) or ws[-1])
  result=dict(name=name,n=n,edges=E,size=K,gates=gates,all_rows_checked=1<<n,helper=helper);(base/(stem+'.witness.json')).write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
