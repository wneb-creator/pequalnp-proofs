import json,sys
from pathlib import Path
b=Path('/tmp/oec/pequalnp-pilot-178/gap3566/finite_search');w=json.loads(Path(sys.argv[1]).read_text());H=w['free_helpers'];n0=w['n'];assert n0==8;N=n0+2*len(H);graph=json.loads((b/'c8-four-helper-extension.json').read_text());assert H==graph['free_helpers'];assert w['gates'][:len(H)]==[['or',a,c] for a,c in H]
for x in range(1<<n0):
 ws=[bool(x>>i&1) for i in range(n0)]
 for op,a,c in w['gates']:ws.append((ws[a] or ws[c]) if op=='or' else (ws[a] and ws[c]))
 assert ws[-1]==any((x>>a&1) and (x>>c&1) for a,c in w['edges'])
def cv(x):return x if x<n0 else x+N-n0
gs=[[op,cv(a),cv(c)] for op,a,c in w['gates']];output=N+len(gs)-1
for j,(a,c) in enumerate(H):
 X=n0+2*j;private=X+1;hlp=N+j
 gs.append(['or',hlp,private]);u=N+len(gs)-1;gs.append(['and',X,u]);v=N+len(gs)-1;gs.append(['or',output,v]);output=N+len(gs)-1
for x in range(1<<N):
 ws=[bool(x>>i&1) for i in range(N)]
 for op,a,c in gs:ws.append((ws[a] or ws[c]) if op=='or' else (ws[a] and ws[c]))
 assert ws[-1]==any((x>>a&1) and (x>>c&1) for a,c in graph['edges'])
r=dict(n=N,edges=graph['edges'],cover=graph['cover'],matching=graph['matching'],size=len(gs),gates=gs,all_rows_checked=1<<N,expected_bound=graph['star_cover_upper']);out=b/f'c8-amplified-{len(H)}-{len(gs)}.witness.json';out.write_text(json.dumps(r,indent=2));print(json.dumps(dict(path=str(out),size=len(gs),bound=graph['star_cover_upper'],counterexample=len(gs)<graph['star_cover_upper'])))
