import itertools,json,time,collections
from pathlib import Path
b=Path('/tmp/oec/pequalnp-pilot-178/gap3566/finite_search');off=[(i,j) for i in range(5) for j in range(5) if i!=j];maps=[[sum(((m>>i)&1)<<p[i] for i in range(5)) for m in range(32)] for p in itertools.permutations(range(5))];classes={};total=0;t=time.monotonic()
for extra in itertools.combinations(off,7):
 rows=[1<<i for i in range(5)]
 for i,j in extra:rows[i]|=1<<j
 if any((rows[i]&rows[j]).bit_count()>1 for i in range(5) for j in range(i)):continue
 total+=1;cols=[sum(((rows[i]>>j)&1)<<i for i in range(5)) for j in range(5)];key=min(tuple(sorted(mp[c] for c in cols)) for mp in maps)
 if key not in classes:classes[key]=dict(count=0,edges=[(i,5+j) for j,c in enumerate(key) for i in range(5) if c>>i&1])
 classes[key]['count']+=1
out=[]
for i,(key,data) in enumerate(sorted(classes.items())):
 E=data['edges'];n=10;neg=[x for x in range(1<<n) if not any((x>>a&1) and (x>>c&1) for a,c in E)];maxneg=[x for x in neg if all(x>>j&1 or any(((x|(1<<j))>>a&1) and ((x|(1<<j))>>c&1) for a,c in E) for j in range(n))];name=f'balanced55m12_{i}';spec=dict(name=name,n=n,edges=E,cover=5,star_cover_upper=16,max_independent_sets=len(maxneg),matching_labeled_count=data['count']);out.append(spec);(b/(name+'.json')).write_text(json.dumps(spec))
r=dict(total_matching_labeled=total,classes=out,seconds=time.monotonic()-t);(b/'balanced55m12-census.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
