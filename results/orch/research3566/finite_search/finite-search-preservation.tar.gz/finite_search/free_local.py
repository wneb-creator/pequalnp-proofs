import random,time,json,sys
from pathlib import Path
b=Path('/tmp/oec/pequalnp-pilot-178/gap3566/finite_search');name=sys.argv[1];spec=json.loads((b/(name+'-upper.witness.json')).read_text());n=spec['n'];E=spec['edges'];H=json.loads((b/(name+'-safe-pairs.json')).read_text());inputs=n+len(H)
def lift(w):return w if w<n else w+len(H)
seed=[(int(op=='or'),lift(a),lift(c)) for op,a,c in spec['gates']];N=len(seed)-1
neg=[x for x in range(1<<n) if not any((x>>a&1) and (x>>c&1) for a,c in E)];rows=[(1<<a)|(1<<c) for a,c in E]+[x for x in neg if all(x>>j&1 or any(((x|(1<<j))>>a&1) and ((x|(1<<j))>>c&1) for a,c in E) for j in range(n))]
I=[sum(((r>>i)&1)<<j for j,r in enumerate(rows)) for i in range(n)];I.extend(I[a]|I[c] for a,c in H);T=(1<<len(E))-1;rng=random.Random(3566);start=time.monotonic();limit=int(sys.argv[2]);best=999;trials=0

def ev(c):
 w=I[:]
 for op,a,b in c:w.append((w[a]|w[b]) if op else (w[a]&w[b]))
 return (w[-1]^T).bit_count()
def mutate(c):
 out=c[:]
 for _ in range(1+int(rng.random()<.15)+int(rng.random()<.05)):
  i=rng.randrange(N);op,a,b=out[i];k=rng.randrange(3)
  if k==0:op=1-op
  elif k==1:a=rng.randrange(inputs+i)
  else:b=rng.randrange(inputs+i)
  out[i]=(op,a,b)
 return out
for restart in range(1000000):
 if time.monotonic()-start>limit:break
 removed=rng.randrange(len(seed)-1);repl=seed[removed][rng.choice([1,2])]
 def conv(x):return x if x<inputs+removed else repl if x==inputs+removed else x-1
 c=[(op,conv(a),conv(d)) for i,(op,a,d) in enumerate(seed) if i!=removed];score=ev(c)
 for it in range(15000):
  cand=mutate(c);s=ev(cand);trials+=1
  if s<=score:c,score=cand,s
  if s<best:best=s;print('BEST',best,'t',time.monotonic()-start,'gates',c,flush=True)
  if s==0:
   for x in range(1<<n):
    vals=[bool(x>>i&1) for i in range(n)];vals.extend(vals[a] or vals[d] for a,d in H)
    for op,a,d in c:vals.append((vals[a] or vals[d]) if op else vals[a] and vals[d])
    assert vals[-1]==any((x>>a&1) and (x>>d&1) for a,d in E)
   r=dict(name=name,n=n,edges=E,gates=[['or',a,d] for a,d in H]+[['or' if op else 'and',a,d] for op,a,d in c],size=N+len(H),free_helpers=H,all_rows_checked=1<<n);(b/(name+'-free-local.witness.json')).write_text(json.dumps(r,indent=2));print('FOUND',flush=True);raise SystemExit
  if it%1000==0 and time.monotonic()-start>limit:break
print('END',dict(best=best,trials=trials,seconds=time.monotonic()-start),flush=True)
