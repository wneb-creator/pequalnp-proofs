import json,sys
from pathlib import Path
b=Path('/tmp/oec/pequalnp-pilot-178/gap3566/finite_search');source=Path(sys.argv[1]);h=int(sys.argv[2]);w=json.loads(source.read_text());assert w['n']==8;E=w['edges'];G=json.loads((b/'c8_reuse_extension.json').read_text());gs=w['gates'];K=len(gs);assert 0<=h<K
for x in range(256):
 vs=[bool(x>>i&1) for i in range(8)]
 for op,a,c in gs:vs.append((vs[a] or vs[c]) if op=='or' else (vs[a] and vs[c]))
 f=bool(any(x>>a&1 and x>>c&1 for a,c in E));B=bool(x&3);helper=vs[8+h];assert vs[-1]==f;assert (not B or helper) and (not helper or B or f)
def cv(i):return i if i<8 else i+2
out=[[op,cv(a),cv(c)] for op,a,c in gs];out.extend([['or',8,10+h],['and',9,10+K],['or',10+K-1,10+K+1]])
for x in range(1024):
 vs=[bool(x>>i&1) for i in range(10)]
 for op,a,c in out:vs.append((vs[a] or vs[c]) if op=='or' else (vs[a] and vs[c]))
 assert vs[-1]==bool(any(x>>a&1 and x>>c&1 for a,c in G['edges']))
result=dict(n=10,edges=G['edges'],cover=5,size=len(out),gates=out,all_rows_checked=1024,source=str(source),helper=h);target=b/f'c8-extension-{len(out)}.witness.json';target.write_text(json.dumps(result,indent=2));print(json.dumps({'path':str(target),'size':len(out),'bound':15,'counterexample':len(out)<15}))
