import itertools,json,sys,resource,subprocess,time,os
from pathlib import Path
base=Path('/tmp/oec/pequalnp-pilot-178/gap3566/finite_search');name=sys.argv[1];pairfile=sys.argv[2];K=int(sys.argv[3]);seconds=int(sys.argv[4]);spec=json.loads((base/(name+'.json')).read_text());n=spec['n'];E=[tuple(e) for e in spec['edges']];H=json.loads((base/pairfile).read_text());N=n+len(H);stem=f'{name}-free{len(H)}-{K}'
adj=[set() for _ in range(n)]
for a,b in E:adj[a].add(b);adj[b].add(a)
assert len({v for p in H for v in p})==2*len(H)
assert all(a!=b and not(adj[a]&adj[b]) for a,b in H)
neg=[x for x in range(1<<n) if not any((x>>a&1) and (x>>b&1) for a,b in E)];neg=[x for x in neg if all(x>>j&1 or any(((x|(1<<j))>>a&1) and ((x|(1<<j))>>b&1) for a,b in E) for j in range(n))];rows=[(1<<a)|(1<<b) for a,b in E]+neg
variables={};clauses=[]
def v(*key):
 key=tuple(key)
 if key not in variables:variables[key]=len(variables)+1
 return variables[key]
def notlit(a):return not a if isinstance(a,bool) else -a
def cl(*lits):
 if any(x is True for x in lits):return
 q=list(dict.fromkeys(x for x in lits if x is not False))
 if any(-x in q for x in q):return
 clauses.append(q)
def eq_if(s,a,b):cl(-s,notlit(a),b);cl(-s,a,notlit(b))
def val(j,r):
 if j<n:return bool(rows[r]>>j&1)
 if j<N:
  a,b=H[j-n];return bool((rows[r]>>a&1) or (rows[r]>>b&1))
 return v('v',j,r)
for i in range(K):
 k=N+i
 for p in ['a','b']:
  ids=[v(p,i,j) for j in range(k)];cl(*ids)
  for a,b in itertools.combinations(ids,2):cl(-a,-b)
 for a in range(k):
  for b in range(a):cl(-v('a',i,a),-v('b',i,b))
 for r in range(len(rows)):
  x=v('x',k,r);y=v('y',k,r);o=v('o',i);out=v('v',k,r)
  for j in range(k):eq_if(v('a',i,j),x,val(j,r));eq_if(v('b',i,j),y,val(j,r))
  cl(-o,-x,out);cl(-o,-y,out);cl(-o,x,y,-out);cl(o,x,-out);cl(o,y,-out);cl(o,-x,-y,out)
 cl(*(v('v',k,r) for r in range(len(E))))
 cl(*(-v('v',k,r) for r in range(len(E),len(rows))))
for i in range(K-1):
 cl(*(v(p,j,N+i) for j in range(i+1,K) for p in ['a','b']))
 for b in range(N+i):
  for a in range(b):cl(-v('b',i,b),-v('b',i+1,a))
for u in range(n):cl(*(v(p,j,u) for j in range(K) for p in ['a','b']))
for r,x in enumerate(rows):
 answer=any((x>>a&1) and (x>>b&1) for a,b in E);cl(v('v',N+K-1,r) if answer else -v('v',N+K-1,r))
cnf=base/(stem+'.cnf');cnf.write_text(f'p cnf {len(variables)} {len(clauses)}\n'+'\n'.join(' '.join(map(str,c))+' 0' for c in clauses)+'\n');(base/(stem+'.vars.json')).write_text(json.dumps(dict(vars=[(k,x) for k,x in variables.items()],rows=rows,H=H)))
print(json.dumps(dict(name=name,original_inputs=n,free_sources=len(H),unknown_gates=K,total_gates=K+len(H),rows=len(rows),vars=len(variables),clauses=len(clauses))),flush=True)
if seconds<=0:raise SystemExit

def cap():resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
t=time.monotonic()
with (base/(stem+'.solver.log')).open('w') as log:
 proc=subprocess.Popen(['/tmp/oec/pequalnp-pilot-178/toolchain/lean-4.36.0-linux/bin/cadical','-t',str(seconds),str(cnf)],stdout=log,stderr=subprocess.STDOUT,preexec_fn=cap);(base/(stem+'.pid.json')).write_text(json.dumps(dict(parent_pid=os.getpid(),solver_pid=proc.pid)));code=proc.wait()
print(dict(exit=code,elapsed=time.monotonic()-t),flush=True)
if code==10:
 txt=(base/(stem+'.solver.log')).read_text();model={int(x) for line in txt.splitlines() if line.startswith('v ') for x in line.split()[1:] if int(x)>0};gates=[['or',a,b] for a,b in H]
 for i in range(K):
  a=next(j for j in range(N+i) if variables['a',i,j] in model);b=next(j for j in range(N+i) if variables['b',i,j] in model);op='or' if variables['o',i] in model else 'and';gates.append([op,a,b])
 for x in range(1<<n):
  ws=[bool(x>>j&1) for j in range(n)]
  for op,a,b in gates:ws.append((ws[a] or ws[b]) if op=='or' else (ws[a] and ws[b]))
  assert ws[-1]==bool(any((x>>a&1) and (x>>b&1) for a,b in E))
 result=dict(name=name,n=n,edges=E,size=len(gates),gates=gates,all_rows_checked=1<<n,free_helpers=H);(base/(stem+'.witness.json')).write_text(json.dumps(result,indent=2));print('FOUND',json.dumps(result),flush=True)
