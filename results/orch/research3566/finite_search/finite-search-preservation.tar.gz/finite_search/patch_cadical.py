import itertools,json,sys,time,random,resource,subprocess
from pathlib import Path
b=Path('/tmp/oec/pequalnp-pilot-178/gap3566/finite_search');name=sys.argv[1];limit=int(sys.argv[2]);spec=json.loads((b/(name+'-upper.witness.json')).read_text());n=spec['n'];E=spec['edges'];seed=[(int(op=='or'),a,c) for op,a,c in spec['gates']];K=len(seed)-1;stem=f'{name}-{K}-flex';d=json.loads((b/(stem+'.vars.json')).read_text());variables={tuple(key):v for key,v in d['vars']};cnf=(b/(stem+'.cnf')).read_text();head,body=cnf.split('\n',1);_,_,nv,nc=head.split();nc=int(nc);rng=random.Random(93666);start=time.monotonic();counts={};logs=b/(name+'-cadical-patches');logs.mkdir(exist_ok=True)
def cap():resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
for trial in range(10000000):
 if time.monotonic()-start>limit:break
 removed=rng.randrange(len(seed)-1);repl=seed[removed][rng.choice([1,2])]
 def conv(x):return x if x<n+removed else repl if x==n+removed else x-1
 gates=[(op,*sorted([conv(a),conv(c)])) for i,(op,a,c) in enumerate(seed) if i!=removed];free=set(rng.sample(range(K),min(K,5+trial%7)));free.update(i for i,g in enumerate(gates) if repl in g[1:]);units=[]
 for i,(op,a,c) in enumerate(gates):
  if i not in free:units.extend([variables['a',i,a],variables['b',i,c],variables['o',i]*(1 if op else -1)])
 patch=logs/'current.cnf';patch.write_text(f'p cnf {nv} {nc+len(units)}\n'+body+'\n'.join(str(x)+' 0' for x in units)+'\n');log=logs/f'{trial:04}.log';t=time.monotonic()
 with log.open('w') as out:r=subprocess.run(['/tmp/oec/pequalnp-pilot-178/toolchain/lean-4.36.0-linux/bin/cadical','-q','-t','2',str(patch)],stdout=out,stderr=subprocess.STDOUT,preexec_fn=cap)
 counts[r.returncode]=counts.get(r.returncode,0)+1;print(json.dumps(dict(trial=trial,removed=removed,free=len(free),exit=r.returncode,seconds=time.monotonic()-t)),flush=True)
 if r.returncode==10:
  txt=log.read_text();model={int(x) for line in txt.splitlines() if line.startswith('v ') for x in line.split()[1:] if int(x)>0};gs=[]
  for i in range(K):
   a=next(j for j in range(n+i) if variables['a',i,j] in model);c=next(j for j in range(n+i) if variables['b',i,j] in model);op='or' if variables['o',i] in model else 'and';gs.append([op,a,c])
  for x in range(1<<n):
   ws=[bool(x>>j&1) for j in range(n)]
   for op,a,c in gs:ws.append((ws[a] or ws[c]) if op=='or' else (ws[a] and ws[c]))
   assert ws[-1]==any((x>>a&1) and (x>>c&1) for a,c in E)
  result=dict(name=name,n=n,edges=E,size=K,gates=gs,all_rows_checked=1<<n);(b/(name+'-cadical-patch.witness.json')).write_text(json.dumps(result,indent=2));print('FOUND',json.dumps(result),flush=True);break
print('DONE',counts,time.monotonic()-start,flush=True)
