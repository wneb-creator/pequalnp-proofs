import ast,datetime,hashlib,json
from pathlib import Path
b=Path('/tmp/oec/pequalnp-pilot-178/gap3566/finite_search')
outcomes=[]
for p in sorted(b.glob('*.run.log')):
 lines=p.read_text().splitlines();r=dict(log=p.name)
 if lines:
  try:r['instance']=json.loads(lines[0])
  except (ValueError,TypeError):pass
 for line in lines:
  if line.startswith("{'exit':"):
   q=ast.literal_eval(line);r['outcome']=q;r['status']={10:'SAT_VERIFIED_BY_GENERATOR',20:'UNSAT_DIAGNOSTIC_ONLY',0:'UNKNOWN',-15:'INTERRUPTED'}.get(q['exit'],'OTHER')
 if 'status' not in r:r['status']='INTERRUPTED_NO_FINAL_STATUS'
 outcomes.append(r)
(b/'search-outcomes.json').write_text(json.dumps(outcomes,indent=2))
artifacts=[]
for p in sorted(b.rglob('*')):
 if not p.is_file() or p.is_symlink() or p.name in ['PRESERVATION-MANIFEST.json','PRESERVATION-MANIFEST.md']:continue
 data=p.read_bytes();artifacts.append(dict(path=str(p.relative_to(b)),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
report=dict(gap='L-meta-3566',generated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),directory=str(b),verdict='Search outcomes and validated witness artifacts are inventoried below. UNSAT outputs are untrusted finite-search diagnostics, not Lean proofs.',outcomes=outcomes,artifacts=artifacts)
(b/'PRESERVATION-MANIFEST.json').write_text(json.dumps(report,indent=2))
md='# Finite-search preservation manifest\n\n'+report['verdict']+'\n\nGenerated '+report['generated_utc']+'. All paths are relative to '+str(b)+'.\n\n| Run log | Outcome | Seconds |\n|---|---|---:|\n'
for r in outcomes:md+='| '+r['log']+' | '+r['status']+' | '+str(round(r.get('outcome',{}).get('elapsed',0),3))+' |\n'
md+='\nThe JSON manifest records byte sizes and SHA-256 hashes for all '+str(len(artifacts))+' retained artifacts. CNFs, complete solver output, generator source, graph specifications, ordinary valid upper-bound witnesses, and full truth-table amplifiers are preserved. The accidentally unconstrained C8 probe is explicitly named in its filename and supplies no helper-search conclusion. No Lean process or git operation was run by this subagent for this gap.\n'
(b/'PRESERVATION-MANIFEST.md').write_text(md)
print(json.dumps(dict(outcomes=len(outcomes),artifacts=len(artifacts),bytes=sum(a['bytes'] for a in artifacts),manifest=str(b/'PRESERVATION-MANIFEST.json'))))
