import json,sys,os,signal,time,subprocess
from pathlib import Path
b=Path('/tmp/oec/pequalnp-pilot-178/gap3566/finite_search');current=None;state=dict(manager_pid=os.getpid(),active=False,completed=[])
def save(): (b/'queue-state.json').write_text(json.dumps(state,indent=2))
def stop(signum,frame):
 if current is not None and current.poll() is None:os.killpg(current.pid,signal.SIGTERM)
 state['stopped']=True;state['active']=False;save();sys.exit(128+signum)
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop);save()
prior=b/'balanced55m12_1-15-deep.run.log'
while "'exit':" not in prior.read_text():time.sleep(1)
flags=['irredundant','two_dirty','topform','solver_sat']
for name,k,seconds in json.loads((b/'search-queue.json').read_text()):
 stem=f'{name}-{k}'+''.join('-'+f for f in flags);log=b/(stem+'.run.log');cmd=[sys.executable,str(b/'synth.py'),name,str(k),str(seconds)]+flags
 with log.open('w') as out:
  current=subprocess.Popen(cmd,stdout=out,stderr=subprocess.STDOUT,start_new_session=True);state.update(active=True,child_pid=current.pid,current=stem,started_at=time.time());save();print('START',stem,flush=True);code=current.wait()
 state['completed'].append(dict(stem=stem,exit=code,finished_at=time.time()));state.update(active=False);save();print('DONE',stem,code,flush=True)
 if (b/(stem+'.witness.json')).exists():state['found']=stem;save();print('FOUND',stem,flush=True);break
state['finished']=True;save();print('QUEUE COMPLETE',flush=True)
