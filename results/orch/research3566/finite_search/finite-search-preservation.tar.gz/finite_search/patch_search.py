import ctypes,itertools,json,sys,time,random,re,resource
from pathlib import Path
resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
b=Path('/tmp/oec/pequalnp-pilot-178/gap3566/finite_search');name=sys.argv[1];limit=int(sys.argv[2]);spec=json.loads((b/(name+'-upper.witness.json')).read_text());n=spec['n'];E=spec['edges'];seed=[(int(op=='or'),a,c) for op,a,c in spec['gates']];K=len(seed)-1
neg=[x for x in range(1<<n) if not any((x>>a&1) and (x>>c&1) for a,c in E)];rows=[(1<<a)|(1<<c) for a,c in E]+[x for x in neg if all(x>>j&1 or any(((x|(1<<j))>>a&1) and ((x|(1<<j))>>c&1) for a,c in E) for j in range(n))]
width=len(rows);sw=(n+K).bit_length();inputs=[sum(((x>>j)&1)<<i for i,x in enumerate(rows)) for j in range(n)];target=(1<<len(E))-1
z=ctypes.CDLL('/usr/lib/x86_64-linux-gnu/libz3.so.4');z.Z3_mk_config.restype=ctypes.c_void_p;z.Z3_mk_context.argtypes=[ctypes.c_void_p];z.Z3_mk_context.restype=ctypes.c_void_p;z.Z3_eval_smtlib2_string.argtypes=[ctypes.c_void_p,ctypes.c_char_p];z.Z3_eval_smtlib2_string.restype=ctypes.c_char_p;z.Z3_del_context.argtypes=[ctypes.c_void_p];cfg=z.Z3_mk_config();ctx=z.Z3_mk_context(cfg)
def run(s):return z.Z3_eval_smtlib2_string(ctx,s.encode()).decode()
lines=['(set-option :timeout 2000)','(set-logic QF_BV)']
for i,v in enumerate(inputs):lines.append(f'(define-fun v{i} () (_ BitVec {width}) (_ bv{v} {width}))')
for i in range(K):
 k=n+i
 for p in ['a','b']:lines.append(f'(declare-fun {p}{i} () (_ BitVec {sw}))');lines.append(f'(assert (bvult {p}{i} (_ bv{k} {sw})))')
 lines.append(f'(declare-fun o{i} () Bool)')
 def sel(p):
  q='v0'
  for j in range(1,k):q=f'(ite (= {p}{i} (_ bv{j} {sw})) v{j} {q})'
  return q
 lines.append(f'(define-fun x{i} () (_ BitVec {width}) {sel("a")})');lines.append(f'(define-fun y{i} () (_ BitVec {width}) {sel("b")})');lines.append(f'(define-fun v{k} () (_ BitVec {width}) (ite o{i} (bvor x{i} y{i}) (bvand x{i} y{i})))')
lines.append(f'(assert (= v{n+K-1} (_ bv{target} {width})))');prefix='\n'.join(lines);(b/(name+'-patch-prefix.smt2')).write_text(prefix);print(run(prefix),flush=True);start=time.monotonic();rng=random.Random(7713566);counts={}
for trial in range(1000000):
 if time.monotonic()-start>limit:break
 removed=rng.randrange(len(seed)-1);repl=seed[removed][rng.choice([1,2])]
 def conv(x):return x if x<n+removed else repl if x==n+removed else x-1
 gates=[(op,conv(a),conv(c)) for i,(op,a,c) in enumerate(seed) if i!=removed]
 free=set(rng.sample(range(K),min(K,8+trial%8)))
 # Ensure local changes around the removed gate can occur.
 free.update(i for i,g in enumerate(gates) if repl in g[1:])
 ls=['(push)']
 for i,(op,a,c) in enumerate(gates):
  if i not in free:ls.extend([f'(assert (= a{i} (_ bv{a} {sw})))',f'(assert (= b{i} (_ bv{c} {sw})))',f'(assert (= o{i} {"true" if op else "false"}))'])
 ls.append('(check-sat)');t=time.monotonic();r=run('\n'.join(ls)).strip();counts[r]=counts.get(r,0)+1;print(json.dumps(dict(trial=trial,free=len(free),removed=removed,status=r,seconds=time.monotonic()-t)),flush=True)
 if r=='sat':
  model=run('(get-value ('+' '.join(f'a{i} b{i} o{i}' for i in range(K))+'))');(b/(name+'-patch-model.txt')).write_text(model);vals={m[0]:m[1] for m in re.findall(r'\(([abo]\d+)\s+(#b[01]+|#x[0-9a-f]+|true|false)\)',model)}
  def iv(v):return int(v[2:],2 if v.startswith('#b') else 16)
  gs=[['or' if vals[f'o{i}']=='true' else 'and',iv(vals[f'a{i}']),iv(vals[f'b{i}'])] for i in range(K)]
  for x in range(1<<n):
   ws=[bool(x>>j&1) for j in range(n)]
   for op,a,c in gs:ws.append((ws[a] or ws[c]) if op=='or' else (ws[a] and ws[c]))
   assert ws[-1]==any((x>>a&1) and (x>>c&1) for a,c in E)
  out=dict(name=name,n=n,edges=E,size=K,gates=gs,all_rows_checked=1<<n);(b/(name+'-patch.witness.json')).write_text(json.dumps(out,indent=2));print('FOUND',json.dumps(out),flush=True);break
 run('(pop)')
print('DONE',counts,time.monotonic()-start,flush=True);z.Z3_del_context(ctx)
