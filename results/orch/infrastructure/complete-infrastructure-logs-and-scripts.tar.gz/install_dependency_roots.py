import hashlib,json,os,shutil,socket,subprocess
from pathlib import Path
B=Path('/tmp/oec/pequalnp-pilot-74');P=Path('/workspace/pequalnp-proofs/lean/.lake/packages')
MP={'Mathlib':'mathlib','Batteries':'batteries','Aesop':'aesop','Qq':'Qq','ImportGraph':'importGraph','Plausible':'plausible','ProofWidgets':'proofwidgets','LeanSearchClient':'LeanSearchClient'}
ESS=('.olean','.olean.private','.olean.server','.ir','.ir.sig')
added=json.loads((B/'experiment-added-files.json').read_text());stage=B/'dependency-cache-stage';stage.mkdir(exist_ok=True);count=0
with (B/'dependency-cache-install.stdout').open('w') as out,(B/'dependency-cache-install.stderr').open('w') as err,(B/'dependency-cache-manifest.jsonl').open('w') as manifest:
 for n in (B/'dependency-cache-archives.txt').read_text().splitlines():
  a=Path(n)
  r=subprocess.run([str(B/'toolchain/bin/leantar'),'-d','-f','--jobs','1','-j','-'],input=json.dumps([{'file':str(a),'base':[str(stage),str(stage)]}]),text=True,stdout=out,stderr=err)
  if r.returncode:raise RuntimeError(a.name)
  files=[p for p in stage.rglob('*') if p.is_file()]
  roots={str(p.relative_to(stage)).split('/lib/lean/',1)[1].split('/',1)[0].split('.',1)[0] for p in files if str(p).endswith('.olean')}
  assert len(roots)==1;root=P/MP[roots.pop()]
  for source in files:
   rel=str(source.relative_to(stage));target=root/rel
   if not rel.endswith(ESS) or target.exists():continue
   if rel.endswith('.olean.private'):
    with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as s:
     s.connect(str(B/'memfd-cache.sock'));s.sendall((json.dumps({'action':'store','source':str(source),'target':str(target),'remove_source':True})+'\n').encode());response=b''
     while not response.endswith(b'\n'):response+=s.recv(65536)
    result=json.loads(response)
    if not result['ok']:raise RuntimeError(result)
    record=result['result']
   else:
    target.parent.mkdir(parents=True,exist_ok=True)
    with source.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
    shutil.copy2(source,target)
    with target.open('rb') as f:
     assert hashlib.file_digest(f,'sha256').hexdigest()==sha
     os.fsync(f.fileno());os.posix_fadvise(f.fileno(),0,0,os.POSIX_FADV_DONTNEED)
    record={'target':str(target),'bytes':target.stat().st_size,'sha256':sha,'disk':True}
   manifest.write(json.dumps(record)+'\n');added.append(str(target));count+=1
  for p in stage.iterdir():
   if p.is_dir():shutil.rmtree(p)
   else:p.unlink()
  a.unlink()
(B/'experiment-added-files.json').write_text(json.dumps(added,indent=2));print('installed new dependency loader files',count)
