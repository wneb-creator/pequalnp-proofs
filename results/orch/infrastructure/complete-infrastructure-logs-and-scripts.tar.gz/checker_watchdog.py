import argparse,json,os,signal,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--log-prefix',required=True);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args()
cmd=a.command
if cmd and cmd[0]=='--':cmd=cmd[1:]
if not cmd:raise SystemExit('checker command required')
base=Path(a.log_prefix);limit=int(7.2*2**30);start=time.monotonic();peak=0;stopped=False;child=None;code=125

def group_alive():
 if child is None:return False
 try:os.killpg(child.pid,0);return True
 except ProcessLookupError:return False

def send_group(sig):
 try:os.killpg(child.pid,sig)
 except ProcessLookupError:pass

def cleanup():
 if child is None:return
 if group_alive():
  send_group(signal.SIGTERM)
  deadline=time.monotonic()+2
  while group_alive() and time.monotonic()<deadline:time.sleep(.05)
  if group_alive():send_group(signal.SIGKILL)
 child.wait()

def interrupted(signum,frame):raise KeyboardInterrupt
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
try:
 with Path(str(base)+'.stdout').open('w') as out,Path(str(base)+'.stderr').open('w') as err,Path(str(base)+'.memory.jsonl').open('w') as log:
  child=subprocess.Popen(cmd,stdout=out,stderr=err,start_new_session=True)
  while child.poll() is None:
   current=int(Path('/sys/fs/cgroup/memory.current').read_text());peak=max(peak,current)
   log.write(json.dumps({'seconds':round(time.monotonic()-start,3),'bytes':current})+'\n');log.flush()
   if current>=limit:stopped=True;break
   time.sleep(.1)
  if not stopped:code=child.wait()
finally:
 cleanup()
 report={'checker_exit':child.returncode if child else None,'memory_guard_stopped':stopped,'peak_cgroup_bytes':peak,'limit_bytes':limit,'seconds':round(time.monotonic()-start,3)}
 Path(str(base)+'.watchdog.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
raise SystemExit(125 if stopped else code)
