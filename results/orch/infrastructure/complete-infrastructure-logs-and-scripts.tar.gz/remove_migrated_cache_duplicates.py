import hashlib,json,re
from pathlib import Path
B=Path('/tmp/oec/pequalnp-pilot-74');A=B/'build-queue/lake-cache/artifacts'
primary=[json.loads(l) for l in (B/'memfd-cache-manifest.jsonl').read_text().splitlines()][:254]
extra=[json.loads(l) for l in (B/'memfd-cache-extra-manifest.jsonl').read_text().splitlines()]
records=[]
for r in primary+extra:
 target=Path(r['target']);h=target.with_name(target.name+'.hash').read_text().strip()
 assert re.fullmatch('[0-9a-f]{16}',h)
 cache=A/(h+'.olean.private')
 if not cache.exists():continue
 assert not cache.is_symlink() and target.is_symlink()
 before=cache.stat()
 with cache.open('rb') as f:
  assert f.fileno()>=0
  assert hashlib.file_digest(f,'sha256').hexdigest()==r['sha256']
 with target.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==r['sha256']
 after=cache.stat();assert (before.st_dev,before.st_ino,before.st_size)==(after.st_dev,after.st_ino,after.st_size)
 records.append({'cache':str(cache),'target':str(target),'inode':before.st_ino,'links':before.st_nlink,'bytes':before.st_size,'sha256':r['sha256']})
 cache.unlink()
(B/'removed-artifact-duplicates.json').write_text(json.dumps(records,indent=2))
(B/'preexisting-memfd-files.json').write_text(json.dumps(primary+extra,indent=2))
print('removed duplicate artifact links',len(records),'bytes uniquely freed',sum(r['bytes'] for r in records if r['links']==1))
