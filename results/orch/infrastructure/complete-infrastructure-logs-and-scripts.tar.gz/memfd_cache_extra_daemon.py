import fcntl,hashlib,json,os,resource,socket,stat,time
from pathlib import Path
BASE=Path('/tmp/oec/pequalnp-pilot-74')
PACKAGES=Path('/workspace/pequalnp-proofs/lean/.lake/packages')
SOCKET=BASE/'memfd-cache-extra.sock'
LIMIT=int(.48*2**30)
held={};total=0

def digest_fd(fd):
 os.lseek(fd,0,os.SEEK_SET);h=hashlib.sha256()
 while True:
  chunk=os.read(fd,1024*1024)
  if not chunk:break
  h.update(chunk)
 return h.hexdigest()

def store(req):
 global total
 source=Path(req['source']);target=Path(req['target'])
 if not source.is_absolute() or not target.is_absolute():raise ValueError('absolute paths required')
 if source.is_symlink():raise ValueError('source must be a regular file')
 if not (source.resolve().is_relative_to(BASE) or source.resolve().is_relative_to(PACKAGES)):raise ValueError('source outside task storage')
 if '..' in target.parts or not target.name.endswith('.olean.private'):raise ValueError('only canonical private cache paths accepted')
 target=target.parent.resolve()/target.name
 source=source.resolve()
 if not target.parent.is_relative_to(PACKAGES.resolve()):raise ValueError('target outside pinned package cache')
 if target in held:raise ValueError('target already memory backed')
 if target.exists() and source!=target:raise ValueError('refusing to replace an existing cache file')
 meta=source.stat()
 if not stat.S_ISREG(meta.st_mode):raise ValueError('source is not regular')
 if total+meta.st_size>LIMIT:raise ValueError('memory-backed byte limit exceeded')
 if len(held)>=14000:raise ValueError('descriptor budget exceeded')
 if int(Path('/sys/fs/cgroup/memory.current').read_text())>int(7.0*2**30):raise ValueError('population memory guard reached')
 fd=os.memfd_create('pequalnp-cache',os.MFD_CLOEXEC|os.MFD_ALLOW_SEALING)
 temp=None;committed=False
 try:
  h=hashlib.sha256()
  with source.open('rb') as f:
   while True:
    chunk=f.read(1024*1024)
    if not chunk:break
    h.update(chunk);view=memoryview(chunk)
    while view:view=view[os.write(fd,view):]
  sha=h.hexdigest()
  if os.fstat(fd).st_size!=meta.st_size or digest_fd(fd)!=sha:raise ValueError('memory-backed byte verification failed')
  os.fchmod(fd,stat.S_IMODE(meta.st_mode))
  os.utime(fd,ns=(meta.st_atime_ns,meta.st_mtime_ns))
  fcntl.fcntl(fd,1024+9,0x0008|0x0004|0x0002|0x0001)
  link=f'/proc/{os.getpid()}/fd/{fd}'
  target.parent.mkdir(parents=True,exist_ok=True)
  temp=target.with_name(target.name+f'.memfd-{os.getpid()}')
  if temp.exists() or temp.is_symlink():raise ValueError('temporary name occupied')
  os.symlink(link,temp)
  with temp.open('rb') as f:
   if hashlib.file_digest(f,'sha256').hexdigest()!=sha:raise ValueError('symlink read verification failed')
  os.replace(temp,target);committed=True;temp=None
  held[target]=fd;total+=meta.st_size
  record={'target':str(target),'bytes':meta.st_size,'sha256':sha,'fd':fd}
  with (BASE/'memfd-cache-extra-manifest.jsonl').open('a') as out:out.write(json.dumps(record)+'\n')
  if source!=target and req.get('remove_source',False):source.unlink()
  return record
 except BaseException:
  if temp is not None and temp.is_symlink():temp.unlink()
  if not committed:os.close(fd)
  raise

if SOCKET.exists():raise SystemExit('refusing to replace an existing socket')
s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);s.bind(str(SOCKET));os.chmod(SOCKET,0o600);s.listen(4)
(BASE/'memfd-cache-extra-daemon.json').write_text(json.dumps({'pid':os.getpid(),'socket':str(SOCKET),'limit':LIMIT,'fd_limits':resource.getrlimit(resource.RLIMIT_NOFILE)}))
while True:
 conn,_=s.accept()
 with conn:
  try:
   raw=b''
   while not raw.endswith(b'\n'):
    piece=conn.recv(65536)
    if not piece:break
    raw+=piece
    if len(raw)>1048576:raise ValueError('request too large')
   req=json.loads(raw)
   if req.get('action')=='status':result={'files':len(held),'bytes':total,'pid':os.getpid()}
   elif req.get('action')=='store':result=store(req)
   else:raise ValueError('unknown action')
   response={'ok':True,'result':result}
  except Exception as e:response={'ok':False,'error':str(e)}
  try:conn.sendall((json.dumps(response)+'\n').encode())
  except (BrokenPipeError,ConnectionResetError):pass
