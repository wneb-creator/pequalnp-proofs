import argparse,hashlib,json,os,shutil,socket,subprocess,time
from pathlib import Path
B=Path('/tmp/oec/pequalnp-pilot-74');P=Path('/workspace/pequalnp-proofs/lean/.lake/packages')
MAP={'Mathlib':'mathlib','Batteries':'batteries','Aesop':'aesop','Qq':'Qq','ImportGraph':'importGraph','Plausible':'plausible','ProofWidgets':'proofwidgets','LeanSearchClient':'LeanSearchClient'}
ESS=('.olean','.olean.private','.olean.server','.ir','.ir.sig')
rows=[json.loads(l) for l in (B/'cache-inventory.jsonl').read_text().splitlines()]

def package(row):
 roots={q.split('/lib/lean/',1)[1].split('/',1)[0].split('.',1)[0] for q,*_ in row['files'] if '/lib/lean/' in q and q.endswith('.olean')}
 assert len(roots)==1
 return P/MAP[roots.pop()]

def rpc(req):
 with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as s:
  s.connect(str(B/'memfd-cache.sock'));s.sendall((json.dumps(req)+'\n').encode());out=b''
  while not out.endswith(b'\n'):
   part=s.recv(65536)
   if not part:break
   out+=part
 r=json.loads(out)
 if not r['ok']:raise RuntimeError(r['error'])
 return r['result']

def evict(p):
 if p.is_symlink() or not p.is_file():return
 fd=os.open(p,os.O_RDONLY)
 try:os.posix_fadvise(fd,0,0,os.POSIX_FADV_DONTNEED)
 finally:os.close(fd)

def drop_stale_cache():
 for row in rows:
  root=package(row)
  for rel,*_ in row['files']:evict(root/rel)
 for p in (B/'toolchain/lib').rglob('*'):
  if p.is_file():evict(p)
 for p in (B/'mathlib-cache').glob('*.ltar'):evict(p)

parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['migrate','populate']);args=parser.parse_args()
start=time.monotonic();drop_stale_cache()
if args.mode=='migrate':
 choices=[]
 for row in rows:
  root=package(row)
  for rel,*_ in row['files']:
   p=root/rel
   if rel.endswith('.olean.private') and p.is_file() and not p.is_symlink():choices.append((p.stat().st_size,p))
 total=rpc({'action':'status'})['bytes']
 for size,p in sorted(choices,reverse=True):
  if total>=int(.37*2**30):break
  rpc({'action':'store','source':str(p),'target':str(p)})
  total+=size
 print(json.dumps({'migrated_bytes':total,'status':rpc({'action':'status'})}))
else:
 stage=B/'cache-populate-work';stage.mkdir(exist_ok=True)
 missing=[];discarded=0
 for row in rows:
  root=package(row)
  wanted=[rel for rel,*_ in row['files'] if rel.endswith(ESS) and not (root/rel).exists()]
  archive=B/'mathlib-cache'/row['archive']
  if not wanted:
   if archive.exists():archive.unlink();discarded+=1
  else:
   if not archive.is_file():raise RuntimeError('missing downloaded archive '+archive.name)
   missing.append((row,root,wanted,archive))
 installed=0;disk_bytes=0;memory_bytes=0
 with (B/'cache-populate-leantar.stdout').open('w') as out,(B/'cache-populate-leantar.stderr').open('w') as err,(B/'cache-populate-manifest.jsonl').open('w') as manifest:
  for i,(row,root,wanted,archive) in enumerate(missing,1):
   stat=os.statvfs(B)
   if stat.f_bavail*stat.f_frsize<96*2**20:raise RuntimeError('disk safety margin reached')
   r=subprocess.run([str(B/'toolchain/bin/leantar'),'-d','-f','--jobs','1','-j','-'],input=json.dumps([{'file':str(archive),'base':[str(stage),str(stage)]}]),text=True,stdout=out,stderr=err)
   if r.returncode:raise RuntimeError('leantar failed for '+archive.name)
   for rel in wanted:
    source=stage/rel;target=root/rel
    if target.exists():continue
    size=source.stat().st_size
    if rel.endswith('.olean.private'):
     result=rpc({'action':'store','source':str(source),'target':str(target),'remove_source':True});memory_bytes+=size
    else:
     target.parent.mkdir(parents=True,exist_ok=True)
     with source.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
     shutil.copy2(source,target)
     with target.open('rb') as f:
      if hashlib.file_digest(f,'sha256').hexdigest()!=sha:raise RuntimeError('disk byte verification failed')
      os.fsync(f.fileno());os.posix_fadvise(f.fileno(),0,0,os.POSIX_FADV_DONTNEED)
     disk_bytes+=size;result={'target':str(target),'bytes':size,'sha256':sha,'disk':True}
    manifest.write(json.dumps(result)+'\n');installed+=1
   for p in stage.iterdir():
    if p.is_dir():shutil.rmtree(p)
    else:p.unlink()
   archive.unlink()
   if i%100==0:
    manifest.flush();out.flush();err.flush()
    report={'done':i,'total':len(missing),'seconds':round(time.monotonic()-start),'installed_files':installed,'disk_bytes':disk_bytes,'memory_bytes':memory_bytes,'cgroup_bytes':int(Path('/sys/fs/cgroup/memory.current').read_text())}
    (B/'cache-populate-progress.json').write_text(json.dumps(report,indent=2))
  report={'done':len(missing),'total':len(missing),'seconds':round(time.monotonic()-start),'installed_files':installed,'disk_bytes':disk_bytes,'memory_bytes':memory_bytes,'status':rpc({'action':'status'})}
  (B/'cache-populate-final.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
