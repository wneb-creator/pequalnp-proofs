import hashlib,json,os,signal,socket,stat,subprocess
from pathlib import Path
B=Path('/tmp/oec/pequalnp-pilot-74');P=Path('/workspace/pequalnp-proofs/lean/.lake/packages')
old=json.loads((B/'preexisting-memfd-files.json').read_text());oldnames={r['target'] for r in old}
added=set(json.loads((B/'experiment-added-files.json').read_text()))
compiled=json.loads((B/'dependency-wrapper-attempt-summary.json').read_text())['compiled_dependencies']
for mod in compiled:
 assert mod.startswith('Batteries.')
 rel=Path(*mod.split('.'));root=P/'batteries'
 for sub in ['.lake/build/lib/lean','.lake/build/ir']:
  prefix=root/sub/rel
  for path in prefix.parent.glob(prefix.name+'.*'):
   if path.is_file() or path.is_symlink():added.add(str(path))
removed=[]
for name in sorted(added):
 path=Path(name)
 assert path.is_relative_to(P) and path.parent.resolve().is_relative_to(P.resolve())
 if name in oldnames:continue
 if path.is_symlink() or path.is_file():path.unlink();removed.append(name)
(B/'experiment-removed-files.json').write_text(json.dumps(removed,indent=2))
for r in old:
 target=Path(r['target']);meta=target.stat()
 if target.is_symlink():
  temp=target.with_name(target.name+'.baseline-restore');assert not temp.exists()
  h=hashlib.sha256()
  with target.open('rb') as source,temp.open('xb') as out:
   while True:
    chunk=source.read(1024*1024)
    if not chunk:break
    h.update(chunk);out.write(chunk)
   out.flush();os.fsync(out.fileno())
  assert h.hexdigest()==r['sha256']
  os.chmod(temp,stat.S_IMODE(meta.st_mode));os.utime(temp,ns=(meta.st_atime_ns,meta.st_mtime_ns));os.replace(temp,target)
 with target.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==r['sha256']
for r in json.loads((B/'removed-artifact-duplicates.json').read_text()):
 target=Path(r['target']);cache=Path(r['cache'])
 if not cache.exists():os.link(target,cache)
 assert target.stat().st_ino==cache.stat().st_ino
assert all(not Path(r['target']).is_symlink() for r in old)
for line in (B/'memfd-cache-manifest.jsonl').read_text().splitlines():
 r=json.loads(line);p=Path(r['target'])
 assert not p.is_symlink(),str(p)
with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as s:
 s.connect(str(B/'memfd-cache.sock'));s.sendall(b'{"action":"status"}\n');status=json.loads(s.recv(4096))['result']
pid=status['pid'];cmd=Path('/proc',str(pid),'cmdline').read_bytes().split(b'\0');assert str(B/'memfd_cache_daemon.py').encode() in cmd
os.kill(pid,signal.SIGTERM);(B/'memfd-cache.sock').unlink()
for mode in ['-xf','-df']:
 with (B/('toolchain-baseline-restore-'+mode[1:]+'.stdout')).open('w') as out,(B/('toolchain-baseline-restore-'+mode[1:]+'.stderr')).open('w') as err:
  r=subprocess.run(['tar','--zstd',mode,str(B/'toolchain-native-editor-backup.tar.zst'),'-C',str(B/'toolchain')],stdout=out,stderr=err)
  if r.returncode:raise RuntimeError('toolchain restore/compare failed')
(B/'toolchain-native-editor-backup.tar.zst').unlink()
report={'removed_experiment_paths':len(removed),'restored_preexisting_private_files':len(old),'restored_hardlinks':len(json.loads((B/'removed-artifact-duplicates.json').read_text())),'main_daemon_stopped':pid,'native_editor_archive_restored_and_compared':True}
(B/'baseline-restoration.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
