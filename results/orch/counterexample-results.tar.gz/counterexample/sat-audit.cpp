#include "cadical/src/cadical.hpp"
#include <array>
#include <vector>
#include <algorithm>
#include <random>
#include <chrono>
#include <iostream>
#include <set>
using namespace std;
constexpr int N=20;
struct Gate {int op,a,b;};
struct Deadline:CaDiCaL::Terminator {chrono::steady_clock::time_point t; bool terminate(){return chrono::steady_clock::now()>t;}};
struct Search {
 CaDiCaL::Solver s;
 int nv=0;
 array<array<int,3>,N> op;
 array<vector<int>,N> A,B;
 set<int> samples;
 vector<pair<int,int>> edges={{0,1},{1,2},{2,3},{3,4},{4,0},{0,5},{1,6},{2,7},{3,8},{4,9},{5,7},{7,9},{9,6},{6,8},{8,5}};
 int fresh(){return ++nv;}
 void clause(initializer_list<int> c){for(int x:c)s.add(x);s.add(0);}
 void clause(vector<int> c){for(int x:c)s.add(x);s.add(0);}
 void exactly(vector<int> c){clause(c);for(unsigned i=0;i<c.size();i++)for(unsigned j=0;j<i;j++)clause({-c[i],-c[j]});}
 bool truth(int x){for(auto [a,b]:edges)if((x>>a&1)&&(x>>b&1))return true;return false;}
 Search(int first) {
  s.set("quiet",1);
  for(int i=0;i<N;i++) {
   for(int j=0;j<3;j++)op[i][j]=fresh();exactly({op[i][0],op[i][1],op[i][2]});
   for(int j=0;j<10+i;j++){A[i].push_back(fresh());B[i].push_back(fresh());}
   exactly(A[i]);exactly(B[i]);
   for(int a=0;a<10+i;a++)for(int b=0;b<a;b++)clause({op[i][2],-A[i][a],-B[i][b]});
   clause({-op[i][2],B[i][0]});
   for(int j=0;j<i;j++)clause({-op[i][2],-A[i][10+j],-op[j][2]});
  }
  vector<int> ns;for(int i=0;i<N;i++)ns.push_back(op[i][2]);
  for(int a=0;a<N;a++)for(int b=0;b<a;b++)for(int c=0;c<b;c++)for(int d=0;d<c;d++)for(int e=0;e<d;e++)clause({-ns[a],-ns[b],-ns[c],-ns[d],-ns[e]});
  // Every gate contributes to the output; duplicate-input gates can pad smaller witnesses.
  for(int i=0;i<N-1;i++){vector<int> uses;for(int j=i+1;j<N;j++){uses.push_back(A[j][10+i]);uses.push_back(B[j][10+i]);}clause(uses);}
  for(int i=0;i<N-1;i++)for(int a=0;a<10+i;a++)for(int b=0;b<a;b++)clause({-A[i][a],-A[i+1][b],B[i+1][10+i]});
  if(first>=0&&first<5){clause({op[0][first/2]});clause({A[0][0]});if(first<4)clause({B[0][first%2?2:1]});}
  for(int i=1;i<=nv;i++)s.freeze(i);
 }
 void sample(int x) {
  if(!samples.insert(x).second)return;
  array<int,10+N>w;
  for(int i=0;i<10;i++){w[i]=fresh();clause({x>>i&1?w[i]:-w[i]});}
  for(int i=0;i<N;i++) {
   int a=fresh(),b=fresh(),z=w[10+i]=fresh();
   for(int j=0;j<10+i;j++) {
    clause({-A[i][j],-a,w[j]});clause({-A[i][j],a,-w[j]});
    clause({-B[i][j],-b,w[j]});clause({-B[i][j],b,-w[j]});
   }
   clause({-op[i][0],-a,-b,z});clause({-op[i][0],a,-z});clause({-op[i][0],b,-z});
   clause({-op[i][1],a,b,-z});clause({-op[i][1],-a,z});clause({-op[i][1],-b,z});
   clause({-op[i][2],a,z});clause({-op[i][2],-a,-z});
  }
  clause({truth(x)?w[10+N-1]:-w[10+N-1]});
 }
 array<Gate,N> model() {
  array<Gate,N> g;
  for(int i=0;i<N;i++) {
   for(int j=0;j<3;j++)if(s.val(op[i][j])>0)g[i].op=j;
   for(int j=0;j<10+i;j++){if(s.val(A[i][j])>0)g[i].a=j;if(s.val(B[i][j])>0)g[i].b=j;}
  }return g;
 }
 bool evaluate(array<Gate,N>&g,int x){array<bool,10+N>w;for(int i=0;i<10;i++)w[i]=x>>i&1;for(int i=0;i<N;i++)w[10+i]=g[i].op==0?w[g[i].a]&&w[g[i].b]:g[i].op==1?w[g[i].a]||w[g[i].b]:!w[g[i].a];return w[10+N-1];}
};
int main() {
 Search t(3);
 const array<Gate,N> witness = {{{1,0,2}, {1,2,4}, {1,2,5}, {1,3,6}, {0,3,11}, {1,4,5}, {0,0,15}, {1,5,13}, {1,6,7}, {1,4,18}, {1,6,10}, {0,1,20}, {0,7,12}, {0,8,17}, {0,9,19}, {1,14,22}, {1,16,24}, {1,23,26}, {1,21,27}, {1,25,28}}};
 for(int i=0;i<N;i++) {
  t.clause({t.op[i][witness[i].op]});
  t.clause({t.A[i][witness[i].a]});
  t.clause({t.B[i][witness[i].b]});
 }
 for(int x=0;x<1024;x++)t.sample(x);
 int status=t.s.solve();
 cout<<"Pinned normalized L_meta_587; gates="<<N<<"; assignments="<<t.samples.size()<<"; SAT status="<<status<<endl;
 if(status!=10)return 1;
 auto g=t.model();
 for(int x=0;x<1024;x++)if(t.truth(x)!=t.evaluate(g,x))return 2;
 cout<<"Model checked independently on all 1024 assignments."<<endl;
 return 0;
}
