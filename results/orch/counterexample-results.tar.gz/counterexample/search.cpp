#include <array>
#include <vector>
#include <algorithm>
#include <random>
#include <chrono>
#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdint>
using namespace std;
constexpr int N=19;
using TT=array<uint64_t,16>;
struct Gate { int op,a,b; };
struct Candidate { array<Gate,N> g; int error=99999; };
array<TT,10> inputs;
TT target;
vector<pair<int,int>> edges={{0,1},{1,2},{2,3},{3,4},{4,0},{0,5},{1,6},{2,7},{3,8},{4,9},{5,7},{7,9},{9,6},{6,8},{8,5}};
mt19937_64 rng(2592);
int rnd(int n) {return rng()%n;}
int eval(Candidate& c, int weight=12) {
 array<TT,29> wires;
 for(int i=0;i<10;i++) wires[i]=inputs[i];
 int nn=0,bad=0;
 for(int i=0;i<N;i++) {
  Gate g=c.g[i]; nn+=g.op==2;
  if(g.op==2&&g.a>=10&&c.g[g.a-10].op==2)bad++;
  if(g.op!=2&&g.a==g.b)bad++;
  for(int j=0;j<16;j++) wires[10+i][j]=g.op==0 ? wires[g.a][j]&wires[g.b][j] : g.op==1 ? wires[g.a][j]|wires[g.b][j] : ~wires[g.a][j];
  if(g.op==2) {
   uint64_t nonzero=0,nonones=0;
   for(int j=0;j<16;j++){nonzero|=wires[10+i][j];nonones|=~wires[10+i][j];}
   if(!nonzero||!nonones)bad++;
  }
 }
 int error=1024*bad;
 for(int j=0;j<16;j++) {
  error+=__builtin_popcountll(wires[28][j]&~target[j])*weight;
  error+=__builtin_popcountll(~wires[28][j]&target[j]);
 }
 if(nn==0) error+=1024;
 if(nn>3) error+=(nn-3)*1024;
 uint32_t used=1U<<28; bool activeNot=false;
 for(int i=N-1;i>=0;i--)if(used&(1U<<(10+i))) {
  used|=1U<<c.g[i].a;
  if(c.g[i].op!=2)used|=1U<<c.g[i].b;
  else activeNot=true;
 }
 if(!activeNot)error+=1024;
 return c.error=error;
}
void dump(const Candidate& c) {
 cout<<"candidate weighted error "<<c.error<<"\n";
 for(int i=0;i<N;i++) cout<<10+i<<" "<<c.g[i].op<<" "<<c.g[i].a<<" "<<c.g[i].b<<"\n";
 cout.flush();
}
Candidate seed() {
 vector<int> cover;
 while(true) {
  cover.clear();int mask=rnd(1024);
  if(__builtin_popcount((unsigned)mask)!=6)continue;
  bool ok=true;for(auto [a,b]:edges)if(!((mask>>a&1)||(mask>>b&1)))ok=false;
  if(!ok)continue;
  for(int i=0;i<10;i++)if(mask>>i&1)cover.push_back(i);
  break;
 }
 shuffle(cover.begin(),cover.end(),rng);
 vector<Gate> gs;vector<int> terms;
 vector<pair<int,int>> rem=edges;
 for(int a:cover) {
  vector<int> ns;
  for(auto [u,v]:rem)if(a==u)ns.push_back(v);else if(a==v)ns.push_back(u);
  rem.erase(remove_if(rem.begin(),rem.end(),[a](auto p){return p.first==a||p.second==a;}),rem.end());
  if(ns.empty())continue;
  shuffle(ns.begin(),ns.end(),rng);
  int b=ns[0];
  for(unsigned i=1;i<ns.size();i++){gs.push_back({1,b,ns[i]}); b=10+gs.size()-1;}
  gs.push_back({0,a,b});terms.push_back(10+gs.size()-1);
 }
 shuffle(terms.begin(),terms.end(),rng);
 int out=terms[0];
 for(unsigned i=1;i<terms.size();i++){gs.push_back({1,out,terms[i]});out=10+gs.size()-1;}
 if(rnd(2))gs={{1,9,5},{1,0,9},{1,0,6},{1,7,3},{0,1,12},{1,6,5},{1,11,3},{1,13,1},{1,14,2},{0,12,15},{0,4,16},{0,19,11},{1,7,21},{0,18,17},{1,20,23},{1,3,15},{0,25,8},{0,22,10},{1,27,26},{1,24,28}};
 while(gs.size()>N) {
  int k=rnd(gs.size()-1),replacement=(rnd(2)?gs[k].a:gs[k].b);
  gs.erase(gs.begin()+k);
  for(auto& g:gs)for(int* p:{&g.a,&g.b}){if(*p==10+k)*p=replacement;else if(*p>10+k)(*p)--;}
 }
 Candidate c;
 for(int i=0;i<N;i++)c.g[i]=gs[i];
 {int k=rnd(N-1);c.g[k].op=2;}
 return c;
}
void mutate(Candidate& c) {
 int nm=1+(rnd(10)==0)+(rnd(30)==0);
 while(nm--) {
  int k=rnd(N); int what=rnd(10);
  if(what<2)c.g[k].op=rnd(16)==0?2:rnd(2);
  else if(what<6)c.g[k].a=rnd(10+k);
  else c.g[k].b=rnd(10+k);
 }
}
int main(int argc,char**argv) {
 int seconds=argc>1?atoi(argv[1]):600;
 if(argc>2)rng.seed(strtoull(argv[2],nullptr,10));
 for(int x=0;x<1024;x++) {
  for(int i=0;i<10;i++)if(x>>i&1)inputs[i][x/64]|=1ULL<<(x%64);
  bool y=false;for(auto [a,b]:edges)y|=(x>>a&1)&&(x>>b&1);
  if(y)target[x/64]|=1ULL<<(x%64);
 }
 auto start=chrono::steady_clock::now();long long evaluations=0;
 Candidate global; global.error=99999;
 vector<Candidate> elites;
 for(int restart=0;;restart++) {
  Candidate c=seed();
  if(!elites.empty()&&rnd(5)) {c=elites[rnd(elites.size())];for(int i=0;i<2+rnd(8);i++)mutate(c);}
  int w=argc>3?atoi(argv[3]):12; eval(c,w);
  double temperature=(restart%5==0?3.0:0.0);
  for(int iter=0;iter<200000;iter++) {
   Candidate d=c;mutate(d);eval(d,w);evaluations++;
   if(d.error<=c.error||(temperature>0&&generate_canonical<double,53>(rng)<exp((c.error-d.error)/temperature)))c=d;
   if(d.error<global.error) {global=d;cout<<"evals "<<evaluations<<" restart "<<restart<<" elapsed "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"\n";dump(d);}
   if(d.error==0){cout<<"FOUND\n";return 0;}
   if(iter%10000==0&&chrono::duration<double>(chrono::steady_clock::now()-start).count()>seconds){cout<<"DONE evaluations "<<evaluations<<"\n";dump(global);return 0;}
  }
  if(elites.size()<32)elites.push_back(c);
  else {int k=rnd(elites.size());if(c.error<elites[k].error||rnd(5)==0)elites[k]=c;}
 }
}
