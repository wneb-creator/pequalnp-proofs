import json
import re
import sys
from pathlib import Path

edges = [(0, 1), (1, 2), (2, 3), (3, 4), (4, 0), (0, 5), (1, 6), (2, 7),
         (3, 8), (4, 9), (5, 7), (7, 9), (9, 6), (6, 8), (8, 5)]

def evaluate(gs, x):
    w = [bool(x >> i & 1) for i in range(10)]
    for op, a, b in gs:
        w.append(w[a] and w[b] if op == 0 else w[a] or w[b] if op == 1 else not w[a])
    return w[-1]

def normalize(gs):
    known = {j: j for j in range(10)}
    pending = set(range(len(gs)))
    out = []
    while pending:
        candidates = []
        for j in pending:
            if j == len(gs) - 1 and len(pending) > 1:
                continue
            op, a, b = gs[j]
            if a not in known or op != 2 and b not in known:
                continue
            a = known[a]
            b = 0 if op == 2 else known[b]
            if op != 2:
                a, b = sorted((a, b))
            candidates.append((a, b, op, j))
        a, b, op, j = min(candidates)
        known[10 + j] = 10 + len(out)
        pending.remove(j)
        out.append((op, a, b))
    return out

repo = Path(sys.argv[1])
outdir = Path(sys.argv[2])
outdir.mkdir(parents=True, exist_ok=True)
rows = []
seen = set()
for number in (584, 587):
    path = repo / 'lean' / 'PEqualNP' / 'Outside' / f'L_meta_{number}.lean'
    matches = re.findall(r'GateOp\.(and|or|not), \[(\d+), (\d+)\]', path.read_text())
    gates = [({'and': 0, 'or': 1, 'not': 2}[op], int(a), int(b)) for op, a, b in matches]
    assert len(gates) == 20
    assert all(evaluate(gates, x) == any((x >> a & 1) and (x >> b & 1) for a, b in edges) for x in range(1024))
    for removed in range(19):
        for operand in (1, 2):
            replacement = gates[removed][operand]
            def renumber(w):
                if w == 10 + removed:
                    return replacement
                return w - (w > 10 + removed)
            shortened = [(op, renumber(a), renumber(b)) for j, (op, a, b) in enumerate(gates) if j != removed]
            ordered = normalize(shortened)
            assert all(evaluate(ordered, x) == evaluate(shortened, x) for x in range(1024))
            key = tuple(ordered)
            if key in seen:
                continue
            seen.add(key)
            errors = sum(evaluate(ordered, x) != any((x >> a & 1) and (x >> b & 1) for a, b in edges) for x in range(1024))
            name = f'seed_{number}_{removed:02d}_{operand}.txt'
            (outdir / name).write_text('\n'.join(' '.join(map(str, g)) for g in ordered) + '\n')
            rows.append({'file': name, 'source': number, 'removed': removed, 'operand': operand, 'errors': errors})
rows.sort(key=lambda x: x['errors'])
(outdir / 'manifest.json').write_text(json.dumps(rows, indent=2) + '\n')
print('Validated both 20-gate source circuits on all 1024 inputs; generated', len(rows), 'distinct 19-gate seeds')
print('Best five seed errors:', [row['errors'] for row in rows[:5]])
