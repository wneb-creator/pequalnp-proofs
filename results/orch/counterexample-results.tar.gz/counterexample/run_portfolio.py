import datetime
import json
import signal
import subprocess
import sys
import time
from pathlib import Path

base = Path(sys.argv[1])
seconds = int(sys.argv[2]) if len(sys.argv) > 2 else 30
count = int(sys.argv[3]) if len(sys.argv) > 3 else 76
distance = int(sys.argv[4]) if len(sys.argv) > 4 else 3
manifest = json.loads((base / 'local-seeds' / 'manifest.json').read_text())
assert isinstance(manifest, list) and all(isinstance(row, dict) for row in manifest)
out = base / f'portfolio-k{distance}'
out.mkdir(exist_ok=True)
running = None
stop = False

def interrupt(signum, frame):
    global stop
    stop = True
    if running is not None and running.poll() is None:
        running.terminate()

signal.signal(signal.SIGTERM, interrupt)
signal.signal(signal.SIGINT, interrupt)
results = []
start = time.monotonic()
for index, row in enumerate(manifest[:count]):
    if stop:
        break
    name = row['file']
    assert Path(name).name == name
    seed = base / 'local-seeds' / name
    logfile = out / (seed.stem + '.log')
    command = [str(base / 'sat-local'), '-1', str(seconds), '1', str(seed), str(distance)]
    print(datetime.datetime.now(datetime.timezone.utc).isoformat(), index, name, 'initial_errors', row['errors'], flush=True)
    with logfile.open('w') as log:
        running = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
        code = running.wait()
    text = logfile.read_text()
    if 'FOUND\n' in text:
        status = 'FOUND'
    elif 'status 20 ' in text:
        status = 'restricted_unsat'
    elif 'status 0 ' in text:
        status = 'unknown'
    else:
        status = 'stopped_or_error'
    results.append({**row, 'status': status, 'exit_code': code, 'log': str(logfile), 'elapsed_total': time.monotonic() - start})
    (out / 'summary.json').write_text(json.dumps(results, indent=2) + '\n')
    print(status, 'elapsed_total', round(time.monotonic() - start, 3), flush=True)
    if status in ('FOUND', 'stopped_or_error'):
        break
print('FINISHED', len(results), 'elapsed', round(time.monotonic() - start, 3), flush=True)
