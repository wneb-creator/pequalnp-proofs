import itertools
import json
import sys
from pathlib import Path

COFACTOR_EDGES = [(0, 1), (1, 2), (2, 3), (0, 5), (1, 6), (2, 7),
                  (3, 8), (4, 6), (6, 8), (8, 5), (5, 7), (7, 4)]
PETERSEN_EDGES = [(0, 1), (1, 2), (2, 3), (3, 4), (4, 0), (0, 5), (1, 6),
                  (2, 7), (3, 8), (4, 9), (5, 7), (7, 9), (9, 6), (6, 8), (8, 5)]

def wires(gates, x, inputs):
    values = [bool(x >> j & 1) for j in range(inputs)]
    for op, a, b in gates:
        assert 0 <= op <= 2 and 0 <= a < len(values) and 0 <= b < len(values)
        values.append(values[a] and values[b] if op == 0 else values[a] or values[b] if op == 1 else not values[a])
    return values

def target(edges, x):
    return any((x >> a & 1) and (x >> b & 1) for a, b in edges)

def lift(gates, cofactor_output, cached_wire, remaining_neighbor):
    lifted = [(op, a + 1, b + 1) for op, a, b in gates]
    next_wire = 10 + len(lifted)
    lifted.append((1, cached_wire + 1, remaining_neighbor + 1))
    lifted.append((0, 0, next_wire))
    lifted.append((1, cofactor_output + 1, next_wire + 1))
    return lifted

def control(path):
    gates = [tuple(map(int, line.split())) for line in Path(path).read_text().splitlines()]
    assert len(gates) == 16
    assert all(wires(gates, x, 9)[24] == target(COFACTOR_EDGES, x) for x in range(512))
    # Add the cached OR explicitly to the positive control, then restore vertex zero.
    gates.append((1, 0, 3))
    lifted = lift(gates, 24, 25, 4)
    assert len(lifted) == 20
    assert all(wires(lifted, x, 10)[-1] == target(PETERSEN_EDGES, x) for x in range(1024))
    print('Positive lift control: old input j maps to new input j+1; all 1024 rows verified, 20 gates.')

def validate(log_path, output_prefix):
    lines = Path(log_path).read_text().splitlines()
    index = next(i for i, line in enumerate(lines) if line == 'FOUND')
    rows = [list(map(int, line.split())) for line in lines[index + 1:index + 17]]
    assert [r[0] for r in rows] == list(range(9, 25))
    gates = [tuple(row[1:]) for row in rows]
    assert sum(op == 2 for op, a, b in gates) == 1, 'This is not an exactly-one-NOT search model.'
    values = [wires(gates, x, 9) for x in range(512)]
    assert all(v[24] == target(COFACTOR_EDGES, x) for x, v in enumerate(values))
    result = {'cofactor_gates': gates, 'cofactor_rows_verified': 512, 'lifted': False}
    for a, b in itertools.combinations((0, 3, 4), 2):
        for wire in range(25):
            if all(v[wire] == (bool(x >> a & 1) or bool(x >> b & 1)) for x, v in enumerate(values)):
                remaining = next(i for i in (0, 3, 4) if i not in (a, b))
                lifted = lift(gates, 24, wire, remaining)
                assert len(lifted) == 19
                assert sum(op == 2 for op, a, b in lifted) == 1
                assert all(wires(lifted, x, 10)[-1] == target(PETERSEN_EDGES, x) for x in range(1024))
                result.update(lifted=True, cached_pair=[a, b], cached_wire=wire,
                              full_gates=lifted, full_rows_verified=1024)
                Path(output_prefix + '.txt').write_text('\n'.join(' '.join(map(str, g)) for g in lifted) + '\n')
                break
        if result['lifted']:
            break
    Path(output_prefix + '.json').write_text(json.dumps(result, indent=2) + '\n')
    print('Exactly-one-NOT cofactor model verified on all 512 rows; lifted full 19-gate witness:', result['lifted'])

if __name__ == '__main__':
    if sys.argv[1] == '--control':
        control(sys.argv[2])
    else:
        validate(sys.argv[1], sys.argv[2])
