#include "cadical/src/cadical.hpp"
#include <array>
#include <vector>
#include <algorithm>
#include <random>
#include <chrono>
#include <iostream>
#include <fstream>
#include <functional>
#include <set>
using namespace std;
constexpr int N=16;
constexpr int I=9;
constexpr int SIZE=1<<I;
constexpr int OUT=I+N-1;
struct Gate {int op,a,b;};
struct Deadline:CaDiCaL::Terminator {chrono::steady_clock::time_point t; bool terminate(){return chrono::steady_clock::now()>t;}};
struct Search {
 CaDiCaL::Solver s;
 int nv=0;
 array<array<int,3>,N> op;
 array<vector<int>,N> A,B;
 set<int> samples;
 vector<pair<int,int>> edges={{0,1},{1,2},{2,3},{0,5},{1,6},{2,7},{3,8},{4,6},{6,8},{8,5},{5,7},{7,4}};
 int fresh(){return ++nv;}
 void clause(initializer_list<int> c){for(int x:c)s.add(x);s.add(0);}
 void clause(vector<int> c){for(int x:c)s.add(x);s.add(0);}
 void exactly(vector<int> c){clause(c);for(unsigned i=0;i<c.size();i++)for(unsigned j=0;j<i;j++)clause({-c[i],-c[j]});}
 bool truth(int x){for(auto [a,b]:edges)if((x>>a&1)&&(x>>b&1))return true;return false;}
 Search(int first) {
  s.set("quiet",1);
  for(int i=0;i<N;i++) {
   for(int j=0;j<3;j++)op[i][j]=fresh();exactly({op[i][0],op[i][1],op[i][2]});
   for(int j=0;j<I+i;j++){A[i].push_back(fresh());B[i].push_back(fresh());}
   exactly(A[i]);exactly(B[i]);
   for(int a=0;a<I+i;a++)for(int b=0;b<a;b++)clause({op[i][2],-A[i][a],-B[i][b]});
   clause({-op[i][2],B[i][0]});
   for(int j=0;j<i;j++)clause({-op[i][2],-A[i][I+j],-op[j][2]});
  }
  vector<int> ns;for(int i=0;i<N;i++)ns.push_back(op[i][2]);clause(ns);
  for(int a=0;a<N;a++)for(int b=0;b<a;b++)clause({-ns[a],-ns[b]});
  // Every gate contributes to the output; duplicate-input gates can pad smaller witnesses.
  for(int i=0;i<N-1;i++){vector<int> uses;for(int j=i+1;j<N;j++){uses.push_back(A[j][I+i]);uses.push_back(B[j][I+i]);}clause(uses);}
  for(int i=0;i<N-1;i++)for(int a=0;a<I+i;a++)for(int b=0;b<a;b++)clause({-A[i][a],-A[i+1][b],B[i+1][I+i]});
  if(first>=0&&first<5){clause({op[0][first/2]});clause({A[0][0]});if(first<4)clause({B[0][first%2?2:1]});}
  if(first==5){clause({op[0][1]});clause({A[0][0]});clause({B[0][3]});}
  for(int i=1;i<=nv;i++)s.freeze(i);
 }
 void sample(int x) {
  if(!samples.insert(x).second)return;
  array<int,I+N>w;
  for(int i=0;i<I;i++){w[i]=fresh();clause({x>>i&1?w[i]:-w[i]});}
  for(int i=0;i<N;i++) {
   int a=fresh(),b=fresh(),z=w[I+i]=fresh();
   for(int j=0;j<I+i;j++) {
    clause({-A[i][j],-a,w[j]});clause({-A[i][j],a,-w[j]});
    clause({-B[i][j],-b,w[j]});clause({-B[i][j],b,-w[j]});
   }
   clause({-op[i][0],-a,-b,z});clause({-op[i][0],a,-z});clause({-op[i][0],b,-z});
   clause({-op[i][1],a,b,-z});clause({-op[i][1],-a,z});clause({-op[i][1],-b,z});
   clause({-op[i][2],a,z});clause({-op[i][2],-a,-z});
  }
  clause({truth(x)?w[OUT]:-w[OUT]});
 }
 array<Gate,N> model() {
  array<Gate,N> g;
  for(int i=0;i<N;i++) {
   for(int j=0;j<3;j++)if(s.val(op[i][j])>0)g[i].op=j;
   for(int j=0;j<I+i;j++){if(s.val(A[i][j])>0)g[i].a=j;if(s.val(B[i][j])>0)g[i].b=j;}
  }return g;
 }
 bool evaluate(array<Gate,N>&g,int x){array<bool,I+N>w;for(int i=0;i<I;i++)w[i]=x>>i&1;for(int i=0;i<N;i++)w[I+i]=g[i].op==0?w[g[i].a]&&w[g[i].b]:g[i].op==1?w[g[i].a]||w[g[i].b]:!w[g[i].a];return w[OUT];}
};
int main(int argc,char**argv) {
 int first=argc>1?atoi(argv[1]):-1,seconds=argc>2?atoi(argv[2]):600;
 auto begin=chrono::steady_clock::now();Deadline d;d.t=begin+chrono::seconds(seconds);
 Search t(first);t.s.connect_terminator(&d);
 if(argc>4) {
  ifstream f(argv[4]);vector<int> changed;
  for(int i=0;i<N;i++) {
   int op,a,b;f>>op>>a>>b;
   if(!f||op<0||op>2||a<0||a>=I+i||b<0||b>=I+i){cerr<<"bad seed\n";return 3;}
   int v=t.fresh();changed.push_back(v);
   t.clause({v,t.op[i][op]});t.clause({v,t.A[i][a]});t.clause({v,t.B[i][b]});
  }
  int k=argc>5?atoi(argv[5]):3;
  vector<int> group;
  function<void(int,int)> select=[&](int start,int left){
   if(!left){t.clause(group);return;}
   for(int i=start;i<=N-left;i++){group.push_back(-changed[i]);select(i+1,left-1);group.pop_back();}
  };
  select(0,k+1);
 }
 t.sample(0);for(int i=0;i<I;i++)t.sample(1<<i);
 for(auto [a,b]:t.edges)t.sample((1<<a)|(1<<b));
 for(int x=0;x<SIZE;x++)if(!t.truth(x)){
  bool maximal=true;for(int i=0;i<I;i++)if(!(x>>i&1)&&!t.truth(x|(1<<i)))maximal=false;
  if(maximal)t.sample(x);
 }
 if(argc>3&&atoi(argv[3]))for(int x=0;x<SIZE;x++)t.sample(x);
 for(int iter=0;;iter++) {
  cout<<"solve first "<<first<<" iter "<<iter<<" samples "<<t.samples.size()<<" variables "<<t.nv<<" elapsed "<<chrono::duration<double>(chrono::steady_clock::now()-begin).count()<<endl;
  int status=t.s.solve();
  if(status!=10){cout<<"status "<<status<<" elapsed "<<chrono::duration<double>(chrono::steady_clock::now()-begin).count()<<endl;return status==20?0:2;}
  auto g=t.model();vector<int> bad;
  for(int x=0;x<SIZE;x++)if(t.truth(x)!=t.evaluate(g,x))bad.push_back(x);
  cout<<"model errors "<<bad.size()<<endl;
  if(bad.empty()){cout<<"FOUND\n";for(int i=0;i<N;i++)cout<<I+i<<" "<<g[i].op<<" "<<g[i].a<<" "<<g[i].b<<"\n";return 0;}
  for(unsigned i=0;i<min((unsigned)16,(unsigned)bad.size());i++)t.sample(bad[i*bad.size()/min((unsigned)16,(unsigned)bad.size())]);
 }
}
