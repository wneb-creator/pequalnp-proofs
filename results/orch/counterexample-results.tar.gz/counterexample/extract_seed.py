import json
import sys
from pathlib import Path

edges = [(0, 1), (1, 2), (2, 3), (3, 4), (4, 0), (0, 5), (1, 6), (2, 7),
         (3, 8), (4, 9), (5, 7), (7, 9), (9, 6), (6, 8), (8, 5)]

def evaluate(gs, x):
    w = [bool(x >> i & 1) for i in range(10)]
    for op, a, b in gs:
        w.append(w[a] and w[b] if op == 0 else w[a] or w[b] if op == 1 else not w[a])
    return w[-1]

def normalize(gs):
    known = {j: j for j in range(10)}
    pending = set(range(19))
    out = []
    while pending:
        candidates = []
        for j in pending:
            if j == 18 and len(pending) > 1:
                continue
            op, a, b = gs[j]
            if a not in known or op != 2 and b not in known:
                continue
            a = known[a]
            b = 0 if op == 2 else known[b]
            if op != 2:
                a, b = sorted((a, b))
            candidates.append((a, b, op, j))
        a, b, op, j = min(candidates)
        known[10 + j] = 10 + len(out)
        pending.remove(j)
        out.append((op, a, b))
    return out

def suitable(gs):
    used = {28}
    for i in range(18, -1, -1):
        if i + 10 in used:
            op, a, b = gs[i]
            used.add(a)
            if op != 2:
                used.add(b)
    if not set(range(10, 29)) <= used:
        return False
    if not 1 <= sum(op == 2 for op, a, b in gs) <= 3:
        return False
    if any(op == 2 and a >= 10 and gs[a - 10][0] == 2 for op, a, b in gs):
        return False
    if any(gs[i][1] > gs[i + 1][1] and gs[i + 1][2] != 10 + i for i in range(18)):
        return False
    return True

lines = Path(sys.argv[1]).read_text().splitlines()
candidates = []
for i, line in enumerate(lines):
    if not line.startswith('candidate') or i + 19 >= len(lines):
        continue
    original = [list(map(int, s.split()))[1:] for s in lines[i + 1:i + 20]]
    if any(len(g) != 3 for g in original):
        continue
    gs = normalize(original)
    assert all(evaluate(gs, x) == evaluate(original, x) for x in range(1024))
    if not suitable(gs):
        continue
    errors = [x for x in range(1024) if evaluate(gs, x) != any((x >> a & 1) and (x >> b & 1) for a, b in edges)]
    candidates.append((len(errors), errors, gs))
if not candidates:
    raise SystemExit('No candidate satisfies SAT normalization restrictions')
count, errors, gs = min(candidates)
output = Path(sys.argv[2])
output.write_text('\n'.join(' '.join(map(str, g)) for g in gs) + '\n')
output.with_suffix('.json').write_text(json.dumps({'errors': errors, 'gates': gs, 'source': sys.argv[1]}, indent=2) + '\n')
print('Saved', output, 'with', count, 'wrong truth-table rows and', sum(op == 2 for op, a, b in gs), 'NOT gates')
