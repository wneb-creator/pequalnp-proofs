from itertools import combinations
from collections import Counter
import json
from pathlib import Path
E=[(0,1),(1,2),(2,3),(3,4),(4,0),(0,5),(1,6),(2,7),(3,8),(4,9),(5,7),(7,9),(9,6),(6,8),(8,5)]
ALL=(1<<1024)-1
P=[sum(1<<r for r in range(1024) if r>>i&1) for i in range(10)]
T=sum(1<<r for r in range(1024) if any((r>>a&1) and(r>>b&1) for a,b in E))
def op(d,a,b,allbits=ALL):
    return (a&b,a|b,a&(allbits^b),(allbits^a)&b)[d]
def viable(S):
    mask=sum(1<<i for i,p in enumerate(P) if p in S)
    if mask==1023:return True
    ex=[x for x in S if x not in P]
    seen={}
    for r in range(1024):
        key=(r&mask)|sum(((x>>r)&1)<<(10+j) for j,x in enumerate(ex))
        t=(T>>r)&1
        if key in seen and seen[key]!=t:return False
        seen[key]=t
    return True
PROJ=[]
for i in range(10):
    Q=[]
    for j in range(10):
        Q.append(sum(1<<r for r in range(512) if j!=i and ((r>>(j if j<i else j-1))&1)))
    PROJ.append(Q)
A9=(1<<512)-1
summaries=[]
for edge,j in [('edge',1),('nonedge',2)]:
    g0=P[0]|P[j]
    S0=frozenset(P+[g0])
    seq=list(P)+[g0]
    counts=Counter(); survivors=[]
    for aidx,bidx in combinations(range(11),2):
        a,b=seq[aidx],seq[bidx]
        for d in range(4):
            g1=op(d,a,b)
            if g1 in S0 or g1==0 or g1==ALL:continue
            for ka in [False,True]:
                for kb in [False,True]:
                    S=set(S0)
                    if not ka:S.remove(a)
                    if not kb:S.remove(b)
                    S.add(g1)
                    if not viable(S):
                        counts['inconsistent']+=1;continue
                    best=0; data=[]
                    for i,Q in enumerate(PROJ):
                        pq=Q[0]|Q[j]
                        vals=Q+[pq]
                        pa,pb=vals[aidx],vals[bidx]
                        pg=op(d,pa,pb,A9)
                        proj=dict(zip(seq,vals));proj[g1]=pg
                        wanted={proj[s] for s in S}
                        mass=sum(proj[s] in [0,A9] for s in S)
                        base={0,A9,*Q,*[A9^q for q in Q]}
                        bp=9
                        for mask in range(4):
                            bank=set(base);cost=0
                            if mask&1:
                                if pq not in bank:cost+=1
                                bank.update([pq,A9^pq])
                            if mask&2:
                                if pg not in bank and not(pa in bank and pb in bank):continue
                                if pg not in bank:cost+=1
                                bank.update([pg,A9^pg])
                            if wanted<=bank:bp=min(bp,cost)
                        assert bp<=2
                        bound=17+mass-bp
                        data.append((bound,i,mass,bp))
                        best=max(best,bound)
                    counts[str(best)]+=1
                    if best<18:survivors.append({'a':aidx,'b':bidx,'op':d,'keep_a':ka,'keep_b':kb,'size':len(S),'best':best,'projection':max(data)})
    result={'first_or':edge,'counts':dict(counts),'survivors':survivors}
    summaries.append(result)
    print(edge,dict(counts),'survivors',len(survivors))
    classes=Counter((r['a']==10 or r['b']==10,r['op'],r['keep_a'],r['keep_b']) for r in survivors)
    print('survivor_classes',dict(classes))
Path('/tmp/oec/pequalnp-pilot-102/or_case/prefix2-results.json').write_text(json.dumps(summaries,indent=2))
