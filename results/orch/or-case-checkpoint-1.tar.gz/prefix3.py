import runpy,json,itertools,time
from pathlib import Path
from collections import Counter
D=runpy.run_path('/tmp/oec/pequalnp-pilot-102/or_case/prefix2.py')
P,T,ALL,PROJ,A9,op=D['P'],D['T'],D['ALL'],D['PROJ'],D['A9'],D['op']
start=time.monotonic()
pairs=[(0,1),(2,3),(0,4),(1,2),(3,4),(2,4),(1,4),(1,3),(0,3),(0,2)]
lookup={frozenset(p):i for i,p in enumerate(pairs)}
auts=[]
for pm in itertools.permutations(range(5)):
    auts.append(tuple(lookup[frozenset([pm[a],pm[b]])] for a,b in pairs))
def values(prefix):
    seq=list(P)
    for a,b,d in prefix:seq.append(op(d,seq[a],seq[b]))
    return seq
def canonical(prefix,ids,syms):
    best=None;answer=None
    for au in syms:
        pp=[(au[a] if a<10 else a,au[b] if b<10 else b,d) for a,b,d in prefix]
        ii=[au[i] if i<10 else i for i in ids]
        seq=values(pp)
        key=tuple(sorted(seq[i] for i in ii))
        if best is None or key<best:
            best=key;answer=(pp,ii)
    return best,answer
def collision(seq,ids):
    raw={i for i in ids if i<10}
    mask=sum(1<<i for i in raw)
    if mask==1023:return None
    extra=[seq[i] for i in ids if i>=10]
    seen={}
    for r in range(1024):
        key=(r&mask)|sum(((g>>r)&1)<<(10+j) for j,g in enumerate(extra))
        t=T>>r&1
        if key in seen and seen[key][1]!=t:return(seen[key][0],r)
        seen[key]=(r,t)
    return None
def bound(prefix,ids):
    k=len(prefix);best=(k+len(ids)-1,-1,0,0,0)
    for i,Q in enumerate(PROJ):
        seq=list(Q)
        for a,b,d in prefix:seq.append(op(d,seq[a],seq[b],A9))
        needed={seq[j] for j in ids}
        mass=sum(seq[j] in [0,A9] for j in ids)
        base={0,A9,*Q,*[A9^q for q in Q]}
        bp=k+1;bm=-1
        for mask in range(1<<k):
            bank=set(base);cost=0;valid=True
            for j,(a,b,d) in enumerate(prefix):
                if not mask>>j&1:continue
                g=seq[10+j]
                if g not in bank:
                    if not(seq[a] in bank and seq[b] in bank):valid=False;break
                    cost+=1
                bank.update([g,A9^g])
            if valid and needed<=bank and cost<bp:bp,bm=cost,mask
        assert bp<=k
        test=(k+15+mass-bp,i,bm,mass,bp)
        if test[0]>best[0]:best=test
    return best
results=[]
for first in json.loads(Path('/tmp/oec/pequalnp-pilot-102/or_case/prefix2-results.json').read_text()):
    j=1 if first['first_or']=='edge' else 2
    syms=[a for a in auts if {a[0],a[j]}=={0,j}]
    parents={}
    for r in first['survivors']:
        pp=[(0,j,1),(r['a'],r['b'],r['op'])]
        ids=list(range(11))
        if not r['keep_a']:ids.remove(r['a'])
        if not r['keep_b']:ids.remove(r['b'])
        ids.append(11)
        key,node=canonical(pp,ids,syms);parents.setdefault(key,node)
    print('BEGIN',first['first_or'],'symmetries',len(syms),'parents',len(parents),flush=True)
    counts=Counter();survivors={};records=[]
    for ni,(prefix,ids) in enumerate(parents.values()):
        seq=values(prefix);S={seq[i] for i in ids};codes=[]
        for a,b in itertools.combinations(sorted(ids),2):
            for d in range(4):
                g=op(d,seq[a],seq[b])
                if g in S or g in [0,ALL]:
                    codes.extend([0]*4);counts['invalid']+=4;continue
                for ka in [False,True]:
                    for kb in [False,True]:
                        nn=list(ids)
                        if not ka:nn.remove(a)
                        if not kb:nn.remove(b)
                        nn.append(12)
                        pp=prefix+[(a,b,d)]
                        ss=seq+[g]
                        bad=collision(ss,nn)
                        if bad is not None:
                            counts['inconsistent']+=1;codes.append(1+4*(bad[0]*1024+bad[1]));continue
                        bb=bound(pp,nn)
                        counts[str(bb[0])]+=1
                        if bb[0]>=18:
                            codes.append(2+4*((bb[1]+1)*8+bb[2]));continue
                        key,node=canonical(pp,nn,syms)
                        if key not in survivors:survivors[key]=(len(survivors),node)
                        codes.append(3+4*survivors[key][0])
        records.append({'prefix':prefix,'ids':ids,'codes':codes})
        print('parent',ni+1,'of',len(parents),'states',sum(counts.values()),'survivors',len(survivors),'elapsed',round(time.monotonic()-start,2),flush=True)
    result={'first_or':first['first_or'],'counts':dict(counts),'parents':records,'survivors':[{'prefix':v[1][0],'ids':v[1][1]} for v in survivors.values()]}
    results.append(result)
    print('DONE',first['first_or'],dict(counts),'unique_survivors',len(survivors),flush=True)
Path('/tmp/oec/pequalnp-pilot-102/or_case/prefix3-results.json').write_text(json.dumps(results,separators=(',',':')))
print('COMPLETE',round(time.monotonic()-start,2),flush=True)
