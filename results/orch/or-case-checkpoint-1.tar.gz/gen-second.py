from pathlib import Path
import re,json
s=Path('lean/PEqualNP/Outside/L_meta_2592.lean').read_text().split('namespace Extended',1)[1]
pins=[int(z,16)for z in re.findall(r'0x[0-9a-f]+',re.search(r'def pins : List Sig := (.*)',s).group(1))]
target=int(re.search(r'def target : Sig := (0x[0-9a-f]+)',s).group(1),16)
pos=[9,7,5,8,6,4,2,0,3,1]
assert len(pins)==10
assert all(pins[i]==sum(1<<r for r in range(1024)if r>>pos[i]&1)for i in range(10))
E=[(0,1),(1,2),(2,3),(3,4),(4,0),(0,5),(1,6),(2,7),(3,8),(4,9),(5,7),(7,9),(9,6),(6,8),(8,5)]
nb=[{b for a,b in E if a==i}|{a for a,b in E if b==i}for i in range(10)]
raw=[];qr=[]
for c in range(10):
 for j in range(10):
  for inv in [False,True]:
   if c==j:raw.append(0);continue
   if not inv:r=1<<pos[next(h for h in sorted(nb[c])if h!=j)]
   else:
    h=next(h for h in sorted(nb[c])if h==j or j not in nb[h])
    r=(1<<pos[j])|(1<<pos[h])
   rr=r|(1<<pos[c]);assert not(r>>pos[c]&1)
   assert (target>>r&1)!=(target>>rr&1)
   def val(row):return (pins[c]>>row&1)&((1-(pins[j]>>row&1))if inv else(pins[j]>>row&1))
   assert val(r)==val(rr)
   raw.append(r)
for a in range(10):
 for b in range(10):
  for c in range(10):
   if c in[a,b]:qr.append(0);continue
   h=next(h for h in sorted(nb[c])if h not in[a,b])
   r=1<<pos[h];rr=r|(1<<pos[c])
   assert (target>>r&1)!=(target>>rr&1)
   q=pins[a]|pins[b]
   assert((pins[c]&q)>>r&1)==((pins[c]&q)>>rr&1)
   qr.append(r)
Path('/tmp/oec/pequalnp-pilot-102/or_case/second-witness-data.json').write_text(json.dumps({'raw':raw,'q':qr}))
header='''import PEqualNP.Outside.L_meta_2592

namespace PEqualNP.Outside.L_meta_2592
namespace SecondGate

open Floor17

def orPin (a b : Fin 10) : Extended.Sig := Extended.bin 1 (pin a) (pin b)

def gate (negative : Bool) (c : Fin 10) (v : Extended.Sig) : Extended.Sig :=
  Extended.bin (if negative then 2 else 0) (pin c) v

'''
header+='def rawData : List Nat := '+str(raw).replace(' ','')+'\n\n'
header+='def orData : List Nat := '+str(qr).replace(' ','')+'\n\n'
Path('results/orch/lemmas/SecondGate.lean').write_text(header)
print('witnesses checked',len(raw),len(qr))
