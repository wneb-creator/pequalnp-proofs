from pathlib import Path
import json,importlib.util,collections,hashlib,time
BASE=Path('/tmp/oec/pequalnp-pilot-10')
SRC=BASE/'independent-search/984/compact'
OUT=BASE/'independent-search/984/direct'
OUT.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('reviewed_chd',BASE/'fresh-full-proof/meta984/chd.py');chd=importlib.util.module_from_spec(spec);spec.loader.exec_module(chd)
def pack(xs,bits):return sum(x<<(bits*i) for i,x in enumerate(xs))
def field(x,bits,i):return (x>>(bits*i))&((1<<bits)-1)
def hk(ws):return sum((w+317)**3+1 for w in ws)%4294967291
helpers='''def qDirectInputs (bits : Nat) : Nat → List Nat → List Nat
  | _, [] => []
  | record, x :: xs => List.replicate (record &&& (2^bits-1)) x ++
      qDirectInputs bits (record >>> bits) xs

def qDirectOther (values valueBits indexBits : Nat) : Nat → Nat → List Nat
  | 0, _ => []
  | n+1, record =>
    let index := record &&& (2^indexBits-1)
    let rest := qDirectOther values valueBits indexBits n (record >>> indexBits)
    if index = 0 then rest else fld values valueBits (index-1) :: rest

def qDirectState (initial : List Nat) (countBits valueBits indexBits slots values record : Nat) : List Nat :=
  qDirectInputs countBits record initial ++
    qDirectOther values valueBits indexBits slots (record >>> (countBits * initial.length))
'''
(OUT/'helpers.fragment.lean').write_text(helpers)
def case_def(name,values):
 return f'def {name} : Nat → Nat\n'+''.join(f'  | {s} => {hex(v) if v>1000 else v}\n' for s,v in sorted(values.items()) if v)+ '  | _ => 0\n'
started=time.monotonic();summary=[]
for graph in [28]+[i for i in range(31) if i!=28]:
 meta=json.loads((SRC/f'compact{graph}.meta.json').read_text());name=f'C{graph}';cap=meta['budget'];wordbits=meta['width']
 initial=sorted(int(w,16) for w in meta['inputs_hex']);inputset=set(initial)
 states={s:[tuple(int(w,16) for w in json.loads(line)) for line in (SRC/f'compact{graph}.layer{s}.jsonl').read_text().splitlines()] for s in range(cap+1)}
 noninputs=sorted({w for rows in states.values() for ws in rows for w in ws}-inputset)
 nonindex={w:j+1 for j,w in enumerate(noninputs)};indexbits=max(1,len(noninputs).bit_length());values=pack(noninputs,wordbits)
 assert all(field(values,wordbits,j)==w for j,w in enumerate(noninputs))
 data={'graph':graph,'name':name,'cap':cap,'word_bits':wordbits,'dictionary_index_bits':indexbits,'initial':initial,'noninputs':noninputs,'packed_values_hex':hex(values),'goal':meta['goal'],'layers':{}}
 params={n:{} for n in ['N','countBits','slots','recordBits','records','buckets','flag','seedBits','seeds']};reordered={}
 for s,rows in states.items():
  if not rows:continue
  keys=[hk(ws) for ws in rows];assert len(set(keys))==len(keys)
  table=chd.build(keys)
  reordered[s]=[None]*len(rows)
  for ws,j in zip(rows,table['positions']):reordered[s][j]=ws
  maxdup=max(max(collections.Counter(w for w in ws if w in inputset).values(),default=0) for ws in rows)
  countbits=max(1,maxdup.bit_length());assert countbits<=2
  slots=max(sum(w not in inputset for w in ws) for ws in rows)
  recordbits=countbits*len(initial)+indexbits*slots
  records=[]
  for ws in reordered[s]:
   counts=collections.Counter(ws)
   inputrecord=pack([counts[w] for w in initial],countbits)
   otherindices=[nonindex[w] for w in ws if w not in inputset]
   record=inputrecord+(pack(otherindices,indexbits)<<(countbits*len(initial)))
   records.append(record)
   decoded=[w for j,w in enumerate(initial) for _ in range(field(record,countbits,j))]
   remainder=record>>(countbits*len(initial))
   decoded += [field(values,wordbits,i-1) for j in range(slots) if (i:=field(remainder,indexbits,j))]
   assert sorted(decoded)==list(ws)
  packedrecords=pack(records,recordbits);packedseeds=pack(table['codes'],table['bits'])
  for j,ws in enumerate(reordered[s]):
   assert field(packedrecords,recordbits,j)==records[j]
   h=hk(ws);code=field(packedseeds,table['bits'],h%table['buckets'])
   actual=code-table['flag'] if code>=table['flag'] else chd.mix(h,code,len(rows))
   assert actual==j
  layer={'N':len(rows),'countBits':countbits,'slots':slots,'recordBits':recordbits,'records':packedrecords,'buckets':table['buckets'],'flag':table['flag'],'seedBits':table['bits'],'seeds':packedseeds}
  for key,val in layer.items():params[key][s]=val
  data['layers'][s]={key:hex(val) if key in ['records','seeds'] else val for key,val in layer.items()}
  (OUT/f'C{graph}.layer{s}.jsonl').write_text(''.join(json.dumps([hex(w)[2:] for w in ws],separators=(',',':'))+'\n' for ws in reordered[s]))
 fragments=[f'def {name}_initial : List Nat := ['+', '.join(hex(w) for w in initial)+']\n',f'def {name}_values : Nat := {hex(values)}\n']
 fragments += [case_def(name+'_'+key,vals) for key,vals in params.items()]
 fragments.append(f'def {name}_S (s j : Nat) : List Nat :=\n  qDirectState {name}_initial ({name}_countBits s) {wordbits} {indexbits} ({name}_slots s) {name}_values\n    (fld ({name}_records s) ({name}_recordBits s) j)\n')
 fragments.append(f'def {name}_idx : Nat → List Nat → Nat :=\n  qIndex {name}_N {name}_buckets {name}_flag {name}_seedBits {name}_seeds\n')
 text='\n'.join(fragments)
 path=OUT/f'C{graph}.data.fragment.lean';path.write_text(text)
 (OUT/f'C{graph}.data.json').write_text(json.dumps(data,indent=2)+'\n')
 # This concrete checked decoder claim is independent of coverage and orbit integration.
 benchmark_s=8 if graph==28 else max(s for s,n in params['N'].items() if n>1)
 decoded_target=reordered[benchmark_s][0]
 diag=f'theorem {name}_decoder_diagnostic : (qNorm ({name}_S {benchmark_s} 0)) = ['+', '.join(hex(w) for w in decoded_target)+'] := by decide +kernel\n'
 (OUT/f'C{graph}.decoder.fragment.lean').write_text(diag)
 stat={'graph':graph,'states':sum(len(x) for x in states.values()),'bytes':len(text.encode()),'sha256':hashlib.sha256(text.encode()).hexdigest(),'noninput_values':len(noninputs),'max_count_bits':max(params['countBits'].values()),'literal_record_hexbytes':sum(len(hex(v))-2 for v in params['records'].values()),'literal_seed_hexbytes':sum(len(hex(v))-2 for v in params['seeds'].values()),'dictionary_hexbytes':len(hex(values))-2}
 summary.append(stat);print(json.dumps(stat),flush=True)
(OUT/'summary.json').write_text(json.dumps(sorted(summary,key=lambda x:x['graph']),indent=2)+'\n')
print(json.dumps({'status':'PASS','graphs':31,'states':sum(x['states'] for x in summary),'total_data_bytes':sum(x['bytes'] for x in summary),'helpers_bytes':len(helpers.encode()),'seconds':time.monotonic()-started}),flush=True)
