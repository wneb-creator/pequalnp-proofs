from pathlib import Path
import collections,json,hashlib,itertools,time,re
BASE=Path('/tmp/oec/pequalnp-pilot-10/independent-search/984')
SRC=BASE/'direct';OUT=BASE/'direct_v2';OUT.mkdir(exist_ok=True)
def pack(xs,bits):return sum(x<<(i*bits) for i,x in enumerate(xs))
def fld(x,bits,i):return (x>>(bits*i))&((1<<bits)-1)
def cases(name,vals):return f'def {name} : Nat → Nat\n'+''.join(f'  | {s} => {hex(v) if v>1000 else v}\n' for s,v in sorted(vals.items()) if v)+'  | _ => 0\n'
helpers=(SRC/'helpers.fragment.lean').read_text()
helpers=helpers+'''def qDirectStatePattern (initial : List Nat)
    (countBits patternBits patterns valueBits indexBits slots values record : Nat) : List Nat :=
  let headerBits := if patternBits = 0 then countBits * initial.length else patternBits
  let inputBits := if patternBits = 0 then countBits else 2
  let inputRecord := if patternBits = 0 then record else
    fld patterns (2 * initial.length) (record &&& (2^patternBits-1))
  qDirectInputs inputBits inputRecord initial ++
    qDirectOther values valueBits indexBits slots (record >>> headerBits)
'''
(OUT/'helpers.fragment.lean').write_text(helpers)
started=time.monotonic();summary=[]
for graph in [28]+[x for x in range(31) if x!=28]:
 data=json.loads((SRC/f'C{graph}.data.json').read_text());name=f'C{graph}';keys=data['initial'];keyset=set(keys);layers={}
 for ss,l in data['layers'].items():
  s=int(ss);rows=[tuple(int(w,16) for w in json.loads(line)) for line in (SRC/f'C{graph}.layer{s}.jsonl').read_text().splitlines()]
  patterns=[sum(collections.Counter(ws)[w]<<(2*j) for j,w in enumerate(keys)) for ws in rows]
  layers[s]=(l,rows,patterns)
 nonempty=list(layers);best_gain=0;best_layers=[];best_patterns=[];best_bits=0
 # At most a handful of occupied layers, permitting exact choice of shared pattern dictionary.
 for mask in range(1,1<<len(nonempty)):
  selected=[s for j,s in enumerate(nonempty) if (mask>>j)&1]
  patterns=sorted(set().union(*(set(layers[s][2]) for s in selected)))
  bits=max(1,(len(patterns)-1).bit_length())
  gain=sum(layers[s][0]['N']*(layers[s][0]['countBits']*len(keys)-bits) for s in selected)-2*len(keys)*len(patterns)
  if gain>best_gain:best_gain,best_layers,best_patterns,best_bits=gain,selected,patterns,bits
 pattern_ids={p:j for j,p in enumerate(best_patterns)};pattern_data=pack(best_patterns,2*len(keys))
 params={n:{} for n in ['N','countBits','patternBits','slots','recordBits','records','buckets','flag','seedBits','seeds']}
 for s,(l,rows,patterns) in layers.items():
  use=s in best_layers;headerbits=best_bits if use else l['countBits']*len(keys)
  recordbits=headerbits+data['dictionary_index_bits']*l['slots']
  records=[]
  for j,ws in enumerate(rows):
   old=fld(int(l['records'],0),l['recordBits'],j)
   others=old>>(l['countBits']*len(keys))
   header=pattern_ids[patterns[j]] if use else old&((1<<(l['countBits']*len(keys)))-1)
   record=header+(others<<headerbits);records.append(record)
   inputrecord=fld(pattern_data,2*len(keys),header) if use else header
   inputbits=2 if use else l['countBits']
   decoded=[w for q,w in enumerate(keys) for _ in range(fld(inputrecord,inputbits,q))]
   decoded += [data['noninputs'][index-1] for q in range(l['slots']) if (index:=fld(others,data['dictionary_index_bits'],q))]
   assert sorted(decoded)==list(ws)
  newlayer=dict(l);newlayer['patternBits']=best_bits if use else 0;newlayer['recordBits']=recordbits;newlayer['records']=hex(pack(records,recordbits))
  data['layers'][str(s)]=newlayer
  for key,val in newlayer.items():params[key][s]=int(val,0) if isinstance(val,str) else val
 data['pattern_codes']=best_patterns;data['packed_patterns_hex']=hex(pattern_data);data['pattern_layers']=best_layers
 data['pattern_index_bits']=best_bits
 fragments=[f'def {name}_initial : List Nat := ['+', '.join(hex(w) for w in keys)+']\n',f'def {name}_values : Nat := '+data['packed_values_hex']+'\n',f'def {name}_patterns : Nat := '+hex(pattern_data)+'\n']
 fragments += [cases(name+'_'+key,vals) for key,vals in params.items()]
 fragments.append(f'def {name}_S (s j : Nat) : List Nat :=\n  qDirectStatePattern {name}_initial ({name}_countBits s) ({name}_patternBits s) {name}_patterns {data["word_bits"]} {data["dictionary_index_bits"]} ({name}_slots s) {name}_values\n    (fld ({name}_records s) ({name}_recordBits s) j)\n')
 fragments.append(f'def {name}_idx : Nat → List Nat → Nat :=\n  qIndex {name}_N {name}_buckets {name}_flag {name}_seedBits {name}_seeds\n')
 text='\n'.join(fragments)
 oldtext=(SRC/f'{name}.data.fragment.lean').read_text()
 if len(text.encode())>=len(oldtext.encode()):
  text=oldtext;data=json.loads((SRC/f'{name}.data.json').read_text());best_patterns=[];best_bits=0;best_layers=[]
 path=OUT/f'{name}.data.fragment.lean';path.write_text(text)
 (OUT/f'{name}.data.json').write_text(json.dumps(data,indent=2)+'\n')
 (OUT/f'{name}.decoder.fragment.lean').write_text((SRC/f'{name}.decoder.fragment.lean').read_text())
 (OUT/f'{name}.aux.fragment.lean').write_text((SRC/f'{name}.aux.fragment.lean').read_text())
 oldbytes=(SRC/f'{name}.data.fragment.lean').stat().st_size
 stat={'graph':graph,'bytes':len(text.encode()),'saved_bytes':oldbytes-len(text.encode()),'patterns':len(best_patterns),'pattern_bits':best_bits,'pattern_layers':best_layers,'sha256':hashlib.sha256(text.encode()).hexdigest()}
 summary.append(stat);print(json.dumps(stat),flush=True)
(OUT/'summary.json').write_text(json.dumps(sorted(summary,key=lambda x:x['graph']),indent=2)+'\n')
print(json.dumps({'status':'PASS','data_bytes':sum(x['bytes'] for x in summary),'saved_bytes':sum(x['saved_bytes'] for x in summary),'helpers_bytes':len(helpers.encode()),'seconds':time.monotonic()-started}),flush=True)
