from pathlib import Path
import json,hashlib,time,math
BASE=Path('/tmp/oec/pequalnp-pilot-10')
SRC=BASE/'proof-strategy/meta984'
OUT=BASE/'independent-search/984/compact'
OUT.mkdir(exist_ok=True)
DISCOVERED=set((BASE/'independent-search/984/compact-source-files.txt').read_text().splitlines())

def read(path):
 assert str(path) in DISCOVERED,path
 return path.read_text()

def embed(mask,color):return sum(((mask>>i)&1)<<(2*i+color) for i in range(mask.bit_length()))
def network(perm):
 n=len(perm)
 if n==1:return []
 if n==2:return [(1,int(perm[0]==1))]
 inv=[0]*n
 for i,j in enumerate(perm):inv[j]=i
 color=[-1]*n
 for seed in range(n):
  if color[seed]>=0:continue
  color[seed]=0;stack=[seed]
  while stack:
   i=stack.pop()
   for j in (i^1,inv[perm[i]^1]):
    want=1-color[i]
    if color[j]<0:color[j]=want;stack.append(j)
    else:assert color[j]==want
 first=sum(color[2*j]<<(2*j) for j in range(n//2))
 last=sum(color[inv[2*j]]<<(2*j) for j in range(n//2))
 sub=[]
 for c in [0,1]:
  sub.append(network([perm[2*j if color[2*j]==c else 2*j+1]//2 for j in range(n//2)]))
 return [(1,first)]+[(2*d,embed(a,0)|embed(b,1)) for (d,a),(e,b) in zip(sub[0],sub[1]) if d==e]+[(1,last)]
def apply(network,w):
 for d,lo in network:
  swap=((w>>d)^w)&lo;w^=swap^(swap<<d)
 return w

def write_json(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
summary=[];started=time.monotonic()
for graph in [28]+[i for i in range(31) if i!=28]:
 source=SRC/f'quotient{graph}.meta.json';meta=json.loads(read(source));k=meta['k'];cap=meta['budget']
 negatives=list(dict.fromkeys(meta['negative_rows']));positives=list(dict.fromkeys(meta['positive_rows']))
 P=len(negatives);E=len(positives);width=P+E
 assert k==P*E and meta['negative_rows']==[x for x in negatives for _ in positives]
 assert meta['positive_rows']==positives*P
 def compact(w):return sum(((w>>(i*E))&1)<<i for i in range(P))+sum(((w>>(k+j))&1)<<(P+j) for j in range(E))
 def expand(w):
  return sum((((1<<E)-1) if (w>>i)&1 else 0)<<(i*E) for i in range(P)) + ((w>>P)*sum(1<<(E*i) for i in range(P))<<k)
 def coordinate(j):
  assert 0<=j<2*k
  return j//E if j<k else P+(j-k)%E
 goal=((1<<E)-1)<<P
 compactinputs=[compact(int(w,16)) for w in meta['inputs_hex']]
 inverse=[];permutations=[];routes=[]
 for auto,oldinv in enumerate(meta['row_inverse_perms']):
  inv=[oldinv[i*E]//E for i in range(P)]+[P+oldinv[j]%E for j in range(E)]
  assert sorted(inv)==list(range(width))
  forward=[0]*width
  for d,s in enumerate(inv):forward[s]=d
  inverse.append(inv);permutations.append(forward)
  padded=forward+list(range(width,32));net=network(padded)
  assert [d for d,_ in net]==[1,2,4,8,16,8,4,2,1]
  for sourcebit,destbit in enumerate(padded):assert apply(net,1<<sourcebit)==1<<destbit
  assert apply(net,goal)==goal
  routes.append({'auto':auto,'lo_hex':[hex(lo) for d,lo in net]})
 def action(w,auto):return sum(((w>>sourcebit)&1)<<destbit for destbit,sourcebit in enumerate(inverse[auto]))
 layers={};parents={};allwide=set();counts={};totalwireoccurrences=0
 for s in range(cap+1):
  path=SRC/f'quotient{graph}.layer{s}.jsonl'
  wide=[tuple(int(w,16) for w in json.loads(line)) for line in read(path).splitlines()]
  states=[]
  for ws in wide:
   cs=tuple(compact(w) for w in ws)
   assert all(expand(c)==w for c,w in zip(cs,ws)),(graph,s,'roundtrip')
   assert cs==tuple(sorted(cs)),(graph,s,'order')
   assert cs==min(tuple(sorted(action(w,a) for w in cs)) for a in range(len(inverse))),(graph,s,'canonical')
   states.append(cs);allwide.update(ws);totalwireoccurrences+=len(ws)
  layers[s]=states;counts[str(s)]=len(states)
  (OUT/f'compact{graph}.layer{s}.jsonl').write_text(''.join(json.dumps([hex(w)[2:] for w in ws],separators=(',',':'))+'\n' for ws in states))
  parentpath=SRC/f'quotient{graph}.parents{s}.jsonl'
  if str(parentpath) in DISCOVERED:
   text=read(parentpath);parents[s]=[json.loads(line) for line in text.splitlines()]
   assert len(parents[s])==len(states)
   (OUT/f'compact{graph}.parents{s}.jsonl').write_text(text)
 # Global order checks preserve qNorm and orbit-canonical selection for arbitrary intermediate wires
 # from these frontiers, not only the stored lists.
 wides=sorted(allwide);compacts=[compact(w) for w in wides]
 assert compacts==sorted(compacts) and len(set(compacts))==len(wides)
 assert all(expand(w)==old for old,w in zip(wides,compacts))
 for auto,oldinv in enumerate(meta['row_inverse_perms']):
  fullinv=oldinv+[k+x for x in oldinv]
  for old,w in zip(wides,compacts):
   wideaction=sum(((old>>src)&1)<<dest for dest,src in enumerate(fullinv))
   assert compact(wideaction)==action(w,auto)
 for s,ps in parents.items():
  for j,p in enumerate(ps):
   if p['kind']==0:assert s==cap and list(layers[s][j])==sorted(compactinputs);continue
   ws=list(layers[s+1][p['parent']])
   if p['kind']==1:raw=ws
   elif p['kind']==2:raw=[ws[p['a']]]+ws
   else:
    assert p['kind']==3
    a,b=p['a'],p['b'];x,y=ws[a],ws[b]
    w=x&y if p['op']==0 else x|y
    raw=[w]+([x] if p['keep']&1 else [])+([y] if p['keep']&2 else [])+[v for z,v in enumerate(ws) if z not in [a,b]]
   assert tuple(sorted(action(w,p['auto']) for w in raw))==layers[s][j],(graph,s,j,'parent')
 newmeta={'graph':graph,'budget':cap,'source_k':k,'k':k,'encoding':'unique negative rows followed by unique positive rows; k retained only as source paired-encoding metadata, not a compact goal parameter','negative_count':P,'positive_count':E,'width':width,'goal':goal,'goal_hex':hex(goal),'coordinate_rows':negatives+positives,'negative_rows':negatives,'positive_rows':positives,'inputs_hex':[hex(w)[2:] for w in compactinputs],'vertex_perms':meta['vertex_perms'],'group':len(inverse),'bit_inverse_perms':inverse,'bit_perms':permutations,'row_inverse_perms':inverse,'row_perms':permutations,'row_schema':'full compact width; source bit index for each destination bit in bit_inverse_perms','orientation':'lexicographic_minimum_sorted_multiset','score_order':'coverage_then_orientation_then_score','source_meta_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'states':counts}
 write_json(OUT/f'compact{graph}.meta.json',newmeta)
 write_json(OUT/f'routes{graph}.json',{'graph':graph,'width':32,'encoding_width':width,'goal':goal,'distances':[1,2,4,8,16,8,4,2,1],'padding':'fixed','networks':routes})
 # Existing rank codes remain valid because all chosen coordinate representatives map injectively.
 fast=json.loads((BASE/f'independent-search/984/fast_pool_{graph}.json').read_text())
 fast['source_coordinate_array']=fast['coordinate_array'];fast['coordinate_array']=[coordinate(j) for j in fast['coordinate_array']]
 assert fast['coordinate_array']==sorted(set(fast['coordinate_array']))
 oldcodes=fast['original_score_codes'];newcodes=[]
 for code in oldcodes:
  cs=[coordinate((code>>(10*i))&1023) for i in range(6)]
  newcodes.append(sum(c<<(10*i) for i,c in enumerate(cs)))
 fast['original_score_codes']=newcodes;fast['goal']=goal;fast['negative_count']=P;fast['positive_count']=E
 write_json(OUT/f'fast_pool_{graph}.json',fast)
 (OUT/f'pool{graph}.txt').write_text('\n'.join(str(x) for x in newcodes)+'\n')
 # Uncompressed state-table lower bounds, with and without omission of known original inputs.
 universe=sorted(set(compacts));indexbits=max(1,(len(universe)-1).bit_length());inputset=set(compactinputs)
 noninput=sorted(set(universe)-inputset);nibits=max(1,(len(noninput)-1).bit_length());nonocc=sum(sum(w not in inputset for w in ws) for states in layers.values() for ws in states)
 fullbits=totalwireoccurrences*indexbits
 inputmaskbits=len(compactinputs)*sum(counts.values())+nonocc*nibits
 stat={'graph':graph,'negative_count':P,'positive_count':E,'width':width,'states':sum(counts.values()),'wire_occurrences':totalwireoccurrences,'unique_wires':len(universe),'wire_index_bits':indexbits,'packed_fullstate_bits':fullbits,'noninput_unique_wires':len(noninput),'noninput_occurrences':nonocc,'input_mask_plus_noninput_indices_bits':inputmaskbits,'source_layers_and_parent_ids_preserved':True}
 summary.append(stat);write_json(OUT/f'compact{graph}.summary.json',stat)
 print(json.dumps(stat),flush=True)
write_json(OUT/'summary.json',sorted(summary,key=lambda x:x['graph']))
print(json.dumps({'status':'PASS','graphs':31,'states':sum(x['states'] for x in summary),'seconds':time.monotonic()-started,'fullstate_index_hex_bytes_lowerbound':sum((x['packed_fullstate_bits']+3)//4 for x in summary),'input_mask_noninput_hex_bytes_lowerbound':sum((x['input_mask_plus_noninput_indices_bits']+3)//4 for x in summary)}),flush=True)
