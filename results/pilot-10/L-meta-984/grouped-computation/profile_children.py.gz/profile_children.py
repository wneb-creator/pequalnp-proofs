from pathlib import Path
import json,collections,hashlib
BASE=Path('/tmp/oec/pequalnp-pilot-10/independent-search/984')
meta=json.loads((BASE/'compact/compact28.meta.json').read_text());fast=json.loads((BASE/'compact/fast_pool_28.json').read_text());data=json.loads((BASE/'direct_v3/C28.data.json').read_text())
P,E=meta['negative_count'],meta['positive_count'];goal=meta['goal']
inputs=[0x792,0x94c,0xf92,0x18a1,0x2468,0x6205,0x900e,0xc070]
def erase(xs,x):
 out=xs.copy();out.remove(x);return out
def children(ws):
 out=[]
 for ai,a in enumerate(ws):
  ra=erase(ws,a)
  out.append({'kind':'one','a_position':ai,'a':a,'values':[a]+ra})
  for bi,b in enumerate(ra):
   if a>b:continue
   rest=erase(ra,b)
   for conj in [False,True]:
    w=a&b if conj else a|b
    for keep in ['none','a','b']:
     child=[w]+([] if keep=='none' else [a if keep=='a' else b])+rest
     out.append({'kind':'and' if conj else 'or','a_position':ai,'b_position_in_ra':bi,'a':a,'b':b,'keep':keep,'values':child})
 return out
def coverage(ws):return all(any(((w>>j)&1)==0 and ((w>>(P+i))&1)==1 for w in ws) for j in range(P) for i in range(E))
def act(w,a):return sum(((w>>source)&1)<<dest for dest,source in enumerate(meta['bit_inverse_perms'][a]))
def ori(ws):
 # Exact orbitActions with ascending actionlist1..group-1 and original list as base.
 other=ws
 for a in reversed(range(1,meta['group'])):
  candidate=[act(w,a) for w in ws]
  if sorted(candidate)<=sorted(other):other=candidate
 return other
def v6(bs):
 a,b,c,d,e,f=bs;x=b+c;y=2-e-f
 return (y if d else max(x,y,max(0,x+y-1))) if a else (0 if d else x)
def score(ws):
 if len(ws)!=8 or len(ws)>12:return False,[]
 sums=[]
 for code in fast['rank_codes']:
  coordinates=[fast['coordinate_array'][(code>>(fast['rank_width']*j))&((1<<fast['rank_width'])-1)] for j in range(6)]
  sums.append(sum(v6([(w>>j)&1 for j in coordinates]) for w in ws))
 return any(x<3 for x in sums),sums
layer=data['layers']['7']
def fld(x,bits,index):return (x>>(bits*index))&((1<<bits)-1)
def hk(ws):return sum(((w%11400714819323198549+317)**3)%11400714819323198549+1 for w in ws)%4294967291
def index(ws):
 h=hk(ws);code=fld(int(layer['seeds'],0),layer['seedBits'],h%layer['buckets'])
 return code-layer['flag'] if code>=layer['flag'] else pow(h+code+317,3,11400714819323198549)%layer['N']
def state(s,j):
 l=data['layers'][str(s)];record=fld(int(l['record_blocks_hex'][j//256],0),l['recordBits'],j%256)
 pb=l.get('patternBits',0);cb=l['countBits'];headbits=pb if pb else cb*len(data['initial'])
 pattern=fld(int(data['packed_patterns_hex'],0),2*len(data['initial']),record&((1<<pb)-1)) if pb else record
 usedbits=2 if pb else cb
 ws=[w for k,w in enumerate(data['initial']) for _ in range(fld(pattern,usedbits,k))]
 other=record>>headbits
 ws += [data['noninputs'][idx-1] for k in range(l['slots']) if (idx:=fld(other,data['dictionary_index_bits'],k))]
 return ws
actual=state(8,2358);assert sorted(actual)==inputs
result={'scope':'Computational exact candidate decomposition of next slack1. Candidate order and duplicate occurrences retained; no new Lean proof.','graph':28,'current_steps':8,'next_steps':7,'slack':1,'sorted_initial':inputs,'actual_direct_initial':actual,'cases':{}}
for label,ws in [('sorted',inputs),('actual_direct',actual)]:
 allc=children(ws);covered=[];scored=[];survivors=[]
 for ordinal,c in enumerate(allc):
  c['ordinal']=ordinal;c['coverage']=coverage(c['values'])
  if not c['coverage']:continue
  c['canonical_values']=ori(c['values']);assert coverage(c['canonical_values'])
  c['score_rejected'],c['score_sums']=score(c['canonical_values'])
  covered.append(ordinal)
  if c['score_rejected']:scored.append(ordinal)
  else:
   j=index(c['canonical_values']);c['lookup_index']=j
   c['found']=j<layer['N'] and sorted(c['canonical_values'])==sorted(state(7,j))
   assert c['found'],(label,ordinal,j)
   survivors.append(ordinal)
 counts={'raw':len(allc),'covered':len(covered),'score_rejected':len(scored),'survivors':len(survivors),'survivor_found_true':len(survivors),'unique_raw_multisets':len({tuple(sorted(c['values'])) for c in allc})}
 result['cases'][label]={'counts':counts,'candidates':allc,'covered_ordinals':covered,'score_rejected_ordinals':scored,'survivor_ordinals':survivors,'covered_literals':[allc[j]['values'] for j in covered],'canonical_covered_literals':[allc[j]['canonical_values'] for j in covered],'survivor_literals':[allc[j]['canonical_values'] for j in survivors]}
 print(label,json.dumps(counts),flush=True)
assert result['cases']['sorted']['counts']==result['cases']['actual_direct']['counts']
(BASE/'matched28-component-inputs.json').write_text(json.dumps(result,indent=2)+'\n')
