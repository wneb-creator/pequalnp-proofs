import argparse
from collections import Counter
import itertools
import json
from pathlib import Path
import time

import term_context_live_bfs as base

CASES=json.loads(Path(__file__).with_name('term-context-982-cases.json').read_text())


def configure(case_index):
    global EDGES,N,ROWS,TRUTH_MASK,TARGET,NEGATIVE,POSITIVE,K,LOW
    case=CASES[case_index]
    EDGES=tuple(tuple(edge) for edge in case['edges'])
    N=case['n']
    ROWS=1<<N
    TRUTH_MASK=(1<<ROWS)-1
    TARGET=sum(1<<x for x in range(ROWS) if any(x>>u&1 and x>>v&1 for u,v in EDGES))
    NEGATIVE=[x for x in range(ROWS) if not (TARGET>>x&1)]
    POSITIVE=[x for x in range(ROWS) if TARGET>>x&1]
    K=len(NEGATIVE)*len(POSITIVE)
    LOW=(1<<K)-1
    for name,value in {'N':N,'ROWS':ROWS,'TRUTH_MASK':TRUTH_MASK,'TARGET':TARGET,
                       'NEGATIVE':NEGATIVE,'POSITIVE':POSITIVE,'K':K,'LOW':LOW,
                       'PAIR_MASK':(1<<(2*K))-1,'POS_MASK':(1<<len(POSITIVE))-1,
                       'REPEAT_POS':sum(1<<(i*len(POSITIVE)) for i in range(len(NEGATIVE)))}.items():
        setattr(base,name,value)


class GraphWires(base.SymWires):
    def __init__(self):
        base.Wires.__init__(self)
        edge_set={tuple(sorted(e)) for e in EDGES}
        degrees=[sum(v in edge for edge in EDGES) for v in range(N)]
        self.perms=[p for p in itertools.permutations(range(N))
                    if all(degrees[i]==degrees[p[i]] for i in range(N))
                    and {tuple(sorted((p[u],p[v]))) for u,v in EDGES}==edge_set]
        assert self.perms
        lookup={p:i for i,p in enumerate(self.perms)}
        self.compose=[[lookup[tuple(h[g[i]] for i in range(N))] for g in self.perms] for h in self.perms]
        self.orbits={}
        self.origins={}
    def canonical_with_symmetry(self,state):
        orbits=[self.orbit(index) for index in state]
        return min((tuple(sorted(orbit[g] for orbit in orbits)),g) for g in range(len(self.perms)))
    def covered(self,state,remaining):
        return base.Wires.covered(self,state,remaining)


def reconstruct(wires,nodes,node_id,initial_ids,target_id):
    chain=[]
    while node_id:
        node=nodes[node_id]
        chain.append(node)
        node_id=node['parent']
    gates=[]
    mapping={wire:i for i,wire in enumerate(initial_ids)}
    for node in reversed(chain):
        a,b,value=node['a'],node['b'],node['value']
        gate_inputs=[mapping[a]] if b is None else [mapping[a],mapping[b]]
        gates.append({'op':node['op'],'inputs':gate_inputs})
        produced=N+len(gates)-1
        mapping={wire:mapping[wire] for wire in node['kept']}
        mapping[value]=produced
        g=node['symmetry']
        p=wires.perms[g]
        gates=[{'op':gate['op'],'inputs':[p[i] if i<N else i for i in gate['inputs']]} for gate in gates]
        mapping={wires.orbit(wire)[g]:(p[index] if index<N else index) for wire,index in mapping.items()}
    output=mapping[target_id]
    for row in range(ROWS):
        values=[row>>i&1 for i in range(N)]
        for gate in gates:
            operands=[values[i] for i in gate['inputs']]
            values.append(1-operands[0] if gate['op']=='not' else (operands[0]&operands[1] if gate['op']=='and' else operands[0]|operands[1]))
        assert values[output]==(TARGET>>row&1)
    return {'n':N,'edges':EDGES,'gates':gates,'output':output,'size':len(gates),'verified_rows':ROWS}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--case',type=int,default=15)
    parser.add_argument('--budget',type=int)
    parser.add_argument('--seconds',type=float,default=180)
    parser.add_argument('--max-states',type=int,default=250000)
    parser.add_argument('--prefix',default='term-context-982-live')
    args=parser.parse_args()
    configure(args.case)
    if args.budget is None:args.budget=CASES[args.case]['search_budget']
    start=time.monotonic()
    deadline=start+args.seconds
    wires=GraphWires()
    initial=tuple(wires.add(sum(1<<row for row in range(ROWS) if row>>i&1)) for i in range(N))
    target_id=wires.add(TARGET)
    for i,wire in enumerate(initial):wires.orbits[wire]=tuple(initial[p[i]] for p in wires.perms)
    wires.orbits[target_id]=(target_id,)*len(wires.perms)
    fixed={0,TRUTH_MASK,*(wires.truth[wire] for wire in initial)}
    nodes=[None]
    states={initial:0}
    zero_count=0
    complete=False
    print(json.dumps({'event':'metadata','n':N,'truth_rows':ROWS,'negative_rows':len(NEGATIVE),'positive_rows':len(POSITIVE),'pair_rows':K,'automorphisms':len(wires.perms),'case':args.case,'edges':EDGES,'budget':args.budget,'coverage':'oriented_only_at_zero_slack','normalization':'no_constants_live_aliases_original_inputs'}),flush=True)
    with Path(args.prefix+'-zero-frontier.jsonl').open('w') as zero_file, Path(args.prefix+'-all-frontiers.jsonl').open('w') as frontiers:
        frontiers.write(json.dumps({'depth':0,'remaining':args.budget,'states':[[hex(wires.truth[i]) for i in initial]]})+'\n')
        frontiers.flush()
        for depth in range(1,args.budget+1):
            remaining=args.budget-depth
            next_states={}
            rejected=set()
            attempted=duplicates=coverage_prunes=normalization_prunes=processed=0
            reason=None
            def emit(parent,parent_id,a,b,value,op,kept):
                nonlocal attempted,duplicates,coverage_prunes,zero_count
                attempted+=1
                canonical,g=wires.canonical_with_symmetry((value,)+kept)
                if canonical in next_states or canonical in rejected:
                    duplicates+=1
                    return
                if not wires.covered(canonical,remaining):
                    coverage_prunes+=1
                    rejected.add(canonical)
                    return
                nodes.append({'parent':parent_id,'a':a,'b':b,'value':value,'op':op,'kept':kept,'symmetry':g})
                next_states[canonical]=len(nodes)-1
                if len(canonical)==remaining+1 and zero_count<200:
                    zero_file.write(json.dumps({'depth':depth,'remaining':remaining,'functions_hex':[hex(wires.truth[i]) for i in canonical]})+'\n')
                    zero_file.flush()
                    zero_count+=1
            for state,parent_id in states.items():
                if time.monotonic()>=deadline:reason='time_limit';break
                if len(next_states)>=args.max_states:reason='state_limit';break
                processed+=1
                slack=remaining+2-len(state)
                for i,a in enumerate(state):
                    if slack>=1:
                        value=wires.negate(a)
                        if value in state or wires.truth[value] in fixed:
                            normalization_prunes+=1
                        else:
                            tail=state[:i]+state[i+1:]
                            emit(state,parent_id,a,None,value,'not',tail)
                            if slack>=2:emit(state,parent_id,a,None,value,'not',(a,)+tail)
                    for j in range(i+1,len(state)):
                        b=state[j]
                        tail=state[:i]+state[i+1:j]+state[j+1:]
                        for meet in (False,True):
                            value=wires.binary(a,b,meet)
                            if value in state or wires.truth[value] in fixed:
                                normalization_prunes+=1
                                continue
                            op='and' if meet else 'or'
                            emit(state,parent_id,a,b,value,op,tail)
                            if slack>=1:
                                emit(state,parent_id,a,b,value,op,(a,)+tail)
                                emit(state,parent_id,a,b,value,op,(b,)+tail)
                            if slack>=2:emit(state,parent_id,a,b,value,op,(a,b)+tail)
                if (target_id,) in next_states:
                    result=reconstruct(wires,nodes,next_states[(target_id,)],initial,target_id)
                    Path(args.prefix+'-solution.json').write_text(json.dumps(result,indent=2)+'\n')
                    print(json.dumps({'event':'solution','size':result['size'],'file':args.prefix+'-solution.json','verified_rows':ROWS}),flush=True)
                    return
            print(json.dumps({'event':'layer','depth':depth,'remaining':remaining,'input_states':len(states),'processed_states':processed,'states':len(next_states),'complete':reason is None,'stop_reason':reason,'attempted':attempted,'duplicates':duplicates,'coverage_prunes':coverage_prunes,'normalization_prunes':normalization_prunes,'wire_functions':len(wires.truth),'slack_histogram':dict(Counter(remaining+1-len(s) for s in next_states)),'seconds':time.monotonic()-start}),flush=True)
            frontiers.write(json.dumps({'depth':depth,'remaining':remaining,'complete':reason is None,'states':[[hex(wires.truth[i]) for i in state] for state in next_states]})+'\n')
            frontiers.flush()
            if reason is not None:break
            if not next_states:
                complete=True
                break
            states=next_states
    print(json.dumps({'event':'finished','complete_empty_closure':complete,'seconds':time.monotonic()-start,'claim':'COMPUTATIONAL_REDUCED_SEARCH_ONLY'}),flush=True)


if __name__=='__main__':main()
