import argparse
from collections import Counter
import json
from pathlib import Path
import time
import term_context_982_live_bfs as search

p=argparse.ArgumentParser()
p.add_argument('--case',type=int,required=True)
p.add_argument('--prefix',required=True)
args=p.parse_args()
search.configure(args.case)
wires=search.GraphWires()
start=time.monotonic()
negative=search.NEGATIVE; positive=search.POSITIVE
pairs=[(n,p) for n in negative for p in positive]
pair_index={p:i for i,p in enumerate(pairs)}
star={i for i,(n,p) in enumerate(pairs) if n==0 or p==search.ROWS-1}
selected=sum(1<<i for i in star)
initial=[sum(((r>>i)&1)<<r for r in range(search.ROWS)) for i in range(search.N)]
fixed={0,search.TRUTH_MASK,*initial}
misses=set(); moves=0; failures=0
layers=[json.loads(x) for x in Path(args.prefix+'-all-frontiers.jsonl').read_text().splitlines()]
for layer in layers:
    remaining=layer['remaining']
    if not layer['states']: continue
    for state in layer['states']:
        ids=[wires.add(int(x,16)) for x in state]
        slack=remaining+1-len(ids)
        def handle(candidate):
            global moves,failures
            moves+=1
            family=wires.up if len(candidate)==remaining else wires.diff
            cov=0
            for wire in candidate:cov|=family[wire]
            missing=search.LOW^cov
            if missing:
                failures+=1
                if not (missing&selected): misses.add(missing)
        for i,a in enumerate(ids):
            if slack>=1:
                value=wires.negate(a)
                if value not in ids and wires.truth[value] not in fixed:
                    tail=ids[:i]+ids[i+1:]
                    handle([value]+tail)
                    if slack>=2:handle([value,a]+tail)
            for j in range(i+1,len(ids)):
                b=ids[j]; tail=ids[:i]+ids[i+1:j]+ids[j+1:]
                for meet in (False,True):
                    value=wires.binary(a,b,meet)
                    if value in ids or wires.truth[value] in fixed:continue
                    for keep in range(4):
                        if keep.bit_count()>slack:continue
                        handle([value]+tail+([a] if keep&1 else [])+([b] if keep&2 else []))
    print(json.dumps({'event':'collect','depth':layer['depth'],'moves':moves,'coverage_failures':failures,'unhit_masks':len(misses),'seconds':time.monotonic()-start}),flush=True)

orbits={}
for i,(n,p) in enumerate(pairs):
    vals=set()
    for perm in wires.perms:
        def source(row):return sum(((row>>perm[j])&1)<<j for j in range(search.N))
        vals.add(pair_index[source(n),source(p)])
    orbits[i]=tuple(sorted(vals))
unique_orbits=set(orbits.values())
orbit_masks={o:sum(1<<i for i in o) for o in unique_orbits}
while misses:
    counts=Counter()
    for mask in misses:
        seen=set()
        while mask:
            bit=mask&-mask; mask-=bit
            seen.add(orbits[bit.bit_length()-1])
        counts.update(seen)
    best=max(counts,key=lambda o:(counts[o]/len(o),counts[o],tuple(-i for i in o)))
    selected|=orbit_masks[best]
    misses={m for m in misses if not m&orbit_masks[best]}
    print(json.dumps({'event':'greedy','selected_pairs':selected.bit_count(),'remaining_masks':len(misses)}),flush=True)
chosen=[pair for i,pair in enumerate(pairs) if selected>>i&1]
assert {r for pair in chosen for r in pair}==set(range(search.ROWS))
lookup={tuple(x):i for i,x in enumerate(chosen)}
actions=[]
for perm in wires.perms:
    def source(row):return sum(((row>>perm[j])&1)<<j for j in range(search.N))
    actions.append([lookup[source(n),source(p)] for n,p in chosen])
data={'case':args.case,'n':search.N,'original_K':search.K,'K':len(chosen),'pairs':chosen,'pair_actions':actions,'vertex_permutations':wires.perms,'fresh_moves_checked':moves,'coverage_failures_preserved':failures,'all_assignments_present':True,'scope':'all fresh moves from supplied maximum-budget frontiers','seconds':time.monotonic()-start}
Path(args.prefix+'-reduced-pairs.json').write_text(json.dumps(data,indent=2))
print(json.dumps({k:v for k,v in data.items() if k not in ['pairs','pair_actions','vertex_permutations']}),flush=True)
