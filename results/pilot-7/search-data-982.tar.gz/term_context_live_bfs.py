import argparse
from collections import Counter
import importlib.util
import itertools
import json
import time
from pathlib import Path

EDGES = ((0,1),(1,2),(2,3),(3,4),(4,0),(0,5),(1,6),(2,7),(3,8),(5,7),(6,8),(8,5))
N = 9
ROWS = 1 << N
TRUTH_MASK = (1 << ROWS) - 1
TARGET = sum(1 << x for x in range(ROWS) if any(x >> u & 1 and x >> v & 1 for u,v in EDGES))
NEGATIVE = [x for x in range(ROWS) if not (TARGET >> x & 1)]
POSITIVE = [x for x in range(ROWS) if TARGET >> x & 1]
K = len(NEGATIVE) * len(POSITIVE)
LOW = (1 << K) - 1
PAIR_MASK = (1 << (2 * K)) - 1
POS_MASK = (1 << len(POSITIVE)) - 1
REPEAT_POS = sum(1 << (i * len(POSITIVE)) for i in range(len(NEGATIVE)))


class Wires:
    def __init__(self):
        self.index = {}
        self.truth = []
        self.encoding = []
        self.diff = []
        self.up = []
    def direct_encoding(self, truth):
        negative = sum(POS_MASK << (i * len(POSITIVE)) for i,x in enumerate(NEGATIVE) if truth >> x & 1)
        positive_bits = sum(1 << i for i,x in enumerate(POSITIVE) if truth >> x & 1)
        positive = positive_bits * REPEAT_POS
        return negative | (positive << K)
    def add(self, truth, encoding=None):
        old = self.index.get(truth)
        if old is not None:
            return old
        if encoding is None:
            encoding = self.direct_encoding(truth)
        index = len(self.truth)
        self.index[truth] = index
        self.truth.append(truth)
        self.encoding.append(encoding)
        self.diff.append((encoding ^ (encoding >> K)) & LOW)
        self.up.append((encoding >> K) & (~encoding) & LOW)
        return index
    def negate(self, index):
        truth = self.truth[index] ^ TRUTH_MASK
        old = self.index.get(truth)
        return old if old is not None else self.add(truth, self.encoding[index] ^ PAIR_MASK)
    def binary(self, left, right, meet):
        truth = self.truth[left] & self.truth[right] if meet else self.truth[left] | self.truth[right]
        old = self.index.get(truth)
        if old is not None:
            return old
        encoding = self.encoding[left] & self.encoding[right] if meet else self.encoding[left] | self.encoding[right]
        return self.add(truth, encoding)
    def covered(self, state, remaining):
        family = self.up if len(state) == remaining + 1 else self.diff
        covered = 0
        for index in state:
            covered |= family[index]
            if covered == LOW:
                return True
        return False


class SymWires(Wires):
    def __init__(self):
        super().__init__()
        columns = ((0,8,2),(3,1,5),(4,6,7))
        self.perms=[]
        for permutation in itertools.permutations(range(3)):
            for swap in (False,True):
                p=list(range(N))
                for side in range(3):
                    target_side=1-side if swap and side<2 else side
                    for i in range(3):p[columns[side][i]]=columns[target_side][permutation[i]]
                assert {tuple(sorted((p[u],p[v]))) for u,v in EDGES} == {tuple(sorted(e)) for e in EDGES}
                self.perms.append(tuple(p))
        self.compose=[[self.perms.index(tuple(h[g[i]] for i in range(N))) for g in self.perms] for h in self.perms]
        self.orbits={}
        self.origins={}
    def negate(self,index):
        value=super().negate(index)
        if value not in self.orbits and value not in self.origins:self.origins[value]=('not',index)
        return value
    def binary(self,a,b,meet):
        value=super().binary(a,b,meet)
        if value not in self.orbits and value not in self.origins:self.origins[value]=('binary',a,b,meet)
        return value
    def orbit(self,index):
        old=self.orbits.get(index)
        if old is not None:return old
        origin=self.origins[index]
        if origin[0]=='not':
            result=tuple(self.negate(a) for a in self.orbit(origin[1]))
        else:
            result=tuple(self.binary(a,b,origin[3]) for a,b in zip(self.orbit(origin[1]),self.orbit(origin[2])))
        for g,value in enumerate(result):
            self.orbits[value]=tuple(result[self.compose[h][g]] for h in range(len(self.perms)))
        return self.orbits[index]
    def canonical(self,state):
        orbits=[self.orbit(index) for index in state]
        return min(tuple(sorted(orbit[g] for orbit in orbits)) for g in range(len(self.perms)))


class ScorePruner:
    def __init__(self,wires,wide=False):
        spec=importlib.util.spec_from_file_location('score6_670_py',Path(__file__).with_name('score6_670.py'))
        self.module=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.module)
        self.wires=wires
        self.pool=[]
        self.values=[]
        self.searches=0
        self.wide_searches=0
        self.wide=None
        if wide:
            spec=importlib.util.spec_from_file_location('score6_wide_670_py',Path(__file__).with_name('score6_wide_670.py'))
            self.wide=importlib.util.module_from_spec(spec)
            spec.loader.exec_module(self.wide)
    def excluded(self,state):
        for witness,cache in zip(self.pool,self.values):
            total=0
            for index in state:
                value=cache.get(index)
                if value is None:
                    word=self.wires.truth[index]
                    value=self.module.value6(*[(word>>row)&1 for row in witness['rows']])
                    cache[index]=value
                total+=value
                if total>=3:break
            if total<3:return True
        self.searches+=1
        words=[self.wires.truth[index] for index in state]
        witness=self.module.find_witness(words)
        if witness is None and self.wide is not None:
            self.wide_searches+=1
            witness=self.wide.witness(words,'triples')
            if witness is None:witness=self.wide.witness(words,'all')
        if witness is None:return False
        self.pool.append(witness)
        self.values.append({})
        return True


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--budget', type=int, default=15)
    parser.add_argument('--depth', type=int, default=5)
    parser.add_argument('--seconds', type=float, default=300)
    parser.add_argument('--max-states', type=int, default=250000)
    parser.add_argument('--frontier-limit', type=int, default=100)
    parser.add_argument('--frontier-file', default='term-context-live-frontier.jsonl')
    parser.add_argument('--symmetry',action='store_true')
    parser.add_argument('--score',action='store_true')
    parser.add_argument('--wide-score',action='store_true')
    parser.add_argument('--score-pool-file',default='term-context-live-score-pool.json')
    parser.add_argument('--score-pool-in')
    parser.add_argument('--nontrivial',action='store_true')
    parser.add_argument('--survivor-file',default='term-context-live-zero-survivors.jsonl')
    parser.add_argument('--positive-survivor-file',default='term-context-live-positive-survivors.jsonl')
    args = parser.parse_args()
    started = time.monotonic()
    deadline = started + args.seconds
    wires = SymWires() if args.symmetry else Wires()
    initial = tuple(wires.add(sum(1 << x for x in range(ROWS) if x >> v & 1)) for v in range(N))
    fixed_forbidden = {0, TRUTH_MASK, *(wires.truth[index] for index in initial)}
    target_id = wires.add(TARGET)
    if args.symmetry:
        for i,index in enumerate(initial):wires.orbits[index]=tuple(initial[p[i]] for p in wires.perms)
        wires.orbits[target_id]=(target_id,)*len(wires.perms)
        initial=wires.canonical(initial)
    score=ScorePruner(wires,args.wide_score) if args.score else None
    if score is not None and args.score_pool_in:
        score.pool=json.loads(Path(args.score_pool_in).read_text())
        assert isinstance(score.pool,list) and all(isinstance(row,dict) and len(row['rows'])==6 for row in score.pool)
        score.values=[{} for _ in score.pool]
    assert wires.covered(initial, args.budget)
    print(json.dumps({'event':'metadata','n':N,'truth_bits':ROWS,'negative_rows':len(NEGATIVE),'positive_rows':len(POSITIVE),
                      'paired_rows':K,'budget':args.budget,'initial_slack':args.budget+1-N,
                      'fixed_forbidden_original_inputs':bool(args.nontrivial),
                      'frontier_encoding':'functions_hex: bit x is value at assignment x; variable i is bit i of x'}),flush=True)
    states = {initial}
    frontier_count = 0
    frontier_seen = set()
    survivors_count=0
    positive_survivors_count=0
    with Path(args.frontier_file).open('w') as frontier, Path(args.survivor_file).open('w') as survivors, Path(args.positive_survivor_file).open('w') as positive_survivors:
        for depth in range(args.depth):
            remaining = args.budget - depth
            next_remaining = remaining - 1
            next_states = set()
            attempted = duplicates = coverage_prunes = length_prunes = processed = score_prunes = normalization_prunes = 0
            rejected=set()
            complete = True
            reason = None
            layer_start = time.monotonic()
            def emit(candidate):
                nonlocal attempted,duplicates,coverage_prunes,length_prunes,frontier_count,score_prunes,survivors_count,positive_survivors_count
                attempted += 1
                if len(candidate) > next_remaining + 1:
                    length_prunes += 1
                    return
                state = wires.canonical(candidate) if args.symmetry else tuple(sorted(candidate))
                if state in next_states or state in rejected:
                    duplicates += 1
                    return
                if not wires.covered(state,next_remaining):
                    coverage_prunes += 1
                    rejected.add(state)
                    return
                if len(state) == next_remaining + 1 and frontier_count < args.frontier_limit and state not in frontier_seen:
                    frontier_seen.add(state)
                    frontier.write(json.dumps({'depth':depth+1,'remaining':next_remaining,'functions_hex':[hex(wires.truth[i]) for i in state]})+'\n')
                    frontier.flush()
                    frontier_count += 1
                if score is not None and len(state)==next_remaining+1 and score.excluded(state):
                    score_prunes+=1
                    rejected.add(state)
                    return
                if len(state)==next_remaining+1 and survivors_count<100:
                    survivors.write(json.dumps({'depth':depth+1,'remaining':next_remaining,'functions_hex':[hex(wires.truth[i]) for i in state]})+'\n')
                    survivors.flush()
                    survivors_count+=1
                if len(state)==next_remaining and positive_survivors_count<100:
                    positive_survivors.write(json.dumps({'depth':depth+1,'remaining':next_remaining,'slack':1,'functions_hex':[hex(wires.truth[i]) for i in state]})+'\n')
                    positive_survivors.flush()
                    positive_survivors_count+=1
                next_states.add(state)
            for state in states:
                if time.monotonic() >= deadline:
                    complete=False;reason='time_limit';break
                if len(next_states) >= args.max_states:
                    complete=False;reason='state_limit';break
                processed += 1
                slack = remaining + 1 - len(state)
                for i,a in enumerate(state):
                    rest = state[:i] + state[i+1:]
                    if slack >= 1:
                        for value in ((wires.negate(a),) if args.nontrivial else (a,wires.negate(a))):
                            if args.nontrivial and (value in state or wires.truth[value] in fixed_forbidden):
                                normalization_prunes+=1
                                continue
                            emit((value,)+rest)
                            if slack >= 2:emit((value,a)+rest)
                    for j in range(i+1,len(state)):
                        b=state[j]
                        tail=state[:i]+state[i+1:j]+state[j+1:]
                        for meet in (False,True):
                            value=wires.binary(a,b,meet)
                            if args.nontrivial and (value in state or wires.truth[value] in fixed_forbidden):
                                normalization_prunes+=1
                                continue
                            emit((value,)+tail)
                            if slack>=1:
                                emit((value,a)+tail)
                                emit((value,b)+tail)
                            if slack>=2:emit((value,a,b)+tail)
                if (target_id,) in next_states:
                    print(json.dumps({'event':'target_found','depth':depth+1,'remaining':next_remaining}),flush=True)
                    return
            print(json.dumps({'event':'layer','depth':depth+1,'remaining':next_remaining,'input_states':len(states),
                              'processed_states':processed,'states':len(next_states),'complete':complete,'stop_reason':reason,
                              'successors_attempted':attempted,'accepted_duplicates':duplicates,'coverage_prunes':coverage_prunes,
                              'length_prunes':length_prunes,'wire_functions':len(wires.truth),'frontier_dumped':frontier_count,
                              'score_prunes':score_prunes,'score_pool_size':len(score.pool) if score else 0,
                              'score_searches':score.searches if score else 0,
                               'wide_score_searches':score.wide_searches if score else 0,
                              'normalization_operation_prunes':normalization_prunes,'zero_survivors_dumped':survivors_count,
                               'slack_histogram':dict(Counter(next_remaining+1-len(state) for state in next_states)),
                               'positive_survivors_dumped':positive_survivors_count,
                              'layer_seconds':round(time.monotonic()-layer_start,3),'total_seconds':round(time.monotonic()-started,3)}),flush=True)
            if not complete or not next_states:
                break
            states=next_states
    if score is not None:Path(args.score_pool_file).write_text(json.dumps(score.pool)+'\n')
    print(json.dumps({'event':'finished','seconds':round(time.monotonic()-started,3),'frontier_dumped':frontier_count,
                      'verdict':'BOUNDED_PROTOTYPE_ONLY_NO_UNSAT_CLAIM'}),flush=True)


if __name__=='__main__':
    main()
