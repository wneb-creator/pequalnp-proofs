import argparse
import functools
import hashlib
import json
from pathlib import Path
import time

import term_context_982_live_bfs as search
from term_context_score6_generic import value6


def main():
    start=time.monotonic()
    parser=argparse.ArgumentParser()
    parser.add_argument('--case',type=int,required=True)
    parser.add_argument('--manifest',default='root982-pair-manifest.json')
    args=parser.parse_args()
    entry=next(e for e in json.loads(Path(args.manifest).read_text()) if e['case']==args.case)
    case=args.case
    prefix=entry['prefix']
    budget=entry['maximum_budget']
    output='root982-core'+str(case)
    search.configure(case)
    graph=search.GraphWires()
    reduced=json.loads(Path(entry['pair_file']).read_text())
    enc_K=reduced['K']
    paired_rows=[pair[0] for pair in reduced['pairs']]+[pair[1] for pair in reduced['pairs']]
    assert set(paired_rows)==set(range(search.ROWS))
    assert [tuple(p) for p in reduced['vertex_permutations']]==graph.perms
    @functools.cache
    def encode_word(word):return sum(((word>>row)&1)<<i for i,row in enumerate(paired_rows))
    perms=graph.perms
    perm_index={p:i for i,p in enumerate(perms)}
    inverses=[]
    for p in perms:
        inverse=[0]*search.N
        for i,j in enumerate(p):inverse[j]=i
        inverses.append(perm_index[tuple(inverse)])
    @functools.cache
    def transform(word,g):
        p=perms[g]
        return sum(((word>>sum(((row>>p[i])&1)<<i for i in range(search.N)))&1)<<row for row in range(search.ROWS))
    @functools.cache
    def orbit_key(state):
        return min(tuple(sorted(transform(word,g) for word in state)) for g in range(len(perms)))
    states=[[] for _ in range(budget+1)]
    keys=[{} for _ in range(budget+1)]
    roots=[]
    for current_budget in [budget]:
        layers=[json.loads(line) for line in Path(prefix+'-all-frontiers.jsonl').read_text().splitlines()]
        assert not layers[-1]['states'] and all(layer.get('complete',True) for layer in layers)
        for layer in layers:
            remaining=layer['remaining']
            for index,encoded in enumerate(layer['states']):
                state=tuple(sorted((int(word,16) for word in encoded),key=encode_word))
                key=orbit_key(state)
                if key not in keys[remaining]:
                    keys[remaining][key]=len(states[remaining])
                    states[remaining].append(state)
                if layer['depth']==0:
                    assert index==0
                    roots.append((current_budget,keys[remaining][key]))
    initial=tuple(sum(1<<row for row in range(search.ROWS) if row>>i&1) for i in range(search.N))
    fixed={0,search.TRUTH_MASK,*initial}
    original_pool=json.loads(Path(prefix+'-score-pool.json').read_text())
    pool=[]
    seen_rows=set()
    for witness in original_pool:
        for p in perms:
            rows=[sum(((row>>p[i])&1)<<i for i in range(search.N)) for row in witness['rows']]
            rows[1:3]=sorted(rows[1:3])
            rows[4:6]=sorted(rows[4:6])
            key=tuple(rows)
            if key not in seen_rows:
                seen_rows.add(key)
                pool.append({'rows':rows})
    for witness in pool:assert [search.TARGET>>row&1 for row in witness['rows']]==[1,1,1,0,0,0]
    wires=search.base.Wires()
    all_words=sorted({word for layer in states for state in layer for word in state})
    word_index={word:i for i,word in enumerate(all_words)}
    encoded_words=[encode_word(word) for word in all_words]
    encoded_initial=[encode_word(word) for word in initial]
    assert len(set(encoded_words))==len(all_words)
    advice=[[[] for _ in layer] for layer in states]
    counts={'moves':0,'coverage':0,'score':0,'next':0}
    examples=[]
    @functools.cache
    def score_reject(state):
        for witness in pool:
            if sum(value6(*[(word>>row)&1 for row in witness['rows']]) for word in state)<3:return True
        return False
    for remaining,layer in enumerate(states):
        if not layer:continue
        assert remaining>0
        lookup={}
        for child_index,state in enumerate(states[remaining-1]):
            for g in range(len(perms)):
                image=tuple(sorted(transform(word,g) for word in state))
                lookup.setdefault(image,(child_index,inverses[g]))
        for state_index,state in enumerate(layer):
            slack=remaining+1-len(state)
            ids=[wires.add(word) for word in state]
            enc=[encode_word(wires.truth[i]) for i in ids]
            entries={}
            def handle(tag,candidate):
                counts['moves']+=1
                family=wires.up if len(candidate)==remaining else wires.diff
                coverage=0
                for wire in candidate:coverage|=family[wire]
                if coverage!=search.LOW:
                    counts['coverage']+=1
                    return
                words=tuple(sorted(wires.truth[wire] for wire in candidate))
                if len(candidate)==remaining and score_reject(words):
                    counts['score']+=1
                    return
                child,g=lookup[words]
                assert tuple(sorted(transform(word,g) for word in words))==tuple(sorted(states[remaining-1][child]))
                payload=1+g+64*child
                packed=tag+1024*payload
                assert 0<=tag<1024 and 0<=g<64
                assert tag not in entries or entries[tag]==packed
                entries[tag]=packed
                counts['next']+=1
                if len(examples)<8:examples.append({'remaining':remaining,'state':state_index,'tag':tag,'child':child,'symmetry':g})
            for ai,a in enumerate(ids):
                tail=ids[:ai]+ids[ai+1:]
                if slack>=1:
                    value=wires.negate(a)
                    if value not in ids and wires.truth[value] not in fixed:
                        handle(4*ai+2,[value]+tail)
                        if slack>=2:handle(4*ai+3,[value,a]+tail)
                for bi in range(ai+1,len(ids)):
                    b=ids[bi]
                    rest=[ids[i] for i in range(len(ids)) if i not in (ai,bi)]
                    for meet in (False,True):
                        value=wires.binary(a,b,meet)
                        if value in ids or wires.truth[value] in fixed:continue
                        for keep in range(4):
                            if keep.bit_count()>slack:continue
                            ka,kb=bool(keep&1),bool(keep&2)
                            ia,ib=ai,bi
                            if enc[ia]>enc[ib]:ia,ib=ib,ia;ka,kb=kb,ka
                            tag=48+8*(ib*(ib+1)//2+ia)+4*int(meet)+2*int(ka)+int(kb)
                            candidate=[value]+rest+([a] if keep&1 else [])+([b] if keep&2 else [])
                            handle(tag,candidate)
            advice[remaining][state_index]=[entries[tag] for tag in sorted(entries)]
    neg_index={row:i for i,row in enumerate(search.NEGATIVE)}
    pos_index={row:i for i,row in enumerate(search.POSITIVE)}
    neg_perms=[];pos_perms=[];pair_perms=[]
    for p in perms:
        def source(row):return sum(((row>>p[i])&1)<<i for i in range(search.N))
        np=[neg_index[source(row)] for row in search.NEGATIVE]
        pp=[pos_index[source(row)] for row in search.POSITIVE]
        neg_perms.append(np);pos_perms.append(pp)
        pair_perms.append([len(search.POSITIVE)*np[i]+pp[j] for i in range(len(search.NEGATIVE)) for j in range(len(search.POSITIVE))])
    pair_perms=reduced['pair_actions']
    pool_codes=[];pool_coordinates=[]
    for witness in pool:
        coords=[paired_rows.index(row) for row in witness['rows']]
        assert all(coord<1024 for coord in coords)
        assert [paired_rows[coord] for coord in coords]==witness['rows']
        pool_codes.append(sum(coord<<(10*i) for i,coord in enumerate(coords)))
        pool_coordinates.append(coords)
    for word in all_words[:20]:
        encoded=encode_word(word)
        for g,permutation in enumerate(pair_perms):
            transformed=sum(((encoded>>permutation[j])&1)<<j for j in range(enc_K))
            transformed|=sum(((encoded>>(enc_K+permutation[j]))&1)<<(enc_K+j) for j in range(enc_K))
            assert transformed==encode_word(transform(word,g))
    data={'case':case,'n':search.N,'K':enc_K,'score_width':10,'negative_rows':search.NEGATIVE,'positive_rows':search.POSITIVE,
          'paired_rows':paired_rows,'full_truth_words_hex':[hex(word) for word in all_words],
          'encoded_words_hex':[hex(word) for word in encoded_words],'inputs_hex':[hex(word) for word in encoded_initial],
          'states':[[[word_index[word] for word in state] for state in layer] for layer in states],
          'advice':advice,'advice_encoding':'entry=tag+1024*(1+symmetry+64*childIndex);sortbytag',
          'roots':roots,'vertex_perms':perms,'inverse_perms':inverses,'negative_perms':neg_perms,'positive_perms':pos_perms,
          'pair_perms':pair_perms,'score_pool_truth_rows':[witness['rows'] for witness in pool],
          'score_pool_coordinates':pool_coordinates,'score_pool_codes':pool_codes,'counts':counts,'examples':examples}
    Path(output+'-data.json').write_text(json.dumps(data,indent=2)+'\n')
    def nat_list(values,hexadecimal=False):return '['+', '.join(hex(v) if hexadecimal else str(v) for v in values)+']'
    def array(values):return '#['+',\n'.join(values)+']'
    lines=['namespace PEqualNP.Outside.L_meta_982_aux.Finite',
           'def seed0K : Nat := '+str(enc_K),
           'def seed0ScoreWidth : Nat := 10',
           'def seed0NegativeRows : List Nat := '+nat_list(search.NEGATIVE),
           'def seed0PositiveRows : List Nat := '+nat_list(search.POSITIVE),
           'def seed0Rows : List Nat := '+nat_list(paired_rows),
           'def seed0Inputs : List Nat := '+nat_list(encoded_initial,True),
           'def seed0Mask : Nat := '+hex((1<<(2*enc_K))-1),
           'def seed0Goal : Nat := '+hex(((1<<enc_K)-1)<<enc_K),
           'def seed0Forbidden : List Nat := [0, seed0Mask] ++ seed0Inputs',
           'def seed0Pool : List Nat := '+nat_list(pool_codes),
           'def seed0Words : Array Nat := '+array([hex(word) for word in encoded_words]),
           'def seed0StateIndices : Array (Array (List Nat)) := '+array([array([nat_list(state) for state in layer]) for layer in data['states']]),
           'def seed0AdviceData : Array (Array (Array Nat)) := '+array([array([array([str(entry) for entry in row]) for row in layer]) for layer in advice]),
           'def seed0States (s i : Nat) : List Nat := ((seed0StateIndices.getD s #[]).getD i []).map (fun j => seed0Words.getD j 0)',
           'def seed0Count (s : Nat) : Nat := (seed0StateIndices.getD s #[]).size',
           'def seed0Advice (s i : Nat) : Array Nat := (seed0AdviceData.getD s #[]).getD i #[]',
           'def seed0Roots : List (Nat × Nat) := ['+', '.join('('+str(s)+', '+str(i)+')' for s,i in roots)+']',
           'def seed0VertexPerms : Array (List Nat) := '+array([nat_list(p) for p in perms]),
           'def seed0InversePerms : Array Nat := '+array([str(i) for i in inverses]),
           'def seed0NegPerms : Array (List Nat) := '+array([nat_list(p) for p in neg_perms]),
           'def seed0PosPerms : Array (List Nat) := '+array([nat_list(p) for p in pos_perms]),
           'def seed0PairPerms : Array (List Nat) := '+array([nat_list(p) for p in pair_perms]),
           'end PEqualNP.Outside.L_meta_982_aux.Finite']
    lean_path=Path(output+'-data.lean')
    lean_path.write_text(('\n\n'.join(lines)+'\n').replace('seed0','seed'+str(case)))
    summary={'case':case,'K':enc_K,'states_by_remaining':[len(layer) for layer in states],
             'total_states':sum(map(len,states)),'distinct_words':len(all_words),'advice_entries':sum(len(row) for layer in advice for row in layer),
             'score_pool_size':len(pool),'lean_bytes':lean_path.stat().st_size,'counts':counts,'seconds':time.monotonic()-start,
             'lean_sha256':hashlib.sha256(lean_path.read_bytes()).hexdigest()}
    Path(output+'-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary),flush=True)


if __name__=='__main__':main()
