import ctypes
from pathlib import Path


def value6(a,b,c,d,e,f):
    x=b+c
    y=2-e-f
    return (y if d else max(x,y,x+y-1)) if a else (0 if d else x)


class Score6:
    def __init__(self,n,target,edges):
        self.n=n
        self.target=target
        self.positive=[(1<<a)|(1<<b) for a,b in edges]
        self.negative=[row for row in range(1<<n) if not (target>>row&1)
                       and all(target>>(row|(1<<v))&1 for v in range(n) if not (row>>v&1))]
        root=Path(__file__).parent
        self.lib=ctypes.CDLL(str(root/'score6_670.so'))
        self.find=self.lib.find_score6
        self.find.argtypes=[ctypes.POINTER(ctypes.c_uint64),ctypes.c_size_t,
                           ctypes.POINTER(ctypes.c_uint64),ctypes.c_size_t,
                           ctypes.POINTER(ctypes.c_uint16),ctypes.POINTER(ctypes.c_uint16)]
        self.find.restype=ctypes.c_uint64
        self.wide_lib=ctypes.CDLL(str(root/'libscore6_wide_670.so'))
        self.find_wide=self.wide_lib.find_wide6
        self.find_wide.argtypes=[ctypes.POINTER(ctypes.c_uint64),ctypes.c_size_t,ctypes.c_size_t,
                                ctypes.POINTER(ctypes.c_uint64),ctypes.c_size_t,ctypes.c_size_t,
                                ctypes.POINTER(ctypes.c_uint16),ctypes.POINTER(ctypes.c_uint16)]
        self.find_wide.restype=ctypes.c_uint64
    @staticmethod
    def patterns(words,rows):
        return (ctypes.c_uint64*len(rows))(*(sum(((word>>row)&1)<<i for i,word in enumerate(words)) for row in rows))
    def find_witness(self,words,wide=False):
        assert len(words)<=63
        positive=self.positive;negative=self.negative
        code=int(self.find(self.patterns(words,positive),len(positive),self.patterns(words,negative),len(negative),
                           (ctypes.c_uint16*len(positive))(*positive),(ctypes.c_uint16*len(negative))(*negative)))
        mode='edges_mis'
        if not code and wide:
            for mode in ('triples','all'):
                positive=self.positive+[r for r in range(1<<self.n) if self.target>>r&1 and r not in self.positive and (mode=='all' or r.bit_count()<=3)]
                negative=self.negative+[r for r in range(1<<self.n) if not (self.target>>r&1) and r not in self.negative and (mode=='all' or r.bit_count()<=1)]
                code=int(self.find_wide(self.patterns(words,positive),len(positive),len(self.positive),
                                        self.patterns(words,negative),len(negative),len(self.negative),
                                        (ctypes.c_uint16*len(positive))(*positive),(ctypes.c_uint16*len(negative))(*negative)))
                if code:break
        if not code:return None
        rows=[code>>(10*i)&1023 for i in range(6)]
        assert [self.target>>row&1 for row in rows]==[1,1,1,0,0,0]
        score=sum(value6(*[(word>>row)&1 for row in rows]) for word in words)
        assert score<3
        return {'rows':rows,'code':code,'score':score,'mode':mode}


class ScorePruner:
    def __init__(self,n,target,edges,wires,wide=False):
        self.finder=Score6(n,target,edges)
        self.wires=wires
        self.wide=wide
        self.pool=[]
        self.values=[]
        self.searches=0
        self.rejects=0
    def excluded(self,state):
        for witness,cache in zip(self.pool,self.values):
            total=0
            for wire in state:
                if wire not in cache:
                    word=self.wires.truth[wire]
                    cache[wire]=value6(*[(word>>row)&1 for row in witness['rows']])
                total+=cache[wire]
                if total>=3:break
            if total<3:
                self.rejects+=1
                return True
        self.searches+=1
        witness=self.finder.find_witness([self.wires.truth[wire] for wire in state],self.wide)
        if witness is None:return False
        self.pool.append(witness)
        self.values.append({})
        self.rejects+=1
        return True
