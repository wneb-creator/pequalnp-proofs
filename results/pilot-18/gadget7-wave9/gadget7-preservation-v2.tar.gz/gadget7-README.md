The seven-input sibling is separate from every S06 source and main runner.
Input order is [0,2,4,5,8,9,10]. Local constants are FALSE7,TRUE8; gate
wires start at9. The target is exactly the disjunction of these nine edges:
09,25,48,58,59,89,0-10,2-10,4-10.

generic11.cnf encodes all monotone AND/OR circuits with at most11 gates,
including free constants, repeated operands, unused gates, and arbitrary
dirty intermediate gates. The only operand-order restriction is a<=b by
commutativity. Output-last normalization and padding by repeated-operand
OR gates cover smaller circuits. There is no cleanliness, first-junk,
liveness, distance, template, or shard restriction.

Nine minimal positive edge rows and seven maximal negative rows suffice:
every positive input contains an encoded edge; every negative input is
contained in an encoded maximal negative input. Full128-input checks are
also required by the independent SAT validator, together with complete
model assignment, all CNF clauses and all encoded intermediate values.

The full graph extension adds exactly ten gates. Its remainder is
6*(3 OR7 OR10) OR7*(3 OR9) OR1*(4 OR8), costing nine gates, followed by
one OR with the gadget. The validator checks all2048 full inputs. Hence
an exact<=11 local result gives<=21 full gates; a local12 positive control
gives22 full gates and is explicitly over both acceptance limits.

MAIN RUNNER ADAPTATION: the seven-input validator is validate_gadget7.py,
SHA1eeceaaf05207387246634a12238389ba4059a5bf3cc43739edcf0173e8141bb.
Require status VALIDATED_GADGET, verified_inputs==128,
full11_verified_inputs==2048, meets_gadget_11_gate_limit is True,
meets_full21_gate_limit is True, and all four exact provenance hashes.
The old eight-input validator key/counts are incompatible. Main owns a
fresh runner copy and its independent controls. Neither main's runner nor
the eight-input sources were changed here. Lean verification is separate.

Sources were derived by exact recorded literal changes from pinned S06
generator3ca527...ac17, validator60e877...54cb, controls d08d46...f923.
Full parents, exact diffs, and the derivation script are retained.

Positive12 pinned controls: constructed complete936-variable model and
actual pinned CaDiCaL SAT model both pass the independent CLI validator,
all128 local inputs and2048 full inputs. Both limit flags are false.
Bad11 pinned control computes local target OR024 and has exactly one bad
local input. Its full21 extension has false positives21,29,85,149. BCP
derives a contradiction after835 units; retained RUP and actual solver
DRAT each pass pinned DSR. These proofs apply only to that pinned fixture.
Additional controls cover16 gate truth assignments,64 unrestricted random
circuits, all128 row-cover cases, and six fail-closed validator cases.

Only tiny fully pinned controls were run: each child capped at3CPU/5wall
seconds,512MiB address space and8MiB file size. Solver/checker hashes were
verified before and after. Generic11 is UNSOLVED; no production search,
global21 refutation, Lean proof, engine mutation, git or lease action.
