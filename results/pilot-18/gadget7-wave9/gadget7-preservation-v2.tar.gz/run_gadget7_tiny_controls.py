from pathlib import Path
import json,hashlib,subprocess,time,resource,os
H=Path('/tmp/oec/pequalnp-pilot-18/orch/S05');R=H/'gadget7-v1';ROOT=H.parent.parent
SOLVER=ROOT/'lean-4.36.0-linux/bin/cadical';CHECKER=ROOT/'solver/dsr-trim/bin/dsr-trim';VALIDATOR=H/'validate_gadget7.py'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pins={str(SOLVER):'2a0137451efde370d67b88aec26f1e902870f095b1204b07049a103bc6bbd647',str(CHECKER):'e6894b5b74ac2c09b494344f397ec5111547aaa782cdb399f1a8b6835ecef84b',str(VALIDATOR):'1eeceaaf05207387246634a12238389ba4059a5bf3cc43739edcf0173e8141bb'}
for p,h in pins.items():assert sha(Path(p))==h
records=[]
def run(name,cmd,expected):
 def limits():
  resource.setrlimit(resource.RLIMIT_CPU,(3,3));resource.setrlimit(resource.RLIMIT_AS,(512*1024*1024,512*1024*1024));resource.setrlimit(resource.RLIMIT_FSIZE,(8*1024*1024,8*1024*1024));os.nice(10)
 t=time.monotonic()
 with (R/(name+'.stdout')).open('x') as out,(R/(name+'.stderr')).open('x') as err:p=subprocess.run(cmd,stdout=out,stderr=err,timeout=5,preexec_fn=limits)
 rec=dict(name=name,command=cmd,exit_code=p.returncode,expected_exit=expected,elapsed_seconds=time.monotonic()-t,cpu_seconds=3,wall_seconds=5,address_space_MiB=512,file_size_MiB=8,logs={n:dict(bytes=(R/(name+'.'+n)).stat().st_size,sha256=sha(R/(name+'.'+n))) for n in ['stdout','stderr']})
 records.append(rec);(R/(name+'.execution.json')).write_text(json.dumps(rec,indent=2)+'\n');assert p.returncode==expected
 return (R/(name+'.stdout')).read_text()
# Checker-only replay of the fully pinned BCP conflict, never generic synthesis.
s=run('bad11-bcp-checker',[str(CHECKER),'--forward','--rup-only',str(R/'bad11-pinned.cnf'),str(R/'bad11-pinned.rup')],0);assert [x for x in s.splitlines() if x.startswith('s ')]==['s VERIFIED UNSAT']
for name,code in [('positive12',0),('bad11',2)]:
 run(name+'-constructed-model-validator',['python3','-B',str(VALIDATOR),str(R/(name+'-pinned.cnf')),str(R/(name+'.model.stdout')),str(R/(name+'-constructed-cli.validation.json')),'--cnf-sha256',sha(R/(name+'-pinned.cnf')),'--metadata-sha256',sha(R/(name+'-pinned.json'))],code)
# Both actual solver invocations have every gate pinned; each has at most five seconds.
for name,code,verdict in [('positive12',10,'s SATISFIABLE'),('bad11',20,'s UNSATISFIABLE')]:
 s=run(name+'-pinned-solver',[str(SOLVER),'--sat','--binary=true','--no-color',str(R/(name+'-pinned.cnf')),str(R/(name+'-tiny.drat'))],code)
 assert [x for x in s.splitlines() if x.startswith('s ')]==[verdict]
 if code==10:
  run(name+'-actual-model-validator',['python3','-B',str(VALIDATOR),str(R/(name+'-pinned.cnf')),str(R/(name+'-pinned-solver.stdout')),str(R/(name+'-actual-cli.validation.json')),'--cnf-sha256',sha(R/(name+'-pinned.cnf')),'--metadata-sha256',sha(R/(name+'-pinned.json'))],0)
  d=json.load(open(R/(name+'-actual-cli.validation.json')));assert d['verified_inputs']==128 and d['full11_verified_inputs']==2048 and d['gate_count']==12 and d['full11_gate_count']==22 and d['meets_gadget_11_gate_limit'] is False and d['meets_full21_gate_limit'] is False
 else:
  s=run(name+'-drat-checker',[str(CHECKER),'--forward',str(R/(name+'-pinned.cnf')),str(R/(name+'-tiny.drat'))],0);assert [x for x in s.splitlines() if x.startswith('s ')]==['s VERIFIED UNSAT']
for p,h in pins.items():assert sha(Path(p))==h
result=dict(status='PASS_PINNED_ONLY_SOLVER_CHECKER_VALIDATOR_CONTROLS',pins=pins,records=records,source_sha256=sha(Path(__file__)),generic11_solved=False,production_launched=False,scope='Only fully pinned12positive/11bad controls. Positive12 exceeds bothlimits, rejectedfor21acceptance. Pinnedbad11UNSAT does not excludegeneric11 orfull21.')
(R/'tiny-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
