from pathlib import Path
import hashlib,json,difflib
H=Path('/tmp/oec/pequalnp-pilot-18/orch/S05');P=H.parent/'S06';D=H/'gadget7-source-derivation';D.mkdir(exist_ok=False)
pins={'build_gadget8.py':'3ca5274e1a394aff25e8f633bfc07ca5dd9ed2163b43db321dfba218e6b1ac17','validate_gadget8.py':'60e877fd3bdb11d134633519482b67ca82478c55a00350e34a935ddd194054cb','control_gadget8.py':'d08d46bac760773620707aff8e1c020f837f904f297b56b8b5bab028a993f923'}
vertices=('VERTICES=[0,2,4,5,6,8,9,10]','VERTICES=[0,2,4,5,8,9,10]')
edge8='[(0,9),(2,5),(4,8),(5,8),(5,9),(8,9),(0,10),(2,10),(4,10),(6,10)]';edge7='[(0,9),(2,5),(4,8),(5,8),(5,9),(8,9),(0,10),(2,10),(4,10)]'
base=[('orch/S06','orch/S05'),('s06-gadget8-v1','s05-gadget7-v1'),vertices,(edge8,edge7)]
build=base+[
 ('range(256)','range(128)'),('range(8)','range(7)'),('==10 and not set(positive)','==9 and not set(positive)'),('1<=k<=13','1<=k<=12'),('10+g','9+g'),('wire<8','wire<7'),('wire<10','wire<9'),('wire==9','wire==8'),('wire-10','wire-9'),("'wire_offset':10,'false_wire':8,'true_wire':9,'output':10+k-1","'wire_offset':9,'false_wire':7,'true_wire':8,'output':9+k-1"),('this 8-input gadget','this 7-input gadget'),('all256 inputs','all128 inputs'),('return 10+len(out)-1','return 9+len(out)-1'),("a=gate(positive,'or',a,v[6]);",''),("q=gate(bad,'or',q,v[6]);",''),('len(positive)==13 and len(bad)==12','len(positive)==12 and len(bad)==11'),("[('generic12',12,None),('generic13',13,None),('positive13-pinned',13,positive),('bad12-pinned',12,bad)]","[('generic11',11,None),('generic12',12,None),('positive12-pinned',12,positive),('bad11-pinned',11,bad)]"),("{'positive13':positive,'bad12':bad,'wire_offset':10","{'positive12':positive,'bad11':bad,'wire_offset':9")]
oldextension="""    def wire(w):
        return VERTICES[w] if w<8 else (w+3 if w<10 else w+3)
"""
newextension="""    def wire(w):
        return VERTICES[w] if w<7 else w+4
"""
oldrest="""    # Eight gates for edges14,18,36,37,67,79, followed by one union gate.
    q=add('or',3,6);q=add('or',q,9);star7=add('and',7,q)
    edge36=add('and',3,6);triangle_tail=add('or',star7,edge36)
    q=add('or',4,8);star1=add('and',1,q);rest=add('or',triangle_tail,star1)
    add('or',gadget_output,rest)
    require(len(full)==len(gates)+9,'extension gate count')
"""
newrest="""    # Nine gates for14,18,36,37,67,6-10,79, then one union gate.
    q=add('or',3,7);q=add('or',q,10);star6=add('and',6,q)
    q=add('or',3,9);star7=add('and',7,q)
    q=add('or',4,8);star1=add('and',1,q)
    q=add('or',star6,star7);rest=add('or',q,star1)
    add('or',gadget_output,rest)
    require(len(full)==len(gates)+10,'extension gate count')
"""
validator=[vertices,(edge8,edge7),(oldextension,newextension),(oldrest,newrest),('all256','all128'),('range(256)','range(128)'),('evaluate(gates,mask,8)','evaluate(gates,mask,7)'),('s06-gadget8-v1','s05-gadget7-v1'),("meta['wire_offset']==10 and meta['false_wire']==8 and meta['true_wire']==9","meta['wire_offset']==9 and meta['false_wire']==7 and meta['true_wire']==8"),('1<=k<=13','1<=k<=12'),("meta['output']==9+k","meta['output']==8+k"),('10+g','9+g'),('full256-input','full128-input'),("evaluate(gates,row['mask'],8)","evaluate(gates,row['mask'],7)"),("'verified_inputs':256","'verified_inputs':128"),("'meets_gadget_12_gate_limit':k<=12","'meets_gadget_11_gate_limit':k<=11"),("'wire_offset':10,'gates':gates,'output':9+k","'wire_offset':9,'gates':gates,'output':8+k"),('13gatepositive control','12gatepositive control')]
control=[('gadget8','gadget7'),('orch/S06','orch/S05'),('positive13','positive12'),('bad12','bad11'),('generic12','generic11'),("row['mask'],8","row['mask'],7"),('row_values[10+g]','row_values[9+g]'),('range(256)','range(128)'),('bad,mask,8','bad,mask,7'),("validation['gate_count']==13","validation['gate_count']==12"),('meets_gadget_12_gate_limit','meets_gadget_11_gate_limit'),('G.build(12)','G.build(11)'),('range(12)','range(11)'),('rng.randrange(10+g)','rng.randrange(9+g)'),('all256','all128'),("'row_completeness_inputs':256","'row_completeness_inputs':128"),("'gadget_gates':12","'gadget_gates':11")]
records=[]
for parent,out,edits in [('build_gadget8.py','build_gadget7.py',build),('validate_gadget8.py','validate_gadget7.py',validator),('control_gadget8.py','control_gadget7.py',control)]:
 raw=(P/parent).read_bytes();assert hashlib.sha256(raw).hexdigest()==pins[parent];(D/parent).write_bytes(raw);s=raw.decode();records_edits=[]
 for a,b in edits:
  assert a in s,(parent,a);records_edits.append(dict(old=a,new=b,count=s.count(a)));s=s.replace(a,b)
 with (H/out).open('x') as f:f.write(s)
 (D/(out+'.diff')).write_text(''.join(difflib.unified_diff(raw.decode().splitlines(True),s.splitlines(True),fromfile=parent,tofile=out)))
 records.append(dict(parent=parent,parent_sha256=pins[parent],output=out,output_sha256=hashlib.sha256(s.encode()).hexdigest(),edits=records_edits))
(D/'derivation.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps([{k:v for k,v in r.items() if k!='edits'} for r in records]))
