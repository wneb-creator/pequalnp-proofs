#!/usr/bin/env python3
"""Generate gadget7 fixtures and scalar/BCP controls; no production SAT search."""
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import random
import sys
import time

sys.dont_write_bytecode=True
OWN=Path('/tmp/oec/pequalnp-pilot-18/orch/S05')
OUT=OWN/'gadget7-v1'


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
G=load('gadget_generator',OWN/'build_gadget7.py')
V=load('gadget_validator',OWN/'validate_gadget7.py')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,value):p.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def holds(c,a):return any(a[abs(x)]==(x>0) for x in c)


def model(meta,gates):
    assignment={}
    values=[V.evaluate(gates,row['mask'],7) for row in meta['rows']]
    for g,(op,left,right) in enumerate(gates):
        record=meta['gate_records'][g];assignment[record['op']]=op=='and'
        for side,port in [('left',left),('right',right)]:
            assignment.update({var:wire==port for wire,var in enumerate(record[side])})
        for ri,row_values in enumerate(values):
            assignment[record['left_values'][ri]]=row_values[left]
            assignment[record['right_values'][ri]]=row_values[right]
            assignment[record['outputs'][ri]]=row_values[9+g]
    assert set(assignment)==set(range(1,meta['variables']+1))
    return assignment


def model_bytes(assignment):
    literals=[i if assignment[i] else -i for i in sorted(assignment)]
    return ('s SATISFIABLE\n'+'\n'.join('v '+' '.join(map(str,literals[i:i+100]))+' 0' for i in range(0,len(literals),100))+'\n').encode()


def bcp(clauses):
    assignment={};proof=[]
    while True:
        changed=False
        for clause in clauses:
            if any(abs(x) in assignment and assignment[abs(x)]==(x>0) for x in clause):continue
            unassigned=[x for x in clause if abs(x) not in assignment]
            if not unassigned:return assignment,proof,True
            if len(unassigned)==1:
                x=unassigned[0];assignment[abs(x)]=x>0;proof.append([x]);changed=True
        if not changed:return assignment,proof,False


def reject(label,fn,results):
    try:fn()
    except (ValueError,AssertionError) as err:results.append({'name':label,'reason':str(err)})
    else:raise AssertionError('negative control accepted: '+label)


def main():
    start=time.monotonic();family=G.prepare(OUT)
    circuits=json.loads((OUT/'circuits.json').read_text());positive=circuits['positive12'];bad=circuits['bad11']
    assert V.gadget_errors(positive)==[]
    errors=V.gadget_errors(bad)
    for mask in range(128):
        enabled={v for i,v in enumerate(V.VERTICES) if mask>>i&1}
        want=any(a in enabled and b in enabled for a,b in V.GADGET_EDGES)
        assert V.evaluate(bad,mask,7)[-1]==(want or {0,2,4}.issubset(enabled))
    assert errors and all(not e['expected'] and e['actual'] for e in errors)
    full_bad=V.extend_full(bad);full_positive=V.extend_full(positive)
    bad_global=[]
    for mask in range(2048):
        wanted=any(mask>>a&1 and mask>>b&1 for a,b in V.FULL_EDGES)
        assert V.evaluate(full_positive,mask,11)[-1]==wanted
        if V.evaluate(full_bad,mask,11)[-1]!=wanted:bad_global.append(mask)
    assert bad_global==[21,29,85,149]
    positive_meta=json.loads((OUT/'positive12-pinned.json').read_text())
    positive_assignment=model(positive_meta,positive);positive_stdout=model_bytes(positive_assignment)
    (OUT/'positive12.model.stdout').write_bytes(positive_stdout)
    validation=V.validate((OUT/'positive12-pinned.cnf').read_bytes(),(OUT/'positive12-pinned.json').read_bytes(),positive_stdout,
        sha(OUT/'positive12-pinned.cnf'),sha(OUT/'positive12-pinned.json'))
    assert validation['status']=='VALIDATED_GADGET' and validation['gate_count']==12
    assert not validation['meets_gadget_11_gate_limit'] and not validation['meets_full21_gate_limit']
    assert validation['full11_gate_count']==22
    dump(OUT/'positive12.validation.json',validation)
    bcp_results=[]
    for name in ['positive12-pinned','bad11-pinned']:
        lines=(OUT/(name+'.cnf')).read_text().splitlines();clauses=[[int(x) for x in line.split()[:-1]] for line in lines[1:]]
        assignment,proof,conflict=bcp(clauses)
        assert conflict==(name=='bad11-pinned')
        if not conflict:assert assignment==positive_assignment and all(holds(c,assignment) for c in clauses)
        if conflict:
            (OUT/'bad11-pinned.rup').write_text(''.join(' '.join(map(str,c))+' 0\n' for c in proof)+'0\n')
        bcp_results.append({'case':name,'derived_assignments':len(assignment),'conflict':conflict,'proof_units':len(proof)})
    bad_meta=json.loads((OUT/'bad11-pinned.json').read_text())
    bad_stdout=model_bytes(model(bad_meta,bad));(OUT/'bad11.model.stdout').write_bytes(bad_stdout)
    negatives=[]
    pos_raw=(OUT/'positive12-pinned.cnf').read_bytes();pos_meta_raw=(OUT/'positive12-pinned.json').read_bytes()
    cp,mp=sha(OUT/'positive12-pinned.cnf'),sha(OUT/'positive12-pinned.json')
    reject('pinned_bad11_rejected_by_full_model_validator',lambda:V.validate((OUT/'bad11-pinned.cnf').read_bytes(),(OUT/'bad11-pinned.json').read_bytes(),bad_stdout,sha(OUT/'bad11-pinned.cnf'),sha(OUT/'bad11-pinned.json')),negatives)
    reject('wrong_CNF_pin',lambda:V.validate(pos_raw,pos_meta_raw,positive_stdout,'0'*64,mp),negatives)
    reject('incomplete_model',lambda:V.validate(pos_raw,pos_meta_raw,b's SATISFIABLE\nv 1 0\n',cp,mp),negatives)
    reject('contradictory_assignment',lambda:V.validate(pos_raw,pos_meta_raw,positive_stdout+b'v 1 -1 0\n',cp,mp),negatives)
    reject('ambiguous_SAT_status',lambda:V.validate(pos_raw,pos_meta_raw,positive_stdout+b's UNSATISFIABLE\n',cp,mp),negatives)
    reject('unknown_status',lambda:V.validate(pos_raw,pos_meta_raw,positive_stdout.replace(b'SATISFIABLE',b'UNKNOWN'),cp,mp),negatives)
    # Separate Boolean relation audit checks every assignment, not just satisfying gate evaluations.
    kernel_checks=0
    for op,a,b,y in itertools.product([False,True],repeat=4):
        c=[[-1,-4,2],[-1,-4,3],[-1,4,-2,-3],[1,4,-2],[1,4,-3],[1,-4,2,3]]
        ass={1:op,2:a,3:b,4:y}
        assert all(holds(x,ass) for x in c)==(y==((a and b) if op else (a or b)));kernel_checks+=1
    # Random unrestricted circuits include repeated ports, free constants, dead gates and junk ANDs.
    rng=random.Random(1342068);base,meta=G.build(11);rows=meta['rows'];random_clause_checks=0
    for trial in range(64):
        gates=[]
        for g in range(11):
            a,b=sorted([rng.randrange(9+g),rng.randrange(9+g)]);gates.append([rng.choice(['and','or']),a,b])
        assignment=model(meta,gates)
        assert all(holds(c,assignment) for c in base.clauses[:-len(rows)])
        encoded_correct=all(holds(c,assignment) for c in base.clauses[-len(rows):])
        assert encoded_correct==(not V.gadget_errors(gates));random_clause_checks+=len(base.clauses)
    row_cover=[]
    for mask in range(128):
        enabled={v for i,v in enumerate(V.VERTICES) if mask>>i&1}
        target=any(a in enabled and b in enabled for a,b in V.GADGET_EDGES)
        witnesses=[r['mask'] for r in rows if r['target']==target and ((r['mask']&mask)==r['mask'] if target else (r['mask']&mask)==mask)]
        assert witnesses;row_cover.append({'input':mask,'target':target,'witness':witnesses[0]})
    dump(OUT/'row-completeness.json',row_cover)
    dump(OUT/'bad11.full-errors.json',{'gadget_errors':errors,'full11_errors':bad_global,'exact_wrong_function':'gadget_target OR x0*x2*x4','gadget_gates':11,'full11_gates':21,'not_a_witness':True})
    result={'status':'PASS_SCALAR_BCP_AND_FULL_VALIDATION_CONTROLS_INDEPENDENT_REVIEW_PENDING',
        'generator_sha256':sha(OWN/'build_gadget7.py'),'validator_sha256':sha(OWN/'validate_gadget7.py'),'control_source_sha256':sha(Path(__file__)),
        'family':family,'positive12_all128':True,'positive12_extension_all2048':True,
        'bad11_errors':errors,'bad11_full11_errors':bad_global,'BCP_controls':bcp_results,
        'gate_kernel_truth_assignments':kernel_checks,'random_circuits':64,'random_clause_checks':random_clause_checks,
        'row_completeness_inputs':128,'negative_controls':negatives,'elapsed_seconds':time.monotonic()-start,
        'solver_launched':False,'generic11_verdict':'UNSOLVED','scope':'Construction gadget only. Pinned bad11 BCP contradiction does not exclude generic11, any whole21 circuit, or a shard.'}
    dump(OUT/'controls.json',result);print(json.dumps(result,indent=2,sort_keys=True))


if __name__=='__main__':main()
