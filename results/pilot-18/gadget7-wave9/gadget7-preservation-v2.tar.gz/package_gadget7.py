from pathlib import Path
import json,hashlib,datetime,fcntl
H=Path('/tmp/oec/pequalnp-pilot-18/orch/S05');P=H.parent/'S06'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
parents={'build_gadget8.py':'3ca5274e1a394aff25e8f633bfc07ca5dd9ed2163b43db321dfba218e6b1ac17','validate_gadget8.py':'60e877fd3bdb11d134633519482b67ca82478c55a00350e34a935ddd194054cb','control_gadget8.py':'d08d46bac760773620707aff8e1c020f837f904f297b56b8b5bab028a993f923'}
for n,h in parents.items():assert sha(P/n)==h and sha(H/'gadget7-source-derivation'/n)==h
family=json.load(open(H/'gadget7-v1/family.json'))['family'];control=json.load(open(H/'gadget7-v1/controls.json'));tiny=json.load(open(H/'gadget7-v1/tiny-controls.json'))
assert control['generic11_verdict']=='UNSOLVED' and tiny['generic11_solved'] is False
files=sorted([p for folder in ['gadget7-v1','gadget7-source-derivation'] for p in (H/folder).rglob('*') if p.is_file()]+[H/n for n in ['build_gadget7.py','validate_gadget7.py','control_gadget7.py','derive_gadget7.py','derive_gadget7.stdout','derive_gadget7.stderr','gadget7-controls.stdout','gadget7-controls.stderr','run_gadget7_tiny_controls.py','gadget7-tiny-controls.stdout','gadget7-tiny-controls.stderr','gadget7-README.md','package_gadget7.py','gadget7_lift.md','gadget7-lift-handoff.json']])
records={str(p.relative_to(H)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files}
generic=next(e for e in family if e['name']=='generic11')
d=dict(status='READY_MAIN_REVIEW_GENERIC11_UNSOLVED_NO_PRODUCTION',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),generator_sha256=sha(H/'build_gadget7.py'),validator_sha256=sha(H/'validate_gadget7.py'),control_source_sha256=sha(H/'control_gadget7.py'),parents_unchanged=parents,generic11=generic,family=family,files=records,runner_acceptance=dict(status='VALIDATED_GADGET',verified_inputs=128,full11_verified_inputs=2048,meets_gadget_11_gate_limit=True,meets_full21_gate_limit=True,provenance_keys=['cnf_sha256','metadata_sha256','solver_stdout_sha256','validator_sha256']),scope='Only seven-input gadget synthesis. Exact11SAT givesfull21 viaexplicit10-gateextension. GenericUNSATwouldexcludeonlythisconstruction. BothactualpinnedproofsapplyONLYbad11fixture. No genericproduction orLean; mainownsrunnercopy/review/launch.')
p=H/'gadget7-handoff.json'
with p.open('x') as f:json.dump(d,f,indent=2,sort_keys=True);f.write('\n')
msg=f'S05 SEVEN-INPUT GENERIC11 READY_MAIN/S08: gadget7-handoff.json SHA{sha(p)}, {len(records)}fullartifacts. Generator{d["generator_sha256"]};validator{d["validator_sha256"]}. Generic11 {generic["variables"]}vars/{generic["clauses"]}clauses/16rows(9edges+7maxnegative),CNF{generic["cnf_sha256"]},metadata{generic["metadata_sha256"]}. Exacttargetonvertices[0,2,4,5,8,9,10];allconstants/repeatedports/deadgates/dirtyANDs allowed,ONLYcommutativeorder+outputlastpadding. DerivedexactpinnedS06sourceswithfullparents/diffs/derivation; original8sourcesunchanged. Full128+full2048validator uses9-gateR+OR(total10); requireverified_inputs128andmeets_gadget_11_gate_limitTRUEplusfull21TRUE/exact4provenances inMAINfreshretainer. Positive12constructed936assignment ANDactualpinnedsolverSAT bothCLI0/full128/full2048/22gates,bothlimitflagsFALSE. Bad11=G OR024 hasonebadlocalinput/fullFP21,29,85,149; BCP835units/RUPchecker0 plusactualpinnedsolver20/DRATchecker0VERIFIED_UNSATONLYfixture. All7tinychildcontrols3CPU5wall512MiB8MiB caps,~0.28aggregate;64randomcircuits700800clausechecks/16kernel/128rowcoverage/6negativevalidatorsPASS. Generic11UNSOLVED,noproduction/no8/mainrunneredits. READMEexactrunnerkey/countdelta. Readyforindependentreview/ownrunnercopy.'
ts=datetime.datetime.now(datetime.timezone.utc).isoformat()
with open('/tmp/oec/pequalnp-pilot-18/orch-notes.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 with open('/workspace/pequalnp-proofs/results/orch/NOTES.md','a') as f:f.write('\n- '+ts+' — '+msg+'\n')
with open('/workspace/pequalnp-proofs/results/orch/lemmas/S05-algebraic-construction.md','a') as f:f.write('\n'+msg+'\n')
print(json.dumps(dict(handoff_sha256=sha(p),artifacts=len(records),generic11=generic,generator_sha256=d['generator_sha256'],validator_sha256=d['validator_sha256'])))
