#!/usr/bin/env python3
"""Validate a complete SAT model, all128 gadget rows, and its full11 extension."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

VERTICES=[0,2,4,5,8,9,10]
GADGET_EDGES=[(0,9),(2,5),(4,8),(5,8),(5,9),(8,9),(0,10),(2,10),(4,10)]
FULL_EDGES=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]


def require(ok,message):
    if not ok:raise ValueError(message)
def digest(raw):return hashlib.sha256(raw).hexdigest()


def evaluate(gates,mask,n):
    values=[bool(mask>>v&1) for v in range(n)]+[False,True]
    for g,(op,a,b) in enumerate(gates):
        require(op in ['and','or'] and type(a) is int and type(b) is int and 0<=a<=b<n+2+g,'malformed decoded gate')
        values.append((values[a] and values[b]) if op=='and' else (values[a] or values[b]))
    return values


def gadget_errors(gates):
    errors=[]
    for mask in range(128):
        enabled={v for i,v in enumerate(VERTICES) if mask>>i&1}
        want=any(a in enabled and b in enabled for a,b in GADGET_EDGES)
        got=evaluate(gates,mask,7)[-1]
        if got!=want:errors.append({'local_mask':mask,'global_vertices':sorted(enabled),'expected':want,'actual':got})
    return errors


def extend_full(gates):
    full=[]
    def wire(w):
        return VERTICES[w] if w<7 else w+4
    for op,a,b in gates:full.append([op,*sorted([wire(a),wire(b)])])
    gadget_output=13+len(gates)-1
    def add(op,a,b):
        full.append([op,min(a,b),max(a,b)]);return 13+len(full)-1
    # Nine gates for14,18,36,37,67,6-10,79, then one union gate.
    q=add('or',3,7);q=add('or',q,10);star6=add('and',6,q)
    q=add('or',3,9);star7=add('and',7,q)
    q=add('or',4,8);star1=add('and',1,q)
    q=add('or',star6,star7);rest=add('or',q,star1)
    add('or',gadget_output,rest)
    require(len(full)==len(gates)+10,'extension gate count')
    return full


def validate(cnf_raw,metadata_raw,model_raw,cnf_sha,metadata_sha):
    require(digest(cnf_raw)==cnf_sha and digest(metadata_raw)==metadata_sha,'input hash mismatch')
    meta=json.loads(metadata_raw)
    require(meta['format']=='s05-gadget7-v1' and meta['vertices']==VERTICES,'wrong gadget metadata')
    require(meta['edges']==[list(e) for e in GADGET_EDGES],'wrong target edges')
    require(meta['wire_offset']==9 and meta['false_wire']==7 and meta['true_wire']==8,'wrong wire constants')
    k=meta['gate_count'];n=meta['variables']
    require(type(k) is int and 1<=k<=12 and meta['output']==8+k,'wrong gate/output bounds')
    require(type(n) is int and n>0,'invalid variable bound')
    require(meta['cnf_sha256']==cnf_sha,'metadata CNF binding mismatch')
    lines=cnf_raw.decode('ascii').splitlines()
    require(lines[0]==f"p cnf {n} {meta['clauses']}",'DIMACS header mismatch')
    clauses=[]
    for line in lines[1:]:
        row=[int(x) for x in line.split()]
        require(row and row[-1]==0 and all(0<abs(x)<=n for x in row[:-1]),'invalid DIMACS clause')
        clauses.append(row[:-1])
    require(len(clauses)==meta['clauses'],'DIMACS count mismatch')
    assignment={};verdicts=[]
    for line in model_raw.decode('ascii').splitlines():
        if line.startswith('s '):verdicts.append(line.strip())
        if not line.startswith('v '):continue
        for token in line.split()[1:]:
            literal=int(token)
            if literal==0:continue
            require(1<=abs(literal)<=n,'model literal outside variable bound')
            require(abs(literal) not in assignment or assignment[abs(literal)]==(literal>0),'contradictory model assignment')
            assignment[abs(literal)]=literal>0
    require(verdicts==['s SATISFIABLE'],'missing/ambiguous SAT verdict')
    require(set(assignment)==set(range(1,n+1)),'incomplete model')
    for i,clause in enumerate(clauses):
        require(any(assignment[abs(x)]==(x>0) for x in clause),f'CNF clause {i+1} violated')
    records=meta['gate_records'];require(len(records)==k,'wrong gate record count')
    gates=[]
    for g,record in enumerate(records):
        chosen=[]
        for side in ['left','right']:
            require(len(record[side])==9+g and len(set(record[side]))==9+g,'wrong selector dimension')
            wires=[w for w,x in enumerate(record[side]) if assignment[x]]
            require(len(wires)==1,'selector is not one-hot');chosen.append(wires[0])
        a,b=chosen;require(a<=b,'unordered operands')
        gates.append(['and' if assignment[record['op']] else 'or',a,b])
    require(not gadget_errors(gates),'decoded gadget fails full128-input validation')
    for ri,row in enumerate(meta['rows']):
        values=evaluate(gates,row['mask'],7)
        for g,record in enumerate(records):
            _,a,b=gates[g]
            require(assignment[record['left_values'][ri]]==values[a] and assignment[record['right_values'][ri]]==values[b]
                and assignment[record['outputs'][ri]]==values[9+g],'encoded row/internal value differs from decoded circuit')
    full=extend_full(gates)
    for mask in range(2048):
        require(evaluate(full,mask,11)[-1]==any(mask>>a&1 and mask>>b&1 for a,b in FULL_EDGES),'full11 extension fails')
    return {'status':'VALIDATED_GADGET','verified_inputs':128,'full11_verified_inputs':2048,
        'gate_count':k,'meets_gadget_11_gate_limit':k<=11,'full11_gate_count':len(full),
        'meets_full21_gate_limit':len(full)<=21,'cnf_clauses_checked':len(clauses),
        'gadget':{'vertices':VERTICES,'wire_offset':9,'gates':gates,'output':8+k},
        'full11_circuit':{'wire_offset':13,'gates':full,'output':13+len(full)-1},
        'provenance':{'cnf_sha256':cnf_sha,'metadata_sha256':metadata_sha,'solver_stdout_sha256':digest(model_raw),
            'validator_sha256':digest(Path(__file__).read_bytes())},
        'scope':'Exact gadget and explicit full11 extension only.12gatepositive control is not a21gate witness; Lean verification remains separate.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('cnf',type=Path);parser.add_argument('solver_stdout',type=Path);parser.add_argument('report',type=Path)
    parser.add_argument('--cnf-sha256',required=True);parser.add_argument('--metadata-sha256',required=True);args=parser.parse_args()
    require(not args.report.exists() and not args.report.is_symlink(),'fresh report required')
    try:
        result=validate(args.cnf.read_bytes(),args.cnf.with_suffix('.json').read_bytes(),args.solver_stdout.read_bytes(),args.cnf_sha256,args.metadata_sha256)
        code=0
    except Exception as error:
        result={'status':'INVALID','reason':type(error).__name__+': '+str(error)};code=2
    args.report.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['gadget','full11_circuit']},sort_keys=True))
    return code


if __name__=='__main__':sys.exit(main())
