import json,hashlib,itertools,collections,pathlib,datetime
R=pathlib.Path('/tmp/oec/pequalnp-pilot-18'); S=R/'orch/S05'
def sha(b):return hashlib.sha256(b).hexdigest()
h=json.loads((S/'gadget7-handoff.json').read_bytes())
for name,info in h['files'].items():
 b=(S/name).read_bytes();assert len(b)==info['bytes'] and sha(b)==info['sha256'],name
m=json.loads((S/'gadget7-v1/generic11.json').read_bytes())
V=[0,2,4,5,8,9,10];E=[(0,9),(2,5),(4,8),(5,8),(5,9),(8,9),(0,10),(2,10),(4,10)]
L=[(V.index(a),V.index(b)) for a,b in E]
def target(x):return any((x>>a)&(x>>b)&1 for a,b in L)
pos=[(1<<a)|(1<<b) for a,b in L];neg=[x for x in range(128) if not target(x) and all(x>>i&1 or target(x|1<<i) for i in range(7))]
assert m['rows']==[{'mask':x,'target':True} for x in pos]+[{'mask':x,'target':False} for x in neg]
for x in range(128):
 assert any(x&e==e for e in pos)==bool(target(x))
 assert any(x&n==x for n in neg)==(not target(x))
clauses=[];used=[]
def emit(*c):clauses.append(tuple(c))
for g,rec in enumerate(m['gate_records']):
 for key in ['op','left','right','left_values','right_values','outputs']:
  v=rec[key];used.extend(v if isinstance(v,list) else [v])
 for side in ['left','right']:
  a=rec[side];emit(*a)
  for i,j in itertools.combinations(a,2):emit(-i,-j)
 for a in range(9+g):
  for b in range(a):emit(-rec['left'][a],-rec['right'][b])
 for r,row in enumerate(m['rows']):
  for side,val in [('left','left_values'),('right','right_values')]:
   y=rec[val][r]
   for w,s in enumerate(rec[side]):
    if w<9:
     v=bool(row['mask']>>w&1) if w<7 else w==8
     emit(-s,y if v else -y)
    else:
     z=m['gate_records'][w-9]['outputs'][r];emit(-s,-y,z);emit(-s,y,-z)
  op,a,b,y=rec['op'],rec['left_values'][r],rec['right_values'][r],rec['outputs'][r]
  emit(-op,-y,a);emit(-op,-y,b);emit(-op,y,-a,-b);emit(op,y,-a);emit(op,y,-b);emit(op,-y,a,b)
for r,row in enumerate(m['rows']):emit(m['gate_records'][-1]['outputs'][r]*(1 if row['target'] else -1))
assert used==list(range(1,m['variables']+1))
raw=('p cnf '+str(m['variables'])+' '+str(len(clauses))+'\n'+''.join(' '.join(map(str,c))+' 0\n' for c in clauses)).encode()
assert raw==(S/'gadget7-v1/generic11.cnf').read_bytes()
for op,a,b,y in itertools.product([False,True],repeat=4):
 assign={1:op,2:a,3:b,4:y}
 cs=[(-1,-4,2),(-1,-4,3),(-1,4,-2,-3),(1,4,-2),(1,4,-3),(1,-4,2,3)]
 holds=all(any(assign[abs(z)]==(z>0) for z in c) for c in cs)
 assert holds==(y==((a and b) if op else (a or b)))
c=json.loads((S/'gadget7-v1/positive12-actual-cli.validation.json').read_bytes())
assert c['verified_inputs']==128 and c['full11_verified_inputs']==2048 and c['full11_gate_count']==22 and c['meets_full21_gate_limit'] is False
F=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
G=c['full11_circuit']['gates'];assert len(G)==22
for x in range(2048):
 a=[bool(x>>i&1) for i in range(11)]+[False,True]
 for op,u,v in G:
  assert 0<=u<len(a) and 0<=v<len(a) and op in ['and','or']
  a.append(a[u] and a[v] if op=='and' else a[u] or a[v])
 assert a[c['full11_circuit']['output']]==any(x>>u&x>>v&1 for u,v in F)
# Independently confirm the ten-gate extension covers exactly the missing edges.
rem={(1,4),(1,8),(3,6),(3,7),(6,7),(6,10),(7,9)}
assert set(E)|rem==set(F) and not set(E)&rem
for x in range(2048):
 z=lambda i:bool(x>>i&1)
 rest=z(6) and (z(3) or z(7) or z(10)) or z(7) and (z(3) or z(9)) or z(1) and (z(4) or z(8))
 assert rest==any(z(a) and z(b) for a,b in rem)
out={'status':'PASS_INDEPENDENT_GADGET7_ENCODING_AND_LIFT','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'handoff_sha256':sha((S/'gadget7-handoff.json').read_bytes()),'bound_files':len(h['files']),'cnf_bytes_independently_rebuilt':len(raw),'cnf_clauses':len(clauses),'cnf_sha256':sha(raw),'boundary_rows':len(m['rows']),'full_gadget_inputs':128,'full_extension_inputs':2048,'positive_control_gates':22,'generic11_unsolved':True,'scope':'Construction only; no global lower bound or Lean acceptance.'}
(R/'orch/MAIN/main-gadget7-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
