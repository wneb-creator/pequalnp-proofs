from pathlib import Path
import importlib.util,json,hashlib,subprocess,resource,os,time,copy,sys
from types import SimpleNamespace
sys.dont_write_bytecode=True
ROOT=Path('/tmp/oec/pequalnp-pilot-18');H=ROOT/'orch/S05';S=ROOT/'orch/S06';R=H/'kissat-sat-only-review';R.mkdir(exist_ok=False);(R/'source').mkdir();(R/'real').mkdir();(R/'schema').mkdir()
PINS={S/'sat_only_gadget_kissat.py':'fd05c03210c7d815ec81f0f3a292ef5d7eeb92f4380c8f4c5fde18d10aaa6bcd',S/'offline_checked_cadical.py':'aa5d13bb83ab79e47b9794809c3c06dc153544975cd1131afbdeaef7c18d484a',S/'validate_gadget8.py':'60e877fd3bdb11d134633519482b67ca82478c55a00350e34a935ddd194054cb',H/'validate_gadget7.py':'1eeceaaf05207387246634a12238389ba4059a5bf3cc43739edcf0173e8141bb',ROOT/'solver/kissat-4.0.4-linux-amd64':'21da5d984e38b74f620f14c62442f834f27b9158decdb722540d97f98aac93a1'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
for p,h in PINS.items():
 assert sha(p)==h and p.is_file() and not p.is_symlink()
 if p.suffix=='.py':(R/'source'/p.name).write_bytes(p.read_bytes())
runner=S/'sat_only_gadget_kissat.py';records=[];t=time.monotonic()
def launch(gadget,name,base,abort=False,wrong_hash=False):
 out=R/'real'/name;cnf=base.with_suffix('.cnf');meta=base.with_suffix('.json');abort_file=R/(name+'.abort')
 if abort:abort_file.write_text('CONTROL_ABORT\n')
 command=['python3','-B',str(runner),str(cnf),str(out),'--gadget',str(gadget),'--cnf-sha256','0'*64 if wrong_hash else sha(cnf),'--metadata-sha256',sha(meta),'--solver-seconds','5','--abort-file',str(abort_file)]
 def outer_limits():
  resource.setrlimit(resource.RLIMIT_CPU,(12,12));resource.setrlimit(resource.RLIMIT_AS,(4096*1024*1024,4096*1024*1024));os.nice(10)
 start=time.monotonic()
 with (R/(name+'.outer.stdout')).open('x') as stdout,(R/(name+'.outer.stderr')).open('x') as stderr:p=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=12,preexec_fn=outer_limits)
 assert p.returncode==2
 d=json.load(open(out/'result.json'));assert d['status']=='UNKNOWN' and d['exit_code']==2 and d['validated_SAT'] is False and d['accepted_CNF_UNSAT'] is False and d['proof_generation'] is False
 assert d['state']=='FINISHED' and d==json.load(open(out/'progress.json'))
 assert not list(out.glob('*.drat')) and not list(out.glob('*.rup')) and 'checker' not in d['phases']
 for log,x in d['logs'].items():assert sha(out/log)==x['sha256'] and (out/log).stat().st_size==x['bytes']
 if abort or wrong_hash:
  assert not d['phases'] and ('abort' in d['reason'] if abort else 'SHA256 mismatch' in d['reason'])
 else:
  assert sha(out/'instance.cnf')==sha(cnf) and sha(out/'instance.json')==sha(meta)
  cmd=d['phases']['solver']['command'];assert cmd==[str(ROOT/'solver/kissat-4.0.4-linux-amd64'),'--sat','--no-color','--statistics',str(out/'instance.cnf')]
  assert d['phases']['solver']['reason'] is None
  if 'bad' in name:
   assert d['phases']['solver']['exit_code']==20 and d['solver_verdicts']==['s UNSATISFIABLE'] and d['reason']=='UNCERTIFIED_UNSAT_NO_PROOF' and d['uncertified_UNSAT'] is True and 'validator' not in d['phases']
  else:
   assert d['phases']['solver']['exit_code']==10 and d['solver_verdicts']==['s SATISFIABLE'] and d['phases']['validator']['exit_code']==0
   v=d['validation_report'];assert v['verified_inputs']==(128 if gadget==7 else 256) and v['full11_verified_inputs']==2048 and v['full11_gate_count']==22
   assert v['meets_full21_gate_limit'] is False and v['meets_gadget_'+str(11 if gadget==7 else 12)+'_gate_limit'] is False
   assert 'gate limit exceeded' in d['reason']
   assert v['provenance']=={'cnf_sha256':sha(cnf),'metadata_sha256':sha(meta),'solver_stdout_sha256':sha(out/'solver.stdout'),'validator_sha256':PINS[H/'validate_gadget7.py' if gadget==7 else S/'validate_gadget8.py']}
 rec=dict(name=name,gadget=gadget,command=command,outer_exit=p.returncode,elapsed_seconds=time.monotonic()-start,result_sha256=sha(out/'result.json'),status=d['status'],reason=d['reason']);records.append(rec);dump(R/(name+'.execution.json'),rec)
for n,owner in [(7,H),(8,S)]:
 launch(n,f'g{n}-positive',owner/f'gadget{n}-v1'/('positive12-pinned' if n==7 else 'positive13-pinned'))
 launch(n,f'g{n}-bad',owner/f'gadget{n}-v1'/('bad11-pinned' if n==7 else 'bad12-pinned'))
launch(7,'abort-before-start',H/'gadget7-v1/positive12-pinned',abort=True)
launch(7,'wrong-CNF-hash',H/'gadget7-v1/positive12-pinned',wrong_hash=True)
spec=importlib.util.spec_from_file_location('reviewed_sat_only',runner);M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
schema=[]
for n in (7,8):
 output=R/'schema'/str(n);output.mkdir();(output/'solver.stdout').write_text('SYNTHETIC_ACCEPT_REPORT_ONLY_NOT_A_MODEL\n')
 args=SimpleNamespace(gadget=n,cnf_sha256='1'*64,metadata_sha256='2'*64,output=output);c=M.CONFIG[n]
 good=dict(status='VALIDATED_GADGET',verified_inputs=c['rows'],full11_verified_inputs=2048,gate_count=c['gates'],full11_gate_count=21,meets_full21_gate_limit=True,provenance=dict(cnf_sha256=args.cnf_sha256,metadata_sha256=args.metadata_sha256,solver_stdout_sha256=sha(output/'solver.stdout'),validator_sha256=c['validator'][1]));good[c['limit']]=True
 M.accept_report(good,args,c);changes=[]
 for key in good:changes.append(('missing-'+key,lambda d,k=key:d.pop(k)))
 for key,value in [('status','UNKNOWN'),('verified_inputs',True),('verified_inputs',127),('full11_verified_inputs',2047),(c['limit'],False),(c['limit'],1),('meets_full21_gate_limit',1),('meets_full21_gate_limit',False),('gate_count',True),('gate_count',0),('gate_count',c['gates']+1),('full11_gate_count',20),('full11_gate_count',22)]:changes.append(('wrong-'+key+'-'+str(value),lambda d,k=key,v=value:d.update({k:v})))
 for key in good['provenance']:changes.append(('wrong-provenance-'+key,lambda d,k=key:d['provenance'].update({k:'0'*64})))
 changes.append(('extra-provenance',lambda d:d['provenance'].update(extra='bad')))
 for name,mutate in changes:
  bad=copy.deepcopy(good);mutate(bad)
  try:M.accept_report(bad,args,c)
  except ValueError as ex:schema.append(dict(gadget=n,name=name,rejected=str(ex)))
  else:raise AssertionError((n,name,'accepted'))
 dump(output/'controls.json',dict(scope='accept_report schema only; synthetic success object is not a candidate/model',synthetic_baseline=good,negative_controls=[x for x in schema if x['gadget']==n]))
for p,h in PINS.items():assert sha(p)==h
assessment=dict(status='PASS_EXACT_SAT_ONLY_KISSAT_RUNNER',source_sha256=PINS[runner],lifecycle_sha256=PINS[S/'offline_checked_cadical.py'],pins={str(p):h for p,h in PINS.items()},source_review=['Pinned unchanged phase supplies sequential children, process groups, parent-death kill, reaping,1536MiBAS,64MiBlogs,wall/abort/disk guards.','Solver command has only CNF positional input and no proof path. No checker phase exists.','Solver20 plus soleUNSAT always UNKNOWN exit2,accepted_CNF_UNSAT false.','Solver10 plus soleSAT only accepts pinnedvalidator0/full128or256/full2048/strictTrueflags/integerconsistentcounts/exactfourprovenances.','Bindings and read-only snapshots checked before and after solver/validator; fresh outputs withinS06/S05 only.'],real_controls=records,schema_rejections=len(schema),synthetic_schema_positive_controls=2,no_exact21_positive_fixture=True,elapsed_seconds=time.monotonic()-t,scope='Independent exactsource/pins/sourceaudit andsix tinyrealcontrols plusstrictschema mutations. No genericsearch. Positive12/13 are overlimit, bad11/12 UNSAT remainsUNKNOWN. Synthetic schema baseline is not a model/witness. Main alone owns production.')
dump(R/'review.json',assessment);print(json.dumps({k:v for k,v in assessment.items() if k not in ['pins','real_controls','source_review']}))
