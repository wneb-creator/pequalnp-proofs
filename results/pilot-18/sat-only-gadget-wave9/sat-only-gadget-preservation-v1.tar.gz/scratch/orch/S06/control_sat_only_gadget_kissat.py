#!/usr/bin/env python3
"""Tiny fixtures and report-decision controls only; no generic search."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import subprocess
import sys
import time
from types import SimpleNamespace

sys.dont_write_bytecode=True
ROOT=Path('/tmp/oec/pequalnp-pilot-18');OWN=ROOT/'orch/S06'
SOURCE=OWN/'sat_only_gadget_kissat.py';PIN='fd05c03210c7d815ec81f0f3a292ef5d7eeb92f4380c8f4c5fde18d10aaa6bcd'
OUT=OWN/'sat-only-gadget-controls-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):return {'bytes':p.stat().st_size,'sha256':sha(p)}
def save(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def require(ok,msg):
    if not ok:raise AssertionError(msg)
def limits():
    resource.setrlimit(resource.RLIMIT_CPU,(10,10));resource.setrlimit(resource.RLIMIT_AS,(2048*1024**2,2048*1024**2))

def run_case(label,gadget,cnf,extra=None):
    output=OUT/label
    command=[sys.executable,'-B',str(SOURCE),str(cnf),str(output),'--gadget',str(gadget),'--cnf-sha256',sha(cnf),'--metadata-sha256',sha(cnf.with_suffix('.json')),'--solver-seconds','5','--abort-file',str(ROOT/'DESK_ERROR.response')]
    if extra:command.extend(extra)
    start=time.monotonic()
    with (OUT/(label+'.outer.stdout')).open('xb') as stdout,(OUT/(label+'.outer.stderr')).open('xb') as stderr:
        result=subprocess.run(command,stdout=stdout,stderr=stderr,cwd=OWN,timeout=15,preexec_fn=limits)
    execution={'command':command,'exit_code':result.returncode,'wall_seconds':time.monotonic()-start,'outer_wall_limit_seconds':15,'outer_cpu_seconds':10,'outer_address_space_mib':2048}
    save(OUT/(label+'.execution.json'),execution)
    require(result.returncode==2,'every real fixture must return UNKNOWN')
    state=json.loads((output/'result.json').read_text())
    require(state==json.loads((output/'progress.json').read_text()),'progress mismatch')
    require(state['source_sha256']==PIN and state['status']=='UNKNOWN' and state['state']=='FINISHED' and state['accepted_CNF_UNSAT'] is False and state['validated_SAT'] is False and state['proof_generation'] is False,'result failclosed')
    require(not any(p.suffix in ['.drat','.rup','.proof'] for p in output.iterdir()),'unexpected proof file')
    expected={phase+suffix for phase in state['phases'] for suffix in ['.stdout','.stderr']}
    require(set(state['logs'])==expected,'exact log keys')
    for name in expected:require(state['logs'][name]==info(output/name),'full log hash')
    if label.startswith('bad'):
        require(set(state['phases'])=={'solver'} and state['phases']['solver']['exit_code']==20 and state['solver_verdicts']==['s UNSATISFIABLE'],'UNSAT fixture path')
        require(state['reason']=='UNCERTIFIED_UNSAT_NO_PROOF' and state['uncertified_UNSAT'] is True,'UNSAT must remain uncertified')
    elif label.startswith('positive'):
        require(set(state['phases'])=={'solver','validator'} and state['phases']['solver']['exit_code']==10 and state['phases']['validator']['exit_code']==0 and state['SAT_indication'] is True,'positive real solver/validator')
        report=state['validation_report'];require(report['full11_gate_count']==22 and report['full11_verified_inputs']==2048 and report['verified_inputs']==2**gadget,'positive full truth')
        require(state['reason']=='ValueError: gadget or full21 gate limit exceeded','positive limit rejection')
    else:require(not state['phases'],'pre-solver rejection')
    return {'status':'PASS','reason':state['reason'],'result_sha256':sha(output/'result.json'),'execution':execution}

def main():
    require(sha(SOURCE)==PIN,'source pin');OUT.mkdir()
    eight=OWN/'gadget8-v1';seven=ROOT/'orch/S05/gadget7-v1'
    actual={}
    for name,gadget,cnf in [('bad12-gadget8',8,eight/'bad12-pinned.cnf'),('positive13-gadget8',8,eight/'positive13-pinned.cnf'),('bad11-gadget7',7,seven/'bad11-pinned.cnf'),('positive12-gadget7',7,seven/'positive12-pinned.cnf')]:actual[name]=run_case(name,gadget,cnf)
    actual['wrong-input-hash']=run_case('wrong-input-hash',8,eight/'bad12-pinned.cnf',['--cnf-sha256','0'*64])
    abort=OUT/'control-abort';abort.write_text('tiny control sentinel\n')
    actual['abort-present']=run_case('abort-present',8,eight/'bad12-pinned.cnf',['--abort-file',str(abort)])
    spec=importlib.util.spec_from_file_location('sat_only_wrapper_controls',SOURCE);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    synthetic=[]
    for gadget in [7,8]:
        config=module.CONFIG[gadget];folder=OUT/f'report-schema-{gadget}';folder.mkdir();(folder/'solver.stdout').write_text('Synthetic schema control only; not a solver model.\n')
        args=SimpleNamespace(gadget=gadget,cnf_sha256='1'*64,metadata_sha256='2'*64,output=folder)
        base={'status':'VALIDATED_GADGET','verified_inputs':2**gadget,'full11_verified_inputs':2048,config['limit']:True,'meets_full21_gate_limit':True,'gate_count':config['gates'],'full11_gate_count':21,'provenance':{'cnf_sha256':args.cnf_sha256,'metadata_sha256':args.metadata_sha256,'solver_stdout_sha256':sha(folder/'solver.stdout'),'validator_sha256':config['validator'][1]}}
        module.accept_report(base,args,config)
        changes=[('wrong-truth-count','verified_inputs',2**gadget-1),('wrong-full-truth','full11_verified_inputs',2047),('integer-gadget-flag',config['limit'],1),('integer-full-flag','meets_full21_gate_limit',1),('over-gadget-count','gate_count',config['gates']+1),('over-full-count','full11_gate_count',22),('boolean-gate-count','gate_count',True),('missing-provenance','provenance',None)]
        for name,key,value in changes:
            report=copy.deepcopy(base);report[key]=value
            try:module.accept_report(report,args,config)
            except ValueError as err:synthetic.append({'gadget':gadget,'case':name,'status':'PASS_REJECTED','reason':str(err)})
            else:raise AssertionError('schema failed to reject '+name)
        for key in base['provenance']:
            report=copy.deepcopy(base);report['provenance'][key]='0'*64
            try:module.accept_report(report,args,config)
            except ValueError as err:synthetic.append({'gadget':gadget,'case':'wrong-'+key,'status':'PASS_REJECTED','reason':str(err)})
            else:raise AssertionError('provenance failed to reject '+key)
    save(OUT/'controls.json',{'status':'PASS_SIX_REAL_WRAPPER_CONTROLS_AND_24_SCHEMA_REJECTIONS','source_sha256':PIN,'control_source_sha256':sha(Path(__file__)),'actual':actual,'synthetic':synthetic,'synthetic_scope':'Only accept_report decision function, not validated candidates or solver runs.','generic_search_launched':False})
    print(json.dumps({'status':'PASS_SIX_REAL_WRAPPER_CONTROLS_AND_24_SCHEMA_REJECTIONS','source_sha256':PIN,'controls_sha256':sha(OUT/'controls.json')}))

if __name__=='__main__':main()
