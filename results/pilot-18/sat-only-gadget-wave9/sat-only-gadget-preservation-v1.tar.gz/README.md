# SAT-only gadget7/gadget8 runner and independent controls

This package freezes runnerfd05c032, parent lifecycleaa5d13, both pinned
validators, both CNF generators for portable recipes, all S06/S05 tiny
controls and reviews, main's source/binding review and both encoder reviews.
Historical pending/not-launched statements refer to their own timestamps.
Both later production runs and launch records are excluded and unread.
Main preserves completed production separately. Gadget7's wider source
and proof-control archive is a separate S05 delivery.

The runner invokes pinned Kissat with --sat --no-color --statistics and
exactly one positional CNF, without a proof path. Solver UNSAT always means
UNCERTIFIED_UNSAT_NO_PROOF/statusUNKNOWN/exit2. Only pinned validation of
every128/256 gadget input, every2048 full input, both gate limits, consistent
gate counts and allfour provenance hashes permits exit10 VALIDATED_SAT.
No exact21 positive fixture exists. The positive12/13 controls validate
full22 circuits and correctly reject; synthetic report baselines are not
models. S06's6 real controls+24 rejections and S05's6 real controls+52
rejections are preserved with complete stdout/stderr and status records.

Extract into a fresh directory, then run:

    python3 -B scratch/orch/S06/restore_sat_only_gadget_archive.py .

Only Python's standard library is needed. The command checks all payloads,
restores six unique CNFs and every copied fixture snapshot using unchanged
generator APIs, checks metadata bytes, verifies72 S06+65 S05 handoff
bindings and every source mapping, and replays four retained positive
models through the archived full validators. It starts no solver/checker.

CNFs are omitted as reproducible bulk; CNF_RECIPES.json binds all aliases.
No executable binary or compiled Python cache is included. Binary hashes
are in BINARY_PINS.json and original records. Source files retain exact
original paths and bytes; replaying the original runner/controls needs
the original workspace layout and exact Kissat binary or a separately
reviewed relocation. Portable restoration requires no source edits and
does not import or execute the pinned runtime wrapper/lifecycle module.

The6 relevant CNFs are the two generic construction targets and four
pinned positive/negative fixtures. The unused larger generic variants
remain in the separate gadget source archives. All preserved UNSAT
observations here are intentionally uncertified UNKNOWN, never exhaustive
gadget/global results. Lean acceptance remains separate.
