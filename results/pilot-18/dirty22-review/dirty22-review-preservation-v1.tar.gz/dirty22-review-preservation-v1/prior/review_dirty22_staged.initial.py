from pathlib import Path
import subprocess,hashlib,json,re,datetime,runpy,fcntl
W=Path('/workspace/pequalnp-proofs');R=Path('/tmp/oec/pequalnp-pilot-18');D=R/'orch/S08/dirty22-staged-review';D.mkdir(exist_ok=False);prefix='results/pilot-18/dirty22-checkpoint/'
h=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):
 q=subprocess.run(['git','--no-pager',*a],cwd=W,capture_output=True);assert q.returncode==0,q.stderr;return q.stdout
head=git('rev-parse','HEAD').decode().strip();names=git('diff','--cached','--name-only','-z').decode().split('\0')[:-1]
assert len(names)==71 and set(names)-{n for n in names if n.startswith(prefix)}=={'results/pilot-18/validation.txt'}
blobs={};index={}
for n in names:
 e=git('ls-files','--stage','--',n).decode().strip();mode,oid,stage=e.split('\t')[0].split();assert mode=='100644' and stage=='0'
 b=git('cat-file','blob',oid);blobs[n]=b;index[n]={'git_blob':oid,'sha256':h(b),'bytes':len(b),'mode':mode};q=D/'snapshot'/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
diff=git('diff','--cached','--binary','--no-ext-diff');(D/'staged.diff').write_bytes(diff)
check=git('diff','--cached','--check');(D/'diff-check.stdout').write_bytes(check)
pkg={n[len(prefix):]:b for n,b in blobs.items() if n.startswith(prefix)};manifest=json.loads(pkg['source-manifest.json']);assert h(pkg['source-manifest.json'])=='30e2012bf8fa4c6c808e15468d85ce7411abee771ec23c92a9bf2f3069929906'
assert len(manifest['files'])==68 and set(pkg)=={x['file'] for x in manifest['files']}|{'README.md','source-manifest.json'}
assert sum(x['bytes'] for x in manifest['files'])==91594
sources={}
for x in manifest['files']:
 p=Path(x['source']);assert p.is_relative_to(R/'orch/S03') or p.is_relative_to(R/'orch/S05');assert not p.is_symlink()
 b=pkg[x['file']];assert len(b)==x['bytes'] and h(b)==x['sha256'] and p.read_bytes()==b,x['file'];sources[str(p)]=b
H=json.loads(pkg['S03/dirty22-certificate-handoff.json']);assert h(pkg['S03/dirty22-certificate-handoff.json'])=='361cd610b831905c5ef95185878101faf2a3d11d2a6f54d5a954df9a05b10b61'
for x in H['artifacts']:
 b=sources[x['path']];assert len(b)==x['bytes'] and h(b)==x['sha256']
lean=pkg['S03/Dirty22Control.lean.txt'].decode();audit=pkg['S03/Dirty22Audit.lean.txt'].decode();gen=json.loads(pkg['S03/Dirty22Control.generation.json'])
assert h(lean.encode())==H['lean_source_sha256']==gen['source_sha256']=='9a7014c902546881f3653782c4dbcc62213e91a6fe67f7faa6e7645029423969'
named=(W/'lean/PEqualNP/Outside/L_meta_1342.lean').read_bytes();assert h(named)==H['named_dependency_sha256']==gen['named_dependency_sha256']=='0e0620c89307cf34be010940037cb187797eea76c85fc8c8a89b9bd1cfc56e5c' and len(named.splitlines())==2069
assert named==git('show',head+':lean/PEqualNP/Outside/L_meta_1342.lean')
assert re.findall(r'^import (.*)$',lean,re.M)==['PEqualNP.Outside.L_meta_1342']
assert re.findall(r'^(?:def|lemma) (\w+)',lean,re.M)==['Dirty22Control','Dirty22Control_monotone','Dirty22Control_size','Dirty22Control_boundary','Dirty22Control_certificate']
assert re.findall(r'^set_option (.*)$',lean,re.M)==['maxRecDepth 10000 in','maxHeartbeats 1000000 in']
assert not re.search(r'\b(sorry|admit|axiom|unsafe|native_decide|run_tac|implemented_by|extern)\b|_root_|"|@\[|^#',lean,re.M)
assert 'namespace PEqualNP.Outside.L_meta_1342_aux\n' in lean and lean.endswith('end PEqualNP.Outside.L_meta_1342_aux\n')
stmt=lean.split('lemma Dirty22Control_certificate :\n',1)[1].split(' := by',1)[0]+'\n';assert stmt==H['exact_statement']==pkg['S03/dirty22-exact-statement.txt'].decode()
assert stmt.rstrip().endswith('C.size ≤ 22') and H['exact_bound']==gen['exact_bound']==22 and not H['final_posted_statement_proved']
assert 'exact target_witness_of_boundary_check Dirty22Control Dirty22Control_monotone Dirty22Control_boundary 22\n    (Nat.le_of_eq Dirty22Control_size)' in lean
assert 'lemma Dirty22Control_size : Dirty22Control.size = 22 := rfl' in lean
assert 'lemma Dirty22Control_boundary : targetBoundaryCheck Dirty22Control = true := by\n  decide' in lean
# Manually reviewed grouping: normalize redundant parentheses and Circuit qualification only.
posted=(R/'statement.txt').read_text();norm=lambda s:re.sub(r'[\s()]','',s.replace('PEqualNP.CircuitLowerBounds.Circuit','Circuit'))
assert norm(posted.replace('≤ 21','≤ 22'))==norm(stmt)
cnames=['PEqualNP.Outside.L_meta_1342_aux.Dirty22Control_'+s for s in ['monotone','size','boundary','certificate']]
assert audit==lean+'\n'+''.join('#print axioms '+n+'\n' for n in cnames)
for label,src in [('dirty22-build','Dirty22Control.lean'),('dirty22-axioms','Dirty22Audit.lean')]:
 b=json.loads(pkg['S03/'+label+'.result.json']);assert b['exit_code']==0 and not b['timeout'] and b['source_unchanged']
 assert b['source_sha256']==h(sources[b['source']]) and b['source'].endswith('/'+src)
 assert b['command']==[str(R/'lean-4.36.0-linux/bin/lake'),'env','lean','-M4000','-j1',b['source']] and b['workdir']==str(W/'lean')
 for k,x in b['logs'].items():assert len(sources[x['path']])==x['bytes'] and h(sources[x['path']])==x['sha256']
assert pkg['S03/dirty22-build.stdout']==pkg['S03/dirty22-build.stderr']==pkg['S03/dirty22-axioms.stderr']==b''
axioms={}
for line in pkg['S03/dirty22-axioms.stdout'].decode().splitlines():
 n=line.split("'")[1];vals=[] if 'does not depend on any axioms' in line else line.split('[',1)[1].rstrip(']').split(', ');axioms[n]=vals
assert axioms==H['axioms'] and set(axioms)==set(cnames) and all(set(v)<={'propext','Classical.choice','Quot.sound'} for v in axioms.values())
# Extract every compiled gate, compare to original JSON and independently check all schedules.
c=json.loads(pkg['S05/shared-factor-compact-complete.json']);assert h(pkg['S05/shared-factor-compact-complete.json'])==H['source_json_sha256']==gen['input_sha256']=='0cd2e6eaa92e2a5cd95d1bd20728ad9157e80b9e88a728ad7033f8af420c1299'
gates=[[op,int(a),int(b)] for op,a,b in re.findall(r'⟨\.(or|and), \[(\d+), (\d+)\]⟩',lean)];assert gates==c['gates'] and len(gates)==22 and c['output']==32 and '⟩], 32⟩' in lean
edges=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
def scalar(c,offset):
 junk=set()
 for x in range(2048):
  w=[bool(x>>i&1) for i in range(11)]+([False,True] if offset==13 else []);target=any(w[u] and w[v] for u,v in edges)
  for k,(op,a,b) in enumerate(c['gates']):
   assert op in ['and','or'] and 0<=a<offset+k and 0<=b<offset+k
   w.append(w[a] and w[b] if op=='and' else w[a] or w[b])
   if op=='and' and w[-1] and not target:junk.add(k)
  assert w[c['output']]==target
 assert sorted(junk)==c['junk_gates'];return sorted(junk)
assert scalar(c,11)==[14];packed=pkg['S05/dirty22-seed-pack/seeds.txt'].decode().splitlines();assert packed.pop(0)=='COVER_ANNEAL 1 4';details=[]
for i in range(4):
 cc=json.loads(pkg[f'S05/dirty22-family/c{i:04d}-k22.baseline22.json']);assert cc['size']==len(cc['gates'])==22 and cc['gate_wire_offset']==13
 count,out=map(int,packed.pop(0).split());assert count==22 and out==cc['output']
 for op,a,b in cc['gates']:assert list(map(int,packed.pop(0).split()))==[1 if op=='and' else 0,a,b]
 details.append({'case':i,'junk':scalar(cc,13),'all2048_inputs':True})
assert all(not s.strip() for s in packed)
val=blobs['results/pilot-18/validation.txt'].decode();old=git('show',head+':results/pilot-18/validation.txt').decode();expected_old=old.replace('TIMING total=201.6 subagents=6','TIMING total=233.6 subagents=6');assert val.startswith(expected_old)
added=val[len(expected_old):];assert 'bound22 partial result, not the posted bound21 theorem' in added and 'no cleanup or posted checker run' in added
assert 'No posted proof or refutation is claimed.' in pkg['README.md'].decode() and 'NOT RUN' in pkg['README.md'].decode()
patterns=runpy.run_path(str(R/'orch/S08/capture_review.py'))['PATTERNS'];hits=[]
for n,b in blobs.items():
 for label,pat in patterns.items():
  if re.search(pat,b.decode(errors='replace')):hits.append({'file':n,'pattern':label})
assert not hits,hits
assert git('diff','--cached','--binary','--no-ext-diff')==diff
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':'PASS_EXACT_STAGED_71_FILE_DIRTY22_PARTIAL_CHECKPOINT','base_HEAD':head,'staged_diff_sha256':h(diff),'staged_files':index,'source_manifest_sha256':h(pkg['source-manifest.json']),'handoff_sha256':h(pkg['S03/dirty22-certificate-handoff.json']),'copied_files':68,'copied_bytes':91594,'all_copies_match_original_sources':True,'compiled_Lean_sha256':H['lean_source_sha256'],'exact_statement':stmt,'bound':22,'original_gate_offset':11,'output_wire':32,'gate_count':22,'source_and_four_schedules_scalar_inputs':10240,'schedule_checks':details,'axioms':axioms,'build_exit_code':0,'audit_exit_code':0,'full_logs_verified':True,'helper_import_scope':'Scratch import of unchanged named2069module. Archive .lean.txt only, not finalPR-import approval. No helper redeclaration; exact existing target_witness bridge used.','named_sha256':h(named),'named_matches_HEAD':True,'validation_change':'Main timing metadata201.6->233.6 and explicitdirty22partial paragraph only. Timing total is reported main metadata, not independently derived elapsed time.','credential_indicators':hits,'posted_checker':'NOT_RUN','posted21_proved':False,'new_Lean_or_solver_or_gitwrite':False,'scope':'Exactstagedresearchsnapshot only; unchangednamedproof remains partial; no PR or acceptance claim.'}
(D/'review.json').write_text(json.dumps(r,indent=2)+'\n');rh=h((D/'review.json').read_bytes())
msg=f'\n- {datetime.datetime.now(datetime.timezone.utc).isoformat()} — S08 URGENT STAGED DIRTY22 PASS: EXACT71INDEXblobs(70checkpointfiles+validation.txt), diffSHA{h(diff)}. Review orch/S08/dirty22-staged-review/review.json SHA{rh}. All68sourcecopies/91594bytes match manifest30e201...9906 andoriginalsources; handoff361cd...0b61 all23bindingsPASS. CompiledLean9a701...3969 exact22gates/output32 matchesoriginalJSON0cd2e6, all10240original+four-scheduleinputs independentlyPASS and packedseedroundtrip exact. ExactpostedpredicatebutBOUND22, sourceusesexistingnamedhelperbridge withscratchOutsideimport only; nohelperredeclaration/forbiddenmechanism/attrs, allowedscopedoptions. Build0/17.69s,audit0/6.83s fullhashboundlogs; fouraxiomsetsallowedonly(sizeNONE). Named2069SHA0e0620 unchangedvsHEAD. Validationonlymainreportedtiming+explicitpartial22paragraph/checkerNOTRUN; nocredentialindicators/no21oracceptanceclaim. FullINDEXsnapshots/diff preserved, no Lean rerun/gitwrite. MAIN MAY PUSH EXACT REVIEWED STAGE NOW.\n'
with (R/'orch-notes.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 with (W/'results/orch/NOTES.md').open('a') as f:f.write(msg)
with (W/'results/orch/lemmas/S08-integration-review.md').open('a') as f:f.write(msg)
print(json.dumps({'verdict':r['verdict'],'review_sha256':rh,'staged_diff_sha256':h(diff),'staged_files':len(names)},indent=2))
