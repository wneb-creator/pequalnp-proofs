# Pure support assembly refinement (new, independent review requested)

Let k selected minimal full-cover supports be proper, nonempty, pairwise
incomparable and have empty common-neighbor sets. Let t=max residual cover
number. Redirect ALL support-copy ORs in their actual clean ancestor union.
At least t gates are removed by the reviewed copy-cover bound. All AND
births and all singleton supports of surviving gates are preserved.

Let B be the actual birth graph in this support model. Its AND ancestor
subcircuit has at least |B| gates by the reviewed birth count. Each selected
support survives at some noncopy OR, since it cannot be an input, constant,
or empty-support AND. These k surviving gates are distinct and outside ALL
AND ancestor cones, because their common-neighbor sets are empty. Thus

    m >= |B| + k + t.

If equality holds (or a relaxed B budget leaves no extra gates), every
selected-support gate has operands inside the AND ancestor subcircuit or
raw inputs. Another selected support cannot be an operand because the
selected supports are incomparable. An additional outside OR gate would
consume an extra gate.

Every supported gate U in the AND ancestor subcircuit satisfies the
following necessary condition: |U|<=1, or there is an owner v in CN(U)
such that every edge vu, u in U, belongs to B. Follow an OR-only path
from U to its first AND; productivity gives an opposite supported input,
and C4-freeness makes the common owner unique when |U|>=2. Its star is a
subset of that AND's birth set. Therefore each selected S must decompose
as S=U union V where both U,V satisfy this useful-support condition.

For an upper budget Bmax containing actual B, useful-support eligibility
only increases. If |Bmax|=17-k-t and actual B is smaller, slack may allow
extra outside ORs, so it is UNSOUND to require two-piece decomposition
solely relative to Bmax without accounting for the slack. Correct finite
test must either (a) know |B| equals that budget, or (b) enumerate exact
actual B, use the appropriate slack, and only apply two-piece decomposition
when slack=0. Generalizing decomposition to at most slack+2 useful leaves
for each output is a safe individual relaxation (shared assembly ignored).

This caution is part of the proposed refinement. No code currently applies
the equality condition to a padded birth set without the required slack.
