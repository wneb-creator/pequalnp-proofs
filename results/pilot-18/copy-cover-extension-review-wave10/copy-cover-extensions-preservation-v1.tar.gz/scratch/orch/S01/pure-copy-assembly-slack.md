# Exact birth slack and individual support assembly

This adds to pure-copy-assembly-bound.md; all claims here need independent
review. They are necessary conditions only, not an existence construction.

After removing all support-copy ORs, at least t=max residual cover gates
have gone. Prune the remaining graph to its AND ancestor subcircuit. If its
birth graph is B, the retained subcircuit has at least |B| gates. The k
minimal selected pure no-CN supports survive at k distinct noncopy ORs
outside this retained subcircuit. Thus at most

    d = 17 - t - |B| - k

additional noncopy ORs occur outside it. Another selected output cannot be
an ancestor of a selected output because the supports are incomparable.
For any selected support, its outside support-assembly ancestor DAG
therefore has at most d+1 OR nodes (itself and the d extras). The union of
its external operand signals uses at most d+2 distinct boundary signals:
a connected DAG with l binary nodes and one root has at most l+1 distinct
external sources, by counting its parent edges; sharing/repetition only
reduces this maximum. Each boundary signal is raw or lies in an AND ancestor
cone. It has singleton support or a unique owner whose entire support-star
is included in B, as proved in the previous note.

Hence each S must be the union of at most d+2 such useful supports. This
test ignores sharing between selected outputs, so is a safe relaxation.
For exact d=0,1,2, the finite script enumerates all possible exact birth sets
B of size17-k-t-d and tests the two/three/four-leaf condition. Required star
unions are tabulated and a subset-zeta OR transform gives every support
constructible with that many leaves for each B. Empty support allows padding
to exactly that many leaves. For d>=3, the script uses the larger birth set
budget17-k-t-3 and NO assembly condition; every smaller actual B is covered
by some padded budget set, giving a weaker but complete remaining branch.

For each t=0,...,7, supports with tau<=t are permitted. An actual family is
tested at t=max tau, while admitting smaller tau only enlarges the search.
As before, rejected-MIS set-cover is allowed to use at most k supports,
omitting exact cardinality, distinctness and minimality constraints.

The producer bounds every scalar run to48 seconds, records any timeout as
UNKNOWN, and never treats a relaxation witness as a Boolean circuit.
