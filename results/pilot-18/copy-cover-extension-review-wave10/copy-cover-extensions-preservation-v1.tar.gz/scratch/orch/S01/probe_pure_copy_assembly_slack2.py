#!/usr/bin/env python3
"""Bounded copy-cover extensions; no solver and no circuit-exhaustion claim."""
import hashlib
import itertools
import json
import time
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parent
START = time.monotonic()
E = [(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
     (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
EM = [(1<<u)|(1<<v) for u,v in E]
N = [sum(1<<(v if u==x else u) for u,v in E if x in (u,v)) for x in range(11)]
CN = [sum(1<<v for v,n in enumerate(N) if s&n==s) for s in range(2048)]
MIS = [s for s in range(2048) if all(s&e != e for e in EM)
       and all(s>>v&1 or s&N[v] for v in range(11))]
assert len(MIS)==24
ALL = (1<<24)-1

@lru_cache(None)
def cover(es):
    if not es: return 0
    u,v=es[0]
    return 1+min(cover(tuple(e for e in es if u not in e)),
                 cover(tuple(e for e in es if v not in e)))

def data(s):
    es=tuple(e for e,em in zip(E,EM) if not s&em)
    tau=cover(es)
    return dict(s=s,cost=s.bit_count()+len(es)+tau-1,tau=tau,
                residual=sum(1<<j for j,em in enumerate(EM) if not s&em),
                z=sum(1<<j for j,m in enumerate(MIS) if not s&m),cn=CN[s])

# Useful support U must be raw/singleton or have an owner star in B.
# Pair table uses exact-tight birth budget only; the separate slack test
# omits assembly constraints and covers every smaller actual birth graph.
useful=[(0,0)]+[(1<<v,0) for v in range(11)]
for u in range(2048):
    if u.bit_count()>=2 and CN[u]:
        assert CN[u].bit_count()==1
        owner=CN[u].bit_length()-1
        req=sum(1<<j for j,(a,b) in enumerate(E)
                if (a==owner and u>>b&1) or (b==owner and u>>a&1))
        useful.append((u,req))
# At slack d=0,1,2 each output uses at most d+2 useful leaves.
# The d>=3 case is separately overapproximated without assembly restrictions.
assembly_tables={}
for leaves in (2,3,4):
    table=[0]*65536
    for items in itertools.combinations_with_replacement(useful,leaves):
        support=required=0
        for u,e in items:support|=u;required|=e
        table[required]|=1<<support
    for bit in range(16):
        step=1<<bit
        for mask in range(65536):
            if mask&step:table[mask]|=table[mask^step]
    assembly_tables[leaves]=table
DEADLINE=time.monotonic()+48
class BudgetExpired(Exception):pass
def budget():
    if time.monotonic()>DEADLINE:raise BudgetExpired

def pure_probe(k):
    allD=[data(s) for s in range(1,2047) if CN[s]==0]
    allD=[d for d in allD if d['cost']<=18-k and d['z']]
    logs=[];calls=0
    try:
        for t,mode in itertools.product(range(8),('0','1','2','slack')):
            budget();q=k-1+t+(3 if mode=='slack' else int(mode))
            ds=[d for d in allD if d['tau']<=t]
            if not ds:
                logs.append(dict(t=t,mode=mode,required_common_hit_edges=q,pool=0,subsets_checked=0));continue
            hitbits=[sum(1<<i for i,d in enumerate(ds) if not d['residual']>>j&1) for j in range(16)]
            subsets=0;coverqueries=0;allc=(1<<len(ds))-1
            for edges in itertools.combinations(range(16),q):
                budget();subsets+=1;bits=allc
                for e in edges:bits&=hitbits[e]
                inds=[]
                while bits:
                    b=bits&-bits;inds.append(b.bit_length()-1);bits-=b
                birth_mask=65535 ^ sum(1<<e for e in edges)
                if mode!='slack': inds=[i for i in inds if assembly_tables[int(mode)+2][birth_mask]>>ds[i]['s']&1]
                masks={ds[i]['z']:i for i in inds}
                union=0
                for z in masks:union|=z
                if union!=ALL:continue
                # Keep maximal rejection masks; replacing by a superset only
                # weakens the <=k set-cover relaxation for this fixed edge set.
                zz=sorted(masks,key=int.bit_count,reverse=True)
                keep=[]
                for z in zz:
                    if not any(z&x==z for x in keep):keep.append(z)
                byrow=[[z for z in keep if z>>j&1] for j in range(24)]
                coverqueries+=1
                @lru_cache(None)
                def solve(covered,left):
                    nonlocal calls
                    calls+=1
                    if calls%128==0:budget()
                    if covered==ALL:return ()
                    if left==0:return None
                    rem=ALL^covered
                    gain=max((z&rem).bit_count() for z in keep)
                    if gain*left<rem.bit_count():return None
                    j=min((j for j in range(24) if rem>>j&1),key=lambda j:len(byrow[j]))
                    for z in sorted(byrow[j],key=lambda z:(z&rem).bit_count(),reverse=True):
                        ans=solve(covered|z,left-1)
                        if ans is not None:return (z,)+ans
                    return None
                ans=solve(0,k)
                if ans is not None:
                    selected=[ds[masks[z]] for z in ans]
                    return dict(k=k,status='RELAXATION_SURVIVOR_NOT_A_CIRCUIT',t=t,mode=mode,
                                common_hit_edge_indices=edges,selected=selected,
                                current_subsets_checked=subsets,prior_levels=logs,calls=calls)
            logs.append(dict(t=t,mode=mode,required_common_hit_edges=q,pool=len(ds),subsets_checked=subsets,coverqueries=coverqueries))
        return dict(k=k,status='ALL_PURE_FAMILIES_EXCLUDED_BY_NECESSARY_RELAXATION_PENDING_REVIEW',levels=logs,calls=calls)
    except BudgetExpired:
        return dict(k=k,status='TIME_LIMIT_UNKNOWN',completed_levels=logs,calls=calls)

result=pure_probe(5)
out=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 math_sha256=hashlib.sha256((ROOT/'pure-copy-assembly-bound.md').read_bytes()).hexdigest(),
 edges=E,MIS=MIS,result=result,elapsed_seconds=time.monotonic()-START,
 solver_run=False,Lean_proof=False,
 scope='New pure k5 exact d=0,1,2 assembly plus weaker d>=3 slack relaxation; requires independent review.')
(ROOT/'copy-cover-pure-assembly-slack2.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out),flush=True)
