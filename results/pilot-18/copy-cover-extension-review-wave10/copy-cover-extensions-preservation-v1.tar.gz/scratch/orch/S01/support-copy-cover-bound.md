# Residual covers charge support-copy ORs

New lemma for independent review. No Lean theorem, SAT verdict, or full-shard
claim. The setting is a productive clean binary AND/OR circuit in C4-free
ambient G, with ordinary singleton inputs and optional FALSE. A proper-output
ancestor cone cannot contain free TRUE: its full support has no common neighbor,
so productivity would force an OR-only path to the proper output.

Call an OR gate a support-copy gate if its singleton support equals the support
of at least one operand. This is weaker than Boolean equality: the OR may add
positive edge rows. In particular every OR with support of size at most one
is a support-copy gate.

Let W have proper NONEMPTY support S. Let H be any accepted ambient edge rows
whose two endpoints lie outside S. Let c be the number of support-copy OR gates
in W's actual ancestor cone. Then

    tau(H) <= c.                                                 (A)

The nonempty-support guard matters. A single clean AND accepts one edge with
zero OR gates; an empty-support version needs a +1 allowance instead.

## Route each AND through one singleton-support operand

Cleanliness and C4-freeness imply that one operand of each AND has support
size at most one. Productivity makes that support exactly one. Choose such
an operand for every AND. In the cone of W retain both parent edges at every
OR, but only this chosen parent edge at every AND; discard vertices that no
longer reach W. This is a directed acyclic routing graph, not a change to the
actual circuit or to its values.

Let F be the set of ordinary raw input vertices occurring in this routed
ancestor graph. F covers every edge accepted by W: on such an input, OR truth
chooses a true retained parent and AND truth makes the chosen parent true;
following these choices reaches a true raw endpoint. FALSE cannot be the end
of a true path. Therefore F minus S covers H.

Every retained gate of support size greater than one is OR, and every routed
path from it to W consists only of ORs. Indeed its first AND descendant would
be entered through the chosen singleton-support operand, but OR-only propagation
has preserved its larger support up to that point. Thus every such large-support
gate has its support contained in S.

## Count components of the small-support part

Delete all large-support gates from the routed graph. The remaining components
contain only raw inputs/FALSE, AND gates with one retained parent, and OR gates
of support size at most one. All those ORs are support-copy gates.

For a component with d input vertices, a AND vertices and q OR vertices, there
are at most a+2q retained parent-edge occurrences. Connectivity gives at least
d+a+q-1 distinct edges, so d<=q+1. Summed over components, if b is the number
of components and q_small their OR count,

    total input vertices <= q_small+b.

Parallel/repeated operand edges only weaken the upper edge count and cause no
problem. Counting FALSE among input vertices is harmless: it never contributes
to F but can only increase this upper bound.

Call a component good if it contains an ordinary input in S, bad otherwise.
Subtracting the distinct input vertices in S shows

    |F minus S| <= q_small + (#bad components).

Here each good component supplies at least one input in S; a shared raw input
cannot belong to two components because it is a single graph vertex.

If W has singleton support, it lies in the small-support part. There can be
only its connected component: every routed vertex reaches W and no large-support
gate can reach a singleton W. The OR-only support path from its singleton input
is retained, making this component good. Hence there is no bad component.

If W has larger support, every small component has a retained edge from a
boundary root into a large-support OR gate. A bad component cannot have a
nonempty-support boundary root: its singleton lies in S, and its OR-only path
to that raw input is retained inside the small component, contradicting badness.
Thus its boundary roots have empty support. An empty-support operand entering
a large-support OR makes that OR a support-copy gate. Choose one such attachment
for each bad component. Different bad components cannot choose the same large
OR: a binary large-support OR has at most one empty-support operand.

Therefore the number of bad components is at most the number q_large of
large-support copy ORs in the routed cone. Combining the inequalities gives

    tau(H) <= |F minus S| <= q_small+q_large <= c,

which proves(A). This is a finite DAG component count and does not assume
that copies are semantically redundant, that the original circuit is minimal,
or that support paths encode full semantic ancestry.

## Birth count after removing support-copy ORs

In any support model, delete a support-copy OR by redirecting it to an operand
with the identical singleton support. Every retained support and every AND's
cross-support birth set remains unchanged. Repeat in topological order; the
number of deleted gates is exactly the original copy count, since all operand
supports are unchanged by redirection. Positive edge values need not remain
unchanged, and no such claim is made. The existing edge_finset_gate_bound
helper depends only on supports and birth covers, not those positive values.

If B is the union of birth edges in a core with m_core gates and c_core copy
ORs, the helper on the redirected core gives

    |E(B)| <= m_core-c_core.                                     (B)

## Simultaneous selected-output ancestry bound

Let k proper full-cover selected outputs have pairwise incomparable supports
of size at least two, as in a minimal product family. Let T be the maximal
selected outputs in their actual ancestry relation, and t=|T|. Prune to the
selected ancestor union and delete these terminal OR gates to form the core.

Let H contain each ambient edge missed by at least one selected support.
The reviewed edge-birth argument puts H in the core birth graph. For every
NONterminal selected output i, its path to a selected descendant must reach
a clean AND. Its OR-side operand contains S_i. Productivity and C4-freeness
therefore require a unique common neighbor u_i and force every edge u_i-v,
v in S_i, to be born in the core. A no-CN selected output cannot be nonterminal.

Define B_req as H plus these mandatory stars. Then B_req subset B. Every
nonterminal selected output's full ancestor cone remains in the core. Applying
(A) to it and(B) to the core proves

    m >= |E(B_req)| + t + max_nonterminal_i tau(G minus S_i).      (C)

The maximum over an empty set is0. This can be combined by MAXIMUM, not sum,
with the reviewed guarded terminal-birth bonus: when B_req is nonempty and
every terminal support's star avoids B_req, the strict birth argument gives
|B_req|+t+1. That strict statement is used WITH S04's nonempty guard.

## Finite use, pending independent review

Enumerate all19 labeled strict partial orders on three selected outputs.
Every actual selected ancestry relation is one of them. Apply(C), the no-CN
source prohibition, and the guarded strict bonus to each order.

On the supplied800 k3/r1 families and258 k3/r0 families, every nonempty relation
has lower bound greater than17. Thus any surviving realization must have three
ancestrally unrelated selected outputs. This is a conclusion of the new bound,
not an assumed normalization. The empty relation itself rejects72 r1 and79 r0
families by birth counts. Every remaining output cone has at most15 gates;
this rejects57 additional r1 and33 r0 families with an individual cost16.

Finally apply the already reviewed symmetric tight-cone tests at cost15:
all14 unselected gates are ancestors of every tight selected output; their
supports must obey the arbitrary-supported-ancestor charge simultaneously.
All output OR operand pairs and the shared last-core support are checked.
This rejects418 additional r1 and105 r0 families. Proposed remaining counts
are253 r1 and41 r0. These conclusions require independent review of(A)-(C)
and the finite code before becoming accepted mathematical pruning results.
