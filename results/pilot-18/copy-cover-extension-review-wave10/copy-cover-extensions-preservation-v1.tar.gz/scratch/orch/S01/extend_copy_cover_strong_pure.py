#!/usr/bin/env python3
"""Bounded copy-cover extensions; no solver and no circuit-exhaustion claim."""
import hashlib
import itertools
import json
import time
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parent
START = time.monotonic()
E = [(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
     (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
EM = [(1<<u)|(1<<v) for u,v in E]
N = [sum(1<<(v if u==x else u) for u,v in E if x in (u,v)) for x in range(11)]
CN = [sum(1<<v for v,n in enumerate(N) if s&n==s) for s in range(2048)]
MIS = [s for s in range(2048) if all(s&e != e for e in EM)
       and all(s>>v&1 or s&N[v] for v in range(11))]
assert len(MIS)==24
ALL = (1<<24)-1

@lru_cache(None)
def cover(es):
    if not es: return 0
    u,v=es[0]
    return 1+min(cover(tuple(e for e in es if u not in e)),
                 cover(tuple(e for e in es if v not in e)))

def data(s):
    es=tuple(e for e,em in zip(E,EM) if not s&em)
    tau=cover(es)
    return dict(s=s,cost=s.bit_count()+len(es)+tau-1,tau=tau,
                residual=sum(1<<j for j,em in enumerate(EM) if not s&em),
                z=sum(1<<j for j,m in enumerate(MIS) if not s&m),cn=CN[s])

def posets(k):
    out=set()
    for order in itertools.permutations(range(k)):
        pairs=list(itertools.combinations(order,2))
        for mask in range(1<<len(pairs)):
            rel=tuple(sorted(p for j,p in enumerate(pairs) if mask>>j&1))
            if all((a,c) in rel for a,b in rel for x,c in rel if b==x): out.add(rel)
    return sorted(out)

def assess(S,relations):
    k=len(S);D=[data(s) for s in S]
    H=0
    for d in D:H|=d['residual']
    checks=[]; feasible=[]
    for rel in relations:
        source={a for a,b in rel};T=set(range(k))-source
        if any(not D[i]['cn'] for i in source):continue
        B=H
        for i in source:
            assert D[i]['cn'].bit_count()==1
            owner=D[i]['cn'].bit_length()-1
            B|=sum(1<<j for j,(u,v) in enumerate(E)
                   if (u==owner and S[i]>>v&1) or (v==owner and S[i]>>u&1))
        copy=max([0]+[d['tau']-int(i in T) for i,d in enumerate(D)])
        lb=B.bit_count()+len(T)+copy
        checks.append(dict(relation=rel,birth_mask=B,terminals=sorted(T),copy=copy,lower=lb))
        if lb<=17:feasible.append(rel)
    tight=[i for i,d in enumerate(D) if d['cost']==18-k]
    pair_tests=[]
    if feasible==[()] and tight:
        def allowed(u):
            return u.bit_count()<=1 or all(not u&~S[i] or CN[u]&~S[i] for i in tight)
        for j,s in enumerate(S):
            opts=[u for u in range(2048) if not u&~s and allowed(u)]
            pairs=[(u,v) for u,v in itertools.combinations_with_replacement(opts,2) if u|v==s]
            pair_tests.append(dict(output=j,allowed_pairs=pairs))
    excluded=not feasible or (feasible==[()] and any(not q['allowed_pairs'] for q in pair_tests))
    return dict(supports=S,data=D,forced_birth_mask=H,checks=checks,
                surviving_relations=feasible,tight_outputs=tight,
                tight_operand_tests=pair_tests,excluded=excluded)

parent=ROOT/'two-spare-forest-filter.json'
families=[r for r in json.loads(parent.read_text())['results'][1]['families'] if not r['excluded']]
assert len(families)==112
relations=posets(4);assert len(relations)==219
rows=[assess(r['supports'],relations) for r in families]
assert all(r['excluded'] for r in rows)
assert sum(not r['surviving_relations'] for r in rows)==111
explicit=[assess([1408,592,1546,501],[()]),assess([1408,592,1866,501,1722],[()])]
out=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         parent_sha256=hashlib.sha256(parent.read_bytes()).hexdigest(),
         math_review_sha256=hashlib.sha256((ROOT.parent/'S04/copy-cover-closure-review.json').read_bytes()).hexdigest(),
         summary=dict(k4_r0_input=112,direct_excluded=111,tight_excluded=1,remaining=0),
         relations=relations,families=rows,explicit_pure_witnesses=explicit,
         solver_run=False,Lean_proof=False,
         scope='Proposed extension on supplied112k4/r0 and two explicit pure witnesses; independent review required.')
(ROOT/'copy-cover-strong-four-extension.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out['summary']),flush=True)
for r in explicit: print(json.dumps(dict(supports=r['supports'],check=r['checks'],excluded=r['excluded'])),flush=True)

# A larger necessary relaxation for pure no-common-neighbor families.
# For exact k distinct minimal factors all outputs are ancestry sinks, so
# each cost <=18-k.  If t=max residual tau, the terminal copy bound forces
# Stronger NEW pure-terminal proof: at least k-1+t target edges are hit by every support.
# Enumerate such free-edge subsets, then allow <=k arbitrary eligible supports
# covering all24 MIS rejection rows. This is an overapproximation.
DEADLINE=time.monotonic()+48
class BudgetExpired(Exception):pass
def budget():
    if time.monotonic()>DEADLINE:raise BudgetExpired

def pure_probe(k):
    allD=[data(s) for s in range(1,2047) if CN[s]==0]
    allD=[d for d in allD if d['cost']<=18-k and d['z']]
    logs=[];calls=0
    try:
        for t in range(8):
            budget();q=k-1+t
            ds=[d for d in allD if d['tau']<=t]
            if not ds:
                logs.append(dict(t=t,required_common_hit_edges=q,pool=0,subsets_checked=0));continue
            hitbits=[sum(1<<i for i,d in enumerate(ds) if not d['residual']>>j&1) for j in range(16)]
            subsets=0;coverqueries=0;allc=(1<<len(ds))-1
            for edges in itertools.combinations(range(16),q):
                budget();subsets+=1;bits=allc
                for e in edges:bits&=hitbits[e]
                inds=[]
                while bits:
                    b=bits&-bits;inds.append(b.bit_length()-1);bits-=b
                masks={ds[i]['z']:i for i in inds}
                union=0
                for z in masks:union|=z
                if union!=ALL:continue
                # Keep maximal rejection masks; replacing by a superset only
                # weakens the <=k set-cover relaxation for this fixed edge set.
                zz=sorted(masks,key=int.bit_count,reverse=True)
                keep=[]
                for z in zz:
                    if not any(z&x==z for x in keep):keep.append(z)
                byrow=[[z for z in keep if z>>j&1] for j in range(24)]
                coverqueries+=1
                @lru_cache(None)
                def solve(covered,left):
                    nonlocal calls
                    calls+=1
                    if calls%128==0:budget()
                    if covered==ALL:return ()
                    if left==0:return None
                    rem=ALL^covered
                    gain=max((z&rem).bit_count() for z in keep)
                    if gain*left<rem.bit_count():return None
                    j=min((j for j in range(24) if rem>>j&1),key=lambda j:len(byrow[j]))
                    for z in sorted(byrow[j],key=lambda z:(z&rem).bit_count(),reverse=True):
                        ans=solve(covered|z,left-1)
                        if ans is not None:return (z,)+ans
                    return None
                ans=solve(0,k)
                if ans is not None:
                    selected=[ds[masks[z]] for z in ans]
                    return dict(k=k,status='RELAXATION_SURVIVOR_NOT_A_CIRCUIT',t=t,
                                common_hit_edge_indices=edges,selected=selected,
                                current_subsets_checked=subsets,prior_levels=logs,calls=calls)
            logs.append(dict(t=t,required_common_hit_edges=q,pool=len(ds),subsets_checked=subsets,coverqueries=coverqueries))
        return dict(k=k,status='ALL_PURE_FAMILIES_EXCLUDED_BY_NECESSARY_RELAXATION_PENDING_REVIEW',levels=logs,calls=calls)
    except BudgetExpired:
        return dict(k=k,status='TIME_LIMIT_UNKNOWN',completed_levels=logs,calls=calls)

pure=[]
for k in (4,5):
    result=pure_probe(k);pure.append(result);print(json.dumps(result),flush=True)
out2=dict(source_sha256=out['source_sha256'],edges=E,MIS=MIS,results=pure,
          elapsed_seconds=time.monotonic()-START,solver_run=False,Lean_proof=False,
          scope='NEW stronger pure-terminal lemma in copy-cover-extensions.md; bounded necessary relaxation only; completed exclusion requires independent math/source review. Mixed k4/k5 remain outside this enumeration.')
(ROOT/'copy-cover-strong-pure-extension.json').write_text(json.dumps(out2,indent=2)+'\n')
print(json.dumps(dict(source_sha256=out['source_sha256'],elapsed_seconds=out2['elapsed_seconds'])),flush=True)
