# Copy-cover extensions, 2026-11-24 05:55 UTC

The reviewed copy-cover and terminal-charge statements are used unchanged.
S04's independent math/finite PASS is bound by review SHA
a598a661731287f9c3a3b586fc594484464ce60d2a92b6e197e070e1536feff6.
All new applications here require independent review; no Lean or solver result.

## Supplied four-factor common-neighbor census

For each of the 112 supplied remaining k=4,r=0 families enumerate all219
labeled strict partial orders on the selected outputs. A nonterminal selected
support has its owner star forced into the core birth graph; delete only the
selected maxima. Apply the reviewed terminal-copy bound, without any strict
bonus. This excludes111 families for every order.

The remaining supports are417,560,772,546, with costs11,13,13,14. Only the
empty order survives. The selected output with support546 and cost14 must
contain every one of the13 nonselected gates in its ancestor cone. Every
nonselected supported gate U therefore obeys

    U subset546 OR CN(U) has a vertex outside546.

This is the previously reviewed arbitrary-supported-ancestor charge in a
tight cone. Raw singleton operands are exempt. None of the four selected
outputs can be an operand of another. Exhausting every pair of allowed
subsets of a selected support gives zero OR operand pairs for both417 and772.
Thus this last family is also excluded. This is the same tight-core proof
used in the reviewed three-factor application, with13 rather than14 coregates.

## Pure no-common-neighbor relaxation

For k distinct minimal factors with CN(S_i) empty, selected outputs cannot
be ancestors of one another. Hence each ancestor cone has at most18-k gates,
so L(S_i)<=18-k. Each support is proper and nonempty; TRUE/repeated/redundant
factors are removed in the previously reviewed minimal-factor normalization.
Let H be the union of residual edge sets G-S_i and let t=max tau(G-S_i).
The reviewed terminal-copy bound implies

    17 >= |H| + k + max(0,t-1).

Consequently at least q=k-1+max(0,t-1) of the16 edges are hit by EVERY support.
For each t=0,...,7 enumerate every q-edge subset F. Eligible supports must
have empty CN, cost<=18-k, residual cover<=t, and hit every edge of F.
Their rejection sets on the24 maximal independent inputs must cover all24
with at most k supports. Allowing fewer supports and omitting distinctness,
minimality and exact-tau constraints only enlarges this necessary relaxation.
Grouping identical rejection sets and deleting contained rejection sets is
safe for the at-most-k set-cover question at fixed F,t. The recursion chooses
an uncovered row and tries every retained support rejecting that row. Its
maximum-gain bound and memoization are standard exact set-cover pruning.

All t levels for k4 finish with no cover (99117 recursivecalls). k5 has a
relaxation survivor, not a circuit:1584,1441,788,117,1794. Their residual
cover numbers are3,2,3,2,3; H has10edges, so the bound is exactly17.

The requested pure witnesses1408,592,1546,501 and1408,592,1866,501,1722
have lower bounds19 and18 respectively and are excluded by the old bound.

## Stronger pure-terminal charge: proposed proof

For pure no-CN selected terminals the minus-one loss can be removed:

    m >= |H| + k + max_i tau(G-S_i).

Choose i attaining t=max tau. If its final OR is NOT a support-copy, removing
the k selected terminals removes no copy OR from its cone, leaving at least
t corecopies; support redirection and the birth-count lemma give the bound.

Otherwise its final OR is a support-copy, so its identical-support parent
is in the core. Redirect all core support-copy ORs, preserving every AND
birth. The parent redirects to a surviving gate with support exactly S_i:
it cannot redirect to an input or constant since |S_i|>=2 and S_i is proper.
This surviving gate is OR, and it cannot be an ancestor of ANY AND: a first
AND after an OR-only path would require a nonempty opposite support inside
CN(S_i), impossible by productivity and CN(S_i)=empty. Prune the redirected
core to the ancestors of its AND gates. This removes at least that additional
noncopy OR while preserving every AND birth. At least t-1 copy ORs and one
further gate have been removed, so |H|<=m-k-t again.

The argument counts only one extra gate, uses actual support-preserving
redirection, and never identifies this with Boolean equivalence. It does
not assume minimum-size circuits or disjoint cones. If t=0 the basic birth
bound already suffices. A support-copy terminal parent exists even when
operands repeat. Distinct selected outputs cannot be the relevant parent
because all selected supports are minimal and incomparable. The reduced
core may keep dead ANDs; the birth helper needs support recurrences only.

This stronger lemma is NEW and not yet independently reviewed. A separate
bounded probe may use q=k-1+t, with all other relaxation steps unchanged.
