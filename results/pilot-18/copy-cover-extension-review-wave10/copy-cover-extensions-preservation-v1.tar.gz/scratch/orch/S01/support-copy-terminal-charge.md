# Terminal factors retain all but one of their copy-OR charges

New extension for independent review; uses lemma(A) and support redirection(B)
from support-copy-cover-bound.md. The previous source/results are immutable.

In the selected-output ancestry setup, let T be the maximal selected outputs,
and delete their terminal OR gates after pruning to the selected ancestor
union. For any selected output i, its cone contains no other member of T:
such a terminal selected ancestor would have a selected descendant. Thus
deleting T removes at most one OR-copy gate from i's cone when i belongs to T,
and removes none otherwise.

Write tau_i=tau(G minus S_i). The core therefore contains at least

    max(0, max_i [tau_i - indicator(i in T)])

support-copy OR gates. No assumption that the terminal OR actually is a copy
is made: deducting one is a safe relaxation. The count is a MAXIMUM across
cones, not a sum, so shared copy gates are not double counted.

Combining with birth redirection and the mandatory stars of nonterminal
selected outputs gives the stronger necessary condition

    m >= |E(B_req)| + |T|
         + max(0, max_i [tau_i - indicator(i in T)]).              (D)

Here B_req is the union of edges missed by some selected support and every
support-star forced by a nonterminal selected output's first clean AND. The
unique owner and the no-CN source prohibition are justified exactly as in
support-copy-cover-bound.md. Proper nonempty supports, productive ANDs and
C4-freeness remain explicit premises.

The guarded strict-terminal-birth bonus can still be included by taking a
maximum with1, only when B_req is nonempty and every terminal support's star
avoids B_req. It is not added to the copy-OR charge.

## Complete application to the supplied remaining triple families

All19 labeled strict partial orders are tested for each exact support family.
The final source rechecks residual cover numbers independently by an
edge-branch recurrence and independently reconstructs support owners.

For the800 reviewed k3/r1 survivors, every partial order has lower bound>17
under(D), except structurally impossible no-CN-source orders. All800 are thus
proposed excluded by this one condition, with no tight-cone follow-up needed.

For the258 reviewed k3/r0 survivors,251 have no feasible order. The other7
permit only the empty relation, so every selected output cone has at most15
gates. Their supports are

    [289,562,768], [385,562,768], [416,562,768],
    [417,530,768], [417,546,768], [417,560,768], [417,562,768].

In each, support768={8,9} has individual cost15. The reviewed symmetric
tight-cone argument applies: that cone contains all14 unselected gates;
arbitrary-supported-ancestor charges constrain every operand support, and
the latest shared-core gate directly feeds all cost15 outputs. Exhausting
the allowed support pairs and the shared-support condition rejects each of
these7. The final code recomputes these tests rather than trusting a result
flag from the earlier weaker application.

Thus the proposal excludes all800 k3/r1 and all258 k3/r0 supplied families.
Earlier independently reviewed classifications connect these finite lists
to the original minimal-factor search. The new lemma and final application
still require independent mathematical and code review. No k4/mixed or whole
AAAA/shard conclusion, SAT verdict, Lean theorem or accepted proof is claimed.
