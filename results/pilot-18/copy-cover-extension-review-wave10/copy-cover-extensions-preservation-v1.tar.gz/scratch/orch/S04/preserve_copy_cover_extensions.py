from pathlib import Path
import datetime,hashlib,json,shutil,tarfile
O=Path(__file__).resolve().parent;I=O.parent/'S01';S=O.parents[1];R=Path('/workspace/pequalnp-proofs');D=O/'copy-cover-extensions-preservation-v1';assert not D.exists();D.mkdir();files={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):p.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
def take(p,h=None):
 p=Path(p);assert p.is_file() and not p.is_symlink() and p.suffix not in ('.cnf','.drat','.lrat','.pyc')
 if h:assert sha(p)==h
 rel=Path('scratch')/p.relative_to(S) if p.is_relative_to(S) else Path('repo')/p.relative_to(R);q=D/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);files[str(rel)]={'source':str(p),'sha256':sha(q),'bytes':q.stat().st_size}
review=json.loads((O/'copy-cover-extensions-review.json').read_text());assert sha(O/'copy-cover-extensions-review.json')=='b3613cd880d5898ff18e5871e2d45dea9bb6fa621de9554bf2f97327ba6ac037'
for n,h in review['bindings'].items():take(I/n,h)
for n in ['copy-cover-extension.stdout.txt','copy-cover-extension.stderr.txt','copy-cover-pure-assembly-slack2.stdout.txt','copy-cover-pure-assembly-slack2.stderr.txt','extend_copy_cover_strong_pure.py','copy-cover-strong-pure-extension.json','copy-cover-strong-extension.stdout.txt','copy-cover-strong-extension.stderr.txt','probe_pure_copy_assembly.py','copy-cover-pure-assembly.json','copy-cover-pure-assembly.stdout.txt','copy-cover-pure-assembly.stderr.txt','support-copy-cover-bound.md','support-copy-terminal-charge.md','two-spare-forest-filter.json']:take(I/n)
assert json.loads((I/'copy-cover-pure-assembly-slack2.stdout.txt').read_text())==json.loads((I/'copy-cover-pure-assembly-slack2.json').read_text())
oldlines=[json.loads(s) for s in (I/'copy-cover-extension.stdout.txt').read_text().splitlines() if s.strip()]
for d in json.loads((I/'copy-cover-pure-extension.json').read_text())['results']:assert d in oldlines
assert json.loads((I/'copy-cover-four-extension.json').read_text())['summary'] in oldlines
assert not (I/'copy-cover-extension.stderr.txt').read_bytes() and not (I/'copy-cover-pure-assembly-slack2.stderr.txt').read_bytes()
for n in ['review_copy_cover_extensions.py','copy-cover-extensions-review.json','copy-cover-extensions-review.stdout.log','copy-cover-extensions-review.stderr.log','review_copy_cover_extensions.py.initial-failed','copy-cover-extensions-review.stdout.log.initial-failed','copy-cover-extensions-review.stderr.log.initial-failed','copy-cover-extensions-math-review.md','preserve_copy_cover_extensions.py','forest-sinks-review.json','copy-cover-closure-review.json','copy-cover-math-review.md','copy-cover-closure-preservation-handoff.json']:take(O/n)
report=R/'results/orch/lemmas/S04-redteam.md'
with report.open('a') as f:f.write('\n\n'+(O/'copy-cover-extensions-math-review.md').read_text())
take(report)
(D/'README.md').write_text('''# S04 independent extension review, final new evidence

PASS mathematical/source audit of S01 new pure-terminal charge, support
assembly and exact-slack split. All112 suppliedk4/r0 records checked directly
(111copy-bound+1tight), and purek4/r4+k5/r5 recorded complete exclusions accepted
on proof/source audit and independent pool/level/quick-control checks.
NO duplicate pure set-cover DFS was run by S04. This limitation is explicit.
Mixedk4/k5 remain OPEN. No CNF/Lean/global/shard claim.

Guards: proper supports of size>=2, productive clean prefix,C4-free ambient
graph, minimal incomparable factors. Size>=2 follows for this fixed graph's
nonempty no-CN supports from minimum degree2. A local isolated-singleton
countercontrol explains why an abstract statement must retain that guard;
it is NOT an actual-graph minimal-product counterexample. All-copy removal
preserves supports/births, not full Boolean functions. Exactd0/1/2 assembly
and unfiltered padded d>=3 branch are separated correctly.

All proof/source/completek4tables/recordedpurelevels/producerstdoutstderr and
independent source/results/logs are preserved. Historical weaker-relaxation
survivors are retained as NONcircuits, not final surviving cases. An initial
S04 harness syntax error before execution is preserved; its corrected run
alone supplies the review. No producer file was changed. No rawCNFs/binaries.

Run python verify_manifest.py after extracting anywhere. Review scripts keep
original producer paths; replay outside the original workspace requires
mapping them to archived scratch paths in a WORKING COPY. Frozen source bytes
must not be silently changed. Full recorded finalstdout equals savedJSON and
old completion lines match bothsavedpurecases; checked during preservation.
''')
(D/'verify_manifest.py').write_text('''from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
m=json.loads((r/'manifest.json').read_text())
for n,v in m['files'].items():
 p=r/n
 assert p.is_file() and not p.is_symlink()
 assert p.stat().st_size==v['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'],n
print('PASS',len(m['files']),'payloads; no second pure-DFS run claimed')
''')
for n in ['README.md','verify_manifest.py']:files[n]={'source':'generated','sha256':sha(D/n),'bytes':(D/n).stat().st_size}
scope='PASS extension math/source audit;112k4r0 directrecord checks; purek4r4/purek5r5 recordedcompleteexclusions accepted without duplicatepureDFS. Proper|S|>=2 guard explicit. Mixedk4/k5 OPEN; noCNF/Lean/globalclaim.'
write(D/'manifest.json',{'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':scope,'files':files,'review_sha256':sha(O/'copy-cover-extensions-review.json')})
archive=O/(D.name+'.tar.gz')
with tarfile.open(archive,'w:gz') as tf:
 for p in sorted(D.rglob('*')):
  if p.is_file():tf.add(p,arcname=p.relative_to(D),recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 members=tf.getmembers();assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
 assert {m.name for m in members}==set(files)|{'manifest.json'}
 for m in members:assert tf.extractfile(m).read()==(D/m.name).read_bytes()
h={'archive':str(archive),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'regular_members':len(members),'manifest_sha256':sha(D/'manifest.json'),'review_sha256':sha(O/'copy-cover-extensions-review.json'),'source_sha256':sha(O/'review_copy_cover_extensions.py'),'scope':scope}
write(O/'copy-cover-extensions-preservation-handoff.json',h);print(json.dumps(h,indent=2))
