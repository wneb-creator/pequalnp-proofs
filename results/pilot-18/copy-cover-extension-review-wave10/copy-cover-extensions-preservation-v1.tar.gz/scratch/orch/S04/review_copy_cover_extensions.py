from pathlib import Path
import functools,hashlib,itertools,json,math,time
O=Path(__file__).resolve().parent;I=O.parent/'S01';start=time.monotonic()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
expected={'copy-cover-extensions.md':'8295b1fd4871c71a3049c9dcb00deeb67f2e9ca063196049ed1b83ec1959b28c','pure-copy-assembly-bound.md':'9511604aa7e0572a736fc7f1c43bafe5ed14b46605f86773b081323a38ddfcda','pure-copy-assembly-slack.md':'6be6376d9e42cea4d66d27cffe80da85883ccdd9b2407342892fb531aed6093b','extend_copy_cover.py':'3d3d1edbf3db6a997ee0abf5d245f2456991c15f5891c648f3570021e5421f4b','probe_pure_copy_assembly_slack2.py':'bd53508cfdd2cfba0a2de41151227a428e73606906cf76debe0bdcc112949e0f','copy-cover-four-extension.json':'3a29613ff5e86b5da22cc3c1f04f888e785441872ed20f2fda5fe7dad666f436','copy-cover-pure-extension.json':'f5f450d5cc687fd8ec67bacd78763aaba5a01514a7d82d76efe0fe242f80be20'}
for n,h in expected.items():assert sha(I/n)==h
four=json.loads((I/'copy-cover-four-extension.json').read_text());pure=json.loads((I/'copy-cover-pure-extension.json').read_text());final=json.loads((I/'copy-cover-pure-assembly-slack2.json').read_text());expected['copy-cover-pure-assembly-slack2.json']=sha(I/'copy-cover-pure-assembly-slack2.json')
assert four['source_sha256']==pure['source_sha256']==expected['extend_copy_cover.py'] and final['source_sha256']==expected['probe_pure_copy_assembly_slack2.py'] and final['math_sha256']==expected['pure-copy-assembly-bound.md']
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)];EM=[(1<<u)|(1<<v) for u,v in E];N=[{v if u==x else u for u,v in E if x in(u,v)} for x in range(11)]
assert min(map(len,N))==2 and all(len(N[u]&N[v])<=1 for u,v in itertools.combinations(range(11),2))
def V(s):return {v for v in range(11) if s>>v&1}
def cn(s):return set.intersection(*(N[v] for v in V(s))) if s else set(range(11))
ind=[x for x in range(2048) if not any(x&e==e for e in EM)];MIS=[x for x in ind if not any(x!=y and x&~y==0 for y in ind)]
assert len(ind)==125 and len(MIS)==24 and MIS==pure['MIS']==final['MIS'];assert 11-max(x.bit_count() for x in ind)==7
@functools.lru_cache(None)
def row(s):
 rem=2047^s;t=rem.bit_count()-max(x.bit_count() for x in ind if x&~rem==0);res=sum(1<<j for j,e in enumerate(EM) if not e&s)
 return {'s':s,'tau':t,'cost':s.bit_count()+res.bit_count()+t-1,'residual':res,'z':sum(1<<j for j,x in enumerate(MIS) if not x&s),'cn':sum(1<<v for v in cn(s))}
# Audit the stored finite k4 records; do not rerun the pure set-cover search.
pairs=list(itertools.permutations(range(4),2));rels=set()
for mask in range(1<<12):
 rel={e for j,e in enumerate(pairs) if mask>>j&1}
 if any((b,a) in rel for a,b in rel) or any((a,c) not in rel for a,b in rel for bb,c in rel if b==bb):continue
 rels.add(tuple(sorted(rel)))
assert len(rels)==219 and rels=={tuple(map(tuple,r)) for r in four['relations']}
forest=json.loads((O/'forest-sinks-review.json').read_text());assert {tuple(d['supports']) for d in four['families']}=={tuple(d['supports']) for d in forest['forest_results'][1]['families'] if not d['excluded']}
checked=0;survivors=[]
for d in four['families']:
 S=d['supports'];D=list(map(row,S));assert D==d['data'];H=functools.reduce(int.__or__,[r['residual'] for r in D],0);assert H==d['forced_birth_mask'];feasible=[]
 assert {tuple(map(tuple,c['relation'])) for c in d['checks']}==rels
 for c in d['checks']:
  checked+=1;rel=set(map(tuple,c['relation']));sources={a for a,b in rel};T=set(range(4))-sources;B=H
  for i in sources:
   u=next(iter(cn(S[i])));B|=sum(1<<j for j,e in enumerate(E) if u in e and set(e)&V(S[i]))
  charge=max(0,*[r['tau']-int(i in T) for i,r in enumerate(D)]);lower=B.bit_count()+len(T)+charge
  assert c['birth_mask']==B and c['terminals']==sorted(T) and c['copy']==charge and c['lower']==lower
  if lower<=17:feasible.append(tuple(sorted(rel)))
 assert set(feasible)=={tuple(map(tuple,r)) for r in d['surviving_relations']}
 if feasible:
  assert feasible==[()] and S==[417,560,772,546]
  tight=[i for i,r in enumerate(D) if r['cost']==14];assert tight==[3]
  allowed=lambda u:u.bit_count()<=1 or all(V(u)<=V(S[i]) or bool(cn(u)-V(S[i])) for i in tight)
  pairs_out=[]
  for j,s in enumerate(S):
   opts=[u for u in range(2048) if not u&~s and allowed(u)];p=[[u,v] for u in opts for v in opts if u<=v and u|v==s]
   assert d['tight_operand_tests'][j]=={'output':j,'allowed_pairs':p};pairs_out.append(len(p))
  assert pairs_out[0]==pairs_out[2]==0;survivors.append({'supports':S,'costs':[r['cost'] for r in D],'allowed_pair_counts':pairs_out})
assert checked==24528 and len(survivors)==1
pool_checks=[]
for k,run in [(4,pure['results'][0]),(5,final['result'])]:
 assert run['k']==k and run['status']=='ALL_PURE_FAMILIES_EXCLUDED_BY_NECESSARY_RELAXATION_PENDING_REVIEW'
 ds=[row(s) for s in range(1,2047) if not cn(s) and row(s)['cost']<=18-k and row(s)['z']]
 assert all(d['s'].bit_count()>=2 for d in ds)
 seen=set()
 for lev in run['levels']:
  t=lev['t'];mode=lev.get('mode');seen.add((t,mode));q=k-1+max(0,t-1) if k==4 else k-1+t+(3 if mode=='slack' else int(mode))
  eligible=[d for d in ds if d['tau']<=t]
  assert lev['required_common_hit_edges']==q and lev['pool']==len(eligible)
  assert lev['subsets_checked']==(math.comb(16,q) if eligible else 0)
  pool_checks.append({'k':k,'t':t,'mode':mode,'q':q,'pool':len(eligible),'subsets':lev['subsets_checked']})
 assert seen==({(t,None) for t in range(8)} if k==4 else {(t,m) for t in range(8) for m in ('0','1','2','slack')})
# Only quick explicit witness/assembly checks; no second exhaustive DFS.
witnesses=[]
for S in [[1408,592,1546,501],[1408,592,1866,501,1722],[1584,1441,788,117,1794]]:
 D=list(map(row,S));H=functools.reduce(int.__or__,[d['residual'] for d in D],0);t=max(d['tau'] for d in D)
 assert all(not d['cn'] for d in D)
 witnesses.append({'supports':S,'taus':[d['tau'] for d in D],'H_edges':H.bit_count(),'old_bound':H.bit_count()+len(S)+max(0,t-1),'strong_bound':H.bit_count()+len(S)+t})
assert [w['old_bound'] for w in witnesses]==[19,18,17] and [w['strong_bound'] for w in witnesses]==[20,19,18]
useful=[]
for u in range(2048):
 C=cn(u)
 if u.bit_count()<=1:useful.append((u,0))
 elif C:
  assert len(C)==1;c=next(iter(C));req=sum(1<<j for j,e in enumerate(E) if c in e and set(e)&V(u));assert req.bit_count()==u.bit_count();useful.append((u,req))
sample_masks=[0,65535]
for w in witnesses:sample_masks.append(functools.reduce(int.__or__,[row(s)['residual'] for s in w['supports']],0))
assembly=[]
for B in sorted(set(sample_masks)):
 opts=[u for u,req in useful if req&~B==0]
 reachable={0};layers=[]
 for leaves in range(1,5):
  reachable={a|b for a in reachable for b in opts};layers.append(set(reachable))
 for s in sorted({x for w in witnesses for x in w['supports']}):
  subopts=[u for u in opts if u and not u&~s]
  @functools.lru_cache(None)
  def minimum(rem):
   if not rem:return 0
   bit=rem&-rem;return 1+min(minimum(rem&~u) for u in subopts if u&bit)
  m=minimum(s)
  assert all((s in layers[j-1])==(m<=j) for j in range(1,5))
  assembly.append([B,s,m])
# Local cardinality guard countercontrol: without |S|>=2, an isolated raw
# singleton can be the redirected terminal, so the extra gate need not exist.
cardinality_control={'ambient_edges':[[0,1]],'vertices':3,'gates':[['and',0,1],['or',3,2]],'output':4,'support':[2],'CN':[],'H_edges':1,'tau':1,'m':2,'unguarded_k1_bound':3,'scope':'Countercontrol to dropping support-size>=2 in the abstract selected-output lemma; NOT a minimal factor-product family for the actual11vertex graph.'}
out={'verdict':'PASS_EXTENSION_MATH_SOURCE_AUDIT_STORED_K4_BOUND_CHECKS_AND_QUICK_CONTROLS','source_sha256':sha(Path(__file__)),'bindings':expected,'k4_stored_order_checks':checked,'k4_direct_excluded':111,'k4_tight_excluded':1,'last_k4_case':survivors,'pure_pool_and_level_checks':pool_checks,'pure4_recorded_calls':pure['results'][0]['calls'],'pure5_recorded_calls':final['result']['calls'],'pure5_recorded_seconds':final['elapsed_seconds'],'quick_witnesses':witnesses,'useful_supports':len(useful),'assembly_quick_crosschecks':assembly,'cardinality_guard_control':cardinality_control,'seconds':time.monotonic()-start,'pure_exhaustive_search_rerun':False,'scope':'Independent mathematical/source audit accepts supplied112k4r0, purek4r4 and purek5r5 exclusion arguments and recorded complete enumeration. No duplicate pure DFS run. Requires proper support size>=2, productivity, cleanliness,C4free,minimal incomparable family and reviewed17gate normalization. Mixedk4/k5 remain OPEN; no CNF/Lean/globalclaim.'}
(O/'copy-cover-extensions-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['bindings','pure_pool_and_level_checks','assembly_quick_crosschecks']},indent=2))
