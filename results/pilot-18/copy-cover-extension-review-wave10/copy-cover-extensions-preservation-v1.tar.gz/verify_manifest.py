from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
m=json.loads((r/'manifest.json').read_text())
for n,v in m['files'].items():
 p=r/n
 assert p.is_file() and not p.is_symlink()
 assert p.stat().st_size==v['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'],n
print('PASS',len(m['files']),'payloads; no second pure-DFS run claimed')
