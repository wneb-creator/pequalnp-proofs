# S04 independent extension review, final new evidence

PASS mathematical/source audit of S01 new pure-terminal charge, support
assembly and exact-slack split. All112 suppliedk4/r0 records checked directly
(111copy-bound+1tight), and purek4/r4+k5/r5 recorded complete exclusions accepted
on proof/source audit and independent pool/level/quick-control checks.
NO duplicate pure set-cover DFS was run by S04. This limitation is explicit.
Mixedk4/k5 remain OPEN. No CNF/Lean/global/shard claim.

Guards: proper supports of size>=2, productive clean prefix,C4-free ambient
graph, minimal incomparable factors. Size>=2 follows for this fixed graph's
nonempty no-CN supports from minimum degree2. A local isolated-singleton
countercontrol explains why an abstract statement must retain that guard;
it is NOT an actual-graph minimal-product counterexample. All-copy removal
preserves supports/births, not full Boolean functions. Exactd0/1/2 assembly
and unfiltered padded d>=3 branch are separated correctly.

All proof/source/completek4tables/recordedpurelevels/producerstdoutstderr and
independent source/results/logs are preserved. Historical weaker-relaxation
survivors are retained as NONcircuits, not final surviving cases. An initial
S04 harness syntax error before execution is preserved; its corrected run
alone supplies the review. No producer file was changed. No rawCNFs/binaries.

Run python verify_manifest.py after extracting anywhere. Review scripts keep
original producer paths; replay outside the original workspace requires
mapping them to archived scratch paths in a WORKING COPY. Frozen source bytes
must not be silently changed. Full recorded finalstdout equals savedJSON and
old completion lines match bothsavedpurecases; checked during preservation.
