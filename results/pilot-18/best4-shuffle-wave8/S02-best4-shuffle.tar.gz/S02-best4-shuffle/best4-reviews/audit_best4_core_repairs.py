"""Independent scalar, scheduling, complete-clause and reproducibility audit; no solve."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode=True
ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S02';FAMILY=HERE/'best4-core-family'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
script=HERE/'generate_best4_core_repairs.py'
spec=importlib.util.spec_from_file_location('best4_audited_generator',script)
generator=importlib.util.module_from_spec(spec);spec.loader.exec_module(generator)
helper,(_,_,local,base)=generator.dependencies()
manifest=json.loads((FAMILY/'family.json').read_text())
assert manifest['complete'] and manifest['program_sha256']==sha(script) and len(manifest['cases'])==2
assert sha(FAMILY/'original-source.json')==generator.SOURCE_SHA
original=json.loads((FAMILY/'original-source.json').read_text())
data=json.loads((FAMILY/'remainder-first-source.json').read_text())
assert sha(FAMILY/'remainder-first-source.json')==manifest['source_sha256']
edges=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
core_edges=[(0,9),(2,5),(4,8),(5,8),(5,9),(8,9)]
remainder_edges=[e for e in edges if e not in core_edges]
order=[0,8,9,10,11,12,13,14,15,16,17,18,19,1,2,3,4,5,6,7,20]
mapping=[order.index(g) for g in range(21)]
assert manifest['new_to_old_gate']==order and manifest['old_to_new_gate']==mapping
assert len(remainder_edges)==10 and data['output']==33
for new,old in enumerate(order):
    op,a,b=original['gates'][old]
    lift=lambda w:w if w<13 else 13+mapping[w-13]
    assert data['gates'][new]==[op,*sorted((lift(a),lift(b)))]
    if new<13:assert all(w<13 or w-13 in order[:13] for w in (a,b))


def scalar(circuit,mask):
    values=[bool(mask>>i&1) for i in range(11)]+[False,True]
    for g,(op,a,b) in enumerate(circuit['gates']):
        assert op in ('and','or') and type(a)is int and type(b)is int and 0<=a<=b<13+g
        values.append(values[a] and values[b] if op=='and' else values[a] or values[b])
    return values


fp=[];fn=[];junk=set();wire_checks=0
for mask in range(2048):
    before=scalar(original,mask);after=scalar(data,mask)
    target=any((mask>>a&1) and (mask>>b&1) for a,b in edges)
    extra=all(mask>>i&1 for i in (0,2,4))
    assert before[20]==(any(mask>>a&1 and mask>>b&1 for a,b in core_edges) or extra)
    assert before[32]==any(mask>>a&1 and mask>>b&1 for a,b in remainder_edges)
    assert before[33]==after[33]==(target or extra)
    for old in range(21):assert before[13+old]==after[13+mapping[old]];wire_checks+=1
    if target and not after[33]:fn.append(mask)
    if not target and after[33]:fp.append(mask)
    if not target:junk.update(g for g,(op,_,_) in enumerate(data['gates']) if op=='and' and after[13+g])
assert not fn and fp==[21,29,85,149] and junk=={17,19}
minimal=[m for m in fp if all(m^(1<<v) not in fp for v in range(11) if m>>v&1)]
assert minimal==[21]
case_reports=[];all_clauses=[]
for row in manifest['cases']:
    path=FAMILY/(row['case']+'.cnf');meta=json.loads(path.with_suffix('.json').read_text())
    assert sha(path)==row['cnf_sha256']==meta['sha256'] and sha(path.with_suffix('.json'))==row['metadata_sha256']
    cnf,base_meta=base.build(size=21,first_junk=0,second_junk=False,prefix_sort=False,last_output=False,live=False,productive_prefix=False)
    original_bytes=local.dimacs(cnf);forced=[base_meta['junk'][0]]
    assert cnf.clauses.count(forced)==1 and meta['base_with_forced_junk_sha256']==hashlib.sha256(original_bytes).hexdigest()
    cnf.clauses.remove(forced)
    old_holes=list(range(1,8))+[20]
    if row['case']=='core-star-h12':old_holes+=list(range(13,17))
    else:assert row['case']=='core-h08'
    holes=sorted(mapping[g] for g in old_holes)
    assert row['old_free_gates']==sorted(old_holes) and row['free_gates']==holes
    pins=[]
    for g,(op,a,b) in enumerate(data['gates']):
        if g not in holes:pins.extend([[base_meta['ops'][g] if op=='and' else -base_meta['ops'][g]],
                                      [base_meta['lefts'][g][a]],[base_meta['rights'][g][b]]])
    assert pins==meta['pin_clauses'] and len(pins)==3*(21-len(holes))
    cnf.clauses.extend(pins)
    assert path.read_bytes()==local.dimacs(cnf)
    assert meta['variables']==cnf.variables and meta['clauses']==len(cnf.clauses)
    assert meta['clean_prefix_length']==0 and meta['output_selection_free']
    assert all(not meta[k] for k in ['enforce_junk','second_junk','prefix_sort','live','last_output','productive_prefix','assigned_shard_exhaustion'])
    assert 'fixed_output_wire' not in meta and [base_meta['output_selectors'][33]] not in cnf.clauses
    assert forced not in cnf.clauses
    all_clauses.append(set(map(tuple,cnf.clauses)))
    case_reports.append({**row,'full_clause_bytes_reconstructed':True,'pin_count':len(pins),
                         'unrestricted_output':True,'no_junk_condition':True})
assert all_clauses[1]<all_clauses[0]
assert len(all_clauses[0]-all_clauses[1])==12
reproduced=HERE/'best4-core-reproduced-v2';generator.generate(reproduced)
names=sorted(p.name for p in FAMILY.iterdir())
assert len(names)==7 and all((FAMILY/n).read_bytes()==(reproduced/n).read_bytes() for n in names)
try:generator.generate(FAMILY)
except ValueError:pass
else:raise AssertionError('Existing output directory accepted')
report={'verdict':'PASS_SELF_SCALAR_RENUMBERING_EXACT_CNF_MAIN_REVIEW_REQUIRED',
        'generator_sha256':sha(script),'audit_sha256':sha(Path(__file__)),
        'source_sha256':generator.SOURCE_SHA,'family_manifest_sha256':sha(FAMILY/'family.json'),
        'full_output_inputs':2048,'intermediate_wire_comparisons':wire_checks,'false_negatives':fn,'false_positives':fp,
        'minimal_extra_inputs':minimal,'remainder_edges':remainder_edges,'core_edges':core_edges,
        'core_function':'OR(six core edges) OR (x0 AND x2 AND x4)',
        'remainder_independent_of_core':True,'new_junk_positions':[17,19],
        'cases':case_reports,'broader_case_removes_exactly_12_star_pin_units':True,
        'byte_exact_reproduced_files':len(names),'existing_directory_rejected':True,'solver_launched':False,
        'scope':'Candidate-only neighborhoods. SAT still requires complete clause/model/full-input validation and Lean. No UNSAT or exhaustive/global claim.'}
out=HERE/'best4-core-review.json';out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'verdict':report['verdict'],'generator_sha256':sha(script),'review_sha256':sha(out),
                  'cases':case_reports,'wire_comparisons':wire_checks}))
