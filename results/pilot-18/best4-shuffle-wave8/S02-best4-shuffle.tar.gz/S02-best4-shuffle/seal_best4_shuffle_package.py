"""Seal completed source/control evidence, excluding all research runtime."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import re
import tarfile

ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S02'
STAGE=HERE/'best4-shuffle-preservation-stage/S02-best4-shuffle'
OUT=HERE/'best4-shuffle-preservation-v1'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
assert not OUT.exists() and not (STAGE/'MANIFEST.json').exists()
bindings=json.loads((STAGE/'copy-bindings.json').read_text())['files']
for row in bindings:
    source=Path(row['source']);raw=source.read_bytes()
    assert not source.is_relative_to(ROOT/'best4-core-pilot')
    assert raw==(STAGE/row['archive']).read_bytes() and sha(raw)==row['sha256'] and len(raw)==row['bytes']
repro=HERE/'best4-shuffle-package-reconstruction'
result=json.loads((repro/'validation.json').read_text())
assert result['verdict']=='PASS_TWO_CNF_SEVEN_FILE_BYTE_EXACT_RECONSTRUCTION' and result['CNFs']==2
assert result['exit_code']==0 and len(result['files'])==7 and not result['solver_launched']
for row in result['files']:assert sha((repro/row['path']).read_bytes())==row['sha256']
validation=STAGE/'validation';validation.mkdir()
for path in sorted(repro.iterdir()):
    if path.is_file():(validation/path.name).write_bytes(path.read_bytes())
for stem in ['best4-shuffle-assembly','best4-shuffle-reconstruct-help','best4-shuffle-reconstruction','best4-shuffle-negative-controls']:
    for suffix in ['.stdout','.stderr']:(validation/(stem+suffix)).write_bytes((HERE/(stem+suffix)).read_bytes())
negative=HERE/'best4-shuffle-reconstruction-controls'
assert json.loads((negative/'validation.json').read_text())['verdict']=='PASS_TWO_RECONSTRUCTION_REJECTIONS'
(validation/'negative-controls').mkdir()
for path in sorted(negative.iterdir()):
    if path.is_file():(validation/'negative-controls'/path.name).write_bytes(path.read_bytes())
for name in ['test_best4_package_reconstruction.py','verify_best4_shuffle_package.py']:
    (STAGE/name).write_bytes((HERE/name).read_bytes())
(STAGE/'seal_best4_shuffle_package.py').write_bytes(Path(__file__).read_bytes())
rows=[]
for path in sorted(STAGE.rglob('*')):
    assert not path.is_symlink()
    if not path.is_file():continue
    assert path.suffix!='.cnf'
    raw=path.read_bytes();text=raw.decode('utf-8')
    assert not re.search(r'github_pat_[A-Za-z0-9_]{30,}|gh[pousr]_[A-Za-z0-9_]{20,}|[?&]lease=[A-Za-z0-9_-]{16,}|-----BEGIN [A-Z ]*PRIVATE KEY-----',text),'Sensitive value indicator; no content printed'
    rows.append({'path':str(path.relative_to(STAGE)),'sha256':sha(raw),'bytes':len(raw)})
manifest={'scope':'Frozen best4 family and completed40row shuffle/wrapper controls only; all pilot/runtime and141rowintegration excluded.',
          'files':rows,'raw_CNF_members':0,'binary_members':0,'best4_runtime_included':False,'active_outputs_read':False}
(STAGE/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
OUT.mkdir();archive=OUT/'S02-best4-shuffle.tar.gz'
with archive.open('xb') as stream:
    with gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w',format=tarfile.USTAR_FORMAT) as tar:
            for path in sorted(STAGE.rglob('*')):
                if not path.is_file():continue
                raw=path.read_bytes();info=tarfile.TarInfo('S02-best4-shuffle/'+str(path.relative_to(STAGE)))
                info.size=len(raw);info.mode=0o644;info.uid=0;info.gid=0;info.mtime=0
                tar.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:gz') as tar:
    members=tar.getmembers()
    assert len(members)==len(rows)+1 and len({m.name for m in members})==len(members)
    for member in members:
        name=PurePosixPath(member.name)
        assert member.isfile() and not name.is_absolute() and '..' not in name.parts and name.parts[0]=='S02-best4-shuffle'
        assert tar.extractfile(member).read()==(STAGE/Path(*name.parts[1:])).read_bytes()
(OUT/'manifest.json').write_bytes((STAGE/'MANIFEST.json').read_bytes())
(OUT/'README.md').write_bytes((STAGE/'README.md').read_bytes())
review={'verdict':'PASS_SELF_BYTE_EXACT_PACKAGE_RECONSTRUCTION_AND_ARCHIVE_ROUNDTRIP_MAIN_REVIEW_REQUIRED',
        'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'archive_regular_members':len(members),
        'manifest_sha256':sha((OUT/'manifest.json').read_bytes()),'exact_source_copies':len(bindings),
        'reconstruction_sources':9,'reconstruction_CNF_files':2,'reconstruction_files':7,
        'reconstruction_exit_code':0,'reconstruction_negative_controls':2,
        'shuffle_DAGs':1000,'shuffle_all_input_intermediate_comparisons':43008000,
        'shuffle_all_input_output_comparisons':2048000,'finite_CLI_controls':8,'finite_wrapper_controls':8,
        'expected_forged_candidate_rejection':True,'main_best4_review_included':True,
        'best4_runtime_included':False,'production_141_integration_included':False,
        'raw_CNF_members':0,'binary_members':0,'sensitive_value_indicators':0,
        'active_outputs_read':False,'solver_launched':False,'repository_artifacts_changed':False,
        'scope':'Portable preparation and completed finite controls, not a solver outcome, exact21 witness, accepted certificate, or posted-checker verdict.'}
(OUT/'validation.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(review))
