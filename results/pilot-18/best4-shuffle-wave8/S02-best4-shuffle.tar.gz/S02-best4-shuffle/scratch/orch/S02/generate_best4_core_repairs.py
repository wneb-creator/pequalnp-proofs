"""Two exact-target candidate neighborhoods after remainder-first rescheduling.

No solver or worker is launched. All13 independent remainder gates precede the
seven-gate dirty core. The first neighborhood frees the core and final gate;
the second additionally frees the four gates of the 10-star.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode=True
ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S02'
SOURCE=ROOT/'orch/MAIN/allnegative-best4/source.json'
SOURCE_SHA='b6da8ac6962d7836f2e5546423f5ed3846b7165fbe1ae47e58b8e470955101b0'
HELPER_SHA='7552f3d344d4e34a6f681b116b5ec748e032b2000315dfc9527c77f8de2bdb6b'
CORE=list(range(1,8));STAR=list(range(13,17))
ORDER=[0,*range(8,20),*CORE,20]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def dependencies():
    path=HERE/'prepare_positive_repairs.py'
    if sha(path.read_bytes())!=HELPER_SHA:raise ValueError('Reviewed helper hash mismatch')
    spec=importlib.util.spec_from_file_location('best4_core_helpers',path)
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    return helper,helper.dependencies()


def reorder(data):
    if sorted(ORDER)!=list(range(21)):raise ValueError('Bad schedule')
    mapping={old:new for new,old in enumerate(ORDER)}
    wire=lambda w:w if w<13 else 13+mapping[w-13]
    gates=[]
    for new,old in enumerate(ORDER):
        op,a,b=data['gates'][old];a,b=sorted((wire(a),wire(b)))
        if not 0<=a<=b<13+new:raise ValueError('Non-topological schedule')
        gates.append([op,a,b])
    return {'inputs':11,'gate_wire_offset':13,'size':21,'gates':gates,'output':wire(data['output'])},mapping


def generate(output):
    if output.exists():raise ValueError('Fresh output directory required')
    raw=SOURCE.read_bytes()
    if sha(raw)!=SOURCE_SHA:raise ValueError('Immutable source hash mismatch')
    source=json.loads(raw);helper,(_,_,local,base)=dependencies()
    validator=local.load(ROOT/'validate_raw_candidate.py','best4_structure_validator',local.RAW_SHA)
    offset,gates,out=validator.check_structure(source)
    local.require(offset==13 and len(gates)==21 and out==33,'Expected21gate source')
    remainder=set(range(20))-set(CORE)
    local.require(len(remainder)==13 and all(w<13 or w-13 in remainder for g in remainder for w in gates[g][1:]),'Remainder depends on core')
    data,mapping=reorder(source);validator.check_structure(data)
    for mask in range(2048):
        before=local.scalar_values(gates,mask);after=local.scalar_values(data['gates'],mask)
        local.require(before[out]==after[data['output']],'Output changed')
        local.require(all(before[13+g]==after[13+mapping[g]] for g in range(21)),'Intermediate changed')
        expected=local.target(mask) or all(mask>>i&1 for i in (0,2,4))
        local.require(after[data['output']]==expected,'Unexpected source function')
    summary=local.source_summary(data)
    local.require(summary['full_2048_false_negative_count']==0 and summary['full_2048_false_positive_count']==4
                  and len(summary['live_gates'])==21,'Unexpected error or liveness count')
    output.mkdir(parents=True,exist_ok=False)
    (output/'original-source.json').write_bytes(raw)
    source_name='remainder-first-source.json'
    (output/source_name).write_text(json.dumps(data,indent=2)+'\n')
    manifest={'kind':'candidate_only_best4_remainder_first_core_repairs','complete':False,
              'program_sha256':sha(Path(__file__).read_bytes()),'original_source_sha256':SOURCE_SHA,
              'helper_sha256':HELPER_SHA,'base_generator_sha256':local.BASE_SHA,
              'source_file':source_name,'source_sha256':sha((output/source_name).read_bytes()),
              'new_to_old_gate':ORDER,'old_to_new_gate':[mapping[g] for g in range(21)],
              'source_summary':summary,'output_selection_free':True,'assigned_shard_exhaustion':False,
              'scope':'Restricted candidate neighborhoods; no global completeness or certificate claim.',
              'cases':[]}
    for case,old_holes in [('core-h08',CORE+[20]),('core-star-h12',CORE+STAR+[20])]:
        holes=sorted(mapping[g] for g in old_holes)
        cnf,meta=helper.local_free_output(local,base,data,holes)
        meta.update(program=Path(__file__).name,program_sha256=manifest['program_sha256'],
                    original_source_sha256=SOURCE_SHA,source_sha256=manifest['source_sha256'],source_file=source_name,
                    new_to_old_gate=ORDER,old_to_new_gate=manifest['old_to_new_gate'],
                    old_free_gates=sorted(old_holes),
                    scope='Candidate-only exact-target core repair with unrestricted output; no first-junk or two-junk condition.')
        raw_cnf=local.dimacs(cnf);meta['sha256']=sha(raw_cnf)
        path=output/(case+'.cnf');path.write_bytes(raw_cnf)
        path.with_suffix('.json').write_text(json.dumps(meta,indent=2)+'\n')
        manifest['cases'].append({'case':case,'kind':'local','budget':None,'free_gates':holes,
                                 'old_free_gates':sorted(old_holes),'variables':cnf.variables,'clauses':len(cnf.clauses),
                                 'cnf_sha256':meta['sha256'],'metadata_sha256':sha(path.with_suffix('.json').read_bytes())})
    manifest['complete']=True
    (output/'family.json').write_text(json.dumps(manifest,indent=2)+'\n')
    return manifest


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('output',type=Path)
    result=generate(parser.parse_args().output)
    print(json.dumps({'cases':result['cases'],'source_sha256':result['original_source_sha256'],
                      'program_sha256':result['program_sha256'],'solver_launched':False}))
