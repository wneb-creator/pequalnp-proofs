#define main frozen_engine_main_for_controls
#include "circuit_anneal_shuffle.cpp"
#undef main

namespace {
void require_control(bool ok,const char* message) {
 if(!ok)throw std::runtime_error(message);
}
std::array<unsigned char,OFFSET+GATES> independent_values(const Circuit& c,int mask) {
 std::array<unsigned char,OFFSET+GATES> values{};
 for(int i=0;i<N;++i)values[i]=(mask>>i)&1;
 values[12]=1;
 for(int g=0;g<GATES;++g) {
  auto gate=c.gates[g];
  require_control(gate.op==0 || gate.op==1,"Control operator invalid");
  require_control(gate.a>=0 && gate.b>=0 && gate.a<OFFSET+g && gate.b<OFFSET+g,"Control wire invalid");
  values[OFFSET+g]=gate.op?(values[gate.a]&values[gate.b]):(values[gate.a]|values[gate.b]);
 }
 return values;
}
}

int main() try {
 std::mt19937_64 fixtures(134230);
 Engine engine(134231),identical_engine(134231);
 uint64_t intermediate=0,outputs=0;
 int moved=0,dead_cases=0,input_outputs=0,nonlast_outputs=0,repeated_cases=0,constant_cases=0;
 Circuit last{};
 for(int trial=0;trial<1000;++trial) {
  Circuit source{};bool repeated=false,constant=false;
  for(int g=0;g<GATES;++g) {
   int limit=OFFSET+g;
   Gate t{int(fixtures()%2),int(fixtures()%limit),int(fixtures()%limit)};
   if(trial%10==0 && g) {t.a=OFFSET+g-1;t.b=int(fixtures()%OFFSET);}
   if(trial%10==1) {t.a=int(fixtures()%OFFSET);t.b=int(fixtures()%OFFSET);}
   if(trial%10==2) {t.a=g?OFFSET+g-1:int(fixtures()%OFFSET);t.b=t.a;}
   if(trial%10==3 && g>=2) {t.a=OFFSET+g-2;t.b=OFFSET+g-1;}
   if(trial%10==5) {t.a=11+int(fixtures()%2);t.b=g?OFFSET+g-1:12;}
   if(t.a>t.b)std::swap(t.a,t.b);
   if(trial%17==0)std::swap(t.a,t.b);
   repeated|=t.a==t.b;constant|=(t.a==11 || t.a==12 || t.b==11 || t.b==12);
   source.gates[g]=t;
  }
  switch(trial%6) {
   case 0:source.output=int(fixtures()%N);break;
   case 1:source.output=11;break;
   case 2:source.output=12;break;
   case 3:source.output=OFFSET+int(fixtures()%GATES);break;
   case 4:source.output=OFFSET;break;
   default:source.output=OFFSET+GATES-1;
  }
  Circuit original=source;std::array<int,GATES> mapping{},again{};
  Circuit shuffled=engine.shuffle_topological(source,&mapping);
  Circuit deterministic=identical_engine.shuffle_topological(source,&again);
  require_control(same_circuit(source,original),"Source was mutated");
  require_control(same_circuit(shuffled,deterministic) && mapping==again,"Shuffle is not seed deterministic");
  std::array<bool,GATES> seen{};bool changed=false;
  auto map_wire=[&](int wire){return wire<OFFSET?wire:OFFSET+mapping[wire-OFFSET];};
  for(int old=0;old<GATES;++old) {
   int next=mapping[old];require_control(next>=0 && next<GATES && !seen[next],"Invalid permutation");seen[next]=true;
   auto before=source.gates[old],after=shuffled.gates[next];
   int a=map_wire(before.a),b=map_wire(before.b);if(a>b)std::swap(a,b);
   require_control(after.op==before.op && after.a==a && after.b==b,"Renamed gate differs");
   require_control(after.a>=0 && after.a<=after.b && after.b<OFFSET+next,"Noncanonical or forward shuffle wire");
   changed|=next!=old;
  }
  require_control(shuffled.output==map_wire(source.output),"Output renaming mismatch");
  auto old_live=engine.live(source),new_live=engine.live(shuffled);
  for(int old=0;old<GATES;++old)require_control(old_live[old]==new_live[mapping[old]],"Liveness changed");
  auto old_score=engine.score(source,7),new_score=engine.score(shuffled,7);
  require_control(old_score.fn==new_score.fn && old_score.fp==new_score.fp && old_score.live==new_score.live && old_score.energy==new_score.energy,"Score changed");
  for(int mask=0;mask<(1<<N);++mask) {
   auto before=independent_values(source,mask),after=independent_values(shuffled,mask);
   for(int input=0;input<OFFSET;++input)require_control(before[input]==after[input],"Input or constant changed");
   for(int old=0;old<GATES;++old) {
    require_control(before[OFFSET+old]==after[OFFSET+mapping[old]],"Intermediate truth function changed");++intermediate;
   }
   require_control(before[source.output]==after[shuffled.output],"Output truth function changed");++outputs;
  }
  moved+=changed;dead_cases+=old_score.live<GATES;input_outputs+=source.output<OFFSET;
  nonlast_outputs+=source.output!=OFFSET+GATES-1;repeated_cases+=repeated;constant_cases+=constant;last=source;
 }
 require_control(intermediate==43008000 && outputs==2048000,"Wrong finite control count");
 require_control(moved>0 && dead_cases>0 && input_outputs>0 && nonlast_outputs>0 && repeated_cases>0 && constant_cases>0,"Missing edge-case coverage");
 int rejected=0;
 for(int kind=0;kind<5;++kind) {
  Circuit bad=last;
  if(kind==0)bad.output=-1;
  if(kind==1)bad.output=OFFSET+GATES;
  if(kind==2)bad.gates[0].op=2;
  if(kind==3)bad.gates[0].a=-1;
  if(kind==4)bad.gates[5].b=OFFSET+5;
  try {engine.shuffle_topological(bad);}catch(const std::runtime_error&){++rejected;}
 }
 require_control(rejected==5,"Malformed shuffle input accepted");
 std::cout<<"{\"status\":\"PASS_SHUFFLE_FULL_TRUTH_CONTROLS\",\"random_DAGs\":1000,\"inputs_per_DAG\":2048,\"intermediate_comparisons\":"<<intermediate
  <<",\"output_comparisons\":"<<outputs<<",\"nonidentity_schedules\":"<<moved<<",\"dead_gate_cases\":"<<dead_cases
  <<",\"input_or_constant_outputs\":"<<input_outputs<<",\"nonlast_outputs\":"<<nonlast_outputs<<",\"repeated_operand_cases\":"<<repeated_cases
  <<",\"constant_operand_cases\":"<<constant_cases<<",\"malformed_rejections\":"<<rejected<<",\"seed_determinism\":true}\n";
 return 0;
} catch(const std::exception& error) {std::cerr<<"CONTROL_ERROR: "<<error.what()<<"\n";return 1;}
