"""Tiny finite compatibility controls; no production annealer or solver run."""
from pathlib import Path
import hashlib
import json
import resource
import subprocess
import time

ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S02/shuffle-engine-v1'
OUT=HERE/'cli-controls';OUT.mkdir(exist_ok=False)
PARENT=ROOT/'orch/S05/direct21-v1/circuit_anneal_direct21'
NEW=HERE/'circuit_anneal_shuffle'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(PARENT)=='cace36645bc4a5c827f5a221965ccdef78c554e6d940d69645da292be6c0b51a'
edges=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
target=lambda m:any(m>>a&1 and m>>b&1 for a,b in edges)
boundary=[(1<<a)|(1<<b) for a,b in edges]+[m for m in range(2048) if not target(m) and all(m>>i&1 or target(m|(1<<i)) for i in range(11))]


def values(data,mask):
    assert data['inputs']==11 and data['gate_wire_offset']==13
    vals=[bool(mask>>i&1) for i in range(11)]+[False,True]
    for g,(op,a,b) in enumerate(data['gates']):
        assert op in ('and','or') and type(a)is int and type(b)is int and 0<=a<=b<13+g
        vals.append(vals[a] and vals[b] if op=='and' else vals[a] or vals[b])
    assert type(data['output'])is int and 0<=data['output']<len(vals)
    return vals


baseline_path=ROOT/'lean-setup/cover-neighborhood-controls/reproduced/c0000-k08.baseline22.json'
baseline=json.loads(baseline_path.read_text());assert len(baseline['gates'])==22
direct_path=ROOT/'orch/S02/triangle589-best3-source.json'
assert sha(direct_path)=='9a743d5d43f651198f908fd086b3307e036697ee9d9990f5c0edfcce6ff3fe96'
direct=json.loads(direct_path.read_text());assert len(direct['gates'])==21
truth=14695981039346656037;fn=fp=0
for mask in range(2048):
    assert values(baseline,mask)[baseline['output']]==target(mask)
    actual=values(direct,mask)[direct['output']]
    fn+=target(mask) and not actual;fp+=actual and not target(mask)
    truth=((truth^actual)*1099511628211)&((1<<64)-1)
assert (fn,fp)==(0,5)
for name,data,header in [('legacy',baseline,f'COVER_ANNEAL 1 1\n22 {baseline["output"]}\n'),
                         ('direct',direct,f'COVER_ANNEAL_DIRECT21 1 1\n21 {direct["output"]} {fn} {fp} {truth}\n')]:
    (OUT/(name+'.pack')).write_text(header+''.join(f'{int(op=="and")} {a} {b}\n' for op,a,b in data['gates']))


def limits():
    resource.setrlimit(resource.RLIMIT_CPU,(10,10))
    resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,256*1024**2))


commands=[];reports={};candidate_files=[]
def run(label,binary,pack,extra):
    directory=OUT/label;directory.mkdir()
    output=directory/'result.json'
    argv=[str(binary),'--pack',str(pack),'--output',str(output),'--seed','134230','--seconds','10',
          '--iterations','1001','--restart','100','--weight','16',*extra]
    started=time.monotonic()
    with (directory/'stdout').open('x') as a,(directory/'stderr').open('x') as b:
        proc=subprocess.run(argv,stdout=a,stderr=b,timeout=15,preexec_fn=limits)
    commands.append({'label':label,'argv':argv,'exit_code':proc.returncode,'wall_seconds':time.monotonic()-started})
    assert proc.returncode in (0,10) and (directory/'stderr').stat().st_size==0
    result=json.loads(output.read_text());reports[label]=result
    if '--self-test' not in extra:
        vals={m:values(result,m)[result['output']] for m in range(2048)}
        assert result['false_negatives']==sum(target(m) and not vals[m] for m in boundary)
        assert result['false_positives']==sum(not target(m) and vals[m] for m in boundary)
        if proc.returncode==10:
            assert all(vals[m]==target(m) for m in range(2048));candidate_files.append(str(output))
    return result,directory


defaults=[];starts=[]
for kind in ['legacy','direct']:
    pack=OUT/(kind+'.pack')
    parent,parent_dir=run(kind+'-parent',PARENT,pack,[])
    off,off_dir=run(kind+'-default-off',NEW,pack,[])
    same=lambda data:{k:v for k,v in data.items() if k!='elapsed_seconds'}
    assert same(parent)==same(off)
    old=sorted(parent_dir.glob('result.json.best-*.json'));new=sorted(off_dir.glob('result.json.best-*.json'))
    assert len(old)==len(new)
    for a,b in zip(old,new):assert same(json.loads(a.read_text()))==same(json.loads(b.read_text()))
    defaults.append({'pack':kind,'all_result_fields_except_clock_equal':True,'best_snapshots_equal':len(old),
                     'iterations':off['iterations'],'restarts':off['restarts']})
    on,on_dir=run(kind+'-enabled',NEW,pack,['--shuffle-restarts'])
    old_start=json.loads((off_dir/'result.json.best-0.json').read_text())
    new_start=json.loads((on_dir/'result.json.best-0.json').read_text())
    old_functions=[0]*21;new_functions=[0]*21
    for mask in range(2048):
        a=values(old_start,mask);b=values(new_start,mask)
        assert a[old_start['output']]==b[new_start['output']]
        for g in range(21):old_functions[g]|=int(a[13+g])<<mask;new_functions[g]|=int(b[13+g])<<mask
    assert sorted(old_functions)==sorted(new_functions)
    starts.append({'pack':kind,'output_checks':2048,'all21_intermediate_functions_preserved_as_multiset':True,
                   'nonidentity_initial_schedule':old_start['gates']!=new_start['gates']})
    selftest,_=run(kind+'-self-test-flag',NEW,pack,['--self-test','--shuffle-restarts'])
    assert selftest['status'] in ('SELF_TEST_PASS','SELF_TEST_DIRECT21_PASS')

report={'verdict':'PASS_FINITE_LEGACY_DIRECT_DEFAULT_OFF_AND_ENABLED_CONTROLS',
        'source_sha256':sha(HERE/'circuit_anneal_shuffle.cpp'),'binary_sha256':sha(NEW),'parent_binary_sha256':sha(PARENT),
        'baseline_source_sha256':sha(baseline_path),'direct_source_sha256':sha(direct_path),
        'commands':commands,'default_off_comparisons':defaults,'enabled_start_checks':starts,
        'candidate_files':candidate_files,'production_launched':False,
        'scope':'1001-iteration fixed-seed compatibility controls and inherited self-tests only; no production worker or solver.'}
(OUT/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'verdict':report['verdict'],'commands':len(commands),'default_off_comparisons':defaults,
                  'enabled_start_checks':starts,'candidate_files':candidate_files}))
