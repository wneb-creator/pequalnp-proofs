"""Preserve frozen source and completed controls only; no active runtime reads."""
from pathlib import Path
import hashlib
import json
import re

ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S02'
STAGE=HERE/'best4-shuffle-preservation-stage/S02-best4-shuffle'
STAGE.mkdir(parents=True,exist_ok=False)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
bindings=[]


def copy(source,relative):
    assert source.is_file() and not source.is_symlink() and source.suffix!='.cnf'
    raw=source.read_bytes();text=raw.decode('utf-8')
    assert not re.search(r'github_pat_[A-Za-z0-9_]{30,}|gh[pousr]_[A-Za-z0-9_]{20,}|[?&]lease=[A-Za-z0-9_-]{16,}|-----BEGIN [A-Z ]*PRIVATE KEY-----',text),'Sensitive value indicator; no content printed'
    path=STAGE/relative;path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream:stream.write(raw)
    assert source.read_bytes()==raw
    bindings.append({'source':str(source),'archive':relative,'sha256':sha(raw),'bytes':len(raw)})


needed=['orch/S02/generate_best4_core_repairs.py','orch/S02/prepare_positive_repairs.py',
        'orch/S02/generate_rescheduled_repairs.py','lean-setup/generate_distance_repairs.py',
        'lean-setup/generate_local_repairs.py','search_l1342_shard17_ancestorreverse.py',
        'validate_raw_candidate.py','lean-setup/validate_sat_candidate.py','orch/MAIN/allnegative-best4/source.json']
sources=[]
for name in needed:
    relative='scratch/'+name;copy(ROOT/name,relative)
    sources.append({'scratch_path':name,'package_path':relative,'sha256':sha((ROOT/name).read_bytes())})

family=HERE/'best4-core-family'
expected={p.name:sha(p.read_bytes()) for p in sorted(family.iterdir())}
assert len(expected)==7 and sum(n.endswith('.cnf') for n in expected)==2
for path in sorted(family.iterdir()):
    if path.suffix!='.cnf':copy(path,'best4-family/'+path.name)
for name in ['audit_best4_core_repairs.py','best4-core-review.json','run_best4_core_pilot.py',
             'run_best4_core_pilot.diff','run_best4_core_pilot.derivation.json',
             'best4-core-controller-review.json','best4-core-handoff.json']:
    copy(HERE/name,'best4-reviews/'+name)
copy(ROOT/'orch/MAIN/main-best4-core-review.json','best4-reviews/main-best4-core-review.json')
copy(ROOT/'orch/MAIN/allnegative-best4/scalar-review.json','best4-reviews/main-scalar-review.json')
copy(ROOT/'run_best3_rescheduled_pilot.py','parents/run_best3_rescheduled_pilot.py')
copy(ROOT/'lean-setup/stochastic/stochastic_tools.py','parents/stochastic_tools.py')

frozen=HERE/'shuffle-engine-v1'
for path in sorted(frozen.rglob('*')):
    assert not path.is_symlink()
    if path.is_file() and path.name not in ['circuit_anneal_shuffle','test_shuffle']:
        copy(path,'shuffle/'+str(path.relative_to(frozen)))
for name in ['shuffle-engine-handoff.json','shuffle-wrapper-handoff.json',
             'prepare_shuffle_engine.py','prepare_shuffle_wrapper_and_core_controller.py',
             'seal_shuffle_review.py','seal_shuffle_wrapper_and_core.py']:
    copy(HERE/name,'shuffle-provenance/'+name)
for stem,suffixes in [
    ('best4-core-help',['.stdout','.stderr']),('best4-core-generation',['.stdout','.stderr']),
    ('best4-core-audit',['.stdout','.stderr']),('best4-core-audit-v2',['.stdout','.stderr']),
    ('shuffle-compiler-help',['.stdout.txt','.stderr.txt']),('shuffle-engine-preparation',['.stdout.txt','.stderr.txt']),
    ('shuffle-seal',['.stdout','.stderr']),('shuffle-wrapper-core-controller-preparation',['.stdout','.stderr']),
    ('shuffle-wrapper-core-seal',['.stdout','.stderr'])]:
    for suffix in suffixes:copy(HERE/(stem+suffix),'outer-logs/'+stem+suffix)
for path,relative in [
    (HERE/'triangle589-best3-source.json','control-fixtures/direct21-source.json'),
    (ROOT/'lean-setup/cover-neighborhood-controls/reproduced/c0000-k08.baseline22.json','control-fixtures/exact22-baseline.json')]:copy(path,relative)

full=json.loads((frozen/'full-controls.stdout').read_text())
cli=json.loads((frozen/'cli-controls/review.json').read_text())
wrapper=json.loads((frozen/'wrapper-controls/review.json').read_text())
assert full['random_DAGs']==1000 and full['intermediate_comparisons']==43008000 and full['output_comparisons']==2048000
assert len(cli['commands'])==8 and all(c['exit_code']==0 for c in cli['commands']) and not cli['candidate_files']
assert len(wrapper['commands'])==8 and wrapper['forged_inexact_candidate_rejected_by_unchanged_real_validator']
assert wrapper['commands'][-1]['exit_code']==1 and all(c['exit_code']==0 for c in wrapper['commands'][:-1])
status={'best4_CNF_cases':2,'best4_runtime_included':False,'main_launch_reported_in_conversation':True,
        'shuffle_full_truth_control':full,'finite_CLI_controls':8,'finite_wrapper_controls':8,
        'forged_candidate_error_is_expected_negative_control':True,'production_141_integration_included':False,
        'active_outputs_read':False,'new_workers_launched':False,
        'scope':'Sources and completed controls only. No exact21 witness, global/shard exhaustion, certified UNSAT or posted-checker result.'}
(STAGE/'snapshot-status.json').write_text(json.dumps(status,indent=2)+'\n')
(STAGE/'reconstruction.json').write_text(json.dumps({'sources':sources,'family':{
    'name':'best4-core-family','generator':'orch/S02/generate_best4_core_repairs.py','expected_files':expected},
    'scope':'Two CNFs, no solver or optimizer execution.'},indent=2)+'\n')
copy(HERE/'reconstruct_best4_package.py','reconstruct_best4_package.py')
copy(Path(__file__),'assemble_best4_shuffle_package.py')
(STAGE/'copy-bindings.json').write_text(json.dumps({'files':bindings},indent=2)+'\n')
(STAGE/'README.md').write_text('S02 best4 core repairs and optional shuffle preservation\n\n'
    'Frozen best4 source b6da8ac6962d7836f2e5546423f5ed3846b7165fbe1ae47e58b8e470955101b0 computes F OR x0*x2*x4, with four wrong full inputs21,29,85,149. Moving its independent13gate remainder before the7gate core preserves all2048outputs and43008intermediate values. The core-h08 family frees the core plus finalgate; core-star-h12 additionally frees the4gate10star and removes exactly12pin units. Both exact-target CNFs have5045variables and freeoutput, with no forcedjunk/clean-prefix/liveness requirement. Main independently reviewed the complete source, scalar checks, exactCNF reconstruction and controller delta.\n\n'
    'Main reported launching the two-case pilot; this archive deliberately contains NO pilot runtime, launch record, or active output. Historical READY/no-launch labels describe source review time. Their controller default is one worker,120s/case,150souterguard,1000MiBAS; it is preserved as code only and never executed by archive reconstruction. No SAT/UNSAT outcome is inferred.\n\n'
    'The fresh40row shuffle source adds an optional default-off randomKahn schedule over all21gates, including deadgates, constants and repeated operands. It preserves the complete output and allintermediate functions and canonicalizescommutativeports. Randomorders are not uniform. The exact six enginechanges and two wrapperchanges are retained. Wrapper preserves resource/provenance/abort/processgroup/independent-all2048-validator gates; it forwards --shuffle-restarts once whenenabled. Main newer141row integration and its separate review are NOT included.\n\n'
    'All completed evidence is retained: C++ build/harness fullstdoutstderr,1000DAGx2048allinput controls(43,008,000intermediate+2,048,000output comparisons), eight CLI legacy/direct/defaultoff/enabled/selftestcontrols, eight wrappercontrols including real-validator rejection of a deliberately forged inexact candidate, and every bestsnapshot. The expected forgedcontrol ERROR/exit1 demonstrates rejection, not a failed production run. Defaultoff snapshots/results match frozenparent except elapsedtime. No heuristic efficacy claim is made.\n\n'
    'Reconstruct only the CNFs using Python3 standardlibrary: python3 reconstruct_best4_package.py /tmp/oec/pequalnp-pilot-18/fresh-best4-reproduction. It verifies all nine sourcepins before staging any absent source under the named scratch root, refuses existing differingfiles, and checks all seven generatedfiles byte-for-byte. No solver, optimizer, compiler, network or Lean build is run. Fullcontrol source and logs are portable evidence; original CLI/wrapper Python controls retain historical absolute paths/binaryhashes and need a matching restored setup to rerun. The standalone C++ fulltruth harness can be rebuilt from shuffle/test_shuffle.cpp with g++ -std=c++17 -O2 -Wall -Wextra -pedantic; this source includes shuffle/circuit_anneal_shuffle.cpp. Compiler-dependent binaries are omitted and their historicalhashes retained in reviews.\n\n'
    'MANIFEST.json hashes every payload. No rawCNF, executablebinary, credential or leasevalue is included. No exact21 witness, global/shard refutation, acceptedcertificate, or posted-checker acceptance is claimed.\n')
print(json.dumps({'stage':str(STAGE),'exact_copies':len(bindings),'CNFs':2,'active_outputs_read':False}))
