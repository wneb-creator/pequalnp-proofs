from pathlib import Path
import datetime
import fcntl
import hashlib
import json
import os

ROOT=Path('/tmp/oec/pequalnp-pilot-18'); HERE=ROOT/'orch/S02'; D=HERE/'shuffle-engine-v1'
REPO=Path('/workspace/pequalnp-proofs')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
parent=ROOT/'orch/S05/direct21-v1/circuit_anneal_direct21.cpp'
assert sha(parent)=='e1a686c19d09439595cdfbf89baf42ff5d1dbfff8949e505b53b999d683ec077'
assert parent.read_bytes()==(D/'parent-circuit_anneal_direct21.cpp').read_bytes()
derivation=json.loads((D/'derivation.json').read_text())
text=parent.read_text()
for change in derivation['changes']:
    assert text.count(change['before'])==1
    text=text.replace(change['before'],change['after'])
assert text==(D/'circuit_anneal_shuffle.cpp').read_text()
assert len(derivation['changes'])==6
full=json.loads((D/'full-controls.stdout').read_text())
cli=json.loads((D/'cli-controls/review.json').read_text())
assert full['status']=='PASS_SHUFFLE_FULL_TRUTH_CONTROLS'
assert full['random_DAGs']==1000 and full['intermediate_comparisons']==43008000
assert full['output_comparisons']==2048000 and full['malformed_rejections']==5
assert cli['verdict']=='PASS_FINITE_LEGACY_DIRECT_DEFAULT_OFF_AND_ENABLED_CONTROLS'
assert len(cli['commands'])==8 and not cli['candidate_files']
assert all(row['exit_code']==0 for row in cli['commands'])
for name in ['build.stderr','test-build.stderr','help.stderr','full-controls.stderr','cli-controls.stderr']:
    assert (D/name).stat().st_size==0
readme='''Optional restart shuffle, based only on frozen S05 direct21 engine e1a686c19d09439595cdfbf89baf42ff5d1dbfff8949e505b53b999d683ec077.

Source circuit_anneal_shuffle.cpp adds Engine::shuffle_topological and the presence flag --shuffle-restarts (default false). engine.diff and derivation.json record the exact six changes. Input and virtual-constant IDs remain fixed. Random Kahn scheduling retains all 21 gates, including dead gates, repeated operands and duplicate computations, remaps all gate references and the output, and sorts each commutative operand pair. The distribution is not claimed uniform over topological orders.

Call sites: initial fresh circuit; best restart before its three mutations; fresh restart before the next mutation. Default-off makes no shuffle RNG draws. The original score, mutation, loaders, candidate validation, output format, and inherited self-tests are unchanged. Both legacy exact22 packs (after the usual deletion) and direct21 packs are supported. --self-test remains the inherited self-test; test_shuffle.cpp is the separate full-truth shuffle audit.

Integration into main's newer 141-row engine requires independent review: port the helper, flag declaration/parser/help and three call sites; do not replace the newer engine wholesale. No wrapper is changed here. A wrapper must explicitly forward the new flag. Record launch argv and source SHA; result JSON does not separately record the flag. Parent and production sources/workers were not changed.

Build: g++ -std=c++17 -O2 -Wall -Wextra -pedantic circuit_anneal_shuffle.cpp -o circuit_anneal_shuffle. Harness: same flags on test_shuffle.cpp. Debian g++14.2.0 capability was checked. Full stdout/stderr are retained. Build and harness exit0 with empty stderr.

Validation: 1000 deterministic random/structured DAGs, all 2048 inputs, 43,008,000 mapped intermediate comparisons and 2,048,000 output comparisons. Includes chains, diamonds, repeated ports, dead gates, constants, input/nonlast outputs and malformed input rejection. Eight finite compatibility controls cover both pack types, default-off byte-equivalent results/snapshots except elapsed_seconds, enabled starts preserving all intermediate functions, and inherited self-tests. All controls exit0; no exact21 candidate found. These are bounded software controls, not a proof or accepted gap result. No production optimizer or SAT solver launched. Performance improvement has not been measured.
'''
(D/'README.md').write_text(readme)
files=[]
for p in sorted(D.rglob('*')):
    if p.is_file() and p.name not in ('circuit_anneal_shuffle','test_shuffle','review.json'):
        files.append({'path':str(p.relative_to(D)),'sha256':sha(p),'bytes':p.stat().st_size})
# Include the nested CLI review even though the top-level review is not yet written.
p=D/'cli-controls/review.json'
files.append({'path':str(p.relative_to(D)),'sha256':sha(p),'bytes':p.stat().st_size})
review={'verdict':'PASS_SOURCE_SELF_REVIEW_AND_FINITE_CONTROLS_MAIN_REVIEW_REQUIRED',
        'source_sha256':sha(D/'circuit_anneal_shuffle.cpp'),'parent_sha256':sha(parent),
        'binary_sha256':sha(D/'circuit_anneal_shuffle'),'diff_sha256':sha(D/'engine.diff'),
        'exact_six_replacements_reconstructed':True,'parent_unchanged':True,
        'mathematics':'Induct on Kahn emission: selected gate predecessors already mapped; Boolean operation and fixed inputs/constants preserve its full function. Bijection retains all dead/duplicate gates; output remapping preserves the output.',
        'scope':'Optional source patch; no production, solver, Lean or posted checker result. Independent main review remains necessary.',
        'full_truth_controls':full,'cli_review_sha256':sha(p),
        'default_off_comparisons':cli['default_off_comparisons'],
        'risks':['Topological orders are not sampled uniformly.','Heuristic effectiveness unmeasured.','New141 integration and wrapper forwarding need independent review.'],
        'artifacts':files}
(D/'review.json').write_text(json.dumps(review,indent=2)+'\n')
handoff={'status':'READY_FOR_MAIN_INDEPENDENT_REVIEW_NO_PRODUCTION',
         'directory':str(D),'source':str(D/'circuit_anneal_shuffle.cpp'),
         'source_sha256':review['source_sha256'],'diff':str(D/'engine.diff'),
         'diff_sha256':review['diff_sha256'],'review':str(D/'review.json'),
         'review_sha256':sha(D/'review.json'),'full_controls':full,
         'parent_sha256':sha(parent),'legacy_direct_default_off_enabled_controls':'PASS',
         'integration':'Port only the six recorded source changes into the independently reviewed main engine; retain its 141-row scoring and wrapper policy.',
         'production_launched':False}
(HERE/'shuffle-engine-handoff.json').write_text(json.dumps(handoff,indent=2)+'\n')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
entry=f'\n- {now} — S02 OPTIONAL SHUFFLE READY_MAIN_REVIEW: source {review["source_sha256"]}, diff {review["diff_sha256"]}, review {sha(D/"review.json")}; handoff orch/S02/shuffle-engine-handoff.json. FrozenS05 parent e1a686 unchanged; exact six replacements add default-off --shuffle-restarts and random Kahn all21gates before initial/fresh/best-restart mutations. All43,008,000 intermediate+2,048,000 output comparisons on1000DAGs PASS, includingdead/repeated/constants/nonlast outputs,5malformedrejections. Legacy/direct finitecontrols8exit0; default-off same snapshots/results exceptclock, enabled initialall2048 functions preserved. No production/solver/141source mutation. Main must port/review sixchanges, not replace141source; performanceunmeasured. Next S02 best4 R-first7core+finalOR repair family from immutable b6da8ac...101b0; S05owns algebra/pack. Sub-agents:none.\n'
with (ROOT/'orch-notes.lock').open('a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    for report in [REPO/'results/orch/NOTES.md',REPO/'results/orch/lemmas/S02-sat-repairs.md']:
        with report.open('a') as out:out.write(entry);out.flush();os.fsync(out.fileno())
print(json.dumps({k:v for k,v in handoff.items() if k not in ('full_controls',)},indent=2))
