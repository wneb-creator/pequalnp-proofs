"""Bind completed controls and ready candidate-only artifacts; no launch."""
from pathlib import Path
import ast
import datetime
import fcntl
import hashlib
import json
import os
import re

ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S02';D=HERE/'shuffle-engine-v1'
REPO=Path('/workspace/pequalnp-proofs');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def binding(path):
    return {'path':str(path),'sha256':sha(path),'bytes':path.stat().st_size}


wrapper=D/'stochastic_tools_shuffle.py'
derivation=json.loads(wrapper.with_suffix('.derivation.json').read_text())
parent=Path(derivation['parent']);text=parent.read_text()
assert sha(parent)==derivation['parent_sha256']
for change in derivation['changes']:
    assert text.count(change['before'])==1;text=text.replace(change['before'],change['after'])
assert text==wrapper.read_text() and len(derivation['changes'])==2
old=ast.parse(parent.read_text());new=ast.parse(text)
old_run=next(n for n in old.body if isinstance(n,ast.FunctionDef) and n.name=='run')
new_run=next(n for n in new.body if isinstance(n,ast.FunctionDef) and n.name=='run')
flag=next(n for n in new_run.body if isinstance(n,ast.If) and ast.unparse(n.test)=='args.shuffle_restarts')
new_run.body.remove(flag);assert ast.dump(old_run)==ast.dump(new_run)
control_path=D/'wrapper-controls/review.json';controls=json.loads(control_path.read_text())
assert controls['verdict']=='PASS_WRAPPER_FORWARDING_DEFAULT_OFF_ABORT_AND_REAL_VALIDATOR_REJECTION'
assert controls['source_sha256']==sha(wrapper) and len(controls['commands'])==8
assert controls['abort_before_start_pass'] and controls['forged_inexact_candidate_rejected_by_unchanged_real_validator']
review={'verdict':'PASS_SELF_TWO_CHANGE_WRAPPER_FORWARDING_MAIN_REVIEW_REQUIRED',
        'source':binding(wrapper),'parent':binding(parent),'diff':binding(wrapper.with_suffix('.diff')),
        'exact_two_replacements_reconstructed':True,
        'run_AST_identical_after_removing_only_flag_append':True,
        'unchanged':['all resource limits','abort and signals','child process group termination','pack and validator SHA checks',
                     'engine/wrapper/pack provenance','full stdout/stderr','all best snapshots','real independent all2048 validator','requires Lean status'],
        'controls':binding(control_path),'default_off_result_and_snapshots_equal_except_clock':True,
        'no_production_launch':True,'risks':['Wrapper records flag in command argv, not a separate boolean field.',
                                           'Main141 engine integration is outside this review; pass its independently reviewed binary via --engine.']}
(D/'wrapper-review.json').write_text(json.dumps(review,indent=2)+'\n')
wrapper_handoff={'status':'READY_MAIN_REVIEW_NO_PRODUCTION','wrapper':binding(wrapper),
                 'review':binding(D/'wrapper-review.json'),'diff':binding(wrapper.with_suffix('.diff')),
                 'derivation':binding(wrapper.with_suffix('.derivation.json')),'controls':binding(control_path),
                 'test_source':binding(D/'test_wrapper.py'),
                 'integration':'Use this fresh wrapper in place of stochastic_tools.py and add --shuffle-restarts to its run subcommand. Pass main independently reviewed141-shuffle binary as --engine. All resource/provenance/independent-validator/lifecycle paths remain unchanged.',
                 'default_off':True,'production_launched':False,
                 'control_artifacts':[binding(p) for p in sorted((D/'wrapper-controls').rglob('*')) if p.is_file()]}
(HERE/'shuffle-wrapper-handoff.json').write_text(json.dumps(wrapper_handoff,indent=2)+'\n')

family=HERE/'best4-core-family';manifest=json.loads((family/'family.json').read_text())
core_review=json.loads((HERE/'best4-core-review.json').read_text())
controller_review=json.loads((HERE/'best4-core-controller-review.json').read_text())
assert manifest['complete'] and len(manifest['cases'])==2
assert core_review['family_manifest_sha256']==sha(family/'family.json')
assert core_review['generator_sha256']==sha(HERE/'generate_best4_core_repairs.py')
assert core_review['audit_sha256']==sha(HERE/'audit_best4_core_repairs.py')
assert controller_review['source_sha256']==sha(HERE/'run_best4_core_pilot.py')
paths=[HERE/'generate_best4_core_repairs.py',HERE/'audit_best4_core_repairs.py',
       HERE/'best4-core-review.json',HERE/'run_best4_core_pilot.py',HERE/'run_best4_core_pilot.diff',
       HERE/'run_best4_core_pilot.derivation.json',HERE/'best4-core-controller-review.json',
       HERE/'best4-core-generation.stdout',HERE/'best4-core-generation.stderr',
       HERE/'best4-core-audit-v2.stdout',HERE/'best4-core-audit-v2.stderr',*sorted(family.iterdir())]
for path in paths+[wrapper,control_path]:
    assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|Authorization:\s*Bearer\s+\S+|[?&]lease=[A-Za-z0-9_-]{12,})',path.read_bytes())
handoff={'status':'READY_MAIN_INDEPENDENT_REVIEW_NO_SOLVER','generator':binding(HERE/'generate_best4_core_repairs.py'),
         'family':binding(family/'family.json'),'review':binding(HERE/'best4-core-review.json'),
         'controller':binding(HERE/'run_best4_core_pilot.py'),'controller_review':binding(HERE/'best4-core-controller-review.json'),
         'source_sha256':manifest['original_source_sha256'],'cases':manifest['cases'],
         'controls':'All2048 outputs and43008 intermediate wire values preserved; independent six-edge core/ten-edge remainder formula checks; complete two CNFs reconstructed and seven files reproduced byte-exact.',
         'suggested_priority':['core-h08','core-star-h12'],'default_workers':1,'solver_seconds_per_case':120,'outer_guard_seconds':150,
         'unexecuted_coordinator_command':['python3','-B',str(HERE/'run_best4_core_pilot.py')],
         'scope':'Exact-target candidate-only repairs. Unrestricted output and no junk/clean-prefix/liveness requirement. Broader case removes12 pin units. No solver run, certificate, global exhaustion or Lean witness.',
         'artifacts':[binding(p) for p in paths]}
(HERE/'best4-core-handoff.json').write_text(json.dumps(handoff,indent=2)+'\n')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
entry=f'\n- {now} — S02 SHUFFLE WRAPPER + BEST4 CORE READY_MAIN_REVIEW: freshwrapper {sha(wrapper)} exacttwochanges(action_store_true+conditionalargvappend), review {sha(D/"wrapper-review.json")}, handoff orch/S02/shuffle-wrapper-handoff.json. Eight finitecontrols PASS legacy/direct/default-off/enabled, abortbeforestart, forgedinexactcandidatecode10 rejectedbyunchangedrealvalidator; all lifecycle/resource/provenance pathsASTunchanged. Mainowns141integration; no duplicateintegration. Best4 generator {sha(HERE/"generate_best4_core_repairs.py")}, audit {sha(HERE/"best4-core-review.json")}, handoff orch/S02/best4-core-handoff.json. b6da8ac...101b0 independentlyF OR024/FP21,29,85,149; independentR13 movedbefore7core, all2048outputs43008intermediatesPASS. Coreh8 CNFc838479...c76c2/84056clauses; corestarh12 ee54d0...24de/84044, both5045vars/freeoutput/nojunkunit; exact2CNFreconstruction7filereproduction. Controller {sha(HERE/"run_best4_core_pilot.py")} exact9configchanges,1workerdefault120s/150outer/1000MiB, SATvalidatorunchanged. No production/solver/lease/gitwrite byS02. Sub-agents:none.\n'
with (ROOT/'orch-notes.lock').open('a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    for path in [REPO/'results/orch/NOTES.md',REPO/'results/orch/lemmas/S02-sat-repairs.md']:
        with path.open('a') as out:out.write(entry);out.flush();os.fsync(out.fileno())
print(json.dumps({'wrapper_handoff':binding(HERE/'shuffle-wrapper-handoff.json'),
                  'core_handoff':binding(HERE/'best4-core-handoff.json'),
                  'wrapper_review_sha256':sha(D/'wrapper-review.json'),'core_review_sha256':sha(HERE/'best4-core-review.json')}))
