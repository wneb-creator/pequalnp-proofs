"""Prepare fresh minimal derivatives; never launch either controller."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S02'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def derive(parent,target,changes):
    old=parent.read_text();new=old
    for before,after in changes:
        assert new.count(before)==1
        new=new.replace(before,after)
    assert not target.exists()
    target.write_text(new)
    ast.parse(new)
    diff=target.with_suffix('.diff')
    diff.write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=parent.name,tofile=target.name)))
    report={'parent':str(parent),'parent_sha256':sha(parent),'source':str(target),'source_sha256':sha(target),
            'diff':str(diff),'diff_sha256':sha(diff),'changes':[{'before':a,'after':b} for a,b in changes]}
    target.with_suffix('.derivation.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


wrapper_parent=ROOT/'lean-setup/stochastic/stochastic_tools.py'
wrapper=HERE/'shuffle-engine-v1/stochastic_tools_shuffle.py'
report=derive(wrapper_parent,wrapper,[
    ("    record = {'scope': 'Candidate-only stochastic optimization; no exhaustion claim.',",
     "    if args.shuffle_restarts:\n        command.append('--shuffle-restarts')\n    record = {'scope': 'Candidate-only stochastic optimization; no exhaustion claim.',"),
    ("    worker.add_argument('--weight', type=int, default=4)",
     "    worker.add_argument('--weight', type=int, default=4)\n    worker.add_argument('--shuffle-restarts', action='store_true')")])
tree_old=ast.parse(wrapper_parent.read_text());tree_new=ast.parse(wrapper.read_text())
old_funcs={n.name:ast.dump(n) for n in tree_old.body if isinstance(n,ast.FunctionDef)}
new_funcs={n.name:ast.dump(n) for n in tree_new.body if isinstance(n,ast.FunctionDef)}
assert all(new_funcs[k]==v for k,v in old_funcs.items() if k!='run')
old_run=next(n for n in tree_old.body if isinstance(n,ast.FunctionDef) and n.name=='run')
new_run=next(n for n in tree_new.body if isinstance(n,ast.FunctionDef) and n.name=='run')
flag_nodes=[n for n in new_run.body if isinstance(n,ast.If) and ast.unparse(n.test)=='args.shuffle_restarts']
assert len(flag_nodes)==1
new_run.body.remove(flag_nodes[0]);assert ast.dump(old_run)==ast.dump(new_run)

controller_parent=ROOT/'run_best3_rescheduled_pilot.py'
assert sha(controller_parent)=='d53ddabc30e36fd2e210f886adf85be7bef82092c027a3097a73994c8950e4ec'
generator_sha=sha(HERE/'generate_best4_core_repairs.py')
controller=HERE/'run_best4_core_pilot.py'
controller_report=derive(controller_parent,controller,[
    ('Rescheduled best3 reserve repairs; never an exhaustion claim.','Remainder-first best4 core repairs; never an exhaustion claim.'),
    ("FAMILY=ROOT/'orch/S02/best3-rescheduled-family'","FAMILY=ROOT/'orch/S02/best4-core-family'"),
    ("OUT=ROOT/'best3-rescheduled-pilot'","OUT=ROOT/'best4-core-pilot'"),
    ('526d4ff2625b801ec283a144714484dbf70b541cee9644eac97d0b55182552c8',generator_sha),
    ("(OUT/'worker-limit.txt').write_text('2\\n')","(OUT/'worker-limit.txt').write_text('1\\n')"),
    ("r'(dirty-early-h14|reverse-ready-k06)'","r'(core-h08|core-star-h12)'"),
    ("'--time=180'","'--time=120'"),
    ('time.monotonic()-started>210','time.monotonic()-started>150'),
    ('Solver exceeded 210-second outer limit','Solver exceeded 150-second outer limit')])
functions=lambda p:{n.name:ast.dump(n) for n in ast.parse(p.read_text()).body if isinstance(n,ast.FunctionDef)}
assert functions(controller)==functions(controller_parent)
review={'verdict':'PASS_SELF_EXACT_NINE_CONFIG_CHANGES_NO_LAUNCH_MAIN_REVIEW_REQUIRED',
        **controller_report,'all_function_ASTs_unchanged':True,'default_workers':1,'allowed_workers':[1,2],
        'solver_limit_seconds':120,'outer_guard_seconds':150,'address_space_MiB':1000,
        'SAT_validator_and_lifecycle_unchanged':True,'solver_launched':False}
(HERE/'best4-core-controller-review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'wrapper':report,'controller_source_sha256':sha(controller),
                  'controller_review_sha256':sha(HERE/'best4-core-controller-review.json')}))
