"""Create a separate optional restart-shuffle patch; never modify the parent."""
from pathlib import Path
import difflib
import hashlib
import json

ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S02'
PARENT=ROOT/'orch/S05/direct21-v1/circuit_anneal_direct21.cpp'
PIN='e1a686c19d09439595cdfbf89baf42ff5d1dbfff8949e505b53b999d683ec077'
raw=PARENT.read_bytes();assert hashlib.sha256(raw).hexdigest()==PIN
out=HERE/'shuffle-engine-v1';out.mkdir(exist_ok=False)
text=raw.decode()
method=''' Circuit shuffle_topological(const Circuit& source,std::array<int,GATES>* map_out=nullptr) {
  if(source.output<0 || source.output>=OFFSET+GATES)
   throw std::runtime_error("Invalid shuffle output");
  for(int g=0;g<GATES;++g) {
   auto t=source.gates[g];
   if(t.op<0 || t.op>1 || t.a<0 || t.b<0 || t.a>=OFFSET+g || t.b>=OFFSET+g)
    throw std::runtime_error("Invalid shuffle gate");
  }
  Circuit result{};std::array<bool,GATES> emitted{};
  std::array<int,GATES> old_to_new{};old_to_new.fill(-1);
  for(int next=0;next<GATES;++next) {
   std::array<int,GATES> available{};int count=0;
   for(int old=0;old<GATES;++old) if(!emitted[old]) {
    auto t=source.gates[old];
    if((t.a<OFFSET || emitted[t.a-OFFSET]) &&
       (t.b<OFFSET || emitted[t.b-OFFSET])) available[count++]=old;
   }
   if(!count)throw std::runtime_error("No available shuffle gate");
   int old=available[pick(count)];auto t=source.gates[old];
   auto map=[&](int wire) {return wire<OFFSET?wire:OFFSET+old_to_new[wire-OFFSET];};
   t.a=map(t.a);t.b=map(t.b);
   if(t.a>t.b)std::swap(t.a,t.b);
   result.gates[next]=t;old_to_new[old]=next;emitted[old]=true;
  }
  result.output=source.output<OFFSET?source.output:OFFSET+old_to_new[source.output-OFFSET];
  if(map_out)*map_out=old_to_new;
  return result;
 }
'''
changes=[(' Circuit mutate(const Circuit& c) {',method+' Circuit mutate(const Circuit& c) {'),
         ('bool selftest=false;','bool selftest=false,shuffle_restarts=false;'),
         ('[--self-test]\\nPacks:','[--self-test] [--shuffle-restarts]\\nPacks:'),
         ('  if(arg=="--self-test") {selftest=true;continue;}','  if(arg=="--self-test") {selftest=true;continue;}\n  if(arg=="--shuffle-restarts") {shuffle_restarts=true;continue;}'),
         (' Circuit current=fresh();',' Circuit current=fresh();\n if(shuffle_restarts)current=engine.shuffle_topological(current);'),
         ('   if(engine.pick(4)==0) {current=best;for(int k=0;k<3;++k)current=engine.mutate(current);}\n   else current=fresh();',
          '   if(engine.pick(4)==0) {\n    current=best;\n    if(shuffle_restarts)current=engine.shuffle_topological(current);\n    for(int k=0;k<3;++k)current=engine.mutate(current);\n   } else {\n    current=fresh();\n    if(shuffle_restarts)current=engine.shuffle_topological(current);\n   }')]
modified=text
for before,after in changes:
    assert modified.count(before)==1,before
    modified=modified.replace(before,after)
(out/'parent-circuit_anneal_direct21.cpp').write_bytes(raw)
(out/'circuit_anneal_shuffle.cpp').write_text(modified)
(out/'engine.diff').write_text(''.join(difflib.unified_diff(text.splitlines(True),modified.splitlines(True),fromfile='circuit_anneal_direct21.cpp',tofile='circuit_anneal_shuffle.cpp')))
(out/'derivation.json').write_text(json.dumps({'parent_sha256':PIN,'source_sha256':hashlib.sha256(modified.encode()).hexdigest(),'changes':[{'before':a,'after':b} for a,b in changes],'scope':'Optional flag defaults false. Random Kahn scheduling retains every gate, including dead gates, before production-start/restart mutation. Parent source untouched.'},indent=2)+'\n')
assert PARENT.read_bytes()==raw
print(json.dumps({'source':str(out/'circuit_anneal_shuffle.cpp'),'sha256':hashlib.sha256(modified.encode()).hexdigest(),'parent_unchanged':True}))
