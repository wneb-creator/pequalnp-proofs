"""Verify and reconstruct two preserved best4 candidate CNFs; never solve."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def within(root,relative):
    relative=Path(relative)
    if relative.is_absolute() or '..' in relative.parts:raise ValueError('Unsafe relative path')
    path=root/relative
    if path.is_symlink() or not path.resolve().is_relative_to(root.resolve()):raise ValueError('Redirected path')
    return path


def main(output):
    package=Path(__file__).resolve().parent
    recipe=json.loads((package/'reconstruction.json').read_text())
    root=Path('/tmp/oec/pequalnp-pilot-18')
    if root.resolve()!=root:raise ValueError('Redirected scratch root')
    output=output.resolve()
    if output.exists() or not output.is_relative_to(root):raise ValueError('Fresh output in named scratch required')
    missing=[]
    for row in recipe['sources']:
        raw=within(package,row['package_path']).read_bytes()
        if sha(raw)!=row['sha256']:raise ValueError('Packaged source hash mismatch')
        destination=within(root,row['scratch_path'])
        if destination.exists():
            if not destination.is_file() or destination.read_bytes()!=raw:raise ValueError('Existing source differs; refusing overwrite')
        else:missing.append((destination,raw))
    for path,raw in missing:
        path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('xb') as stream:stream.write(raw)
    output.mkdir(parents=True,exist_ok=False)
    family=recipe['family'];destination=within(output,family['name'])
    command=[sys.executable,'-B',str(within(root,family['generator'])),str(destination)]
    with (output/'generator.stdout').open('x') as out,(output/'generator.stderr').open('x') as err:
        proc=subprocess.run(command,stdout=out,stderr=err,timeout=60)
    if proc.returncode:raise RuntimeError('Generator failed; full logs retained')
    expected=family['expected_files']
    if set(expected)!={p.name for p in destination.iterdir()}:raise ValueError('Generated file set mismatch')
    files=[]
    for name,wanted in expected.items():
        path=within(destination,name);actual=sha(path.read_bytes())
        if actual!=wanted:raise ValueError('Generated file hash mismatch')
        files.append({'path':str(path.relative_to(output)),'sha256':actual,'bytes':path.stat().st_size})
    report={'verdict':'PASS_TWO_CNF_SEVEN_FILE_BYTE_EXACT_RECONSTRUCTION','command':command,'exit_code':proc.returncode,
            'files':files,'CNFs':sum(p['path'].endswith('.cnf') for p in files),
            'solver_launched':False,'compiler_run':False,'network_used':False,'Lean_built':False,
            'scope':'Generator reconstruction only; no research or finite-control worker is executed.'}
    (output/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'verdict':report['verdict'],'CNFs':report['CNFs'],'files':len(files)}))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('output',type=Path)
    main(parser.parse_args().output)
