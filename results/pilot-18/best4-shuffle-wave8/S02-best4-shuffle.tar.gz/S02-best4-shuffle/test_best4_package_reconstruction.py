"""Two fail-closed preservation controls; no solver or production worker."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys

ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S02'
PACKAGE=HERE/'best4-shuffle-preservation-stage/S02-best4-shuffle'
OUT=HERE/'best4-shuffle-reconstruction-controls';OUT.mkdir(exist_ok=False)
commands=[]


def check(name,script,destination,error):
    argv=[sys.executable,'-B',str(script),str(destination)]
    with (OUT/(name+'.stdout')).open('x') as a,(OUT/(name+'.stderr')).open('x') as b:
        proc=subprocess.run(argv,stdout=a,stderr=b,timeout=15)
    assert proc.returncode==1 and error in (OUT/(name+'.stderr')).read_text()
    commands.append({'control':name,'command':argv,'exit_code':proc.returncode,'expected_rejection':error})


check('existing-output',PACKAGE/'reconstruct_best4_package.py',HERE/'best4-shuffle-package-reconstruction',
      'Fresh output in named scratch required')
bad=OUT/'bad-source-package';shutil.copytree(PACKAGE,bad)
recipe=json.loads((bad/'reconstruction.json').read_text());first=bad/recipe['sources'][0]['package_path']
first.write_bytes(first.read_bytes()+b'\n# Deliberate finite corruption control.\n')
destination=OUT/'must-not-be-created'
check('corrupt-source',bad/'reconstruct_best4_package.py',destination,'Packaged source hash mismatch')
assert not destination.exists()
report={'verdict':'PASS_TWO_RECONSTRUCTION_REJECTIONS','controls':commands,'solver_launched':False,
        'production_inputs_modified':False,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(OUT/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'verdict':report['verdict'],'controls':len(commands)}))
