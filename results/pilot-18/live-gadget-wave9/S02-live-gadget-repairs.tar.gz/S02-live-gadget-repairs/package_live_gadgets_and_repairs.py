"""Freeze source/controls and completed finite repairs; no active worker outputs."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile

ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S02'
STAGE=HERE/'live-gadget-repair-stage/S02-live-gadget-repairs';OUT=HERE/'live-gadget-repair-preservation-v1'
STAGE.mkdir(parents=True,exist_ok=False);OUT.mkdir(exist_ok=False)
sha=lambda raw:hashlib.sha256(raw).hexdigest();bindings=[];omitted=[]
def copy(source,relative):
    assert source.is_file() and not source.is_symlink();raw=source.read_bytes()
    if source.suffix=='.cnf':
        omitted.append({'source':str(source),'sha256':sha(raw),'bytes':len(raw),'reason':'reconstructed by verified recipe'});return
    text=raw.decode()
    assert not re.search(r'github_pat_[A-Za-z0-9_]{30,}|gh[pousr]_[A-Za-z0-9_]{20,}|[?&]lease=[A-Za-z0-9_-]{16,}|-----BEGIN [A-Z ]*PRIVATE KEY-----',text),'Sensitive indicator; no content printed'
    p=STAGE/relative;p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(raw)
    assert source.read_bytes()==raw
    bindings.append({'source':str(source),'archive':relative,'sha256':sha(raw),'bytes':len(raw)})
def tree(directory,prefix):
    for p in sorted(directory.rglob('*')):
        assert not p.is_symlink()
        if p.is_file():copy(p,prefix+'/'+str(p.relative_to(directory)))
sources=[]
for relative in ['orch/S02/build_live_gadgets.py','orch/S02/build_live_rootor_gadgets.py',
                 'orch/S05/build_gadget7.py','orch/S06/build_gadget8.py','orch/S05/validate_gadget7.py',
                 'orch/S06/validate_gadget8.py','validate_raw_candidate.py','lean-setup/validate_sat_candidate.py']:
    packaged='scratch/'+relative;copy(ROOT/relative,packaged)
    sources.append({'scratch':relative,'package':packaged,'sha256':sha((ROOT/relative).read_bytes())})
for name in ['gadget-live-v1','gadget-live-rootor-v1','gadget-live-controls-v2','gadget-live-rootor-controls','candidate134232-repair']:
    tree(HERE/name,'evidence/'+name)
for name in ['gadget-live-handoff.json','gadget-live-rootor-handoff.json','gadget-live-normalization.md',
             'audit_live_gadgets.py','audit_live_rootor_gadgets.py','repair_134232.py']:
    copy(HERE/name,'evidence/'+name)
for stem in ['gadget-live-help','gadget-live-generation','gadget-live-audit-v2','gadget-live-rootor-help',
             'gadget-live-rootor-generation','gadget-live-rootor-audit','repair134232','repair134232-raw-validation']:
    for suffix in ['.stdout','.stderr']:copy(HERE/(stem+suffix),'logs/'+stem+suffix)
copy(ROOT/'orch/MAIN/main-live-gadget-review.json','main-review/main-live-gadget-review.json')
review=ROOT/'orch/S06/gadget-live-review-v1';tree(review,'S06-independent-review')
handoff=json.loads((ROOT/'orch/S06/gadget-live-review-handoff.json').read_text())
for name,row in handoff['files'].items():
    raw=(ROOT/name).read_bytes();assert sha(raw)==row['sha256'] and len(raw)==row['bytes']
for name in ['gadget-live-review-handoff.json','gadget-live-review.execution.json','gadget-live-review.stdout','gadget-live-review.stderr',
             'review_live_gadgets.py','sat_only_gadget_kissat.py','offline_checked_cadical.py']:
    copy(ROOT/'orch/S06'/name,'S06-review-provenance/'+name)
expected={}
for name in ['gadget-live-v1','gadget-live-rootor-v1']:
    for p in sorted((HERE/name).iterdir()):expected[name+'/'+p.name]=sha(p.read_bytes())
for name in ['gadget-live-controls-v2','gadget-live-rootor-controls']:
    for p in sorted((HERE/name).iterdir()):
        if p.suffix=='.cnf' or p.with_suffix('.cnf').exists():expected[name+'/'+p.name]=sha(p.read_bytes())
assert len(expected)==18 and sum(x.endswith('.cnf') for x in expected)==8
(STAGE/'reconstruction.json').write_text(json.dumps({'sources':sources,'expected':expected},indent=2)+'\n')
copy(HERE/'restore_live_gadget_package.py','restore_live_gadget_package.py')
copy(HERE/'verify_best4_shuffle_package.py','verify_payloads.py')
copy(Path(__file__),'package_live_gadgets_and_repairs.py')
repair=json.loads((HERE/'candidate134232-repair/review.json').read_text())
rawcheck=json.loads((HERE/'candidate134232-repair/raw-validation.json').read_text())
assert not repair['candidate'] and all(r['status']=='COMPLETE' for r in repair['families'])
assert rawcheck['status']=='EXACT_BUT_TOO_LARGE' and rawcheck['size']==22 and not rawcheck['meets_posted_gate_limit']
(STAGE/'README.md').write_text('Final live/rootOR gadget preparation and finite134232 repairs\n\n'
    'The all-live generic7/11 and8/12 models append17/19clauses, no variables: every nonlastgate is usedlater and everyessentialinput occurs. Output-cone pruning thenOR-copy padding proves the representation restriction WLOG; fullmath/main/S06independentreviews are included. The separate rootORchildren append only-761/-903 and explicitly haveNOOR-rootWLOG/completenessclaim. Allparentsandearlierhandoffs stayfrozen.\n\n'
    'Allfourmodels are prepared searchinputs; this package includesNOproductionruntime or solververdict, even if mainlaunches them later. Positive SAT-assignment controls are local12/global22 andlocal13/global22; allfourstrengthenedfixturemodels pass everyclause and unchangedlocal/full2048validators, withfalsegate-limitflags. They are not21witnesses. FourhundredrandomDAGs/76800fullinputcomparisons verifyprune/pad semantics; exactclause-delta and byte-reproduction evidence retained.\n\n'
    'The distinct134232 source5acc0e...73a1 has20livegates, deadslot4, computesFminusONLYedge25, has24fullFN/zeroFP, andallliveANDsareclean. A complete restricted1/2fresh-operation selective-fanout scan made1055178fullbitsetcontextchecks andfound84exactfunctionrepairs, minimum22gates; a commonone-gatesignal at<=3arbitraryports made8113723checks andfoundnone. All12materializationcontrols independentlychecked2048inputs. The best22repair passes unchangedrawvalidator full2048 twice andreturnsEXACT_BUT_TOO_LARGE/exit2. This is not an arbitrary21gate impossibility statement. Fullsource/errors/normalization/helper/sourcepins/contextreports/stdoutstderr and22control are retained.\n\n'
    'Restore all8CNFs,8metadatafiles and2familyfiles byte-exact usingPython3stdlib: python3 restore_live_gadget_package.py /tmp/oec/pequalnp-pilot-18/fresh-live-restore . It preflights8sourcepins, refusesdifferingexistingfiles, writesonlyfreshscratch andstagesabsentpinnedsources undernamedroot. It regenerates bothgenericfamilies andfourpositivefixtures and replays4fullvalidators withoutsolvers. verify_payloads.py checksallarchivedhashes. No rawCNF/executablebinary/credential/leasevalue/activeoutput is included. Priorcontroltimestamps and PREPARED labels describe their creation. Mainalonehandlesfinalruntimepreservation; no exact21witness, acceptedcertificate/globalrefutation/Lean acceptance claimed.\n')
repro=HERE/'live-gadget-repair-reconstruction'
with (OUT/'reconstruction.stdout').open('x') as a,(OUT/'reconstruction.stderr').open('x') as b:
    proc=subprocess.run([sys.executable,'-B',str(STAGE/'restore_live_gadget_package.py'),str(repro)],stdout=a,stderr=b,timeout=60)
assert proc.returncode==0
result=json.loads((repro/'validation.json').read_text());assert result['CNFs']==8 and len(result['files'])==18
copy(repro/'validation.json','reconstruction-evidence/validation.json')
for path in sorted(OUT.iterdir()):copy(path,'reconstruction-evidence/'+path.name)
for row in bindings:assert sha(Path(row['source']).read_bytes())==row['sha256']
(STAGE/'copy-bindings.json').write_text(json.dumps({'files':bindings,'omitted_CNFs':omitted},indent=2)+'\n')
rows=[{'path':str(p.relative_to(STAGE)),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(STAGE.rglob('*')) if p.is_file()]
(STAGE/'MANIFEST.json').write_text(json.dumps({'files':rows,'scope':'Preparedlive/rootORmodels andcompletedfinite134232repairs only; no productionruntime.'},indent=2)+'\n')
with (OUT/'verification.stdout').open('x') as a,(OUT/'verification.stderr').open('x') as b:
    proc=subprocess.run([sys.executable,'-B',str(STAGE/'verify_payloads.py')],stdout=a,stderr=b,timeout=30)
assert proc.returncode==0
archive=OUT/'S02-live-gadget-repairs.tar.gz'
with archive.open('xb') as f:
    with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w',format=tarfile.USTAR_FORMAT) as tar:
            for p in sorted(STAGE.rglob('*')):
                if not p.is_file():continue
                raw=p.read_bytes();info=tarfile.TarInfo('S02-live-gadget-repairs/'+str(p.relative_to(STAGE)))
                info.size=len(raw);info.mode=0o644;info.uid=0;info.gid=0;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:gz') as tar:
    members=tar.getmembers();assert len(members)==len(rows)+1 and len({m.name for m in members})==len(members)
    for m in members:
        name=PurePosixPath(m.name);assert m.isfile() and not name.is_absolute() and '..' not in name.parts and name.parts[0]=='S02-live-gadget-repairs'
        assert tar.extractfile(m).read()==(STAGE/Path(*name.parts[1:])).read_bytes()
for name in ['README.md','MANIFEST.json']:(OUT/name).write_bytes((STAGE/name).read_bytes())
validation={'verdict':'PASS_SELF_PORTABLE_PREPARATION_AND_FINITE_REPAIR_PRESERVATION_MAIN_REVIEW_REQUIRED',
    'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'archive_regular_members':len(members),
    'manifest_sha256':sha((OUT/'MANIFEST.json').read_bytes()),'exact_source_copies':len(bindings),
    'S06_prior_bindings_verified':len(handoff['files']),'reconstructed_CNFs':8,'reconstructed_files':18,'positive_models_replayed':4,
    'finite_repair_context_checks':9168901,'finite_repair_smallest_exact_gates':22,'exact21_found':False,
    'raw_CNF_members':0,'binary_members':0,'active_outputs_read':False,'production_runtime_included':False,'solver_launched':False}
(OUT/'validation.json').write_text(json.dumps(validation,indent=2)+'\n');print(json.dumps(validation))
