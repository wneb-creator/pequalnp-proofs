"""One-unit delta and complete positive-assignment controls; no solver."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode=True
ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S02';OUT=HERE/'gadget-live-rootor-controls'
OUT.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
G=load(HERE/'build_live_rootor_gadgets.py','rootor_producer')
family=json.loads((HERE/'gadget-live-rootor-v1/family.json').read_text());checks=[];positive=[]
assert family['generator_sha256']==sha(HERE/'build_live_rootor_gadgets.py')
for row in family['cases']:
    n=row['inputs'];parent=HERE/'gadget-live-v1'/(G.PINS[n][0]+'.cnf');path=HERE/'gadget-live-rootor-v1'/(row['name']+'.cnf')
    meta=json.loads(path.with_suffix('.json').read_text());pm=json.loads(parent.with_suffix('.json').read_text())
    original=parent.read_bytes().splitlines(keepends=True);child=path.read_bytes().splitlines(keepends=True)
    unit=-pm['gate_records'][-1]['op']
    assert child[1:-1]==original[1:] and child[-1]==f'{unit} 0\n'.encode()
    assert child[0]==f'p cnf {pm["variables"]} {pm["clauses"]+1}\n'.encode()
    assert sha(path)==row['cnf_sha256']==meta['cnf_sha256'] and sha(path.with_suffix('.json'))==row['metadata_sha256']
    assert row['root_or_unit']==[unit] and meta['candidate_only'] and not meta['all_circuits_covered']
    # The appended literal is true exactly when op=false (OR), and false for AND.
    assert (False==(unit>0)) and not (True==(unit>0))
    checks.append({**row,'parent_body_byte_identical':True,'only_one_negative_last_op_unit':True})
    kp=row['gate_count']+1;pp=HERE/'gadget-live-controls-v2'/f'gadget{n}-positive{kp}-live.cnf'
    raw,metadata=G.child(pp.read_bytes(),pp.with_suffix('.json').read_bytes())
    cp=OUT/f'gadget{n}-positive{kp}-live-rootor.cnf';cp.write_bytes(raw)
    cp.with_suffix('.json').write_text(json.dumps(metadata,indent=2,sort_keys=True)+'\n')
    model=(HERE/'gadget-live-controls-v2'/f'gadget{n}-positive.model.stdout').read_bytes()
    (OUT/f'gadget{n}-positive.model.stdout').write_bytes(model)
    assignment={}
    for line in model.decode().splitlines():
        if line.startswith('v '):
            for lit in map(int,line.split()[1:]):
                if lit:assert abs(lit) not in assignment;assignment[abs(lit)]=lit>0
    clauses=[[int(x) for x in line.split()[:-1]] for line in raw.decode().splitlines()[1:]]
    assert set(assignment)==set(range(1,metadata['variables']+1))
    assert all(any(assignment[abs(x)]==(x>0) for x in c) for c in clauses)
    owner='S05' if n==7 else 'S06';vp=ROOT/'orch'/owner/f'validate_gadget{n}.py'
    pin='1eeceaaf05207387246634a12238389ba4059a5bf3cc43739edcf0173e8141bb' if n==7 else '60e877fd3bdb11d134633519482b67ca82478c55a00350e34a935ddd194054cb'
    assert sha(vp)==pin;v=load(vp,f'rootor_validator{n}')
    report=v.validate(raw,cp.with_suffix('.json').read_bytes(),model,sha(cp),sha(cp.with_suffix('.json')))
    assert report['status']=='VALIDATED_GADGET' and report['verified_inputs']==1<<n and report['full11_verified_inputs']==2048
    assert report['full11_gate_count']==22 and not report['meets_full21_gate_limit']
    (OUT/f'gadget{n}-positive.validation.json').write_text(json.dumps(report,indent=2)+'\n')
    positive.append({'inputs':n,'local_gates':kp,'global_gates':22,'clauses_checked':len(clauses),'all_clauses_satisfied':True,'validator_sha256':pin})
new=HERE/'gadget-live-rootor-reproduced';G.generate(new)
names=sorted(p.name for p in (HERE/'gadget-live-rootor-v1').iterdir())
assert all((HERE/'gadget-live-rootor-v1'/name).read_bytes()==(new/name).read_bytes() for name in names)
review={'verdict':'PASS_SELF_EXACT_ROOT_OR_UNIT_AND_FULL_POSITIVE_MODEL_MAIN_REVIEW_REQUIRED',
        'producer_sha256':sha(HERE/'build_live_rootor_gadgets.py'),'audit_sha256':sha(Path(__file__)),
        'cases':checks,'positive_controls':positive,'reproduced_files':len(names),
        'scope':'Candidate-only children, no OR-root WLOG/completeness/search-result claim. Positivecontrols are22wholegates, not21witnesses.',
        'solver_launched':False}
(OUT/'review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'verdict':review['verdict'],'producer_sha256':review['producer_sha256'],'review_sha256':sha(OUT/'review.json'),'cases':checks}))
