"""Bounded one/two-operation and shared-signal fanout repairs of a new20gate seed.

Full2048 bitsets decide every context test. Materialization counts all required
original cones, clones, freshgates and survivingoutput dependencies. This is a
restricted finite local search, not generic21 synthesis or a lower bound.
"""
from pathlib import Path
from itertools import combinations
import hashlib
import importlib.util
import json
import os
import random
import resource
import time

ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S02';OUT=HERE/'candidate134232-repair'
SOURCE=ROOT/'best4-candidate-134232/engine-result.json'
PIN='5acc0e0950f734cacb22039c5a7f19230404e4eb8c63784bfecbe93f5fb273a1'
HELPER=ROOT/'orch/S05/candidate134227_fanout.py'
HELPER_PIN='25c90fc1ba3edb4b36230deb5b558708feef3c91506e34bd9bc330284eba0acb'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
OUT.mkdir(exist_ok=False)
raw=SOURCE.read_bytes();assert sha(raw)==PIN
helper_raw=HELPER.read_bytes();assert sha(helper_raw)==HELPER_PIN
(OUT/'original-source.json').write_bytes(raw);(OUT/'frozen_fanout_helper.py').write_bytes(helper_raw)
spec=importlib.util.spec_from_file_location('frozen134232helper',OUT/'frozen_fanout_helper.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
original=json.loads(raw)
assert original['inputs']==11 and original['gate_wire_offset']==13 and len(original['gates'])==21
live={original['output']-13}
for g in reversed(range(21)):
    if g in live:live.update(w-13 for w in original['gates'][g][1:] if w>=13)
assert len(live)==20 and set(range(21))-live=={4}
mapping={i:i for i in range(11)};gates=[]
for g,(op,a,b) in enumerate(original['gates']):
    assert op in ('and','or') and type(a)is int and type(b)is int and 0<=a<=b<13+g
    if g in live:
        assert a not in (11,12) and b not in (11,12)
        mapping[13+g]=11+len(gates);gates.append([op,*sorted((mapping[a],mapping[b]))])
data={'inputs':11,'gate_wire_offset':11,'gates':gates,'size':20,'output':mapping[original['output']]}
(OUT/'normalized20.json').write_text(json.dumps(data,indent=2)+'\n')
fn=[];fp=[];junk=set();intermediate=0
for mask in range(2048):
    x=[bool(mask>>i&1) for i in range(11)];old=x+[False,True];new=x[:]
    for op,a,b in original['gates']:old.append(old[a] and old[b] if op=='and' else old[a] or old[b])
    for op,a,b in gates:new.append(new[a] and new[b] if op=='and' else new[a] or new[b])
    for g in live:assert old[13+g]==new[mapping[13+g]];intermediate+=1
    target=any(x[a] and x[b] for a,b in helper.EDGES)
    expected=any(x[a] and x[b] for a,b in helper.EDGES if (a,b)!=(2,5))
    assert old[original['output']]==new[data['output']]==expected
    if target and not expected:fn.append(mask)
    if expected and not target:fp.append(mask)
    if not target:junk.update(g for g,(op,_,_) in enumerate(gates) if op=='and' and new[11+g])
assert len(fn)==24 and not fp and not junk
v=helper.values(data)
uses=[[] for _ in v]
for g,(_,a,b) in enumerate(gates):uses[a].append((g,0));uses[b].append((g,1))
uses[data['output']].append((-1,0))
first=[(w,x) for w,x in enumerate(v)]
for a,b in combinations(range(len(v)),2):
    first.extend([(('and',a,b),v[a]&v[b]),(('or',a,b),v[a]|v[b])])
second=first[:]
for expr,x in first:
    if isinstance(expr,int):continue
    for w,y in enumerate(v):second.extend([(('and',expr,w),x&y),(('or',expr,w),x|y)])
controls=[];rng=random.Random(134232)
ports=[(i,j) for i in range(20) for j in (0,1)]+[(-1,0)]
for _ in range(12):
    selected=set(rng.sample(ports,3));expr,x=rng.choice(second)
    result=helper.materialize(data,selected,expr);expected=helper.context(data,selected,x)
    assert helper.values(result)[result['output']]==expected
    helper.scalar_check(result,expected)
    controls.append({'ports':sorted(selected),'expression':expr,'gates':result['size']})

resource.setrlimit(resource.RLIMIT_CPU,(20,20));resource.setrlimit(resource.RLIMIT_AS,(768*1024**2,768*1024**2));os.nice(10)
start=time.monotonic();reports=[];candidate=None;best=None;control_exact=None


def check_family(label,contexts,expressions):
    global candidate,best,control_exact
    began=time.monotonic();report={'family':label,'status':'COMPLETE','contexts':0,'eligible_contexts':0,'checks':0,'exact_function_matches':0,'smallest_exact':None}
    for selected in contexts:
        report['contexts']+=1
        low=helper.context(data,selected,0);high=helper.context(data,selected,helper.ONES)
        assert not low&~high
        if helper.TARGET&~high or low&~helper.TARGET:continue
        report['eligible_contexts']+=1;must1=helper.TARGET&~low;must0=high&~helper.TARGET
        for expr,value in expressions:
            report['checks']+=1
            if value&must1!=must1 or value&must0:continue
            report['exact_function_matches']+=1
            e=helper.materialize(data,selected,expr)
            assert helper.values(e)[e['output']]==helper.TARGET
            witness={'gates':e['size'],'ports':sorted(selected),'expression':expr,'family':label}
            if report['smallest_exact'] is None or e['size']<report['smallest_exact']['gates']:report['smallest_exact']=witness
            if best is None or e['size']<best['gates']:
                helper.scalar_check(e);best=witness;control_exact=e
                e.update(repair=witness,source_sha256=PIN,all2048_scalar_checked=True,requires_Lean_proof=True)
                (OUT/'smallest-exact-control.json').write_text(json.dumps(e,indent=2)+'\n')
            if e['size']<=21:
                helper.scalar_check(e);p=OUT/'exact21-candidate.json';p.write_text(json.dumps(e,indent=2)+'\n')
                candidate={'path':str(p),'sha256':sha(p.read_bytes()),'gates':e['size']};report['status']='EXACT_CANDIDATE_REQUIRES_INDEPENDENT_VALIDATOR_AND_LEAN';break
        if candidate:break
        if time.monotonic()-began>5:report['status']='TIME_LIMIT_PARTIAL';break
    report['elapsed_seconds']=time.monotonic()-began;reports.append(report)
    print(json.dumps(report),flush=True)


same_wire=[]
for wire in range(len(v)):
    for subset in range(1,1<<len(uses[wire])):
        selected={uses[wire][i] for i in range(len(uses[wire])) if subset>>i&1}
        assert helper.context(data,selected,v[wire])==v[data['output']]
        same_wire.append(selected)
check_family('one_or_two_fresh_operations_selective_uses_of_one_original_wire',same_wire,second)
if not candidate:
    arbitrary=(set(selected) for count in [1,2,3] for selected in combinations(ports,count))
    check_family('one_common_signal_at_up_to_three_arbitrary_ports',arbitrary,first)
report={'source_sha256':PIN,'script_sha256':sha(Path(__file__).read_bytes()),'helper_sha256':HELPER_PIN,
        'source_full_FN':fn,'source_full_FP':fp,'missing_edge':[2,5],'dead_original_gate':4,
        'normalized_gates':20,'normalized_sha256':sha((OUT/'normalized20.json').read_bytes()),
        'normalization_intermediate_comparisons':intermediate,'all_live_ANDs_clean':True,
        'control_materializations':controls,'control_scalar_inputs':12*2048,
        'families':reports,'candidate':candidate,'smallest_exact':best,'elapsed_seconds':time.monotonic()-start,
        'scope':__doc__,'solver_launched':False,'global_completeness_claim':False}
(OUT/'review.json').write_text(json.dumps(report,indent=2)+'\n')
assert SOURCE.read_bytes()==raw and HELPER.read_bytes()==helper_raw
print(json.dumps({'candidate':candidate,'smallest_exact':best,'statuses':[r['status'] for r in reports],
                  'review_sha256':sha((OUT/'review.json').read_bytes())}),flush=True)
