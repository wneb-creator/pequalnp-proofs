"""Verify every archived payload hash; execute no preserved source."""
from pathlib import Path
import hashlib
import json

root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
expected={entry['path']:entry for entry in manifest['files']}
if len(expected)!=len(manifest['files']):raise ValueError('Duplicate manifest paths')
found=set()
for path in root.rglob('*'):
    if path.is_symlink():raise ValueError('Symlink not allowed')
    if not path.is_file():continue
    name=str(path.relative_to(root))
    if name=='MANIFEST.json':continue
    if name not in expected:raise ValueError('Unlisted payload')
    raw=path.read_bytes();entry=expected[name]
    if len(raw)!=entry['bytes'] or hashlib.sha256(raw).hexdigest()!=entry['sha256']:
        raise ValueError('Payload hash mismatch')
    found.add(name)
if found!=set(expected):raise ValueError('Missing payload')
print(json.dumps({'verdict':'PASS_ALL_PAYLOAD_HASHES','files':len(found),'preserved_code_executed':False}))
