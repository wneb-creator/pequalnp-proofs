"""Candidate-only OR-root children of the frozen all-live gadget7/8 CNFs.

No WLOG claim is made for the output operator. Each child adds one negative op
unit and no variables. Existing live sources, CNFs and metadata stay unchanged.
"""
from pathlib import Path
import argparse
import hashlib
import json

ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S02'
PINS={7:('gadget7-generic11-live','80bb5ead5500d40b876c8a205ea9e37e885187467ec63d57c624ba3758ccaf5e','b0fdd37ef162b2a8bd7edd88866d5051250bbd79655bbb3ed417c96f46870c8b'),
      8:('gadget8-generic12-live','41d9653eb06d023d91e332beb083fc76d66433c297fee8c9c4aebe6a9c09ef30','c91c7e045e51024d69a2bd1e846de5bd54f897fd25e689871cb56f307eb9044f')}
sha=lambda raw:hashlib.sha256(raw).hexdigest()


def child(raw,metadata_raw):
    meta=json.loads(metadata_raw);lines=raw.splitlines(keepends=True)
    assert raw.endswith(b'\n') and meta['cnf_sha256']==sha(raw)
    header=lines[0].decode().split();assert header[:2]==['p','cnf']
    variables,count=map(int,header[2:]);assert variables==meta['variables'] and count==meta['clauses']==len(lines)-1
    op=meta['gate_records'][-1]['op'];assert type(op)is int and 1<=op<=variables
    unit=[-op];new=(f'p cnf {variables} {count+1}\n'.encode()+b''.join(lines[1:])+f'{-op} 0\n'.encode())
    meta.update(clauses=count+1,cnf_sha256=sha(new),live_parent_cnf_sha256=sha(raw),
                live_parent_metadata_sha256=sha(metadata_raw),live_parent_clause_count=count,
                root_or_unit=unit,root_operator='or',root_or_candidate_only=True,candidate_only=True,
                all_circuits_covered=False,root_or_postprocessor_sha256=sha(Path(__file__).read_bytes()),
                scope='Candidate-only OR-root restriction of the all-live exact-target gadget. AND-root possibilities are excluded; no completeness or lower-bound claim.',
                completeness='No completeness claim for the OR-root restriction. All-live padding is justified separately; it does not establish OR-root WLOG at the same size.')
    if 'pinned_circuit' in meta:meta['scope']='Fully pinned positive OR-root SAT-assignment fixture; not generic synthesis or a21gate witness.'
    return new,meta


def generate(output):
    if output.exists():raise ValueError('Fresh output required')
    output.mkdir(parents=True,exist_ok=False);cases=[]
    for n,(parent,cp,mp) in PINS.items():
        p=HERE/'gadget-live-v1'/(parent+'.cnf');raw=p.read_bytes();metadata=p.with_suffix('.json').read_bytes()
        if sha(raw)!=cp or sha(metadata)!=mp:raise ValueError('Frozen live parent hash mismatch')
        new,meta=child(raw,metadata);name=parent+'-rootor'
        path=output/(name+'.cnf');path.write_bytes(new)
        path.with_suffix('.json').write_text(json.dumps(meta,indent=2,sort_keys=True)+'\n')
        cases.append({'name':name,'inputs':n,'gate_count':meta['gate_count'],'variables':meta['variables'],
                      'clauses':meta['clauses'],'added_clauses':1,'added_variables':0,'root_or_unit':meta['root_or_unit'],
                      'parent_cnf_sha256':cp,'parent_metadata_sha256':mp,'cnf_sha256':sha(new),
                      'metadata_sha256':sha(path.with_suffix('.json').read_bytes()),'candidate_only':True})
        assert p.read_bytes()==raw and p.with_suffix('.json').read_bytes()==metadata
    result={'status':'PREPARED_CANDIDATE_ONLY_NO_SOLVER','generator_sha256':sha(Path(__file__).read_bytes()),
            'cases':cases,'completeness_claim':False,'solver_launched':False}
    (output/'family.json').write_text(json.dumps(result,indent=2)+'\n');return result


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('output',type=Path)
    print(json.dumps(generate(p.parse_args().output)))
