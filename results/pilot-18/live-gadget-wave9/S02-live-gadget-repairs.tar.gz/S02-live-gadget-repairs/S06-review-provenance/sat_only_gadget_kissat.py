#!/usr/bin/env python3
"""Bounded gadget7/gadget8 witness search. No proof output; UNSAT is UNKNOWN.

Exit10 only after pinned full gadget/full2048 validator acceptance; else exit2.
Reuse the hash-pinned reviewed lifecycle, with one child at a time and no checker.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import signal
import sys

sys.dont_write_bytecode=True
ROOT=Path('/tmp/oec/pequalnp-pilot-18')
OWN=ROOT/'orch/S06'
LIFECYCLE=OWN/'offline_checked_cadical.py'
LIFECYCLE_SHA='aa5d13bb83ab79e47b9794809c3c06dc153544975cd1131afbdeaef7c18d484a'
SOLVER=(ROOT/'solver/kissat-4.0.4-linux-amd64','21da5d984e38b74f620f14c62442f834f27b9158decdb722540d97f98aac93a1')
CONFIG={
  8:{'validator':(OWN/'validate_gadget8.py','60e877fd3bdb11d134633519482b67ca82478c55a00350e34a935ddd194054cb'),'rows':256,'gates':12,'limit':'meets_gadget_12_gate_limit','format':'s06-gadget8-v1'},
  7:{'validator':(ROOT/'orch/S05/validate_gadget7.py','1eeceaaf05207387246634a12238389ba4059a5bf3cc43739edcf0173e8141bb'),'rows':128,'gates':11,'limit':'meets_gadget_11_gate_limit','format':'s05-gadget7-v1'},
}

def require(ok,msg):
    if not ok:raise ValueError(msg)
require(LIFECYCLE.is_file() and not LIFECYCLE.is_symlink() and hashlib.sha256(LIFECYCLE.read_bytes()).hexdigest()==LIFECYCLE_SHA,'lifecycle source SHA256 mismatch')
spec=importlib.util.spec_from_file_location('pinned_gadget_lifecycle',LIFECYCLE)
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)

def accept_report(report,args,config):
    require(report.get('status')=='VALIDATED_GADGET' and type(report.get('verified_inputs')) is int and report['verified_inputs']==config['rows'] and type(report.get('full11_verified_inputs')) is int and report['full11_verified_inputs']==2048,'incomplete truth validation')
    require(report.get(config['limit']) is True and report.get('meets_full21_gate_limit') is True,'gadget or full21 gate limit exceeded')
    require(type(report.get('gate_count')) is int and 1<=report['gate_count']<=config['gates'] and type(report.get('full11_gate_count')) is int and report['full11_gate_count']==report['gate_count']+(9 if args.gadget==8 else 10) and report['full11_gate_count']<=21,'inconsistent validated gate counts')
    require(report.get('provenance')=={'cnf_sha256':args.cnf_sha256,'metadata_sha256':args.metadata_sha256,'solver_stdout_sha256':base.digest(args.output/'solver.stdout'),'validator_sha256':config['validator'][1]},'validation provenance mismatch')

def run(args):
    args.output.mkdir(mode=0o700)
    config=CONFIG[args.gadget];stop=[None];handlers={}
    def handler(sig,_frame):stop[0]='signal_'+signal.Signals(sig).name
    for sig in [signal.SIGTERM,signal.SIGINT]:handlers[sig]=signal.signal(sig,handler)
    state={'started_utc':base.utc(),'state':'PREPARING','status':'UNKNOWN','exit_code':2,'validated_SAT':False,'accepted_CNF_UNSAT':False,'SAT_indication':False,'proof_generation':False,'gadget':args.gadget,'source_sha256':base.digest(Path(__file__)),'cnf_sha256':args.cnf_sha256,'metadata_sha256':args.metadata_sha256,'pins':{k:{'path':str(v[0]),'sha256':v[1]} for k,v in args.pins.items()},'phases':{},'limits':{'solver_wall_seconds':args.solver_seconds,'validator_wall_seconds':30,'address_space_mib':1536,'log_bytes_per_file':args.proof_bytes,'min_free_bytes':args.min_free_bytes,'active_children_at_most':1},'scope':'Witness search only. No proof generation/checker. Solver UNSAT remains UNCERTIFIED/UNKNOWN and never establishes exhaustion. SAT requires pinned full gadget/full2048 validator and both gate limits. Lean acceptance remains separate.'}
    def persist():base.atomic_json(args.output/'progress.json',state)
    snapshot=args.output/'instance.cnf';metadata=snapshot.with_suffix('.json');code=2
    try:
        persist();base.verify_bindings(args)
        require(not stop[0] and not args.abort_file.exists(),'external_abort_file')
        require(shutil.disk_usage(args.output).free>=args.min_free_bytes+2*args.proof_bytes,'insufficient_disk_headroom')
        require(json.loads(args.cnf.with_suffix('.json').read_text()).get('format')==config['format'],'gadget metadata format mismatch')
        shutil.copyfile(args.cnf,snapshot);shutil.copyfile(args.cnf.with_suffix('.json'),metadata)
        snapshot.chmod(0o400);metadata.chmod(0o400)
        require(base.digest(snapshot)==args.cnf_sha256 and base.digest(metadata)==args.metadata_sha256,'snapshot copy mismatch')
        # Exactly one positional input, and no proof-path argument.
        command=[str(args.pins['solver'][0]),'--sat','--no-color','--statistics',str(snapshot)]
        solver=base.phase(args,'solver',command,args.solver_seconds,1536,stop,state,persist)
        state['solver_verdicts']=base.verdicts(args.output/'solver.stdout')
        state['SAT_indication']='s SATISFIABLE' in state['solver_verdicts']
        base.verify_bindings(args)
        require(base.digest(snapshot)==args.cnf_sha256 and base.digest(metadata)==args.metadata_sha256,'snapshot changed')
        require(not stop[0] and not args.abort_file.exists(),'abort after solver')
        require(solver['reason'] is None,'solver '+str(solver['reason']))
        if solver['exit_code']==10 and state['solver_verdicts']==['s SATISFIABLE']:
            report_path=args.output/'gadget.validated.json'
            command=[sys.executable,'-B',str(config['validator'][0]),str(snapshot),str(args.output/'solver.stdout'),str(report_path),'--cnf-sha256',args.cnf_sha256,'--metadata-sha256',args.metadata_sha256]
            check=base.phase(args,'validator',command,30,1536,stop,state,persist)
            require(check['reason'] is None and check['exit_code']==0,'SAT validator failed or timed out')
            report=json.loads(report_path.read_text());state['validation_report']=report
            accept_report(report,args,config)
            base.verify_bindings(args)
            require(base.digest(snapshot)==args.cnf_sha256 and base.digest(metadata)==args.metadata_sha256,'snapshot changed during validation')
            require(not stop[0] and not args.abort_file.exists(),'abort after validator')
            state.update(status='VALIDATED_SAT',validated_SAT=True,reason=None);code=10
        elif solver['exit_code']==20 and state['solver_verdicts']==['s UNSATISFIABLE']:
            state.update(reason='UNCERTIFIED_UNSAT_NO_PROOF',uncertified_UNSAT=True)
        else:state['reason']='solver_unknown_or_exit_verdict_mismatch'
    except Exception as error:
        state.update(status='UNKNOWN',validated_SAT=False,reason=type(error).__name__+': '+str(error));code=2
    finally:
        state['logs']={p.name:{'bytes':p.stat().st_size,'sha256':base.digest(p)} for p in args.output.iterdir() if p.is_file() and p.suffix in ['.stdout','.stderr']}
        state.update(state='FINISHED',finished_utc=base.utc(),exit_code=code,accepted_CNF_UNSAT=False)
        persist();base.atomic_json(args.output/'result.json',state)
        for sig,prior in handlers.items():signal.signal(sig,prior)
    return code

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('cnf',type=Path);p.add_argument('output',type=Path)
    p.add_argument('--gadget',type=int,choices=[7,8],required=True)
    p.add_argument('--cnf-sha256',required=True);p.add_argument('--metadata-sha256',required=True)
    p.add_argument('--solver-seconds',type=float,default=600)
    p.add_argument('--abort-file',type=Path,default=ROOT/'DESK_ERROR.response')
    p.add_argument('--preflight-only',action='store_true');a=p.parse_args()
    for name in ['cnf_sha256','metadata_sha256']:
        value=getattr(a,name);require(len(value)==64 and all(c in '0123456789abcdef' for c in value),'invalid SHA256')
    require(1<=a.solver_seconds<=600,'solver wall limit must be1..600seconds')
    a.cnf=a.cnf.resolve(strict=True);a.output=a.output.absolute();a.abort_file=a.abort_file.absolute()
    require(a.cnf.is_relative_to(ROOT) or a.cnf.is_relative_to(Path('/workspace/pequalnp-proofs')),'input outside workspace')
    require(any(a.output.parent.resolve().is_relative_to(x.resolve()) for x in [OWN,ROOT/'orch/S05']),'output outside S06/S05 scratch')
    require(not a.output.exists() and not a.output.is_symlink(),'fresh output required')
    # The reused phase calls this proof_bytes; here it caps only each log file.
    a.proof_bytes=64*1024**2;a.min_free_bytes=256*1024**2
    a.pins={'solver':SOLVER,'validator':CONFIG[a.gadget]['validator'],'lifecycle':(LIFECYCLE,LIFECYCLE_SHA),'runner':(Path(__file__).resolve(),base.digest(Path(__file__)))}
    if a.preflight_only:
        base.verify_bindings(a);print(json.dumps({'status':'PREFLIGHT_PASS','source_sha256':a.pins['runner'][1],'solver_launched':False}));return 0
    code=run(a);print(json.dumps({'exit_code':code,'result':str(a.output/'result.json')}));return code

if __name__=='__main__':sys.exit(main())
