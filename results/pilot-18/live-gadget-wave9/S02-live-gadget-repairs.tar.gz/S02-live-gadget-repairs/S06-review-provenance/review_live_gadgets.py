#!/usr/bin/env python3
"""Independent live-CNF delta/normalization/model audit. No SAT solver."""
import copy
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import random
import shutil
import subprocess
import sys
import time
from types import SimpleNamespace

sys.dont_write_bytecode=True
ROOT=Path('/tmp/oec/pequalnp-pilot-18');OWN=ROOT/'orch/S06';PEER=ROOT/'orch/S02';OUT=OWN/'gadget-live-review-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):return {'bytes':p.stat().st_size,'sha256':sha(p)}
def save(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def need(ok,msg):
    if not ok:raise AssertionError(msg)
def load(path,name):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def eval_all(gates,n):
    result=[]
    for mask in range(1<<n):
        values=[bool(mask>>i&1) for i in range(n)]+[False,True]
        for op,a,b in gates:values.append((values[a] and values[b]) if op=='and' else (values[a] or values[b]))
        result.append(values)
    return result
def cone(gates,n,output):
    live=set();todo=[output]
    while todo:
        w=todo.pop()
        if w<n+2 or w in live:continue
        live.add(w);todo.extend(gates[w-n-2][1:])
    return live
def trim_and_pad(gates,n,k,output):
    live=cone(gates,n,output);wires={i:i for i in range(n+2)};new=[]
    for i,(op,a,b) in enumerate(gates):
        if n+2+i in live:
            wires[n+2+i]=n+2+len(new);new.append((op,*sorted([wires[a],wires[b]])))
    current=wires[output]
    while len(new)<k:new.append(('or',current,current));current=n+2+len(new)-1
    return new
def check_normalization(gates,n,output):
    fixed=trim_and_pad(gates,n,len(gates),output)
    before=eval_all(gates,n);after=eval_all(fixed,n)
    need(all(a[output]==b[-1] for a,b in zip(before,after)),'normalization truth')
    need(len(cone(fixed,n,n+1+len(fixed)))==len(fixed),'normalized gates live')
    used={w for _,a,b in fixed for w in [a,b] if w<n}
    for v in range(n):
        essential=any(before[m][output]!=before[m|(1<<v)][output] for m in range(1<<n) if not (m>>v&1))
        need(not essential or v in used,'essential input lost')
    return 1<<n

def main():
    start=time.monotonic();OUT.mkdir();snap=OUT/'source-snapshot';snap.mkdir()
    handoff=PEER/'gadget-live-handoff.json';need(sha(handoff)=='9e05f71294110c1c779f1906e7fc87dcb22375843714be274522d37422354397','handoff pin')
    h=json.loads(handoff.read_text());bindings={}
    for entry in h['artifacts']:
        p=Path(entry['path']);need(info(p)=={k:entry[k] for k in ['bytes','sha256']},'S02 artifact pin')
        bindings[str(p)]=info(p);target=snap/p.relative_to(PEER);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
    shutil.copyfile(handoff,snap/handoff.name)
    runner=OWN/'sat_only_gadget_kissat.py';need(sha(runner)=='fd05c03210c7d815ec81f0f3a292ef5d7eeb92f4380c8f4c5fde18d10aaa6bcd','runner pin')
    runtime=load(runner,'live_review_runner');cases=[];positives=[];essential_witnesses=[]
    added_keys={'parent_cnf_sha256','parent_clauses','postprocessor_sha256','all_gate_liveness','all_essential_inputs_used','liveness_clauses','input_usage_clauses','normalization'}
    for row in h['cases']:
        n=row['inputs'];k=row['gates'];owner=ROOT/f'orch/S0{5 if n==7 else 6}'
        parent=owner/f'gadget{n}-v1'/f'generic{k}.cnf';child=PEER/'gadget-live-v1'/(row['name']+'.cnf')
        pm=json.loads(parent.with_suffix('.json').read_text());cm=json.loads(child.with_suffix('.json').read_text())
        need(sha(parent)==row['parent_sha256'] and sha(child)==row['cnf_sha256'] and sha(child.with_suffix('.json'))==row['metadata_sha256'],'case pins')
        need(set(cm)==set(pm)|added_keys,'metadata added key set')
        for key,value in pm.items():
            if key not in ['clauses','cnf_sha256','scope']:need(cm[key]==value,'unchanged metadata '+key)
        manual=[]
        for wire in range(n+2,n+2+k-1):
            clause=[]
            for index,record in enumerate(pm['gate_records']):
                if n+2+index>wire:clause += [record['left'][wire],record['right'][wire]]
            manual.append(clause)
        for wire in range(n):manual.append([literal for record in pm['gate_records'] for literal in [record['left'][wire],record['right'][wire]]])
        parent_lines=parent.read_bytes().splitlines(True)
        expected=(f"p cnf {pm['variables']} {pm['clauses']+len(manual)}\n".encode()+b''.join(parent_lines[1:])+''.join(' '.join(map(str,c))+' 0\n' for c in manual).encode())
        need(child.read_bytes()==expected,'exact unchanged parent body plus delta')
        need(cm['liveness_clauses']==manual[:k-1] and cm['input_usage_clauses']==manual[k-1:],'metadata clauses')
        need(cm['postprocessor_sha256']==h['producer_sha256'] and cm['parent_cnf_sha256']==sha(parent) and cm['parent_clauses']==pm['clauses'],'parent metadata binding')
        need(cm['variables']==pm['variables'] and cm['clauses']==pm['clauses']+len(manual) and cm['all_gate_liveness'] is True and cm['all_essential_inputs_used'] is True,'counts and flags')
        need(len(manual)==k-1+n==row['added_clauses'] and all(c and all(0<x<=pm['variables'] for x in c) for c in manual),'positive selector-only delta')
        edges=pm['local_edges']
        target=lambda mask:any(mask>>a&1 and mask>>b&1 for a,b in edges)
        for v in range(n):
            neighbor=next(b if a==v else a for a,b in edges if v in [a,b]);low=1<<neighbor;high=low|(1<<v)
            need(not target(low) and target(high),'incident edge essential witness');essential_witnesses.append({'gadget':n,'input':v,'negative':low,'positive':high})
        command=[sys.executable,'-B',str(runner),str(child),str(OUT/f'never-launched-{n}'),'--gadget',str(n),'--cnf-sha256',sha(child),'--metadata-sha256',sha(child.with_suffix('.json')),'--preflight-only']
        with (OUT/f'preflight-{n}.stdout').open('xb') as stdout,(OUT/f'preflight-{n}.stderr').open('xb') as stderr:
            result=subprocess.run(command,cwd=OWN,stdout=stdout,stderr=stderr,timeout=5)
        need(result.returncode==0 and not (OUT/f'never-launched-{n}').exists(),'runner preflight no launch')
        save(OUT/f'preflight-{n}.execution.json',{'command':command,'exit_code':result.returncode,'timeout_seconds':5,'solver_launched':False})
        cases.append({**row,'exact_delta_and_metadata':'PASS','runner_preflight':'PASS','parent_metadata_sha256':sha(parent.with_suffix('.json'))})
        fixture=PEER/'gadget-live-controls-v2'/f'gadget{n}-positive{k+1}-live.cnf';model=PEER/'gadget-live-controls-v2'/f'gadget{n}-positive.model.stdout'
        vp=owner/f'validate_gadget{n}.py';need(sha(vp)==runtime.CONFIG[n]['validator'][1],'validator pin')
        validator=load(vp,f'live_review_validator{n}')
        report=validator.validate(fixture.read_bytes(),fixture.with_suffix('.json').read_bytes(),model.read_bytes(),sha(fixture),sha(fixture.with_suffix('.json')))
        need(report==json.loads((PEER/'gadget-live-controls-v2'/f'gadget{n}-positive.validation.json').read_text()),'positive complete report replay')
        need(report['verified_inputs']==1<<n and report['full11_verified_inputs']==2048 and report['full11_gate_count']==22 and report['meets_full21_gate_limit'] is False,'positive overlimit scope')
        folder=OUT/f'positive-model-{n}';folder.mkdir();shutil.copyfile(model,folder/'solver.stdout');save(folder/'validation.json',report)
        args=SimpleNamespace(gadget=n,cnf_sha256=sha(fixture),metadata_sha256=sha(fixture.with_suffix('.json')),output=folder)
        try:runtime.accept_report(report,args,runtime.CONFIG[n])
        except ValueError as error:need(str(error)=='gadget or full21 gate limit exceeded','exact runner overlimit rejection')
        else:raise AssertionError('positive22 accepted')
        positives.append({'gadget':n,'clauses_checked':report['cnf_clauses_checked'],'gadget_inputs':1<<n,'full_inputs':2048,'full_gate_count':22,'runner_acceptance':'REJECTED_OVERLIMIT','validator_sha256':sha(vp)})
    # Exhaust all one-input three-gate DAGs, including constants, both ops,
    # repeated ports, every possible output; then larger independent randoms.
    options=[[ (op,a,b) for op in ['and','or'] for a,b in itertools.combinations_with_replacement(range(3+g),2)] for g in range(3)]
    exhaustive=0;truth=0
    for gates in itertools.product(*options):
        for output in range(6):truth+=check_normalization(gates,1,output);exhaustive+=1
    rng=random.Random(18480506);random_cases=0
    for n,k in [(7,11),(8,12)]:
        for trial in range(64):
            gates=[]
            for g in range(k):gates.append((rng.choice(['and','or']),*sorted([rng.randrange(n+2+g),rng.randrange(n+2+g)])))
            truth+=check_normalization(gates,n,rng.randrange(n+2+k));random_cases+=1
    report={'status':'PASS_INDEPENDENT_LIVE_DELTA_NORMALIZATION_AND_FROZEN_RUNNER_COMPATIBILITY','handoff_sha256':sha(handoff),'producer_sha256':h['producer_sha256'],'review_source_sha256':sha(Path(__file__)),'artifact_bindings':bindings,'cases':cases,'essential_input_witnesses':essential_witnesses,'positive_model_replays':positives,'exhaustive_one_input_DAG_output_cases':exhaustive,'random_large_DAG_output_cases':random_cases,'full_truth_comparisons':truth,'normalization_math':'Retain output ancestors, preserving topological order; append repeated-operand OR copies to k. Every retained nonoutput gate has later use; copies connect former output to last. Strictly increasing uses imply all gates reach last. Essential inputs must occur on some retained operand, witnessed by incident edges. Constants/repeated operands remain allowed. Equivalence is existence after normalization, not entailment by the old CNF.','solver_launched':False,'scope':'Only the two generic gadget construction spaces. SAT-only UNSAT remains UNKNOWN; no global/shard/Lean conclusion.','elapsed_seconds':time.monotonic()-start}
    save(OUT/'review.json',report);print(json.dumps({k:report[k] for k in ['status','handoff_sha256','producer_sha256','exhaustive_one_input_DAG_output_cases','random_large_DAG_output_cases','full_truth_comparisons','elapsed_seconds']}))

if __name__=='__main__':main()
