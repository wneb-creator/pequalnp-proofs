"""Fresh generic7/8 CNFs with WLOG all-gate liveness and essential-input usage.

No solver is launched. Existing source, CNF, metadata and worker files are read
only. Constants, repeated operands and arbitrary AND/OR functions remain allowed.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode=True
ROOT=Path('/tmp/oec/pequalnp-pilot-18')
CONFIG={7:('S05','6bc53c66e01a9f7a3fbcede34ddba0893209636be60d4a1ea18505970b5b1c16',11),
        8:('S06','3ca5274e1a394aff25e8f633bfc07ca5dd9ed2163b43db321dfba218e6b1ac17',12)}
sha=lambda raw:hashlib.sha256(raw).hexdigest()


def load(n):
    owner,pin,k=CONFIG[n];path=ROOT/'orch'/owner/f'build_gadget{n}.py'
    if sha(path.read_bytes())!=pin:raise ValueError('Reviewed generator hash mismatch')
    spec=importlib.util.spec_from_file_location(f'live_parent_{n}',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def extra_clauses(meta):
    n=len(meta['vertices']);k=meta['gate_count'];offset=meta['wire_offset'];records=meta['gate_records']
    gates=[];inputs=[]
    for g in range(k-1):
        wire=offset+g
        gates.append([records[h][side][wire] for h in range(g+1,k) for side in ['left','right']])
    for v in range(n):inputs.append([records[g][side][v] for g in range(k) for side in ['left','right']])
    assert len(gates)==k-1 and len(inputs)==n and all(gates+inputs)
    return gates,inputs


def strengthen(cnf,meta):
    original=cnf.raw();parent_clauses=len(cnf.clauses);gate_clauses,input_clauses=extra_clauses(meta)
    cnf.clauses.extend(gate_clauses+input_clauses)
    meta.update(clauses=len(cnf.clauses),cnf_sha256=sha(cnf.raw()),
                parent_cnf_sha256=sha(original),parent_clauses=parent_clauses,
                postprocessor_sha256=sha(Path(__file__).read_bytes()),
                all_gate_liveness=True,all_essential_inputs_used=True,
                liveness_clauses=gate_clauses,input_usage_clauses=input_clauses,
                normalization='Prune non-output ancestors, then pad with OR copies of the current output. All gates then reach the last output. Each essential input occurs in a gate operand.',
                scope='Generic at-most-k gadget synthesis after output-cone pruning and OR-copy padding; no operator, first-junk, cleanliness, fanin-distinctness or distance restriction.')
    return cnf,meta


def generate(output):
    if output.exists():raise ValueError('Fresh output required')
    output.mkdir(parents=True,exist_ok=False);family=[]
    for n,(_,pin,k) in CONFIG.items():
        parent=load(n);cnf,meta=parent.build(k);before=cnf.raw()
        cnf,meta=strengthen(cnf,meta);assert cnf.variables==meta['variables']
        assert len(cnf.clauses)-meta['parent_clauses']==k-1+n
        name=f'gadget{n}-generic{k}-live'
        (output/(name+'.cnf')).write_bytes(cnf.raw())
        parent.dump(output/(name+'.json'),meta)
        family.append({'name':name,'inputs':n,'gates':k,'variables':cnf.variables,'clauses':len(cnf.clauses),
                       'added_clauses':k-1+n,'added_variables':0,'parent_sha256':sha(before),
                       'cnf_sha256':meta['cnf_sha256'],'metadata_sha256':sha((output/(name+'.json')).read_bytes()),
                       'parent_generator_sha256':pin})
    report={'status':'PREPARED_NO_SOLVER_MAIN_REVIEW_REQUIRED','generator_sha256':sha(Path(__file__).read_bytes()),
            'cases':family,'solver_launched':False,'no_global_refutation_claim':True}
    (output/'family.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('output',type=Path)
    print(json.dumps(generate(p.parse_args().output)))
