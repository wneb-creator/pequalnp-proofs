"""Exact delta, full positive-model and finite normalization controls; no solver."""
from pathlib import Path
import hashlib
import importlib.util
import json
import random
import sys

sys.dont_write_bytecode=True
ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S02';OUT=HERE/'gadget-live-controls-v2'
OUT.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
G=load(HERE/'build_live_gadgets.py','live_producer');family=json.loads((HERE/'gadget-live-v1/family.json').read_text())
assert family['generator_sha256']==sha(HERE/'build_live_gadgets.py')
validator_pins={7:'1eeceaaf05207387246634a12238389ba4059a5bf3cc43739edcf0173e8141bb',8:'60e877fd3bdb11d134633519482b67ca82478c55a00350e34a935ddd194054cb'}


def values(gates,n,mask):
    v=[bool(mask>>i&1) for i in range(n)]+[False,True]
    for g,(op,a,b) in enumerate(gates):
        assert op in ['and','or'] and type(a)is int and type(b)is int and 0<=a<=b<n+2+g
        v.append(v[a] and v[b] if op=='and' else v[a] or v[b])
    return v


def normalize(gates,n,k,output):
    off=n+2;live=set();todo=[output]
    while todo:
        w=todo.pop()
        if w<off or w-off in live:continue
        live.add(w-off);todo.extend(gates[w-off][1:])
    mapping={i:i for i in range(off)};new=[]
    for g,(op,a,b) in enumerate(gates):
        if g in live:mapping[off+g]=off+len(new);new.append([op,*sorted([mapping[a],mapping[b]])])
    out=mapping[output]
    while len(new)<k:new.append(['or',out,out]);out=off+len(new)-1
    return new,out


case_reports=[];positive_reports=[];finite=[]
for row in family['cases']:
    n=row['inputs'];k=row['gates'];parent=G.load(n);owner=G.CONFIG[n][0]
    path=HERE/'gadget-live-v1'/(row['name']+'.cnf');meta=json.loads(path.with_suffix('.json').read_text())
    cnf,base_meta=parent.build(k);base_raw=cnf.raw();base_count=len(cnf.clauses)
    assert hashlib.sha256(base_raw).hexdigest()==row['parent_sha256']==meta['parent_cnf_sha256']
    manual=[]
    for g in range(k-1):
        c=[]
        for h in range(g+1,k):
            c.append(base_meta['gate_records'][h]['left'][n+2+g]);c.append(base_meta['gate_records'][h]['right'][n+2+g])
        manual.append(c)
    for v in range(n):manual.append([r[s][v] for r in base_meta['gate_records'] for s in ['left','right']])
    cnf.clauses.extend(manual)
    assert path.read_bytes()==cnf.raw() and meta['liveness_clauses']+meta['input_usage_clauses']==manual
    assert sha(path)==row['cnf_sha256']==meta['cnf_sha256'] and sha(path.with_suffix('.json'))==row['metadata_sha256']
    assert len(manual)==k-1+n and cnf.variables==base_meta['variables']==row['variables']
    essential=[]
    for v in range(n):
        witnesses=[m for m in range(1<<n) if not (m>>v&1) and parent.target(m)!=parent.target(m|(1<<v))]
        assert witnesses;essential.append(witnesses[0])
    case_reports.append({**row,'complete_parent_plus_delta_byte_match':True,'essential_input_witnesses':essential})
    # Existing satisfying models are replayed against the stronger fully pinned
    # positive fixtures. This proves fixture SAT without a new solver process.
    kp=k+1;positive,_=parent.circuit_controls();pos,pm=parent.build(kp)
    units=parent.pins(pm,positive);pos.clauses.extend(units)
    pm.update(pinned_circuit=positive,pin_clause_count=len(units),clauses=len(pos.clauses),cnf_sha256=hashlib.sha256(pos.raw()).hexdigest())
    pos,pm=G.strengthen(pos,pm)
    pm['scope']='Fully pinned positive SAT-assignment control with liveness and input-usage clauses; not generic synthesis or a21gate witness.'
    pp=OUT/f'gadget{n}-positive{kp}-live.cnf';pp.write_bytes(pos.raw());parent.dump(pp.with_suffix('.json'),pm)
    model_path=ROOT/'orch'/owner/f'gadget{n}-v1'/f'positive{kp}.model.stdout'
    model_raw=model_path.read_bytes();(OUT/f'gadget{n}-positive.model.stdout').write_bytes(model_raw)
    ass={}
    for line in model_raw.decode().splitlines():
        if line.startswith('v '):
            for lit in map(int,line.split()[1:]):
                if lit:assert abs(lit) not in ass;ass[abs(lit)]=lit>0
    assert set(ass)==set(range(1,pos.variables+1)) and all(any(ass[abs(v)]==(v>0) for v in c) for c in pos.clauses)
    for mask in range(1<<n):assert values(positive,n,mask)[-1]==parent.target(mask)
    vp=ROOT/'orch'/owner/f'validate_gadget{n}.py';assert sha(vp)==validator_pins[n]
    validator=load(vp,f'live_validator{n}')
    result=validator.validate(pp.read_bytes(),pp.with_suffix('.json').read_bytes(),model_raw,sha(pp),sha(pp.with_suffix('.json')))
    assert result['status']=='VALIDATED_GADGET' and result['verified_inputs']==1<<n and result['full11_verified_inputs']==2048
    assert result['full11_gate_count']==22 and not result['meets_full21_gate_limit']
    parent.dump(OUT/f'gadget{n}-positive.validation.json',result)
    positive_reports.append({'inputs':n,'gates':kp,'all_clauses_checked':len(pos.clauses),'variables':pos.variables,
        'full_model_satisfies_strengthened_fixture':True,'full11_verified_inputs':2048,'full11_gates':22,
        'not_a_target_limit_witness':True,'model_source_sha256':sha(model_path),'validator_sha256':sha(vp)})
    rng=random.Random(134200+n);dead_cases=0;checks=0;false_live=0;false_used=0
    for trial in range(200):
        gates=[]
        for g in range(k):
            a,b=sorted([rng.randrange(n+2+g),rng.randrange(n+2+g)])
            gates.append([rng.choice(['and','or']),a,b])
        out=rng.randrange(n+2+k);normal,last=normalize(gates,n,k,out)
        used={w for g in normal for w in g[1:]}
        assert all(n+2+g in used for g in range(k-1)) and last==n+2+k-1
        for mask in range(1<<n):assert values(gates,n,mask)[out]==values(normal,n,mask)[last];checks+=1
        selector_ass={}
        for g,(op,a,b) in enumerate(gates):
            for side,wire in [('left',a),('right',b)]:selector_ass.update({v:i==wire for i,v in enumerate(base_meta['gate_records'][g][side])})
        gate_holds=all(any(selector_ass[x] for x in c) for c in manual[:k-1])
        input_holds=all(any(selector_ass[x] for x in c) for c in manual[k-1:])
        syntactic_inputs={w for gate in gates for w in gate[1:] if w<n}
        ancestors={k-1}
        for g in reversed(range(k)):
            if g in ancestors:ancestors.update(w-(n+2) for w in gates[g][1:] if w>=n+2)
        assert gate_holds==(len(ancestors)==k) and input_holds==(len(syntactic_inputs)==n)
        false_live+=not gate_holds;false_used+=not input_holds
    assert false_live and false_used
    finite.append({'inputs':n,'random_DAGs':200,'full_output_comparisons':checks,'dead_circuits_rejected':false_live,'unused_input_circuits_rejected':false_used})
reproduced=HERE/'gadget-live-reproduced-v2';G.generate(reproduced)
names=sorted(p.name for p in (HERE/'gadget-live-v1').iterdir())
assert all((HERE/'gadget-live-v1'/p).read_bytes()==(reproduced/p).read_bytes() for p in names)
report={'verdict':'PASS_SELF_EXACT_DELTA_POSITIVE_SAT_ASSIGNMENT_AND_NORMALIZATION_MAIN_REVIEW_REQUIRED',
    'producer_sha256':sha(HERE/'build_live_gadgets.py'),'audit_sha256':sha(Path(__file__)),
    'cases':case_reports,'positive_controls':positive_reports,'random_controls':finite,
    'exact_reproduction_files':len(names),'solver_launched':False,
    'scope':'Two fresh generic models; positive SAT controls are22gate full extensions, not21witnesses. No search verdict.'}
(OUT/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'verdict':report['verdict'],'producer_sha256':report['producer_sha256'],'review_sha256':sha(OUT/'review.json'),
                  'cases':case_reports,'positive_controls':positive_reports,'random_controls':finite}))
