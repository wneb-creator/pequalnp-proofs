# Independent liveness and input-use normalization review: PASS

For either target, each raw input v lies on an edge vw. The assignment with
only w enabled is negative and the assignment with v,w enabled is positive.
Thus every raw input is essential; the review records all15 such witnesses.

Given any at-most-k AND/OR circuit for the target, follow dependencies from
its chosen output and discard the other gates. Keep the surviving topological
order. Each surviving gate except the output has a surviving later use on a
path to that output. Append OR(output,output) gates until there are exactly k
gates. Every former output then feeds the next copy; all gates reach the final
output and the function is unchanged. Constants and repeated operands are
allowed by the parent encoding. No cleanliness, productive-AND, first-junk,
operator-order, or distinct-input assumption enters this argument.

In the opposite direction, if every nonlast gate is used by a later gate,
following any sequence of uses strictly increases its index and must terminate
at the only unconstrained sink, the last output gate. Hence these local use
clauses are exactly the all-output-ancestor predicate in a forward-only DAG.
An essential raw input must occur in a retained operand, since otherwise the
output would be independent of it. Padding retains every such occurrence.

The actual deltas contain one OR of the matching later left/right selectors
per nonlast gate, followed by one OR of all matching raw-input selectors per
real input. Thus the counts are10+7=17 and11+8=19. All clauses are nonempty,
positive, and use existing selector variables; the independent byte rebuild
retains the complete original CNF body. Metadata preserves every existing
field except the documented clause count/hash/scope updates and adds only
the stated provenance/normalization fields. Both validator formats and all
row, selector, operator, output and variable indices remain unchanged.

This establishes equivalence of existence after normalization. It does not
claim the added clauses follow logically from every original assignment;
dead padded representations can fail them. The new CNFs are unsearched in
this review. The frozen SAT-only runner still treats every solver UNSAT as
uncertified UNKNOWN. Even a separately certified gadget lower bound would
not refute arbitrary whole21 circuits or the assigned shard. Lean acceptance
remains separate.

Independent finite checks include all43200 one-input/three-gate DAG/output
choices (constants and repeated ports included),128 larger random choices,
110976 full truth comparisons, exact full-model replay for both strengthened
positive fixtures, and both actual runner preflights. Positive fixtures
extend to22 gates and are rejected by the unchanged runner acceptance rule.
No solver, checker, production, or existing-output mutation occurred.
