"""Restore eight live/rootOR generic/control CNFs byte-exact; no solver."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode=True
ROOT=Path('/tmp/oec/pequalnp-pilot-18');sha=lambda b:hashlib.sha256(b).hexdigest()
def inside(root,relative):
    p=Path(relative)
    if p.is_absolute() or '..' in p.parts:raise ValueError('Unsafe relative path')
    result=root/p
    if result.is_symlink() or not result.resolve().is_relative_to(root.resolve()):raise ValueError('Redirected path')
    return result
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def main(output):
    package=Path(__file__).resolve().parent;recipe=json.loads((package/'reconstruction.json').read_text())
    output=output.resolve()
    if output.exists() or not output.is_relative_to(ROOT) or ROOT.resolve()!=ROOT:raise ValueError('Fresh output inside named scratch required')
    pending=[]
    for row in recipe['sources']:
        raw=inside(package,row['package']).read_bytes();dest=inside(ROOT,row['scratch'])
        if sha(raw)!=row['sha256']:raise ValueError('Packaged source hash mismatch')
        if dest.exists():
            if not dest.is_file() or dest.read_bytes()!=raw:raise ValueError('Existing source differs; refusing overwrite')
        else:pending.append((dest,raw))
    for p,raw in pending:
        p.parent.mkdir(parents=True,exist_ok=True)
        with p.open('xb') as f:f.write(raw)
    output.mkdir(parents=True,exist_ok=False)
    live=load(ROOT/'orch/S02/build_live_gadgets.py','restored_live')
    child=load(ROOT/'orch/S02/build_live_rootor_gadgets.py','restored_rootor')
    live.generate(output/'gadget-live-v1')
    # Change only the imported module's parent-input directory. Source bytes and
    # their recorded hashes remain unchanged; no existing live inputs are written.
    child.HERE=output;child.generate(output/'gadget-live-rootor-v1')
    positive=output/'gadget-live-controls-v2';positive.mkdir()
    rootpositive=output/'gadget-live-rootor-controls';rootpositive.mkdir()
    reports=[]
    for n in [7,8]:
        parent=live.load(n);kp=live.CONFIG[n][2]+1;gates,_=parent.circuit_controls()
        cnf,meta=parent.build(kp);units=parent.pins(meta,gates);cnf.clauses.extend(units)
        meta.update(pinned_circuit=gates,pin_clause_count=len(units),clauses=len(cnf.clauses),cnf_sha256=sha(cnf.raw()))
        cnf,meta=live.strengthen(cnf,meta)
        meta['scope']='Fully pinned positive SAT-assignment control with liveness and input-usage clauses; not generic synthesis or a21gate witness.'
        p=positive/f'gadget{n}-positive{kp}-live.cnf';p.write_bytes(cnf.raw());parent.dump(p.with_suffix('.json'),meta)
        raw,cm=child.child(p.read_bytes(),p.with_suffix('.json').read_bytes())
        q=rootpositive/f'gadget{n}-positive{kp}-live-rootor.cnf';q.write_bytes(raw)
        q.with_suffix('.json').write_text(json.dumps(cm,indent=2,sort_keys=True)+'\n')
        model=inside(package,f'evidence/gadget-live-controls-v2/gadget{n}-positive.model.stdout').read_bytes()
        owner='S05' if n==7 else 'S06';validator=load(ROOT/'orch'/owner/f'validate_gadget{n}.py',f'restored_validator{n}')
        for path in [p,q]:
            result=validator.validate(path.read_bytes(),path.with_suffix('.json').read_bytes(),model,sha(path.read_bytes()),sha(path.with_suffix('.json').read_bytes()))
            assert result['status']=='VALIDATED_GADGET' and result['verified_inputs']==1<<n and result['full11_verified_inputs']==2048
            assert result['full11_gate_count']==22 and not result['meets_full21_gate_limit']
            reports.append({'file':str(path.relative_to(output)),'local_inputs':1<<n,'full_inputs':2048,'whole_gates':22})
    files=[]
    for relative,wanted in recipe['expected'].items():
        p=inside(output,relative);raw=p.read_bytes()
        if sha(raw)!=wanted:raise ValueError('Reconstructed hash mismatch')
        files.append({'path':relative,'sha256':wanted,'bytes':len(raw)})
    result={'verdict':'PASS_EIGHT_CNF_EIGHT_METADATA_TWO_FAMILIES_RECONSTRUCTED',
            'files':files,'CNFs':8,'replayed_positive_models':reports,'solver_launched':False,'network_used':False}
    (output/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'verdict':result['verdict'],'files':len(files),'CNFs':8,'positive_models_replayed':4}))
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('output',type=Path);main(p.parse_args().output)
