#!/usr/bin/env python3
"""Finite support-copy-cover/birth application; no solver."""
import hashlib
import itertools
import json
import time
from functools import lru_cache
from pathlib import Path

ROOT=Path(__file__).resolve().parent
START=time.monotonic()
P1=ROOT/'mixed-triple-census.json'
P0=ROOT/'two-spare-forest-filter.json'
mixed=json.loads(P1.read_text());forest=json.loads(P0.read_text())
families={1:[r for r in mixed['results'][0]['families'] if r['position_witness'] is not None],
          0:[r for r in forest['results'][0]['families'] if not r['excluded']]}
assert len(families[1])==800 and len(families[0])==258
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
   (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
EM=[(1<<u)|(1<<v) for u,v in E]
N=[sum(1<<(v if u==x else u) for u,v in E if x in(u,v)) for x in range(11)]
CN=[sum(1<<v for v,n in enumerate(N) if n&s==s) for s in range(2048)]
@lru_cache(None)
def cover(es):
    if not es:return 0
    u,v=es[0]
    return 1+min(cover(tuple(e for e in es if u not in e)),cover(tuple(e for e in es if v not in e)))

relations=set()
for order in itertools.permutations(range(3)):
    pairs=list(itertools.combinations(order,2))
    for flags in itertools.product((False,True),repeat=3):
        rel=tuple(sorted(e for e,b in zip(pairs,flags) if b))
        if all((a,c) in rel for a,b in rel for x,c in rel if b==x):relations.add(rel)
relations=sorted(relations)
assert len(relations)==19 and relations[0]==()

results=[];tested=0;downward=0
for r,rows in families.items():
    records=[]
    for row in rows:
        S=row['supports'];L=row['individual_costs'];O=row['owners']
        assert sum(o is None for o in O)==r
        tau=[]
        for s,l,o in zip(S,L,O):
            es=tuple(e for e,em in zip(E,EM) if not s&em)
            tc=cover(es);tau.append(tc)
            assert s.bit_count()+len(es)+tc-1==l
            assert CN[s]==(0 if o is None else 1<<o)
            assert s.bit_count()>=2 and s<2047
        H={e for e,em in zip(E,EM) if any(not s&em for s in S)}
        stars=[set() if o is None else {tuple(sorted((o,v))) for v in range(11) if s>>v&1}
               for s,o in zip(S,O)]
        order_checks=[];feasible=[]
        for rel in relations:
            tested+=1
            source={a for a,b in rel};terminal=set(range(3))-source
            if any(O[a] is None for a in source):
                order_checks.append(dict(relation=rel,rejected='NO_COMMON_SOURCE'))
                continue
            B=set(H)
            for a in source:B|=stars[a]
            copy_bound=max([tau[a] for a in source]+[0])
            strict=bool(B) and all(not stars[t]&B for t in terminal)
            lower=len(B)+len(terminal)+max(copy_bound,int(strict))
            order_checks.append(dict(relation=rel,nonterminals=sorted(source),terminals=sorted(terminal),
                required_birth_edges=sorted(B),copy_OR_lower_bound=copy_bound,
                guarded_terminal_bonus=int(strict),gate_lower_bound=lower,rejected=lower>17))
            if lower<=17:feasible.append(rel)
        assert all(not rel for rel in feasible), 'Unexpected nontrivial ancestry survivor'
        reason=None;pairs_record=[];bad_shared=[];tight=[];intersection=None
        if not feasible:
            reason='ALL_ANCESTRY_ORDERS_EXCLUDED'
        elif max(L)>15:
            reason='ANTICHAIN_CONE_AT_MOST15'
        else:
            tight=[i for i in range(3) if L[i]==15]
            def allowed(u):
                return u.bit_count()<=1 or all(u&~S[i]==0 or bool(CN[u]&~S[i]) for i in tight)
            if tight:
                for j,s in enumerate(S):
                    opts=[u for u in range(2048) if u&~s==0 and allowed(u)]
                    for u in opts:
                        v=u
                        while True:
                            assert allowed(v);downward+=1
                            if not v:break
                            v=(v-1)&u
                    pairs=[(u,v) for u,v in itertools.combinations_with_replacement(opts,2) if u|v==s]
                    pairs_record.append(dict(output=j,allowed_pairs=pairs))
                intersection=2047
                for i in tight:intersection&=S[i]
                bad_shared=[i for i in tight if not allowed(S[i]&~intersection)]
                if any(not x['allowed_pairs'] for x in pairs_record) or bad_shared:
                    reason='SYMMETRIC_TIGHT_CORE'
        records.append(dict(supports=S,individual_costs=L,owners=O,residual_cover_numbers=tau,
            forced_edges=sorted(H),ancestry_checks=order_checks,feasible_ancestry_relations=feasible,
            tight_outputs=tight,operand_pairs=pairs_record,shared_core_intersection=intersection,
            failed_shared_outputs=bad_shared,excluded=reason is not None,reason=reason))
    summary=dict(r=r,input=len(rows),ancestry_birth_excluded=sum(x['reason']=='ALL_ANCESTRY_ORDERS_EXCLUDED' for x in records),
        antichain_cone_excluded=sum(x['reason']=='ANTICHAIN_CONE_AT_MOST15' for x in records),
        tight_core_excluded=sum(x['reason']=='SYMMETRIC_TIGHT_CORE' for x in records),
        total_excluded=sum(x['excluded'] for x in records),remaining=sum(not x['excluded'] for x in records),
        nontrivial_ancestry_survivors=sum(any(rel for rel in x['feasible_ancestry_relations']) for x in records))
    assert summary['remaining']=={1:253,0:41}[r]
    results.append(dict(summary=summary,families=records))
    print(json.dumps(summary),flush=True)
out=dict(verdict='COPY_COVER_MANDATORY_BIRTH_FILTER_PENDING_INDEPENDENT_MATH_REVIEW',
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    proof_sha256=hashlib.sha256((ROOT/'support-copy-cover-bound.md').read_bytes()).hexdigest(),
    inputs=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in (P1,P0)],
    strict_partial_orders=relations,relations_checked=tested,downward_checks=downward,
    elapsed_seconds=time.monotonic()-START,results=results,solver_run=False,Lean_proof=False,
    scope='Only supplied800r1/258r0 triples. New residual-cover/copy-OR lemma pending review; guarded strict birth and tight-core deductions reused. Survivors are support families, not circuits.')
(ROOT/'ancestry-copy-birth-filter.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ('source_sha256','proof_sha256','relations_checked','downward_checks','elapsed_seconds')}))
