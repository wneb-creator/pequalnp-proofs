#!/usr/bin/env python3
"""Actual clean-DAG controls for the new component-count bound."""
import hashlib
import json
import random
import time
from functools import lru_cache
from pathlib import Path

ROOT=Path(__file__).resolve().parent
START=time.monotonic();rng=random.Random(13420537)
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
   (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
EM=[(1<<u)|(1<<v) for u,v in E]
N=[sum(1<<(v if u==x else u) for u,v in E if x in(u,v)) for x in range(11)]
EV=[sum(1<<j for j,e in enumerate(E) if v in e) for v in range(11)]+[0]
INDEP=[s for s in range(2048) if not any(s&e==e for e in EM)]
IV=[sum(1<<j for j,s in enumerate(INDEP) if s>>v&1) for v in range(11)]+[0]
@lru_cache(None)
def tau(mask):
    if not mask:return 0
    u,v=E[(mask&-mask).bit_length()-1]
    return 1+min(tau(mask&~EV[u]),tau(mask&~EV[v]))
checks=0;nonzero_residuals=0;component_checks=0;redirect_checks=0;snapshots=[]
for trial in range(256):
    S=[1<<v for v in range(11)]+[0];T=EV.copy();I=IV.copy();anc=[0]*12;gates=[];copies=0
    for g in range(20):
        opts=[]
        for a in range(len(S)):
            if not S[a]:continue
            common=2047
            for v in range(11):
                if S[a]>>v&1:common&=N[v]
            for b in range(a+1,len(S)):
                if S[b] and S[b]&~common==0:opts.append((a,b))
        AND=bool(opts) and rng.random()<0.5
        a,b=rng.choice(opts) if AND else (rng.randrange(len(S)),rng.randrange(len(S)))
        s=0 if AND else S[a]|S[b]
        t=T[a]&T[b] if AND else T[a]|T[b]
        iv=I[a]&I[b] if AND else I[a]|I[b]
        if AND:assert iv==0
        ac=anc[a]|anc[b]|(1<<g)
        if not AND and s in (S[a],S[b]):copies|=1<<g
        gates.append((AND,a,b));S.append(s);T.append(t);I.append(iv);anc.append(ac)
        if not s or s==2047:continue
        root=12+g;retained=set();parents={};stack=[root]
        while stack:
            w=stack.pop()
            if w in retained:continue
            retained.add(w)
            if w<12:continue
            op,x,y=gates[w-12]
            if op:
                singleton=x if S[x].bit_count()==1 else y
                assert S[singleton].bit_count()==1
                ps=[singleton]
            else:ps=[x,y]
            parents[w]=ps;stack.extend(ps)
        F=sum(1<<w for w in retained if w<11)
        assert all(not t>>j&1 or F&e for j,e in enumerate(EM))
        H=t&~sum(0 for _ in ())
        incident=0
        for v in range(11):
            if s>>v&1:incident|=EV[v]
        H=t&~incident
        assert all(not H>>j&1 or (F&~s)&e for j,e in enumerate(EM))
        low={w for w in retained if S[w].bit_count()<=1}
        adj={w:set() for w in low}
        for w,ps in parents.items():
            for p in ps:
                if w in low and p in low:adj[w].add(p);adj[p].add(w)
        components=[];unused=set(low)
        while unused:
            q=[next(iter(unused))];comp=set()
            while q:
                w=q.pop()
                if w in comp:continue
                comp.add(w);q.extend(adj[w]-comp)
            unused-=comp;components.append(comp)
        bad=[];small_copies=sum(w>=12 and not gates[w-12][0] for w in low)
        large_copies=sum(w>=12 and S[w].bit_count()>1 and bool(copies>>(w-12)&1) for w in retained)
        for comp in components:
            inputs=sum(w<12 for w in comp);ors=sum(w>=12 and not gates[w-12][0] for w in comp)
            assert inputs<=ors+1
            if not any(w<11 and s>>w&1 for w in comp):bad.append(comp)
        attachments=[]
        for comp in bad:
            links=[w for w,ps in parents.items() if w not in low and any(p in comp for p in ps)]
            assert links
            for w in links:
                assert not gates[w-12][0] and copies>>(w-12)&1
                assert all(S[p]==0 for p in parents[w] if p in comp)
            attachments.append(set(links))
        assert all(not x&y for i,x in enumerate(attachments) for y in attachments[i+1:])
        assert len(bad)<=large_copies
        assert (F&~s).bit_count()<=small_copies+len(bad)
        cc=(ac&copies).bit_count()
        assert tau(H)<=(F&~s).bit_count()<=cc
        checks+=1;component_checks+=len(components);nonzero_residuals+=int(bool(H))
    # Redirect every support-copy OR and compare all supports/birth edges.
    alias=list(range(12));RS=S[:12];RG=[];old_births=0;new_births=0
    for g,(op,a,b) in enumerate(gates):
        w=12+g
        if op:
            old_births|=sum(1<<j for j,(u,v) in enumerate(E) if (S[a]>>u&1 and S[b]>>v&1) or (S[a]>>v&1 and S[b]>>u&1))
        if not op and copies>>g&1:
            chosen=a if S[a]==S[w] else b
            assert S[chosen]==S[w]
            alias.append(alias[chosen])
        else:
            x,y=alias[a],alias[b];ns=0 if op else RS[x]|RS[y]
            assert ns==S[w]
            if op:new_births|=sum(1<<j for j,(u,v) in enumerate(E) if (RS[x]>>u&1 and RS[y]>>v&1) or (RS[x]>>v&1 and RS[y]>>u&1))
            alias.append(len(RS));RS.append(ns);RG.append((op,x,y))
        assert RS[alias[-1]]==S[w]
    assert old_births==new_births and len(RG)==len(gates)-copies.bit_count()
    redirect_checks+=1
    if trial<12:snapshots.append(dict(gates=gates,supports=S,edge_values=T,copy_mask=copies,births=old_births,redirected=RG))
# Explicit missing-guard negative control: AND(0,9) has S=empty, tau=1,c=0.
assert tau(1<<E.index((0,9)))==1
out=dict(verdict='ACTUAL_DAG_AND_REDIRECTION_CONTROLS_PASS_NOT_A_GENERAL_PROOF',
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    math_sha256=hashlib.sha256((ROOT/'support-copy-cover-bound.md').read_bytes()).hexdigest(),
    circuits=256,gates_per_circuit=20,nonempty_proper_outputs_checked=checks,
    nonempty_residual_cases=nonzero_residuals,components_checked=component_checks,
    support_redirections_checked=redirect_checks,empty_support_countercontrol=True,
    snapshots=snapshots,elapsed_seconds=time.monotonic()-START,solver_run=False,Lean_proof=False)
(ROOT/'support-copy-cover-controls.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='snapshots'}))
