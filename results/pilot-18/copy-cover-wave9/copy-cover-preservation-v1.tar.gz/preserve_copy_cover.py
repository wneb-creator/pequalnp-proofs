#!/usr/bin/env python3
"""Seal and reproduce this finite mathematical research handoff."""
import hashlib
import io
import json
import subprocess
import sys
import tarfile
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
DEST=ROOT/'copy-cover-preservation-v1'
assert not DEST.exists()
DEST.mkdir()
handoff=ROOT/'copy-cover-closure-handoff.json'
data=json.loads(handoff.read_text())
payload={}
for f in data['files']:
    p=Path(f['path']);raw=p.read_bytes()
    assert hashlib.sha256(raw).hexdigest()==f['sha256']
    payload[p.name]=(p,raw)
extra=[ROOT/'copy-cover-closure-handoff.json',ROOT/'copy-cover-preservation-README.md',
       ROOT/'support-copy-cover-bound.md',ROOT/'support-copy-terminal-charge.md',
       ROOT/'two-sink-tight-cones.md',ROOT/'two-sink-tight-cones-v2.md',
       ROOT/'tight-survivor-obstruction.md',ROOT/'joint-factor-cost.md',
       ROOT/'irrelevant-input-charge.md',Path(__file__)]
for p in extra:payload[p.name]=(p,p.read_bytes())
review_root=ROOT.parent/'S04'
for name in ('forced-birth-math-review.md','forced-birth-review.json',
             'forest-sinks-review.json','mixed-triple-review.json'):
    p=review_root/name;payload['prior-reviews/'+name]=(p,p.read_bytes())
manifest=dict(status='PENDING_NEW_MATH_INDEPENDENT_REVIEW_NO_LEAN_SAT_GLOBAL_CLAIM',
    files=[dict(member=n,source=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
           for n,(p,raw) in sorted(payload.items())])
manifest_raw=(json.dumps(manifest,indent=2)+'\n').encode()
(DEST/'manifest.json').write_bytes(manifest_raw)
archive=ROOT/'copy-cover-preservation-v1.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as tf:
    for name,raw in [('manifest.json',manifest_raw)]+[(n,v[1]) for n,v in sorted(payload.items())]:
        ti=tarfile.TarInfo(name);ti.size=len(raw);ti.mode=0o644;ti.mtime=0
        tf.addfile(ti,io.BytesIO(raw))
restore=DEST/'restore';restore.mkdir()
with tarfile.open(archive,'r:gz') as tf:
    assert len(tf.getmembers())==len(payload)+1
    for member in tf.getmembers():
        assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        raw=tf.extractfile(member).read()
        expected=manifest_raw if member.name=='manifest.json' else payload[member.name][1]
        assert raw==expected
        target=restore/member.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
runs=[]
for script,stem in [('filter_terminal_copy_birth.py','final-filter'),('check_support_copy_cover.py','dag-controls')]:
    out=DEST/(stem+'.stdout.txt');err=DEST/(stem+'.stderr.txt');start=time.monotonic()
    with out.open('wb') as so,err.open('wb') as se:
        proc=subprocess.run([sys.executable,str(restore/script)],cwd=restore,stdout=so,stderr=se,timeout=30)
    assert proc.returncode==0
    runs.append(dict(script=script,exit_code=proc.returncode,elapsed_seconds=time.monotonic()-start,
        stdout_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),stderr_sha256=hashlib.sha256(err.read_bytes()).hexdigest()))
original=json.loads((ROOT/'terminal-copy-birth-filter.json').read_text())
reproduced=json.loads((restore/'terminal-copy-birth-filter.json').read_text())
for key in ('results','relations','relations_checked','source_sha256','proof_sha256','terminal_extension_sha256'):
    assert original[key]==reproduced[key]
original_controls=json.loads((ROOT/'support-copy-cover-controls.json').read_text())
new_controls=json.loads((restore/'support-copy-cover-controls.json').read_text())
for key in original_controls:
    if key!='elapsed_seconds':assert original_controls[key]==new_controls[key]
result=dict(verdict='ARCHIVE_HASH_ROUNDTRIP_AND_PORTABLE_REPRODUCTION_PASS_NEW_MATH_PENDING_REVIEW',
    archive=str(archive),archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),archive_bytes=archive.stat().st_size,
    manifest_sha256=hashlib.sha256(manifest_raw).hexdigest(),payload_count=len(payload),regular_members=len(payload)+1,
    producer_handoff_sha256=hashlib.sha256(handoff.read_bytes()).hexdigest(),runs=runs,
    final_family_records_identical=True,all_deterministic_DAG_controls_identical=True,
    solver_run=False,Lean_build=False)
(DEST/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
