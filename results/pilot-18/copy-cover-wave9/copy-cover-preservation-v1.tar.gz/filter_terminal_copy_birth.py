#!/usr/bin/env python3
"""Final terminal-copy residual-cover charge on all supplied triples."""
import hashlib
import itertools
import json
import time
from functools import lru_cache
from pathlib import Path

ROOT=Path(__file__).resolve().parent
START=time.monotonic()
parents=[ROOT/'mixed-triple-census.json',ROOT/'two-spare-forest-filter.json']
mixed=json.loads(parents[0].read_text());forest=json.loads(parents[1].read_text())
family_sets={1:[r for r in mixed['results'][0]['families'] if r['position_witness']],
             0:[r for r in forest['results'][0]['families'] if not r['excluded']]}
assert len(family_sets[1])==800 and len(family_sets[0])==258
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
   (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
EM=[(1<<u)|(1<<v) for u,v in E]
N=[sum(1<<(v if u==x else u) for u,v in E if x in(u,v)) for x in range(11)]
CN=[sum(1<<v for v,n in enumerate(N) if n&s==s) for s in range(2048)]
@lru_cache(None)
def cover(es):
    if not es:return 0
    u,v=es[0]
    return 1+min(cover(tuple(e for e in es if u not in e)),cover(tuple(e for e in es if v not in e)))
relations=set()
for order in itertools.permutations(range(3)):
    pairs=list(itertools.combinations(order,2))
    for flags in itertools.product((False,True),repeat=3):
        rel=tuple(sorted(p for p,b in zip(pairs,flags) if b))
        if all((a,c) in rel for a,b in rel for x,c in rel if b==x):relations.add(rel)
relations=sorted(relations)
assert len(relations)==19
results=[];checked=0
for r,rows in family_sets.items():
    records=[]
    for row in rows:
        S=row['supports'];L=row['individual_costs'];O=row['owners']
        assert sum(o is None for o in O)==r
        tau=[]
        for s,l,o in zip(S,L,O):
            es=tuple(e for e,em in zip(E,EM) if not s&em);tc=cover(es);tau.append(tc)
            assert l==s.bit_count()+len(es)+tc-1
            assert CN[s]==(0 if o is None else 1<<o)
            assert 2<=s.bit_count()<11
        H={e for e,em in zip(E,EM) if any(not s&em for s in S)}
        stars=[set() if o is None else {tuple(sorted((o,v))) for v in range(11) if s>>v&1}
               for s,o in zip(S,O)]
        orders=[];feasible=[]
        for rel in relations:
            checked+=1;source={a for a,b in rel};T=set(range(3))-source
            if any(O[a] is None for a in source):
                orders.append(dict(relation=rel,rejected='NO_COMMON_SOURCE'));continue
            B=set(H)
            for a in source:B|=stars[a]
            copy_bound=max([0]+[tau[i]-int(i in T) for i in range(3)])
            guarded_bonus=int(bool(B) and all(not stars[i]&B for i in T))
            lower=len(B)+len(T)+max(copy_bound,guarded_bonus)
            orders.append(dict(relation=rel,terminals=sorted(T),required_birth_edges=sorted(B),
                copy_OR_lower_bound=copy_bound,guarded_terminal_bonus=guarded_bonus,
                prefix_gate_lower_bound=lower,excluded=lower>17))
            if lower<=17:feasible.append(rel)
        tight_tests=[];shared_failed=[];intersection=None;tight=[]
        if not feasible:
            reason='ALL19_ANCESTRY_ORDERS_EXCLUDED'
        else:
            assert feasible==[()], 'Only the ancestry antichain should survive'
            assert max(L)<=15
            tight=[i for i in range(3) if L[i]==15]
            assert tight
            def allowed(u):
                return u.bit_count()<=1 or all(u&~S[i]==0 or bool(CN[u]&~S[i]) for i in tight)
            for j,s in enumerate(S):
                opts=[u for u in range(2048) if not u&~s and allowed(u)]
                pairs=[(u,v) for u,v in itertools.combinations_with_replacement(opts,2) if u|v==s]
                tight_tests.append(dict(output=j,allowed_pairs=pairs))
            intersection=2047
            for i in tight:intersection&=S[i]
            shared_failed=[i for i in tight if not allowed(S[i]&~intersection)]
            assert any(not x['allowed_pairs'] for x in tight_tests) or shared_failed
            reason='ONLY_ANTICHAIN_THEN_REVIEWED_TIGHT_CORE_EXCLUSION'
        records.append(dict(supports=S,individual_costs=L,owners=O,residual_cover_numbers=tau,
            original_forced_edges=sorted(H),ancestry_checks=orders,feasible_ancestry_relations=feasible,
            tight_outputs=tight,operand_tests=tight_tests,shared_core_intersection=intersection,
            failed_shared_outputs=shared_failed,excluded=True,reason=reason))
    summary=dict(r=r,input=len(rows),direct_copy_birth_excluded=sum(x['reason']=='ALL19_ANCESTRY_ORDERS_EXCLUDED' for x in records),
        antichain_tight_excluded=sum(x['reason']!='ALL19_ANCESTRY_ORDERS_EXCLUDED' for x in records),
        total_excluded=len(records),remaining=0)
    assert (summary['direct_copy_birth_excluded'],summary['antichain_tight_excluded'])=={1:(800,0),0:(251,7)}[r]
    results.append(dict(summary=summary,families=records));print(json.dumps(summary),flush=True)
out=dict(verdict='ALL_SUPPLIED_K3_R1_R0_PROPOSED_EXCLUDED_PENDING_INDEPENDENT_REVIEW',
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    proof_sha256=hashlib.sha256((ROOT/'support-copy-cover-bound.md').read_bytes()).hexdigest(),
    terminal_extension_sha256=hashlib.sha256((ROOT/'support-copy-terminal-charge.md').read_bytes()).hexdigest(),
    inputs=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in parents],
    relations=relations,relations_checked=checked,results=results,elapsed_seconds=time.monotonic()-START,
    solver_run=False,Lean_proof=False,
    scope='Only supplied800r1/258r0 minimal proper full-cover triples in17productivecleanprefixgates. New copy-cover lemma requires independent proof/code review. No k4/5 or global shard claim.')
(ROOT/'terminal-copy-birth-filter.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ('source_sha256','proof_sha256','terminal_extension_sha256','relations_checked','elapsed_seconds')}))
