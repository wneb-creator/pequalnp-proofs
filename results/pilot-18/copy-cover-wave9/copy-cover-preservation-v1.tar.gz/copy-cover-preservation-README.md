# S01 copy-cover research checkpoint

Status at creation: new general mathematics and final finite application
await independent S04 review. This package is NOT a Lean proof, SAT result,
accepted proof, or whole assigned-shard conclusion.

The proposed residual-cover/support-copy-OR lemma and terminal correction are
in support-copy-cover-bound.md and support-copy-terminal-charge.md. The final
filter checks all19 selected ancestry relations for each supplied remaining
family. It proposes excluding all800 k3/r1 families directly,251/258 k3/r0
families directly, and the last7 by the already reviewed tight-cone argument.
Earlier independent reviews connect the supplied lists to their original
minimal proper-full-factor censuses. Larger factor families remain open.

The two Python entry points needed to reproduce the final finite application
and actual-DAG controls are filter_terminal_copy_birth.py and
check_support_copy_cover.py. Place them beside their supplied input JSON and
mathematical Markdown files, and run them with Python3. No solver, external
package, network, lease, repository write, credential or Lean tool is needed.
Output timing and absolute input-path fields vary by extraction directory;
all mathematical family records, source hashes and deterministic controls
must match. Complete original stdout and stderr are retained verbatim.

The earlier ancestry-copy-birth filter is preserved as a weaker intermediate
result. It is superseded by the terminal-minus-one charge, not evidence of a
second independent verification. Random actual-DAG controls are concrete
checks, not a proof of the general lemma. The empty-support AND countercontrol
explains the explicit nonempty-output-support premise. The strict-birth bonus
uses S04's nonempty-required-birth guard; the old unguarded generic claim is
not reused.

No production worker, active CNF, final Lean file, lease or Git state was
changed by these tasks. Main owns independent review, preservation and delivery.

Sub-agents: none
TIMING total=331 subagents=0
