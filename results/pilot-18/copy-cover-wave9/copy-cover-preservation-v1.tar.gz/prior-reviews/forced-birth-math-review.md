# S04 forced-birth review: PASS with an explicit nonempty-H guard

The new argument closes the previously reviewed17 remaining k3/r2 support
families, conditional on the already reviewed17-gate productive-clean-prefix
normalization and complete mixed census. One family needs at least19 gates;
the other16 need at least18. With51 earlier exclusions, all68 surviving
mixed-r2 families are excluded. This is a mathematical and finite review,
not a Lean proof, implemented CNF restriction, SAT result or whole-shard claim.

The producer proof reviewed is forced-birth-terminal-bound.md, SHA256
ce4af7f97ca5ac57c10f10d85467daa6f9e9e33ec79a66f461769dfbc55c980a.
Its unrestricted strict statement has a genuine degenerate counterexample:
in the triangle on0,1,2, the three terminal OR gates(0,1),(0,2),(1,2) are
proper full-cover factors, have supports of size2, form an ancestry antichain,
and their product is the triangle edge function. H is empty, the core is
empty, and the terminal-star condition holds. The proposed bound says3>=4.
The failed step is choosing a last gate in the empty core.

Repair: require |E(H)|>0 for the strict bonus, or separately require a
nonempty retained core. Every application here has14 or16 edges in H, so the
repair does not change any exclusion. The independent finite source applies
the explicit nonempty-H guard. The original producer text and finite output
are retained unchanged as reviewed historical artifacts, with this correction.

## Exact helper interface and pruning

The existing edge_finset_gate_bound and edge_finset_gate_bound_partial were
read in the named Lean file without editing or compiling it. Their support
interfaces need only topologically earlier parents, singleton-or-empty raw
supports, empty AND support, OR support union, complete joins at ANDs, the
C4-free one-small-side property, and a birth cover for the graph being counted.
Neither helper requires a designated output or an exact function at a core
wire. A read-only snapshot and the original file hash are retained.

Pruning to the ancestor union of the k selected outputs makes those outputs
terminal because they are a syntactic ancestry antichain. Their nonempty
supports imply OR gates. Deleting them therefore retains every AND and all
its operand computations. Remove unused TRUE and reindex the remaining
inputs/gates in topological order before applying hsmall. TRUE cannot occur
on a retained path: its full support has no common neighbor in a loopless
graph, so productivity precludes a first AND descendant, while an OR-only
path would make a selected support full. FALSE and copies cause no problem.

For each edge of H, an output accepts that edge despite rejecting both
singleton endpoints. The edge-birth lemma yields a cross-support AND birth
in its core cone. Let B be the union of cross-support edges over every core
AND. Cleanliness gives B subset G, so B is C4-free. The counting helper gives

    |H| <= |B| <= #core AND + #core OR with support size>1
                     <= #core gates <= m-k.

Repeated births and shared ancestors are counted by the existing helper;
this argument does not sum individual output costs or count distinct ANDs
as distinct graph edges.

## Equality contradiction with H nonempty

Assume |H|=m-k. Then every inequality is equality, the core is nonempty, and
B=H. Pruning to the ancestor union of all core ANDs preserves all AND operand
computations and B. If it deletes any core gate, the same helper contradicts
|H|=m-k. Thus each core gate is ancestral to an AND (including itself).

Suppose a core gate has the exact support S_i of a selected output. Follow
it to a first AND q. The OR-only segment before q puts S_i in one operand.
Productivity supplies an element u of the other operand, and cleanliness
puts u in CN(S_i). If CN(S_i) is empty there is an immediate contradiction.
Otherwise every edge u-v for v in S_i is born at q. The terminal-star
condition says these edges are outside H, contradicting B=H.

The last core gate must itself be AND, since it is ancestral to one. It is
live after initial pruning and has no later core gate, so it directly feeds
a selected terminal OR. Its support is empty, forcing the other operand to
have exact support S_i. Since |S_i|>=2 and S_i is proper, that operand is a
gate rather than a raw input, FALSE or TRUE. It cannot be another selected
output by ancestry incomparability. Thus it is a forbidden core gate. This
proves m>=|H|+k+1 under the nonempty-H and terminal-star hypotheses. No
minimum-size or no-dead-gate assumption was inserted into the original prefix.

## Finite application and scope

All18 v2 survivors have one common-neighbor support of cost at least14.
The independently reviewed three-new-gates lemma therefore makes the three
selected outputs an ancestry antichain in17 gates. One family[384,592,1034]
has16 forced edges and the basic count already requires19 gates. The other17
have14 forced edges. Their common support has a unique owner belonging to
both no-common-neighbor supports, so every terminal star edge intersects all
three supports and lies outside H. The strict count requires18 gates.

One of those17 was already excluded by partial twins. The exact current
remaining set therefore splits into ONE basic and SIXTEEN strict exclusions.
The independent script verifies the exact17 binding, all18 edge sets and
owner conditions, individual costs by a separate brute-force cover calculation,
36864 complete truth rows, full-factor product and proper-subproduct witnesses,
and the exact disjoint union51+17=68. It also retains the triangle countermodel
and a sharp nonempty-H control: G consists of disjoint edges01 and23; the
single factor(0 OR1) OR(2 AND3) has m=3, k=1, |H|=1 and attains the repaired
strict bound. These controls verify concrete edge cases, not the general proof.

Independent source review_forced_birth.py SHA256
624c39cbebd076ec2e4925200d44396366c42ae2a275264f39a567f5261a41a9;
result forced-birth-review.json SHA256
8ccc9ad77b0a23d8c91c7141cf7627e26b2f0d64589a994cd35a21f1f26fa500.
The run exited0 in0.057 seconds with empty stderr. The named Lean file remains
SHA256 0e0620c89307cf34be010940037cb187797eea76c85fc8c8a89b9bd1cfc56e5c.

The surviving common-neighbor counts remain258 k3/r0 and112 k4/r0; k3/r1
remains800 at this checkpoint. Pure k4/r4 and k5/r5 remain open. This review
does not convert support-family exclusions into unreviewed CNF clauses or
claim that the full21-gate proof gap has been closed.
