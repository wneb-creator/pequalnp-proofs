"""Final four-input preparation package with all main/S06 reviews; no runtime."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile

ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S02'
PREP=HERE/'live-gadget-repair-stage/S02-live-gadget-repairs'
STAGE=HERE/'final-live-gadget-stage/S02-final-live-gadgets';OUT=HERE/'final-live-gadget-preservation-v1'
STAGE.mkdir(parents=True,exist_ok=False);OUT.mkdir(exist_ok=False)
sha=lambda raw:hashlib.sha256(raw).hexdigest();bindings=[];omitted=[]
def copy(source,relative):
    assert source.is_file() and not source.is_symlink();raw=source.read_bytes()
    if source.suffix=='.cnf':
        omitted.append({'source':str(source),'sha256':sha(raw),'bytes':len(raw),'recipe':'preparation/reconstruction.json'});return
    text=raw.decode()
    assert not re.search(r'github_pat_[A-Za-z0-9_]{30,}|gh[pousr]_[A-Za-z0-9_]{20,}|[?&]lease=[A-Za-z0-9_-]{16,}|-----BEGIN [A-Z ]*PRIVATE KEY-----',text),'Sensitive indicator; content not printed'
    dest=STAGE/relative;dest.parent.mkdir(parents=True,exist_ok=True)
    with dest.open('xb') as f:f.write(raw)
    assert source.read_bytes()==raw
    bindings.append({'source':str(source),'archive':relative,'sha256':sha(raw),'bytes':len(raw)})
def tree(source,prefix):
    for path in sorted(source.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():copy(path,prefix+'/'+str(path.relative_to(source)))
old=json.loads((PREP/'MANIFEST.json').read_text())
for row in old['files']:
    raw=(PREP/row['path']).read_bytes();assert sha(raw)==row['sha256'] and len(raw)==row['bytes']
tree(PREP,'preparation')
for name in ['validation.json','validation.txt']:
    copy(HERE/'live-gadget-repair-preservation-v1'/name,'earlier-delivery/'+name)
copy(HERE/'live-gadget-repair-preservation-handoff.json','earlier-delivery/handoff.json')
for name in ['main-live-gadget-review.json','main-live-rootor-review.json']:
    copy(ROOT/'orch/MAIN'/name,'main-reviews/'+name)
handoff_path=ROOT/'orch/S06/gadget-rootor-review-handoff.json'
assert sha(handoff_path.read_bytes())=='0821cf3561edc2ecd31b270accbb0a3f4e89d8fe8b0291b1f608f156c5e748fa'
handoff=json.loads(handoff_path.read_text());assert handoff['status']=='PASS_ROOT_OR_CANDIDATE_ONLY_DELTA_AND_COMPATIBILITY'
for name,row in handoff['files'].items():
    path=ROOT/name;assert path.resolve().is_relative_to(ROOT)
    raw=path.read_bytes();assert sha(raw)==row['sha256'] and len(raw)==row['bytes']
tree(ROOT/'orch/S06/gadget-rootor-review-v1','S06-rootOR-review')
for name in ['gadget-rootor-review-handoff.json','gadget-rootor-review.execution.json','gadget-rootor-review.stdout',
             'gadget-rootor-review.stderr','review_rootor_gadgets.py']:
    copy(ROOT/'orch/S06'/name,'S06-rootOR-provenance/'+name)
copy(HERE/'verify_best4_shuffle_package.py','verify_payloads.py')
copy(Path(__file__),'seal_final_live_gadgets.py')
(STAGE/'README.md').write_text('Final four live/rootOR gadget inputs: source, recipes, complete controls and reviews\n\n'
    'All four production-input recipes are present: generic7/11-live, generic8/12-live, and their separate rootORchildren. Live adds17/19clauses with no variables and has the reviewed output-cone-pruning/OR-copy-padding normalization. Each rootORchild adds oneunit(-761/-903), excludesAND-rootcircuits and explicitly makesNOcompleteness/WLOGclaim. Bothmainreviews and allS06live/rootORreviews, sourceaudits, completepositiveassignmentmodels, fullvalidatoroutputs and preflights are retained. Main/S06bindings were rehashed.\n\n'
    'Noactiveoutputs or launch/runtime records are included. Mainreportedlaunching the livevariants05:52 androotORvariants05:53; those ongoingresults are deliberately absent. Historical PREPARED/productionfalse labels in source/reviewrecords describe their earliercreation. Any finalruntime must be preservedseparately aftercompletion. No currentSAT/UNSAT outcome is inferred.\n\n'
    'The nestedpreparation directory is an exactunchanged copy of the earlier source/control package. It includes all8CNFrecipes:4productioninputs plus4positivefixtures, fourcompletepositiveSATmodels/full128or256+2048validatorchecks,400randomDAG/76800normalizationcomparisons and completed134232 finitework. Positivefixtures are22wholegates, not21witnesses. The134232 one/twofresh-operation andmultiport scans completed9168901contextchecks, foundno21repair, and retainedanexact22control; the rawvalidator exit2 correctlylabels ittoo large. These localnegativeresults do not exclude arbitrary21circuits.\n\n'
    'Reconstruct all8CNFs+8metadata+2familyfiles withPython3stdlib: python3 preparation/restore_live_gadget_package.py /tmp/oec/pequalnp-pilot-18/fresh-final-live-reproduction . This checks8sourcepins/refusesexistingdifferentfiles, regeneratesbyte-identicalCNFs and replays4positivevalidators; it launches no solver,optimizer,compiler orLean. Run verify_payloads.py for checksum-onlyverification. Binaries/rawCNFfiles/credentials/leasevalues are omitted. The originalfrozenhandoffs andinputs remainunchanged. Mainperformsfinaldeliveryreview; no exact21witness, acceptedcertificate, globalrefutation orpostedcheckeracceptance is claimed.\n')
repro=HERE/'final-live-gadget-reconstruction'
with (OUT/'reconstruction.stdout').open('x') as a,(OUT/'reconstruction.stderr').open('x') as b:
    proc=subprocess.run([sys.executable,'-B',str(STAGE/'preparation/restore_live_gadget_package.py'),str(repro)],stdout=a,stderr=b,timeout=60)
assert proc.returncode==0
restored=json.loads((repro/'validation.json').read_text());assert restored['CNFs']==8 and len(restored['files'])==18 and len(restored['replayed_positive_models'])==4
copy(repro/'validation.json','final-reconstruction/validation.json')
for p in sorted(OUT.iterdir()):copy(p,'final-reconstruction/'+p.name)
for row in bindings:assert sha(Path(row['source']).read_bytes())==row['sha256']
(STAGE/'copy-bindings.json').write_text(json.dumps({'files':bindings,'omitted_CNFs':omitted},indent=2)+'\n')
rows=[{'path':str(p.relative_to(STAGE)),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(STAGE.rglob('*')) if p.is_file()]
(STAGE/'MANIFEST.json').write_text(json.dumps({'files':rows,'scope':'Final reviewedfourinputpreparation pluscontrols/finitechecks, noactive runtime.'},indent=2)+'\n')
with (OUT/'verification.stdout').open('x') as a,(OUT/'verification.stderr').open('x') as b:
    proc=subprocess.run([sys.executable,'-B',str(STAGE/'verify_payloads.py')],stdout=a,stderr=b,timeout=30)
assert proc.returncode==0
archive=OUT/'S02-final-live-gadgets.tar.gz'
with archive.open('xb') as f:
    with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w',format=tarfile.USTAR_FORMAT) as tar:
            for p in sorted(STAGE.rglob('*')):
                if not p.is_file():continue
                raw=p.read_bytes();info=tarfile.TarInfo('S02-final-live-gadgets/'+str(p.relative_to(STAGE)))
                info.size=len(raw);info.mode=0o644;info.uid=0;info.gid=0;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:gz') as tar:
    members=tar.getmembers();assert len(members)==len(rows)+1 and len({m.name for m in members})==len(members)
    for member in members:
        name=PurePosixPath(member.name);assert member.isfile() and not name.is_absolute() and '..' not in name.parts and name.parts[0]=='S02-final-live-gadgets'
        assert tar.extractfile(member).read()==(STAGE/Path(*name.parts[1:])).read_bytes()
for name in ['README.md','MANIFEST.json']:(OUT/name).write_bytes((STAGE/name).read_bytes())
report={'verdict':'PASS_SELF_FINAL_REVIEWED_FOUR_INPUT_SOURCE_CONTROL_PRESERVATION_MAIN_DELIVERY_REVIEW_REQUIRED',
    'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'archive_regular_members':len(members),
    'manifest_sha256':sha((OUT/'MANIFEST.json').read_bytes()),'exact_source_copies':len(bindings),
    'S06_rootOR_bindings_verified':len(handoff['files']),'main_live_and_rootOR_reviews_included':True,
    'production_input_recipes':4,'positive_fixture_recipes':4,'reconstructed_CNFs':8,'reconstructed_files':18,'positive_models_replayed':4,
    'finite134232_work_included':True,'raw_CNF_members':0,'binary_members':0,'active_outputs_read':False,'production_runtime_included':False,'solver_launched':False}
(OUT/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
