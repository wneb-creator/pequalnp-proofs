#!/usr/bin/env python3
"""Independent one-unit candidate restriction review; no solver execution."""
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time
from types import SimpleNamespace
sys.dont_write_bytecode=True
ROOT=Path('/tmp/oec/pequalnp-pilot-18');OWN=ROOT/'orch/S06';PEER=ROOT/'orch/S02';OUT=OWN/'gadget-rootor-review-v1'
def info(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def sha(p):return info(p)['sha256']
def save(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def need(ok,msg):
    if not ok:raise AssertionError(msg)
def load(p,name):
    s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def delta(parent,child,producer):
    pm=json.loads(parent.with_suffix('.json').read_text());cm=json.loads(child.with_suffix('.json').read_text());unit=-pm['gate_records'][-1]['op']
    lines=parent.read_bytes().splitlines(True)
    expected=f"p cnf {pm['variables']} {pm['clauses']+1}\n".encode()+b''.join(lines[1:])+f'{unit} 0\n'.encode()
    need(child.read_bytes()==expected,'exact one unit delta')
    added={'live_parent_cnf_sha256','live_parent_metadata_sha256','live_parent_clause_count','root_or_unit','root_operator','root_or_candidate_only','candidate_only','all_circuits_covered','root_or_postprocessor_sha256'}
    need(set(cm)==set(pm)|added,'metadata added keys')
    for key,value in pm.items():
        if key not in ['clauses','cnf_sha256','scope','completeness']:need(cm[key]==value,'old metadata changed '+key)
    need(cm['clauses']==pm['clauses']+1 and cm['cnf_sha256']==sha(child) and cm['root_or_unit']==[unit] and cm['root_operator']=='or','child counts/unit')
    need(cm['candidate_only'] is True and cm['root_or_candidate_only'] is True and cm['all_circuits_covered'] is False,'candidate-only scope')
    need(cm['live_parent_cnf_sha256']==sha(parent) and cm['live_parent_metadata_sha256']==sha(parent.with_suffix('.json')) and cm['live_parent_clause_count']==pm['clauses'] and cm['root_or_postprocessor_sha256']==producer,'parent/producer binding')
    record=pm['gate_records'][-1];op=record['op'];a=record['left_values'][0];b=record['right_values'][0];y=record['outputs'][0]
    kernel=[[-op,-y,a],[-op,-y,b],[-op,y,-a,-b],[op,y,-a],[op,y,-b],[op,-y,a,b]]
    existing={tuple(map(int,line.split()[:-1])) for line in lines[1:]}
    need(all(tuple(c) in existing for c in kernel),'actual parent gate kernel')
    for values in itertools.product([False,True],repeat=4):
        assignment=dict(zip([op,a,b,y],values));sat=all(any(assignment[abs(v)]==(v>0) for v in c) for c in kernel+[[unit]])
        need(sat==(not values[0] and values[3]==(values[1] or values[2])),'unit means OR')
    return unit

def main():
    t=time.monotonic();OUT.mkdir();snap=OUT/'source-snapshot';snap.mkdir()
    hp=PEER/'gadget-live-rootor-handoff.json';need(sha(hp)=='91789a606104b4fa9e601b51abaf15ef0a6947c0634831ae0f5cbc8c5da57eb2','rootOR handoff pin');h=json.loads(hp.read_text())
    bindings={}
    for entry in h['artifacts']:
        p=Path(entry['path']);need(info(p)=={k:entry[k] for k in ['bytes','sha256']},'artifact pin');bindings[str(p)]=info(p)
        q=snap/p.relative_to(PEER);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
    shutil.copyfile(hp,snap/hp.name)
    live=OWN/'gadget-live-review-handoff.json';need(sha(live)=='9de59886c99eab3684f91ad885dc35301d59ab380f7b5770c7aa1a300acecca6','live review pin')
    runner=OWN/'sat_only_gadget_kissat.py';need(sha(runner)=='fd05c03210c7d815ec81f0f3a292ef5d7eeb92f4380c8f4c5fde18d10aaa6bcd','runner pin');runtime=load(runner,'rootor_review_runner')
    cases=[]
    for row in h['cases']:
        n=row['inputs'];k=row['gate_count'];parent=PEER/'gadget-live-v1'/f'gadget{n}-generic{k}-live.cnf';child=PEER/'gadget-live-rootor-v1'/(row['name']+'.cnf')
        need(sha(child)==row['cnf_sha256'] and sha(child.with_suffix('.json'))==row['metadata_sha256'] and sha(parent)==row['parent_cnf_sha256'],'case pins')
        unit=delta(parent,child,h['producer_sha256']);need([unit]==row['root_or_unit'],'reported unit')
        pp=PEER/'gadget-live-controls-v2'/f'gadget{n}-positive{k+1}-live.cnf';cp=PEER/'gadget-live-rootor-controls'/f'gadget{n}-positive{k+1}-live-rootor.cnf'
        delta(pp,cp,h['producer_sha256'])
        vp=runtime.CONFIG[n]['validator'][0];need(sha(vp)==runtime.CONFIG[n]['validator'][1],'validator pin');v=load(vp,f'rootor_validator{n}')
        model=PEER/'gadget-live-rootor-controls'/f'gadget{n}-positive.model.stdout'
        report=v.validate(cp.read_bytes(),cp.with_suffix('.json').read_bytes(),model.read_bytes(),sha(cp),sha(cp.with_suffix('.json')))
        need(report==json.loads((PEER/'gadget-live-rootor-controls'/f'gadget{n}-positive.validation.json').read_text()),'full report replay')
        need(report['gadget']['gates'][-1][0]=='or' and report['full11_gate_count']==22 and report['full11_verified_inputs']==2048 and report['verified_inputs']==1<<n,'positive actual OR/full truth')
        folder=OUT/f'positive-{n}';folder.mkdir();shutil.copyfile(model,folder/'solver.stdout');save(folder/'validation.json',report)
        try:runtime.accept_report(report,SimpleNamespace(gadget=n,cnf_sha256=sha(cp),metadata_sha256=sha(cp.with_suffix('.json')),output=folder),runtime.CONFIG[n])
        except ValueError as error:need(str(error)=='gadget or full21 gate limit exceeded','overlimit reason')
        else:raise AssertionError('22gate control accepted')
        command=[sys.executable,'-B',str(runner),str(child),str(OUT/f'never-launched-{n}'),'--gadget',str(n),'--cnf-sha256',sha(child),'--metadata-sha256',sha(child.with_suffix('.json')),'--preflight-only']
        with (OUT/f'preflight-{n}.stdout').open('xb') as stdout,(OUT/f'preflight-{n}.stderr').open('xb') as stderr:r=subprocess.run(command,cwd=OWN,stdout=stdout,stderr=stderr,timeout=5)
        need(r.returncode==0 and not (OUT/f'never-launched-{n}').exists(),'preflight only')
        save(OUT/f'preflight-{n}.execution.json',{'command':command,'exit_code':r.returncode,'solver_launched':False})
        cases.append({**row,'exact_unit_and_unchanged_metadata':'PASS','positive_complete_model_and_full_truth':'PASS_22GATES_REJECTED','runner_preflight':'PASS'})
    result={'status':'PASS_ROOT_OR_CANDIDATE_ONLY_DELTA_AND_COMPATIBILITY','S02_handoff_sha256':sha(hp),'live_review_handoff_sha256':sha(live),'producer_sha256':h['producer_sha256'],'source_sha256':sha(Path(__file__)),'artifact_bindings':bindings,'cases':cases,'gate_kernel_assignments_checked':64,'solver_launched':False,'elapsed_seconds':time.monotonic()-t,'scope':'One negative last-op unit per child selects OR. No OR-root WLOG/completeness claim. Future SAT must pass unchanged full validator; SAT-only UNSAT remains UNKNOWN. No global/shard/Lean result.'}
    save(OUT/'review.json',result);print(json.dumps({k:result[k] for k in ['status','S02_handoff_sha256','producer_sha256','gate_kernel_assignments_checked','elapsed_seconds']}))

if __name__=='__main__':main()
