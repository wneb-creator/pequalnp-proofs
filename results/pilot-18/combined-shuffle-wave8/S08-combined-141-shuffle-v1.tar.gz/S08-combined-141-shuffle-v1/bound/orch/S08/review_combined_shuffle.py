from pathlib import Path
import sys,json,difflib,subprocess,resource,time,traceback
sys.path.insert(0,str(Path(__file__).parent))
from wave5_delivery_helpers import Review,R,W,sha
v=Review('combined-141-shuffle-review');O=v.O;M=R/'orch/MAIN/all-negative-shuffle-v1';S=R/'orch/S02/shuffle-engine-v1';B=R/'orch/MAIN/all-negative-engine-v1'
pack=R/'orch/S05/triangle589-best3-direct21-v1/direct-seeds.txt';wrapper=S/'stochastic_tools_shuffle.py';oldwrapper=R/'lean-setup/stochastic/stochastic_tools.py'
sourcepin='6717226e0fb1e0ed3a260e23aa0f162d2f8b3591a425798528194878d5f32bf7';binarypin='e67583803d64fcf68d585e58833eb2b9c13b246d420385e2cf0dd8cbac8eac6d';wrapperpin='99c843f9a450c37c1c283d00684015269bd2eca091da3488e8d5811b6d934944'
executions=[]
def run(name,cmd,expect=0,cpu=10,mem=512,wall=15):
 def limits():
  resource.setrlimit(resource.RLIMIT_CPU,(cpu,cpu+1));resource.setrlimit(resource.RLIMIT_AS,(mem*1024**2,mem*1024**2))
 start=time.monotonic()
 with (O/(name+'.stdout')).open('xb') as a,(O/(name+'.stderr')).open('xb') as b:p=subprocess.run([str(x) for x in cmd],cwd=O,stdout=a,stderr=b,timeout=wall,preexec_fn=limits)
 row={'name':name,'command':[str(x) for x in cmd],'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-start,'cpu_cap':cpu,'wall_cap':wall,'AS_MiB':mem};executions.append(row)
 (O/'executions.json').write_text(json.dumps(executions,indent=2)+'\n');assert p.returncode==expect,row
def changes(a,b):
 a=a.splitlines(True);b=b.splitlines(True)
 return [(tag,a[i:j],b[k:l]) for tag,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes() if tag!='equal']
def main():
 for p in sorted(M.rglob('*')):
  if p.is_file():v.bind(p,Path('snapshot/main')/p.relative_to(M))
 for p in [B/'circuit_anneal_allnegative.cpp',B/'circuit_anneal_allnegative',B/'parent.cpp',S/'circuit_anneal_shuffle.cpp',R/'orch/S02/shuffle-engine-handoff.json',S/'review.json',pack,pack.with_suffix('.json'),oldwrapper,R/'validate_raw_candidate.py',R/'lean-setup/validate_sat_candidate.py',R/'orch/S08/all-negative-engine-review/review.json']:v.bind(p)
 src=(M/'circuit_anneal_allnegative_shuffle.cpp').read_text();base=(B/'circuit_anneal_allnegative.cpp').read_text();parent=(B/'parent.cpp').read_text();s02=(S/'circuit_anneal_shuffle.cpp').read_text()
 assert sha(src.encode())==sourcepin and sha((M/'circuit_anneal_allnegative_shuffle').read_bytes())==binarypin
 assert sha(base.encode())=='18efdd149487dfee83693dd0781a17316ba0fda9d68c43c6c70c73f96a77250b'
 assert changes(base,src)==changes(parent,s02) and len(changes(base,src))==6
 assert ''.join(difflib.unified_diff(base.splitlines(True),src.splitlines(True),fromfile='circuit_anneal_allnegative.cpp',tofile='circuit_anneal_allnegative_shuffle.cpp'))==(M/'source.diff').read_text()
 assert base[base.index('std::vector<int> fitness_rows'):base.index(' Circuit remove_gate')]==src[src.index('std::vector<int> fitness_rows'):src.index(' Circuit remove_gate')]
 h=json.loads(v.bind(R/'orch/S02/shuffle-wrapper-handoff.json','wrapper-handoff.json'))
 for key in ['wrapper','review','diff','derivation','controls','test_source']:
  row=h[key];b=v.bind(Path(row['path']),Path('snapshot/wrapper')/Path(row['path']).name);assert len(b)==row['bytes'] and sha(b)==row['sha256']
 for row in h['control_artifacts']:
  p=Path(row['path']);b=v.bind(p,Path('snapshot/S02-controls')/p.relative_to(S));assert len(b)==row['bytes'] and sha(b)==row['sha256']
 assert sha(wrapper.read_bytes())==wrapperpin
 deriv=json.loads((S/'stochastic_tools_shuffle.derivation.json').read_text());new=oldwrapper.read_text()
 for r in deriv['changes']:assert new.count(r['before'])==1;new=new.replace(r['before'],r['after'])
 assert new==wrapper.read_text() and len(deriv['changes'])==2
 assert ''.join(difflib.unified_diff(oldwrapper.read_text().splitlines(True),new.splitlines(True),fromfile='stochastic_tools.py',tofile='stochastic_tools_shuffle.py'))==(S/'stochastic_tools_shuffle.diff').read_text()
 controls=json.loads((M/'control-results.json').read_text());assert controls['source_sha256']==sourcepin and controls['binary_sha256']==binarypin
 for n,row in controls['controls'].items():assert row['exit']==0 and row['stdout_sha256']==sha((M/(n+'.stdout')).read_bytes()) and (M/(n+'.stderr')).stat().st_size==row['stderr_bytes']==0
 mainshuffle=json.loads((M/'test_shuffle.stdout').read_text());assert mainshuffle['intermediate_comparisons']==43008000 and mainshuffle['output_comparisons']==2048000 and mainshuffle['malformed_rejections']==5
 assert b'comparisons=2048000' in (M/'test_vectors.stdout').read_bytes()
 cpp=O/'independent_shuffle.cpp'
 cpp.write_text(r'''#define main reviewed_engine_main
#include "snapshot/main/circuit_anneal_allnegative_shuffle.cpp"
#undef main
#include <bitset>
#include <set>
using Table=std::bitset<2048>;
void need(bool b,const char*s){if(!b)throw std::runtime_error(s);}
std::array<Table,34> tables(const Circuit& c){
 std::array<Table,34> w{};
 for(int i=0;i<11;++i)for(int x=0;x<2048;++x)w[i].set(x,(x>>i)&1);
 w[12].set();
 for(int g=0;g<21;++g){auto t=c.gates[g];need(t.op==0||t.op==1,"op");need(t.a>=0&&t.b>=0&&t.a<13+g&&t.b<13+g,"wires");w[13+g]=t.op?(w[t.a]&w[t.b]):(w[t.a]|w[t.b]);}
 return w;
}
int main(int argc,char**argv)try{
 need(argc==2,"pack");Engine e(508134234),repeat(508134234);std::mt19937_64 rng(508134235);auto fixtures=load_direct21(argv[1]);
 for(int trial=0;trial<256;++trial){Circuit c{};for(int g=0;g<21;++g){auto&t=c.gates[g];t={int(rng()%2),int(rng()%(13+g)),int(rng()%(13+g))};if(trial%4==0&&g)t.a=12+g;if(trial%4==1)t.a=t.b=int(rng()%13);if(trial%4==2)t.a=11+int(rng()%2);}c.output=trial%34;fixtures.push_back(c);}
 uint64_t intermediates=0,outputs=0,vectorbits=0;int moved=0;
 for(auto c:fixtures){auto immutable=c;std::array<int,21> map{},map2{};auto q=e.shuffle_topological(c,&map),again=repeat.shuffle_topological(c,&map2);need(same_circuit(c,immutable),"source mutation");need(map==map2&&same_circuit(q,again),"determinism");
  std::set<int> range(map.begin(),map.end());need(range.size()==21&&*range.begin()==0&&*range.rbegin()==20,"bijection");bool changed=false;
  auto wire=[&](int w){return w<13?w:13+map[w-13];};
  for(int old=0;old<21;++old){auto a=c.gates[old],b=q.gates[map[old]];int x=wire(a.a),y=wire(a.b);if(x>y)std::swap(x,y);need(b.op==a.op&&b.a==x&&b.b==y&&b.a<=b.b&&b.b<13+map[old],"rename");changed|=map[old]!=old;}
  moved+=changed;need(q.output==wire(c.output),"output mapping");auto a=tables(c),b=tables(q);
  for(int g=0;g<21;++g){need(a[13+g]==b[13+map[g]],"intermediate truth");intermediates+=2048;}
  need(a[c.output]==b[q.output],"output truth");outputs+=2048;
  std::set<int> live;std::vector<int> todo{c.output};while(!todo.empty()){int w=todo.back();todo.pop_back();if(w>=13&&live.insert(w).second){todo.push_back(c.gates[w-13].a);todo.push_back(c.gates[w-13].b);}}
  auto l=e.live(q);for(int old=0;old<21;++old)need(l[map[old]]==bool(live.count(13+old)),"independent live map");
  for(int weight:{1,8,16}){auto x=e.score(c,weight),y=e.score(q,weight);need(x.fn==y.fn&&x.fp==y.fp&&x.live==y.live&&x.energy==y.energy,"score preservation");}
  auto bits=e.vector_eval(q.gates.data(),21,q.output);auto rows=fitness_rows();for(size_t i=0;i<rows.size();++i){need(bool((bits.words[i/64]>>(i%64))&1)==b[q.output][rows[i]],"141 bits");++vectorbits;}
 }
 int rejected=0;for(int kind=0;kind<10;++kind){auto bad=fixtures.back();switch(kind){case 0:bad.output=-1;break;case 1:bad.output=34;break;case 2:bad.gates[0].op=-1;break;case 3:bad.gates[0].op=2;break;case 4:bad.gates[0].a=-1;break;case 5:bad.gates[0].b=-1;break;case 6:bad.gates[5].a=18;break;case 7:bad.gates[5].b=18;break;case 8:bad.gates[20].a=34;break;default:bad.gates[20].b=34;}
  try{e.shuffle_topological(bad);}catch(const std::runtime_error&){++rejected;}}
 need(rejected==10&&moved>0,"negative or diversity controls");
 std::cout<<"PASS independent full_truth_bitsets circuits="<<fixtures.size()<<" intermediate_bits="<<intermediates<<" output_bits="<<outputs<<" fitness_bits="<<vectorbits<<" malformed_rejections="<<rejected<<" nonidentity="<<moved<<"\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}
''')
 run('independent-build',['g++','-std=c++17','-O1','-g','-fsanitize=undefined','-fno-sanitize-recover=all','-Wall','-Wextra','-Werror',cpp,'-o',O/'independent_shuffle'],cpu=25,mem=1536,wall=35)
 run('independent-controls',[O/'independent_shuffle',pack])
 # Three finite controls cross three restart boundaries, not a production search.
 for label,wrap,binary,flag in [('parent',oldwrapper,B/'circuit_anneal_allnegative',False),('off',wrapper,M/'circuit_anneal_allnegative_shuffle',False),('on',wrapper,M/'circuit_anneal_allnegative_shuffle',True)]:
  cmd=[sys.executable,'-B',wrap,'run','--engine',binary,'--pack',pack,'--output',O/label,'--seed','134236','--seconds','1','--iterations','301','--restart','100','--weight','8','--abort-file',O/'absent-abort']
  if flag:cmd.append('--shuffle-restarts')
  run('combined-'+label,cmd)
  r=json.loads((O/label/'result.json').read_text());c=json.loads((O/label/'engine-result.json').read_text())
  assert r['status']=='UNKNOWN' and r['engine_exit']==0 and c['iterations']==301 and c['restarts']==3
  assert r['command'].count('--shuffle-restarts')==int(flag)
  assert c['fitness_domain']=='16_edges_plus_all_125_negative_inputs'
  for n,row in r['logs'].items():assert row=={'bytes':(O/label/n).stat().st_size,'sha256':sha((O/label/n).read_bytes())}
 def clean(p):
  d=json.loads(p.read_text());d.pop('elapsed_seconds',None);return d
 a=O/'parent';b=O/'off';names={p.name for p in a.glob('engine-result.json*')};assert names=={p.name for p in b.glob('engine-result.json*')}
 for n in names:assert clean(a/n)==clean(b/n),n
 # Validate every integrated enabled snapshot independently on all2048 inputs.
 edges=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
 checks=[]
 for p in (O/'on').glob('engine-result.json*'):
  c=json.loads(p.read_text());fn=fp=0
  for x in range(2048):
   w=[bool(x>>i&1) for i in range(11)]+[False,True]
   for op,i,j in c['gates']:w.append((w[i] and w[j]) if op=='and' else (w[i] or w[j]))
   want=any(x>>i&1 and x>>j&1 for i,j in edges);fn+=want and x.bit_count()==2 and not w[c['output']];fp+=not want and w[c['output']]
  assert (fn,fp)==(c['false_negatives'],c['false_positives']);checks.append({'file':p.name,'inputs':2048,'edge_FN':fn,'full_FP':fp})
 # Actual new wrapper must retain the independent-validator rejection with the flag enabled.
 fixture=R/'orch/S08/all-negative-engine-review/fake_claimed_candidate.py';v.bind(fixture)
 run('new-wrapper-forgery',[sys.executable,'-B',wrapper,'run','--engine',fixture,'--pack',pack,'--output',O/'forgery','--seed','134236','--seconds','1','--iterations','1','--restart','100','--weight','8','--abort-file',O/'absent-abort','--shuffle-restarts'],expect=1)
 forged=json.loads((O/'forgery/result.json').read_text());assert forged['status']=='ERROR' and forged['validator_exit']==2 and forged['engine_exit']==10
 assert 'Target mismatch at input 21' in (O/'forgery/validation.stdout.txt').read_text()
 # Bind the separately supplied actual combined controls, if finished, without any runtime reads.
 combined=M/'integrated-wrapper-controls.json'
 if combined.exists():v.bind(combined,'integrated-wrapper-controls.json')
 v.checks={'source_sha256':sourcepin,'binary_sha256':binarypin,'wrapper_sha256':wrapperpin,'exact_engine_port_blocks':6,'exact_wrapper_insertions':2,'Bits141_scoring_identical':True,'main_shuffle_intermediate_controls':43008000,'main_shuffle_output_controls':2048000,'main_random_scalar_controls':2048000,'independent_control_stdout':(O/'independent-controls.stdout').read_text().strip(),'default_off_result_and_all_snapshots_equal_except_clock':len(names),'own_combined_three_runs_iterations_each':301,'restarts_each':3,'enabled_snapshots_independent_full2048':checks,'enabled_wrapper_forged_candidate_rejected':True,'proof_of_preservation':'Validated earlier-wire DAG implies a ready gate always exists. Each emitted gate maps only already emitted dependencies; bijective renaming preserves AND/OR functions by induction, all21 slots including dead gates, raw/constants and output. All141 masks, mutation, scalar acceptance, validator and lifecycle are unchanged.','caveats':['Flag is recorded in command argv, not as a separate result boolean.','Generic --self-test exits before shuffle; the dedicated shuffle controls exercise it.','Disabled mode consumes no shuffle RNG draws; enabled mode deliberately changes search trajectory. No performance guarantee.','No exact21/full Lean claim; main owns resource admission and production.']}
 for path,row in list(v.bindings.items()):assert sha(Path(path).read_bytes())==row['sha256'],path
 for p in sorted(O.rglob('*')):
  if p.is_file() and 'snapshot' not in p.relative_to(O).parts:v.bind(p)
 v.bind(Path(__file__))
 v.finish('PASS_COMBINED_141_SHUFFLE_ENGINE_AND_WRAPPER','Source6717226e...32bf7/binarye6758380...eac6d/wrapper99c843f9...34944 PASS. ExactsixS02engineblocks/twowrapperinsertions; Bits141/scoring/acceptance/lifecycle unchanged. Main43,008,000intermediate+2,048,000shuffleoutputs+2,048,000scalarcontrols bound. OwnUBSan264DAG fullbitsettruth11,354,112intermediate/540,672output/37,224fitnessbits+10malformed PASS; three301iterationcombinedcontrols cross3restarts, defaultoffallresults/snapshots equalexceptclock, enabledfull2048snapshotchecks andactualwrapperforgedcandidate rejectionPASS. Flags inargv; no speed/exact21/Leanclaim. Mainmayadmit boundedshufflepilot usingexactpins, noS08production. Fullsource/snapshots/commands/logs retained.')
if __name__=='__main__':
 try:main()
 except BaseException:
  (O/'reviewer-failure.txt').write_text(traceback.format_exc());raise
