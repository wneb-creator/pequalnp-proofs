#!/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3
from pathlib import Path
import sys
assert "--shuffle-restarts" in sys.argv
out=Path(sys.argv[sys.argv.index("--output")+1])
out.write_bytes(Path(__file__).with_name("forged-inexact-source.json").read_bytes())
raise SystemExit(10)
