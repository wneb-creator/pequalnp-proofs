#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <csignal>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>

// Candidate heuristic only. No failed run implies UNSAT or shard exhaustion.
namespace {
constexpr int N=11, OFFSET=13, GATES=21;
constexpr std::array<std::array<int,2>,16> EDGES={{{0,9},{0,10},{1,4},{1,8},
 {2,5},{2,10},{3,6},{3,7},{4,8},{4,10},{5,8},{5,9},{6,7},{6,10},{7,9},{8,9}}};
struct Gate { int op,a,b; }; // 1=AND, 0=OR; constants are wires 11 and 12.
struct Circuit { std::array<Gate,GATES> gates; int output; };
struct Baseline { std::array<Gate,22> gates; int output; };
struct Score { int fn,fp,live; double energy; };
volatile std::sig_atomic_t stopped=0;
void stop(int) { stopped=1; }
bool target(int mask) {
 for (auto e:EDGES) if ((mask&(1<<e[0])) && (mask&(1<<e[1]))) return true;
 return false;
}
bool scalar(const Gate* gates,int count,int output,int mask) {
 std::array<bool,35> w{};
 for(int i=0;i<N;++i) w[i]=(mask&(1<<i))!=0;
 w[12]=true;
 for(int g=0;g<count;++g) {
  auto t=gates[g];
  if(t.op<0 || t.op>1 || t.a<0 || t.b<0 || t.a>=OFFSET+g || t.b>=OFFSET+g)
   throw std::runtime_error("Invalid gate in scalar evaluation");
  w[OFFSET+g]=t.op ? w[t.a]&&w[t.b] : w[t.a]||w[t.b];
 }
 if(output<0 || output>=OFFSET+count) throw std::runtime_error("Invalid output");
 return w[output];
}
bool scalar_with_alias(const Baseline& b,int removed,int alias,int mask) {
 std::array<bool,35> w{};
 for(int i=0;i<N;++i)w[i]=(mask&(1<<i))!=0;
 w[12]=true;
 for(int g=0;g<22;++g) {
  auto t=b.gates[g];
  w[OFFSET+g]=g==removed?w[alias]:(t.op?w[t.a]&&w[t.b]:w[t.a]||w[t.b]);
 }
 return w[b.output];
}
std::vector<int> fitness_rows() {
 std::vector<int> rows;
 for(auto e:EDGES) rows.push_back((1<<e[0])|(1<<e[1]));
 for(int mask=0;mask<(1<<N);++mask) if(!target(mask)) {
  rows.push_back(mask);
 }
 if(rows.size()!=141) throw std::runtime_error("Unexpected fitness-domain size");
 return rows;
}
// Three-word truth vector: 16 minimal positives and all 125 negatives.
struct Bits {
 std::array<uint64_t,3> words{};
 static Bits one(size_t i) {
  if(i>=192)throw std::runtime_error("Bit index out of range");
  Bits b;b.words[i/64]=uint64_t(1)<<(i%64);return b;
 }
 Bits& operator|=(const Bits& b) { for(size_t i=0;i<3;++i)words[i]|=b.words[i];return *this; }
 int count() const { int n=0;for(auto w:words)n+=__builtin_popcountll(w);return n; }
 friend Bits operator&(Bits a,const Bits& b) { for(size_t i=0;i<3;++i)a.words[i]&=b.words[i];return a; }
 friend Bits operator|(Bits a,const Bits& b) { a|=b;return a; }
 friend Bits operator^(Bits a,const Bits& b) { for(size_t i=0;i<3;++i)a.words[i]^=b.words[i];return a; }
 friend Bits operator~(Bits a) { for(auto& w:a.words)w=~w;return a; }
 friend bool operator==(const Bits& a,const Bits& b) { return a.words==b.words; }
 friend bool operator!=(const Bits& a,const Bits& b) { return !(a==b); }
};
struct Engine {
 std::mt19937_64 rng;
 std::array<Bits,OFFSET> inputs{};
 Bits positives{};
 Bits all{};
 explicit Engine(uint64_t seed):rng(seed) {
  auto rows=fitness_rows();
  for(size_t i=0;i<rows.size();++i) {all|=Bits::one(i);if(i<16)positives|=Bits::one(i);}
  for(int v=0;v<N;++v) for(size_t i=0;i<rows.size();++i)
   if(rows[i]&(1<<v)) inputs[v]|=Bits::one(i);
  inputs[12]=all;
 }
 int pick(int n) { if(n<=0)throw std::runtime_error("Empty random choice"); return int(rng()%uint64_t(n)); }
 double uniform() { return double(rng()>>11)*0x1.0p-53; }
 Bits vector_eval(const Gate* gates,int count,int output) const {
  std::array<Bits,35> w{};std::copy(inputs.begin(),inputs.end(),w.begin());
  for(int g=0;g<count;++g) {
   auto t=gates[g];w[OFFSET+g]=t.op ? w[t.a]&w[t.b] : w[t.a]|w[t.b];
  }
  return w[output];
 }
 std::array<bool,GATES> live(const Circuit& c) const {
  std::array<bool,GATES> bits{};
  if(c.output>=OFFSET) bits[c.output-OFFSET]=true;
  for(int g=GATES-1;g>=0;--g) if(bits[g])
   for(int a:{c.gates[g].a,c.gates[g].b}) if(a>=OFFSET) bits[a-OFFSET]=true;
  return bits;
 }
 Score score(const Circuit& c,int weight) const {
  Bits v=vector_eval(c.gates.data(),GATES,c.output);
  int fn=(positives&~v).count();
  int fp=((all^positives)&v).count();
  auto bits=live(c);int count=std::count(bits.begin(),bits.end(),true);
  // A strict fractional tie-breaker; one fitness error always dominates it.
  return {fn,fp,count,double(weight*fn+fp)+0.02*count};
 }
 Circuit remove_gate(const Baseline& b,int remove,int alias) const {
  Circuit c{};
  auto map=[&](int wire) {
   if(wire==OFFSET+remove) wire=alias;
   if(wire>OFFSET+remove)--wire;
   return wire;
  };
  int j=0;
  for(int g=0;g<22;++g) if(g!=remove) {
   Gate t=b.gates[g];t.a=map(t.a);t.b=map(t.b);
   if(t.a>t.b)std::swap(t.a,t.b);
   c.gates[j++]=t;
  }
  c.output=map(b.output);return c;
 }
 Circuit initial(const Baseline& b) {
  int g=pick(22),mode=pick(3);
  int alias=mode==0?b.gates[g].a:mode==1?b.gates[g].b:pick(OFFSET+g);
  return remove_gate(b,g,alias);
 }
 Circuit shuffle_topological(const Circuit& source,std::array<int,GATES>* map_out=nullptr) {
  if(source.output<0 || source.output>=OFFSET+GATES)
   throw std::runtime_error("Invalid shuffle output");
  for(int g=0;g<GATES;++g) {
   auto t=source.gates[g];
   if(t.op<0 || t.op>1 || t.a<0 || t.b<0 || t.a>=OFFSET+g || t.b>=OFFSET+g)
    throw std::runtime_error("Invalid shuffle gate");
  }
  Circuit result{};std::array<bool,GATES> emitted{};
  std::array<int,GATES> old_to_new{};old_to_new.fill(-1);
  for(int next=0;next<GATES;++next) {
   std::array<int,GATES> available{};int count=0;
   for(int old=0;old<GATES;++old) if(!emitted[old]) {
    auto t=source.gates[old];
    if((t.a<OFFSET || emitted[t.a-OFFSET]) &&
       (t.b<OFFSET || emitted[t.b-OFFSET])) available[count++]=old;
   }
   if(!count)throw std::runtime_error("No available shuffle gate");
   int old=available[pick(count)];auto t=source.gates[old];
   auto map=[&](int wire) {return wire<OFFSET?wire:OFFSET+old_to_new[wire-OFFSET];};
   t.a=map(t.a);t.b=map(t.b);
   if(t.a>t.b)std::swap(t.a,t.b);
   result.gates[next]=t;old_to_new[old]=next;emitted[old]=true;
  }
  result.output=source.output<OFFSET?source.output:OFFSET+old_to_new[source.output-OFFSET];
  if(map_out)*map_out=old_to_new;
  return result;
 }
 Circuit mutate(const Circuit& c) {
  Circuit next=c;int move=pick(100);
  if(move<4) {next.output=pick(OFFSET+GATES);return next;}
  int g=pick(GATES);
  if(pick(5)!=0) {
   auto bits=live(c);std::array<int,GATES> candidates{};int count=0;
   for(int i=0;i<GATES;++i)if(bits[i])candidates[count++]=i;
   if(count)g=candidates[pick(count)];
  }
  auto &t=next.gates[g];
  if(move<17)t.op^=1;
  else if(move<52)t.a=pick(OFFSET+g);
  else if(move<87)t.b=pick(OFFSET+g);
  else {t.op=pick(2);t.a=pick(OFFSET+g);t.b=pick(OFFSET+g);}
  if(t.a>t.b)std::swap(t.a,t.b);
  return next;
 }
};
std::vector<Baseline> load(const std::string& path) {
 std::ifstream f(path);std::string magic;int version=0,count=0;
 if(!(f>>magic>>version>>count) || magic!="COVER_ANNEAL" || version!=1 || count<1 || count>10000)
  throw std::runtime_error("Invalid seed pack header");
 std::vector<Baseline> all(count);
 for(auto& b:all) {
  int gates=0;if(!(f>>gates>>b.output) || gates!=22)throw std::runtime_error("Invalid baseline header");
  for(auto& t:b.gates)if(!(f>>t.op>>t.a>>t.b))throw std::runtime_error("Truncated baseline");
  for(int x=0;x<(1<<N);++x)if(scalar(b.gates.data(),22,b.output,x)!=target(x))
   throw std::runtime_error("Seed baseline fails all-input validation");
 }
 std::string extra;if(f>>extra)throw std::runtime_error("Trailing pack content");
 return all;
}

// Direct21 packs contain inexact search seeds, never accepted witnesses.
bool is_direct21_pack(const std::string& path) {
 std::ifstream f(path);std::string magic;
 if(!(f>>magic))throw std::runtime_error("Unreadable seed pack");
 return magic=="COVER_ANNEAL_DIRECT21";
}
std::vector<Circuit> load_direct21(const std::string& path) {
 std::ifstream f(path);std::string magic;int version=0,count=0;
 if(!(f>>magic>>version>>count) || magic!="COVER_ANNEAL_DIRECT21" || version!=1 || count<1 || count>10000)
  throw std::runtime_error("Invalid direct21 pack header");
 std::vector<Circuit> all(count);
 for(auto& c:all) {
  int gates=0,want_fn=0,want_fp=0;uint64_t want_truth=0;
  if(!(f>>gates>>c.output>>want_fn>>want_fp>>want_truth) || gates!=GATES ||
      c.output<0 || c.output>=OFFSET+GATES || want_fn<0 || want_fn>2048 || want_fp<0 || want_fp>2048)
   throw std::runtime_error("Invalid direct21 seed header");
  for(int g=0;g<GATES;++g) {
   auto& t=c.gates[g];
   if(!(f>>t.op>>t.a>>t.b) || t.op<0 || t.op>1 || t.a<0 || t.a>t.b || t.b>=OFFSET+g)
    throw std::runtime_error("Invalid canonical direct21 gate");
  }
  int fn=0,fp=0;uint64_t truth=14695981039346656037ULL;
  for(int x=0;x<(1<<N);++x) {
   bool value=scalar(c.gates.data(),GATES,c.output,x),wanted=target(x);
   fn+=wanted&&!value;fp+=!wanted&&value;
   truth=(truth^uint64_t(value))*1099511628211ULL;
  }
  if(fn!=want_fn || fp!=want_fp || truth!=want_truth)
   throw std::runtime_error("Direct21 full truth-table metadata mismatch");
 }
 std::string extra;if(f>>extra)throw std::runtime_error("Trailing direct21 content");
 return all;
}
bool same_circuit(const Circuit& a,const Circuit& b) {
 if(a.output!=b.output)return false;
 for(int g=0;g<GATES;++g)
  if(a.gates[g].op!=b.gates[g].op || a.gates[g].a!=b.gates[g].a || a.gates[g].b!=b.gates[g].b)return false;
 return true;
}
void check_direct21_scalar_vector(const Circuit& c,const Engine& engine) {
 Bits bits{};auto rows=fitness_rows();
 for(int x=0;x<(1<<N);++x) {
  bool value=scalar(c.gates.data(),GATES,c.output,x);
  for(size_t i=0;i<rows.size();++i)if(rows[i]==x && value)bits|=Bits::one(i);
 }
 if(bits!=engine.vector_eval(c.gates.data(),GATES,c.output))
  throw std::runtime_error("Direct21 scalar/vector mismatch");
 int fn=0,fp=0;
 for(int x:rows) {
  bool value=scalar(c.gates.data(),GATES,c.output,x);
  fn+=target(x)&&!value;fp+=!target(x)&&value;
 }
 auto score=engine.score(c,4);
 if(score.fn!=fn || score.fp!=fp)throw std::runtime_error("Scalar score mismatch");
 for(int g=0;g<GATES;++g)if(c.gates[g].a>c.gates[g].b)
  throw std::runtime_error("Direct21 noncanonical mutation");
}

void write_result(const std::string& path,const Circuit& c,const Score& score,
 const std::string& status,uint64_t seed,uint64_t iterations,int restarts,double elapsed,int weight) {
 std::ofstream f(path);if(!f)throw std::runtime_error("Cannot write result");
 f<<"{\n  \"status\": \""<<status<<"\",\n  \"inputs\": 11,\n  \"candidate_only\": true,\n"
  <<"  \"assigned_shard_exhaustion\": false,\n  \"requires_Lean_proof\": true,\n"
  <<"  \"seed\": "<<seed<<",\n  \"iterations\": "<<iterations<<",\n  \"restarts\": "<<restarts
  <<",\n  \"elapsed_seconds\": "<<elapsed<<",\n  \"positive_weight\": "<<weight
   <<",\n  \"fitness_domain\": \"16_edges_plus_all_125_negative_inputs\""
  <<",\n  \"false_negatives\": "<<score.fn<<",\n  \"false_positives\": "<<score.fp
  <<",\n  \"live_gates\": "<<score.live<<",\n  \"size\": 21,\n  \"output\": "<<c.output
  <<",\n  \"gate_wire_offset\": 13,\n  \"gates\": [\n";
 for(int g=0;g<GATES;++g) {auto t=c.gates[g];f<<"    [\""<<(t.op?"and":"or")<<"\", "<<t.a<<", "<<t.b<<"]"<<(g+1<GATES?",":"")<<"\n";}
 f<<"  ]\n}\n";if(!f)throw std::runtime_error("Result write failed");
}
}
int main(int argc,char** argv) try {
 std::string pack,output;uint64_t seed=1342,max_iterations=100000000;
 double seconds=60;int period=100000,weight=4;bool selftest=false,shuffle_restarts=false;
 for(int i=1;i<argc;++i) {
  std::string arg=argv[i];
  if(arg=="--help") {
   std::cout<<"circuit_anneal --pack FILE --output NEWFILE [--seed N] [--seconds N] [--iterations N] [--restart N] [--weight 1..16] [--self-test] [--shuffle-restarts]\nPacks: COVER_ANNEAL exact22 or COVER_ANNEAL_DIRECT21 validated direct starts.\n";return 0;
  }
  if(arg=="--self-test") {selftest=true;continue;}
  if(arg=="--shuffle-restarts") {shuffle_restarts=true;continue;}
  if(i+1==argc)throw std::runtime_error("Missing option value");
  std::string value=argv[++i];
  if(arg=="--pack")pack=value;else if(arg=="--output")output=value;
  else if(arg=="--seed")seed=std::stoull(value);else if(arg=="--seconds")seconds=std::stod(value);
  else if(arg=="--iterations")max_iterations=std::stoull(value);
  else if(arg=="--restart")period=std::stoi(value);else if(arg=="--weight")weight=std::stoi(value);
  else throw std::runtime_error("Unknown option");
 }
 if(pack.empty() || output.empty() || !std::isfinite(seconds) || seconds<=0 || seconds>3600 ||
    max_iterations==0 || max_iterations>1000000000000ULL || period<100 || period>10000000 || weight<1 || weight>16)
  throw std::runtime_error("Invalid bounded configuration");
 {std::ifstream existing(output);if(existing.good())throw std::runtime_error("Output must be fresh");}
 std::signal(SIGINT,stop);std::signal(SIGTERM,stop);
 auto start=std::chrono::steady_clock::now();
 auto elapsed=[&](){return std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();};
 bool direct21=is_direct21_pack(pack);
 auto baselines=direct21?std::vector<Baseline>{}:load(pack);
 auto direct_seeds=direct21?load_direct21(pack):std::vector<Circuit>{};
 Engine engine(seed);
 auto fresh=[&]() -> Circuit {
  if(direct21)return direct_seeds[engine.pick(int(direct_seeds.size()))];
  return engine.initial(baselines[engine.pick(int(baselines.size()))]);
 };
 if(selftest && direct21) {
  uint64_t mutations=0,starts=0;
  for(const auto& c:direct_seeds) {
   check_direct21_scalar_vector(c,engine);
   for(int k=0;k<128;++k) {
    auto next=engine.mutate(c);check_direct21_scalar_vector(next,engine);++mutations;
   }
  }
  for(size_t i=0;i<direct_seeds.size()*32;++i) {
   Circuit c=fresh();
   if(std::none_of(direct_seeds.begin(),direct_seeds.end(),[&](const Circuit& seed){return same_circuit(c,seed);}))
    throw std::runtime_error("Direct21 restart changed or deleted a gate");
   check_direct21_scalar_vector(c,engine);++starts;
  }
  std::ofstream f(output);
  if(!f)throw std::runtime_error("Cannot write direct21 self-test result");
  f<<"{\"status\":\"SELF_TEST_DIRECT21_PASS\",\"seeds\":"<<direct_seeds.size()
   <<",\"full_truth_inputs\":2048,\"direct_start_controls\":"<<starts
   <<",\"mutation_controls\":"<<mutations<<"}\n";
  if(!f)throw std::runtime_error("Direct21 self-test result write failed");
  std::cout<<"SELF_TEST_DIRECT21_PASS seeds="<<direct_seeds.size()<<" starts="<<starts<<" mutations="<<mutations<<"\n";
  return 0;
 }

 if(selftest) {
  uint64_t comparisons=0,mutations=0;
  for(const auto& b:baselines) {
   if(engine.vector_eval(b.gates.data(),22,b.output)!=engine.positives)throw std::runtime_error("Baseline vector mismatch");
   for(int g=0;g<22;++g)for(int alias:{b.gates[g].a,b.gates[g].b,0,11,12}) {
    Circuit c=engine.remove_gate(b,g,alias);auto rows=fitness_rows();Bits scalar_bits{};
    for(size_t i=0;i<rows.size();++i) {
     bool value=scalar(c.gates.data(),GATES,c.output,rows[i]);
     if(value!=scalar_with_alias(b,g,alias,rows[i]))throw std::runtime_error("Deletion renumbering mismatch");
     if(value)scalar_bits|=Bits::one(i);
    }
    if(scalar_bits!=engine.vector_eval(c.gates.data(),GATES,c.output))throw std::runtime_error("Deletion/vector mismatch");
    ++comparisons;
    c=engine.mutate(c);scalar_bits=Bits{};
    for(size_t i=0;i<rows.size();++i)if(scalar(c.gates.data(),GATES,c.output,rows[i]))scalar_bits|=Bits::one(i);
    if(scalar_bits!=engine.vector_eval(c.gates.data(),GATES,c.output))throw std::runtime_error("Mutation/vector mismatch");
    ++mutations;
   }
  }
  std::ofstream f(output);f<<"{\"status\":\"SELF_TEST_PASS\",\"baselines\":"<<baselines.size()<<",\"deletion_controls\":"<<comparisons<<",\"mutation_controls\":"<<mutations<<"}\n";
  std::cout<<"SELF_TEST_PASS baselines="<<baselines.size()<<" deletion_controls="<<comparisons<<" mutation_controls="<<mutations<<"\n";return 0;
 }
 Circuit current=fresh();
 if(shuffle_restarts)current=engine.shuffle_topological(current);
 Score current_score=engine.score(current,weight);Circuit best=current;Score best_score=current_score;
 uint64_t iteration=0;int restarts=0,best_serial=0;std::string status="UNKNOWN";
 auto snapshot=[&]() {
  std::string path=output+".best-"+std::to_string(best_serial++)+".json";
  write_result(path,best,best_score,"BEST_PARTIAL_NOT_A_WITNESS",seed,iteration,restarts,elapsed(),weight);
  std::cout<<"BEST_FILE "<<path<<"\n"<<std::flush;
 };
 snapshot();
 for(;iteration<max_iterations;++iteration) {
  if((iteration&1023)==0 && (stopped || elapsed()>=seconds)) {status=stopped?"ABORTED":"UNKNOWN";break;}
  if(current_score.fn==0 && current_score.fp==0) {
   for(int x=0;x<(1<<N);++x)if(scalar(current.gates.data(),GATES,current.output,x)!=target(x))
    throw std::runtime_error("Fitness candidate fails full truth table");
   best=current;best_score=current_score;status="CANDIDATE_NEEDS_INDEPENDENT_VALIDATION";break;
  }
  if(iteration && iteration%uint64_t(period)==0) {
   ++restarts;
   if(engine.pick(4)==0) {
    current=best;
    if(shuffle_restarts)current=engine.shuffle_topological(current);
    for(int k=0;k<3;++k)current=engine.mutate(current);
   } else {
    current=fresh();
    if(shuffle_restarts)current=engine.shuffle_topological(current);
   }
   current_score=engine.score(current,weight);
   if(current_score.energy<best_score.energy) {best=current;best_score=current_score;snapshot();}
   if(current_score.fn==0 && current_score.fp==0) {best=current;best_score=current_score;break;}
  }
  Circuit next=engine.mutate(current);Score next_score=engine.score(next,weight);
  double fraction=double(iteration%uint64_t(period))/period;
  double temperature=0.08+2.5*(1.0-fraction)*(1.0-fraction);
  double delta=next_score.energy-current_score.energy;
  if(delta<=0 || engine.uniform()<std::exp(-delta/temperature)) {current=next;current_score=next_score;}
  if(current_score.energy<best_score.energy) {
   best=current;best_score=current_score;
   snapshot();
  }
 }
 // A candidate on the final permitted mutation must not be lost at the limit.
 if(best_score.fn==0 && best_score.fp==0) {
  for(int x=0;x<(1<<N);++x)if(scalar(best.gates.data(),GATES,best.output,x)!=target(x))
   throw std::runtime_error("Best candidate fails full truth table");
  status="CANDIDATE_NEEDS_INDEPENDENT_VALIDATION";
 }
 write_result(output,best,best_score,status,seed,iteration,restarts,elapsed(),weight);
 if(status=="CANDIDATE_NEEDS_INDEPENDENT_VALIDATION")std::cout<<output<<"\n";
 else std::cout<<status<<" iterations="<<iteration<<" restarts="<<restarts<<" elapsed="<<elapsed()<<"\n";
 return status=="CANDIDATE_NEEDS_INDEPENDENT_VALIDATION"?10:0;
} catch(const std::exception& error) {std::cerr<<"ERROR: "<<error.what()<<"\n";return 2;}
