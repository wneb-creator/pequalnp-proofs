#define main engine_program_main
#include "circuit_anneal_allnegative_shuffle.cpp"
#undef main
int main() {
 Engine e(134230);auto rows=fitness_rows();
 std::array<bool,2048> seen{};int neg=0,pos=0;
 for(int x:rows) {if(seen[x])return 1;seen[x]=true;if(target(x))++pos;else++neg;}
 if(pos!=16 || neg!=125)return 2;
 for(int x=0;x<2048;++x)if(!target(x) && !seen[x])return 3;
 uint64_t checks=0;
 for(int trial=0;trial<1000;++trial) {
  Circuit c{};
  for(int g=0;g<GATES;++g) {
   auto& t=c.gates[g];t.op=e.pick(2);t.a=e.pick(OFFSET+g);t.b=e.pick(OFFSET+g);
   if(t.a>t.b)std::swap(t.a,t.b);
  }
  c.output=trial==0?11:trial==1?12:e.pick(OFFSET+GATES);
  auto s=e.score(c,4);int fn=0,fp=0;
  for(int x=0;x<2048;++x) {
   bool v=scalar(c.gates.data(),GATES,c.output,x);
   if(!target(x) && v)++fp;
   if(target(x) && __builtin_popcount(unsigned(x))==2 && !v)++fn;
   ++checks;
  }
  if(s.fn!=fn || s.fp!=fp)return 4;
  if(trial==0 && (fn!=16 || fp!=0))return 5;
  if(trial==1 && (fn!=0 || fp!=125))return 6;
  check_direct21_scalar_vector(c,e);
 }
 std::cout<<"PASS independent full2048 scalar comparisons="<<checks<<" random circuits=1000 negative rows=125 positive edges=16\n";
 return 0;
}
