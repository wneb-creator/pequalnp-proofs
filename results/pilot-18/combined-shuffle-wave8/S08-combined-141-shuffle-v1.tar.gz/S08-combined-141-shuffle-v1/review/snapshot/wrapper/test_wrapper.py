"""Finite wrapper forwarding and unchanged validator/lifecycle controls; no production."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S02/shuffle-engine-v1'
OUT=HERE/'wrapper-controls';OUT.mkdir(exist_ok=False)
NEW=HERE/'stochastic_tools_shuffle.py';PARENT=ROOT/'lean-setup/stochastic/stochastic_tools.py'
ENGINE=HERE/'circuit_anneal_shuffle';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
derivation=json.loads(NEW.with_suffix('.derivation.json').read_text())
assert sha(PARENT)==derivation['parent_sha256'] and sha(NEW)==derivation['source_sha256']
for kind in ['legacy','direct']:
    pack=OUT/(kind+'.pack');pack.write_bytes((HERE/'cli-controls'/pack.name).read_bytes())
    pack.with_suffix('.json').write_text(json.dumps({'pack_sha256':sha(pack),'kind':'finite_wrapper_control_fixture'})+'\n')
commands=[];results={}


def run(label,wrapper,kind='direct',extra=(),engine=ENGINE,abort=None,expected=0):
    output=OUT/label
    argv=[sys.executable,'-B',str(wrapper),'run','--engine',str(engine),'--pack',str(OUT/(kind+'.pack')),
          '--output',str(output),'--seed','134230','--seconds','1','--iterations','1001',
          '--restart','100','--weight','16','--abort-file',str(abort or OUT/'absent-abort'),*extra]
    start=time.monotonic()
    with (OUT/(label+'.stdout')).open('x') as a,(OUT/(label+'.stderr')).open('x') as b:
        proc=subprocess.run(argv,stdout=a,stderr=b,timeout=10)
    assert proc.returncode==expected
    report=json.loads((output/'result.json').read_text());results[label]=report
    commands.append({'label':label,'argv':argv,'exit_code':proc.returncode,'wall_seconds':time.monotonic()-start,
                     'status':report['status'],'report_sha256':sha(output/'result.json')})
    return report


default_checks=[]
for kind in ['legacy','direct']:
    old=run(kind+'-parent',PARENT,kind)
    off=run(kind+'-default-off',NEW,kind)
    enabled=run(kind+'-enabled',NEW,kind,extra=['--shuffle-restarts'])
    assert old['status']==off['status']==enabled['status']=='UNKNOWN'
    assert '--shuffle-restarts' not in old['command'] and '--shuffle-restarts' not in off['command']
    assert enabled['command'][-1]=='--shuffle-restarts' and enabled['command'].count('--shuffle-restarts')==1
    same=lambda x:{k:v for k,v in x.items() if k!='elapsed_seconds'}
    left=json.loads((OUT/(kind+'-parent')/'engine-result.json').read_text())
    right=json.loads((OUT/(kind+'-default-off')/'engine-result.json').read_text())
    assert same(left)==same(right)
    oldfiles=sorted((OUT/(kind+'-parent')).glob('engine-result.json.best-*.json'))
    newfiles=sorted((OUT/(kind+'-default-off')).glob('engine-result.json.best-*.json'))
    assert len(oldfiles)==len(newfiles)
    for a,b in zip(oldfiles,newfiles):assert same(json.loads(a.read_text()))==same(json.loads(b.read_text()))
    default_checks.append({'pack':kind,'result_and_all_snapshots_equal_except_clock':True,'snapshots':len(oldfiles)})

abort=OUT/'abort-sentinel';abort.write_text('finite control\n')
stopped=run('abort-before-start',NEW,extra=['--shuffle-restarts'],abort=abort)
assert stopped['status']=='ABORTED_BEFORE_START' and 'engine_exit' not in stopped
assert not (OUT/'abort-before-start/engine-result.json').exists()

# This deliberately lying toy engine must be rejected by the unchanged real
# all2048 validator. It is a finite negative control, never a production engine.
fixture=OUT/'forged-inexact-source.json'
data=json.loads((ROOT/'orch/S02/triangle589-best3-source.json').read_text())
data['status']='CANDIDATE_NEEDS_INDEPENDENT_VALIDATION'
fixture.write_text(json.dumps(data)+'\n')
fake=OUT/'forged-engine.py'
fake.write_text('#!'+sys.executable+'\nfrom pathlib import Path\nimport sys\n'
                'assert "--shuffle-restarts" in sys.argv\n'
                'out=Path(sys.argv[sys.argv.index("--output")+1])\n'
                'out.write_bytes(Path(__file__).with_name("forged-inexact-source.json").read_bytes())\n'
                'raise SystemExit(10)\n')
fake.chmod(0o755)
failed=run('forged-candidate-rejected',NEW,extra=['--shuffle-restarts'],engine=fake,expected=1)
assert failed['status']=='ERROR' and failed['validator_exit']==2 and failed['error_type']=='ValueError'
assert (OUT/'forged-candidate-rejected/validation.stdout.txt').exists()
report={'verdict':'PASS_WRAPPER_FORWARDING_DEFAULT_OFF_ABORT_AND_REAL_VALIDATOR_REJECTION',
        'source_sha256':sha(NEW),'parent_sha256':sha(PARENT),'engine_sha256':sha(ENGINE),
        'default_off_controls':default_checks,'commands':commands,
        'optional_flag_forwarded_once':True,'abort_before_start_pass':True,
        'forged_inexact_candidate_rejected_by_unchanged_real_validator':True,
        'scope':'Finite1001iteration controls and toy negative control only; no production worker or solver.',
        'production_launched':False}
(OUT/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'verdict':report['verdict'],'source_sha256':sha(NEW),'review_sha256':sha(OUT/'review.json'),
                  'commands':len(commands)}))
