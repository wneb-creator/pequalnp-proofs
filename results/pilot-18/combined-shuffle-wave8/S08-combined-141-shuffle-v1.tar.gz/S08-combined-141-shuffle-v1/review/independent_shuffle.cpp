#define main reviewed_engine_main
#include "snapshot/main/circuit_anneal_allnegative_shuffle.cpp"
#undef main
#include <bitset>
#include <set>
using Table=std::bitset<2048>;
void need(bool b,const char*s){if(!b)throw std::runtime_error(s);}
std::array<Table,34> tables(const Circuit& c){
 std::array<Table,34> w{};
 for(int i=0;i<11;++i)for(int x=0;x<2048;++x)w[i].set(x,(x>>i)&1);
 w[12].set();
 for(int g=0;g<21;++g){auto t=c.gates[g];need(t.op==0||t.op==1,"op");need(t.a>=0&&t.b>=0&&t.a<13+g&&t.b<13+g,"wires");w[13+g]=t.op?(w[t.a]&w[t.b]):(w[t.a]|w[t.b]);}
 return w;
}
int main(int argc,char**argv)try{
 need(argc==2,"pack");Engine e(508134234),repeat(508134234);std::mt19937_64 rng(508134235);auto fixtures=load_direct21(argv[1]);
 for(int trial=0;trial<256;++trial){Circuit c{};for(int g=0;g<21;++g){auto&t=c.gates[g];t={int(rng()%2),int(rng()%(13+g)),int(rng()%(13+g))};if(trial%4==0&&g)t.a=12+g;if(trial%4==1)t.a=t.b=int(rng()%13);if(trial%4==2)t.a=11+int(rng()%2);}c.output=trial%34;fixtures.push_back(c);}
 uint64_t intermediates=0,outputs=0,vectorbits=0;int moved=0;
 for(auto c:fixtures){auto immutable=c;std::array<int,21> map{},map2{};auto q=e.shuffle_topological(c,&map),again=repeat.shuffle_topological(c,&map2);need(same_circuit(c,immutable),"source mutation");need(map==map2&&same_circuit(q,again),"determinism");
  std::set<int> range(map.begin(),map.end());need(range.size()==21&&*range.begin()==0&&*range.rbegin()==20,"bijection");bool changed=false;
  auto wire=[&](int w){return w<13?w:13+map[w-13];};
  for(int old=0;old<21;++old){auto a=c.gates[old],b=q.gates[map[old]];int x=wire(a.a),y=wire(a.b);if(x>y)std::swap(x,y);need(b.op==a.op&&b.a==x&&b.b==y&&b.a<=b.b&&b.b<13+map[old],"rename");changed|=map[old]!=old;}
  moved+=changed;need(q.output==wire(c.output),"output mapping");auto a=tables(c),b=tables(q);
  for(int g=0;g<21;++g){need(a[13+g]==b[13+map[g]],"intermediate truth");intermediates+=2048;}
  need(a[c.output]==b[q.output],"output truth");outputs+=2048;
  std::set<int> live;std::vector<int> todo{c.output};while(!todo.empty()){int w=todo.back();todo.pop_back();if(w>=13&&live.insert(w).second){todo.push_back(c.gates[w-13].a);todo.push_back(c.gates[w-13].b);}}
  auto l=e.live(q);for(int old=0;old<21;++old)need(l[map[old]]==bool(live.count(13+old)),"independent live map");
  for(int weight:{1,8,16}){auto x=e.score(c,weight),y=e.score(q,weight);need(x.fn==y.fn&&x.fp==y.fp&&x.live==y.live&&x.energy==y.energy,"score preservation");}
  auto bits=e.vector_eval(q.gates.data(),21,q.output);auto rows=fitness_rows();for(size_t i=0;i<rows.size();++i){need(bool((bits.words[i/64]>>(i%64))&1)==b[q.output][rows[i]],"141 bits");++vectorbits;}
 }
 int rejected=0;for(int kind=0;kind<10;++kind){auto bad=fixtures.back();switch(kind){case 0:bad.output=-1;break;case 1:bad.output=34;break;case 2:bad.gates[0].op=-1;break;case 3:bad.gates[0].op=2;break;case 4:bad.gates[0].a=-1;break;case 5:bad.gates[0].b=-1;break;case 6:bad.gates[5].a=18;break;case 7:bad.gates[5].b=18;break;case 8:bad.gates[20].a=34;break;default:bad.gates[20].b=34;}
  try{e.shuffle_topological(bad);}catch(const std::runtime_error&){++rejected;}}
 need(rejected==10&&moved>0,"negative or diversity controls");
 std::cout<<"PASS independent full_truth_bitsets circuits="<<fixtures.size()<<" intermediate_bits="<<intermediates<<" output_bits="<<outputs<<" fitness_bits="<<vectorbits<<" malformed_rejections="<<rejected<<" nonidentity="<<moved<<"\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}
