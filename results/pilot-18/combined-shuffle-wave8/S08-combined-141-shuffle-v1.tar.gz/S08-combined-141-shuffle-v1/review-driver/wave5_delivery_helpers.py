from pathlib import Path,PurePosixPath
import datetime,fcntl,hashlib,io,json,re,tarfile
R=Path('/tmp/oec/pequalnp-pilot-18');W=Path('/workspace/pequalnp-proofs');S08=R/'orch/S08'
sha=lambda b:hashlib.sha256(b).hexdigest()
def digestfile(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
class Review:
 def __init__(self,name):self.O=S08/name;self.O.mkdir(exist_ok=True);self.bindings={};self.checks={}
 def bind(self,p,save=None):
  b=p.read_bytes();self.bindings[str(p)]={'bytes':len(b),'sha256':sha(b)}
  if save:
   q=self.O/save;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
  return b
 def tar(self,p,prefix,manifest_name,field='path'):
  raw=self.bind(p);data={}
  with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tf:
   for m in tf.getmembers():
    n=PurePosixPath(m.name);assert m.isfile() and not n.is_absolute() and '..' not in n.parts
    rel=str(n.relative_to(prefix)) if prefix else str(n)
    assert rel not in data;data[rel]=tf.extractfile(m).read();assert len(data[rel])==m.size
  manifest=json.loads(data[manifest_name]);rows=manifest['files'];assert len({x[field] for x in rows})==len(rows)
  assert set(data)=={x[field] for x in rows}|{manifest_name}
  for row in rows:assert len(data[row[field]])==row['bytes'] and sha(data[row[field]])==row['sha256']
  assert all(not raw.startswith(b'\x7fELF') for raw in data.values())
  self.scan(data)
  return data,manifest
 def scan(self,data):
  patterns={'github_token':rb'\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})\b','private_key':rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----','aws_key':rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b','bearer':rb'(?i)authorization\s*[:=]\s*[\x22\x27]?bearer\s+[A-Za-z0-9._-]{20,}'}
  hits=[{'path':name,'rule':rule} for name,raw in data.items() for rule,pat in patterns.items() if re.search(pat,raw)]
  assert not hits,hits
 def finish(self,verdict,summary):
  result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':verdict,'bindings':self.bindings,'checks':self.checks,'scope':summary,'no_solver_Lean_production_gitwrite':True}
  p=self.O/'review.json';p.write_text(json.dumps(result,indent=2)+'\n');h=sha(p.read_bytes());print(json.dumps({'verdict':verdict,'review':str(p),'sha256':h},indent=2),flush=True)
  msg=f'\n- {result["utc"]} — S08 {verdict}: {p.relative_to(R)} SHA{h}. {summary}\n'
  with (R/'orch-notes.lock').open('a') as lock:
   fcntl.flock(lock,fcntl.LOCK_EX)
   with (W/'results/orch/NOTES.md').open('a') as f:f.write(msg)
   fcntl.flock(lock,fcntl.LOCK_UN)
  with (W/'results/orch/lemmas/S08-integration-review.md').open('a') as f:f.write(msg)
  return result
