from pathlib import Path
import collections,functools,hashlib,itertools,json,time
O=Path(__file__).resolve().parent;I=O.parent/'S01';start=time.monotonic()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
hand=json.loads((I/'copy-cover-closure-handoff.json').read_text());bindings={}
for item in hand['files']:
 p=Path(item['path']);assert p.is_relative_to(I) and not p.is_symlink() and p.stat().st_size==item['bytes'] and sha(p)==item['sha256'];bindings[p.name]=item['sha256']
data=json.loads((I/'terminal-copy-birth-filter.json').read_text())
assert data['source_sha256']==sha(I/'filter_terminal_copy_birth.py') and data['proof_sha256']==sha(I/'support-copy-cover-bound.md') and data['terminal_extension_sha256']==sha(I/'support-copy-terminal-charge.md')
for item in data['inputs']:assert sha(Path(item['path']))==item['sha256']
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)];EM=[(1<<u)|(1<<v) for u,v in E];N=[{v if u==x else u for u,v in E if x in(u,v)} for x in range(11)]
ind=[s for s in range(2048) if not any(s&e==e for e in EM)]
def V(s):return {v for v in range(11) if s>>v&1}
def cn(s):return set.intersection(*(N[v] for v in V(s))) if s else set(range(11))
@functools.lru_cache(None)
def tau_residual(s):
 rem=2047^s;return rem.bit_count()-max(x.bit_count() for x in ind if x&~rem==0)
pairs=list(itertools.permutations(range(3),2));relations=[]
for bits in range(64):
 rel={e for j,e in enumerate(pairs) if bits>>j&1}
 if any((b,a) in rel for a,b in rel) or any((a,c) not in rel for a,b in rel for bb,c in rel if b==bb):continue
 relations.append(rel)
assert len(relations)==19 and {tuple(sorted(r)) for r in relations}==set(map(lambda a:tuple(map(tuple,a)),data['relations']))
forest=json.loads((O/'forest-sinks-review.json').read_text());mixed=json.loads((I/'mixed-triple-census.json').read_text())
expected={0:{tuple(r['supports']) for r in forest['forest_results'][0]['families'] if not r['excluded']},1:{tuple(r['supports']) for r in mixed['results'][0]['families'] if r['position_witness'] is not None}}
checked=0;bonus_needed=0;allrows=[];tightrows=[];downward=0
for group in data['results']:
 r=group['summary']['r'];assert {tuple(row['supports']) for row in group['families']}==expected[r]
 for row in group['families']:
  S=row['supports'];sets=list(map(V,S));C=list(map(cn,S));tau=list(map(tau_residual,S))
  assert tau==row['residual_cover_numbers'] and sum(not c for c in C)==r
  L=[len(s)+sum(set(e).isdisjoint(s) for e in E)+t-1 for s,t in zip(sets,tau)]
  assert L==row['individual_costs'] and row['owners']==[next(iter(c)) if c else None for c in C]
  H={e for e in E if any(set(e).isdisjoint(s) for s in sets)}
  assert H==set(map(tuple,row['original_forced_edges']))
  cases={tuple(map(tuple,q['relation'])):q for q in row['ancestry_checks']};assert len(cases)==19
  feasible=[];checkrows=[]
  for rel in relations:
   checked+=1;old=cases[tuple(sorted(rel))];nonterminal={a for a,b in rel};T=set(range(3))-nonterminal
   if any(not C[i] for i in nonterminal):assert old['rejected']=='NO_COMMON_SOURCE';continue
   K=H|{tuple(sorted((u,v))) for i in nonterminal for u in C[i] for v in sets[i]}
   charge=max([0]+[tau[i]-int(i in T) for i in range(3)])
   strict=bool(K) and all(all(tuple(sorted((u,v))) not in K for u in C[i] for v in sets[i]) for i in T)
   lower=len(K)+len(T)+max(charge,int(strict))
   assert old['terminals']==sorted(T) and old['required_birth_edges']==[list(e) for e in sorted(K)]
   assert old['copy_OR_lower_bound']==charge and old['guarded_terminal_bonus']==int(strict) and old['prefix_gate_lower_bound']==lower and old['excluded']==(lower>17)
   bonus_needed+=int(strict and charge==0)
   if lower<=17:feasible.append(tuple(sorted(rel)))
   checkrows.append([sum(1<<j for j,e in enumerate(pairs) if e in rel),len(K),len(T),charge,int(strict),lower])
  assert set(feasible)==set(tuple(map(tuple,r)) for r in row['feasible_ancestry_relations'])
  reason='DIRECT_COPY_BIRTH'
  if feasible:
   assert feasible==[()] and max(L)<=15
   tight=[i for i in range(3) if L[i]==15];assert tight==row['tight_outputs'] and tight
   allowed=[len(V(u))<=1 or all(V(u)<=sets[i] or bool(cn(u)-sets[i]) for i in tight) for u in range(2048)]
   for u in range(2048):
    if allowed[u]:
     for v in V(u):assert allowed[u^(1<<v)];downward+=1
   tests=[]
   for j,s in enumerate(S):
    opts=[u for u in range(2048) if u&~s==0 and allowed[u]]
    decomp=[[u,v] for u in opts for v in opts if u<=v and u|v==s]
    assert row['operand_tests'][j]=={'output':j,'allowed_pairs':decomp}
    tests.append({'output':j,'pairs':decomp})
   intersection=functools.reduce(int.__and__,[S[i] for i in tight],2047)
   failed=[i for i in tight if not allowed[S[i]&~intersection]]
   assert row['shared_core_intersection']==intersection and row['failed_shared_outputs']==failed
   assert any(not t['pairs'] for t in tests) or failed
   tightrows.append({'supports':S,'tight':tight,'operand_tests':tests,'shared_failed':failed});reason='ANTICHAIN_TIGHT'
  allrows.append({'r':r,'supports':S,'tau':tau,'relation_checks':checkrows,'surviving_relations':feasible,'exclusion':reason})
assert checked==20102 and len(tightrows)==7
assert {tuple(d['supports']) for d in tightrows}=={(289,562,768),(385,562,768),(416,562,768),(417,530,768),(417,546,768),(417,560,768),(417,562,768)}
assert sum(d['r']==1 and d['exclusion']=='DIRECT_COPY_BIRTH' for d in allrows)==800
assert sum(d['r']==0 and d['exclusion']=='DIRECT_COPY_BIRTH' for d in allrows)==251
print(json.dumps({'finite':'PASS','orders':checked,'r1_direct':800,'r0_direct':251,'r0_tight':7,'strict_bonus_needed':bonus_needed}),flush=True)

# Reuse saved concrete DAGs, not the producer's randomized generator. Evaluate
# all2048 assignments and route each proper nonempty intermediate output.
controlsource=O/'selected-birth-controls-v3.json';actual=json.loads(controlsource.read_text())['actual_DAG_controls']
ALL=(1<<2048)-1;raw=[sum(1<<x for x in range(2048) if x>>v&1) for v in range(11)]+[0,ALL];F=functools.reduce(int.__or__,(raw[u]&raw[v] for u,v in E),0)
incident=[sum(1<<j for j,e in enumerate(E) if mask&EM[j]) for mask in range(2048)];covers=sorted(range(2048),key=lambda x:(x.bit_count(),x))
@functools.lru_cache(None)
def tau_mask(mask):return next(s.bit_count() for s in covers if mask&~incident[s]==0)
rootchecks=[];totalcomp=0;redirections=[]
for ci,control in enumerate(actual):
 gates=control['gates'];val=list(raw);supp=[1<<v for v in range(11)]+[0,2047];anc=[set() for _ in range(13)];copies=set()
 for g,(op,a,b) in enumerate(gates):
  w=13+g;z=val[a]&val[b] if op=='and' else val[a]|val[b];s=sum(1<<v for v in range(11) if z>>(1<<v)&1)
  val.append(z);supp.append(s);anc.append(anc[a]|anc[b]|{w})
  if op=='and':assert supp[a] and supp[b] and not z&(ALL^F)
  elif s in (supp[a],supp[b]):copies.add(w)
  if not s or s==2047:continue
  parents={};retained=set();todo=[w]
  while todo:
   q=todo.pop()
   if q in retained:continue
   retained.add(q)
   if q<13:continue
   opq,a,b=gates[q-13]
   pp=([b] if supp[b].bit_count()==1 else [a]) if opq=='and' else [a,b]
   if opq=='and':assert supp[pp[0]].bit_count()==1
   parents[q]=pp;todo.extend(pp)
  assert 12 not in retained
  rawmask=sum(1<<v for v in retained if v<11);accepted=sum(1<<j for j,e in enumerate(EM) if z>>e&1)
  H=accepted&~incident[s];assert H&~incident[rawmask&~s]==0
  low={q for q in retained if supp[q].bit_count()<=1};adj={q:set() for q in low}
  for q,pp in parents.items():
   for a in pp:
    if q in low and a in low:adj[q].add(a);adj[a].add(q)
  components=[];unused=set(low)
  while unused:
   todo=[min(unused)];comp=set()
   while todo:
    q=todo.pop()
    if q not in comp:comp.add(q);todo.extend(adj[q]-comp)
   unused-=comp;components.append(comp)
  attachment_sets=[]
  for comp in components:
   ni=sum(q<13 for q in comp);no=sum(q>=13 and gates[q-13][0]=='or' for q in comp)
   assert ni<=no+1
   if any(q<11 and s>>q&1 for q in comp):continue
   attachments={q for q,pp in parents.items() if q not in low and any(a in comp for a in pp)}
   assert attachments and attachments<=copies
   assert all(supp[a]==0 for q in attachments for a in parents[q] if a in comp)
   assert all(not attachments&t for t in attachment_sets);attachment_sets.append(attachments)
  cc=len(anc[w]&copies);qsmall=sum(q>=13 and gates[q-13][0]=='or' for q in low)
  qlarge=len((retained-low)&copies)
  assert len(attachment_sets)<=qlarge and (rawmask&~s).bit_count()<=qsmall+len(attachment_sets)<=cc
  tc=tau_mask(H);assert tc<=cc
  rootchecks.append([ci,w,s,H,tc,cc,len(components),len(attachment_sets)]);totalcomp+=len(components)
 # Materialize removal of every support-copy OR, including duplicates, and
 # compare supports/birth graphs. Positive semantic equality is not assumed.
 alias={w:w for w in range(13)};newS=supp[:13];newV=list(raw);newG=[];oldB=set();newB=set()
 for g,(op,a,b) in enumerate(gates):
  w=13+g
  if op=='and':oldB|={tuple(sorted((u,v))) for u in V(supp[a]) for v in V(supp[b])}
  if w in copies:alias[w]=alias[a if supp[a]==supp[w] else b]
  else:
   aa,bb=alias[a],alias[b];alias[w]=len(newS);newG.append([op,aa,bb]);newS.append(0 if op=='and' else newS[aa]|newS[bb]);newV.append(newV[aa]&newV[bb] if op=='and' else newV[aa]|newV[bb])
   if op=='and':newB|={tuple(sorted((u,v))) for u in V(newS[aa]) for v in V(newS[bb])}
  assert newS[alias[w]]==supp[w]
 assert oldB==newB and len(newG)==len(gates)-len(copies)
 redirections.append({'control':ci,'original_gates':len(gates),'copy_ORs':len(copies),'reduced_gates':newG,'birth_edges':sorted(newB),'positive_semantic_changes':sum(newV[alias[w]]!=val[w] for w in range(13,13+len(gates)))})
assert len(redirections)==50
out={'verdict':'PASS_COPY_COVER_MATH_AND_COMPLETE_SUPPLIED_K3_R1_R0_CLOSURE','source_sha256':sha(Path(__file__)),'producer_handoff_sha256':sha(I/'copy-cover-closure-handoff.json'),'producer_bindings':bindings,'rows':allrows,'orders_checked':checked,'r1_direct_excluded':800,'r0_direct_excluded':251,'r0_antichain_tight_excluded':7,'remaining_r1':0,'remaining_r0':0,'tight_cases':tightrows,'tight_downward_checks':downward,'strict_bonus_needed_cases':bonus_needed,'actual_DAG_source_sha256':sha(controlsource),'actual_DAGs':len(actual),'proper_nonempty_outputs_checked':len(rootchecks),'nonempty_residual_outputs':sum(bool(r[3]) for r in rootchecks),'small_components_checked':totalcomp,'root_checks':rootchecks,'support_copy_redirections':redirections,'empty_support_negative_control':{'gates':[['and',0,9]],'support':0,'accepted_edge':(0,9),'tau':1,'copy_ORs':0,'shows_nonempty_support_guard_required':True},'seconds':time.monotonic()-start,'solver_run':False,'Lean_build':False,'scope':'Mathematical/finite independent review of new copy-cover and terminal-minus-one charges; all supplied800r1/258r0 triples excluded under prior reviewed17-gate productive-clean proper minimal full-cover normalization. No k4/mixed, whole-shard, CNF or Lean/global result.'}
(O/'copy-cover-closure-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['producer_bindings','rows','tight_cases','root_checks','support_copy_redirections']},indent=2))
