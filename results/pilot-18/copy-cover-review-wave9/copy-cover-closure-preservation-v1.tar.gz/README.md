# S04 independent PASS of S01 copy-cover / terminal-charge closure

New independent mathematical and finite PASS. All supplied800 k3/r1 families
are excluded directly by the copy-cover birth bound. Of258 k3/r0 families,
251 are excluded directly and seven by the prior reviewed tight-core proof.
No k4/mixed, whole-shard, actual CNF, Lean or global result is asserted.

The NONEMPTY output-support guard is essential and explicit. A clean AND
with empty support accepts an edge with no OR, furnishing the negative
control. Copy-OR redirection preserves singleton supports and AND birth
sets, NOT necessarily full Boolean functions. Terminal subtraction is at
most one per chosen cone and aggregate copy counts use MAXIMUM, not sum.
The strict-terminal bonus is needed in ZERO finite cases. Thus no unguarded
strict lemma is used in these exclusions.

All16 S01 handoff artifacts are preserved, including complete25MB/27MB
historical/new tables, producer proofs/sources/random-control outputs and
full stdout/stderr. All independent review sources, complete decisions,
50 concrete DAGs,1702 proper-output checks,10004 component checks and50
support redirections are included. No raw CNFs or executable binaries.

Extract anywhere and run python verify_manifest.py. Exact original paths,
bytes and hashes for every payload are in manifest.json. The source review
retains producer handoff absolute paths; replay in another workspace requires
mapping those ORIGINAL INPUT paths to the matching archived scratch paths
in a WORKING COPY. Do not silently rewrite the frozen evidence. Component
and finite checks use only Python standard library; no solver or Lean.

The earlier S04 birth-only proposal archive remains frozen as a historical,
weaker result. This new independent S01 review supersedes its family counts
for these suppliedr0/r1 lists; it does not retroactively declare every earlier
proposed generalization peer-reviewed. Main alone owns preservation/push.
