from pathlib import Path
import hashlib,json
H=Path('/tmp/oec/pequalnp-pilot-18/orch/S05'); R=H/'candidate134227-repair'; R.mkdir(exist_ok=False)
P=H.parent/'S04/candidate-134227'
EDGES=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
parent=(H/'triangle589_best3_internal_context.py').read_text(); parent_sha=hashlib.sha256(parent.encode()).hexdigest(); assert parent_sha=='e7b8100a8a679f4f10c59c25348a2014daad67a950909a7395f37f918f62c7e2'
records=[]
for label,name,pin,n in [('best3','best-3-pruned20.json','d616bef5ef2b3c1f523d49af2cf27eeecd63b21681afa7ece962b2f24a5f3687',20),('best1','best-1-common-subexpressions.json','9676a161801be76afd5881d8b4c8050ccff292f1a6174caae0eec083306fc61c',19)]:
    raw=(P/name).read_bytes(); assert hashlib.sha256(raw).hexdigest()==pin
    (R/(label+'-offset13.json')).write_bytes(raw); d=json.loads(raw)
    def cv(w):
        assert w not in (11,12)
        return w if w<11 else w-2
    e=dict(inputs=11,gate_wire_offset=11,gates=[[op,cv(a),cv(b)] for op,a,b in d['gates']],output=cv(d['output']),size=n,source_sha256=pin)
    assert len(e['gates'])==n
    fn=[];fp=[];intermediate=0
    for m in range(2048):
        x=[bool(m>>v&1) for v in range(11)];v=x+[False,True];w=x[:]
        for (op,a,b),(op2,c,f) in zip(d['gates'],e['gates']):
            v.append(v[a] and v[b] if op=='and' else v[a] or v[b]);w.append(w[c] and w[f] if op2=='and' else w[c] or w[f]);assert v[-1]==w[-1];intermediate+=1
        target=any(x[a] and x[b] for a,b in EDGES);actual=w[e['output']]
        expected=(target or x[9]) if label=='best1' else any(x[a] and x[b] for a,b in EDGES if (a,b)!=(2,5))
        assert actual==expected
        if target and not actual:fn.append(m)
        if actual and not target:fp.append(m)
    path=R/(label+'-offset11.json');path.write_text(json.dumps(e,indent=2)+'\n'); newpin=hashlib.sha256(path.read_bytes()).hexdigest()
    edits=[("SOURCE=H/'triangle589-best3-analysis/original-offset11.json'",'SOURCE=Path('+repr(str(path))+')'),("PIN='f3c2bacb85a0ce0e080072ad39b0a695f90affb6f7204880c44acdf496195790'",'PIN='+repr(newpin)),('resource.RLIMIT_CPU,(50,50)','resource.RLIMIT_CPU,(8,8)'),("assert len(gates)==21 and (sig[d['output']]&~target).bit_count()==5 and not target&~sig[d['output']]",f"assert len(gates)=={n} and (sig[d['output']]&~target).bit_count()=={len(fp)} and (target&~sig[d['output']]).bit_count()=={len(fn)}"),('COMPLETE_ALL21_ROOTS',f'COMPLETE_ALL{n}_ROOTS'),('for root in [28,30,15,16,14,29,31]+[r for r in range(11,32) if r not in [28,30,15,16,14,29,31]]:',f'for root in range(11,{11+n}):'),('range(32)',f'range({11+n})'),("H/'triangle589-best3-internal-exact21.json'",'Path('+repr(str(R/(label+'-internal-exact21.json')))+')'),("H/'triangle589-best3-internal-context-result.json'",'Path('+repr(str(R/(label+'-internal-result.json')))+')'),('time.monotonic()-start>45','time.monotonic()-start>5')]
    body=parent
    for a,b in edits:assert a in body,a;body=body.replace(a,b)
    script=R/(label+'-internal.py');script.write_text(body)
    records.append(dict(label=label,source_sha256=pin,normalized_sha256=newpin,gates=n,full_FN=fn,full_FP=fp,intermediate_checks=intermediate,internal_script_sha256=hashlib.sha256(script.read_bytes()).hexdigest(),edits=edits))
(R/'preparation.json').write_text(json.dumps(dict(parent_sha256=parent_sha,records=records),indent=2)+'\n')
print(json.dumps(dict(status='PASS2048_FULL_FUNCTIONS_AND_NORMALIZATION',records=[{k:v for k,v in x.items() if k!='edits'} for x in records])))
