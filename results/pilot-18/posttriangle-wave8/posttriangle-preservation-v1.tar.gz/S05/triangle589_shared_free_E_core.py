"""Core formula synthesis with one additionally shared intermediate, E free."""
from pathlib import Path
import json,hashlib,time,resource,os
from prepare_triangle589 import EDGES
H=Path('/tmp/oec/pequalnp-pilot-18/orch/S05')
def main():
    resource.setrlimit(resource.RLIMIT_CPU,(10,10));os.nice(10);start=time.monotonic()
    vertices=[1,2,4,5,8];edges=[(1,4),(1,8),(4,8),(2,5),(5,8)]
    sig={v:sum(1<<m for m in range(32) if m>>i&1) for i,v in enumerate(vertices)}
    target=sum(1<<m for m in range(32) if any(m>>vertices.index(a)&1 and m>>vertices.index(b)&1 for a,b in edges))
    sig['E']=sig[5]|sig[8]
    def synth(initial,budget,stop_on_target=True):
        expr={v:k for k,v in initial.items()};levels=[list(expr)];cost={v:0 for v in expr};pairs=0
        for n in range(1,budget+1):
            new=[]
            for a in range(n):
                b=n-1-a
                if a>b:continue
                for i,x in enumerate(levels[a]):
                    ys=levels[b][i:] if a==b else levels[b]
                    for y in ys:
                        pairs+=1
                        for op,z in [('and',x&y),('or',x|y)]:
                            if z in expr:continue
                            expr[z]=(op,expr[x],expr[y]);cost[z]=n;new.append(z)
            levels.append(new)
            if stop_on_target and target in expr:break
        return expr,cost,levels,pairs
    expr,cost,levels,pairs=synth(sig,3,False);candidates=[(v,cost[v]) for v in expr if cost[v]>0]
    results=[];found=None;complete=True
    for value,k in candidates:
        ext=dict(sig,T=value);body,body_cost,_,p=synth(ext,6-k);pairs+=p
        success=target in body
        results.append(dict(shared_truth=value,shared_cost=k,found=success,reachable_functions=len(body)))
        if success:
            gates=[];memo={}
            def op(kind,a,b):
                if a==b:return a
                key=(kind,*sorted((a,b)))
                if key not in memo:memo[key]=11+len(gates);gates.append(list(key))
                return memo[key]
            E=op('or',5,8)
            def build(e,T=None):
                if isinstance(e,int):return e
                if e=='E':return E
                if e=='T':assert T is not None;return T
                kind,a,b=e;return op(kind,build(a,T),build(b,T))
            shared=build(expr[value]);core=build(body[target],shared)
            tri1=op('and',3,op('or',6,7));tri2=op('and',6,7)
            star=op('and',10,op('or',6,op('or',4,op('or',0,2))))
            rest=op('or',tri1,op('or',tri2,star))
            nine=op('and',9,op('or',op('or',0,7),E))
            output=op('or',core,op('or',rest,nine))
            assert len(gates)<=21
            for m in range(2048):
                vals=[bool(m>>v&1) for v in range(11)]
                for kind,a,b in gates:vals.append(vals[a]&vals[b] if kind=='and' else vals[a]|vals[b])
                assert vals[output]==any(m>>a&1 and m>>b&1 for a,b in EDGES)
            d=dict(inputs=11,gate_wire_offset=11,gate_count=len(gates),gates=gates,output=output,shared_expression=expr[value],core_expression=body[target],all_2048_scalar_checks_pass=True,Lean_proof=False)
            path=H/'triangle589-free-E-shared-exact21.json'
            with path.open('x') as f:json.dump(d,f,indent=2);f.write('\n')
            found=dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),gate_count=len(gates));break
        if time.monotonic()-start>7:complete=False;break
    report=dict(status='EXACT_CANDIDATE' if found else 'NO_CANDIDATE_IN_STATED_FAMILY',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),complete=complete,source_candidates=len(candidates),checked_candidates=len(results),operation_pairs=pairs,results=results,candidate=found,elapsed_seconds=time.monotonic()-start,scope='Five-input core with free E and one extra shared intermediate computed by a <=3-operation formula; remaining core is a formula with combined fresh count<=6. Not all six-gate DAGs.')
    with (H/'triangle589-shared-free-E-core-result.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in report.items() if k!='results'}))
if __name__=='__main__':main()
