"""Fresh direct21 pack of the exact immutable best3 inexact function; no search."""
from pathlib import Path
import json,hashlib,random,time
from prepare_triangle589 import EDGES,NEG,evaluate,write,sha
R=Path('/tmp/oec/pequalnp-pilot-18');H=R/'orch/S05'
SOURCE=R/'triangle589-candidate-134226/engine-result.json.best-3.json'
PIN='9a743d5d43f651198f908fd086b3307e036697ee9d9990f5c0edfcce6ff3fe96'
def main():
    start=time.monotonic();assert sha(SOURCE)==PIN;raw=SOURCE.read_bytes();d=json.loads(raw)
    out=H/'triangle589-best3-direct21-v1';out.mkdir(exist_ok=False);(out/'source.json').write_bytes(raw)
    assert d['gate_wire_offset']==13 and d['size']==len(d['gates'])==21
    before=[evaluate(d,m) for m in range(2048)]
    target=[any(m>>a&1 and m>>b&1 for a,b in EDGES) for m in range(2048)]
    expected=[target[m] or bool(m>>2&1 and m>>4&1 and (m&129)) for m in range(2048)]
    assert [v[d['output']] for v in before]==expected
    assert [m for m in range(2048) if expected[m] and not target[m]]==[21,29,85,148,149]
    deps=[{w-13 for w in row[1:] if w>=13} for row in d['gates']]
    junk=[17,19];ancestors=set(junk);todo=junk[:]
    while todo:
        for g in deps[todo.pop()]:
            if g not in ancestors:ancestors.add(g);todo.append(g)
    orders=[];entries=[];lines=[];checks=0
    for attempt in range(32):
        rng=random.Random(589134226+attempt);done=set();order=[]
        mode=['original','reverse-ready','early-junk','late-junk'][attempt] if attempt<4 else f'random-{attempt}'
        while len(order)<21:
            ready=[g for g in range(21) if g not in done and deps[g]<=done]
            if attempt==0:g=min(ready)
            elif attempt==1:g=max(ready)
            elif attempt==2:g=min(ready,key=lambda q:(q not in ancestors,q))
            elif attempt==3:g=min(ready,key=lambda q:(q in junk,q))
            else:g=rng.choice(ready)
            order.append(g);done.add(g)
        if order in orders:continue
        orders.append(order);mapping={g:i for i,g in enumerate(order)}
        remap=lambda w:w if w<13 else 13+mapping[w-13]
        seed=dict(inputs=11,gate_wire_offset=13,size=21,gates=[[d['gates'][g][0],*sorted(remap(w) for w in d['gates'][g][1:])] for g in order],output=remap(d['output']))
        truth=14695981039346656037
        for m in range(2048):
            after=evaluate(seed,m);assert after[seed['output']]==expected[m]
            for g in range(21):assert after[13+mapping[g]]==before[m][13+g];checks+=1
            truth=((truth^after[seed['output']])*1099511628211)&((1<<64)-1)
        path=out/f'seed-{len(entries):02d}.json';write(path,seed)
        entries.append(dict(path=str(path),sha256=sha(path),order=mode,new_to_old=order,junk_gates=[mapping[g] for g in junk],full_fn=0,full_fp=5,boundary_fn=0,boundary_fp=3,truth_fnv1a64=truth,all_21_gates_live=True))
        lines.append(f'21 {seed["output"]} 0 5 {truth}');lines.extend(f'{int(op=="and")} {a} {b}' for op,a,b in seed['gates'])
        if len(entries)==8:break
    assert len(entries)==8 and len({tuple(x) for x in orders})==8
    pack=out/'direct-seeds.txt';pack.write_text('COVER_ANNEAL_DIRECT21 1 8\n'+'\n'.join(lines)+'\n')
    tokens=pack.read_text().split();assert tokens[:3]==['COVER_ANNEAL_DIRECT21','1','8'];at=3
    for entry in entries:
        size,output,fn,fp,truth=map(int,tokens[at:at+5]);at+=5;assert (size,fn,fp)==(21,0,5)
        gates=[]
        for g in range(21):
            op,a,b=map(int,tokens[at:at+3]);at+=3;assert op in [0,1] and 0<=a<=b<13+g;gates.append((op,a,b))
        h=14695981039346656037;got_fn=got_fp=0
        for m in range(2048):
            v=[bool(m&(1<<i)) for i in range(11)]+[False,True]
            for op,a,b in gates:v.append((v[a]&v[b]) if op else (v[a]|v[b]))
            assert v[output]==expected[m];got_fn+=target[m] and not v[output];got_fp+=not target[m] and v[output]
            h=((h^v[output])*1099511628211)&((1<<64)-1)
        assert (got_fn,got_fp,h)==(fn,fp,truth)
    assert at==len(tokens) and SOURCE.read_bytes()==raw
    metadata=dict(kind='inexact_positive21_best3_direct_seed',candidate_only=True,assigned_shard_exhaustion=False,requires_Lean_proof=True,production_launched=False,count=8,pack_sha256=sha(pack),source_sha256=PIN,preparer_sha256=sha(Path(__file__)),engine_source_sha256='e1a686c19d09439595cdfbf89baf42ff5d1dbfff8949e505b53b999d683ec077',engine_binary_sha256='cace36645bc4a5c827f5a221965ccdef78c554e6d940d69645da292be6c0b51a',wrapper_sha256='1e6f24c16faf2948c0aec5e4c300f9114d3e331c5894f191c9e0e7607f8afe8b',raw_validator_sha256='d244bfc58d60560041c5890592f3c2de90905c78fcd058f691b27e7785131401',exact_function='F OR (x2 AND x4 AND (x0 OR x7))',all_16_positive_edges_explicitly_pass=all(expected[(1<<a)|(1<<b)] for a,b in EDGES),full_false_positive_masks=[21,29,85,148,149],boundary_false_positive_masks=[29,85,149],intermediate_comparisons=checks,decoded_input_checks=2048*len(entries),seeds=entries,elapsed_seconds=time.monotonic()-start)
    write(out/'direct-seeds.json',metadata)
    print(json.dumps({k:metadata[k] for k in ['count','pack_sha256','full_false_positive_masks','boundary_false_positive_masks','intermediate_comparisons','decoded_input_checks','elapsed_seconds']}))
if __name__=='__main__':main()
