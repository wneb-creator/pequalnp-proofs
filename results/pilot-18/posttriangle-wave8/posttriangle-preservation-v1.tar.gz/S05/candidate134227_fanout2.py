"""Bounded two-operation selective-fanout repair using full 2048-bit contexts.

For each original wire, redirect any nonempty subset of its uses to one
expression over original wires. Original cones are cloned when required.
This is a local finite family, not arbitrary resynthesis.
"""
from pathlib import Path
from itertools import combinations
import argparse,hashlib,json,time,resource,os

H=Path('/tmp/oec/pequalnp-pilot-18/orch/S05')
EDGES=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
ONES=(1<<2048)-1
TARGET=sum(1<<m for m in range(2048) if any(m>>a&1 and m>>b&1 for a,b in EDGES))
RAW=[sum(1<<m for m in range(2048) if m>>v&1) for v in range(11)]

def values(d):
    v=RAW[:]
    for op,a,b in d['gates']:v.append(v[a]&v[b] if op=='and' else v[a]|v[b])
    return v

def context(d,ports,value):
    v=RAW[:]
    for i,(op,a,b) in enumerate(d['gates']):
        x=value if (i,0) in ports else v[a]
        y=value if (i,1) in ports else v[b]
        v.append(x&y if op=='and' else x|y)
    return value if (-1,0) in ports else v[d['output']]

def materialize(d,ports,expr):
    gates=[];cache={};oldcache={};newcache={}
    def mk(op,a,b):
        if a==b:return a
        key=(op,*sorted((a,b)))
        if key not in cache:cache[key]=11+len(gates);gates.append(list(key))
        return cache[key]
    def old(w):
        if w<11:return w
        if w not in oldcache:
            op,a,b=d['gates'][w-11];oldcache[w]=mk(op,old(a),old(b))
        return oldcache[w]
    def ex(e):
        if isinstance(e,int):return old(e)
        op,a,b=e;return mk(op,ex(a),ex(b))
    def new(w):
        if w<11:return w
        if w not in newcache:
            i=w-11;op,a,b=d['gates'][i]
            x=ex(expr) if (i,0) in ports else new(a)
            y=ex(expr) if (i,1) in ports else new(b)
            newcache[w]=mk(op,x,y)
        return newcache[w]
    output=ex(expr) if (-1,0) in ports else new(d['output'])
    # Remove nodes materialized in a branch later discarded by idempotence.
    live=set()
    def visit(w):
        if w<11 or w in live:return
        live.add(w);_,a,b=gates[w-11];visit(a);visit(b)
    visit(output);mapping={i:i for i in range(11)};out=[]
    for i,g in enumerate(gates):
        w=11+i
        if w in live:
            op,a,b=g;mapping[w]=11+len(out);out.append([op,mapping[a],mapping[b]])
    return dict(inputs=11,gate_wire_offset=11,size=len(out),gates=out,output=mapping[output],candidate_only=True)

def scalar_check(d,target=TARGET):
    for m in range(2048):
        v=[bool(m>>i&1) for i in range(11)]
        for op,a,b in d['gates']:v.append(v[a] and v[b] if op=='and' else v[a] or v[b])
        assert v[d['output']]==bool(target>>m&1)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--label',required=True,choices=['best1','best3']);args=ap.parse_args()
    os.nice(10);resource.setrlimit(resource.RLIMIT_CPU,(8,8));start=time.monotonic()
    R=H/'candidate134227-repair';p=R/(args.label+'-offset11.json');raw=p.read_bytes();d=json.loads(raw);v=values(d)
    expressions=[(w,x) for w,x in enumerate(v)]
    for a,b in combinations(range(len(v)),2):
        expressions.append((('and',a,b),v[a]&v[b]));expressions.append((('or',a,b),v[a]|v[b]))
    first=expressions[:]
    for expr,x in first:
        if isinstance(expr,int):continue
        for w,y in enumerate(v):
            expressions.append((("and",expr,w),x&y));expressions.append((("or",expr,w),x|y))
    uses=[[] for _ in v]
    for i,(_,a,b) in enumerate(d['gates']):uses[a].append((i,0));uses[b].append((i,1))
    uses[d['output']].append((-1,0))
    records=[];checks=0;matches=0;candidate=None;min_exact=None;status='COMPLETE'
    controls=[]
    try:
        for w,ports in enumerate(uses):
            if not ports:continue
            eligible=0;subsets=0
            for mask in range(1,1<<len(ports)):
                selected={ports[i] for i in range(len(ports)) if mask>>i&1};subsets+=1
                low=context(d,selected,0);high=context(d,selected,ONES)
                assert not low&~high
                # All original-wire aliases recover original semantics, including selective uses.
                assert context(d,selected,v[w])==v[d['output']]
                if TARGET&~high or low&~TARGET:continue
                eligible+=1;must1=TARGET&~low;must0=high&~TARGET
                for expr,value in expressions:
                    checks+=1
                    if value&must1!=must1 or value&must0:continue
                    matches+=1;e=materialize(d,selected,expr)
                    assert values(e)[e['output']]==TARGET
                    if min_exact is None or e['size']<min_exact['gates']:
                        min_exact=dict(gates=e['size'],source_wire=w,ports=sorted(selected),expr=expr)
                    if e['size']<=21:
                        scalar_check(e);e.update(source_sha256=hashlib.sha256(raw).hexdigest(),repair=min_exact,all_2048_scalar_checks_pass=True)
                        out=R/(args.label+'-fanout2-exact21.json');out.write_text(json.dumps(e,indent=2)+'\n');candidate=dict(path=str(out),sha256=hashlib.sha256(out.read_bytes()).hexdigest(),gates=e['size']);raise RuntimeError('EXACT')
                if time.monotonic()-start>5:raise TimeoutError()
            records.append(dict(wire=w,uses=ports,subsets=subsets,repairable_contexts=eligible))
        # Alias controls recover the original source; independent full scalar test.
        for w,ports in enumerate(uses):
            if ports and len(controls)<5:
                e=materialize(d,{ports[0]},w);scalar_check(e,v[d['output']]);controls.append(dict(wire=w,gate_count=e['size']))
    except TimeoutError:status='TIME_LIMIT_PARTIAL'
    except RuntimeError as ex:
        if str(ex)!='EXACT':raise
        status='EXACT_CANDIDATE_REQUIRES_RAW_VALIDATOR_AND_LEAN'
    report=dict(status=status,label=args.label,source_sha256=hashlib.sha256(raw).hexdigest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),records=records,full_context_checks=checks,exact_function_matches=matches,smallest_exact=min_exact,candidate=candidate,controls=controls,elapsed_seconds=time.monotonic()-start,scope=__doc__)
    p=R/(args.label+'-fanout2-result.json')
    with p.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in report.items() if k!='records'}))

if __name__=='__main__':main()
