"""Exact one-gate corrections into <=3 ports, followed by one gate alias deletion."""
from pathlib import Path
from itertools import combinations
import json,hashlib,time,resource,os
from candidate134227_fanout import H,TARGET,ONES,values,context,materialize,scalar_check
def main():
    os.nice(10);resource.setrlimit(resource.RLIMIT_CPU,(7,7));t=time.monotonic()
    R=H/'allnegative-best4-analysis';p=R/'original-offset11.json';d=json.loads(p.read_text());v=values(d)
    first=[]
    for a,b in combinations(range(len(v)),2):first.extend([(('and',a,b),v[a]&v[b]),(('or',a,b),v[a]|v[b])])
    ports=[(i,j) for i in range(len(d['gates'])) for j in (0,1)]+[(-1,0)]
    seen=set();records=[];checks=0;deletions=0;minimum=100;found=None;status='COMPLETE_STATED_FAMILY'
    try:
        for n in range(1,4):
            for selected0 in combinations(ports,n):
                selected=set(selected0);low=context(d,selected,0);high=context(d,selected,ONES)
                if TARGET&~high or low&~TARGET:continue
                must1=TARGET&~low;must0=high&~TARGET
                for expr,value in first:
                    checks+=1
                    if value&must1!=must1 or value&must0:continue
                    e=materialize(d,selected,expr)
                    if e['size']!=22:continue
                    key=(e['output'],tuple(tuple(g) for g in e['gates']))
                    if key in seen:continue
                    seen.add(key);assert values(e)[e['output']]==TARGET
                    if len(seen)==1:
                        scalar_check(e)
                        with (R/'exact22-one-gate-control.json').open('x') as f:json.dump(e,f,indent=2);f.write('\n')
                    rec=dict(correction_ports=selected0,correction=expr,alias_checks=0,exact_aliases=[])
                    ev=values(e)
                    for i,(_,a,b) in enumerate(e['gates']):
                        w=11+i;uses={(j,k) for j,g in enumerate(e['gates']) for k in (0,1) if g[k+1]==w}
                        if e['output']==w:uses.add((-1,0))
                        for leaf in sorted({a,b}):
                            deletions+=1;rec['alias_checks']+=1
                            if context(e,uses,ev[leaf])!=TARGET:continue
                            f=materialize(e,uses,leaf);assert values(f)[f['output']]==TARGET
                            rec['exact_aliases'].append(dict(gate=i,alias=leaf,size=f['size']));minimum=min(minimum,f['size'])
                            if f['size']<=21:
                                scalar_check(f);f.update(source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),correction=rec,all2048_scalar_pass=True)
                                out=R/'correct-delete-exact21.json';out.write_text(json.dumps(f,indent=2)+'\n');found=dict(path=str(out),sha256=hashlib.sha256(out.read_bytes()).hexdigest(),gates=f['size']);raise RuntimeError('EXACT')
                    records.append(rec)
                if time.monotonic()-t>4.5:raise TimeoutError()
    except TimeoutError:status='TIME_LIMIT_PARTIAL'
    except RuntimeError as e:
        if str(e)!='EXACT':raise
        status='EXACT_CANDIDATE_NEEDS_RAW_VALIDATOR_AND_LEAN'
    report=dict(status=status,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),full_context_checks=checks,distinct_exact22_corrections=len(seen),alias_deletions=deletions,smallest_exact_after_alias=None if minimum==100 else minimum,records=records,candidate=found,elapsed_seconds=time.monotonic()-t,scope=__doc__)
    with (R/'correct-delete-result.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in report.items() if k!='records'}))
if __name__=='__main__':main()
