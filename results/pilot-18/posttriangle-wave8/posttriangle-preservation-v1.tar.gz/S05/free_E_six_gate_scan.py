"""Finite core scan. Default runs tiny controls ONLY; --scan requires main CPU admission."""
from pathlib import Path
from itertools import combinations
import argparse,hashlib,json,time,resource,random,os
H=Path('/tmp/oec/pequalnp-pilot-18/orch/S05')
VERTICES=[1,2,4,5,8];CORE_EDGES=[(1,4),(1,8),(4,8),(2,5),(5,8)]
RAW={v:sum(1<<m for m in range(32) if m>>i&1) for i,v in enumerate(VERTICES)}
BASE={value:('raw',v) for v,value in RAW.items()};BASE[RAW[5]|RAW[8]]=('E',)
TARGET=sum(1<<m for m in range(32) if any(m>>VERTICES.index(a)&1 and m>>VERTICES.index(b)&1 for a,b in CORE_EDGES))

def tail(available,target):
    """Find an exact <=3-operation formula, including balanced and chain shapes."""
    first={v:('wire',v) for v in available}
    for x,y in combinations(available,2):
        first.setdefault(x&y,('and',('wire',x),('wire',y)))
        first.setdefault(x|y,('or',('wire',x),('wire',y)))
    if target in first:return first[target]
    for op in ('and','or'):
        eligible=[x for x in first if (x&target==target if op=='and' else not x&~target)]
        for x,y in combinations(eligible,2):
            if (x&y if op=='and' else x|y)==target:return (op,first[x],first[y])
    final=[(op,y) for y in available for op in ('and','or') if (y&target==target if op=='and' else not y&~target)]
    for x,xe in first.items():
        for y in available:
            for inner,z in [('and',x&y),('or',x|y)]:
                for outer,w in final:
                    if (z&w if outer=='and' else z|w)==target:return (outer,(inner,xe,('wire',y)),('wire',w))
    return None

def formula_set(available):
    """Independent small cost-layer DP used only for controls."""
    seen=set(available);levels=[set(available)]
    for n in range(1,4):
        new=set()
        for a in range(n):
            b=n-1-a
            for x in levels[a]:
                for y in levels[b]:new.add(x&y);new.add(x|y)
        new-=seen;seen|=new;levels.append(new)
    return seen

def expr_value(expr,values):
    if expr[0]=='wire':return values[expr[1]]
    a=expr_value(expr[1],values);b=expr_value(expr[2],values)
    return a&b if expr[0]=='and' else a|b

def controls():
    rng=random.Random(5896);cases=[]
    for index in range(12):
        available=list(BASE)
        for _ in range(index%4):
            a,b=rng.sample(available,2);value=a&b if rng.randrange(2) else a|b
            if value not in available:available.append(value)
        exact=formula_set(available);targets=[TARGET]+rng.sample(sorted(exact),min(12,len(exact)))
        for target in targets:
            e=tail(available,target);assert (e is not None)==(target in exact)
            if e is not None:assert expr_value(e,{v:v for v in available})==target
        cases.append(dict(available=available,reachable_up_to3=len(exact),targets=len(targets)))
    # Known seven-core-gate implementation after a four-gate prefix is a positive tail control.
    a=RAW[1]&RAW[4];b=RAW[1]|RAW[4];c=b|RAW[5];d=RAW[8]&c
    available=list(BASE)+[a,b,c,d];e=tail(available,TARGET)
    assert e is not None and expr_value(e,{v:v for v in available})==TARGET
    return dict(status='PASS_TINY_CONTROLS',independent_DP_cases=cases,known_seven_gate_positive_tail=e)

def export(history,expression,path):
    from prepare_triangle589 import EDGES
    gates=[];canonical={}
    def op(kind,a,b):
        if a==b:return a
        key=(kind,*sorted((a,b)))
        if key not in canonical:canonical[key]=11+len(gates);gates.append(list(key))
        return canonical[key]
    Ew=op('or',5,8);wires={value:v for v,value in RAW.items()};wires[RAW[5]|RAW[8]]=Ew
    for kind,a,b,z in history:wires[z]=op(kind,wires[a],wires[b])
    def rec(e):
        if e[0]=='wire':return wires[e[1]]
        return op(e[0],rec(e[1]),rec(e[2]))
    core=rec(expression)
    rest=op('or',op('and',3,op('or',6,7)),op('or',op('and',6,7),op('and',10,op('or',6,op('or',4,op('or',0,2))))))
    nine=op('and',9,op('or',Ew,op('or',0,7)))
    output=op('or',core,op('or',rest,nine));assert len(gates)<=21
    for m in range(2048):
        v=[bool(m>>i&1) for i in range(11)]
        for kind,a,b in gates:v.append(v[a]&v[b] if kind=='and' else v[a]|v[b])
        assert v[output]==any(m>>a&1 and m>>b&1 for a,b in EDGES)
    data=dict(inputs=11,gate_wire_offset=11,gate_count=len(gates),gates=gates,output=output,all_2048_scalar_checks_pass=True,Lean_proof=False,core_prefix=history,core_tail=expression)
    with path.open('x') as f:json.dump(data,f,indent=2);f.write('\n')
    return dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),gate_count=len(gates))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--scan',action='store_true');ap.add_argument('--label',required=True);ap.add_argument('--seconds',type=float,default=10);ap.add_argument('--cpu-seconds',type=int,default=12);args=ap.parse_args()
    assert args.label.replace('-','').isalnum() and 0<args.seconds<=40 and 0<args.cpu_seconds<=45
    os.nice(10);resource.setrlimit(resource.RLIMIT_CPU,(args.cpu_seconds,args.cpu_seconds));t=time.monotonic()
    report=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),controls=controls(),scan_requested=args.scan,complete=False,candidate=None)
    if args.scan:
        states={():[]};layers=[];timed=False;scanned=0
        for depth in range(1,4):
            fresh={}
            for state,history in states.items():
                available=sorted(set(BASE)|set(state))
                for a,b in combinations(available,2):
                    for op,z in [('and',a&b),('or',a|b)]:
                        if z in available:continue
                        new=tuple(sorted((*state,z)))
                        if new not in fresh:fresh[new]=history+[(op,a,b,z)]
                if time.monotonic()-t>args.seconds:timed=True;break
            layers.append(dict(depth=depth,states=len(fresh)));states=fresh
            if timed:break
        report['prefix_layers']=layers
        report['prefix_state_sha256']=hashlib.sha256(json.dumps(sorted(states),separators=(',',':')).encode()).hexdigest()
        if not timed:
            for state,history in states.items():
                available=sorted(set(BASE)|set(state));e=tail(available,TARGET);scanned+=1
                if e is not None:
                    report['candidate']=export(history,e,H/(args.label+'-exact21.json'));break
                if time.monotonic()-t>args.seconds:timed=True;break
        report.update(prefix_states_scanned=scanned,complete=not timed,candidate_requires_raw_validator_and_Lean=True,status='EXACT_CANDIDATE' if report['candidate'] else 'TIME_LIMIT_PARTIAL' if timed else 'NO_SIX_GATE_CORE')
    else:report['status']='TINY_CONTROLS_ONLY_NO_PREFIX_SCAN'
    report['elapsed_seconds']=time.monotonic()-t
    with (H/(args.label+'-result.json')).open('x') as f:json.dump(report,f,indent=2);f.write('\n')
    print(json.dumps(report))
if __name__=='__main__':main()
