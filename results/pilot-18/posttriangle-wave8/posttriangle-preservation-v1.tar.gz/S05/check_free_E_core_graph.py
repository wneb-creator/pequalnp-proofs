from pathlib import Path
import json,hashlib
H=Path('/tmp/oec/pequalnp-pilot-18/orch/S05')
V=[1,2,4,5,8];E=[(1,4),(1,8),(4,8),(2,5),(5,8)]
ind=[];covers=[]
for m in range(32):
    s={v for i,v in enumerate(V) if m>>i&1}
    independent=not any(a in s and b in s for a,b in E)
    if independent and all(any(a in s|{v} and b in s|{v} for a,b in E) for v in set(V)-s):ind.append(sorted(s))
    if all(a in s or b in s for a,b in E):covers.append(s)
assert sorted(ind)==sorted([[2,8],[1,5],[1,2],[4,5],[2,4]])
assert min(map(len,covers))==3
counts={v:sum(v in e for e in E) for v in V}
assert [v for v,n in counts.items() if n>=3]==[8]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
d=dict(status='MATHEMATICAL_TWO_AND_OBSTRUCTION_FINITE_GRAPH_CHECKS',maximal_independent_sets=ind,vertex_cover=3,degrees=counts,scope='Five-input core with E=x5 ORx8 free; not a six-total-gate or global lower bound.',proof_sha256=sha(H/'free_E_core_two_AND_obstruction.md'),three_prefix_reduction_sha256=sha(H/'free_E_six_gate_reduction.md'),control_source_sha256=sha(Path(__file__)))
with (H/'free-E-core-math-checks.json').open('x') as f:json.dump(d,f,indent=2);f.write('\n')
print(json.dumps(d))
