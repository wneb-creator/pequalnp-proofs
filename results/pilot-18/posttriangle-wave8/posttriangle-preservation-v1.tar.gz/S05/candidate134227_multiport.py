"""One common original-wire expression injected at <=3 arbitrary input ports.

Different ports may originally carry different wires. The new expression has
at most one fresh gate. Clones needed to retain original operand cones count.
"""
from pathlib import Path
from itertools import combinations
import argparse,json,hashlib,time,resource,os,random
from candidate134227_fanout import H,TARGET,ONES,values,context,materialize,scalar_check

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--label',required=True,choices=['best1','best3']);a=ap.parse_args()
    os.nice(10);resource.setrlimit(resource.RLIMIT_CPU,(8,8));start=time.monotonic()
    R=H/'candidate134227-repair';raw=(R/(a.label+'-offset11.json')).read_bytes();d=json.loads(raw);v=values(d)
    first=[(w,x) for w,x in enumerate(v)]
    for x,y in combinations(range(len(v)),2):
        first.extend([(('and',x,y),v[x]&v[y]),(('or',x,y),v[x]|v[y])])
    ports=[(i,j) for i in range(len(d['gates'])) for j in (0,1)]+[(-1,0)]
    controls=[];rng=random.Random(134227)
    for _ in range(12):
        selected=set(rng.sample(ports,3));expr,value=rng.choice(first);e=materialize(d,selected,expr)
        expected=context(d,selected,value);assert values(e)[e['output']]==expected
        scalar_check(e,expected);controls.append(dict(ports=sorted(selected),expr=expr,size=e['size']))
    levels=[];checks=0;matches=0;candidate=None;minimum=None;status='COMPLETE'
    try:
        for n in range(1,4):
            count=0;eligible=0;levelchecks=0
            for selected0 in combinations(ports,n):
                selected=set(selected0);count+=1
                low=context(d,selected,0);high=context(d,selected,ONES)
                assert not low&~high
                if TARGET&~high or low&~TARGET:continue
                eligible+=1;must1=TARGET&~low;must0=high&~TARGET
                for expr,x in first:
                    checks+=1;levelchecks+=1
                    if x&must1!=must1 or x&must0:continue
                    matches+=1;e=materialize(d,selected,expr);assert values(e)[e['output']]==TARGET
                    if minimum is None or e['size']<minimum['size']:minimum=dict(size=e['size'],ports=selected0,expr=expr)
                    if e['size']<=21:
                        scalar_check(e);e.update(repair=minimum,source_sha256=hashlib.sha256(raw).hexdigest(),all_2048_scalar_checks_pass=True)
                        p=R/(a.label+'-multiport-exact21.json');p.write_text(json.dumps(e,indent=2)+'\n');candidate=dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),size=e['size']);raise RuntimeError('EXACT')
                if time.monotonic()-start>5:raise TimeoutError()
            levels.append(dict(port_count=n,subsets=count,repairable_contexts=eligible,full_context_checks=levelchecks))
    except TimeoutError:status='TIME_LIMIT_PARTIAL'
    except RuntimeError as ex:
        if str(ex)!='EXACT':raise
        status='EXACT_CANDIDATE_REQUIRES_RAW_VALIDATOR_AND_LEAN'
    d=dict(status=status,label=a.label,source_sha256=hashlib.sha256(raw).hexdigest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),dependency_sha256=hashlib.sha256((H/'candidate134227_fanout.py').read_bytes()).hexdigest(),levels=levels,full_context_checks=checks,exact_function_matches=matches,smallest_exact=minimum,candidate=candidate,controls=controls,elapsed_seconds=time.monotonic()-start,scope=__doc__)
    with (R/(a.label+'-multiport-result.json')).open('x') as f:json.dump(d,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in d.items() if k!='controls'}))

if __name__=='__main__':main()
