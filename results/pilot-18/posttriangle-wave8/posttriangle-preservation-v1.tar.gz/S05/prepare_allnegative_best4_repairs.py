from pathlib import Path
import json,hashlib
from prepare_triangle589 import EDGES,NEG,evaluate
H=Path('/tmp/oec/pequalnp-pilot-18/orch/S05');R=H/'allnegative-best4-analysis';raw=(R/'source.json').read_bytes();pin=hashlib.sha256(raw).hexdigest();assert pin=='b6da8ac6962d7836f2e5546423f5ed3846b7165fbe1ae47e58b8e470955101b0';d=json.loads(raw)
e=json.load(open(R/'original-offset11.json'));norm=hashlib.sha256((R/'original-offset11.json').read_bytes()).hexdigest();assert norm=='441a221b84f6570ac59b0b9c776bcd6e90029232c8e649e34080f91d8db71f3a'
(R/'best4-offset11.json').write_bytes((R/'original-offset11.json').read_bytes());checks=0;fp=[];fn=[];live=set();junk=set()
def visit(w):
 if w<13 or w in live:return
 live.add(w);_,a,b=d['gates'][w-13];visit(a);visit(b)
visit(d['output']);assert len(live)==21
for m in range(2048):
 v=evaluate(d,m);w=evaluate(e,m);x=v[:11];target=any(x[a] and x[b] for a,b in EDGES)
 for g in range(21):assert v[g+13]==w[g+11];checks+=1
 core=(x[0] or x[5] or x[8]) and (x[9] or ((x[4] or x[5]) and (x[2] or x[8])))
 rest=(x[1] and (x[4] or x[8])) or (x[3] and (x[6] or x[7])) or (x[7] and (x[6] or x[9])) or (x[10] and (x[0] or x[2] or x[4] or x[6]))
 assert v[d['output']]==(core or rest)==(target or (x[0] and x[2] and x[4]))
 if target and not v[d['output']]:fn.append(m)
 if not target and v[d['output']]:fp.append(m)
 if not target:junk.update(g for g,(op,a,b) in enumerate(d['gates']) if op=='and' and v[g+13])
assert not fn and fp==[21,29,85,149] and sorted(junk)==[5,7]
changes=[]
parent='triangle589_best3_internal_context.py';s=(H/parent).read_text()
edits=[("SOURCE=H/'triangle589-best3-analysis/original-offset11.json'","SOURCE=H/'allnegative-best4-analysis/original-offset11.json'"),('f3c2bacb85a0ce0e080072ad39b0a695f90affb6f7204880c44acdf496195790',norm),(".bit_count()==5 and not target", ".bit_count()==4 and not target"),('resource.RLIMIT_CPU,(50,50)','resource.RLIMIT_CPU,(8,8)'),('time.monotonic()-start>45','time.monotonic()-start>5'),("H/'triangle589-best3-internal-exact21.json'","H/'allnegative-best4-analysis/internal-exact21.json'"),("H/'triangle589-best3-internal-context-result.json'","H/'allnegative-best4-analysis/internal-result.json'")]
for a,b in edits:assert a in s;s=s.replace(a,b)
p=H/'allnegative_best4_internal.py'
with p.open('x') as f:f.write(s)
changes.append(dict(parent=parent,parent_sha256=hashlib.sha256((H/parent).read_bytes()).hexdigest(),edits=edits,script=str(p),script_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
for parent,filename in [('candidate134227_fanout.py','allnegative_best4_fanout.py'),('candidate134227_fanout2.py','allnegative_best4_fanout2.py'),('candidate134227_multiport.py','allnegative_best4_multiport.py')]:
 s=(H/parent).read_text();edits=[("choices=['best1','best3']","choices=['best4']"),("H/'candidate134227-repair'","H/'allnegative-best4-analysis'")]
 for a,b in edits:assert a in s;s=s.replace(a,b)
 p=H/filename
 with p.open('x') as f:f.write(s)
 changes.append(dict(parent=parent,parent_sha256=hashlib.sha256((H/parent).read_bytes()).hexdigest(),edits=edits,script=str(p),script_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
result=dict(status='FULL2048_FUNCTION_AND_NORMALIZATION_PASS',fn=fn,fp=fp,minimal_extras=[21],junk_gates=sorted(junk),all21_live=True,intermediate_checks=checks,source_sha256=pin,normalized_sha256=norm,scripts=changes)
(R/'preparation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
