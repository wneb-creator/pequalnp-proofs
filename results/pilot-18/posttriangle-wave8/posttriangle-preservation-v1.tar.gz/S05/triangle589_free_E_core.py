"""Exact small formula DP for core edges14,18,48,25,58 with E=5 OR8 free."""
from pathlib import Path
import json,hashlib,time,resource,os
H=Path('/tmp/oec/pequalnp-pilot-18/orch/S05')
def main():
    resource.setrlimit(resource.RLIMIT_CPU,(5,5));os.nice(10);t0=time.monotonic()
    vertices=[1,2,4,5,8];edges=[(1,4),(1,8),(4,8),(2,5),(5,8)]
    sig={v:sum(1<<m for m in range(32) if m>>i&1) for i,v in enumerate(vertices)}
    target=sum(1<<m for m in range(32) if any(m>>(vertices.index(a))&1 and m>>(vertices.index(b))&1 for a,b in edges))
    free=sig[5]|sig[8];mincost={v:0 for v in sig.values()};expr={value:k for k,value in sig.items()};expr[free]='E';mincost[free]=0
    levels=[list(mincost)];counts=[];found=None;pairs=0
    for n in range(1,8):
        new=[]
        for a in range(n):
            b=n-1-a
            if a>b:continue
            for i,x in enumerate(levels[a]):
                ys=levels[b][i:] if a==b else levels[b]
                for y in ys:
                    pairs+=1
                    for op,z in [('and',x&y),('or',x|y)]:
                        if z in mincost:continue
                        mincost[z]=n;expr[z]=(op,expr[x],expr[y]);new.append(z)
        levels.append(new);counts.append(dict(fresh_formula_gates=n,new_functions=len(new),cumulative_functions=len(mincost)))
        if target in mincost:found=dict(cost=mincost[target],expression=expr[target]);break
    result=dict(status='EXACT_FORMULA_DP_COMPLETE_TO_FIRST_TARGET',vertices=vertices,edges=edges,free_signal='x5 ORx8',free_signal_cost_charged_in_surrounding_circuit=True,counts=counts,pairs=pairs,target=found,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),elapsed_seconds=time.monotonic()-t0,scope='Formula operation count with free E and five raw inputs; minimum formula cost, not arbitrary shared-DAG lower bound. A six-operation result would imply whole construction<=21 before independent scalar validation.')
    with (H/'triangle589-free-E-core-result.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(result))
if __name__=='__main__':main()
