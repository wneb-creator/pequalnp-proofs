"""Bounded algebraic construction for subdivided K4: no solver or global claim."""
from pathlib import Path
from itertools import combinations
from functools import lru_cache
import hashlib,json,time,resource,os,heapq
H=Path('/tmp/oec/pequalnp-pilot-18/orch/S05')
# a,b,c,A,B,C,h map to original vertices 0,2,4,9,5,8,10.
N=7;EDGES=[(3,4),(3,5),(4,5),(0,3),(1,4),(2,5),(0,6),(1,6),(2,6)]
def main():
    os.nice(10);resource.setrlimit(resource.RLIMIT_CPU,(5,5));start=time.monotonic()
    independent=[m for m in range(1<<N) if not any(m>>a&1 and m>>b&1 for a,b in EDGES)]
    mis=[m for m in independent if all(m>>v&1 or m|(1<<v) not in independent for v in range(N))]
    rows=[(1<<a)|(1<<b) for a,b in EDGES]+mis;pos=(1<<len(EDGES))-1
    sig=[sum(1<<j for j,m in enumerate(rows) if m>>v&1) for v in range(N)]
    nodes=[None]*N;reach=[0]*N;memo={}
    def op(kind,a,b):
        if a==b:return a
        key=(kind,*sorted((a,b)))
        if key not in memo:
            memo[key]=len(nodes);nodes.append(key);sig.append(sig[a]&sig[b] if kind=='and' else sig[a]|sig[b]);reach.append(reach[a]|reach[b]|(1<<(len(nodes)-1)))
        return memo[key]
    @lru_cache(None)
    def linear(mask):
        bits=[v for v in range(N) if mask>>v&1];x=bits[0]
        for y in bits[1:]:x=op('or',x,y)
        return x
    clauses=[(s,linear(s)) for s in range(1,1<<N)]
    contributors=set();triples=0;qualified=0
    for v in range(N):
        neighborhood=sum(1<<(b if a==v else a) for a,b in EDGES if v in (a,b));s=neighborhood
        while s:contributors.add(op('and',v,linear(s)));s=(s-1)&neighborhood
    for i,(a,aw) in enumerate(clauses):
        for j in range(i+1,len(clauses)):
            b,bw=clauses[j]
            if a&b in (a,b):continue
            for c,cw in clauses[j+1:]:
                triples+=1
                if a&c in (a,c) or b&c in (b,c):continue
                value=sig[aw]&sig[bw]&sig[cw]
                if value>>len(EDGES) or value.bit_count()<2:continue
                qualified+=1
                for x,y,z in [(aw,bw,cw),(aw,cw,bw),(bw,cw,aw)]:
                    root=op('and',op('and',x,y),z)
                    if reach[root].bit_count()<=11:contributors.add(root)
    pool=sorted(contributors,key=lambda x:(reach[x].bit_count(),-sig[x].bit_count(),x))
    # Retain multiple structurally distinct implementations of the same cover.
    bycover={}
    for p in pool:bycover.setdefault(sig[p],[]).append(p)
    pool=[p for entries in bycover.values() for p in entries[:12]]
    states=[(0,0,())];levels=[];best=None;checks=0;complete=True
    try:
        for depth in range(1,10):
            proposals={}
            for covered,used,chosen in states:
                for p in pool:
                    checks+=1;cover=covered|sig[p]
                    if cover==covered:continue
                    u=used|reach[p];cost=u.bit_count()+depth-1
                    if cost>12:continue
                    if cover==pos:
                        if best is None or cost<best['cost']:best=dict(cost=cost,chosen=chosen+(p,),used=u)
                        if cost<=11:raise RuntimeError('HIT')
                        continue
                    key=(cover,u);item=(cost+1.4*(len(EDGES)-cover.bit_count()),cost,cover,u,chosen+(p,))
                    proposals[key]=item
                if time.monotonic()-start>2.5:raise TimeoutError()
            kept=heapq.nsmallest(180,proposals.values());levels.append(dict(depth=depth,states=len(proposals),retained=len(kept)))
            states=[(cover,u,chosen) for _,_,cover,u,chosen in kept]
            if not states:break
    except TimeoutError:complete=False
    except RuntimeError as e:
        if str(e)!='HIT':raise
    candidate=None
    if best:
        root=best['chosen'][0]
        for p in best['chosen'][1:]:root=op('or',root,p)
        mapping={v:v for v in range(N)};gates=[]
        for w in range(N,len(nodes)):
            if reach[root]>>w&1:
                kind,a,b=nodes[w];mapping[w]=N+len(gates);gates.append([kind,mapping[a],mapping[b]])
        for m in range(1<<N):
            values=[bool(m>>v&1) for v in range(N)]
            for kind,a,b in gates:values.append(values[a]&values[b] if kind=='and' else values[a]|values[b])
            assert values[mapping[root]]==any(m>>a&1 and m>>b&1 for a,b in EDGES)
        candidate=dict(inputs=N,gate_wire_offset=N,gates=gates,output=mapping[root],size=len(gates),exact_all128=True,original_vertex_map=[0,2,4,9,5,8,10])
        p=H/'gadget7-contributor-candidate.json'
        with p.open('x') as f:json.dump(candidate,f,indent=2);f.write('\n')
        candidate=dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),size=len(gates))
    result=dict(status='LOCAL11_CANDIDATE' if candidate and candidate['size']<=11 else 'BOUNDED_ALGEBRA_NO11',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),independent_inputs=len(independent),maximal_independent_masks=mis,clauses=len(clauses),triples_tested=triples,qualified=qualified,pool_size=len(pool),combination_checks=checks,completed_retained_states=complete,levels=levels,candidate=candidate,elapsed_seconds=time.monotonic()-start,scope='All nonnested three-linear-clause clean contributors plus stars, canonical ascending OR trees; retain12percoverage andbeam180. Heuristic construction, not lower bound. Local11 does not automatically lift to full21; hstar extension must be checked.')
    with (H/'gadget7-contributors-result.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(result))
if __name__=='__main__':main()
