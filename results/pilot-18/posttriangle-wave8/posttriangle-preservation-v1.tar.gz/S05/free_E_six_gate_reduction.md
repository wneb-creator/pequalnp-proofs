# Six-gate core reduction (mathematics, not a completed enumeration)

The core has raw inputs x1,x2,x4,x5,x8 and a free signal E=x5 OR x8.
Its target is T=14 OR18 OR48 OR25 OR58. E is charged once outside the core.
A core with at most six binary AND/OR gates yields the proposed whole21
construction: core6 + E1 + other-edges9 + nine-star3 + finalOR2.

To decide this finite core question it suffices to enumerate all reachable
sets of three distinct new truth functions and then all formulas using at
most three more operations over the six original signals and that set.
Truth functions are 32-bit vectors on the five actual raw variables, so E's
relation to its inputs is preserved; E is not an independent sixth variable.

First remove unused nodes and gates whose function is already available.
The latter can be rewired to the earlier equal function. This is an exact
finite-function equivalence for all32 assignments. Constants and copies do
not help a nonconstant AND/OR target: propagate constants and copies away.
All remaining gates have distinct earlier input functions and add a new
truth function. Enumerating all ordered AND/OR operations on the available
functions therefore reaches the state of the first three gates of any
candidate. Deduplicating equal sets of available functions is sound because
future gates depend only on which functions are available, not their names.

Any circuit with at most three further AND/OR gates is equivalent to a
formula with at most three operations over those available signals. If its
three nodes form a tree, this is immediate. The only nontrivial reconvergent
shape has first-node output u feeding both the second node (u op v) and the
last node u op' (u op v). If op=op', idempotence/associativity reduce to the
second node. If op differs from op', absorption reduces to u. Repeated
fanins and missing/unused nodes also reduce. These are all possible DAG
shapes with three nodes. Thus testing balanced and chain formulas suffices.

Circuits shorter than three gates are tested while generating prefixes;
circuits of four or five gates have a three-gate prefix and a shorter tail.
Hence a completed negative enumeration, with separately checked state and
tail generators, would exclude every six-gate implementation of THIS core
with E free. It would not exclude a whole21 circuit with different sharing,
different intermediate functions, or different decomposition.

As of this document, only the formula and one-shared-intermediate subfamilies
have been executed. A full three-prefix/three-tail scan has NOT been run.
No six-gate DAG obstruction, Lean theorem, or global lower bound is claimed.
