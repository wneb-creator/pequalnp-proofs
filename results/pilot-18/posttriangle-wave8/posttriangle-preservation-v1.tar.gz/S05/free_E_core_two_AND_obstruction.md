# The free-E core requires at least three AND gates

This is a mathematical argument for the five-input core only, not a Lean
result or a global circuit lower bound. Inputs are 1,2,4,5,8, with E=5 OR8
available as an additional free linear signal. Target edges are14,18,48,25,58.

Suppose there are at most two AND gates. Before the first AND, every wire is
a linear OR. Write that AND as D=A*B, where A,B are linear. Every later wire
before the second AND is a linear OR, or a linear OR together with D. There
can be no raw linear disjunct in the final output, since the target is false
on every singleton. The output is therefore the second AND alone, or an OR
of the two AND outputs. Copies/constants can first be propagated away.

If D reaches the final output directly, or enters both operands of the
second AND, absorption reduces the function to D OR(L*M), for linear L,M.
Each of the two products must then have no false positive. This C4-free
graph has no non-star complete bipartite subgraph, so each product covers
edges incident to a single vertex. The target has vertex-cover number3,
and cannot be covered by two such products.

If D enters just one operand of the second AND, the remaining possibility
is T=L*(M+A*B), with linear L,M,A,B. L must be a vertex cover, hence contain
at least three vertices. If M is nonempty, every vertex in M must neighbor
every vertex of L, since L*M is a disjunct of the target. The only vertex
of degree at least three is8, whose neighborhood is{1,4,5}. Consequently
M={8} and L={1,4,5}.

The product A*B must now accept both edges14 and25. A and B cannot share
any of1,4,5: L would let the corresponding singleton through. They cannot
share2 either, because input{1,2} would then be falsely accepted. Thus on
the four vertices1,4,2,5, the two edges must be split between disjoint
linear sides. One splitting creates false cross-pairs15 and24; the other
creates12 and45. Each pair intersects L and is a nonedge. Contradiction.

If M is empty, the target would be L*A*B, a conjunction of three linear
clauses. Its maximal independent sets are{2,8},{1,5},{1,2},{4,5},{4,2}.
Each has a distinct minimal vertex-cover complement. A valid linear clause
rejecting a maximal independent set must be exactly that complement:
the clause support is itself a vertex cover and is contained in a minimal
cover. Hence an exact monotone CNF requires at least five clauses. Three
clauses cannot suffice.

These cases exhaust two AND gates, even with arbitrary OR gates and the
free E signal. A six-gate core, if it exists, therefore uses at least three
AND gates. This does not establish that six total gates are impossible.
The free-E formula DP and one-shared-intermediate scans are separately
recorded finite evidence; no general six-gate DAG scan has been performed.
