"""Two algebraically different core centers, four schedules each. No search."""
from pathlib import Path
import json,hashlib,random,time
from prepare_triangle589 import EDGES,NEG,evaluate,write,sha
H=Path('/tmp/oec/pequalnp-pilot-18/orch/S05')
def construct(center):
    leaf={9:0,5:2,8:4};b,c=sorted(v for v in leaf if v!=center);gates=[];memo={}
    def op(kind,a,b):
        key=(kind,*sorted((a,b)))
        if key not in memo:memo[key]=11+len(gates);gates.append(list(key))
        return memo[key]
    def join(*ws):
        z=ws[0]
        for w in ws[1:]:z=op('or',z,w)
        return z
    upper=join(b,c,leaf[center])
    inner=op('and',op('or',b,leaf[c]),op('or',c,leaf[b]))
    core=op('and',upper,op('or',center,inner))
    rest=join(op('and',1,op('or',4,8)),op('and',3,op('or',6,7)),op('and',7,op('or',6,9)),op('and',10,join(0,2,4,6)))
    output=op('or',core,rest)
    return dict(inputs=11,gate_wire_offset=11,size=len(gates),gates=gates,output=output)
def main():
    t=time.monotonic();R=H/'allnegative-best4-rotated-direct21-v1';R.mkdir(exist_ok=False)
    target=[any(m>>a&1 and m>>b&1 for a,b in EDGES) for m in range(2048)]
    expected=[target[m] or bool(m&1 and m&4 and m&16) for m in range(2048)]
    entries=[];lines=[];keys=set();checks=0;rows=0
    for center in [5,8]:
        d=construct(center);assert len(d['gates'])==21;write(R/f'center-{center}-original.json',d)
        before=[evaluate(d,m) for m in range(2048)];assert [v[d['output']] for v in before]==expected
        deps=[{w-11 for w in g[1:] if w>=11} for g in d['gates']]
        live=set()
        def visit(w):
            if w<11 or w-11 in live:return
            live.add(w-11);_,a,b=d['gates'][w-11];visit(a);visit(b)
        visit(d['output']);assert len(live)==21
        junk=[g for g,(op,_,_) in enumerate(d['gates']) if op=='and' and any(not target[m] and before[m][11+g] for m in range(2048))]
        count=0
        for attempt in range(32):
            rng=random.Random(13423000+100*center+attempt);done=set();order=[]
            while len(order)<21:
                ready=[g for g in range(21) if g not in done and deps[g]<=done]
                g=min(ready) if attempt==0 else max(ready) if attempt==1 else rng.choice(ready)
                done.add(g);order.append(g)
            mapping={g:i for i,g in enumerate(order)}
            cv=lambda w:w if w<11 else 13+mapping[w-11]
            e=dict(inputs=11,gate_wire_offset=13,size=21,gates=[[d['gates'][g][0],*sorted(cv(w) for w in d['gates'][g][1:])] for g in order],output=cv(d['output']))
            key=(e['output'],tuple(tuple(g) for g in e['gates']))
            if key in keys:continue
            keys.add(key);truth=14695981039346656037
            for m in range(2048):
                v=evaluate(e,m);assert v[e['output']]==expected[m];rows+=1
                for g in range(21):assert v[13+mapping[g]]==before[m][11+g];checks+=1
                truth=((truth^v[e['output']])*1099511628211)&((1<<64)-1)
            p=R/f'seed-{len(entries):02d}.json';write(p,e)
            entries.append(dict(path=str(p),sha256=sha(p),center=center,attempt=attempt,new_to_old=order,junk_gates=[mapping[g] for g in junk],full_fn=0,full_fp=4,boundary_fn=0,boundary_fp=3,truth_fnv1a64=truth,all21_live=True))
            lines.append(f'21 {e["output"]} 0 4 {truth}');lines.extend(f'{int(op=="and")} {a} {b}' for op,a,b in e['gates'])
            count+=1
            if count==4:break
        assert count==4
    p=R/'direct-seeds.txt';p.write_text('COVER_ANNEAL_DIRECT21 1 8\n'+'\n'.join(lines)+'\n')
    tokens=p.read_text().split();assert tokens[:3]==['COVER_ANNEAL_DIRECT21','1','8'];at=3
    for entry in entries:
        n,out,fn,fp,truth=map(int,tokens[at:at+5]);at+=5;assert (n,fn,fp)==(21,0,4);gates=[]
        for g in range(21):
            kind,a,b=map(int,tokens[at:at+3]);at+=3;assert kind in (0,1) and 0<=a<=b<13+g;gates.append((kind,a,b))
        h=14695981039346656037
        for m in range(2048):
            v=[bool(m>>i&1) for i in range(11)]+[False,True]
            for kind,a,b in gates:v.append(v[a]&v[b] if kind else v[a]|v[b])
            assert v[out]==expected[m];h=((h^v[out])*1099511628211)&((1<<64)-1)
        assert h==truth
    assert at==len(tokens)
    meta=dict(kind='algebraically_rotated_one_extra_triple_positive21',candidate_only=True,exact_target=False,Lean_proof=False,production_launched=False,count=8,original_best4_source_sha256='b6da8ac6962d7836f2e5546423f5ed3846b7165fbe1ae47e58b8e470955101b0',pack_sha256=sha(p),source_sha256=sha(Path(__file__)),dependency_sha256=sha(H/'prepare_triangle589.py'),engine_source_sha256='18efdd149487dfee83693dd0781a17316ba0fda9d68c43c6c70c73f96a77250b',engine_binary_sha256='7d802a63b218449bd58178785a917a363edecedace5f65201344804dec3a3870',wrapper_sha256='1e6f24c16faf2948c0aec5e4c300f9114d3e331c5894f191c9e0e7607f8afe8b',raw_validator_sha256='d244bfc58d60560041c5890592f3c2de90905c78fcd058f691b27e7785131401',exact_function='F OR x0*x2*x4',full_false_positive_masks=[m for m in range(2048) if expected[m] and not target[m]],boundary_false_positive_masks=[m for m in NEG if expected[m]],all16_positive_edges_pass=all(expected[(1<<a)|(1<<b)] for a,b in EDGES),decoded_input_checks=rows,intermediate_comparisons=checks,seeds=entries,elapsed_seconds=time.monotonic()-t)
    write(R/'direct-seeds.json',meta);print(json.dumps({k:v for k,v in meta.items() if k!='seeds'}))
if __name__=='__main__':main()
