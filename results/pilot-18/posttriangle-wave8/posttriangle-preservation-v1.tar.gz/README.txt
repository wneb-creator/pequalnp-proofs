S05 post-triangle candidate preservation, frozen completed work only.

Both new packs have eight distinct schedules. The original-center and rotated-
center packs compute F OR x0*x2*x4, with four false positives; neither is an
exact witness. All production admission belongs to main. The finite selftests
use the reviewed141 engine, whose complete source/build provenance, original
controls and independent reviews are flattened unchanged under reviewed141/.
Binary hashes are retained there; no binaries are included.

The134227 sources, all bounded internal/fanout/multiport repair code and full
logs are included. The free-E sixgate scan completed7478prefix states with no
candidate. Its mathematical completeness argument awaits independent review;
there is no global21-gate lower bound. The7/8-input contributor searches are
heuristic beams, finding exact12/13gate controls only. No solver/Lean is run by
this package. The postarchive proof notes and initial control failure are kept.

Portable verification: python3 S05/verify_posttriangle_archive.py ARCHIVE.tar.gz
This checks all member hashes, both packed outputs and intermediate values,
four original/control functions, and both small gadget controls; it launches
no engine or search. Producer scripts retain historical absolute paths and
pins for provenance; rebasing their paths is required to rerun elsewhere.
Old cited S04 input snapshots are copied under candidate134227-repair/.
Earlier solver-mode work is preserved separately by S06 and omitted here.
Historical report/metadata fields describe their original timestamped state.
