from pathlib import Path
import sys, json, difflib, subprocess, resource, time, traceback
sys.path.insert(0,str(Path(__file__).parent))
from wave5_delivery_helpers import Review,R,W,sha

v=Review('all-negative-engine-review'); O=v.O
M=R/'orch/MAIN/all-negative-engine-v1'
pack=R/'orch/S05/triangle589-best3-direct21-v1/direct-seeds.txt'
legacy=R/'orch/S05/dirty22-seed-pack/seeds.txt'
wrapper=R/'lean-setup/stochastic/stochastic_tools.py'
validator=R/'validate_raw_candidate.py'
sourcepin='18efdd149487dfee83693dd0781a17316ba0fda9d68c43c6c70c73f96a77250b'
binarypin='7d802a63b218449bd58178785a917a363edecedace5f65201344804dec3a3870'
records=[]
def run(name,cmd,cpu=10,mem=512,wall=20,expect=0):
 def limit():
  resource.setrlimit(resource.RLIMIT_CPU,(cpu,cpu+1))
  resource.setrlimit(resource.RLIMIT_AS,(mem*1024**2,mem*1024**2))
 t=time.monotonic()
 with (O/(name+'.stdout')).open('xb') as a,(O/(name+'.stderr')).open('xb') as b:
  p=subprocess.run([str(x) for x in cmd],stdout=a,stderr=b,cwd=O,timeout=wall,preexec_fn=limit)
 row={'name':name,'command':[str(x) for x in cmd],'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-t,'cpu_seconds':cpu,'address_space_MiB':mem,'wall_limit_seconds':wall}
 records.append(row);(O/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 assert p.returncode==expect,row
 return row

def main():
 for p in sorted(M.rglob('*')):
  if p.is_file():v.bind(p,Path('snapshot/main')/p.relative_to(M))
 for p in [pack,pack.with_suffix('.json'),legacy,legacy.with_suffix('.json'),wrapper,validator,R/'lean-setup/validate_sat_candidate.py',R/'orch/S08/direct21-engine-review/review.json',Path(__file__)]:v.bind(p)
 assert sha((M/'circuit_anneal_allnegative.cpp').read_bytes())==sourcepin
 assert sha((M/'circuit_anneal_allnegative').read_bytes())==binarypin
 parent=(M/'parent.cpp').read_text();new=(M/'circuit_anneal_allnegative.cpp').read_text()
 assert sha(parent.encode())=='e1a686c19d09439595cdfbf89baf42ff5d1dbfff8949e505b53b999d683ec077'
 assert ''.join(difflib.unified_diff(parent.splitlines(True),new.splitlines(True),fromfile='parent.cpp',tofile='circuit_anneal_allnegative.cpp'))==(M/'source.diff').read_text()
 prior=json.loads((R/'orch/S08/direct21-engine-review/review.json').read_text())
 assert any(x.get('sha256')==sha(parent.encode()) for x in prior['bindings'].values())
 assert sha(wrapper.read_bytes())=='1e6f24c16faf2948c0aec5e4c300f9114d3e331c5894f191c9e0e7607f8afe8b'
 assert sha(validator.read_bytes())=='d244bfc58d60560041c5890592f3c2de90905c78fcd058f691b27e7785131401'
 mainreview=json.loads((M/'main-review.json').read_text());assert mainreview['source_sha256']==sourcepin and mainreview['binary_sha256']==binarypin and mainreview['production_launched'] is False
 build=json.loads((M/'build.json').read_text());assert build['exit_code']==0 and build['source_sha256']==sourcepin
 assert (M/'build.stderr').stat().st_size==0
 assert (M/'independent-controls.stdout').read_text().strip()=='PASS independent full2048 scalar comparisons=2048000 random circuits=1000 negative rows=125 positive edges=16'
 for name,status in [('selftest-best3','SELF_TEST_DIRECT21_PASS'),('selftest-legacy','SELF_TEST_PASS')]:
  assert json.loads((M/(name+'.json')).read_text())['status']==status
  assert (M/(name+'.stderr')).stat().st_size==0
 wc=M/'wrapper-one-iteration-control'; wr=json.loads((wc/'result.json').read_text());er=json.loads((wc/'engine-result.json').read_text())
 assert wr['status']=='UNKNOWN' and wr['engine_exit']==0 and wr['engine_sha256']==binarypin
 assert wr['engine_result_sha256']==sha((wc/'engine-result.json').read_bytes())
 for name,r in wr['logs'].items():assert r=={'bytes':(wc/name).stat().st_size,'sha256':sha((wc/name).read_bytes())}
 for name,h in wr['best_files'].items():assert h==sha((wc/name).read_bytes())
 for key,path in [('pack_sha256',pack),('pack_metadata_sha256',pack.with_suffix('.json')),('wrapper_sha256',wrapper),('validator_sha256',validator)]:assert wr[key]==sha(path.read_bytes())
 assert er['fitness_domain']=='16_edges_plus_all_125_negative_inputs' and er['false_negatives']==0 and er['false_positives']==5 and er['iterations']==1
 # A separately written scalar evaluator binds the main wrapper output to its truth table.
 edges=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
 errors=[]
 for x in range(2048):
  vals=[bool(x>>i&1) for i in range(11)]+[False,True]
  for op,a,b in er['gates']:vals.append((vals[a] and vals[b]) if op=='and' else (vals[a] or vals[b]))
  want=any(x>>a&1 and x>>b&1 for a,b in edges)
  if vals[er['output']]!=want:errors.append(x)
 assert errors==[21,29,85,148,149]
 v.checks['main_evidence']={'main_review_sha256':sha((M/'main-review.json').read_bytes()),'build_Werror':True,'full_scalar_inputs':2048000,'random_circuits':1000,'legacy_deletions':440,'legacy_mutations':440,'direct_mutations':1024,'direct_starts':256,'wrapper_one_iteration':'UNKNOWN; 0 edge-FN / 5 full-FP','wrapper_output_independent_full2048_errors':errors}
 cpp=O/'independent_review_controls.cpp'
 cpp.write_text(r'''#define main reviewed_engine_program_main
#include "snapshot/main/circuit_anneal_allnegative.cpp"
#undef main
#include <bitset>
#include <limits>
#include <set>
void req(bool b,const char* s){if(!b)throw std::runtime_error(s);}
bool reference_target(unsigned x){
 const unsigned masks[]={513,1025,18,258,36,1028,72,136,272,1040,288,544,192,1088,640,768};
 for(auto m:masks)if((x&m)==m)return true;
 return false;
}
bool reference_value(const Gate* gates,int count,int output,unsigned x){
 std::vector<unsigned> w;for(unsigned i=0;i<11;++i)w.push_back((x>>i)&1U);
 w.push_back(0);w.push_back(1);
 for(int g=0;g<count;++g){auto t=gates[g];req(t.op==0||t.op==1,"op");req(t.a>=0&&t.b>=0&&t.a<int(w.size())&&t.b<int(w.size()),"operand");w.push_back(t.op?(w[t.a]*w[t.b]):unsigned(w[t.a]+w[t.b]>0));}
 req(output>=0&&output<int(w.size()),"output");return w[output]!=0;
}
int main(int argc,char**argv)try{
 req(argc==3,"packs required");Engine e(134231);Bits zero{};std::bitset<192> seen;
 for(size_t i=0;i<192;++i){auto a=Bits::one(i);req(a.count()==1,"one count");req(a.words[i/64]==(uint64_t(1)<<(i%64)),"one location");req((a&~a)==zero,"complement");req((~a).count()==191,"complement count");
  for(size_t j=0;j<192;++j){auto b=Bits::one(j);req((a&b).count()==int(i==j),"and");req((a|b).count()==(i==j?1:2),"or");req((a^b).count()==(i==j?0:2),"xor");req((a==b)==(i==j),"eq");req((a!=b)==(i!=j),"ne");}seen.set(i);}
 req(seen.all(),"coverage");int throws=0;for(size_t i:{size_t(192),std::numeric_limits<size_t>::max()})try{Bits::one(i);}catch(const std::runtime_error&){++throws;}req(throws==2,"index guard");
 req(e.all.words==std::array<uint64_t,3>{UINT64_MAX,UINT64_MAX,8191},"all mask");req(e.positives.words==std::array<uint64_t,3>{65535,0,0},"positive mask");req((e.all^e.positives).count()==125,"negative mask");req(e.inputs[11]==zero&&e.inputs[12]==e.all,"constants");
 auto rows=fitness_rows();std::set<int> distinct(rows.begin(),rows.end());req(rows.size()==141&&distinct.size()==141,"row uniqueness");int neg=0;
 for(unsigned x=0;x<2048;++x){if(!reference_target(x)){++neg;req(distinct.count(x)==1,"missing negative");}else if(std::bitset<11>(x).count()==2)req(distinct.count(x)==1,"missing edge");}
 req(neg==125,"negative count");for(size_t i=0;i<rows.size();++i)req(reference_target(rows[i])==(i<16),"row partition");
 uint64_t scalar_checks=0,vector_checks=0,score_checks=0,circuits=0,exact_controls=0;
 auto check=[&](const Gate* gates,int count,int output,const Circuit* c){
  auto bits=e.vector_eval(gates,count,output);req((bits&~e.all)==zero,"tail bits");int fullfn=0,edgefn=0,fp=0;bool values[2048]{};
  for(unsigned x=0;x<2048;++x){bool val=reference_value(gates,count,output,x);values[x]=val;bool t=reference_target(x);fullfn+=t&&!val;edgefn+=t&&std::bitset<11>(x).count()==2&&!val;fp+=!t&&val;++scalar_checks;}
  for(size_t i=0;i<rows.size();++i){req(bool((bits.words[i/64]>>(i%64))&1)==values[rows[i]],"independent vector mismatch");++vector_checks;}
  req((edgefn==0&&fp==0)==(fullfn==0&&fp==0),"zero criterion");
  req((e.positives&~bits).count()==edgefn&&((e.all^e.positives)&bits).count()==fp,"counts");
  if(c)for(int weight:{1,4,16}){auto s=e.score(*c,weight);req(s.fn==edgefn&&s.fp==fp,"score counts");req(s.live>=0&&s.live<=21,"live bounds");req(s.energy>=weight*edgefn+fp&&s.energy<weight*edgefn+fp+1,"strict tie break");++score_checks;}
  else {req(fullfn==0&&fp==0,"exact22 positive control");++exact_controls;}
  ++circuits;
 };
 std::mt19937_64 rng(0x8508134231ULL);
 for(int trial=0;trial<512;++trial){Circuit c{};for(int g=0;g<21;++g){auto&t=c.gates[g];t.op=int(rng()%2);t.a=int(rng()%uint64_t(13+g));t.b=int(rng()%uint64_t(13+g));if(t.a>t.b)std::swap(t.a,t.b);}c.output=trial%34;check(c.gates.data(),21,c.output,&c);}
 auto seeds=load_direct21(argv[1]);for(auto&c:seeds)check(c.gates.data(),21,c.output,&c);
 auto baselines=load(argv[2]);for(auto&b:baselines)check(b.gates.data(),22,b.output,nullptr);
 Circuit c{};for(auto&t:c.gates)t={0,11,11};c.output=11;auto s=e.score(c,16);req(s.fn==16&&s.fp==0,"false control");c.output=12;s=e.score(c,1);req(s.fn==0&&s.fp==125,"true control");
 std::cout<<"PASS UBSan independent_reference circuits="<<circuits<<" scalar_checks="<<scalar_checks<<" vector_bit_checks="<<vector_checks<<" weighted_scores="<<score_checks<<" exact22_controls="<<exact_controls<<" singleton_bits=192 bit_pairs=36864 invalid_indices=2 tail_bits=51\n";return 0;
}catch(const std::exception&x){std::cerr<<"FAIL "<<x.what()<<"\n";return 1;}
''')
 run('controls-build',['g++','-std=c++17','-O1','-g','-fsanitize=undefined','-fno-sanitize-recover=all','-Wall','-Wextra','-Werror',cpp,'-o',O/'independent_review_controls'],cpu=25,mem=1536,wall=35)
 run('independent-controls',[O/'independent_review_controls',pack,legacy],cpu=10,mem=512,wall=15)
 exactbin=O/'snapshot/main/circuit_anneal_allnegative';exactbin.chmod(0o755)
 run('binary-selftest',[exactbin,'--pack',pack,'--output',O/'binary-selftest.json','--seed','134231','--self-test'],cpu=10,mem=256,wall=15)
 assert json.loads((O/'binary-selftest.json').read_text())=={'status':'SELF_TEST_DIRECT21_PASS','seeds':8,'full_truth_inputs':2048,'direct_start_controls':256,'mutation_controls':1024}
 # Inject only a deliberately false candidate status/count into a finite fake engine.
 # Actual reviewed wrapper and full scalar validator must reject it independently.
 bad=dict(er);bad.update(status='CANDIDATE_NEEDS_INDEPENDENT_VALIDATION',false_negatives=0,false_positives=0)
 payload=O/'deliberately_inexact_candidate.json';payload.write_text(json.dumps(bad,indent=2)+'\n')
 fake=O/'fake_claimed_candidate.py';fake.write_text('#!'+sys.executable+'\nimport sys\nfrom pathlib import Path\nPath(sys.argv[sys.argv.index("--output")+1]).write_bytes(Path('+repr(str(payload))+').read_bytes())\nraise SystemExit(10)\n');fake.chmod(0o755)
 run('wrapper-reject',[sys.executable,'-B',wrapper,'run','--engine',fake,'--pack',pack,'--output',O/'wrapper-reject','--seed','134231','--seconds','1','--iterations','1','--restart','100','--weight','4','--abort-file',O/'nonexistent-abort'],cpu=10,mem=512,wall=15,expect=1)
 rejection=json.loads((O/'wrapper-reject/result.json').read_text());assert rejection['engine_exit']==10 and rejection['validator_exit']==2 and rejection['status']=='ERROR'
 assert 'Target mismatch at input 21' in (O/'wrapper-reject/validation.stdout.txt').read_text()
 assert not (O/'wrapper-reject/validated.json').exists()
 v.checks['independent_controls_stdout']=(O/'independent-controls.stdout').read_text().strip()
 v.checks['binary_selftest']=json.loads((O/'binary-selftest.json').read_text())
 v.checks['false_candidate_wrapper_rejection']={'engine_exit':10,'validator_exit':2,'wrapper_exit':1,'status':'ERROR','first_mismatch':21,'no_validated_output':True}
 v.checks['source_review']={'exact_parent_and_unified_diff':True,'mutation_restart_pack_loading_bounds_and_validation_unchanged':True,'three_word_masks':['ffffffffffffffff','ffffffffffffffff','0000000000001fff'],'mask_tail_bits':51,'zero_error_criterion':'For valid monotone AND/OR/constants circuits, acceptance of every minimal positive edge implies acceptance of all target-positive supersets; all 125 target-negatives are explicitly included. Thus edge-FN=0 and full-FP=0 iff full2048 exactness.','acceptance':'Both engine candidate paths still scalar-check all2048; wrapper still requires exit10/status match and independently pinned full2048 normalization/gate-limit validator.','caveats':['FN counts positive edges only, not every positive input. FP now counts all125 negatives and is not comparable with old40-row FP.','Zero errors means fn=fp=0, not energy=0: live-gate fractional tie-breaker remains.','No exact21 candidate or successful exact21 acceptance fixture exists; exact22 positive vector controls and inexact candidate rejection were used.','The finite controls establish correctness, not search performance; candidate status still requires Lean proof.']}
 # Recheck every bound original after controls; none is rewritten by this reviewer.
 for path,row in list(v.bindings.items()):assert sha(Path(path).read_bytes())==row['sha256'],path
 for p in sorted(O.rglob('*')):
  if p.is_file() and 'snapshot' not in p.relative_to(O).parts:v.bind(p)
 v.checks['recommendation']='PASS: main may admit a bounded pilot using this exact binary and unchanged pinned wrapper/pack/validators; main alone owns resource admission and launch.'
 v.checks['named_Lean_unchanged_sha256']=sha((W/'lean/PEqualNP/Outside/L_meta_1342.lean').read_bytes())
 assert v.checks['named_Lean_unchanged_sha256']=='0e0620c89307cf34be010940037cb187797eea76c85fc8c8a89b9bd1cfc56e5c'
 v.finish('PASS_ALL_NEGATIVE_141ROW_ENGINE_FOR_BOUNDED_PILOT','Source18efdd149487dfee83693dd0781a17316ba0fda9d68c43c6c70c73f96a77250b/binary7d802a63b218449bd58178785a917a363edecedace5f65201344804dec3a3870; exactparent/diff/main-review and mainfullcontrols/wrapperUNKNOWN bound. IndependentUBSan 524circuits/1073152scalarinputs/73884vectorbits/1560weightedscorechecks/192bits/36864bitpairs/2invalidindices/four exact22positivecontrols PASS. Exactbinary selftest1024mutations+256starts PASS; actualwrapper rejects forgedzero-error best3 atinput21 (validator2,wrapperERROR). Zero edge-FN/full-FP iff full2048 bymonotonicity; unchangedfull2048candidate+independentvalidator gates. FNedge-only,FPall125,energyincludeslivefraction; no performance/exact21/Leanclaim. Mainmayadmit boundedpilot; noS08production/solver/Lean/gitwrite. Fullcommands/logs/snapshots retained.')

if __name__=='__main__':
 try:main()
 except BaseException:
  (O/'reviewer-failure.txt').write_text(traceback.format_exc());raise
