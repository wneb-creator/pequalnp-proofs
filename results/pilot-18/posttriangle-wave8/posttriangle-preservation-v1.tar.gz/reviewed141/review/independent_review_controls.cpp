#define main reviewed_engine_program_main
#include "snapshot/main/circuit_anneal_allnegative.cpp"
#undef main
#include <bitset>
#include <limits>
#include <set>
void req(bool b,const char* s){if(!b)throw std::runtime_error(s);}
bool reference_target(unsigned x){
 const unsigned masks[]={513,1025,18,258,36,1028,72,136,272,1040,288,544,192,1088,640,768};
 for(auto m:masks)if((x&m)==m)return true;
 return false;
}
bool reference_value(const Gate* gates,int count,int output,unsigned x){
 std::vector<unsigned> w;for(unsigned i=0;i<11;++i)w.push_back((x>>i)&1U);
 w.push_back(0);w.push_back(1);
 for(int g=0;g<count;++g){auto t=gates[g];req(t.op==0||t.op==1,"op");req(t.a>=0&&t.b>=0&&t.a<int(w.size())&&t.b<int(w.size()),"operand");w.push_back(t.op?(w[t.a]*w[t.b]):unsigned(w[t.a]+w[t.b]>0));}
 req(output>=0&&output<int(w.size()),"output");return w[output]!=0;
}
int main(int argc,char**argv)try{
 req(argc==3,"packs required");Engine e(134231);Bits zero{};std::bitset<192> seen;
 for(size_t i=0;i<192;++i){auto a=Bits::one(i);req(a.count()==1,"one count");req(a.words[i/64]==(uint64_t(1)<<(i%64)),"one location");req((a&~a)==zero,"complement");req((~a).count()==191,"complement count");
  for(size_t j=0;j<192;++j){auto b=Bits::one(j);req((a&b).count()==int(i==j),"and");req((a|b).count()==(i==j?1:2),"or");req((a^b).count()==(i==j?0:2),"xor");req((a==b)==(i==j),"eq");req((a!=b)==(i!=j),"ne");}seen.set(i);}
 req(seen.all(),"coverage");int throws=0;for(size_t i:{size_t(192),std::numeric_limits<size_t>::max()})try{Bits::one(i);}catch(const std::runtime_error&){++throws;}req(throws==2,"index guard");
 req(e.all.words==std::array<uint64_t,3>{UINT64_MAX,UINT64_MAX,8191},"all mask");req(e.positives.words==std::array<uint64_t,3>{65535,0,0},"positive mask");req((e.all^e.positives).count()==125,"negative mask");req(e.inputs[11]==zero&&e.inputs[12]==e.all,"constants");
 auto rows=fitness_rows();std::set<int> distinct(rows.begin(),rows.end());req(rows.size()==141&&distinct.size()==141,"row uniqueness");int neg=0;
 for(unsigned x=0;x<2048;++x){if(!reference_target(x)){++neg;req(distinct.count(x)==1,"missing negative");}else if(std::bitset<11>(x).count()==2)req(distinct.count(x)==1,"missing edge");}
 req(neg==125,"negative count");for(size_t i=0;i<rows.size();++i)req(reference_target(rows[i])==(i<16),"row partition");
 uint64_t scalar_checks=0,vector_checks=0,score_checks=0,circuits=0,exact_controls=0;
 auto check=[&](const Gate* gates,int count,int output,const Circuit* c){
  auto bits=e.vector_eval(gates,count,output);req((bits&~e.all)==zero,"tail bits");int fullfn=0,edgefn=0,fp=0;bool values[2048]{};
  for(unsigned x=0;x<2048;++x){bool val=reference_value(gates,count,output,x);values[x]=val;bool t=reference_target(x);fullfn+=t&&!val;edgefn+=t&&std::bitset<11>(x).count()==2&&!val;fp+=!t&&val;++scalar_checks;}
  for(size_t i=0;i<rows.size();++i){req(bool((bits.words[i/64]>>(i%64))&1)==values[rows[i]],"independent vector mismatch");++vector_checks;}
  req((edgefn==0&&fp==0)==(fullfn==0&&fp==0),"zero criterion");
  req((e.positives&~bits).count()==edgefn&&((e.all^e.positives)&bits).count()==fp,"counts");
  if(c)for(int weight:{1,4,16}){auto s=e.score(*c,weight);req(s.fn==edgefn&&s.fp==fp,"score counts");req(s.live>=0&&s.live<=21,"live bounds");req(s.energy>=weight*edgefn+fp&&s.energy<weight*edgefn+fp+1,"strict tie break");++score_checks;}
  else {req(fullfn==0&&fp==0,"exact22 positive control");++exact_controls;}
  ++circuits;
 };
 std::mt19937_64 rng(0x8508134231ULL);
 for(int trial=0;trial<512;++trial){Circuit c{};for(int g=0;g<21;++g){auto&t=c.gates[g];t.op=int(rng()%2);t.a=int(rng()%uint64_t(13+g));t.b=int(rng()%uint64_t(13+g));if(t.a>t.b)std::swap(t.a,t.b);}c.output=trial%34;check(c.gates.data(),21,c.output,&c);}
 auto seeds=load_direct21(argv[1]);for(auto&c:seeds)check(c.gates.data(),21,c.output,&c);
 auto baselines=load(argv[2]);for(auto&b:baselines)check(b.gates.data(),22,b.output,nullptr);
 Circuit c{};for(auto&t:c.gates)t={0,11,11};c.output=11;auto s=e.score(c,16);req(s.fn==16&&s.fp==0,"false control");c.output=12;s=e.score(c,1);req(s.fn==0&&s.fp==125,"true control");
 std::cout<<"PASS UBSan independent_reference circuits="<<circuits<<" scalar_checks="<<scalar_checks<<" vector_bit_checks="<<vector_checks<<" weighted_scores="<<score_checks<<" exact22_controls="<<exact_controls<<" singleton_bits=192 bit_pairs=36864 invalid_indices=2 tail_bits=51\n";return 0;
}catch(const std::exception&x){std::cerr<<"FAIL "<<x.what()<<"\n";return 1;}
