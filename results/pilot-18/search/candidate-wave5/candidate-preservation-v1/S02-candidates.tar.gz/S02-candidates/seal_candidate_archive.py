"""Seal prior candidate evidence; no solver, build, network or repository write."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import re
import tarfile

ROOT = Path('/tmp/oec/pequalnp-pilot-18'); HERE = ROOT/'orch/S02'
STAGE = HERE/'preservation-stage/S02-candidates'
REPRO = HERE/'consolidated-reconstruction'
OUT = HERE/'candidate-preservation-v1'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def write_json(path, data):
    with path.open('x') as f:
        f.write(json.dumps(data, indent=2)+'\n')


def copy(source, dest):
    assert source.is_file() and not source.is_symlink()
    with dest.open('xb') as f:
        f.write(source.read_bytes())


assert not OUT.exists() and not (STAGE/'MANIFEST.json').exists()
bindings = json.loads((HERE/'consolidated-copy-bindings.json').read_text())
for row in bindings['files']:
    source = Path(row['source']); copied = STAGE/row['archive']
    assert source.read_bytes() == copied.read_bytes()
    assert len(copied.read_bytes()) == row['bytes'] and sha(copied.read_bytes()) == row['sha256']

embedded_counts = {}
for relative, original in [('positive-repairs/full-results.json',ROOT/'positive-candidate-pilot'),
                           ('dirty22-window-repairs/full-results.json',ROOT/'dirty22-window-pilot')]:
    files = json.loads((STAGE/relative).read_text())['files']
    assert set(files) == {p.name for p in original.iterdir()}
    for name, row in files.items():
        raw = row['content'].encode()
        assert sha(raw) == row['sha256'] and raw == (original/name).read_bytes()
    embedded_counts[relative] = len(files)
for relative in ['positive-repairs/controls-full-results.json']:
    files = json.loads((STAGE/relative).read_text())['files']
    for name, row in files.items():
        raw = row['content'].encode()
        assert sha(raw) == row['sha256'] and raw == (HERE/'positive-controls'/name).read_bytes()
    embedded_counts[relative] = len(files)

positive = json.loads((ROOT/'positive-candidate-pilot/portfolio.json').read_text())
dirty = json.loads((ROOT/'dirty22-window-pilot/portfolio.json').read_text())
assert positive.get('finished') and len(positive['cases']) == 2
assert all(v['exit_code'] == 0 and v['status_lines'] == ['s UNKNOWN'] for v in positive['cases'].values())
assert dirty.get('finished') and len(dirty['cases']) == 6
assert all(v['exit_code'] == 20 and v['status_lines'] == ['s UNSATISFIABLE'] for v in dirty['cases'].values())

repro = json.loads((REPRO/'validation.json').read_text())
assert repro['status'] == 'PASS_EXACT_CNF_RECONSTRUCTION'
assert len(repro['files']) == 68 and sum(r['file'].endswith('.cnf') for r in repro['files']) == 28
assert len(repro['commands']) == 8 and all(r['exit_code'] == 0 for r in repro['commands'])
assert not repro['solver_launched'] and not repro['network_used'] and not repro['Lean_built']
for row in repro['files']:
    assert sha((REPRO/row['family']/row['file']).read_bytes()) == row['sha256']
recipe = json.loads((STAGE/'reconstruction.json').read_text())
for row in recipe['stage_sources']:
    assert sha((STAGE/row['package_path']).read_bytes()) == row['sha256']

validation = STAGE/'validation'; validation.mkdir()
copy(REPRO/'validation.json', validation/'reconstruction-validation.json')
copy(HERE/'consolidated-copy-bindings.json', STAGE/'copy-bindings.json')
for p in sorted(REPRO.iterdir()):
    if p.is_file() and p.suffix in ('.stdout','.stderr'):
        copy(p, validation/p.name)
for name in ['consolidated-reconstruction.stdout.txt','consolidated-reconstruction.stderr.txt',
             'consolidation.stdout.txt','consolidation.stderr.txt']:
    copy(HERE/name, validation/name)
copy(Path(__file__), STAGE/'seal_candidate_archive.py')

patterns = [re.compile(r'github_pat_[A-Za-z0-9_]{30,}'),
            re.compile(r'gh[pousr]_[A-Za-z0-9_]{20,}'),
            re.compile(r'[?&]lease=[A-Za-z0-9_-]{16,}'),
            re.compile(r'-----BEGIN [A-Z ]*PRIVATE KEY-----')]
rows = []
for p in sorted(STAGE.rglob('*')):
    assert not p.is_symlink()
    if p.is_dir(): continue
    assert p.is_file() and p.suffix != '.cnf'
    raw = p.read_bytes(); decoded = raw.decode('utf-8')
    assert not any(pattern.search(decoded) for pattern in patterns), 'Sensitive value indicator; no content printed'
    rows.append({'path':str(p.relative_to(STAGE)),'bytes':len(raw),'sha256':sha(raw)})
manifest = {'scope':'Prior candidate records only; no exact21 witness, global exhaustion or accepted certificate.',
            'files':rows,'raw_CNF_members':0,'solver_binaries':0,
            'outcomes':{'positive_K3_UNKNOWN':2,'positive_local5_not_run':2,
                        'dirty22_UNSAT_UNCERTIFIED':6,'factor_cases_retired_unrun':18}}
write_json(STAGE/'MANIFEST.json',manifest)
OUT.mkdir()
archive = OUT/'S02-candidates.tar.gz'
with archive.open('xb') as compressed:
    with gzip.GzipFile(filename='',fileobj=compressed,mode='wb',mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w',format=tarfile.USTAR_FORMAT) as tar:
            for p in sorted(STAGE.rglob('*')):
                if not p.is_file(): continue
                raw = p.read_bytes(); info = tarfile.TarInfo('S02-candidates/'+str(p.relative_to(STAGE)))
                info.size = len(raw); info.mode = 0o644; info.uid = 0; info.gid = 0; info.mtime = 0
                tar.addfile(info,io.BytesIO(raw))
count = 0
with tarfile.open(archive,'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == len(rows)+1 and len({m.name for m in members}) == len(members)
    for m in members:
        path = PurePosixPath(m.name)
        assert m.isfile() and not path.is_absolute() and '..' not in path.parts
        assert path.parts[0] == 'S02-candidates' and not m.name.endswith('.cnf')
        raw = tar.extractfile(m).read()
        assert raw == (STAGE/Path(*path.parts[1:])).read_bytes(); count += 1
copy(STAGE/'MANIFEST.json',OUT/'manifest.json')
report = {'verdict':'PASS_SELF_PACKAGING_EXACT_COPIES_FULL_LOGS_RECONSTRUCTION_AND_ARCHIVE_ROUNDTRIP',
          'archive':archive.name,'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,
          'archive_regular_members':count,'manifest_sha256':sha((OUT/'manifest.json').read_bytes()),
          'sealing_source_sha256':sha(Path(__file__).read_bytes()),
          'exact_source_copies':len(bindings['files']),'embedded_full_file_checks':embedded_counts,
          'reconstruction_files':68,'reconstruction_CNF_files':28,'reconstruction_commands_exit0':8,
          'reconstruction_validation_sha256':sha((REPRO/'validation.json').read_bytes()),
          'credential_value_indicators':0,'lease_value_indicators':0,'raw_CNF_members':0,
          'outcomes':manifest['outcomes'],'blocking_findings':[],
          'scope':'Main independent review required before preservation push. No global/shard UNSAT, exact21 witness or Lean acceptance.',
          'solver_launched':False,'repository_changed':False}
write_json(OUT/'validation.json',report)
(OUT/'README.md').write_text('S02 prior candidate evidence: two UNKNOWN positive pilots, six uncertified local UNSAT windows, and eighteen unrun factor restrictions retired by reviewed mathematics. No exact21 witness or global/shard exhaustion.\n\n'
    'The archive contains complete sources, reviews, metadata, full logs, and standard-library-only exact reconstruction recipes. All28 historical CNFs and68 generated files were reproduced with exact SHA256 equality; raw CNFs and solver binaries are omitted. Extract into a fresh folder, read S02-candidates/README.md, then use reconstruct_all.py with a fresh scratch output path. No solver runs during reconstruction.\n\n'
    'MANIFEST.json binds every internal payload; external validation.json records exact-copy and round-trip checks. Main independently reviews before commit/push. Historical READY labels inside are superseded by explicit retirement records. New context-window pilots are a separate family and are not included in this prior-evidence snapshot.\n')
print(json.dumps(report))
