# S02 candidate preservation checkpoint

No exact21 witness or posted proof is in this archive. It contains complete
candidate records and two mathematically retired factor families.

| Family | Generated CNFs | Actual search outcomes |
| --- | ---: | --- |
|Positive F_G OR x9 repairs|4|Two K3 pilots UNKNOWN; two local5 formulas not run|
|Dirty22 deletion windows|6|All six solver UNSAT, exit20, **uncertified**|
|Triangle upper factors|12|Never run; retired by S04-reviewed joint bounds18/19 versus17prefix gates|
|Supports1280/1536/80|6|Never run; retired by S04-reviewed tight bound18 versus17prefix gates|

The six neighborhood UNSAT results have no proof checker or retained certificate.
They do not exhaust all circuits, the assigned shard, or the posted statement.
The retired-factor exclusions are reviewed mathematics with finite controls;
they are not Lean theorems or CNF UNSAT certificates. Historical READY and
individual-cost-feasible labels are preserved as history and superseded by the
retirement records and this README. No further blind short repetitions are queued.

Sources, generator/audit/controller reviews, three dirty22 input circuits, both
positive input circuits, metadata and full solver/controller stdout/stderr are
included. Synthetic known22 SAT models are controls only. Model validation and
normalization remain prerequisites for any future exact candidate, followed by
Lean verification. No solver executable, credential, lease value or raw CNF is
included. All archive members are regular files and are bound by MANIFEST.json.

## Exact reconstruction

Python3 and its standard library suffice. There are no downloads or installs.
The pinned source files use the original absolute scratch hierarchy, so the
reconstructor stages missing files only under `/tmp/oec/pequalnp-pilot-18`.
Existing different files cause rejection rather than overwrite. Active or
previous input CNFs are never edited; all generation uses a fresh output folder.

Regenerate the10 positive/dirty22 CNFs and verify every generated file hash:

```sh
python3 reconstruct_all.py /tmp/oec/pequalnp-pilot-18/s02-reconstruction-fresh
```

For historical reproduction of all28 CNFs, including retired restrictions:

```sh
python3 reconstruct_all.py /tmp/oec/pequalnp-pilot-18/s02-full-reconstruction-fresh \
  --include-retired
```

The optional path first regenerates the original and J18-normalized parents from
the bundled pinned sources, verifying both CNF and metadata hashes. It then
reproduces the retired factor files. This does not run a solver or claim a
certificate. Full generator stdout/stderr and a68-file validation record are
saved outside the archive in the requested output folder.

`reconstruction.json` binds every required source, seed, expected artifact hash,
and parent hash. The smaller archived positive-only recipe is retained with its
earlier successful14-file test and negative controls. `copy-bindings.json` records
the snapshot provenance. The top-level manifests supersede no source bytes.

This archive was prepared by S02; main independently reviews before commit/push.
