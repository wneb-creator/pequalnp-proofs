#!/usr/bin/env python3
"""Finite graph/position checks for tight-survivor-obstruction.md."""
from pathlib import Path
import hashlib
import itertools
import json

ROOT=Path(__file__).resolve().parent
E={(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
   (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)}
H={(1,8),(2,5),(2,10),(3,7),(5,8),(5,9),(7,9),(8,9)}
assert H=={e for e in E if not set(e)&{0,4,6}}
matching={(1,8),(2,10),(3,7),(5,9)}
cover={2,5,7,8}
assert matching<=H and len(set().union(*map(set,matching)))==2*len(matching)==8
assert all(set(e)&cover for e in H)
assert len(H)==8 and len(cover)==4
assert 2+len(H)+len(cover)-1==13
neighbors0={b if a==0 else a for a,b in E if 0 in (a,b)}
assert neighbors0=={9,10}
commonB={v for v in range(11) if all((min(v,t),max(v,t)) in E for t in (9,10))}
assert commonB=={0}
positions=[]
for a,b,c in itertools.permutations(range(13,17),3):
    if c<15:
        continue
    spare=next(i for i in range(13,17) if i not in (a,b,c))
    if not b<spare<c:
        continue
    assert b<=14
    assert not a<b or not b-a>=2  # A cannot precede B with room for an AND.
    positions.append(dict(A=a,B=b,C=c,q=spare,
                          B_ancestor_cone_gate_capacity=14,
                          required_P_index=12,
                          possible_intervening_indices=list(range(13,b))))
assert len(positions)==4
for row in positions:
    assert all(i==row['A'] for i in row['possible_intervening_indices'])
result=dict(verdict='PASS_FINITE_GRAPH_AND_POSITION_CONTROLS',
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    mathematical_argument_sha256=hashlib.sha256((ROOT/'tight-survivor-obstruction.md').read_bytes()).hexdigest(),
    positions=positions,partial_graph=sorted(H),matching=sorted(matching),cover=sorted(cover),
    partial_operand_lower_bound=13,shared_prefix_claimed_lower_bound=18,
    math_independent_review='PENDING',Lean_proof=False,solver_run=False,
    caveat='Finite controls do not independently establish the structural DAG/deletion argument.')
(ROOT/'tight-survivor-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'verdict':result['verdict'],'source_sha256':result['source_sha256'],
                  'position_cases':len(positions),'partial_operand_lower_bound':13}))
