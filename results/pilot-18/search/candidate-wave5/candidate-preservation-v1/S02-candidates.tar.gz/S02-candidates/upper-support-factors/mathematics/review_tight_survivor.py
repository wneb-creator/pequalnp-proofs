from pathlib import Path
import hashlib,itertools,json,time
O=Path('/tmp/oec/pequalnp-pilot-18/orch/S04');I=O.parent/'S01'
start=time.monotonic()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
handoff=json.loads((I/'joint-cost-handoff.json').read_text())
for r in handoff['files']:
 p=Path(r['path']);assert p.is_relative_to(I) and p.is_file() and not p.is_symlink()
 assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
assert len(handoff['files'])==18
assert sha(I/'tight-survivor-obstruction.md')=='69bb5f1587acceb0fd5ecebf3ed4a525919c439eef62c70a7c11e9ae149a1acc'
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
EM=[(1<<a)|(1<<b) for a,b in E]
def F(x):return any(x&e==e for e in EM)
# All late output schedules allowed by lower costs and B<q<C.
schedules=[]
for A,B,q,C in itertools.permutations(range(13,17)):
 if A>=13 and B>=13 and C>=15 and B<q<C:schedules.append(dict(A=A,B=B,q=q,C=C))
assert len(schedules)==4
for s in schedules:
 assert s['B'] in [13,14]
remaining=[e for e in E if 0 not in e and 4 not in e and 6 not in e]
matching=[(1,8),(2,10),(3,7),(5,9)];cover={2,5,7,8}
assert len(remaining)==8 and set(matching)<=set(remaining)
assert len({v for e in matching for v in e})==8
assert all(cover&set(e) for e in remaining)
assert 2+8+4-1==13

def ev(gates,x):
 v=[bool(x>>i&1) for i in range(11)]+[False,True]
 for op,a,b in gates:v.append(v[a] and v[b] if op=='and' else v[a] or v[b])
 return v
controls=[]
for mode in range(8):
 gates=[]
 def add(op,a,b):gates.append((op,a,b));return 12+len(gates)
 def OR(xs):
  xs=list(xs);r=xs[0]
  for w in xs[1:]:r=add('or',r,w)
  return r
 edges={e:add('and',*e) for e in E}
 r=OR([0,edges[(2,5)]]) if mode&1 else 0
 if mode&2:
  zero=add('or',11,11);r=add('or',r,zero);r=add('or',r,r)
 else:zero=11
 v=OR([9,edges[(1,4)]])
 q=add('and',r,v)
 pure=OR([9,10])
 if mode&4:pure=add('or',pure,pure)
 w=OR([pure]+[edges[e] for e in E if not ({9,10}&set(e))]+[q])
 if mode&2:w=add('or',w,zero)
 old=[ev(gates,x) for x in range(2048)]
 support=lambda wire:sum(1<<v for v in range(11) if old[1<<v][wire])
 assert support(r)==1 and support(w)==1536
 assert any(F(x) and not old[x][r] for x in range(2048)), 'R must NOT cover F'
 for g,(op,a,b) in enumerate(gates):
  if op=='and':
   assert support(a) and support(b)
   assert all(not old[x][g+13] for x in range(2048) if not F(x))
 assert all(old[x][w]==(F(x) or bool(x&1536)) for x in range(2048))
 cone=set()
 def visit(wire):
  if wire<13 or wire in cone:return
  cone.add(wire);_,a,b=gates[wire-13];visit(a);visit(b)
 visit(w)
 oa=set()
 def orvisit(wire):
  if wire in oa:return
  oa.add(wire)
  if wire>=13 and gates[wire-13][0]=='or':
   _,a,b=gates[wire-13];orvisit(a);orvisit(b)
 orvisit(w)
 zero_wires={9,10,11}
 for g,(op,a,b) in enumerate(gates):
  if op=='or' and a in zero_wires and b in zero_wires:zero_wires.add(13+g)
 pure_gates={x for x in oa&zero_wires if x>=13};boundary={}
 for wire in oa-zero_wires:
  if wire>=13:
   op,a,b=gates[wire-13]
   if op=='or' and ((a in zero_wires)!=(b in zero_wires)):boundary[wire]=b if a in zero_wires else a
 assert len(pure_gates)+len(boundary)>=2
 assert q not in pure_gates and q not in boundary and q in cone
 remap={i:11 if i in(9,10) else i for i in range(13)};new=[]
 for g,(op,a,b) in enumerate(gates):
  wire=13+g
  if wire not in cone:continue
  if wire==q:remap[wire]=remap[v]
  elif wire in pure_gates:remap[wire]=11
  elif wire in boundary:remap[wire]=remap[boundary[wire]]
  else:new.append((op,remap[a],remap[b]));remap[wire]=12+len(new)
 assert len(new)<=len(cone)-3
 independent_checks=0;pointwise_checks=0;strict_edge_gains=[]
 for x in range(2048):
  if x&1536:continue
  nv=ev(new,x)
  for wire in cone:
   assert old[x][wire]<=nv[remap[wire]];pointwise_checks+=1
   if not F(x):assert old[x][wire]==nv[remap[wire]];independent_checks+=1
  assert nv[remap[w]]==F(x)
  if x in EM and old[x][q]<nv[remap[q]]:strict_edge_gains.append(x)
 assert 18 in strict_edge_gains # edge(1,4): local equality is deliberately false
 controls.append(dict(mode=mode,original_gates=len(gates),cone_gates=len(cone),reduced_gates=len(new),pure_OR_count=len(pure_gates),boundary_OR_count=len(boundary),charged_AND=q,replacement=v,strict_edge_gains=strict_edge_gains,independent_wire_equalities=independent_checks,pointwise_wire_nondecreases=pointwise_checks,gates=gates,output=w,reduced_circuit=new,redirect=remap))
result=dict(verdict='PASS_TIGHT_SURVIVOR_MATHEMATICS_AND_LOCAL_CONTROLS',source_sha256=sha(Path(__file__)),reviewed_math_sha256=sha(I/'tight-survivor-obstruction.md'),handoff_sha256=sha(I/'joint-cost-handoff.json'),handoff_artifacts_verified=18,late_schedules=schedules,forced_P_edges=remaining,matching_size4=matching,cover_size4=sorted(cover),partial_P_bound=13,nonfullcover_ancestor_controls=controls,independent_wire_equalities=sum(c['independent_wire_equalities'] for c in controls),pointwise_wire_nondecreases=sum(c['pointwise_wire_nondecreases'] for c in controls),mathematical_conclusion='The exact full-cover support triple {8,10},{9,10},{4,6} needs at least18 productive clean prefix gates, independent of output positions.',scope='No conclusion about other support families, dirty prefixes, or global <=21 circuits; no Lean or UNSAT certificate.',seconds=time.monotonic()-start,solver_run=False,Lean_build=False)
(O/'tight-survivor-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['verdict','source_sha256','reviewed_math_sha256','handoff_artifacts_verified','independent_wire_equalities','pointwise_wire_nondecreases','seconds']}))
print('Eight actual DAG controls include strict residual edge-value increases; all negative rows preserved.')
