"""Fresh candidate-only exact factors F_G OR OR(S), with a fixed17gate prefix.

Six orders of supports {8,10}, {9,10}, {4,6}; no solver or WLOG claim.
"""
from pathlib import Path
import argparse
import copy
import hashlib
import importlib.util
import itertools
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path('/tmp/oec/pequalnp-pilot-18')
PARENT = ROOT / 'orch/S01/consecutive-junk-v2/normalized.cnf'
HELPER_SHA = 'e24f9c066ab8a37fa9dbe0d028acb594b8d6d8bc83e9f482fd62e8a390920538'
SUPPORTS = (1280,1536,80)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def encode(value):
    return (json.dumps(value, indent=2) + '\n').encode()


def helper():
    path = ROOT / 'orch/S02/generate_triangle_factors.py'
    require(sha(path.read_bytes()) == HELPER_SHA, 'Parent-reader helper SHA mismatch')
    spec = importlib.util.spec_from_file_location('reviewed_factor_parent_reader', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def factor(base, mask, support):
    return bool(base.target(mask) or mask & support)


def cost(base, support):
    vertices = [v for v in range(11) if support >> v & 1]
    residual = [(a,b) for a,b in base.EDGES if a not in vertices and b not in vertices]
    cover = min(mask.bit_count() for mask in range(2048)
                if all(mask >> a & 1 or mask >> b & 1 for a,b in residual))
    common = [v for v in range(11) if all((min(v,u),max(v,u)) in base.EDGES for u in vertices)]
    return {'support_mask':support,'support_vertices':vertices,'common_neighbors':common,
            'residual_edges':residual,'residual_cover_size':cover,
            'clean_wire_gate_lower_bound':len(vertices)+len(residual)+cover-1}


def pin_units(base, meta, order):
    require(sorted(order) == sorted(SUPPORTS), 'Invalid support permutation')
    units = []
    for wire,support in zip((27,28,29),order):
        units += [[lit if support >> v & 1 else -lit] for v,lit in enumerate(meta['prefix_support_tables'][wire])]
        units += [[lit] for lit in meta['prefix_edge_tables'][wire]]
    for g,(_,a,b) in zip(range(17,21),base.SUFFIX):
        units += [[meta['ops'][g]],[meta['lefts'][g][a]],[meta['rights'][g][b]]]
    require(len(units) == 93 and len({abs(c[0]) for c in units}) == 93, 'Wrong unit delta')
    return units


def generate(parent, output):
    require(not output.exists(), 'Output directory must be fresh')
    base = helper()
    body,meta = base.read_parent(parent)
    costs = {support:cost(base,support) for support in SUPPORTS}
    require([costs[s]['clean_wire_gate_lower_bound'] for s in SUPPORTS] == [14,14,16], 'Unexpected individual cost')
    require([costs[s]['common_neighbors'] for s in SUPPORTS] == [[4],[0],[10]], 'Unexpected common neighbors')
    require(all(meta['support_cost_bounds'][s] == costs[s]['clean_wire_gate_lower_bound'] for s in SUPPORTS), 'Parent cost-table disagreement')
    require(all(all(factor(base,m,s) for s in SUPPORTS) == base.target(m) for m in range(2048)), 'Factor product identity fails')
    output.mkdir(parents=True,exist_ok=False)
    program_sha = sha(Path(__file__).read_bytes())
    family = {'kind':'candidate_only_exact_upper_support_factors','complete':False,
              'program_sha256':program_sha,'parent_reader_helper_sha256':HELPER_SHA,
              'parent_sha256':base.PARENT_SHA,'parent_metadata_sha256':base.META_SHA,
              'supports':list(SUPPORTS),'factor_costs':costs,'fixed_factor_wires':[27,28,29],
              'fixed_suffix':base.SUFFIX,'effective_gate_upper_bound_after_two_copies_removed':19,
              'claimed_WLOG':False,'assigned_shard_exhaustion':False,'solver_launched':False,'cases':[]}
    for order in itertools.permutations(SUPPORTS):
        units = pin_units(base,meta,order)
        constraints = [{'wire':27+i,'gate_index':14+i,'available_prefix_gates':15+i,
                        **costs[s],'cost_feasible':costs[s]['clean_wire_gate_lower_bound'] <= 15+i}
                       for i,s in enumerate(order)]
        feasible = all(row['cost_feasible'] for row in constraints)
        name = 'support-order-'+'-'.join(map(str,order))
        added = ''.join(str(c[0])+' 0\n' for c in units).encode('ascii')
        raw = f'p cnf {meta["variables"]} {meta["clauses"]+len(units)}\n'.encode('ascii')+body+added
        child = copy.deepcopy(meta)
        child.update(sha256=sha(raw),clauses=meta['clauses']+len(units),candidate_only=True,
                     assigned_shard_exhaustion=False,upper_factor_program_sha256=program_sha,
                     upper_factor_parent_sha256=base.PARENT_SHA,upper_factor_helper_sha256=HELPER_SHA,
                     upper_factor_support_order=list(order),upper_factor_constraints=constraints,
                     upper_factor_added_units=units,upper_factor_fixed_suffix=base.SUFFIX,
                     upper_factor_cost_feasible=feasible,upper_factor_claimed_WLOG=False,
                     upper_factor_boundary_values=[[factor(base,m,s) for m in meta['rows']] for s in order],
                     operation_case='AAAA',research_status='CANDIDATE_GENERATED_NO_SOLVER_VERDICT')
        path = output/(name+'.cnf')
        path.write_bytes(raw);path.with_suffix('.json').write_bytes(encode(child))
        family['cases'].append({'case':name,'support_order':list(order),'cost_feasible':feasible,
            'variables':meta['variables'],'clauses':child['clauses'],'added_unit_clauses':len(units),
            'cnf_sha256':sha(raw),'metadata_sha256':sha(path.with_suffix('.json').read_bytes())})
    family['complete'] = True
    family['cost_feasible_case_count'] = sum(row['cost_feasible'] for row in family['cases'])
    (output/'family.json').write_bytes(encode(family))
    return family


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output',type=Path)
    parser.add_argument('--parent',type=Path,default=PARENT)
    args = parser.parse_args()
    result = generate(args.parent,args.output)
    print(json.dumps({'cases':len(result['cases']),'cost_feasible':result['cost_feasible_case_count'],
                      'program_sha256':result['program_sha256'],'solver_launched':False}))
