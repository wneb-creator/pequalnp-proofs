# Tight surviving triple: proposed shared-prefix lower bound18

Pending independent review. No Lean or UNSAT certificate; no CNF change.

Let A,B,C be full-cover outputs of a productive clean prefix on the concrete
graph, with singleton supports respectively

    A:{8,10}, B:{9,10}, C:{4,6}.

Their individual ancestor lower bounds are14,14,16. Their unique common
neighbors are4,0,10. Their product is F and every proper subproduct is dirty.
I claim that these three outputs cannot coexist in17prefix gates.

## A small strengthening of the restriction charge

Suppose W is a proper-support full-cover output with support S and nonempty
residual graph. Suppose an ancestor signal R has nonempty singleton support T,
T not contained in S, and every common neighbor of T lies in S. The signal R
need not itself cover F.

Follow a path from R to W to its first AND q. Such a gate exists because an
OR-only path would give T subset S. One operand U contains R through OR-only
ancestry. The other operand V has nonempty support, by productivity, and
support V subset commonNeighbors(T) subset S, by cleanliness.

Restrict S to zero. Then V is false on all independent residual inputs, just
as the clean q is. Replace q by V: this keeps every independent-input value
unchanged and can only increase edge values, since U AND V <= V. Therefore
all later gates stay clean, the output still accepts every residual edge and
has empty singleton support. It deletes an AND in addition to the at least
|S| OR gates deleted by the pure-S OR-DAG argument. The actual-circuit
partial-edge theorem now gives an ancestor lower bound L(S)+1 for W.

The only new point versus the reviewed joint charge is permitting non-full-
cover R. Exact equality on residual edge rows is unnecessary: nondecrease
suffices for the partial-edge theorem. If simplification already deleted q,
its extra AND deletion has already been counted. OR and AND charges are
distinct original gate nodes.

## The late prefix has only one possible intervening AND

Assume at most17prefix gates; number them0..16, padding dead gates if needed.
All three outputs are distinct OR gates: AND outputs are clean with empty
support, and the specified supports are nonempty and not raw inputs.

The individual cost bounds put A and B at indices at least13, and C at an
index at least15. Hence these three output gates occupy three of positions
13,14,15,16. There is at most one other gate in those four positions.

By the reviewed joint argument for C, the owner4 of A contributes one charge
above L(C)=16. If B were outside C's ancestor cone it would contribute an
additional, distinct outside output gate, requiring18prefix gates. Thus B
is an ancestor of C.

Their supports are incomparable, so that path has an AND. Let q be its first
AND. It is the one unselected gate in positions13..16. There are no available
OR intermediates on the B-to-q path: A's support does not contain B's support,
and C follows q. Consequently one input of q is B itself. Its other input R
has support exactly {0}, because commonNeighbors({9,10})={0} and q is
productive. The final path into C is likewise direct: A cannot be an OR
intermediate because its support is not contained in C's. Therefore

    q = B AND R,       C = q OR P,

where support R={0} and support P={4,6}. Both R and P are inputs or gates at
indices at most12: they cannot be A,B,C or q, whose supports differ.

No selected output A or C can be an ancestor of B. C is later. An A-to-B
path would need an intervening AND because their supports are incomparable,
but the only such late gate is q, which is later than B. Thus the entire
ancestor cone of B is contained in the thirteen gates0..12 plus B itself.
Its individual lower bound14 forces all thirteen earlier gates to belong to
that cone. In particular B is gate13 or14, and any intervening gate is A,
which is not an ancestor of B.

## The other AND operand must be raw input0

If R were a gate among0..12, it would be an ancestor of B. Apply the small
restriction charge with T={0}, S={9,10}. The concrete neighbor set of0 is
exactly {9,10}, so the hypotheses hold and B would need at least15ancestor
gates, contradicting the exact14 just proved. R therefore is an input.
Its singleton support is {0}, so it is raw x0 (neither free constant has
that support). Thus q=x0 AND B.

## The other OR operand is too late for B's ancestor cone

On every target edge not incident to0, q is false. Since C accepts all target
edges, P accepts every such edge. Its support is {4,6}, so apply the actual
partial-support bound to these eight edges outside that support:

    (1,8),(2,5),(2,10),(3,7),(5,8),(5,9),(7,9),(8,9).

This graph has vertex-cover number4. One cover is {2,5,7,8}; a matching of
size4 is {(1,8),(2,10),(3,7),(5,9)}, proving the lower bound without exhaustive
enumeration. The partial-support theorem therefore gives

    ancestors(P) >= 2+8+4-1 = 13.

P is a gate among0..12, so it must be gate12 and must use all thirteen gates
through itself. Every one of these gates is also an ancestor of B. Since
there is no intervening ancestor gate between gate12 and B, P must be a
direct input of B. But B is OR, so support(P)={4,6} would be contained in
support(B)={9,10}, a contradiction.

Thus this support family needs at least18gates in a productive clean prefix.
The argument allows repeated operands, constants, aliases, dead gates and
any output ordering. It uses exact ancestor lower bounds and the reviewed
productive normalization; it never assumes that selected outputs form an
ancestry antichain. It says nothing about other surviving support families.
