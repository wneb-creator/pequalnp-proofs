# Retired support triple1280/1536/80

The three exact upper factors have supports `{8,10}`, `{9,10}`, `{4,6}`.
Their product is F_G on all2048 inputs. The six permutations were encoded at the
last three prefix gates, with exactly93unit clauses appended to the unchanged
J18 parent. All source, truth-table, byte-delta and reproduction controls passed.

No case was solved. S04 subsequently reviewed S01's tight-survivor argument:
these factors require at least18gates in a productive clean prefix, while the
parent provides17. All six are retired, including the four that passed individual
cost bounds. The mathematical review source/results/logs are preserved here.
This is not a Lean theorem or an UNSAT certificate and excludes no unrestricted
size21 circuit outside the stated factor family.

The copy suffix would normalize to two ANDs, so any successful prefix would have
given at most19effective gates. Historical READY labels in the original audit
are superseded by `retirement.json`. The archive's optional retired reconstruction
reproduces all CNF bytes for history; it never launches a solver.
