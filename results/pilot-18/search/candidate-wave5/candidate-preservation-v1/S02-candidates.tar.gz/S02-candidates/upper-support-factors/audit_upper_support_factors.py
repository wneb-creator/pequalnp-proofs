"""Bounded independent truth/cost/CNF-delta controls; no solver."""
from pathlib import Path
import hashlib
import importlib.util
import itertools
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path('/tmp/oec/pequalnp-pilot-18')
HERE = ROOT/'orch/S02'
OUT = HERE/'upper-support-controls'
OUT.mkdir(exist_ok=False)
FAMILY = HERE/'upper-support-factors'
PARENT = ROOT/'orch/S01/consecutive-junk-v2/normalized.cnf'
sha = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source = HERE/'generate_upper_support_factors.py'
spec = importlib.util.spec_from_file_location('upper_support_generator',source)
g = importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
base = g.helper()
raw_parent=PARENT.read_bytes();parent=json.loads(PARENT.with_suffix('.json').read_text())
assert sha(PARENT)=='3fefefe3949bc703fc2b9f023be12bc42f1afe7619e8ed5ed63be2f8e7648812'
assert sha(PARENT.with_suffix('.json'))=='a7425759cf64d1eef6ccd281dedf0c2e67049b88ce335a4ac166fcc0d077e19b'
body=raw_parent.split(b'\n',1)[1]
manifest=json.loads((FAMILY/'family.json').read_text())
assert manifest['complete'] and manifest['program_sha256']==sha(source)
edges={(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)}
supports={1280:{8,10},1536:{9,10},80:{4,6}}
target=[];values={s:[] for s in supports}
for mask in range(2048):
    vertices={v for v in range(11) if mask & (1<<v)}
    truth=any({a,b}<=vertices for a,b in edges);target.append(truth)
    for s,vertices_s in supports.items():
        values[s].append(truth or bool(vertices & vertices_s))
        assert values[s][-1] == g.factor(base,mask,s)
    assert all(values[s][-1] for s in supports)==truth
negative=[m for m in range(2048) if not target[m]]
assert len(negative)==125
for a,b in itertools.combinations(supports,2):
    assert any(values[a][m] and values[b][m] for m in negative)
costs={};owners={}
for s,vertices in supports.items():
    residual=[(a,b) for a,b in edges if a not in vertices and b not in vertices]
    tau=next(k for k in range(12) if any(all(a in c or b in c for a,b in residual)
                                        for c in itertools.combinations(range(11),k)))
    costs[s]=len(vertices)+len(residual)+tau-1
    owners[s]=[v for v in range(11) if all((min(v,u),max(v,u)) in edges for u in vertices)]
    assert costs[s]==parent['support_cost_bounds'][s]==manifest['factor_costs'][str(s)]['clean_wire_gate_lower_bound']
    assert owners[s]==manifest['factor_costs'][str(s)]['common_neighbors']
assert costs=={1280:14,1536:14,80:16} and owners=={1280:[4],1536:[0],80:[10]}
joint={s:costs[s]+len({owners[t][0] for t in supports if t!=s and owners[t][0] in supports[s]})
       for s in supports}
assert joint=={1280:15,1536:15,80:17}

cases=[];seen=set();suffix_checks=0
for item in manifest['cases']:
    order=tuple(item['support_order']);assert set(order)==set(supports) and order not in seen;seen.add(order)
    path=FAMILY/(item['case']+'.cnf');raw=path.read_bytes();meta=json.loads(path.with_suffix('.json').read_text())
    assert sha(path)==item['cnf_sha256']==meta['sha256']
    assert sha(path.with_suffix('.json'))==item['metadata_sha256']
    units=[]
    for wire,s in zip((27,28,29),order):
        units.extend([lit if v in supports[s] else -lit] for v,lit in enumerate(parent['prefix_support_tables'][wire]))
        for mask,lit in zip(parent['rows'][:16],parent['prefix_edge_tables'][wire]):
            assert values[s][mask];units.append([lit])
    suffix=[(27,27),(30,30),(28,31),(29,32)]
    for gate,(a,b) in zip(range(17,21),suffix):
        units += [[parent['ops'][gate]],[parent['lefts'][gate][a]],[parent['rights'][gate][b]]]
    assert len(units)==93 and len({abs(c[0]) for c in units})==93
    assert raw==b'p cnf 11968 114660\n'+body+''.join(str(c[0])+' 0\n' for c in units).encode()
    assert meta['upper_factor_added_units']==units
    assert meta['upper_factor_boundary_values']==[[values[s][m] for m in parent['rows']] for s in order]
    feasible=all(costs[s]<=15+i for i,s in enumerate(order))
    assert feasible==item['cost_feasible']==meta['upper_factor_cost_feasible']
    assert meta['candidate_only'] and not meta['assigned_shard_exhaustion'] and not meta['upper_factor_claimed_WLOG']
    assert meta['first_junk']==17 and meta['second_junk'] and meta['consecutive_junk']
    assert meta['live'] and meta['last_output'] and meta['productive_prefix']
    wire_values={27+i:values[s] for i,s in enumerate(order)}
    for gate,(a,b) in zip(range(17,21),suffix):
        wire_values[13+gate]=[x and y for x,y in zip(wire_values[a],wire_values[b])]
    assert wire_values[33]==target
    assert all(any(wire_values[13+gate][m] for m in negative) for gate in (17,18,19))
    assert not any(wire_values[33][m] for m in negative)
    suffix_checks+=2048
    cases.append({'case':item['case'],'cnf_sha256':sha(path),'metadata_sha256':sha(path.with_suffix('.json')),
                  'exact_93_unit_delta':True,'cost_feasible':feasible})
assert seen==set(itertools.permutations(supports)) and sum(x['cost_feasible'] for x in cases)==4
for bad_order in [(1280,1280,80),(1280,1536),(1280,1536,81)]:
    try:g.pin_units(base,parent,bad_order)
    except ValueError:pass
    else:raise AssertionError('Invalid order accepted')
try:g.generate(PARENT,FAMILY)
except ValueError:pass
else:raise AssertionError('Existing output accepted')
g.generate(PARENT,OUT/'reproduced')
names=sorted(p.name for p in FAMILY.iterdir())
assert len(names)==13 and all((FAMILY/n).read_bytes()==(OUT/'reproduced'/n).read_bytes() for n in names)
review={'verdict':'PASS_BOUNDED_SELF_AUDIT_READY_MAIN_REVIEW','generator_sha256':sha(source),
        'audit_sha256':sha(Path(__file__)),'parent_reader_helper_sha256':g.HELPER_SHA,
        'manifest_sha256':sha(FAMILY/'family.json'),'case_count':6,'cost_feasible_case_count':4,
        'scalar_factor_values':3*2048,'product_identity_rows':2048,'suffix_rows':suffix_checks,
        'exact_delta_cases':cases,'individual_bounds':costs,'common_neighbors':owners,
        'reviewed_joint_charge_formula_values':joint,'maximum_joint_relaxation_bound':17,
        'invalid_order_rejections':3,'existing_output_rejected':True,'byte_identical_reproduction_files':13,
        'blocking_findings':[],'solver_launched':False,
        'limits':['Passing individual and joint lower bounds does not construct a17gate shared prefix.',
                  'Fixed exact factors and output slots are candidate-only restrictions, not WLOG.',
                  'Two suffix copies normalize away; this family seeks at most19effective gates.',
                  'Full factor oracle/suffix checks do not supply a satisfying model of the parent CNF.']}
p=HERE/'upper-support-review.json';p.write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'review':str(p),'sha256':sha(p),'generator_sha256':sha(source),'cases':6,'cost_feasible':4}))
