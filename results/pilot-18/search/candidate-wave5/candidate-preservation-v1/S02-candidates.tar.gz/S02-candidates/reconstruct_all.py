"""Restore hash-pinned CNFs in fresh scratch; no solver, network, or Lean."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def within(root, relative):
    name=Path(relative)
    if name.is_absolute() or '..' in name.parts:
        raise ValueError('Unsafe relative path')
    path=root/name
    if path.is_symlink() or not path.resolve().is_relative_to(root.resolve()):
        raise ValueError('Path escapes its root or is a symlink')
    return path


def main(output, include_retired):
    package=Path(__file__).resolve().parent
    recipe=json.loads((package/'reconstruction.json').read_text())
    root=Path(recipe['scratch_root'])
    if root!=Path('/tmp/oec/pequalnp-pilot-18') or root.resolve()!=root:
        raise ValueError('Unexpected or redirected scratch root')
    output=output.resolve()
    if output.exists() or not output.is_relative_to(root):
        raise ValueError('Fresh output directory inside named scratch root required')
    missing=[]
    for row in recipe['stage_sources']:
        raw=within(package,row['package_path']).read_bytes()
        if digest(raw)!=row['sha256']:raise ValueError('Packaged source hash mismatch')
        destination=within(root,row['scratch_path'])
        if destination.exists():
            if not destination.is_file() or destination.read_bytes()!=raw:
                raise ValueError('Existing scratch source differs; refusing to overwrite')
        else:missing.append((destination,raw))
    for path,raw in missing:
        path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('xb') as stream:stream.write(raw)
    output.mkdir(parents=True,exist_ok=False)
    commands=[]

    def run(label,arguments):
        argv=[sys.executable,'-B',*map(str,arguments)]
        with (output/(label+'.stdout')).open('x') as out,(output/(label+'.stderr')).open('x') as err:
            result=subprocess.run(argv,stdout=out,stderr=err,timeout=120)
        commands.append({'label':label,'argv':argv,'exit_code':result.returncode})
        if result.returncode:raise RuntimeError('Generator failed; full logs preserved')

    parent=None
    if include_retired:
        base=output/'parent-base';original=output/'parent-original';normalized=output/'parent-normalized'
        run('parent-base',[root/'search_l1342_shard17_ancestorreverse.py','--distinct-prefix',base])
        run('parent-original',[root/'build_original_strong.py',base/'prefix-distinct.cnf',original])
        for name in ['original.cnf','original.json']:
            if digest((original/name).read_bytes())!=recipe['parent_hashes'][name]:
                raise ValueError('Original parent hash mismatch')
        run('parent-normalized',[root/'orch/S01/build_consecutive_junk.py',original/'original.cnf',normalized])
        for name in ['normalized.cnf','normalized.json']:
            if digest((normalized/name).read_bytes())!=recipe['parent_hashes'][name]:
                raise ValueError('Normalized parent hash mismatch')
        parent=normalized/'normalized.cnf'

    checked=[];skipped=[]
    for family in recipe['families']:
        kind=family['kind'];destination=within(output,family['name'])
        if kind in ['upper','triangle'] and not include_retired:
            skipped.append(family['name']);continue
        label=family['name'].replace('/','-')
        if kind=='positive':
            args=[root/'orch/S02/prepare_positive_repairs.py',within(root,family['source_scratch_path']),
                  destination,'--budgets',*map(str,family['budgets']),'--local-counts',*map(str,family['local_counts'])]
        elif kind=='dirty22':args=[root/'orch/S02/generate_dirty22_window_repairs.py',destination]
        elif kind in ['upper','triangle']:
            script='generate_upper_support_factors.py' if kind=='upper' else 'generate_triangle_factors.py'
            args=[root/'orch/S02'/script,destination,'--parent',parent]
        else:raise ValueError('Unknown family kind')
        run(label,args)
        expected=family['expected_files_sha256']
        if {p.name for p in destination.iterdir()}!=set(expected):raise ValueError('Generated file set mismatch')
        for name,wanted in expected.items():
            actual=digest(within(destination,name).read_bytes())
            if actual!=wanted:raise ValueError('Generated file hash mismatch')
            checked.append({'family':family['name'],'file':name,'sha256':actual})
    report={'status':'PASS_EXACT_CNF_RECONSTRUCTION','files':checked,'commands':commands,
            'skipped_retired_families':skipped,'included_retired_as_historical_generation_only':include_retired,
            'solver_launched':False,'network_used':False,'Lean_built':False}
    (output/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'status':report['status'],'files':len(checked),'CNFs':sum(x['file'].endswith('.cnf') for x in checked)}))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output',type=Path)
    parser.add_argument('--include-retired',action='store_true',help='Historical reproduction only; never a search launch.')
    args=parser.parse_args();main(args.output,args.include_retired)
