"""Exact dirty22 deletion intake and small repair-window ranking; no CNF/solver."""
from pathlib import Path
from itertools import combinations
from collections import deque
import datetime
import hashlib
import importlib.util
import json
import sys
import time

sys.dont_write_bytecode=True
ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S05'
SOURCE=HERE/'shared-factor-compact-complete.json'
PIN='0cd2e6eaa92e2a5cd95d1bd20728ad9157e80b9e88a728ad7033f8af420c1299'
HELPER=ROOT/'lean-setup/generate_local_repairs.py'
HPIN='857f7082cb81bda879891aba76a84e59f0a1b030f6c6c0eccf08f507cf96cd97'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')

def main():
    start=time.monotonic();assert sha(SOURCE)==PIN and sha(HELPER)==HPIN
    spec=importlib.util.spec_from_file_location('unchanged_local_repair_helper',HELPER)
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    source=json.loads(SOURCE.read_text());gates=source['gates']
    outdir=HERE/'dirty22-deletions';outdir.mkdir(exist_ok=False)
    negatives=[m for m in range(2048) if not helper.target(m) and all(m>>v&1 or helper.target(m|(1<<v)) for v in range(11))]
    rows=[(1<<a)|(1<<b) for a,b in helper.EDGES]+negatives
    assert len(rows)==40 and len(negatives)==24
    full=(1<<40)-1;pos=(1<<16)-1;neg=full^pos
    inputs=[sum(1<<i for i,m in enumerate(rows) if m>>v&1) for v in range(11)]+[0,full]
    original_readers={g:[i for i,row in enumerate(gates) if 11+g in row[1:]] for g in range(22)}
    assert all(len(original_readers[g])==1 for g in range(21))
    entries=[];all_windows=[];compares=0
    for deleted in range(22):
        for side in (0,1):
            case=f'd{deleted:02d}-'+('left' if side==0 else 'right')
            alias=gates[deleted][1+side]
            def move(w):
                if w<11:return w
                old=w-11
                if old==deleted:return move(alias)
                return 13+old-(old>deleted)
            candidate=dict(inputs=11,gate_wire_offset=13,size=21,
                           gates=[[op,*sorted((move(a),move(b)))] for i,(op,a,b) in enumerate(gates) if i!=deleted],
                           output=move(source['output']))
            assert all(0<=a<=b<13+g for g,(_,a,b) in enumerate(candidate['gates']))
            # Independent direct original-circuit alias semantics, all retained wires.
            for mask in range(2048):
                old=[bool(mask>>v&1) for v in range(11)]
                for i,(op,a,b) in enumerate(gates):
                    old.append(old[alias] if i==deleted else (old[a] and old[b] if op=='and' else old[a] or old[b]))
                new=helper.scalar_values(candidate['gates'],mask)
                assert old[source['output']]==new[candidate['output']]
                assert all(old[11+g]==new[move(11+g)] for g in range(22) if g!=deleted)
                compares+=21
            summary=helper.source_summary(candidate)
            assert not summary['exact_target'], 'An exact deletion must be escalated immediately'
            def vector(holes=(),forced=0,flip=None):
                vals=inputs.copy()
                for g,(op,a,b) in enumerate(candidate['gates']):
                    value=vals[a]&vals[b] if op=='and' else vals[a]|vals[b]
                    if g in holes:value=forced
                    if g==flip:value^=full
                    vals.append(value)
                return vals
            vals=vector();actual=vals[candidate['output']];errors=actual^pos
            assert errors.bit_count()==len(summary['boundary_error_masks'])
            fixes=[];damage=[]
            for g in range(21):
                flipped=vector(flip=g)[candidate['output']]
                fixes.append(errors&~(flipped^pos)&full)
                damage.append((flipped^pos)&~errors&full)
                assert fixes[-1].bit_count()==summary['error_flip_influence'][g]
            dirty=[g for g,(op,_,_) in enumerate(candidate['gates']) if op=='and' and vals[13+g]&neg]
            adjacency=[set() for _ in range(21)]
            for g,(_,a,b) in enumerate(candidate['gates']):
                for w in (a,b):
                    if w>=13:adjacency[g].add(w-13);adjacency[w-13].add(g)
            old_to_new=[None if g==deleted else g-(g>deleted) for g in range(22)]
            readers=[old_to_new[g] for g in original_readers[deleted]]
            centers=set(readers)
            if deleted!=14:centers.add(old_to_new[14])
            else:centers.update(old_to_new[g] for g in (6,7,15,16))
            centers.update(summary['dead_gates'])
            distances=[99]*21;queue=deque()
            for g in centers:distances[g]=0;queue.append(g)
            while queue:
                g=queue.popleft()
                for h in adjacency[g]:
                    if distances[h]>distances[g]+1:distances[h]=distances[g]+1;queue.append(h)
            order=sorted(range(21),key=lambda g:(g not in centers,distances[g],-fixes[g].bit_count(),damage[g].bit_count(),g))
            pool=sorted(order[:8])
            # One high-influence gate can enter the eight-node local pool.
            influential=max(range(21),key=lambda g:(fixes[g].bit_count(),-damage[g].bit_count(),-distances[g]))
            if influential not in pool:pool=sorted(order[:7]+[influential])
            windows=[];oracle_rejected=0
            for count in (3,4,5):
                for holes in combinations(pool,count):
                    if not set(holes)&centers:continue
                    lo=vector(holes,0)[candidate['output']]
                    hi=vector(holes,full)[candidate['output']]
                    bad=(lo&neg)|(pos&~hi)
                    if bad:oracle_rejected+=1;continue
                    covered=0
                    for g in holes:covered|=fixes[g]
                    window=dict(free_gates=list(holes),hole_count=count,
                                row_oracle_feasible=True,individually_repairable_error_rows=covered.bit_count(),
                                total_error_rows=errors.bit_count(),distance_sum=sum(distances[g] for g in holes),
                                deletion_reader_included=bool(set(holes)&set(readers)),
                                mapped_original_junk_included=deleted!=14 and old_to_new[14] in holes,
                                dead_slots_included=sorted(set(holes)&set(summary['dead_gates'])))
                    windows.append(window)
            windows.sort(key=lambda w:(w['hole_count'],-w['individually_repairable_error_rows'],
                         not w['deletion_reader_included'],not w['mapped_original_junk_included'],w['distance_sum'],w['free_gates']))
            selected=[]
            for count in (3,4,5):selected += [w for w in windows if w['hole_count']==count][:2]
            path=outdir/(case+'.json');write(path,candidate)
            detail=dict(case=case,source_sha256=PIN,deleted_original_gate=deleted,
                        original_gate=gates[deleted],alias_side=('left' if side==0 else 'right'),
                        alias_original_wire=alias,original_gate_to_new_gate=old_to_new,
                        mapped_original_junk=old_to_new[14],mapped_original_readers=readers,
                        source_file=str(path),source_file_sha256=sha(path),summary=summary,
                        boundary_dirty_gates=dirty,window_pool=pool,oracle_rejected_windows=oracle_rejected,
                        oracle_feasible_windows=len(windows),recommended_windows=selected,
                        exact_2048_deletion_semantics=True)
            write(outdir/(case+'-analysis.json'),detail);entries.append(detail)
            for window in selected:
                all_windows.append(dict(case=case,seed=str(path),seed_sha256=sha(path),**window,
                    boundary_fn=len(summary['boundary_false_negative_masks']),boundary_fp=len(summary['boundary_false_positive_masks']),
                    full_errors=summary['full_2048_false_negative_count']+summary['full_2048_false_positive_count'],
                    dirty_gates=dirty))
    all_windows.sort(key=lambda w:(w['total_error_rows'],w['hole_count'],
                     w['full_errors'],-bool(w['dirty_gates']),-w['individually_repairable_error_rows'],
                     not w['mapped_original_junk_included'],w['distance_sum'],w['case']))
    # Diverse shortlist: two windows per distinct deletion seed, at most eight seeds.
    chosen=[];seeds=set()
    for w in all_windows:
        if w['case'] not in seeds:
            if len(seeds)==8:continue
            seeds.add(w['case'])
        if sum(c['case']==w['case'] for c in chosen)<2:chosen.append(w)
    result=dict(status='READY_FOR_S02_MAIN_REVIEW_NO_CNF_NO_SOLVER',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                elapsed_seconds=time.monotonic()-start,source_sha256=PIN,script_sha256=sha(Path(__file__)),
                unchanged_local_helper_sha256=HPIN,deletion_count=44,full_input_checks=44*2048,
                intermediate_comparisons=compares,shortlist=chosen,
                seeds=[dict(case=d['case'],source_file=d['source_file'],source_file_sha256=d['source_file_sha256'],
                       deleted_original_gate=d['deleted_original_gate'],alias_side=d['alias_side'],
                       boundary_fn=len(d['summary']['boundary_false_negative_masks']),
                       boundary_fp=len(d['summary']['boundary_false_positive_masks']),
                       live_gates=len(d['summary']['live_gates']),dirty_gates=d['boundary_dirty_gates'],
                       full_errors=d['summary']['full_2048_false_negative_count']+d['summary']['full_2048_false_positive_count']) for d in entries],
                helper_intake='helper.repair(base, json.load(seed), sorted(free_gates)); fixed output, exact 40 rows, no clean/junk restrictions. S02 may apply its reviewed free-output wrapper.',
                ranking_scope='Heuristic locality and independent row-wise free-output relaxation only; not SAT feasibility or completeness.',
                no_exact_21_candidate=True,no_solver_launched=True)
    write(outdir/'ranking.json',result)
    write(outdir/'manifest.json',dict(status=result['status'],source_sha256=PIN,
          artifacts=[dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size) for p in sorted(outdir.iterdir())]+[dict(path=str(Path(__file__)),sha256=sha(Path(__file__)),bytes=Path(__file__).stat().st_size)]))
    print(json.dumps(dict(status=result['status'],elapsed_seconds=result['elapsed_seconds'],
                         manifest_sha256=sha(outdir/'manifest.json'),shortlist=chosen)))

if __name__=='__main__':main()
