"""Six exact-target, free-output repair windows from S05's pinned shortlist.

No solver is invoked. The reviewed local/free-output helpers are unchanged.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import re
import sys

sys.dont_write_bytecode = True
ROOT = Path('/tmp/oec/pequalnp-pilot-18')
HANDOFF = ROOT/'orch/S05/dirty22-repair-handoff.json'
HANDOFF_SHA = '5f20cd2772d29e1fcef44a9329968b2df7893cb435af7544aae70f43087313a3'
HELPER_SHA = '7552f3d344d4e34a6f681b116b5ec748e032b2000315dfc9527c77f8de2bdb6b'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def helpers():
    path=ROOT/'orch/S02/prepare_positive_repairs.py'
    if sha(path.read_bytes())!=HELPER_SHA:
        raise ValueError('Reviewed local-free-output helper SHA mismatch')
    spec=importlib.util.spec_from_file_location('reviewed_free_output_windows',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    free,distance,local,base=module.dependencies()
    return module,local,base


def generate(output):
    if output.exists():raise ValueError('Fresh output directory required')
    raw_handoff=HANDOFF.read_bytes()
    if sha(raw_handoff)!=HANDOFF_SHA:raise ValueError('S05 handoff SHA mismatch')
    handoff=json.loads(raw_handoff)
    wrapper,local,base=helpers()
    validator=local.load(ROOT/'validate_raw_candidate.py','dirty22_structure',local.RAW_SHA)
    rows=handoff['shortlist']
    local.require(len(rows)==6 and len({r['case'] for r in rows})==6,'Wrong shortlist size')
    sources={}
    for row in rows:
        local.require(re.fullmatch(r'd[0-9]{2}-(left|right)-h(03|05)',row['case']) is not None,'Unsafe case name')
        path=Path(row['seed'])
        local.require(path.parent==ROOT/'orch/S05/dirty22-deletions' and not path.is_symlink(),'Unexpected source path')
        raw=path.read_bytes();local.require(sha(raw)==row['seed_sha256'],'Seed SHA mismatch')
        offset,gates,out=validator.check_structure(json.loads(raw))
        local.require(offset==13 and len(gates)==21,'Expected21 augmented gates')
        data={'inputs':11,'gate_wire_offset':13,'size':21,'output':out,
              'gates':[[op,*sorted((a,b))] for op,a,b in gates]}
        if path.name not in sources:
            summary=local.source_summary(data)
            local.require(summary['full_2048_false_positive_count']==0,'Expected no false positives')
            sources[path.name]={'raw':raw,'data':data,'summary':summary,'sha256':sha(raw)}
        summary=sources[path.name]['summary']
        local.require(summary['boundary_false_negative_masks']==row['source_missing_edge_masks'],'Missing edge mismatch')
        holes=row['free_gates']
        local.require(holes==sorted(set(holes)) and len(holes)==int(row['case'][-2:]) and
                      all(type(g) is int and 0<=g<21 for g in holes),'Invalid window')
    output.mkdir(parents=True,exist_ok=False)
    manifest={'kind':'candidate_only_dirty22_deletion_freeoutput_windows','complete':False,
              'program_sha256':sha(Path(__file__).read_bytes()),'handoff_sha256':HANDOFF_SHA,
              'reviewed_free_output_helper_sha256':HELPER_SHA,'local_helper_sha256':wrapper.dependencies()[1].HELPER_SHA,
              'base_generator_sha256':local.BASE_SHA,'output_selection_free':True,
              'assigned_shard_exhaustion':False,'sources':{},'cases':[]}
    for name,source in sources.items():
        (output/name).write_bytes(source['raw'])
        manifest['sources'][name]={'sha256':source['sha256'],'summary':source['summary']}
    for row in rows:
        source=sources[Path(row['seed']).name]
        cnf,meta=wrapper.local_free_output(local,base,source['data'],row['free_gates'])
        meta.update(program=Path(__file__).name,program_sha256=manifest['program_sha256'],
                    source_sha256=source['sha256'],source_file=Path(row['seed']).name,
                    dirty22_handoff_sha256=HANDOFF_SHA,reviewed_free_output_helper_sha256=HELPER_SHA,
                    source_missing_edge_masks=row['source_missing_edge_masks'],
                    scope='Candidate-only exact-target local repair; all target boundary constraints retained, output free.')
        raw=local.dimacs(cnf);meta['sha256']=sha(raw)
        path=output/(row['case']+'.cnf');path.write_bytes(raw)
        path.with_suffix('.json').write_text(json.dumps(meta,indent=2)+'\n')
        manifest['cases'].append({'case':row['case'],'source_file':Path(row['seed']).name,
            'free_gates':row['free_gates'],'variables':cnf.variables,'clauses':len(cnf.clauses),
            'cnf_sha256':meta['sha256'],'metadata_sha256':sha(path.with_suffix('.json').read_bytes())})
    manifest['complete']=True
    (output/'family.json').write_text(json.dumps(manifest,indent=2)+'\n')
    return manifest


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('output',type=Path)
    args=parser.parse_args();result=generate(args.output)
    print(json.dumps({'cases':len(result['cases']),'program_sha256':result['program_sha256'],'solver_launched':False}))
