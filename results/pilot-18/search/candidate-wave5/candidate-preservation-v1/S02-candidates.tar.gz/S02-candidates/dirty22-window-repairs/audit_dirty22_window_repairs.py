"""Independent source scalar checks and six exact base-plus-pin reconstructions."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S02'
FAMILY=HERE/'dirty22-window-family';OUT=HERE/'dirty22-window-controls'
OUT.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
path=HERE/'generate_dirty22_window_repairs.py'
spec=importlib.util.spec_from_file_location('dirty22_window_generator',path)
generator=importlib.util.module_from_spec(spec);spec.loader.exec_module(generator)
wrapper,local,base=generator.helpers()
handoff=json.loads(generator.HANDOFF.read_text())
assert sha(generator.HANDOFF)==generator.HANDOFF_SHA
manifest=json.loads((FAMILY/'family.json').read_text())
assert manifest['complete'] and manifest['program_sha256']==sha(path)
assert len(manifest['sources'])==3 and len(manifest['cases'])==6
assert [r['case'] for r in manifest['cases']]==[r['case'] for r in handoff['shortlist']]
edges=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
       (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
target=[any(mask&(1<<a) and mask&(1<<b) for a,b in edges) for mask in range(2048)]
sources={};scalar_checks=0
for name,row in manifest['sources'].items():
    path=FAMILY/name;assert sha(path)==row['sha256']
    data=json.loads(path.read_text());gates=data['gates'];assert data['inputs']==11 and data['gate_wire_offset']==13 and len(gates)==21
    outputs=[]
    for mask in range(2048):
        values=[bool(mask>>v&1) for v in range(11)]+[False,True]
        for i,(op,a,b) in enumerate(gates):
            assert op in ['and','or'] and type(a) is int and type(b) is int and 0<=a<13+i and 0<=b<13+i
            values.append(values[a] and values[b] if op=='and' else values[a] or values[b])
        outputs.append(values[data['output']]);scalar_checks+=1
    fn=[m for m in range(2048) if target[m] and not outputs[m]]
    fp=[m for m in range(2048) if not target[m] and outputs[m]]
    bfn=[(1<<a)|(1<<b) for a,b in edges if ((1<<a)|(1<<b)) in fn]
    assert not fp and fn and len(fn)==row['summary']['full_2048_false_negative_count']
    assert bfn==row['summary']['boundary_false_negative_masks']
    data['gates']=[[op,*sorted((a,b))] for op,a,b in gates]
    sources[name]={'data':data,'full_FN':len(fn),'full_FP':0,'boundary_FN_masks':bfn,'sha256':sha(path)}

cases=[]
for row,expected_row in zip(manifest['cases'],handoff['shortlist']):
    path=FAMILY/(row['case']+'.cnf');meta=json.loads(path.with_suffix('.json').read_text())
    assert sha(path)==row['cnf_sha256']==meta['sha256']
    assert sha(path.with_suffix('.json'))==row['metadata_sha256']
    source=sources[row['source_file']];data=source['data'];holes=row['free_gates']
    assert holes==expected_row['free_gates'] and source['sha256']==expected_row['seed_sha256']
    assert source['boundary_FN_masks']==expected_row['source_missing_edge_masks']
    cnf,original=base.build(size=21,first_junk=0,second_junk=False,prefix_sort=False,
                             last_output=False,live=False,productive_prefix=False)
    before=local.dimacs(cnf);marker=[original['junk'][0]]
    assert cnf.clauses.count(marker)==1
    removal=cnf.clauses.index(marker);cnf.clauses.pop(removal)
    pins=[]
    for gate,(op,a,b) in enumerate(data['gates']):
        if gate not in holes:
            pins += [[original['ops'][gate] if op=='and' else -original['ops'][gate]],
                     [original['lefts'][gate][a]],[original['rights'][gate][b]]]
    cnf.clauses.extend(pins)
    assert path.read_bytes()==local.dimacs(cnf)
    assert meta['base_with_forced_junk_sha256']==hashlib.sha256(before).hexdigest()
    assert meta['removed_unit_original_index']==removal and meta['pin_clauses']==pins
    assert meta['variables']==original['variables'] and meta['clauses']==len(cnf.clauses)
    assert [original['output_selectors'][data['output']]] not in cnf.clauses
    assert meta['output_selection_free'] and 'fixed_output_wire' not in meta
    assert not meta['enforce_junk'] and not meta['second_junk'] and meta['clean_prefix_length']==0
    assert not meta['live'] and not meta['last_output'] and not meta['prefix_sort'] and not meta['productive_prefix']
    assert meta['candidate_only'] and not meta['assigned_shard_exhaustion']
    cases.append({**row,'exact_base_minus_junk_unit_plus_fixed_pins':True,
                  'fixed_pin_count':len(pins),'target_boundary_constraints_unchanged':True,
                  'source_output_unit_absent':True})

try:generator.generate(FAMILY)
except ValueError:pass
else:raise AssertionError('Existing directory accepted')
reproduced=OUT/'reproduced';generator.generate(reproduced)
names=sorted(p.name for p in FAMILY.iterdir())
assert len(names)==16 and all((FAMILY/n).read_bytes()==(reproduced/n).read_bytes() for n in names)
prior=HERE/'positive-repairs-review.json'
assert sha(prior)=='667dfab9773d414fa6603472f8678e0b0c2807c6f11f4fba5a916c4e84e3673d'
review={'verdict':'PASS_SELF_SOURCE_SCALAR_AND_EXACT_CNF_DELTA_CONTROLS_READY_MAIN_REVIEW',
    'generator_sha256':sha(HERE/'generate_dirty22_window_repairs.py'),
    'audit_sha256':sha(Path(__file__)),'handoff_sha256':generator.HANDOFF_SHA,
    'family_manifest_sha256':sha(FAMILY/'family.json'),
    'reviewed_free_output_helper_sha256':generator.HELPER_SHA,
    'prior_full_known22_model_control_review_sha256':sha(prior),
    'source_scalar_checks':scalar_checks,
    'sources':{k:{p:v for p,v in r.items() if p!='data'} for k,r in sources.items()},
    'cases':cases,'byte_identical_reproduction_files':16,'existing_output_rejected':True,
    'blocking_findings':[],'solver_launched':False,
    'scope':'Six candidate-only neighborhoods; exact target constraints retained; free output; no global/shard exhaustion.'}
p=HERE/'dirty22-window-review.json';p.write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'review':str(p),'sha256':sha(p),'generator_sha256':review['generator_sha256'],'cases':6}))
