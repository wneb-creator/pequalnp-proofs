"""Reconstruct six candidate CNFs in fresh scratch; never launch a solver."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def within(root, relative):
    relative = Path(relative)
    if relative.is_absolute() or '..' in relative.parts:
        raise ValueError('Unsafe relative path')
    path = root/relative
    if path.is_symlink() or not path.resolve().is_relative_to(root.resolve()):
        raise ValueError('Redirected path')
    return path


def main(output):
    package = Path(__file__).resolve().parent
    recipe = json.loads((package/'reconstruction.json').read_text())
    root = Path('/tmp/oec/pequalnp-pilot-18')
    if root.resolve() != root:
        raise ValueError('Redirected scratch root')
    output = output.resolve()
    if output.exists() or not output.is_relative_to(root):
        raise ValueError('Fresh output directory inside named scratch required')
    missing = []
    for row in recipe['sources']:
        raw = within(package,row['package_path']).read_bytes()
        if sha(raw) != row['sha256']:
            raise ValueError('Package source hash mismatch')
        destination = within(root,row['scratch_path'])
        if destination.exists():
            if not destination.is_file() or destination.read_bytes() != raw:
                raise ValueError('Existing source differs; refusing overwrite')
        else:
            missing.append((destination,raw))
    for path,raw in missing:
        path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('xb') as stream:
            stream.write(raw)
    output.mkdir(parents=True,exist_ok=False)
    command = [sys.executable,'-B',str(root/'orch/S02/generate_context_windows.py'),
               str(root/'orch/S02/context-window-proposal.json'),str(output/'family')]
    with (output/'generator.stdout').open('x') as out,(output/'generator.stderr').open('x') as err:
        result = subprocess.run(command,stdout=out,stderr=err,timeout=120)
    if result.returncode:
        raise RuntimeError('Generator failed; full logs preserved')
    expected = recipe['expected_files']
    if set(expected) != {p.name for p in (output/'family').iterdir()}:
        raise ValueError('Generated file set mismatch')
    for name,wanted in expected.items():
        if sha(within(output/'family',name).read_bytes()) != wanted:
            raise ValueError('Generated hash mismatch')
    report = {'verdict':'PASS_EXACT_SIX_CNF_RECONSTRUCTION','command':command,'exit_code':0,
              'expected_files':expected,'files':len(expected),'CNFs':sum(n.endswith('.cnf') for n in expected),
              'solver_launched':False,'scope':'Candidate-only fresh reproduction; no solve or completeness claim.'}
    (output/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'verdict':report['verdict'],'files':report['files'],'CNFs':report['CNFs']}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output',type=Path)
    main(parser.parse_args().output)
