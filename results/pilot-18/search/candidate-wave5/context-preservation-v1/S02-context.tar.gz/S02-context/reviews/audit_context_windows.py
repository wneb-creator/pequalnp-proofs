"""Independent scalar semantics and complete base-minus-unit-plus-pins checks."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path('/tmp/oec/pequalnp-pilot-18'); HERE = ROOT/'orch/S02'
FAMILY = HERE/'context-window-family'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
path = HERE/'generate_context_windows.py'
spec = importlib.util.spec_from_file_location('context_generator', path)
generator = importlib.util.module_from_spec(spec); spec.loader.exec_module(generator)
wrapper, local, base = generator.helpers()
manifest = json.loads((FAMILY/'family.json').read_text())
proposal = json.loads((FAMILY/'proposal.json').read_text())
assert manifest['complete'] and manifest['program_sha256'] == sha(path)
assert manifest['proposal_sha256'] == sha(FAMILY/'proposal.json')
assert len(manifest['sources']) == 2 and len(manifest['cases']) == 6
edges = [(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
         (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
sources = {}; scalar_count = 0
for key, row in manifest['sources'].items():
    path = FAMILY/row['file']; assert sha(path) == row['sha256'] == proposal['sources'][key]['sha256']
    data = json.loads(path.read_text()); gates = data['gates']
    assert data['inputs'] == 11 and data['gate_wire_offset'] == 13 and len(gates) == 21
    fn = []; fp = []; formula_checks = 0
    for mask in range(2048):
        target = any((mask>>a&1) and (mask>>b&1) for a,b in edges)
        values = [bool(mask>>i&1) for i in range(11)] + [False, True]
        for g,(op,a,b) in enumerate(gates):
            assert op in ('and','or') and type(a) is int and type(b) is int and 0<=a<13+g and 0<=b<13+g
            values.append(values[a] and values[b] if op=='and' else values[a] or values[b])
        actual = values[data['output']]; scalar_count += 1
        if target and not actual: fn.append(mask)
        if actual and not target: fp.append(mask)
        if key == 'p18':
            expected = target or values[5] or ((values[0] or values[7]) and (values[1] or values[4]))
            assert actual == expected; formula_checks += 1
    live = {data['output']-13}
    for g in reversed(range(21)):
        if g in live: live.update(w-13 for w in gates[g][1:] if w>=13)
    wanted = proposal['sources'][key]
    assert (len(fn),len(fp),len(live)) == (wanted['expected_full_FN'],wanted['expected_full_FP'],wanted['expected_live_gates'])
    if key == 'p18': assert sorted(set(range(21))-live) == [4,10,16]
    data['gates'] = [[op,*sorted((a,b))] for op,a,b in gates]
    sources[key] = {'data':data,'sha256':sha(path),'full_FN':len(fn),'full_FP':len(fp),
                    'live_gates':sorted(live),'explicit_positive_formula_checks':formula_checks}
cases = []
for row, planned in zip(manifest['cases'], proposal['cases']):
    assert all(row[k] == v for k,v in planned.items())
    path = FAMILY/(row['case']+'.cnf'); meta = json.loads(path.with_suffix('.json').read_text())
    assert sha(path) == row['cnf_sha256'] == meta['sha256']
    assert sha(path.with_suffix('.json')) == row['metadata_sha256']
    data = sources[row['source']]['data']; holes = row['free_gates']
    if row['require_connected_gate_region']:
        adjacency = {g:set() for g in holes}
        for g in holes:
            for w in data['gates'][g][1:]:
                if w-13 in adjacency: adjacency[g].add(w-13); adjacency[w-13].add(g)
        seen = set(); todo = [holes[0]]
        while todo:
            g = todo.pop()
            if g not in seen: seen.add(g); todo.extend(adjacency[g]-seen)
        assert seen == set(holes)
    cnf, original = base.build(size=21,first_junk=0,second_junk=False,prefix_sort=False,
                               last_output=False,live=False,productive_prefix=False)
    before = local.dimacs(cnf); marker = [original['junk'][0]]
    assert cnf.clauses.count(marker) == 1
    removal = cnf.clauses.index(marker); cnf.clauses.pop(removal)
    pins = []
    for g,(op,a,b) in enumerate(data['gates']):
        if g not in holes:
            pins.extend([[original['ops'][g] if op=='and' else -original['ops'][g]],
                         [original['lefts'][g][a]],[original['rights'][g][b]]])
    cnf.clauses.extend(pins)
    assert path.read_bytes() == local.dimacs(cnf)
    assert meta['pin_clauses'] == pins and meta['removed_unit_original_index'] == removal
    assert meta['base_with_forced_junk_sha256'] == hashlib.sha256(before).hexdigest()
    assert meta['variables'] == original['variables'] and meta['clauses'] == len(cnf.clauses)
    assert [original['output_selectors'][data['output']]] not in cnf.clauses
    assert meta['output_selection_free'] and 'fixed_output_wire' not in meta
    assert meta['clean_prefix_length'] == 0 and meta['candidate_only']
    assert all(not meta[k] for k in ('enforce_junk','second_junk','live','last_output','prefix_sort','productive_prefix','assigned_shard_exhaustion'))
    cases.append({**row,'exact_base_minus_junk_unit_plus_fixed_pins':True,'fixed_pin_count':len(pins),
                  'source_output_pin_absent':True,'target_boundary_constraints_unchanged':True})
try: generator.generate(FAMILY/'proposal.json', FAMILY)
except ValueError: pass
else: raise AssertionError('Existing directory accepted')
reproduced = HERE/'context-window-reproduced'
generator.generate(FAMILY/'proposal.json', reproduced)
names = sorted(p.name for p in FAMILY.iterdir())
assert len(names) == 16 and all((FAMILY/n).read_bytes() == (reproduced/n).read_bytes() for n in names)
prior = HERE/'positive-repairs-review.json'
assert sha(prior) == '667dfab9773d414fa6603472f8678e0b0c2807c6f11f4fba5a916c4e84e3673d'
review = {'verdict':'PASS_SELF_SOURCE_SCALAR_EXACT_CNF_DELTAS_READY_MAIN_REVIEW',
          'generator_sha256':sha(HERE/'generate_context_windows.py'),'audit_sha256':sha(Path(__file__)),
          'family_manifest_sha256':sha(FAMILY/'family.json'),'proposal_sha256':sha(FAMILY/'proposal.json'),
          'source_scalar_checks':scalar_count,'sources':{k:{p:v for p,v in s.items() if p!='data'} for k,s in sources.items()},
          'cases':cases,'byte_identical_reproduction_files':len(names),'existing_directory_rejected':True,
          'prior_full_known22_model_control_review_sha256':sha(prior),'blocking_findings':[],
          'solver_launched':False,'scope':'Six candidate neighborhoods only; no global or assigned-shard exhaustion.'}
path = HERE/'context-window-review.json'; path.write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'review':str(path),'sha256':sha(path),'generator_sha256':review['generator_sha256'],'cases':6}))
