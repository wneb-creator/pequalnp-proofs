"""Seal context source/review snapshot; active workers and inputs are read-only."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import re
import tarfile

ROOT = Path('/tmp/oec/pequalnp-pilot-18'); HERE = ROOT/'orch/S02'
STAGE = HERE/'context-preservation-stage/S02-context'
OUT = HERE/'context-preservation-v1'
sha = lambda b:hashlib.sha256(b).hexdigest()
assert not OUT.exists() and not (STAGE/'MANIFEST.json').exists()
bindings = json.loads((STAGE/'copy-bindings.json').read_text())['files']
for row in bindings:
    raw = Path(row['source']).read_bytes()
    assert raw == (STAGE/row['archive']).read_bytes() and sha(raw) == row['sha256']
review = json.loads((STAGE/'reviews/main-context-window-review.json').read_text())
assert review['verdict'] == 'PASS_MAIN_INDEPENDENT_SCALAR_CNF_AND_CONTROLLER_DELTA'
assert review['controller_sha256'] == sha((STAGE/'controller/run_context_window_pilot.py').read_bytes())
validation = STAGE/'validation'; validation.mkdir()
for name in ['validation.json','generator.stdout','generator.stderr']:
    (validation/name).write_bytes((HERE/'context-package-reconstruction'/name).read_bytes())
for name in ['context-package-reconstruction.stdout.txt','context-package-reconstruction.stderr.txt',
             'context-reconstruct-help.stdout.txt','context-reconstruct-help.stderr.txt']:
    (validation/name).write_bytes((HERE/name).read_bytes())
negative = validation/'negative-controls'; negative.mkdir()
for p in sorted((HERE/'context-reconstruction-negative-controls').iterdir()):
    if p.is_file(): (negative/p.name).write_bytes(p.read_bytes())
reproduced = json.loads((validation/'validation.json').read_text())
assert reproduced['verdict'] == 'PASS_EXACT_SIX_CNF_RECONSTRUCTION' and reproduced['files'] == 16
for name,wanted in reproduced['expected_files'].items():
    assert sha((HERE/'context-package-reconstruction/family'/name).read_bytes()) == wanted
(STAGE/'seal_context_archive.py').write_bytes(Path(__file__).read_bytes())
rows = []
patterns = [r'github_pat_[A-Za-z0-9_]{30,}',r'gh[pousr]_[A-Za-z0-9_]{20,}',
            r'[?&]lease=[A-Za-z0-9_-]{16,}',r'-----BEGIN [A-Z ]*PRIVATE KEY-----']
for p in sorted(STAGE.rglob('*')):
    assert not p.is_symlink()
    if p.is_dir(): continue
    assert p.is_file() and p.suffix != '.cnf'
    raw = p.read_bytes(); text = raw.decode()
    assert not any(re.search(pattern,text) for pattern in patterns), 'Sensitive value indicator; no content printed'
    rows.append({'path':str(p.relative_to(STAGE)),'bytes':len(raw),'sha256':sha(raw)})
manifest = {'scope':'Reviewed candidate source and launch provenance only; live results excluded.',
            'files':rows,'raw_CNF_members':0,'solver_binaries':0,'exact21_claim':False}
(STAGE/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
OUT.mkdir(); archive = OUT/'S02-context.tar.gz'
with archive.open('xb') as f:
    with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w',format=tarfile.USTAR_FORMAT) as tar:
            for p in sorted(STAGE.rglob('*')):
                if not p.is_file(): continue
                raw = p.read_bytes(); info = tarfile.TarInfo('S02-context/'+str(p.relative_to(STAGE)))
                info.size = len(raw); info.mode = 0o644; info.uid = 0; info.gid = 0; info.mtime = 0
                tar.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == len(rows)+1 and len({m.name for m in members}) == len(members)
    for m in members:
        path = PurePosixPath(m.name)
        assert m.isfile() and not path.is_absolute() and '..' not in path.parts and path.parts[0] == 'S02-context'
        assert tar.extractfile(m).read() == (STAGE/Path(*path.parts[1:])).read_bytes()
(OUT/'manifest.json').write_bytes((STAGE/'MANIFEST.json').read_bytes())
(OUT/'README.md').write_bytes((STAGE/'README.md').read_bytes())
report = {'verdict':'PASS_SELF_CONTEXT_SOURCE_PACKAGING_AND_EXACT_REPRODUCTION',
          'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,
          'archive_regular_members':len(members),'manifest_sha256':sha((OUT/'manifest.json').read_bytes()),
          'exact_copy_files':len(bindings),'reproduced_files':16,'reproduced_CNF_files':6,'negative_controls':2,
          'main_review_sha256':sha((STAGE/'reviews/main-context-window-review.json').read_bytes()),
          'companion_prior_archive_sha256':'cc2a5d6751aa0f817b4a831288481da5565e9170e023e78ee769da757d404889',
          'source_snapshot_only':True,'live_solver_outputs_archived':False,'raw_CNF_members':0,
          'credential_value_indicators':0,'lease_value_indicators':0,'blocking_findings':[],
          'solver_launched':False,'production_inputs_changed':False,
          'scope':'No global/shard exhaustion or exact21 claim; completed pilot outcomes require later addendum.'}
(OUT/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
