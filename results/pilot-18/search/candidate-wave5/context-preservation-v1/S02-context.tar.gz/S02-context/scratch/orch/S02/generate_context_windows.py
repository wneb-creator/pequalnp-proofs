"""Fresh exact-target, free-output neighborhoods; no solver or completeness claim."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import re
import sys

sys.dont_write_bytecode = True
ROOT = Path('/tmp/oec/pequalnp-pilot-18')
HERE = ROOT/'orch/S02'
HELPER_SHA = '30cf9e2b29acf4b5f2356c07e389903bfa54b8226da235062203e6545d2350ad'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def helpers():
    path = HERE/'generate_dirty22_window_repairs.py'
    if sha(path.read_bytes()) != HELPER_SHA:
        raise ValueError('Reviewed helper SHA mismatch')
    spec = importlib.util.spec_from_file_location('reviewed_context_helper', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.helpers()


def connected(gates, holes):
    seen = {holes[0]}
    while True:
        old = set(seen)
        for g in holes:
            for w in gates[g][1:]:
                h = w - 13
                if h in holes and (g in seen or h in seen):
                    seen.update((g, h))
        if seen == old:
            return len(seen) == len(holes)


def generate(proposal_path, output):
    if output.exists():
        raise ValueError('Fresh output directory required')
    raw_proposal = proposal_path.read_bytes()
    proposal = json.loads(raw_proposal)
    wrapper, local, base = helpers()
    validator = local.load(ROOT/'validate_raw_candidate.py', 'context_structure', local.RAW_SHA)
    rows = proposal['cases']
    local.require(len(rows) == 6 and len({r['case'] for r in rows}) == 6, 'Expected six cases')
    sources = {}
    for key, row in proposal['sources'].items():
        local.require(key in ('p18', 'd08'), 'Unknown source label')
        path = Path(row['path'])
        local.require(path.parent in (ROOT/'orch/S05/dirty22-deletions', ROOT/'orch/S05/dirty22-positive-shapes')
                      and not path.is_symlink(), 'Unexpected source path')
        raw = path.read_bytes()
        local.require(sha(raw) == row['sha256'], 'Seed SHA mismatch')
        offset, gates, out = validator.check_structure(json.loads(raw))
        local.require(offset == 13 and len(gates) == 21, 'Expected 21 augmented gates')
        data = {'inputs': 11, 'gate_wire_offset': 13, 'size': 21, 'output': out,
                'gates': [[op, *sorted((a, b))] for op, a, b in gates]}
        summary = local.source_summary(data)
        local.require(summary['full_2048_false_negative_count'] == row['expected_full_FN'] and
                      summary['full_2048_false_positive_count'] == row['expected_full_FP'] and
                      len(summary['live_gates']) == row['expected_live_gates'], 'Source semantics mismatch')
        sources[key] = {'raw': raw, 'data': data, 'summary': summary, 'sha256': sha(raw)}
    for row in rows:
        local.require(re.fullmatch(r'(p18|d08)-h(05|08|10)(-[ab])?', row['case']) is not None, 'Unsafe case name')
        holes = row['free_gates']
        local.require(holes == sorted(set(holes)) and len(holes) == int(row['case'][5:7]) and
                      all(type(g) is int and 0 <= g < 21 for g in holes), 'Invalid holes')
        local.require(not row['require_connected_gate_region'] or connected(sources[row['source']]['data']['gates'], holes),
                      'Required connected gate region is disconnected')
    output.mkdir(parents=True, exist_ok=False)
    (output/'proposal.json').write_bytes(raw_proposal)
    manifest = {'kind': 'candidate_only_context_windows', 'complete': False,
                'program_sha256': sha(Path(__file__).read_bytes()), 'proposal_sha256': sha(raw_proposal),
                'reviewed_wrapper_sha256': HELPER_SHA, 'base_generator_sha256': local.BASE_SHA,
                'output_selection_free': True, 'assigned_shard_exhaustion': False,
                'recommended_pilot_seconds': 90, 'sources': {}, 'cases': []}
    for key, source in sources.items():
        (output/(key+'-source.json')).write_bytes(source['raw'])
        manifest['sources'][key] = {'file': key+'-source.json', 'sha256': source['sha256'], 'summary': source['summary']}
    for row in rows:
        source = sources[row['source']]
        cnf, meta = wrapper.local_free_output(local, base, source['data'], row['free_gates'])
        meta.update(program=Path(__file__).name, program_sha256=manifest['program_sha256'],
                    source_sha256=source['sha256'], source_file=row['source']+'-source.json',
                    proposal_sha256=manifest['proposal_sha256'], reviewed_wrapper_sha256=HELPER_SHA,
                    scope='Candidate-only context repair; exact target boundary constraints retained, output free.')
        raw = local.dimacs(cnf)
        meta['sha256'] = sha(raw)
        path = output/(row['case']+'.cnf')
        path.write_bytes(raw)
        path.with_suffix('.json').write_text(json.dumps(meta, indent=2)+'\n')
        manifest['cases'].append({**row, 'source_file': row['source']+'-source.json',
            'variables': cnf.variables, 'clauses': len(cnf.clauses),
            'cnf_sha256': meta['sha256'], 'metadata_sha256': sha(path.with_suffix('.json').read_bytes())})
    manifest['complete'] = True
    (output/'family.json').write_text(json.dumps(manifest, indent=2)+'\n')
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('proposal', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    result = generate(args.proposal, args.output)
    print(json.dumps({'cases': len(result['cases']), 'program_sha256': result['program_sha256'], 'solver_launched': False}))
