"""Fresh four-form AAOA research inputs; coverage also needs the AAAA fallback.

No solver is launched. The four formulas alone are not claimed to exhaust AAOA.
The existence normalization is pending independent review and is not an implied
clause proof for the input CNF.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path

PARENT_SHA='70308894ffc6f4c3b682140c7df3d17ed3035c79dc66f56dc51bd47020004e91'
META_SHA='0f530e106a5811be95fb87df8802be78bd6a45f91c4ef548acf1d4688c00857f'
SHAPES={
 'T1': {'formula':'a AND (b OR cde)',
        'ports':[(None,None),(None,30),(None,31),(None,32)],
        'orders':[(17,0,17,1),(17,1,18,0)],'delta':879},
 'T2': {'formula':'a AND (bc OR de)',
        'ports':[(None,None),(None,None),(30,31),(None,32)],
        'orders':[(17,0,17,1),(18,0,18,1),(17,0,18,0)],'delta':1313},
 'T3': {'formula':'ab AND (c OR de)',
        'ports':[(None,None),(None,None),(None,31),(30,32)],
        'orders':[(17,0,17,1),(18,0,18,1)],'delta':877},
 'T4': {'formula':'abc AND (d OR e)',
        'ports':[(None,None),(None,30),(None,None),(31,32)],
        'orders':[(17,0,17,1),(17,1,18,0),(19,0,19,1)],'delta':1313}
}

def require(ok,message):
    if not ok: raise ValueError(message)

def digest(data): return hashlib.sha256(data).hexdigest()

def json_bytes(x): return (json.dumps(x,indent=2)+'\n').encode()

def generate(parent,output):
    raw=parent.read_bytes(); mr=parent.with_suffix('.json').read_bytes()
    require(digest(raw)==PARENT_SHA,'Wrong AAOA parent CNF')
    require(digest(mr)==META_SHA,'Wrong AAOA parent metadata')
    meta=json.loads(mr);header,body=raw.split(b'\n',1)
    require(header==b'p cnf 11968 114571','Wrong dimensions')
    require(len(body.splitlines())==114571,'Wrong clause count')
    require(meta['operation_case']=='AAOA' and meta['consecutive_junk'],'Wrong source case')
    require(meta['original_DAG'] and meta['live'] and meta['last_output'],'Wrong source model')
    units={tuple(map(int,s.split()[:-1])) for s in body.splitlines()}
    require(all((v,) in units for v in [2807,3072,-3341,3614,2974,3243]),'Missing operation/junk units')
    ports=[meta['lefts'],meta['rights']]
    require(not output.exists(),'Output directory already exists')
    program_sha=digest(Path(__file__).read_bytes())
    prepared=[]
    for name,shape in SHAPES.items():
        delta=[]
        for gate,descriptions in zip(range(17,21),shape['ports']):
            for side,source in enumerate(descriptions):
                table=ports[side][gate]
                require(len(table)==13+gate,'Wrong selector width')
                if source is None:
                    delta.extend([-lit] for lit in table[30:])
                else:
                    require(0<=source<13+gate,'Forward fixed reference')
                    delta.append([table[source]])
        for g,s,h,t in shape['orders']:
            a,b=ports[s][g][:30],ports[t][h][:30]
            for i in range(30):
                for j in range(i): delta.append([-a[i],-b[j]])
        require(len(delta)==shape['delta'],'Unexpected clause delta')
        extra=''.join(' '.join(map(str,c))+' 0\n' for c in delta).encode()
        blob=f'p cnf 11968 {114571+len(delta)}\n'.encode()+body+extra
        record=copy.deepcopy(meta)
        record.update(sha256=digest(blob),clauses=114571+len(delta),
          aaoa_shape=name,aaoa_formula=shape['formula'],aaoa_ports=shape['ports'],
          aaoa_leaf_orders=shape['orders'],aaoa_added_clauses=delta,
          aaoa_parent_sha256=PARENT_SHA,aaoa_parent_metadata_sha256=META_SHA,
          aaoa_generator_sha256=program_sha,
          aaoa_claimed_as_logical_consequence=False,
          aaoa_coverage_requires_AAAA_fallback=True,
          aaoa_review_status='CANDIDATE_ONLY_PENDING_INDEPENDENT_MATHEMATICAL_REVIEW',
          research_status='GENERATED_ONLY_NO_SOLVER_VERDICT')
        prepared.append((name,blob,json_bytes(record),len(delta)))
    output.mkdir(parents=True,exist_ok=False)
    entries={}
    for name,blob,mr,count in prepared:
        with (output/(name+'.cnf')).open('xb') as f:f.write(blob)
        with (output/(name+'.json')).open('xb') as f:f.write(mr)
        entries[name]={'cnf_sha256':digest(blob),'metadata_sha256':digest(mr),
                       'variables':11968,'clauses':114571+count,'added_clauses':count}
    family={'scope':'Four AAOA normal-form research cases; no solver verdict.',
      'program_sha256':program_sha,'parent_sha256':PARENT_SHA,'parent_metadata_sha256':META_SHA,
      'review_status':'CANDIDATE_ONLY_PENDING_INDEPENDENT_MATHEMATICAL_REVIEW',
      'four_cases_alone_claimed_complete_for_AAOA':False,
      'coverage_note':'S01 port classification maps AAOA to these four forms OR an AAAA fallback. Use the AAAA case as well for completeness.',
      'all_original_junk_requirements_retained':True,'files':entries}
    with (output/'family.json').open('xb') as f:f.write(json_bytes(family))
    return family

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('parent',type=Path);p.add_argument('output',type=Path)
    a=p.parse_args();r=generate(a.parent,a.output)
    print(json.dumps({'generated':4,'output':str(a.output),'program_sha256':r['program_sha256'],
                      'scope':r['scope']}))
