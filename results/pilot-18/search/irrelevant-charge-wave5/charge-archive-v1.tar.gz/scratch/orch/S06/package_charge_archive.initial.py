#!/usr/bin/env python3
"""Archive ten reviewed cuts and only the four finished AAOA runs; no workers."""
import datetime,gzip,hashlib,json,subprocess,tarfile,time
from pathlib import Path
R=Path('/tmp/oec/pequalnp-pilot-18');O=R/'orch/S06';W=Path('/workspace/pequalnp-proofs');A=O/'charge-archive-v1'
PARENT_SHA='38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08'
REVIEW_SHA='b0af769b67da5f0b2f42aa1d4e341e217556b56cf17ea3a7a7aa5ffe9a0a2d7b'


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def digest(raw):return hashlib.sha256(raw).hexdigest()
def read_json(path):return json.loads(path.read_text())
def dump(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')


def main():
    start=time.monotonic();A.mkdir(mode=0o700)
    source=R/'original-dag-strong/original.cnf';original=source.read_bytes();assert digest(original)==PARENT_SHA
    original_body=original.split(b'\n',1)[1]
    handpath=O/'irrelevant-charge-handoff.json';hand=read_json(handpath)
    assert sha(handpath)=='9b9adf9f84a8e1321f55d936b5c9d091ee80edf0347750d0aefda7020b9084f2'
    reviewpath=R/'orch/S08/irrelevant-charge-final-review-v2/review.json'
    assert sha(reviewpath)==REVIEW_SHA
    assert read_json(reviewpath)['verdict']=='PASS_FINAL_TEN_IRRELEVANT_INPUT_CHARGE_DELTAS_AND_RUP_COMPATIBILITY'
    paths=set();files={};recipes=[];omitted=[];source_map=[];partial_proofs={};finished=[]
    def add(path):
        assert path.exists(),path
        if path.is_dir():
            paths.update(p for p in path.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
        else:paths.add(path)
    def layout(path):
        if path.is_relative_to(R):return Path('scratch')/path.relative_to(R)
        assert path.is_relative_to(W),path
        return Path('repo')/path.relative_to(W)
    def put(relative,raw,provenance):
        assert not relative.is_absolute() and '..' not in relative.parts
        entry={'path':str(relative),'bytes':len(raw),'sha256':digest(raw),'source_path':provenance}
        if str(relative) in files:
            assert files[str(relative)]['sha256']==entry['sha256'];return
        dest=A/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);files[str(relative)]=entry
    def generated(name,value):put(Path(name),(json.dumps(value,indent=2,sort_keys=True)+'\n').encode(),'generated archive metadata')

    # Exact frozen handoff payload, including all ten metadata/delta/threshold records.
    add(handpath)
    for rel,pin in hand['files'].items():
        p=O/rel;assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256'],p;add(p)
    for case in hand['family']:
        p=Path(case['parent']);assert sha(p)==case['parent_cnf_sha256'] and sha(p.with_suffix('.json'))==case['parent_metadata_sha256'];add(p);add(p.with_suffix('.json'))
    for name in ['package_charge_archive.py','restore_archive2_cnfs.py','offline_checked_cadical.py',
                 'check_charge_metadata.py','charge-metadata-compatibility.json','charge-metadata-compatibility.stdout','charge-metadata-compatibility.stderr',
                 'AAOA-offline-handoff.json','AAOA-offline-plan','prepare_aaoa_offline_commands.py',
                 'AAOA-offline-preparation.result.json','AAOA-offline-preparation.stdout','AAOA-offline-preparation.stderr',
                 'AAOA-wave1-launch.json','AAOA-wave1-second-launch.json','main-AAOA-launch-review.json']:
        add(O/name)
    add(R/'lean-setup/validate_sat_candidate.py')
    # Reviewed mathematical foundations, sources and every saved control/review diagnostic.
    add(R/'orch/S04/irrelevant-input-preservation-v1')
    for name in ['irrelevant-input-preservation-handoff.json','irrelevant-preservation.stdout.log','irrelevant-preservation.stderr.log']:
        add(R/'orch/S04'/name)
    for directory,script,prefix in [
        ('irrelevant-charge-prep-review','review_irrelevant_charge_prep.py','irrelevant-charge-prep-review'),
        ('irrelevant-charge-delta-review','review_irrelevant_charge_delta.py','irrelevant-charge-delta-review'),
        ('irrelevant-charge-final-review','review_irrelevant_charge_final.py','irrelevant-charge-final-review'),
        ('irrelevant-charge-final-review-v2','review_irrelevant_charge_final_v2.py','irrelevant-charge-final-review-v2')]:
        for p in [R/'orch/S08'/directory,R/'orch/S08'/script,R/'orch/S08'/(prefix+'.stdout'),R/'orch/S08'/(prefix+'.stderr')]:add(p)
    # Standalone provenance for the three old-RUP parents and their exact partition.
    add(R/'orch/S08/aaao-chain-review-v2')
    for name in ['review_aaao_chain.py','aaao-chain-review-v2.stdout','aaao-chain-review-v2.stderr']:add(R/'orch/S08'/name)
    for name in ['combined.drat','manifest.json','checker.stdout','checker.stderr']:add(O/'AAAO-chain-absorption-family'/name)
    add(O/'AAAO-chain-handoff.json')
    for name in ['build_consecutive_junk.py','build_aaoa_shapes.py']:add(R/'orch/S01'/name)
    for name in ['chain-review.json','chain-review.stdout.log','chain-review.stderr.log','review_chain_variants.py',
                 'aaOA-review.json','aaOA-review.stdout.log','aaOA-review.stderr.log','review_aaOA_forms.py',
                 'aaoa-delta-review.json','aaoa-delta.stdout.log','aaoa-delta.stderr.log','review_aaoa_deltas.py']:add(R/'orch/S04'/name)
    add(O/'archive-wave1/reproduction')
    add(source.with_suffix('.json'))
    add(W/'results/orch/lemmas/S06-solver-performance.md')

    # No discovery under active run directories. These four named directories are terminal.
    for name in ['T1','T2','T3','T4']:
        directory=O/('offline-AAOA-'+name+'-wave1');result=read_json(directory/'result.json')
        assert result['state']=='FINISHED' and result['status']=='UNKNOWN' and result['exit_code']==2
        assert result['accepted_CNF_UNSAT'] is False and result['validated_SAT'] is False
        assert result['reason']=='ValueError: solver wall_time_limit'
        assert set(result['phases'])=={'solver'} and result['phases']['solver']['reason']=='wall_time_limit'
        assert set(result['logs'])=={'solver.stdout','solver.stderr'}
        assert (directory/'progress.json').read_bytes()==(directory/'result.json').read_bytes()
        assert sha(directory/'instance.cnf')==result['cnf_sha256'] and sha(directory/'instance.json')==result['metadata_sha256']
        for filename,pin in result['logs'].items():
            p=directory/filename;assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256']
        proof=directory/'proof.drat';pin=result['retained_proof_file']
        assert pin['is_accepted_complete_certificate'] is False
        assert proof.stat().st_size==pin['bytes'] and sha(proof)==pin['sha256']
        partial_proofs[proof]={'bytes':pin['bytes'],'sha256':pin['sha256'],
            'reason':'Incomplete retained DRAT from terminal UNKNOWN wall-time run; not an accepted certificate; intentionally outside archive.',
            'hash_independently_recomputed_during_packaging':True}
        add(directory)
        for stream in ['stdout','stderr']:add(O/('AAOA-'+name+'-supervisor.'+stream))
        finished.append({'case':name,'directory':str(layout(directory)),'status':'UNKNOWN','reason':result['reason'],
            'started_utc':result['started_utc'],'finished_utc':result['finished_utc'],'result_sha256':sha(directory/'result.json'),
            'parent_cnf_sha256':result['cnf_sha256'],'metadata_sha256':result['metadata_sha256'],
            'full_log_files':sorted(result['logs']),'incomplete_proof':partial_proofs[proof]})

    for path in sorted(paths):
        assert path.is_file() and not path.is_symlink(),path
        relative=layout(path)
        if path in partial_proofs:
            info={'relative_path':str(relative),'source_path':str(path),**partial_proofs[path]};omitted.append(info)
            source_map.append({'archive_path':str(relative),'source_path':str(path),'bytes':info['bytes'],'sha256':info['sha256'],'disposition':'omitted_incomplete_proof'})
            continue
        raw=path.read_bytes();assert digest(path.read_bytes())==digest(raw),'source changed during snapshot: '+str(path)
        assert not raw.startswith(b'\x7fELF') and path.suffix not in ['.pyc','.o','.so'],path
        source_map.append({'archive_path':str(relative),'source_path':str(path),'bytes':len(raw),'sha256':digest(raw),
            'disposition':'cnf_recipe' if path.suffix=='.cnf' and len(raw)>65536 else 'payload'})
        if path.suffix=='.cnf' and len(raw)>65536:
            header,body=raw.split(b'\n',1);assert body.startswith(original_body),path
            suffix=body[len(original_body):];dp=Path('cnf-deltas')/(digest(suffix)+'.clauses')
            put(dp,suffix,'deduplicated clause suffix of pinned original')
            rec={'relative_path':str(relative),'source_path':str(path),'bytes':len(raw),'sha256':digest(raw),
                'header':header.decode('ascii'),'delta_path':str(dp),'delta_sha256':digest(suffix)}
            recipes.append(rec);omitted.append(dict(rec,reason='large CNF exactly reproducible from original body, header and archived suffix'))
        else:put(relative,raw,str(path))
    generated('cnf-recipes.json',{'parent_sha256':PARENT_SHA,'parent_bytes':len(original),'recipes':recipes,'small_fixture_max_bytes':65536})
    generated('source-map.json',source_map);generated('omitted-files.json',omitted)
    summary={'scope':'Ten independently reviewed +1 cost encodings and four completed AAOA UNKNOWN runs. No whole-case/shard/global UNSAT, SAT witness or Lean acceptance.',
        'encoding_review_sha256':REVIEW_SHA,'handoff_sha256':sha(handpath),'generator_sha256':hand['generator_source_sha256'],
        'shared_3553_clause_delta_sha256':hand['delta_sha256'],'fresh_encoding_count':10,'new_variables':17,'new_variable_range':[11969,11985],
        'mathematics_review_sha256':hand['math_review_sha256'],'completed_AAOA_runs':finished,
        'incomplete_proofs_payload_included':False,'incomplete_proofs_bytes':sum(x['bytes'] for x in partial_proofs.values()),
        'no_running_directories_read':True,'reviewed_sources_and_inputs_unchanged':True,
        'structural_metadata_check':read_json(O/'charge-metadata-compatibility.json')['status'],
        'cached_bytecode_policy':'__pycache__ directories and .pyc files are deliberately absent from selected source expectations and payload. Historical review records are preserved unchanged.',
        'worker_launch':False}
    generated('summary.json',summary)
    readme='''# S06 reviewed irrelevant-input charge and completed AAOA archive

All ten strengthened CNFs share the exact reviewed3553-clause suffix:3366 raw-input/actual-ancestor trigger implications and187 full-support-guarded links to existing signed-counter thresholds. Only17 penalty variables11969..11985 are added. The original11968 indices and parent clause bytes are unchanged. S08 final actual-delta/RUP-compatibility review is PASS b0af769b67da5f0b2f42aa1d4e341e217556b56cf17ea3a7a7aa5ffe9a0a2d7b. S04 mathematical review and all S08 specification/seven-delta/final reviews, sources, full controls/logs and historical failed reviewer attempt are preserved.

The seven primary inputs are original, AAAA-chain, AAAO-chain and T1..T4. Three more add the same charge to the reviewed3895-RUP AAAO parent and its exact P/d partition. The old RUP proof remains a consequence of the old parent after valid minimum-cover/exact-counter choices, including246 old clauses mentioning those auxiliaries. The new mathematical charge is not claimed RUP-entailed, and not every old auxiliary assignment must extend. Full-support exemption and the difference between3553 guarded clauses and S04's3383 unguarded alternative are explained in the retained S06 README.

All four archived AAOA runs are terminal UNKNOWN/wall-time, with no SAT or accepted UNSAT certificate. Each full result/progress, input metadata, solver stdout/stderr and outer supervisor stdout/stderr is preserved byte-for-byte. No checker stage ran. Their four incomplete DRAT files total the exact byte count in summary.json and remain in scratch; omitted-files.json binds independent fresh byte-count/hash checks. They are not accepted certificates and are intentionally not payload. None of the active strengthened run directories is read or included.

No large raw CNF or compiled binary is archived. `manifest.json` binds all payload. `source-map.json` gives original paths and each payload/recipe/omission disposition. `cnf-recipes.json` reconstructs every omitted CNF as recorded header + pinned original body + deduplicated clause suffix. `omitted-files.json` separately lists incomplete proofs. Cached .pyc files and __pycache__ directories are excluded by policy from both selection expectations and payload; historical records that mention them are preserved.

Portable verification, with no solver/checker/Lean or original scratch-path dependency:

    python3 scratch/orch/S06/restore_archive2_cnfs.py ARCHIVE ORIGINAL.cnf --verify-only

For restoration into a fresh external directory, replace --verify-only with FRESH_DIRECTORY. ORIGINAL.cnf must have SHA25638d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08. Both11968- and11985-variable headers are reconstructed exactly. The restorer's filename is historical; its format applies to this archive. Original generator dependencies are retained under scratch/orch/S06/archive-wave1/reproduction/; chain/AAOA generation and normalization reviews are included as provenance. Absolute source paths inside historical records are informational, not required by reconstruction.

Full reviewed metadata is retained unchanged. The pinned SAT validator's strict metadata parser and decoder-field checks pass for all10 inputs; this is structural compatibility only, not a SAT witness or full validation. A future solver model must assign all11985 variables and pass the unchanged full CNF/2048-input audit. Historical pending-status fields reflect preparation before independent review and are superseded by the frozen final S08 review, not edited in place.

This is a research preservation package. It makes no new SAT, UNSAT, shard-exhaustion or Lean acceptance claim. Main alone owns copy/push/admission. Packaging only snapshots and hashes permitted frozen sources and four explicitly finished runs.
'''
    put(Path('README.md'),readme.encode(),'generated archive documentation')
    manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':sorted(files.values(),key=lambda x:x['path']),
        'archived_bytes':sum(x['bytes'] for x in files.values()),'large_cnf_recipes':len(recipes),
        'large_raw_cnfs':0,'compiled_binaries':0,'incomplete_proof_omissions':4,'scope':summary['scope']}
    dump(A/'manifest.json',manifest)
    # Run only the portable standard-library restorer; verify every payload and recipe.
    command=['python3','-B',str(A/'scratch/orch/S06/restore_archive2_cnfs.py'),str(A),str(source),'--verify-only']
    with (O/'charge-archive-v1-restore.stdout').open('xb') as out,(O/'charge-archive-v1-restore.stderr').open('xb') as err:
        completed=subprocess.run(command,cwd=O,stdout=out,stderr=err,timeout=20)
    assert completed.returncode==0
    tarpath=O/'charge-archive-v1.tar.gz'
    with tarpath.open('xb') as f,gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
        for p in sorted(A.rglob('*')):
            if not p.is_file():continue
            info=tar.gettarinfo(str(p),arcname=str(p.relative_to(A)));info.uid=info.gid=info.mtime=0;info.uname=info.gname='';info.mode=0o644
            with p.open('rb') as data:tar.addfile(info,data)
    expected={e['path']:e for e in files.values()};expected['manifest.json']={'bytes':(A/'manifest.json').stat().st_size,'sha256':sha(A/'manifest.json')};seen=set()
    with tarfile.open(tarpath,'r:gz') as tar:
        for member in tar:
            assert member.isfile() and not member.issym() and not member.islnk();rel=Path(member.name)
            assert not rel.is_absolute() and '..' not in rel.parts and member.name not in seen;seen.add(member.name)
            raw=tar.extractfile(member).read();pin=expected[member.name];assert len(raw)==pin['bytes'] and digest(raw)==pin['sha256']
    assert seen==set(expected)
    record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_LOCAL_PACKAGING_AND_RECONSTRUCTION_PENDING_INDEPENDENT_DELIVERY_REVIEW',
        'source_sha256':sha(Path(__file__)),'archive':str(A),'manifest_sha256':sha(A/'manifest.json'),
        'tar_path':str(tarpath),'tar_sha256':sha(tarpath),'tar_bytes':tarpath.stat().st_size,'tar_members':len(seen),
        'manifest_files':len(files),'large_cnf_recipes':len(recipes),'all_tar_members_hash_bound':True,
        'finished_AAOA_runs':4,'all_finished_runs_UNKNOWN':True,'incomplete_proofs':partial_proofs and [dict(path=str(p),**v) for p,v in partial_proofs.items()],
        'restore_command':command,'restore_exit_code':completed.returncode,'restore_stdout_sha256':sha(O/'charge-archive-v1-restore.stdout'),
        'restore_stderr_sha256':sha(O/'charge-archive-v1-restore.stderr'),'elapsed_seconds':time.monotonic()-start,
        'solver_checker_Lean_launch':False,'read_running_directories':False}
    dump(O/'charge-archive-v1.record.json',record)
    print(json.dumps({k:v for k,v in record.items() if k not in ['incomplete_proofs','restore_command']},indent=2))


if __name__=='__main__':main()
