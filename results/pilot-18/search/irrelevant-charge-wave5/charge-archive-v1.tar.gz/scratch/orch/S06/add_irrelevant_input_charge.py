#!/usr/bin/env python3
"""Prepare a fresh conditional +1 ancestor-cost encoding; never launch solvers.

Mathematics: S01 irrelevant-input-charge.md, separately reviewed. These are
new mathematical restrictions, not an RUP certificate for the old CNF.
All original variables and clause bytes are preserved; append17 penalty bits.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT=Path('/tmp/oec/pequalnp-pilot-18')
OWN=ROOT/'orch/S06'
REPO=Path('/workspace/pequalnp-proofs')
COUNTER_SOURCE=REPO/'results/pilot-18/search/search_l1342_shard17_ancestorreverse.py'
COUNTER_SHA='b10d8832060d1c554fd3daa563b7159d515a3c55adc49718989eaa9bd0c2f24f'
MATH_SOURCE=ROOT/'orch/S01/irrelevant-input-charge.md'
MATH_SHA='951fd0d38db513a2fcfa98ddad5ef9c9dbc8c5d58acc4ba37867d0bc564af48f'
EDGES=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
       (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
NEIGHBORS=[[w for w in range(11) if tuple(sorted((v,w))) in EDGES] for v in range(11)]


def digest(raw):return hashlib.sha256(raw).hexdigest()
def sha(path):return digest(path.read_bytes())
def require(ok,message):
    if not ok:raise ValueError(message)
def clause_bytes(clauses):return ''.join(' '.join(map(str,c))+' 0\n' for c in clauses).encode('ascii')
def load_counter():
    require(sha(COUNTER_SOURCE)==COUNTER_SHA,'counter source mismatch')
    sys.dont_write_bytecode=True
    spec=importlib.util.spec_from_file_location('s06_pinned_counter',COUNTER_SOURCE)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    require(module.N==11 and module.EDGES==EDGES,'counter graph mismatch')
    return module


def inspect_counters(raw,meta):
    require(meta['first_junk']==17 and meta['size']==21,'wrong shard dimensions')
    require(meta['original_DAG'] and meta['productive_prefix'] and meta['prefix_ancestor_cost'] and meta['prefix_totalizer_reverse'],'missing normalization/counter prerequisites')
    require('irrelevant_input_charge' not in meta,'charge already present')
    require(meta['variables']==11968,'expected unchanged original variable universe')
    header,body=raw.split(b'\n',1)
    require(header==f"p cnf {meta['variables']} {meta['clauses']}".encode(),'header mismatch')
    require(raw.endswith(b'\n') and len(body.splitlines())==meta['clauses'],'clause count mismatch')
    require(digest(raw)==meta['sha256'],'metadata CNF hash mismatch')
    require(len(meta['partial_edge_cost_restrictions'])==17 and len(meta['prefix_ancestor_flags'])==17,'counter dimension mismatch')
    module=load_counter();records=[]
    for g,restriction in enumerate(meta['partial_edge_cost_restrictions']):
        support=meta['prefix_support_tables'][13+g]
        residual=restriction['residual_edge_flags'];cover=restriction['vertex_cover_flags'];anc=meta['prefix_ancestor_flags'][g]
        require(restriction['gate']==g and restriction['bound']==g+2,'bound mismatch')
        require(len(support)==11 and len(residual)==16 and len(cover)==11 and len(anc)==g,'cost input dimension mismatch')
        require(cover==list(range(cover[0],cover[0]+11)) and cover[0]==residual[-1]+1,'counter start allocation mismatch')
        values=support+residual+cover+[-a for a in anc]
        counter=module.CNF();counter.variables=cover[-1]
        output=module.totalizer_atleast(counter,values,g+3)
        require(len(output)==g+3 and output[-1]==restriction['overflow_flag']==counter.variables,'root threshold allocation mismatch')
        require(output[-2]==restriction['overflow_flag']-1,'penultimate threshold is not adjacent')
        block=clause_bytes(counter.clauses)
        require(body.count(block)==1,'exact signed counter clauses not uniquely present in parent')
        old_guards=clause_bytes([[-output[-1],bit] for bit in support])
        require(body.count(block+old_guards)==1,'counter/old full-support guards not contiguous')
        records.append({'gate':g,'bound':g+2,'input_literals':values,'support_literals':support,
            'root_thresholds':output,'penalty_threshold':output[-2],'old_overflow':output[-1],
            'reconstructed_counter_clauses':len(counter.clauses),'counter_clause_block_sha256':digest(block),
            'counter_first_variable':cover[-1]+1,'counter_last_variable':counter.variables})
    return records


def build_delta(meta,counters):
    penalties=[meta['variables']+1+g for g in range(17)]
    implications=[];guards=[];implication_records=[]
    for g,p in enumerate(penalties):
        support=meta['prefix_support_tables'][13+g]
        for h in range(g+1):
            ancestor=[] if h==g else [-meta['prefix_ancestor_flags'][g][h]]
            for side,key in [('left','lefts'),('right','rights')]:
                require(len(meta[key][h])==13+h,'selector source offset mismatch')
                for v in range(11):
                    clause=[p,support[v]]+[-support[u] for u in NEIGHBORS[v]]+ancestor+[-meta[key][h][v]]
                    implications.append(clause)
                    implication_records.append({'root_gate':g,'reader_gate':h,'side':side,'input':v,'clause':clause})
        threshold=counters[g]['penalty_threshold']
        guards.extend([[-p,-threshold,bit] for bit in support])
    require(len(implications)==3366 and len(guards)==187,'unexpected clause count')
    clauses=implications+guards
    require(all(1<=abs(x)<=11985 for c in clauses for x in c),'delta literal out of range')
    return penalties,clauses,implication_records


def prepare(parent,output,expected_cnf,expected_metadata):
    parent=parent.resolve(strict=True);output=output.absolute()
    require(output.parent.resolve().is_relative_to(OWN.resolve()),'output outside owned scratch')
    require(not output.exists() and not output.is_symlink(),'fresh output required')
    require(parent.is_relative_to(ROOT) or parent.is_relative_to(REPO),'input outside workspace')
    raw=parent.read_bytes();metadata_raw=parent.with_suffix('.json').read_bytes();meta=json.loads(metadata_raw)
    require(digest(raw)==expected_cnf and digest(metadata_raw)==expected_metadata,'parent pin mismatch')
    require(sha(MATH_SOURCE)==MATH_SHA,'math statement changed; fresh review required')
    counters=inspect_counters(raw,meta);penalties,clauses,implications=build_delta(meta,counters);delta=clause_bytes(clauses)
    result=f"p cnf 11985 {meta['clauses']+3553}\n".encode()+raw.split(b'\n',1)[1]+delta
    description={'version':'s06-irrelevant-charge-v1','mathematics_status':'PENDING_SEPARATE_INDEPENDENT_REVIEW_AT_PREPARATION',
        'implementation_status':'PREPARED_FOR_INDEPENDENT_REVIEW_NO_SOLVER',
        'parent_cnf_sha256':expected_cnf,'parent_metadata_sha256':expected_metadata,
        'math_source_path':str(MATH_SOURCE),'math_source_sha256':MATH_SHA,
        'counter_source_path':str(COUNTER_SOURCE),'counter_source_sha256':COUNTER_SHA,
        'generator_source_sha256':sha(Path(__file__)),'penalty_bits':penalties,
        'added_variables':17,'implication_clauses':3366,'conditional_threshold_clauses':187,
        'added_clauses':3553,'delta_sha256':digest(delta),'counters':counters,
        'threshold_semantics':'t_g is [sum(support,residual,cover,negated strict ancestors)>=g+2]; p_g AND proper support forbids t_g.',
        'cost_semantics':'M>=|S|+|H|+selected_cover-1+p for proper support, with minimum cover chosen existentially.',
        'full_support_exempt':True,'parent_body_byte_preserved':True,'all_old_indices_preserved':True,
        'not_an_RUP_certificate':True,'no_original_auxiliary_model_extension_claim':True}
    child=dict(meta,variables=11985,clauses=meta['clauses']+3553,sha256=digest(result),irrelevant_input_charge=description)
    output.mkdir(mode=0o700)
    (output/'instance.cnf').write_bytes(result);(output/'instance.json').write_text(json.dumps(child,indent=2)+'\n')
    (output/'delta.clauses').write_bytes(delta)
    (output/'thresholds.json').write_text(json.dumps(counters,indent=2)+'\n')
    record={'parent':str(parent),'parent_cnf_sha256':expected_cnf,'parent_metadata_sha256':expected_metadata,
        'cnf_sha256':digest(result),'metadata_sha256':sha(output/'instance.json'),'variables':11985,
        'clauses':child['clauses'],'delta_sha256':digest(delta),'added_variables':17,'added_clauses':3553,
        'source_sha256':sha(Path(__file__)),'math_source_sha256':MATH_SHA,'counter_source_sha256':COUNTER_SHA,
        'old_body_unchanged':True,'review_pending':True,'solver_launched':False}
    (output/'generation.json').write_text(json.dumps(record,indent=2)+'\n')
    require(parent.read_bytes()==raw and parent.with_suffix('.json').read_bytes()==metadata_raw,'parent changed during preparation')
    return record


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('parent',type=Path);p.add_argument('output',type=Path)
    p.add_argument('--parent-sha256',required=True);p.add_argument('--metadata-sha256',required=True);a=p.parse_args()
    print(json.dumps(prepare(a.parent,a.output,a.parent_sha256,a.metadata_sha256),indent=2))
