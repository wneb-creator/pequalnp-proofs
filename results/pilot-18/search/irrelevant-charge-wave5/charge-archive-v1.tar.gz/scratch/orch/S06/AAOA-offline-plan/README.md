# Reviewed AAOA offline command preparation

`commands-manifest.json` contains four unexecuted argv arrays for the unchanged reviewed T1..T4 CNFs. Every case passed the frozen runner's input/binary-only preflight, and no output case directory was created. All preflight stdout/stderr, copied metadata, exact clause deltas and review snapshots are retained. The generator's old pending-review strings are preserved; the later pinned S04 PASS reviews supersede them.

Each slot has at most one child: solver600seconds/1536MiBAS/512MiBperfile, then checker600seconds/3072MiBAS only after completedUNSAT, or fullSATvalidator30seconds/1536MiBAS. Hold the slot until the entire pipeline exits. Four proofs alone can occupy2GiB; logs and prior retained proofs need additional space. No global disk reservation is implemented.

Main alone chooses whether/when to start T1/T2 after the AAAA online pair fully exits, and T3/T4 after P/d pipelines fully exit, considering new candidate-pin readiness. No automated scheduler or process-control action was performed. Treat any SAT indication as a stop/escalation signal; only full validation establishes a candidate. UNSAT requires runnerexit0/VERIFIED_UNSAT. Timeout/abort/overflow/failure is UNKNOWN.

These four normal forms need the separate AAAA fallback for the reviewed existence cover. No cut was added and no original or normalized parent has been refuted by this preparation. Archive2-final remains frozen and ready for review.
