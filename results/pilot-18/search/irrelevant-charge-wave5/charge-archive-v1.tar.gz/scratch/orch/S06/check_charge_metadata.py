#!/usr/bin/env python3
"""Check frozen metadata with the pinned validator parser; no SAT audit/model."""
import datetime,hashlib,importlib.util,json,sys
from pathlib import Path
R=Path('/tmp/oec/pequalnp-pilot-18');O=R/'orch/S06';V=R/'lean-setup/validate_sat_candidate.py'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(V)=='b807c1a580ce1fa49da51d859e6bc5d94bab2f9f0cd359c35cef35686f826529'
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('pinned_validator',V);validator=importlib.util.module_from_spec(spec);spec.loader.exec_module(validator)
handoff=json.loads((O/'irrelevant-charge-handoff.json').read_text());records=[]
for case in handoff['family']:
    group='irrelevant-charge-AAAO-v1' if case['name'] in ['AAAO-RUP','AAAO-P-RUP','AAAO-d-RUP'] else 'irrelevant-charge-v1'
    cnf=O/group/case['name']/'instance.cnf';metadata=cnf.with_suffix('.json')
    child=validator.load_metadata(metadata.read_bytes());parent=validator.load_metadata(Path(case['parent']).with_suffix('.json').read_bytes())
    assert sha(cnf)==case['cnf_sha256']==child['sha256'] and sha(metadata)==case['metadata_sha256']
    assert cnf.read_bytes().split(b'\n',1)[0]==f"p cnf {child['variables']} {child['clauses']}".encode()
    assert child['variables']==11985 and child['size']==21
    assert all(child[k]==value for k,value in parent.items() if k not in ['variables','clauses','sha256'])
    assert set(child)==set(parent)|{'irrelevant_input_charge'}
    for key in ['ops','lefts','rights']:
        assert len(child[key])==21
    for g in range(21):
        validator.variable(child['ops'][g],child,'operation')
        for side in ['lefts','rights']:
            ids=child[side][g];assert len(ids)==13+g and len(set(ids))==len(ids)
            for x in ids:validator.variable(x,child,'operand selector')
    assert len(child['output_selectors'])==34
    for x in child['output_selectors']:validator.variable(x,child,'output selector')
    records.append({'name':case['name'],'cnf_sha256':sha(cnf),'metadata_sha256':sha(metadata),'strict_metadata_parser':'PASS','decoder_variable_shapes':'PASS','all_old_fields_preserved_except_counts_and_hash':True})
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_STRUCTURAL_METADATA_COMPATIBILITY_ONLY',
    'validator_sha256':sha(V),'source_sha256':sha(Path(__file__)),'cases':records,
    'scope':'Called only load_metadata/variable. No model, CNF satisfaction, target check or full SAT validation was attempted. A future solver model must assign all11985 variables and pass unchanged full audit.',
    'solver_launched':False,'wrote_input_metadata':False}
(O/'charge-metadata-compatibility.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'cases':len(records),'result_sha256':sha(O/'charge-metadata-compatibility.json')}))
