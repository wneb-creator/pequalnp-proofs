#!/usr/bin/env python3
"""Bounded scalar encoding controls and seven fresh inputs; no solver/checker."""
import copy
import datetime
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import random
import sys
import time

R=Path('/tmp/oec/pequalnp-pilot-18');O=R/'orch/S06';D=O/'irrelevant-charge-v1'
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('charge',O/'add_irrelevant_input_charge.py');M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def holds(clause,assignment):return any(assignment[abs(x)]==(x>0) for x in clause)


def witness_totalizer(values,cap,next_variable,assignment):
    """Independent semantic extension using exact subtree population counts."""
    if not values:return [],next_variable,0
    if len(values)==1:return values,next_variable,int(assignment[abs(values[0])]==(values[0]>0))
    split=len(values)//2
    left,next_variable,a=witness_totalizer(values[:split],cap,next_variable,assignment)
    right,next_variable,b=witness_totalizer(values[split:],cap,next_variable,assignment)
    out=[]
    for j in range(1,min(len(left)+len(right),cap)+1):
        next_variable+=1;out.append(next_variable);assignment[next_variable]=(a+b>=j)
    return out,next_variable,a+b


def main():
    start=time.monotonic();D.mkdir(mode=0o700);module=M.load_counter()
    parent=R/'original-dag-strong/original.cnf';raw=parent.read_bytes();meta=json.loads(parent.with_suffix('.json').read_text())
    assert sha(parent)=='38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08'
    assert sha(parent.with_suffix('.json'))=='5a430e86affc12584f964af39920201684505bafca4d34c1d30e6a10de3b9f51'
    counters=M.inspect_counters(raw,meta);penalties,delta,descriptions=M.build_delta(meta,counters)
    assert penalties==list(range(11969,11986)) and len(delta)==3553
    # Recover the graph independently from edge-row masks, rather than generator constants.
    neighbors=[0]*11
    for row in meta['rows'][:16]:
        vertices=[v for v in range(11) if row>>v&1];assert len(vertices)==2
        u,v=vertices;neighbors[u]|=1<<v;neighbors[v]|=1<<u
    assert [[u for u in range(11) if mask>>u&1] for mask in neighbors]==M.NEIGHBORS
    assert len({(r['root_gate'],r['reader_gate'],r['side'],r['input']) for r in descriptions})==3366
    for desc in descriptions:
        g,h,v=desc['root_gate'],desc['reader_gate'],desc['input'];s=meta['prefix_support_tables'][13+g]
        key={'left':'lefts','right':'rights'}[desc['side']]
        expected=[penalties[g],s[v]]+[-s[u] for u in range(11) if neighbors[v]>>u&1]
        if h<g:expected.append(-meta['prefix_ancestor_flags'][g][h])
        expected.append(-meta[key][h][v]);assert desc['clause']==expected
    trigger_rows=0
    for support in range(2048):
        for v in range(11):
            structural=not(support>>v&1) and (neighbors[v]&support)==neighbors[v]
            for ancestor,read,p in itertools.product([False,True],repeat=3):
                clause=p or bool(support>>v&1) or bool(neighbors[v]&~support) or not ancestor or not read
                assert clause==(p or not(structural and ancestor and read));trigger_rows+=1
    # Raw ancestry is compared against dynamic input reachability in actual source DAGs.
    rng=random.Random(13420631);path_checks=0;positive_triggers=0
    for example in range(32):
        gates=[];gate_anc=[];raw_anc=[]
        for g in range(17):
            ports=[rng.randrange(13+g),rng.randrange(13+g)];gates.append(ports);ga=set();ra=set()
            for w in ports:
                if w<11:ra.add(w)
                elif w>=13:ga.add(w-13);ga.update(gate_anc[w-13]);ra.update(raw_anc[w-13])
            gate_anc.append(ga);raw_anc.append(ra)
            supports=[0,2047,1536,80]+[rng.randrange(2048) for _ in range(12)]
            for s in supports:
                trigger_v={v for v in ra if not(s>>v&1) and neighbors[v]&s==neighbors[v]}
                witnessed={v for h in ga|{g} for v in gates[h] if v<11 and not(s>>v&1) and neighbors[v]&s==neighbors[v]}
                assert trigger_v==witnessed;path_checks+=1;positive_triggers+=bool(witnessed)
    small_truths=0;small_clause_checks=0
    for n in range(1,8):
        values=[i+1 if i%2==0 else -(i+1) for i in range(n)]
        for cap in range(1,n+1):
            cnf=module.CNF();cnf.variables=n;out=module.totalizer_atleast(cnf,values,cap)
            for bits in itertools.product([False,True],repeat=n):
                assignment={i+1:bits[i] for i in range(n)};expected,nv,count=witness_totalizer(values,cap,n,assignment)
                assert out==expected and nv==cnf.variables
                assert all(holds(c,assignment) for c in cnf.clauses)
                assert [assignment[abs(x)]==(x>0) for x in out]==[count>=j for j in range(1,len(out)+1)]
                small_truths+=1;small_clause_checks+=len(cnf.clauses)
    # Every actual counter is tested around the tightened and original boundaries.
    actual_counter_tests=0;actual_clause_checks=0;guard_tests=0
    for g,c in enumerate(counters):
        values=c['input_literals'];bound=g+2;cap=g+3;initial=c['counter_first_variable']-1
        cnf=module.CNF();cnf.variables=initial;out=module.totalizer_atleast(cnf,values,cap)
        counts=sorted({0,bound-1,bound,bound+1,len(values)})
        for count in counts:
            selected=set(rng.sample(range(len(values)),count));assignment={abs(x):((i in selected)==(x>0)) for i,x in enumerate(values)}
            expected,nv,total=witness_totalizer(values,cap,initial,assignment)
            assert expected==out and nv==cnf.variables and total==count
            assert all(holds(clause,assignment) for clause in cnf.clauses)
            assert assignment[c['penalty_threshold']]==(count>=bound)
            assert assignment[c['old_overflow']]==(count>bound)
            actual_counter_tests+=1;actual_clause_checks+=len(cnf.clauses)
        for count in range(len(values)+1):
            for full,p in itertools.product([False,True],repeat=2):
                old=full or count<=bound;new_guard=full or not p or count<bound
                assert (old and new_guard)==(full or count+int(p)<=bound);guard_tests+=1
        # Boundary negative control: guarding old overflow instead would miss the +1.
        assert (not True or not (bound>bound)) and not (not True or not (bound>=bound))
    # Reject unsafe metadata or a missing pre-existing counter clause before producing output.
    bad=copy.deepcopy(meta);bad['partial_edge_cost_restrictions'][0]['overflow_flag']+=1
    try:M.inspect_counters(raw,bad);raise AssertionError('bad overflow accepted')
    except ValueError:pass
    cnf=module.CNF();cnf.variables=counters[0]['counter_first_variable']-1
    module.totalizer_atleast(cnf,counters[0]['input_literals'],3)
    block=M.clause_bytes(cnf.clauses);changed=raw.replace(block,block.replace(b' 0\n',b' 1 0\n',1),1)
    bad=copy.deepcopy(meta);bad['sha256']=M.digest(changed)
    try:M.inspect_counters(changed,bad);raise AssertionError('modified counter accepted')
    except ValueError:pass
    try:M.prepare(parent,D/'bad-pin','0'*64,sha(parent.with_suffix('.json')));raise AssertionError('wrong pin accepted')
    except ValueError:pass
    assert not (D/'bad-pin').exists()
    chain=json.loads((R/'orch/S04/chain-review.json').read_text());aaoa=json.loads((R/'orch/S04/aaoa-delta-review.json').read_text())
    parents=[('original',parent,{'cnf_sha256':sha(parent),'metadata_sha256':sha(parent.with_suffix('.json'))})]
    parents += [(name,R/'orch/S01/consecutive-junk-v2'/(name+'.cnf'),binding) for name,binding in chain['cases'].items()]
    parents += [(name,R/'orch/S01/aaoa-four-v1'/(name+'.cnf'),binding) for name,binding in aaoa['cases'].items()]
    family=[]
    for name,source,binding in parents:
        before=source.read_bytes();beforemeta=source.with_suffix('.json').read_bytes()
        record=M.prepare(source,D/name,binding['cnf_sha256'],binding['metadata_sha256'])
        child=(D/name/'instance.cnf').read_bytes();oldmeta=json.loads(beforemeta);newmeta=json.loads((D/name/'instance.json').read_text())
        assert child.split(b'\n',1)[1]==before.split(b'\n',1)[1]+M.clause_bytes(delta)
        assert newmeta['variables']==11985 and newmeta['clauses']==oldmeta['clauses']+3553
        assert all(newmeta[k]==v for k,v in oldmeta.items() if k not in ['variables','clauses','sha256'])
        assert source.read_bytes()==before and source.with_suffix('.json').read_bytes()==beforemeta
        record['name']=name;family.append(record)
    assert len({x['delta_sha256'] for x in family})==1 and len(family)==7
    # Fresh-directory refusal must preserve the already generated first input.
    before=sha(D/'original/instance.cnf')
    try:M.prepare(parent,D/'original',sha(parent),sha(parent.with_suffix('.json')));raise AssertionError('reuse accepted')
    except ValueError:pass
    assert sha(D/'original/instance.cnf')==before
    controls={'trigger_truth_rows':trigger_rows,'syntactic_path_checks':path_checks,'positive_path_triggers':positive_triggers,
        'small_signed_counter_truths':small_truths,'small_counter_clause_checks':small_clause_checks,
        'actual_counter_boundary_tests':actual_counter_tests,'actual_counter_clause_checks':actual_clause_checks,
        'conditional_bound_arithmetic_tests':guard_tests,'independent_implication_structure_checks':3366,
        'negative_controls':['off_by_one_old_overflow_detected','modified_overflow_metadata_rejected','modified_counter_clause_rejected','wrong_parent_pin_rejected','fresh_directory_reuse_rejected'],
        'fresh_parent_delta_and_metadata_checks':7}
    result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_SCALAR_ENCODING_CONTROLS_MATH_AND_INDEPENDENT_IMPLEMENTATION_REVIEW_PENDING',
        'elapsed_seconds':time.monotonic()-start,'source_sha256':sha(Path(__file__)),'generator_source_sha256':sha(O/'add_irrelevant_input_charge.py'),
        'math_source_sha256':M.MATH_SHA,'counter_source_sha256':M.COUNTER_SHA,'controls':controls,'family':family,
        'scope':'No mathematical proof, solver, checker, Lean, active-input change or launch approval. Exact7parent deltas prepared for review.'}
    dump(D/'controls.json',result);dump(D/'family.json',family)
    dump(D/'artifact-manifest.json',{'files':{str(p.relative_to(D)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(D.rglob('*')) if p.is_file()},'source_sha256':sha(Path(__file__))})
    print(json.dumps({'status':result['status'],'elapsed_seconds':result['elapsed_seconds'],'controls':controls,'family_count':len(family),'controls_sha256':sha(D/'controls.json'),'generator_sha256':result['generator_source_sha256']},indent=2))


if __name__=='__main__':main()
