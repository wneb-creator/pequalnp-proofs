#!/usr/bin/env python3
"""Bind existing reviewed AAOA CNFs to unexecuted offline commands; preflight only."""
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/tmp/oec/pequalnp-pilot-18')
OWN = ROOT / 'orch/S06'
OUT = OWN / 'AAOA-offline-plan'
INPUT = ROOT / 'orch/S01/aaoa-four-v1'
RUNNER = OWN / 'offline_checked_cadical.py'
RUNNER_SHA = 'aa5d13bb83ab79e47b9794809c3c06dc153544975cd1131afbdeaef7c18d484a'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def main():
    assert sha(RUNNER) == RUNNER_SHA
    frozen = {
        ROOT / 'orch/S04/aaOA-review.json': '43c372c7bf7ce40f262a907323708c182e5e67b58b660ab8ff03922ce4a27b48',
        ROOT / 'orch/S04/aaoa-delta-review.json': 'd7ba2eb9f1dec7206aa7c6c9a440dc135482b1b13ddc9085c9cac804b2c40704',
        ROOT / 'orch/S08/offline-runner-review/review.json': 'e3a1dfb01fe24acf900e34ae15012c78b3ab15a574240334de0fdfc535ac7b03',
        ROOT / 'orch/S08/offline-real-case13-review/review.json': 'c1a22439752d28b1a1640d87553de7ae14246a8ab697fd80775f6495a9534f99',
        ROOT / 'orch/S01/build_aaoa_shapes.py': '6bcb7e1abdb2c65ffdc9a6a1ced8554509ed2f96a40a756f30d718708256ae63',
        INPUT / 'family.json': 'b05805738736e9b04257657dd8bd39d0fe1c6c31428f191a9fa727fb32109401',
    }
    for path, expected in frozen.items():
        assert sha(path) == expected, path
    review = json.loads((ROOT / 'orch/S04/aaoa-delta-review.json').read_text())
    family = json.loads((INPUT / 'family.json').read_text())
    parent = ROOT / 'orch/S01/consecutive-junk-v2/AAOA.cnf'
    assert sha(parent) == review['parent_sha256']
    assert sha(parent.with_suffix('.json')) == review['parent_metadata_sha256']
    body = parent.read_bytes().split(b'\n', 1)[1]
    OUT.mkdir(mode=0o700)
    # Copies preserve historical pending-status fields; later reviewed bindings supersede them.
    snapshots = []
    for i, (path, expected) in enumerate(frozen.items()):
        target = OUT / ('evidence-' + str(i) + '-' + path.name)
        target.write_bytes(path.read_bytes())
        assert sha(target) == expected
        snapshots.append({'source': str(path), 'snapshot': str(target), 'sha256': expected, 'bytes': target.stat().st_size})
    cases = []
    for name in ['T1', 'T2', 'T3', 'T4']:
        cnf = INPUT / (name + '.cnf')
        metadata = cnf.with_suffix('.json')
        binding = review['cases'][name]
        assert sha(cnf) == binding['cnf_sha256'] == family['files'][name]['cnf_sha256']
        assert sha(metadata) == binding['metadata_sha256'] == family['files'][name]['metadata_sha256']
        raw = cnf.read_bytes()
        header, child_body = raw.split(b'\n', 1)
        assert header == f"p cnf 11968 {binding['clauses']}".encode()
        assert child_body.startswith(body) and len(child_body.splitlines()) == binding['clauses']
        delta = child_body[len(body):]
        assert len(delta.splitlines()) == binding['added_clauses']
        meta = json.loads(metadata.read_text())
        assert meta['sha256'] == binding['cnf_sha256'] and meta['aaoa_shape'] == name
        assert meta['aaoa_parent_sha256'] == review['parent_sha256']
        assert meta['aaoa_parent_metadata_sha256'] == review['parent_metadata_sha256']
        assert meta['aaoa_generator_sha256'] == review['source_sha256']
        assert meta['aaoa_coverage_requires_AAAA_fallback'] is True
        assert meta['aaoa_claimed_as_logical_consequence'] is False
        assert delta == ''.join(' '.join(map(str, clause)) + ' 0\n' for clause in meta['aaoa_added_clauses']).encode()
        (OUT / (name + '.metadata.json')).write_bytes(metadata.read_bytes())
        (OUT / (name + '.delta.clauses')).write_bytes(delta)
        output = OWN / ('offline-AAOA-' + name + '-wave1')
        assert not output.exists() and not output.is_symlink()
        command = ['python3', '-B', str(RUNNER), str(cnf), str(output),
                   '--cnf-sha256', binding['cnf_sha256'], '--metadata-sha256', binding['metadata_sha256'],
                   '--solver-seconds', '600', '--checker-seconds', '600', '--proof-mib', '512',
                   '--max-records', '100000000', '--min-free-mib', '1024',
                   '--abort-file', str(ROOT / 'DESK_ERROR.response')]
        preflight_command = command + ['--preflight-only']
        start = datetime.datetime.now(datetime.timezone.utc).isoformat()
        with (OUT / (name + '.preflight.stdout')).open('xb') as out, (OUT / (name + '.preflight.stderr')).open('xb') as err:
            done = subprocess.run(preflight_command, cwd=OWN, stdout=out, stderr=err, timeout=10)
        preflight = json.loads((OUT / (name + '.preflight.stdout')).read_text())
        assert done.returncode == 0 and preflight['status'] == 'PREFLIGHT_PASS'
        assert preflight['solver_launched'] is False and preflight['source_sha256'] == RUNNER_SHA
        assert not output.exists() and not output.is_symlink()
        assert sha(cnf) == binding['cnf_sha256'] and sha(metadata) == binding['metadata_sha256']
        cases.append({'case': name, 'formula': meta['aaoa_formula'], 'cnf': str(cnf), 'metadata': str(metadata),
            'cnf_sha256': binding['cnf_sha256'], 'metadata_sha256': binding['metadata_sha256'],
            'variables': 11968, 'clauses': binding['clauses'], 'added_clauses': binding['added_clauses'],
            'output': str(output), 'output_fresh_at_preflight': True, 'command': command,
            'production_executed': False, 'no_new_cuts_or_input_changes': True,
            'preflight': {'command': preflight_command, 'started_utc': start, 'exit_code': done.returncode,
                'status': preflight['status'], 'stdout_sha256': sha(OUT / (name + '.preflight.stdout')),
                'stderr_sha256': sha(OUT / (name + '.preflight.stderr')), 'started_worker': False}})
    result = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'status': 'READY_FOR_MAIN_REVIEW_NOT_LAUNCHED', 'source_sha256': sha(Path(__file__)),
        'runner_path': str(RUNNER), 'runner_sha256': RUNNER_SHA, 'cases': cases,
        'review_snapshots': snapshots, 'parent_cnf': str(parent), 'parent_sha256': review['parent_sha256'],
        'parent_metadata_sha256': review['parent_metadata_sha256'],
        'limits_per_case': {'solver_wall_seconds': 600, 'checker_wall_seconds': 600,
            'SAT_validator_wall_seconds': 30, 'solver_address_space_mib': 1536,
            'checker_address_space_mib': 3072, 'SAT_validator_address_space_mib': 1536,
            'proof_file_cap_mib': 512, 'solver_each_log_file_cap_mib': 512,
            'checker_or_validator_each_log_file_cap_mib': 64, 'proof_max_zero_bytes': 100000000,
            'minimum_free_disk_mib': 1024, 'active_child_processes_maximum': 1},
        'acceptance': {'UNSAT': 'runner exit0 plus VERIFIED_UNSAT; strict solver20/soleUNSAT then independent checker0/soleVERIFIED_UNSAT and pinned unchanged inputs/proof/tools',
            'SAT': 'runner exit10 plus VALIDATED_SAT; pinned full2048-input validator, gate bound and provenance required',
            'limits_failures_aborts': 'UNKNOWN, not a proof; preserve full diagnostics and retained partial proof'},
        'scheduling_proposal_not_authorization': {'T1_T2': 'Main may assign the two slots only after the AAAA online solver AND checker have exited and complete terminal logs are preserved.',
            'T3_T4': 'Main may assign slots only after AAAO P/d complete the entire solver/checker/validator pipeline; solver wall expiry alone does not release a checker-held slot.',
            'candidate_priority': 'Main decides after new candidate-pin readiness; no timer, scheduler or auto-launch is installed.',
            'hold_slot_through_checker': True, 'stop_and_escalate_on_any_SAT_indication': True},
        'disk': {'free_bytes_at_preparation': shutil.disk_usage(OWN).free,
            'four_proofs_maximum_bytes': 4 * 512 * 1024**2,
            'reservation': 'No global disk reservation. Include per-file logs, snapshots and retained earlier proofs in admission.'},
        'scope': 'Exactly the existing reviewed four AAOA CNFs, no cut changes. Coverage also requires the separate AAAA fallback; no exhaustion claim.',
        'historical_pending_metadata': 'Original generator fields remain unchanged; pinned later S04 mathematical and exact-delta PASS reviews supply review status.',
        'archive2_final_handoff_sha256': sha(OWN / 'archive2-final-handoff.json'), 'worker_launch': False}
    save_json(OUT / 'commands-manifest.json', result)
    (OUT / 'README.md').write_text('''# Reviewed AAOA offline command preparation

`commands-manifest.json` contains four unexecuted argv arrays for the unchanged reviewed T1..T4 CNFs. Every case passed the frozen runner's input/binary-only preflight, and no output case directory was created. All preflight stdout/stderr, copied metadata, exact clause deltas and review snapshots are retained. The generator's old pending-review strings are preserved; the later pinned S04 PASS reviews supersede them.

Each slot has at most one child: solver600seconds/1536MiBAS/512MiBperfile, then checker600seconds/3072MiBAS only after completedUNSAT, or fullSATvalidator30seconds/1536MiBAS. Hold the slot until the entire pipeline exits. Four proofs alone can occupy2GiB; logs and prior retained proofs need additional space. No global disk reservation is implemented.

Main alone chooses whether/when to start T1/T2 after the AAAA online pair fully exits, and T3/T4 after P/d pipelines fully exit, considering new candidate-pin readiness. No automated scheduler or process-control action was performed. Treat any SAT indication as a stop/escalation signal; only full validation establishes a candidate. UNSAT requires runnerexit0/VERIFIED_UNSAT. Timeout/abort/overflow/failure is UNKNOWN.

These four normal forms need the separate AAAA fallback for the reviewed existence cover. No cut was added and no original or normalized parent has been refuted by this preparation. Archive2-final remains frozen and ready for review.
''')
    inventory = {str(p.relative_to(OUT)): {'bytes': p.stat().st_size, 'sha256': sha(p)}
                 for p in sorted(OUT.iterdir()) if p.is_file()}
    save_json(OUT / 'artifact-manifest.json', {'utc': result['utc'], 'files': inventory,
        'preparer_source': str(Path(__file__)), 'preparer_source_sha256': sha(Path(__file__)), 'worker_launch': False})
    print(json.dumps({'status': result['status'], 'commands_manifest_sha256': sha(OUT / 'commands-manifest.json'),
        'artifact_manifest_sha256': sha(OUT / 'artifact-manifest.json'), 'preflight_cases_passed': 4, 'worker_launch': False}))


if __name__ == '__main__':
    main()
