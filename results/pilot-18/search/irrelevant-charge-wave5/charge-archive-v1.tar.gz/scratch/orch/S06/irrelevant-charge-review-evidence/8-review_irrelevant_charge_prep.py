#!/usr/bin/env python3
"""Read-only counter/specification review; no generator or SAT solver execution."""
from pathlib import Path
import ast, datetime, hashlib, itertools, json, time, traceback
R=Path('/tmp/oec/pequalnp-pilot-18'); W=Path('/workspace/pequalnp-proofs'); O=R/'orch/S08/irrelevant-charge-prep-review'
O.mkdir(exist_ok=True); (O/'snapshots').mkdir(exist_ok=True)
start=time.monotonic(); bindings={}; checks={}; sha=lambda b:hashlib.sha256(b).hexdigest()
def bind(p,snapshot=False):
 b=p.read_bytes(); bindings[str(p)]={'bytes':len(b),'sha256':sha(b)}
 if snapshot:(O/'snapshots'/p.name).write_bytes(b)
 return b
try:
 source=W/'results/pilot-18/search/search_l1342_shard17_ancestorreverse.py'
 rawsource=bind(source,True); assert sha(rawsource)=='b10d8832060d1c554fd3daa563b7159d515a3c55adc49718989eaa9bd0c2f24f'
 math=bind(R/'orch/S01/irrelevant-input-charge.md',True);assert sha(math)=='951fd0d38db513a2fcfa98ddad5ef9c9dbc8c5d58acc4ba37867d0bc564af48f'
 parent=bind(R/'original-dag-strong/original.cnf'); assert sha(parent)=='38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08'
 data=json.loads(bind(R/'original-dag-strong/original.json',True))
 s04=json.loads(bind(R/'orch/S04/irrelevant-input-review.json',True)); bind(R/'orch/S04/review_irrelevant_input.py',True)
 bind(R/'orch/S04/irrelevant-input-review.stdout.log',True)
 assert s04['verdict']=='PASS_MATHEMATICS_TRIGGER_SPEC_AND_PINNED_COUNTER_REUSE' and s04['reviewed_math_sha256']==sha(math)
 draft=bind(R/'orch/S06/add_irrelevant_input_charge.py',True)
 commands=json.loads(bind(R/'orch/S06/AAOA-offline-plan/commands-manifest.json',True)); frozen=[]
 for c in commands['cases']:
  for key in ['cnf','metadata']:
   p=Path(c[key]); b=bind(p);assert sha(b)==c[key+'_sha256'];frozen.append(p)
 # Extract only the existing counter and its in-memory CNF class. Do not run a generator.
 tree=ast.parse(rawsource); picked=[n for n in tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name in ['CNF','totalizer_atleast']]
 assert len(picked)==2; ns={};exec(compile(ast.Module(body=picked,type_ignores=[]),str(source),'exec'),ns)
 CNF=ns['CNF']; counter=ns['totalizer_atleast']; networks=[]
 for g,row in enumerate(data['partial_edge_cost_restrictions']):
  support=data['prefix_support_tables'][13+g]; residual=row['residual_edge_flags']; cover=row['vertex_cover_flags']; ancestors=data['prefix_ancestor_flags'][g]
  inputs=support+residual+cover+[-a for a in ancestors]; assert len(inputs)==38+g and len(set(map(abs,inputs)))==len(inputs)
  cnf=CNF();cnf.variables=cover[-1]; out=counter(cnf,inputs,g+3)
  body=''.join(' '.join(map(str,c))+' 0\n' for c in cnf.clauses).encode()
  assert parent.count(body)==1 and out[-1]==row['overflow_flag'] and out[-2]==out[-1]-1
  guards=''.join(f'-{out[-1]} {s} 0\n' for s in support).encode(); assert parent.count(body+guards)==1
  assert s04['existing_counter_thresholds'][g]['at_least_bound']==out[-2]
  networks.append({'gate':g,'sum_inputs':inputs,'threshold_index':g+2,'threshold_literal':out[-2],'overflow_literal':out[-1],'network_sha256':sha(body),'clauses':len(cnf.clauses)})
 checks['pinned_networks']=networks
 # Exactness under signed literals: fixed inputs must force all stored thresholds,
 # including capped merges. This bounded scalar unit propagation is not a SAT search.
 def propagate(clauses,a):
  a=dict(a)
  while True:
   changed=False
   for clause in clauses:
    if any(abs(l) in a and a[abs(l)]==(l>0) for l in clause):continue
    unknown=[l for l in clause if abs(l) not in a]
    assert unknown, 'contradiction under prescribed input'
    if len(unknown)==1:
     l=unknown[0];a[abs(l)]=l>0;changed=True
   if not changed:return a
 models=0
 for n in range(1,7):
  values=[i if i%2 else -i for i in range(1,n+1)]
  for cap in range(1,n+1):
   c=CNF();c.variables=n;out=counter(c,values,cap)
   for mask in range(1<<n):
    a={i+1:bool(mask>>i&1) for i in range(n)};a=propagate(c.clauses,a)
    weight=sum(a[abs(l)]==(l>0) for l in values)
    assert all(abs(l) in a and (a[abs(l)]==(l>0))==(weight>=i+1) for i,l in enumerate(out));models+=1
 checks['bounded_signed_counter_exactness']={'n_max':6,'all_input_assignments_and_caps':models,'all_thresholds_forced':True,'solver':False}
 # Independent integer algebra includes proper empty support and empty residual.
 algebra=0
 for g in range(17):
  for a in range(g+1):
   for s,e,c,p in itertools.product(range(11),range(17),range(12),range(2)):
    t=s+e+c+g-a;m=1+a;old=t<=g+2;link=not p or t<g+2
    assert (old and link)==(m>=s+e+c-1+p);algebra+=1
 checks['cost_algebra']={'cases':algebra,'M':'1+A','T':'|S|+|H|+|C|+g-A','proper_support_bound':'T+p<=g+2','penalty_link':'p -> not(T>=g+2)'}
 edges=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
 neigh=[sum(1<<(b if a==v else a) for a,b in edges if v in (a,b)) for v in range(11)]
 trigger_count=0
 for s in range(2048):
  for v in range(11):
   eligible=not(s>>v&1) and neigh[v]&~s==0
   for anc,reads,p in itertools.product(range(2),repeat=3):
    ordinary=bool(p or s>>v&1 or neigh[v]&~s or not anc or not reads)
    assert ordinary==(not(eligible and anc and reads) or bool(p));trigger_count+=1
   if s in [0,2047]:assert not eligible
 checks['trigger_truth_table']={'checks':trigger_count,'empty_and_full_support_never_trigger_for_this_graph':True,'raw_inputs_only':list(range(11)),'constants_excluded':[11,12],'self_ancestor_omitted':True}
 # Concrete cone controls distinguish syntactic ancestry from singleton support,
 # include a dead reader, FALSE and TRUE constants, and empty accepted residual H.
 def inspect(gates,out):
  supp=[1<<v for v in range(11)]+[0,2047]; rows=[sum(1<<i for i,(a,b) in enumerate(edges) if v in(a,b)) for v in range(11)]+[0,65535]
  for op,a,b in gates:
   supp.append(supp[a]|supp[b] if op=='or' else supp[a]&supp[b]);rows.append(rows[a]|rows[b] if op=='or' else rows[a]&rows[b])
  cone=set();raw=set()
  def visit(w):
   if w<13:
    if w<11:raw.add(w)
    return
   if w in cone:return
   cone.add(w);_,a,b=gates[w-13];visit(a);visit(b)
  visit(out);s=supp[out];trigger=[v for v in raw if not(s>>v&1) and neigh[v]&~s==0]
  H=[e for i,e in enumerate(edges) if rows[out]>>i&1 and not(s&sum(1<<v for v in e))]
  return {'gates':gates,'output':out,'support':s,'raw_ancestors':sorted(raw),'gate_ancestors':sorted(cone),'trigger_vertices':sorted(trigger),'accepted_residual_edges':H}
 controls={
  'hidden_raw_input_and_empty_H':inspect([('and',0,9),('or',9,10),('or',13,14)],15),
  'same_support_without_raw_input':inspect([('or',9,10)],13),
  'dead_raw_reader_is_not_ancestor':inspect([('and',0,9),('or',9,10)],14),
  'free_TRUE_copy':inspect([('or',12,12)],13),
  'free_FALSE_copy':inspect([('or',11,11)],13)}
 assert controls['hidden_raw_input_and_empty_H']['trigger_vertices']==[0] and not controls['hidden_raw_input_and_empty_H']['accepted_residual_edges']
 assert all(not c['trigger_vertices'] for name,c in controls.items() if name!='hidden_raw_input_and_empty_H')
 checks['syntactic_reachability_and_boundary_controls']=controls
 # Both link variants have the same projected admissibility with existential p;
 # full support cannot force p, hence choose false for the unconditional link.
 projection=0
 for g in range(17):
  for full,trigger,t in itertools.product(range(2),range(2),range(55)):
   if full and trigger:continue
   old=bool(full or t<=g+2)
   guarded=any(old and (not trigger or p) and (full or not p or t<g+2) for p in range(2))
   plain=any(old and (not trigger or p) and (not p or t<g+2) for p in range(2))
   assert guarded==plain;projection+=1
 checks['guarded_vs_plain_existential_link']={'cases':projection,'equal_projection':True,'guarded_added_clauses':3553,'plain_added_clauses':3383,'added_variables':17,'prefer_existing_S06_choice':'No change requested merely to save 170 clauses.'}
 checks['cover_witness_caveat']={'H_empty':True,'S_size':2,'M':3,'penalty':1,'old_cover_size':2,'old_inequality':True,'same_cover_new_inequality':False,'minimum_cover_size':0,'minimum_cover_new_inequality':True,'scope':'Valid actual prefix example exists in reachability controls; no every-old-auxiliary-assignment extension claim.'}
 # Persist all boundary controls and hashes, and establish no parent/input writes.
 for p in frozen+[source,R/'original-dag-strong/original.cnf',R/'original-dag-strong/original.json']:
  assert sha(p.read_bytes())==bindings[str(p)]['sha256']
 checks['active_AAOA_four_CNF_and_metadata_pins_unchanged']=True
 checks['math_review_source']={'S04_review_sha256':bindings[str(R/'orch/S04/irrelevant-input-review.json')]['sha256'],'math_sha256':sha(math),'scope':'Independent encoding/specification review relies on separately reviewed actual-circuit charge theorem; no Lean theorem/UNSAT/global claim.'}
 checks['S06_draft']={'sha256':sha(draft),'status':'Observed draft, final handoff and emitted children not yet accepted','guarded_3553_clause_form_matches_spec':True}
 verdict='PASS_COUNTER_SPECIFICATION_AND_BOUNDARY_PREPARATION_NOT_FINAL_IMPLEMENTATION'
except Exception:
 verdict='FAIL';(O/'failure.txt').write_text(traceback.format_exc());raise
finally:
 report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':locals().get('verdict','FAIL'),'script_sha256':sha(Path(__file__).read_bytes()),'seconds':time.monotonic()-start,'bindings':bindings,'checks':checks,'solver_run':False,'Lean_run':False,'CNF_mutations':False,'implementation_duplicated':False}
 (O/'review.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'verdict':report['verdict'],'review_sha256':sha((O/'review.json').read_bytes()),'seconds':report['seconds'],'checks':list(checks)}))
