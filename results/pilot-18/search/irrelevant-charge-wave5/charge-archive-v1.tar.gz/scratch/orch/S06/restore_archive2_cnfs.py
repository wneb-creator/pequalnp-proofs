#!/usr/bin/env python3
"""Verify archive2 inventory and reconstruct omitted CNFs without starting workers."""
import argparse
import hashlib
import json
from pathlib import Path


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def safe(root, relative):
    p = Path(relative)
    assert not p.is_absolute() and '..' not in p.parts
    return root / p


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('archive', type=Path)
    p.add_argument('original', type=Path)
    p.add_argument('output', type=Path, nargs='?')
    p.add_argument('--verify-only', action='store_true')
    a = p.parse_args()
    manifest = json.loads((a.archive / 'manifest.json').read_text())
    names = set()
    for item in manifest['files']:
        assert item['path'] not in names
        names.add(item['path'])
        source = safe(a.archive, item['path'])
        assert source.is_file() and not source.is_symlink()
        raw = source.read_bytes()
        assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
    actual = {str(p.relative_to(a.archive)) for p in a.archive.rglob('*') if p.is_file()}
    assert actual == names | {'manifest.json'}
    recipes = json.loads((a.archive / 'cnf-recipes.json').read_text())
    original = a.original.read_bytes()
    assert len(original) == recipes['parent_bytes'] and sha(original) == recipes['parent_sha256']
    body = original.split(b'\n', 1)[1]
    if not a.verify_only:
        assert a.output is not None
        a.output.mkdir(parents=True, exist_ok=False)
    seen = set()
    for item in recipes['recipes']:
        assert item['relative_path'] not in seen and item['relative_path'] not in names
        seen.add(item['relative_path'])
        delta = safe(a.archive, item['delta_path']).read_bytes()
        assert sha(delta) == item['delta_sha256']
        raw = item['header'].encode('ascii') + b'\n' + body + delta
        assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
        fields = item['header'].split()
        assert fields[:2] == ['p', 'cnf'] and len(fields) == 4
        assert len(body.splitlines()) + len(delta.splitlines()) == int(fields[3])
        if not a.verify_only:
            target = safe(a.output, item['relative_path'])
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
    print(json.dumps({'status': 'PASS', 'manifest_files': len(names), 'reconstructed_CNF_count': len(seen),
                      'wrote_files': not a.verify_only, 'started_workers': False}))


if __name__ == '__main__':
    main()
