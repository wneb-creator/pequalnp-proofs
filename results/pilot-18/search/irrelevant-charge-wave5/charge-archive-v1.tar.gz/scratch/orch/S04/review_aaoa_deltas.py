from pathlib import Path
import hashlib
import itertools
import json
import random
import time

ROOT=Path('/tmp/oec/pequalnp-pilot-18');OUT=ROOT/'orch/S04'
PARENT=ROOT/'orch/S01/consecutive-junk-v2/AAOA.cnf'
DIRECTORY=ROOT/'orch/S01/aaoa-four-v1'
SOURCE=ROOT/'orch/S01/build_aaoa_shapes.py'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

# Independently transcribed from the reviewed four gate schedules.
LAYOUTS={
 'T1':[[None,None],[None,30],[None,31],[None,32]],
 'T2':[[None,None],[None,None],[30,31],[None,32]],
 'T3':[[None,None],[None,None],[None,31],[30,32]],
 'T4':[[None,None],[None,30],[None,None],[31,32]]}
ORDERS={
 'T1':[(17,0,17,1),(17,1,18,0)],
 'T2':[(17,0,17,1),(18,0,18,1),(17,0,18,0)],
 'T3':[(17,0,17,1),(18,0,18,1)],
 'T4':[(17,0,17,1),(17,1,18,0),(19,0,19,1)]}

def schedule(name,leaves):
    a,b,c,d,e=leaves
    if name=='T1':
        c,d,e=sorted([c,d,e]);return [[c,d],[e,30],[b,31],[a,32]]
    if name=='T2':
        p,q=sorted([sorted([b,c]),sorted([d,e])]);return [p,q,[30,31],[a,32]]
    if name=='T3':return [sorted([a,b]),sorted([d,e]),[c,31],[30,32]]
    a,b,c=sorted([a,b,c]);return [[a,b],[c,30],sorted([d,e]),[31,32]]

def main():
    start=time.monotonic();raw=PARENT.read_bytes();meta=json.loads(PARENT.with_suffix('.json').read_text())
    assert sha(PARENT)=='70308894ffc6f4c3b682140c7df3d17ed3035c79dc66f56dc51bd47020004e91'
    assert sha(PARENT.with_suffix('.json'))=='0f530e106a5811be95fb87df8802be78bd6a45f91c4ef548acf1d4688c00857f'
    family=json.loads((DIRECTORY/'family.json').read_text())
    assert family['program_sha256']==sha(SOURCE)
    assert family['parent_sha256']==sha(PARENT)
    assert family['parent_metadata_sha256']==sha(PARENT.with_suffix('.json'))
    assert family['four_cases_alone_claimed_complete_for_AAOA'] is False
    body=raw.split(b'\n',1)[1];tables=[meta['lefts'],meta['rights']]
    rng=random.Random(13420451);records={};witnesses=0;checks=0
    for name in ['T1','T2','T3','T4']:
        delta=[]
        for g,ports in zip(range(17,21),LAYOUTS[name]):
            for side,source in enumerate(ports):
                if source is None:delta.extend([[-tables[side][g][w]] for w in range(30,13+g)])
                else:delta.append([tables[side][g][source]])
        for g,s,h,t in ORDERS[name]:
            for a in range(30):
                for b in range(a):delta.append([-tables[s][g][a],-tables[t][h][b]])
        path=DIRECTORY/(name+'.cnf');child=json.loads(path.with_suffix('.json').read_text())
        expected=f"p cnf 11968 {114571+len(delta)}\n".encode()+body
        expected+=''.join(' '.join(map(str,c))+' 0\n' for c in delta).encode()
        assert path.read_bytes()==expected
        assert child['aaoa_added_clauses']==delta
        assert child['aaoa_ports']==LAYOUTS[name]
        assert child['aaoa_leaf_orders']==[list(x) for x in ORDERS[name]]
        assert child['aaoa_coverage_requires_AAAA_fallback'] is True
        assert child['aaoa_claimed_as_logical_consequence'] is False
        assert child['aaoa_parent_sha256']==sha(PARENT)
        assert child['aaoa_parent_metadata_sha256']==sha(PARENT.with_suffix('.json'))
        assert child['aaoa_generator_sha256']==sha(SOURCE)
        assert child['sha256']==sha(path)==family['files'][name]['cnf_sha256']
        assert sha(path.with_suffix('.json'))==family['files'][name]['metadata_sha256']
        assert child['variables']==11968 and child['clauses']==114571+len(delta)
        for key,value in meta.items():
            if key not in ['sha256','clauses']:assert child[key]==value,key
        for i in range(250):
            ports=schedule(name,[rng.randrange(30) for _ in range(5)])
            assignment={}
            for g,pair in zip(range(17,21),ports):
                for side,chosen in enumerate(pair):
                    assignment.update({v:w==chosen for w,v in enumerate(tables[side][g])})
            assert all(any(assignment[abs(v)]==(v>0) for v in c) for c in delta)
            witnesses+=1;checks+=len(delta)
        records[name]={'cnf_sha256':sha(path),'metadata_sha256':sha(path.with_suffix('.json')),
                       'clauses':child['clauses'],'added_clauses':len(delta),'exact_parent_body_preserved':True}
    result={'verdict':'PASS_FOUR_AAOA_EXACT_DELTAS_AND_PERMITTED_SYMMETRIES',
            'scope':'Use these four templates with AAAA fallback; no standalone AAOA exhaustion or implication claim',
            'parent_sha256':sha(PARENT),'parent_metadata_sha256':sha(PARENT.with_suffix('.json')),
            'source_sha256':sha(SOURCE),'family_sha256':sha(DIRECTORY/'family.json'),'cases':records,
            'canonical_selector_models':witnesses,'added_clause_checks':checks,
            'script_sha256':sha(Path(__file__)),'seconds':time.monotonic()-start}
    (OUT/'aaoa-delta-review.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
