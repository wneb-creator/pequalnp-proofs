from pathlib import Path
import hashlib
import itertools
import json
import random
import time

ROOT=Path('/tmp/oec/pequalnp-pilot-18');OUT=ROOT/'orch/S04'
FAMILY=ROOT/'orch/S01/consecutive-junk-v2'
PARENT=ROOT/'original-dag-strong/original.cnf'
SOURCE=ROOT/'orch/S01/build_consecutive_junk.py'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    start=time.monotonic();meta=json.loads(PARENT.with_suffix('.json').read_text())
    parent=PARENT.read_bytes();body=parent.split(b'\n',1)[1]
    assert sha(PARENT)=='38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08'
    family=json.loads((FAMILY/'family.json').read_text())
    assert family['program_sha256']==sha(SOURCE)
    records={};projection_checks=0
    for name in ['AAAA','AAAO']:
        ops=meta['ops'][17:];junk=meta['junk'][17:]
        delta=[[junk[1]]]+[[op if letter=='A' else -op] for op,letter in zip(ops,name)]
        left,right=meta['lefts'],meta['rights']
        for g in [18,19,20]:
            delta.append([right[g][13+g-1]])
            delta.extend([[-left[g][wire]] for wire in range(30,13+g)])
        delta.append([junk[2] if name=='AAAA' else -junk[2]])
        leaves=[left[17][:30],right[17][:30],left[18][:30],left[19][:30]]
        strict=[False,True,True]
        if name=='AAAA':leaves.append(left[20][:30]);strict=[False,False,True,True]
        for arow,brow,less in zip(leaves,leaves[1:],strict):
            block=[]
            for a,b in itertools.product(range(30),repeat=2):
                if not (a<b if less else a<=b):block.append([-arow[a],-brow[b]])
            delta+=block
            forbidden={(-a,-b) for a,b in block}
            for a,b in itertools.product(range(30),repeat=2):
                assert ((arow[a],brow[b]) not in forbidden)==(a<b if less else a<=b)
                projection_checks+=1
        assert len(delta)==(1815 if name=='AAAA' else 1380)
        path=FAMILY/(name+'-chain.cnf');m=json.loads(path.with_suffix('.json').read_text())
        expected=f"p cnf 11968 {114566+len(delta)}\n".encode()+body
        expected+=''.join(' '.join(map(str,c))+' 0\n' for c in delta).encode()
        assert path.read_bytes()==expected
        assert m['consecutive_junk_added_clauses']==delta
        assert m['sha256']==sha(path)==family['files'][name+'-chain']['cnf_sha256']
        assert sha(path.with_suffix('.json'))==family['files'][name+'-chain']['metadata_sha256']
        assert m['consecutive_junk_generator_sha256']==sha(SOURCE)
        assert m['consecutive_junk_parent_sha256']==sha(PARENT)
        assert m['consecutive_junk_parent_metadata_sha256']==sha(PARENT.with_suffix('.json'))
        assert m['consecutive_junk_claimed_as_logical_consequence'] is False
        assert m['fixed_chain'] is True and m['operation_case']==name
        for key,value in meta.items():
            if key not in ['sha256','clauses']:assert m[key]==value,key
        records[name+'-chain']={'cnf_sha256':sha(path),'metadata_sha256':sha(path.with_suffix('.json')),
                               'clauses':114566+len(delta),'added_clauses':len(delta),
                               'exact_parent_plus_independently_reconstructed_delta':True}
    # Negative functions of a minimal q-factor family: all rows except all1
    # are negative, hence each factor has its private all-other1 witness.
    # Check all permutations, both no-padding and factor-vs-P padding choices.
    controls=0;truth_rows=0;pad_controls=0
    for shape in ['AAAA','AAAO']:
        count=5 if shape=='AAAA' else 4
        for q in range(3,count+1):
            for permutation in itertools.permutations(range(q)):
                for pad_factor in range(-2,q):
                    # -2=no padding; -1=padding P in AAAO; >=0 factor padding.
                    if pad_factor==-1 and shape=='AAAA':continue
                    wires={factor:13+rank for rank,factor in enumerate(permutation)}
                    if pad_factor>=0:wires[pad_factor]=29
                    ordered=sorted(wires,key=wires.get)
                    occurrences=[ordered[0]]*(count-q)+ordered
                    indices=[wires[f] for f in occurrences]
                    if shape=='AAAA':assert indices[0]<=indices[1]<=indices[2]<indices[3]<indices[4]
                    else:assert indices[0]<=indices[1]<indices[2]<indices[3]
                    private=(1<<q)-1-(1<<ordered[-1])
                    for row in range(1<<q):
                        running=bool(row&(1<<occurrences[0]));products=[]
                        for factor in occurrences[1:]:
                            running=running and bool(row&(1<<factor));products.append(running)
                        assert products[-1]==(row==(1<<q)-1)
                        if row==private:assert all(products[:-1]) and not products[-1]
                        truth_rows+=1
                    # Fixed chain output has a reader for every preceding gate;
                    # P can be source11 (FALSE), even if old output was OR(H,H).
                    gates=[(True,indices[0],indices[1])]
                    for i in range(2,count):gates.append((True,indices[i],30+len(gates)-1))
                    if shape=='AAAO':gates.append((False,29 if pad_factor==-1 else 11,32))
                    assert len(gates)==4
                    assert all(any(30+g in (a,b) for _,a,b in gates[g+1:]) for g in range(3))
                    assert all(a<=b for _,a,b in gates)
                    controls+=1;pad_controls+=pad_factor!=-2
    result={'verdict':'PASS_CHAIN_MATHEMATICS_AND_EXACT_DELTAS',
            'scope':'AAAA-chain and AAAO-chain existence normalizations; no parent implication or UNSAT claim',
            'proof_repair':'Final AAAO OR(H,H) is converted to OR(FALSE,H), which the existing chain CNF allows',
            'weaker_encoding_note':'AAAA inequalities also permit a<b=c<d<e; this only enlarges the searched normal form',
            'source_sha256':sha(SOURCE),'family_sha256':sha(FAMILY/'family.json'),
            'parent_sha256':sha(PARENT),'parent_metadata_sha256':sha(PARENT.with_suffix('.json')),
            'cases':records,'leaf_order_projection_checks':projection_checks,
            'factor_permutation_controls':controls,'factor_or_P_padding_controls':pad_controls,
            'truth_rows_checked':truth_rows,'script_sha256':sha(Path(__file__)),'seconds':time.monotonic()-start}
    (OUT/'chain-review.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
