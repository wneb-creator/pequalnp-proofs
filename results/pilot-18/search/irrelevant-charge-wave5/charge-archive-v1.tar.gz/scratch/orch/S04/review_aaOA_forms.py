from pathlib import Path
import collections
import hashlib
import itertools
import json
import time

ROOT=Path('/tmp/oec/pequalnp-pilot-18');OUT=ROOT/'orch/S04'
FULL=(1<<32)-1
PREFIX=[sum(1<<m for m in range(32) if m&(1<<v)) for v in range(5)]+[0,FULL]
COUNTS=collections.Counter();EXAMPLES={}

def evaluate(gates):
    values=PREFIX[:]
    for op,a,b in gates:
        assert 0<=a<len(values) and 0<=b<len(values)
        values.append(values[a]&values[b] if op else values[a]|values[b])
    return values

def live(gates):
    return all(any(7+g in (a,b) for _,a,b in gates[g+1:]) for g in range(3))

def normalized_template(form,leaves):
    a,b,c,d,e=leaves
    if form=='T1':
        c,d,e=sorted([c,d,e]);leaves=[a,b,c,d,e]
        gates=[(True,c,d),(True,e,7),(False,b,8),(True,a,9)]
    elif form=='T2':
        first,second=sorted([sorted([b,c]),sorted([d,e])])
        b,c=first;d,e=second;leaves=[a,b,c,d,e]
        gates=[(True,b,c),(True,d,e),(False,7,8),(True,a,9)]
    elif form=='T3':
        a,b=sorted([a,b]);d,e=sorted([d,e]);leaves=[a,b,c,d,e]
        gates=[(True,a,b),(True,d,e),(False,c,8),(True,7,9)]
    else:
        assert form=='T4'
        a,b,c=sorted([a,b,c]);d,e=sorted([d,e]);leaves=[a,b,c,d,e]
        gates=[(True,a,b),(True,c,7),(False,d,e),(True,8,9)]
    assert all(0<=v<7 for v in leaves)
    assert all(a<=b for _,a,b in gates)
    return gates,leaves

def and_fallback(factors,f):
    unique=sorted(set(factors))
    minimal=[]
    for q in range(1,len(unique)+1):
        for chosen in itertools.combinations(unique,q):
            value=FULL
            for w in chosen:value &= PREFIX[w]
            if not value&~f:
                assert value==f
                minimal=list(chosen);break
        if minimal:break
    assert 3<=len(minimal)<=5
    leaves=[minimal[0]]*(5-len(minimal))+minimal
    a,b,c,d,e=leaves
    return [(True,a,b),(True,c,7),(True,d,8),(True,e,9)],leaves

def classify(gates,vals):
    d,j,o,last=gates;A,B=d[1:];f=vals[-1]
    r=last[1] # last's other operand is gate19 (wire9).
    assert r!=9
    chained=7 in j[1:]
    if chained:
        c=j[2] if j[1]==7 else j[1]
        # J=D is represented by D times one of D's prefix factors.
        cprefix=A if c==7 else c
    if r<7:
        assert 8 in o[1:]
        q=o[2] if o[1]==8 else o[1]
        if chained:
            if q<7:return 'T1',[r,q,A,B,cprefix],'R_prefix_chain'
            if q==7:return 'AAAA',[r,A,B],'R_prefix_absorb_D'
            assert q==8
            return 'AAAA',[r,A,B,cprefix],'R_prefix_absorb_J'
        assert q==7
        return 'T2',[r,A,B,j[1],j[2]],'R_prefix_independent'
    if r==7:
        assert 8 in o[1:]
        q=o[2] if o[1]==8 else o[1]
        if chained:
            assert q<7 and c<7
            return 'T4',[A,B,A,q,c],'R_D_chain_absorb_inner_D'
        assert q!=7
        if q==8:return 'AAAA',[A,B,j[1],j[2]],'R_D_independent_absorb_J'
        return 'T3',[A,B,q,j[1],j[2]],'R_D_independent'
    assert r==8
    if chained:
        assert o[1]<7 and o[2]<7
        return 'T4',[A,B,cprefix,o[1],o[2]],'R_J_chain'
    assert 7 in o[1:]
    q=o[2] if o[1]==7 else o[1]
    assert q!=8
    if q==7:return 'AAAA',[A,B,j[1],j[2]],'R_J_independent_absorb_D'
    return 'T3',[j[1],j[2],q,A,B],'R_J_independent_swap_pairs'

def main():
    start=time.monotonic()
    pairs=[list(itertools.combinations_with_replacement(range(k),2)) for k in [7,8,9]]
    excluded={a&b for a in PREFIX for b in PREFIX}
    for da,db in pairs[0]:
        for ja,jb in pairs[1]:
            for oa,ob in pairs[2]:
                for r in range(10):
                    gates=[(True,da,db),(True,ja,jb),(False,oa,ob),(True,r,9)]
                    COUNTS['syntactic_cases']+=1
                    if not live(gates):continue
                    vals=evaluate(gates);f=vals[-1]
                    if not vals[7]&~f or not vals[8]&~f:continue
                    if f in excluded:
                        COUNTS['excluded_prefix_pair_outputs']+=1;continue
                    form,leaves,branch=classify(gates,vals)
                    if form=='AAAA':new,leaves=and_fallback(leaves,f)
                    else:new,leaves=normalized_template(form,leaves)
                    values=evaluate(new)
                    assert values[-1]==f,(branch,gates,new)
                    assert live(new)
                    assert values[7]&~f and values[8]&~f
                    if form=='AAAA':assert values[9]&~f
                    else:assert [x[0] for x in new]==[True,True,False,True]
                    COUNTS['checked_cases']+=1
                    COUNTS['form_'+form]+=1;COUNTS['branch_'+branch]+=1
                    COUNTS['truth_rows']+=32
                    if branch not in EXAMPLES:EXAMPLES[branch]={'before':gates,'after':new,'form':form,'leaves':leaves,'truth_word':f}
    # Symbolic five-distinct-leaf minimal-term signatures distinguish the four
    # shapes; repeated terminals or constants cannot preserve five essentials.
    signatures={}
    for form in ['T1','T2','T3','T4']:
        g,_=normalized_template(form,[0,1,2,3,4]);truth=evaluate(g)[-1]
        mins=[m for m in range(32) if (truth>>m)&1 and all(not (truth>>(m&~(1<<v)))&1 for v in range(5) if m&(1<<v))]
        assert len(mins)==2
        signatures[form]={'term_sizes':sorted(m.bit_count() for m in mins),'intersection_size':(mins[0]&mins[1]).bit_count()}
    assert len({str(v) for v in signatures.values()})==4
    result={'verdict':'PASS_AAOA_FOUR_FORM_AND_AAAA_FALLBACK_MATHEMATICS',
            'scope':'Existence-preserving port classification, approved leaf symmetries, junk/liveness/output controls; no new CNF reviewed',
            'counts':dict(COUNTS),'five_leaf_signatures':signatures,'examples':EXAMPLES,
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'seconds':time.monotonic()-start}
    (OUT/'aaOA-review.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='examples'},indent=2))

if __name__=='__main__':main()
