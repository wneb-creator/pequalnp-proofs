#!/usr/bin/env python3
"""Independently review seven emitted mathematical-strengthening deltas, read-only."""
from pathlib import Path
import ast, collections, datetime, hashlib, json, time, traceback
R=Path('/tmp/oec/pequalnp-pilot-18'); W=Path('/workspace/pequalnp-proofs'); S=R/'orch/S06'; F=S/'irrelevant-charge-v1'; O=R/'orch/S08/irrelevant-charge-delta-review'
O.mkdir(exist_ok=True);(O/'snapshot').mkdir(exist_ok=True)
h=lambda b:hashlib.sha256(b).hexdigest(); bindings={};checks={};t0=time.monotonic()
def bind(p,snapshot=None):
 b=p.read_bytes();bindings[str(p)]={'bytes':len(b),'sha256':h(b)}
 if snapshot:
  q=O/'snapshot'/snapshot;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
 return b
def parse(b):
 result=[]
 for line in b.splitlines():
  nums=tuple(map(int,line.split()));assert nums and nums[-1]==0 and 0 not in nums[:-1];result.append(nums[:-1])
 return result
def cb(cs):return ''.join(' '.join(map(str,c))+' 0\n' for c in cs).encode()
try:
 prep_path=R/'orch/S08/irrelevant-charge-prep-review/review.json';prep=json.loads(bind(prep_path,'preparation-review.json'))
 assert h(prep_path.read_bytes())=='d3684badea28b22aeff35bf353a8fdf72a4400bf56e956db6dd89d121b569d14'
 source=bind(S/'add_irrelevant_input_charge.py','add_irrelevant_input_charge.py');assert h(source)=='56da4e9f313a18cabbcb582dffd999b212f8858e110c43c9f5dd7fb2c778b27d'
 driver=bind(S/'control_irrelevant_input_charge.py','control_irrelevant_input_charge.py');assert h(driver)=='811821121c3d36332a033b057e774fb3c202b17ac505527e236ce3af9cbf558f'
 math=bind(R/'orch/S01/irrelevant-input-charge.md','irrelevant-input-charge.md');assert h(math)=='951fd0d38db513a2fcfa98ddad5ef9c9dbc8c5d58acc4ba37867d0bc564af48f'
 s04=json.loads(bind(R/'orch/S04/irrelevant-input-review.json','S04-review.json'));assert s04['verdict'].startswith('PASS') and s04['reviewed_math_sha256']==h(math)
 execution=json.loads(bind(S/'irrelevant-charge-v1.execution.json','execution.json'))
 stdout=bind(S/'irrelevant-charge-v1.stdout','controls.stdout');stderr=bind(S/'irrelevant-charge-v1.stderr','controls.stderr')
 assert execution['exit_code']==0 and execution['source_sha256']==h(driver) and execution['stdout_sha256']==h(stdout) and execution['stderr_sha256']==h(stderr) and not stderr and not execution['solver_launched']
 manifest=json.loads(bind(F/'artifact-manifest.json','artifact-manifest.json')); assert manifest['source_sha256']==h(driver)
 for rel,b in manifest['files'].items():
  p=Path(rel);assert not p.is_absolute() and '..' not in p.parts
  raw=bind(F/p,'family/'+rel);assert len(raw)==b['bytes'] and h(raw)==b['sha256']
 assert set(manifest['files'])=={str(p.relative_to(F)) for p in F.rglob('*') if p.is_file()}-{'artifact-manifest.json'}
 family=json.loads((O/'snapshot/family/family.json').read_text()); controls=json.loads((O/'snapshot/family/controls.json').read_text());out=json.loads(stdout)
 assert controls['family']==family and controls['source_sha256']==h(driver) and controls['generator_source_sha256']==h(source)
 assert out['controls']==controls['controls'] and out['controls_sha256']==h((F/'controls.json').read_bytes()) and out['family_count']==7
 assert out['generator_sha256']==h(source) and controls['status']=='PASS_SCALAR_ENCODING_CONTROLS_MATH_AND_INDEPENDENT_IMPLEMENTATION_REVIEW_PENDING'
 assert len(family)==7 and {c['name'] for c in family}=={'original','AAAA-chain','AAAO-chain','T1','T2','T3','T4'}
 original=bind(R/'original-dag-strong/original.cnf');od=json.loads(bind(R/'original-dag-strong/original.json','original-parent.json'));original_body=original.split(b'\n',1)[1]
 assert h(original)=='38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08'
 # Recover every original local cover/counter clause, proving the cover auxiliaries
 # may be reselected independently of all other constraints in these exact parents.
 oldsource=bind(W/'results/pilot-18/search/search_l1342_shard17_ancestorreverse.py','pinned-counter.py')
 assert h(oldsource)=='b10d8832060d1c554fd3daa563b7159d515a3c55adc49718989eaa9bd0c2f24f'
 tree=ast.parse(oldsource);ns={};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in ['CNF','totalizer_atleast']],type_ignores=[]),'pinned-counter.py','exec'),ns)
 aux=set();expected_aux=collections.Counter();networks=[]
 for g,row in enumerate(od['partial_edge_cost_restrictions']):
  inputs=od['prefix_support_tables'][13+g]+row['residual_edge_flags']+row['vertex_cover_flags']+[-a for a in od['prefix_ancestor_flags'][g]]
  cnf=ns['CNF']();cnf.variables=row['vertex_cover_flags'][-1];root=ns['totalizer_atleast'](cnf,inputs,g+3);block=cb(cnf.clauses)
  assert original_body.count(block)==1 and root[-1]==row['overflow_flag'] and root[-2]==prep['checks']['pinned_networks'][g]['threshold_literal']
  av=set(row['vertex_cover_flags'])|set(range(row['vertex_cover_flags'][-1]+1,root[-1]+1));assert not aux&av;aux|=av
  expected_aux.update(map(tuple,cnf.clauses));expected_aux.update((-root[-1],s) for s in od['prefix_support_tables'][13+g])
  for flag,edge_mask in zip(row['residual_edge_flags'],od['rows'][:16]):
   ends=[v for v in range(11) if edge_mask>>v&1];assert len(ends)==2
   expected_aux.update([(-flag,*(row['vertex_cover_flags'][v] for v in ends))])
  networks.append({'gate':g,'bound':g+2,'input_literals':inputs,'support_literals':od['prefix_support_tables'][13+g],'root_thresholds':root,'penalty_threshold':root[-2],'old_overflow':root[-1],'reconstructed_counter_clauses':len(cnf.clauses),'counter_clause_block_sha256':h(block),'counter_first_variable':row['vertex_cover_flags'][-1]+1,'counter_last_variable':cnf.variables})
 actual_aux=collections.Counter(c for c in parse(original_body) if any(abs(l) in aux for l in c)); assert actual_aux==expected_aux
 checks['cover_auxiliary_independence']={'local_variables':len(aux),'clauses':sum(actual_aux.values()),'all_old_occurrences_local':True,'all_later_parent_clauses_avoid_these_variables':True,'consequence':'Minimum cover and exact local thresholds may be reselected for fixed circuit variables; no extension of every old auxiliary assignment claimed.'}
 # Compare against independently reviewed S04 trigger fixture as a multiset,
 # then check the 187 proper-support guards using independently recovered thresholds.
 expected_triggers=collections.Counter(map(tuple,s04['expected_trigger_clause_fixture']))
 assert len(expected_triggers)==3366 and all(n==1 for n in expected_triggers.values())
 expected_guards=[(-(11969+g),-networks[g]['penalty_threshold'],s) for g in range(17) for s in od['prefix_support_tables'][13+g]]
 assert len(expected_guards)==187
 cases=[];deltas=[]
 for case in family:
  name=case['name'];directory=O/'snapshot/family'/name;parent=Path(case['parent']);raw=bind(parent);meta_raw=bind(parent.with_suffix('.json'),'parents/'+name+'.json');meta=json.loads(meta_raw)
  assert h(raw)==case['parent_cnf_sha256'] and h(meta_raw)==case['parent_metadata_sha256']
  assert meta['variables']==11968 and meta['sha256']==h(raw) and all(meta[k] for k in ['original_DAG','productive_prefix','prefix_ancestor_cost','prefix_totalizer_reverse'])
  body=raw.split(b'\n',1)[1];assert body.startswith(original_body)
  assert not any(abs(l) in aux for c in parse(body[len(original_body):]) for l in c)
  child=(directory/'instance.cnf').read_bytes();childmeta_raw=(directory/'instance.json').read_bytes();cm=json.loads(childmeta_raw);delta=(directory/'delta.clauses').read_bytes();clauses=parse(delta)
  assert len(clauses)==3553 and collections.Counter(clauses[:3366])==expected_triggers and clauses[3366:]==expected_guards
  assert all(0<abs(l)<=11985 for c in clauses for l in c) and {abs(l) for c in clauses for l in c if abs(l)>11968}==set(range(11969,11986))
  assert child==f"p cnf 11985 {meta['clauses']+3553}\n".encode()+body+delta
  assert len(child.splitlines())-1==cm['clauses']==case['clauses']==meta['clauses']+3553 and cm['variables']==11985
  assert h(child)==case['cnf_sha256']==cm['sha256'] and h(childmeta_raw)==case['metadata_sha256'] and h(delta)==case['delta_sha256']
  assert set(cm)==set(meta)|{'irrelevant_input_charge'} and all(cm[k]==v for k,v in meta.items() if k not in ['variables','clauses','sha256'])
  desc=cm['irrelevant_input_charge'];assert desc['counters']==networks==json.loads((directory/'thresholds.json').read_text())
  assert desc['penalty_bits']==list(range(11969,11986)) and desc['added_variables']==17 and desc['added_clauses']==3553 and desc['implication_clauses']==3366 and desc['conditional_threshold_clauses']==187
  assert desc['parent_cnf_sha256']==h(raw) and desc['parent_metadata_sha256']==h(meta_raw) and desc['delta_sha256']==h(delta) and desc['generator_source_sha256']==h(source)
  assert desc['math_source_sha256']==h(math) and desc['counter_source_sha256']==h(oldsource)
  assert all(desc[k] for k in ['full_support_exempt','parent_body_byte_preserved','all_old_indices_preserved','not_an_RUP_certificate','no_original_auxiliary_model_extension_claim'])
  generated=json.loads((directory/'generation.json').read_text());assert case==dict(generated,name=name)
  assert not case['solver_launched'] and case['source_sha256']==h(source) and case['added_variables']==17 and case['added_clauses']==3553
  cases.append({'name':name,'parent_sha256':h(raw),'cnf_sha256':h(child),'metadata_sha256':h(childmeta_raw),'delta_sha256':h(delta),'variables':11985,'clauses':cm['clauses'],'old_body_byte_preserved':True});deltas.append(delta)
 assert all(d==deltas[0] for d in deltas)
 checks['actual_seven_deltas']={'cases':cases,'all_delta_bytes_identical':True,'delta_bytes':len(deltas[0]),'delta_sha256':h(deltas[0]),'trigger_clauses':3366,'proper_support_threshold_guards':187,'penalty_bits':list(range(11969,11986))}
 # Independent negative fixture: one missing/changed trigger or the old overflow
 # cannot pass this review's exact specification comparison.
 original_clauses=parse(deltas[0]); mutated=list(original_clauses); mutated[-1]=(mutated[-1][0],mutated[-1][1]-1,mutated[-1][2]);assert mutated[3366:]!=expected_guards
 assert collections.Counter(original_clauses[1:3366])!=expected_triggers
 checks['independent_negative_fixtures']=['old_overflow_in_guard_detected','missing_trigger_detected']
 checks['S06_controls_bound_to_complete_exit0_logs']=True
 checks['no_projection_overclaim']={'math_separately_reviewed':True,'scope':'Any actual normalized productive clean-prefix circuit extends using a minimum cover, exact thresholds, and p=1 only when a trigger exists. New mathematical strengthening, not a RUP claim or whole-shard exhaustion.','nonempty_residual_guard_required':False,'full_support_exempt':True,'no_Lean_or_posted_acceptance':True,'no_launch_or_resource_admission':True}
 for path,b in bindings.items():assert h(Path(path).read_bytes())==b['sha256'],f'changed during review: {path}'
 verdict='PASS_EXACT_SEVEN_IRRELEVANT_INPUT_CHARGE_DELTAS_AND_PROJECTION'
except Exception:
 verdict='FAIL';(O/'failure.txt').write_text(traceback.format_exc());raise
finally:
 result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':locals().get('verdict','FAIL'),'script_sha256':h(Path(__file__).read_bytes()),'seconds':time.monotonic()-t0,'bindings':bindings,'checks':checks,'no_solver_Lean_checker_or_git_write':True,'all_existing_inputs_unchanged':locals().get('verdict','FAIL').startswith('PASS')}
 (O/'review.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'verdict':result['verdict'],'review_sha256':h((O/'review.json').read_bytes()),'seconds':result['seconds'],'bound_files':len(bindings),'delta_sha256':checks.get('actual_seven_deltas',{}).get('delta_sha256')},indent=2))
