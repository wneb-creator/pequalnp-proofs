#include <algorithm>
#include <chrono>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
using namespace std;
struct Propagator {
 int n; vector<vector<int>> cs, occ; vector<int> val,trail; size_t head=0; long long visits=0;
 int litval(int x)const{return x>0?val[x]:-val[-x];}
 bool assign(int x){int t=litval(x);if(t)return t>0;val[abs(x)]=x>0?1:-1;trail.push_back(x);return true;}
 bool propagate(){while(head<trail.size()) {int x=trail[head++]; for(int ci:occ[n-x]) {++visits;int count=0,last=0;bool sat=false;for(int y:cs[ci]){int v=litval(y);if(v>0){sat=true;break;}if(!v){count++;last=y;}}if(sat)continue;if(!count)return false;if(count==1&&!assign(last))return false;}}return true;}
 void undo(size_t k){while(trail.size()>k){val[abs(trail.back())]=0;trail.pop_back();}head=k;}
 explicit Propagator(const string &path){ifstream in(path);string s;int expect=0;n=0;while(getline(in,s)){if(s.empty()||s[0]=='c')continue;if(s[0]=='p'){istringstream h(s);string a,b;h>>a>>b>>n>>expect;continue;}istringstream r(s);int x;vector<int> c;while(r>>x){if(!x){sort(c.begin(),c.end());c.erase(unique(c.begin(),c.end()),c.end());bool taut=false;for(int y:c)if(binary_search(c.begin(),c.end(),-y)){taut=true;break;}if(!taut)cs.push_back(c);c.clear();}else c.push_back(x);}if(!c.empty())throw runtime_error("multiline clause unsupported");}if(n<=0)throw runtime_error("header");val.resize(n+1);occ.resize(2*n+1);for(int i=0;i<(int)cs.size();i++)for(int x:cs[i]){if(abs(x)>n)throw runtime_error("literal bound");occ[n+x].push_back(i);}}
 bool root(){for(auto &c:cs){if(c.empty())return false;if(c.size()==1&&!assign(c[0]))return false;}return propagate();}
};
int main(int argc,char **argv){try{
 if(argc!=6)throw runtime_error("usage: probe CNF candidates.txt units.drat stats.tsv seconds");
 auto start=chrono::steady_clock::now();double limit=stod(argv[5]);auto elapsed=[&](){return chrono::duration<double>(chrono::steady_clock::now()-start).count();};
 Propagator p(argv[1]);ifstream cand(argv[2]);vector<int> vars;int v;while(cand>>v){if(v<1||v>p.n)throw runtime_error("candidate bound");vars.push_back(v);}
 ofstream proof(argv[3]),stats(argv[4]);stats<<"round\tvariable\tpositive_implied\tnegative_implied\troot_size\n";
 if(!p.root()){proof<<"0\n";cout<<"ROOT_UNSAT\n";return 20;}
 size_t initial=p.trail.size();int learned=0,round=0;bool changed=true;
 while(changed&&elapsed()<limit){changed=false;round++;for(int x:vars){if(elapsed()>limit)break;if(p.val[x])continue;int counts[2]={0,0};for(int sign=0;sign<2;sign++){int l=sign?-x:x;size_t root=p.trail.size();bool ok=p.assign(l)&&p.propagate();counts[sign]=ok?(int)(p.trail.size()-root):-1;p.undo(root);if(!ok){proof<<-l<<" 0\n";proof.flush();learned++;changed=true;if(!p.assign(-l)||!p.propagate()){proof<<"0\n";cout<<"DERIVED_UNSAT\n";return 20;}break;}}stats<<round<<'\t'<<x<<'\t'<<counts[0]<<'\t'<<counts[1]<<'\t'<<p.trail.size()<<'\n';}}
 cout<<"{\"initial_root_units\":"<<initial<<",\"final_root_units\":"<<p.trail.size()<<",\"learned_units\":"<<learned<<",\"rounds\":"<<round<<",\"fixed_point\":"<<(changed?"false":"true")<<",\"clause_visits\":"<<p.visits<<",\"seconds\":"<<elapsed()<<"}\n";
 return 0;
 }catch(const exception&e){cerr<<e.what()<<'\n';return 1;}}
