"""Two exact Shannon cubes with checked conditional unit consequences; no solver."""
import hashlib,json,subprocess,time
from pathlib import Path
R=Path('/tmp/oec/pequalnp-pilot-18');O=R/'orch/S06';D=O/'AAAO-chain-split';D.mkdir(exist_ok=False)
P=R/'orch/S01/consecutive-junk-v2/AAAO-chain.cnf';raw=P.read_bytes();h,body=raw.split(b'\n',1);n,c=map(int,h.split()[2:]);m=json.loads(P.with_suffix('.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(P)=='a8e94b6cfeaafb8b6c4e01d33e6f552a984e395d224dc3d6281d99cc49850753'
proof=(O/'AAAO-chain-probe/combined.drat').read_bytes();selector=m['lefts'][20][29];assert selector==3644
cases=[]
for label,lit in [('P-last-prefix',selector),('P-not-last-prefix',-selector)]:
 cnf=D/(label+'.cnf');local=D/(label+'.drat');cnf.write_bytes(f'p cnf {n} {c+len(proof.splitlines())+1}\n'.encode()+body+proof+f'{lit} 0\n'.encode())
 start=time.monotonic()
 with (D/(label+'.stdout')).open('w') as out,(D/(label+'.stderr')).open('w') as err:
  p=subprocess.run([str(O/'probe'),str(cnf),str(O/'all-vars.txt'),str(local),str(D/(label+'.tsv')),'5'],stdout=out,stderr=err,timeout=10)
 assert p.returncode in [0,20]
 lines=local.read_text().splitlines();proof+=''.join(f'{-lit} '+line+'\n' for line in lines).encode()
 cases.append({'label':label,'cube':[lit],'local_cnf_sha256':sha(cnf),'local_proof_sha256':sha(local),'probe_exit':p.returncode,'new_conditional_clauses':len(lines),'stdout':(D/(label+'.stdout')).read_text(),'elapsed_seconds':time.monotonic()-start})
(D/'combined.drat').write_bytes(proof);checker=R/'solver/dsr-trim/bin/dsr-trim'
assert sha(checker)=='e6894b5b74ac2c09b494344f397ec5111547aaa782cdb399f1a8b6835ecef84b'
with (D/'checker.stdout').open('w') as out,(D/'checker.stderr').open('w') as err:
 p=subprocess.run([str(checker),'--forward','--rup-only',str(P),str(D/'combined.drat')],stdout=out,stderr=err,timeout=10)
assert p.returncode==0 and 's VALID\n' in (D/'checker.stdout').read_text()
aug=D/'augmented.cnf';aug.write_bytes(f'p cnf {n} {c+len(proof.splitlines())}\n'.encode()+body+proof)
meta=dict(m,clauses=c+len(proof.splitlines()),sha256=sha(aug),s06_chain_parent_sha256=sha(P),s06_rup_proof_sha256=sha(D/'combined.drat'));aug.with_suffix('.json').write_text(json.dumps(meta,indent=2)+'\n')
for case in cases:
 name=case['label'];cnf=D/(name+'-final.cnf');lit=case['cube'][0];cnf.write_bytes(f'p cnf {n} {meta["clauses"]+1}\n'.encode()+body+proof+f'{lit} 0\n'.encode());cm=dict(meta,clauses=meta['clauses']+1,sha256=sha(cnf),s06_cube=[lit]);cnf.with_suffix('.json').write_text(json.dumps(cm,indent=2)+'\n');case.update(final_cnf_sha256=sha(cnf),final_metadata_sha256=sha(cnf.with_suffix('.json')))
report={'parent_sha256':sha(P),'split_variable':selector,'split_meaning':'final OR prefix operand P is wire29, the last clean-prefix gate output','complete_disjoint_partition':'literal3644 true/false (Shannon partition)','cases':cases,'proof_sha256':sha(D/'combined.drat'),'added_clauses':len(proof.splitlines()),'augmented_cnf_sha256':sha(aug),'checker_exit':p.returncode,'checker_stdout_sha256':sha(D/'checker.stdout'),'checker_stderr_sha256':sha(D/'checker.stderr'),'scope':'Only reviewed AAAO-chain parent; no production solver launch or UNSAT claim.'}
(D/'manifest.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
