#!/usr/bin/env python3
"""Bounded scalar probing of reviewed AAAO-chain; starts no CDCL/Lean worker."""
import hashlib,json,subprocess,time
from pathlib import Path
R=Path('/tmp/oec/pequalnp-pilot-18');O=R/'orch/S06';D=O/'AAAO-chain-probe';P=R/'orch/S01/consecutive-junk-v2/AAAO-chain.cnf'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(R/'orch/S04/chain-review.json')=='299f6bdc23ac20e8f9b54cae7eb3a787c1aacf951ab08b8314be212c67f1472d'
assert sha(P)=='a8e94b6cfeaafb8b6c4e01d33e6f552a984e395d224dc3d6281d99cc49850753'
assert sha(P.with_suffix('.json'))=='88b777c3060b404d4be4d8dffd2f7ddda979be7bc0e29966eb858195cebcdfd1'
assert sha(O/'probe.cpp')=='2deef9ec207f5225f4d31c25351998733f3b39e533d2234d02c99b0cf11a09a6'
assert sha(O/'suffix-fanin/lifted-all.drat')=='f319ae4b04ce7c6910389dc7f60ed61c353417192c47a44def9b35cc784683c8'
checker=R/'solver/dsr-trim/bin/dsr-trim';assert sha(checker)=='e6894b5b74ac2c09b494344f397ec5111547aaa782cdb399f1a8b6835ecef84b'
D.mkdir(exist_ok=False);raw=P.read_bytes();h,body=raw.split(b'\n',1);n,c=map(int,h.split()[2:]);meta=json.loads(P.with_suffix('.json').read_text());base=(O/'suffix-fanin/lifted-all.drat').read_bytes()
cnf=D/'seeded.cnf';cnf.write_bytes(f'p cnf {n} {c+len(base.splitlines())}\n'.encode()+body+base)
cmd=[str(O/'probe'),str(cnf),str(O/'all-vars.txt'),str(D/'new-units.drat'),str(D/'statistics.tsv'),'5']
start=time.monotonic()
with (D/'probe.stdout').open('w') as out,(D/'probe.stderr').open('w') as err:
 p=subprocess.run(cmd,stdout=out,stderr=err,timeout=10)
assert p.returncode in [0,20];proof=base+(D/'new-units.drat').read_bytes();(D/'combined.drat').write_bytes(proof)
with (D/'checker.stdout').open('w') as out,(D/'checker.stderr').open('w') as err:
 check=subprocess.run([str(checker),'--forward','--rup-only',str(P),str(D/'combined.drat')],stdout=out,stderr=err,timeout=10)
verdict=[s for s in (D/'checker.stdout').read_text().splitlines() if s.startswith('s ')]
assert check.returncode==0 and verdict==(['s VERIFIED UNSAT'] if p.returncode==20 else ['s VALID'])
aug=D/'augmented.cnf';aug.write_bytes(f'p cnf {n} {c+len(proof.splitlines())}\n'.encode()+body+proof)
meta.update(sha256=sha(aug),clauses=c+len(proof.splitlines()),s06_chain_parent_sha256=sha(P),s06_rup_proof_sha256=sha(D/'combined.drat'),s06_normalization_review_sha256=sha(R/'orch/S04/chain-review.json'))
aug.with_suffix('.json').write_text(json.dumps(meta,indent=2)+'\n')
report={'parent_sha256':sha(P),'parent_metadata_sha256':sha(P.with_suffix('.json')),'normalization_review_sha256':sha(R/'orch/S04/chain-review.json'),'probe_command':cmd,'probe_exit':p.returncode,'probe_stdout':(D/'probe.stdout').read_text(),'new_unit_clauses':len((D/'new-units.drat').read_text().splitlines()),'proof_clauses':len(proof.splitlines()),'proof_sha256':sha(D/'combined.drat'),'augmented_cnf_sha256':sha(aug),'checker_exit':check.returncode,'checker_verdicts':verdict,'checker_stdout_sha256':sha(D/'checker.stdout'),'checker_stderr_sha256':sha(D/'checker.stderr'),'elapsed_seconds':time.monotonic()-start,'scope':'Checked RUP consequences of exact reviewed AAAO-chain parent; no implication from unchanged original normalization is asserted.'}
(D/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
