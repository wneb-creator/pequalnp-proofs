#!/usr/bin/env python3
"""Bounded unit-only refutations of P equal to a product leaf; no CDCL solver."""
import hashlib,json,subprocess,time
from pathlib import Path
R=Path('/tmp/oec/pequalnp-pilot-18');O=R/'orch/S06';D=O/'AAAO-chain-absorption-family';D.mkdir(exist_ok=False)
P=R/'orch/S01/consecutive-junk-v2/AAAO-chain.cnf';raw=P.read_bytes();h,body=raw.split(b'\n',1);n,c=map(int,h.split()[2:]);m=json.loads(P.with_suffix('.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P)=='a8e94b6cfeaafb8b6c4e01d33e6f552a984e395d224dc3d6281d99cc49850753'
assert sha(O/'AAAO-chain-split/combined.drat')=='589778cceecd469b3e9de4996869dbfd8d1a9c0e02b3fee952ce7b93864e7a38'
assert sha(O/'probe.cpp')=='2deef9ec207f5225f4d31c25351998733f3b39e533d2234d02c99b0cf11a09a6'
proof=(O/'AAAO-chain-split/combined.drat').read_bytes();cases=[];start=time.monotonic();budget=15
ports=[('d',m['lefts'][19]),('c',m['lefts'][18]),('b',m['rights'][17]),('a',m['lefts'][17])]
for wire in range(29,12,-1):
 for label,port in ports:
  if time.monotonic()-start>=budget:break
  cube=[m['lefts'][20][wire],port[wire]];stem=f'wire-{wire:02d}-{label}';cnf=D/(stem+'.cnf');local=D/(stem+'.drat')
  cnf.write_bytes(f'p cnf {n} {c+len(proof.splitlines())+2}\n'.encode()+body+proof+''.join(f'{x} 0\n' for x in cube).encode())
  with (D/(stem+'.stdout')).open('w') as out,(D/(stem+'.stderr')).open('w') as err:
   p=subprocess.run([str(O/'probe'),str(cnf),str(O/'all-vars.txt'),str(local),str(D/(stem+'.tsv')),'1'],stdout=out,stderr=err,timeout=5)
  assert p.returncode in [0,20]
  lines=local.read_text().splitlines();proof+=''.join(' '.join(str(-x) for x in cube)+' '+line+'\n' for line in lines).encode()
  cases.append({'wire':wire,'leaf':label,'cube':cube,'probe_exit':p.returncode,'new_lifted_clauses':len(lines),'local_cnf_sha256':sha(cnf),'local_proof_sha256':sha(local),'stdout':(D/(stem+'.stdout')).read_text()})
 if time.monotonic()-start>=budget:break
# Last prefix wire must occur in final OR operand P or final product factor d.
proof+=b'3644 3371 0\n';(D/'combined.drat').write_bytes(proof)
checker=R/'solver/dsr-trim/bin/dsr-trim';assert sha(checker)=='e6894b5b74ac2c09b494344f397ec5111547aaa782cdb399f1a8b6835ecef84b'
with (D/'checker.stdout').open('w') as out,(D/'checker.stderr').open('w') as err:
 p=subprocess.run([str(checker),'--forward','--rup-only',str(P),str(D/'combined.drat')],stdout=out,stderr=err,timeout=10)
assert p.returncode==0 and 's VALID\n' in (D/'checker.stdout').read_text()
aug=D/'augmented.cnf';aug.write_bytes(f'p cnf {n} {c+len(proof.splitlines())}\n'.encode()+body+proof)
meta=dict(m,clauses=c+len(proof.splitlines()),sha256=sha(aug),s06_chain_parent_sha256=sha(P),s06_rup_proof_sha256=sha(D/'combined.drat'));aug.with_suffix('.json').write_text(json.dumps(meta,indent=2)+'\n')
part=[]
for name,cube in [('last-prefix-is-P',[3644,-3371]),('last-prefix-is-d',[-3644,3371])]:
 cnf=D/(name+'.cnf');cnf.write_bytes(f'p cnf {n} {meta["clauses"]+2}\n'.encode()+body+proof+''.join(f'{x} 0\n' for x in cube).encode());cm=dict(meta,sha256=sha(cnf),clauses=meta['clauses']+2,s06_cube=cube);cnf.with_suffix('.json').write_text(json.dumps(cm,indent=2)+'\n');part.append({'name':name,'cube':cube,'cnf_sha256':sha(cnf),'metadata_sha256':sha(cnf.with_suffix('.json'))})
# Both excluded truth assignments have direct replayable proofs on parent+cube.
emptyproof=D/'excluded-pairs.drat';emptyproof.write_bytes(proof+b'0\n');excluded=[]
for name,cube in [('both-last',[3644,3371]),('neither-last',[-3644,-3371])]:
 cnf=D/(name+'.cnf');cnf.write_bytes(f'p cnf {n} {c+2}\n'.encode()+body+''.join(f'{x} 0\n' for x in cube).encode())
 with (D/(name+'-check.stdout')).open('w') as out,(D/(name+'-check.stderr')).open('w') as err:
  q=subprocess.run([str(checker),'--forward','--rup-only',str(cnf),str(emptyproof)],stdout=out,stderr=err,timeout=10)
 assert q.returncode==0 and 's VERIFIED UNSAT\n' in (D/(name+'-check.stdout')).read_text();excluded.append({'name':name,'cube':cube,'cnf_sha256':sha(cnf),'checker_exit':q.returncode,'stdout_sha256':sha(D/(name+'-check.stdout')),'stderr_sha256':sha(D/(name+'-check.stderr'))})
report={'parent_sha256':sha(P),'elapsed_seconds':time.monotonic()-start,'probe_budget_seconds':budget,'cases_attempted':len(cases),'cases_refuted':sum(x['probe_exit']==20 for x in cases),'cases':cases,'proof_sha256':sha(D/'combined.drat'),'proof_clauses':len(proof.splitlines()),'augmented_cnf_sha256':sha(aug),'checker_exit':p.returncode,'checker_stdout_sha256':sha(D/'checker.stdout'),'checker_stderr_sha256':sha(D/'checker.stderr'),'partition':part,'excluded_boolean_assignments':excluded,'exclusion_proof_sha256':sha(emptyproof),'scope':'All additions replay-checked on exact AAAO-chain parent. P equals no product leaf if all68 cases refuted. Two-case XOR partition is exact; no production search launched.'}
(D/'manifest.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='cases'},indent=2))
