#!/usr/bin/env python3
from pathlib import Path
import collections, datetime, hashlib, json, time, traceback
R=Path('/tmp/oec/pequalnp-pilot-18');S=R/'orch/S06';O=R/'orch/S08/irrelevant-charge-final-review-v2';O.mkdir(exist_ok=True);(O/'snapshot').mkdir(exist_ok=True)
h=lambda b:hashlib.sha256(b).hexdigest();bindings={};checks={};t0=time.monotonic()
def bind(p,snapshot=None):
 b=p.read_bytes();bindings[str(p)]={'bytes':len(b),'sha256':h(b)}
 if snapshot:
  q=O/'snapshot'/snapshot;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
 return b
def parse(b):
 cs=[]
 for line in b.splitlines():
  c=tuple(map(int,line.split()));assert c and c[-1]==0 and 0 not in c[:-1];cs.append(c[:-1])
 return cs
try:
 seven_path=R/'orch/S08/irrelevant-charge-delta-review/review.json';seven=json.loads(bind(seven_path,'seven-delta-review.json'))
 assert h(seven_path.read_bytes())=='c6772e779bb864ecebd934545bfd8677560e71557428b26bf7dc21aed6cb71a7' and seven['verdict']=='PASS_EXACT_SEVEN_IRRELEVANT_INPUT_CHARGE_DELTAS_AND_PROJECTION'
 for path,pin in seven['bindings'].items():assert h(bind(Path(path)))==pin['sha256']
 handoff=json.loads(bind(S/'irrelevant-charge-handoff.json','handoff.json'));assert h((S/'irrelevant-charge-handoff.json').read_bytes())=='9b9adf9f84a8e1321f55d936b5c9d091ee80edf0347750d0aefda7020b9084f2'
 assert handoff['generator_source_sha256']=='56da4e9f313a18cabbcb582dffd999b212f8858e110c43c9f5dd7fb2c778b27d' and len(handoff['files'])==71
 for rel,pin in handoff['files'].items():
  p=Path(rel);assert not p.is_absolute() and '..' not in p.parts
  b=bind(S/p,'S06/'+rel);assert len(b)==pin['bytes'] and h(b)==pin['sha256']
 for evidence in handoff['evidence']:
  source=bind(Path(evidence['source_path']));snapshot=bind(Path(evidence['snapshot_path']));assert source==snapshot and len(source)==evidence['bytes'] and h(source)==evidence['sha256']
 family=handoff['family'];oldfamily=json.loads((S/'irrelevant-charge-v1/family.json').read_text());addedrecord=json.loads((S/'irrelevant-charge-AAAO-v1/family.json').read_text());addedfamily=addedrecord['family']
 assert family==oldfamily+addedfamily and len(family)==10 and len(addedfamily)==3
 assert {c['name'] for c in addedfamily}=={'AAAO-RUP','AAAO-P-RUP','AAAO-d-RUP'}
 mf=json.loads((S/'irrelevant-charge-AAAO-v1/artifact-manifest.json').read_text())
 assert set(mf['files'])=={str(p.relative_to(S/'irrelevant-charge-AAAO-v1')) for p in (S/'irrelevant-charge-AAAO-v1').rglob('*') if p.is_file()}-{'artifact-manifest.json'}
 for rel,pin in mf['files'].items():assert pin==handoff['files']['irrelevant-charge-AAAO-v1/'+rel]
 base=R/'orch/S08/aaao-chain-review-v2';prev=json.loads(bind(base/'review.json','earlier-RUP-review.json'))
 assert h((base/'review.json').read_bytes())=='5ce1515a74ede401f5324f2940a08e4276e069887f960a080f14c038891cbe97'
 replay=prev['replays'][0];assert replay['label']=='final-rup' and replay['exit_code']==0 and replay['verdicts']==['s VALID'] and '--rup-only' in replay['command']
 proof=bind(base/'final.drat','earlier-final.drat');assert h(proof)==prev['proof_sha256']==replay['proof_sha256']=='8e937b00f88bc1b24b1dec5586c774af36215fc8f2ddbb7397bcdba55a3dcdc8'
 for suf in ['stdout','stderr']:
  b=bind(base/('final-rup.'+suf),'earlier-final-rup.'+suf);assert h(b)==replay[suf+'_sha256']
 assert len(parse(proof))==3895 and max(abs(l) for c in parse(proof) for l in c)<=11968
 chain=bind(R/'orch/S01/consecutive-junk-v2/AAAO-chain.cnf');assert h(chain)==prev['parent_sha256'];chainbody=chain.split(b'\n',1)[1]
 originalmeta=json.loads((R/'original-dag-strong/original.json').read_text());aux=set()
 for row in originalmeta['partial_edge_cost_restrictions']:aux.update(range(row['vertex_cover_flags'][0],row['overflow_flag']+1))
 aux_rup=sum(any(abs(l) in aux for l in c) for c in parse(proof));assert aux_rup==246
 delta=(S/'irrelevant-charge-v1/original/delta.clauses').read_bytes();thresholds=json.loads((S/'irrelevant-charge-v1/original/thresholds.json').read_text());assert h(delta)==handoff['delta_sha256']==seven['checks']['actual_seven_deltas']['delta_sha256']
 expected_parents={'AAAO-RUP':prev['augmented_cnf_sha256'],'AAAO-P-RUP':prev['partition'][0]['cnf_sha256'],'AAAO-d-RUP':prev['partition'][1]['cnf_sha256']}
 cubes={'AAAO-RUP':[],'AAAO-P-RUP':prev['partition'][0]['cube'],'AAAO-d-RUP':prev['partition'][1]['cube']}
 cases=[]
 for case in addedfamily:
  name=case['name'];D=S/'irrelevant-charge-AAAO-v1'/name;parent=Path(case['parent']);raw=bind(parent);mr=bind(parent.with_suffix('.json'),'parents/'+name+'.json');meta=json.loads(mr)
  assert h(raw)==case['parent_cnf_sha256']==expected_parents[name] and h(mr)==case['parent_metadata_sha256'] and meta['sha256']==h(raw)
  units=''.join(f'{lit} 0\n' for lit in cubes[name]).encode();body=raw.split(b'\n',1)[1];assert body==chainbody+proof+units
  child=(D/'instance.cnf').read_bytes();cmraw=(D/'instance.json').read_bytes();cm=json.loads(cmraw)
  assert child==f"p cnf 11985 {meta['clauses']+3553}\n".encode()+body+delta and (D/'delta.clauses').read_bytes()==delta
  assert h(child)==case['cnf_sha256']==cm['sha256'] and h(cmraw)==case['metadata_sha256']
  assert cm['variables']==case['variables']==11985 and cm['clauses']==case['clauses']==meta['clauses']+3553==len(child.splitlines())-1
  assert set(cm)==set(meta)|{'irrelevant_input_charge'} and all(cm[k]==v for k,v in meta.items() if k not in ['variables','clauses','sha256'])
  desc=cm['irrelevant_input_charge'];reference=json.loads((S/'irrelevant-charge-v1/AAAO-chain/instance.json').read_text())['irrelevant_input_charge']
  assert set(desc)==set(reference) and all(desc[k]==v for k,v in reference.items() if k not in ['parent_cnf_sha256','parent_metadata_sha256'])
  assert desc['parent_cnf_sha256']==h(raw) and desc['parent_metadata_sha256']==h(mr) and json.loads((D/'thresholds.json').read_text())==thresholds
  assert case==dict(json.loads((D/'generation.json').read_text()),name=name) and not case['solver_launched']
  cases.append({'name':name,'parent_sha256':h(raw),'cnf_sha256':h(child),'metadata_sha256':h(cmraw),'clauses':cm['clauses'],'cube':cubes[name],'old_body_byte_preserved':True})
 checks['ten_actual_deltas']={'first_seven_review_sha256':h(seven_path.read_bytes()),'seven_review_input_bindings_reconfirmed':True,'new_cases':cases,'count':10,'common_delta_sha256':h(delta),'common_delta_bytes':len(delta),'added_variables':17,'added_clauses':3553,'trigger_clauses':3366,'full_support_guard_clauses':187,'all_old_clause_bytes_and_indices_preserved':True}
 checks['RUP_compatibility']={'prior_review_sha256':h((base/'review.json').read_bytes()),'prior_proof_sha256':h(proof),'rup_clauses':3895,'rup_clauses_mentioning_cover_or_counter_auxiliaries':aux_rup,'argument':'All 3895 old additions were already checked with --rup-only, hence are logical consequences of the normalized parent. Reselecting minimum covers/exact counters preserves the old parent and therefore these RUP clauses. The new charge is a separate mathematical restriction; it is not claimed RUP-entailed. Existing RUP remains valid after strengthening, with original variables unchanged.','new_replay':False,'partition':'Identical P/d structural cubes remain disjoint and covering after intersecting with the common charge constraint; neither case refuted.'}
 checks['review_harness_correction']={'prior_attempt':'irrelevant-charge-final-review','cause':'Reviewer assumed additional family JSON was a list; actual documented envelope uses family key. No producer artifact defect or mutation.'}
 checks['handoff']={'sha256':h((S/'irrelevant-charge-handoff.json').read_bytes()),'files':71,'all_hashes_and_evidence_copies_match':True,'source_sha256':handoff['generator_source_sha256'],'math_review_sha256':handoff['math_review_sha256'],'historical_pending_metadata_preserved':True,'scope':'Encoding soundness and exact deltas only. No solver/Lean/whole-shard exhaustion/production launch or resource-admission claim. Additional-three preparation elapsed time is producer-reported; exact output bytes were independently verified.'}
 for path,pin in bindings.items():assert h(Path(path).read_bytes())==pin['sha256'],f'changed during review: {path}'
 verdict='PASS_FINAL_TEN_IRRELEVANT_INPUT_CHARGE_DELTAS_AND_RUP_COMPATIBILITY'
except Exception:
 verdict='FAIL';(O/'failure.txt').write_text(traceback.format_exc());raise
finally:
 report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':locals().get('verdict','FAIL'),'script_sha256':h(Path(__file__).read_bytes()),'seconds':time.monotonic()-t0,'bindings':bindings,'checks':checks,'no_solver_Lean_checker_gitwrite':True,'active_CNF_mutations':False}
 (O/'review.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'verdict':report['verdict'],'review_sha256':h((O/'review.json').read_bytes()),'seconds':report['seconds'],'bound_files':len(bindings)},indent=2))
