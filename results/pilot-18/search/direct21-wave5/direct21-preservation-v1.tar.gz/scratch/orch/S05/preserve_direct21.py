"""Preserve reviewed package without ELF binaries; keep exact binary pins/rebuild recipe."""
from pathlib import Path
import hashlib,json,tarfile,io,gzip,datetime
ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S05'
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    handoff=HERE/'direct21-engine-handoff.json';d=json.loads(handoff.read_text())
    out=HERE/'direct21-preservation-v1';out.mkdir(exist_ok=False)
    payload={};omitted=[]
    for row in d['artifacts']:
        p=Path(row['path']);b=p.read_bytes();assert sha(b)==row['sha256'] and len(b)==row['bytes']
        if b.startswith(b'\x7fELF'):
            omitted.append(dict(row,reason='compiled binary excluded; exact hash retained'));continue
        b.decode('utf-8');name='scratch/'+str(p.relative_to(ROOT));assert name not in payload;payload[name]=b
    extras=[handoff,Path(__file__),HERE/'prepare_direct21_engine.py',HERE/'test_direct21_controls.py']
    review=ROOT/'orch/S08/direct21-engine-review/review.json'
    assert sha(review.read_bytes())=='925c50536a390fe063fccc4d59f08d1f6db6e7a2026ff0efe7d648060bc88719'
    extras.append(review)
    for p in extras:
        name='scratch/'+str(p.relative_to(ROOT));payload[name]=p.read_bytes()
    readme='''# Direct21 restart engine preservation

This is a research/candidate package, not a 21-gate witness or a proof.
The reviewed engine accepts explicitly tagged inexact 21-slot restart seeds.
Main owns production launches; unchanged wrapper and independent raw validation remain mandatory.
All original package files are byte preserved except ELF binaries, intentionally excluded.
Omitted binary sizes and SHA256 hashes are in manifest.json. Original handoff paths
are historical; archive members map them under scratch/ relative to the original root.

Rebuild the new binary from circuit_anneal_direct21.cpp using the command in
direct21-v1/build-result.json: g++ -std=c++17 -O3 -Wall -Wextra -Wpedantic SOURCE -o OUTPUT.
Compiler version, successful build stdout/stderr, source hash and observed binary
hash are preserved. Rebuilding on another compiler/environment may change binary bytes.
Parent circuit_anneal.cpp and derivation prepare_direct21_engine.py are included.
Finite controls and all full logs are preserved; test_direct21_controls.py records
the expected original scratch layout and pinned dependencies. No search is run by
this archive creator. Main/S08 reviewed exact original engine/pack independently.
'''
    payload['README.md']=readme.encode()
    manifest=dict(status='PRESERVATION_ONLY_NO_PRODUCTION',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),original_handoff_sha256=sha(handoff.read_bytes()),review_sha256=sha(review.read_bytes()),omitted_binaries=omitted,files=[dict(member=n,sha256=sha(b),bytes=len(b)) for n,b in sorted(payload.items())])
    mb=(json.dumps(manifest,indent=2)+'\n').encode();payload['manifest.json']=mb
    archive=HERE/'direct21-preservation-v1.tar.gz'
    with archive.open('xb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
        for n,b in sorted(payload.items()):
            info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(b))
    with tarfile.open(archive,'r:gz') as tar:
        assert {m.name for m in tar.getmembers()}==set(payload)
        for m in tar.getmembers():assert m.isfile() and tar.extractfile(m).read()==payload[m.name]
    (out/'manifest.json').write_bytes(mb)
    delivery=dict(archive=str(archive),archive_sha256=sha(archive.read_bytes()),archive_bytes=archive.stat().st_size,members=len(payload),omitted_binary_count=len(omitted),manifest_sha256=sha(mb),all_members_regular=True,roundtrip_hashes_pass=True)
    (HERE/'direct21-preservation-handoff.json').write_text(json.dumps(delivery,indent=2)+'\n')
    print(json.dumps(delivery,indent=2))
if __name__=='__main__':main()
