#!/usr/bin/python3
import json,sys
from pathlib import Path
args=sys.argv[1:];output=Path(args[args.index('--output')+1])
data=json.loads(Path('/tmp/oec/pequalnp-pilot-18/orch/S05/direct21-v1/seed-0.json').read_text())
data['status']='CANDIDATE_NEEDS_INDEPENDENT_VALIDATION'
output.write_text(json.dumps(data)+'\n')
raise SystemExit(10)
