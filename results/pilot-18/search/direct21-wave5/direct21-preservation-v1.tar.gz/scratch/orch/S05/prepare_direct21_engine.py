"""Derive a separate direct21 engine and pack; never run production search."""
from pathlib import Path
import hashlib
import json
import difflib

ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S05'
OLD=ROOT/'lean-setup/stochastic/circuit_anneal.cpp'
PIN='a82e670373e5f0048df004efbcb0f417949ce0255545c0767b647cb7207068b3'
SOURCE=HERE/'dirty22-positive-shapes/d16-right-absorbed18.json'
SPIN='f54738c35881deea8ba24b6f15cc533042e7db6342e6c31e481528868bc0b8cd'

ADDITION=r'''
// Direct21 packs contain inexact search seeds, never accepted witnesses.
bool is_direct21_pack(const std::string& path) {
 std::ifstream f(path);std::string magic;
 if(!(f>>magic))throw std::runtime_error("Unreadable seed pack");
 return magic=="COVER_ANNEAL_DIRECT21";
}
std::vector<Circuit> load_direct21(const std::string& path) {
 std::ifstream f(path);std::string magic;int version=0,count=0;
 if(!(f>>magic>>version>>count) || magic!="COVER_ANNEAL_DIRECT21" || version!=1 || count<1 || count>10000)
  throw std::runtime_error("Invalid direct21 pack header");
 std::vector<Circuit> all(count);
 for(auto& c:all) {
  int gates=0,want_fn=0,want_fp=0;uint64_t want_truth=0;
  if(!(f>>gates>>c.output>>want_fn>>want_fp>>want_truth) || gates!=GATES ||
      c.output<0 || c.output>=OFFSET+GATES || want_fn<0 || want_fn>2048 || want_fp<0 || want_fp>2048)
   throw std::runtime_error("Invalid direct21 seed header");
  for(int g=0;g<GATES;++g) {
   auto& t=c.gates[g];
   if(!(f>>t.op>>t.a>>t.b) || t.op<0 || t.op>1 || t.a<0 || t.a>t.b || t.b>=OFFSET+g)
    throw std::runtime_error("Invalid canonical direct21 gate");
  }
  int fn=0,fp=0;uint64_t truth=14695981039346656037ULL;
  for(int x=0;x<(1<<N);++x) {
   bool value=scalar(c.gates.data(),GATES,c.output,x),wanted=target(x);
   fn+=wanted&&!value;fp+=!wanted&&value;
   truth=(truth^uint64_t(value))*1099511628211ULL;
  }
  if(fn!=want_fn || fp!=want_fp || truth!=want_truth)
   throw std::runtime_error("Direct21 full truth-table metadata mismatch");
 }
 std::string extra;if(f>>extra)throw std::runtime_error("Trailing direct21 content");
 return all;
}
bool same_circuit(const Circuit& a,const Circuit& b) {
 if(a.output!=b.output)return false;
 for(int g=0;g<GATES;++g)
  if(a.gates[g].op!=b.gates[g].op || a.gates[g].a!=b.gates[g].a || a.gates[g].b!=b.gates[g].b)return false;
 return true;
}
void check_direct21_scalar_vector(const Circuit& c,const Engine& engine) {
 uint64_t bits=0;auto rows=boundary_rows();
 for(int x=0;x<(1<<N);++x) {
  bool value=scalar(c.gates.data(),GATES,c.output,x);
  for(size_t i=0;i<rows.size();++i)if(rows[i]==x && value)bits|=uint64_t(1)<<i;
 }
 if(bits!=engine.vector_eval(c.gates.data(),GATES,c.output))
  throw std::runtime_error("Direct21 scalar/vector mismatch");
 for(int g=0;g<GATES;++g)if(c.gates[g].a>c.gates[g].b)
  throw std::runtime_error("Direct21 noncanonical mutation");
}
'''

SELFTEST=r'''
 if(selftest && direct21) {
  uint64_t mutations=0,starts=0;
  for(const auto& c:direct_seeds) {
   check_direct21_scalar_vector(c,engine);
   for(int k=0;k<128;++k) {
    auto next=engine.mutate(c);check_direct21_scalar_vector(next,engine);++mutations;
   }
  }
  for(size_t i=0;i<direct_seeds.size()*32;++i) {
   Circuit c=fresh();
   if(std::none_of(direct_seeds.begin(),direct_seeds.end(),[&](const Circuit& seed){return same_circuit(c,seed);}))
    throw std::runtime_error("Direct21 restart changed or deleted a gate");
   check_direct21_scalar_vector(c,engine);++starts;
  }
  std::ofstream f(output);
  if(!f)throw std::runtime_error("Cannot write direct21 self-test result");
  f<<"{\"status\":\"SELF_TEST_DIRECT21_PASS\",\"seeds\":"<<direct_seeds.size()
   <<",\"full_truth_inputs\":2048,\"direct_start_controls\":"<<starts
   <<",\"mutation_controls\":"<<mutations<<"}\n";
  if(!f)throw std::runtime_error("Direct21 self-test result write failed");
  std::cout<<"SELF_TEST_DIRECT21_PASS seeds="<<direct_seeds.size()<<" starts="<<starts<<" mutations="<<mutations<<"\n";
  return 0;
 }
'''

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def evaluate(data,m):
    vals=[bool(m>>i&1) for i in range(11)]+[False,True]
    for op,a,b in data['gates']:vals.append(vals[a] and vals[b] if op=='and' else vals[a] or vals[b])
    return vals

def main():
    assert sha(OLD)==PIN and sha(SOURCE)==SPIN
    out=HERE/'direct21-v1';out.mkdir(exist_ok=False)
    old=OLD.read_text();new=old
    anchor='void write_result(const std::string& path'
    assert new.count(anchor)==1;new=new.replace(anchor,ADDITION+'\n'+anchor,1)
    anchor=' auto baselines=load(pack);Engine engine(seed);'
    replacement=''' bool direct21=is_direct21_pack(pack);
 auto baselines=direct21?std::vector<Baseline>{}:load(pack);
 auto direct_seeds=direct21?load_direct21(pack):std::vector<Circuit>{};
 Engine engine(seed);
 auto fresh=[&]() -> Circuit {
  if(direct21)return direct_seeds[engine.pick(int(direct_seeds.size()))];
  return engine.initial(baselines[engine.pick(int(baselines.size()))]);
 };'''
    assert new.count(anchor)==1;new=new.replace(anchor,replacement+SELFTEST,1)
    anchor='engine.initial(baselines[engine.pick(int(baselines.size()))])'
    assert new.count(anchor)==3
    new=new.replace('Circuit current='+anchor+';','Circuit current=fresh();',1)
    new=new.replace('else current='+anchor+';','else current=fresh();',1)
    anchor='[--self-test]\\n";return 0;'
    assert new.count(anchor)==1
    new=new.replace(anchor,'[--self-test]\\nPacks: COVER_ANNEAL exact22 or COVER_ANNEAL_DIRECT21 validated direct starts.\\n";return 0;',1)
    (out/'parent-circuit_anneal.cpp').write_text(old)
    (out/'circuit_anneal_direct21.cpp').write_text(new)
    (out/'engine.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='reviewed/circuit_anneal.cpp',tofile='new/circuit_anneal_direct21.cpp')))
    data=json.loads(SOURCE.read_text());assert data['size']==len(data['gates'])==21 and data['gate_wire_offset']==13
    edges=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
    target=[any(m>>a&1 and m>>b&1 for a,b in edges) for m in range(2048)]
    before=[evaluate(data,m) for m in range(2048)]
    deps=[{w-13 for w in row[1:] if w>=13} for row in data['gates']]
    ancestors={14};todo=[14]
    while todo:
        for g in deps[todo.pop()]:
            if g not in ancestors:ancestors.add(g);todo.append(g)
    lines=['COVER_ANNEAL_DIRECT21 1 4'];entries=[];orders=[]
    for index,mode in enumerate(('original','reverse-ready','early-junk','late-junk')):
        done=set();order=[]
        while len(order)<21:
            ready=[g for g in range(21) if g not in done and deps[g]<=done]
            if mode=='original':g=min(ready)
            elif mode=='reverse-ready':g=max(ready)
            elif mode=='early-junk':g=min(ready,key=lambda x:(x not in ancestors,x))
            else:g=min(ready,key=lambda x:(x==14,x))
            done.add(g);order.append(g)
        mapping={old:new for new,old in enumerate(order)}
        remap=lambda w:w if w<13 else 13+mapping[w-13]
        seed=dict(inputs=11,gate_wire_offset=13,size=21,
                  gates=[[data['gates'][g][0],*sorted(remap(w) for w in data['gates'][g][1:])] for g in order],
                  output=remap(data['output']))
        fn=fp=0;truth=14695981039346656037
        for m in range(2048):
            after=evaluate(seed,m)
            assert all(after[13+mapping[g]]==before[m][13+g] for g in range(21))
            actual=after[seed['output']];assert actual==before[m][data['output']]
            fn+=target[m] and not actual;fp+=not target[m] and actual
            truth=((truth^actual)*1099511628211)&((1<<64)-1)
        assert (fn,fp)==(0,51)
        p=out/f'seed-{index}.json';write(p,seed)
        lines.append(f'21 {seed["output"]} {fn} {fp} {truth}')
        lines.extend(f'{int(op=="and")} {a} {b}' for op,a,b in seed['gates'])
        entries.append(dict(path=str(p),sha256=sha(p),order=mode,new_to_old=order,
                            original_junk_to_new=mapping[14],full_fn=fn,full_fp=fp,truth_fnv1a64=truth,
                            all_2048_outputs_and_all_intermediates_preserved=True))
        orders.append(tuple(order))
    assert len(set(orders))==4
    pack=out/'direct-seeds.txt';pack.write_text('\n'.join(lines)+'\n')
    write(out/'direct-seeds.json',dict(kind='all2048_checked_inexact_direct21_seed_controls',
        candidate_only=True,assigned_shard_exhaustion=False,requires_Lean_proof=True,count=4,
        pack_sha256=sha(pack),source_sha256=SPIN,preparer_sha256=sha(Path(__file__)),
        engine_source_sha256=sha(out/'circuit_anneal_direct21.cpp'),
        wrapper_sha256='1e6f24c16faf2948c0aec5e4c300f9114d3e331c5894f191c9e0e7607f8afe8b',
        raw_validator_sha256='d244bfc58d60560041c5890592f3c2de90905c78fcd058f691b27e7785131401',seeds=entries))
    write(out/'generation.json',dict(status='GENERATED_FOR_REVIEW_NOT_BUILT_OR_LAUNCHED',
        parent_sha256=PIN,new_source_sha256=sha(out/'circuit_anneal_direct21.cpp'),pack_sha256=sha(pack),
        source_seed_sha256=SPIN,truth_inputs_per_seed=2048,intermediate_comparisons=4*2048*21,
        unchanged_existing_paths=[str(OLD),str(ROOT/'lean-setup/stochastic/circuit_anneal'),str(ROOT/'lean-setup/stochastic/stochastic_tools.py')]))
    print(json.dumps(dict(new_source_sha256=sha(out/'circuit_anneal_direct21.cpp'),pack_sha256=sha(pack),generation=str(out/'generation.json'))))

if __name__=='__main__':main()
