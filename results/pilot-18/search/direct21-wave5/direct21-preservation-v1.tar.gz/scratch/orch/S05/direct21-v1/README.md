# Direct21 candidate restart extension (review required)

The original reviewed engine supports only exact22 seeds: COVER_ANNEAL version1, then a random gate deletion at each fresh restart. Its code/help were inspected; old-binary rejection of the direct21 pack is retained as a finite control. There is no existing21-seed path.

This separate version retains the original exact22 path and adds an explicitly tagged COVER_ANNEAL_DIRECT21 version1 path. Each entry is:

    21 OUTPUT FULL_FALSE_NEGATIVES FULL_FALSE_POSITIVES TRUTH_FNV1A64
    OP A B   (21 gate rows)

Inputs are0..10; FALSE11/TRUE12; gates13..33. OP0=OR/1=AND. The loader checks count1..10000,21gate entries, output bounds, canonical0<=A<=B<13+gate, then computes all2048 output bits independently. Full FN/FP counts and the FNV-1a64 fingerprint must match. The fingerprint is a diagnostic checksum, not cryptographic authentication; the unchanged wrapper binds all pack bytes with SHA256. Extra/truncated content is rejected. Inexact seeds are only initial search states and can never be accepted as target witnesses from this metadata.

The direct fresh-start function copies a21-slot circuit exactly, without deleting a gate. Both initial selection and ordinary restarts use it. The old25-percent best-perturbation restart path remains unchanged. Old baseline deletion, score, mutation, annealing, snapshots, final2048 candidate check, exit/status semantics, bounds and signal handling are unchanged. A source comparison verifies those blocks exactly, except the fresh-start call replacement. Legacy behavior uses the old random calls in their original order.

Four topological orders of the positive18live nonlinear state are packed. Their function is F OR x5 OR ((x0 OR x7) AND (x1 OR x4));0fullFN/51fullFP,0boundaryFN/14boundaryFP. Every21slot value (including dead slots) and output matches the original on all2048 inputs. Original source SHA f54738c35881deea8ba24b6f15cc533042e7db6342e6c31e481528868bc0b8cd. This is not an exact21 witness.

Build: g++ -std=c++17 -O3 -Wall -Wextra -Wpedantic, exit0/1.87s, no warnings; source/binary/command/compiler-version/log hashes in build-result.json. Independent controls use only --self-test and fake engines, not a production search:

- Four direct seeds:128 exact fresh-start controls,512 single-mutation scalar/boundary-vector controls; full scalar2048 evaluation per control.
- Existing exact22 pack:440 deletion-renumbering and440 mutation controls pass unchanged.
- Fifteen malformed direct packs reject (version/count/header/output/op/negative/forward/noncanonical wires/error counts/truth fingerprint/truncation/trailing data).
- Old engine rejects new direct format before search.
- The unchanged wrapper invokes the pinned raw validator for a fake candidate carrying the actual inexact direct seed; validation rejects and wrapper status is ERROR.
- The unchanged wrapper rejects a tampered pack before starting a child.

Existing engine/source/wrapper/raw-validator/oldpack hashes were verified unchanged before and after controls. Full logs and commands are under controls/. No exact21 positive end-to-end fixture is available. Candidate acceptance still requires the unchanged wrapper's pinned independent raw validator, then a Lean proof. Never launch this binary directly for production.

proposed-command.json records an UNEXECUTED60s/weight16 example through the original wrapper. Main/S08 review and main resource admission precede any launch. S05 did no production search, SAT, Lean, desk, credential, git or network action. The earlier authorized60CPU algebra enumeration was superseded and NOT launched.

Reproduction sources: prepare_direct21_engine.py in the parent directory derives the new source from the pinned old source, emits exact engine.diff, and creates the pack; test_direct21_controls.py runs finite controls in a fresh directory. Both refuse to overwrite prior artifacts. Parent source, nonlinear input, reviewed wrapper/raw-validator copies and binaries are preserved for review; existing files outside this new directory are untouched.
