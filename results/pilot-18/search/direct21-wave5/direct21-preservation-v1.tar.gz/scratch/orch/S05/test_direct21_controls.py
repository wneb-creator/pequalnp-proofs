"""Finite direct21/legacy controls and unchanged-wrapper rejection tests."""
from pathlib import Path
import hashlib
import json
import resource
import subprocess
import sys
import time

ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S05';D=HERE/'direct21-v1'
ENGINE=D/'circuit_anneal_direct21';WRAPPER=ROOT/'lean-setup/stochastic/stochastic_tools.py'
PACK=D/'direct-seeds.txt';OLDPACK=HERE/'dirty22-seed-pack/seeds.txt'
OLDCPP=ROOT/'lean-setup/stochastic/circuit_anneal.cpp'
OLDBIN=ROOT/'lean-setup/stochastic/circuit_anneal'
RAW=ROOT/'validate_raw_candidate.py'
PINS={OLDCPP:'a82e670373e5f0048df004efbcb0f417949ce0255545c0767b647cb7207068b3',
      OLDBIN:'31620eae27eed733fe22f94965a215394e3fc6bd2a313f566335a3eb30dd4f00',
      WRAPPER:'1e6f24c16faf2948c0aec5e4c300f9114d3e331c5894f191c9e0e7607f8afe8b',
      RAW:'d244bfc58d60560041c5890592f3c2de90905c78fcd058f691b27e7785131401',
      OLDPACK:'7545d43b161bb5d1fab2cbf3e517c56a40dab5e8e26bdaff4bc4649760dbfe0a'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def limits():
    resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,256*1024**2))
    resource.setrlimit(resource.RLIMIT_CPU,(10,10))

def main():
    start=time.monotonic();out=D/'controls';out.mkdir(exist_ok=False)
    for p,h in PINS.items():assert sha(p)==h
    records=[]
    def run(name,command,expected):
        before=time.monotonic()
        with (out/(name+'.stdout')).open('x') as a,(out/(name+'.stderr')).open('x') as b:
            result=subprocess.run(command,cwd=out,stdout=a,stderr=b,timeout=12,preexec_fn=limits)
        record=dict(name=name,command=command,exit_code=result.returncode,elapsed_seconds=time.monotonic()-before,
                    stdout_sha256=sha(out/(name+'.stdout')),stderr_sha256=sha(out/(name+'.stderr')))
        write(out/(name+'.result.json'),record);records.append(record)
        assert result.returncode in expected,record
        return record
    # Check the production algorithm remains identical except how fresh seeds are selected.
    old=OLDCPP.read_text();new=(D/'circuit_anneal_direct21.cpp').read_text()
    assert old.split('std::vector<Baseline> load',1)[0]==new.split('std::vector<Baseline> load',1)[0]
    oldloop=old.split(' Score current_score=engine.score(current,weight);',1)[1]
    newloop=new.split(' Score current_score=engine.score(current,weight);',1)[1]
    assert newloop.replace('else current=fresh();','else current=engine.initial(baselines[engine.pick(int(baselines.size()))]);')==oldloop
    assert old.split('void write_result(',1)[1].split('int main(',1)[0]==new.split('void write_result(',1)[1].split('int main(',1)[0]
    # Independently parse packed source fields; every original intermediate has already been checked by preparer.
    tokens=PACK.read_text().split();assert tokens[:3]==['COVER_ANNEAL_DIRECT21','1','4'];cursor=3
    for index in range(4):
        count,output,fn,fp,truth=map(int,tokens[cursor:cursor+5]);cursor+=5
        seed=json.loads((D/f'seed-{index}.json').read_text());assert (count,output,fn,fp)==(21,seed['output'],0,51)
        decoded=[]
        for g in range(21):
            op,a,b=map(int,tokens[cursor:cursor+3]);cursor+=3
            assert op in (0,1) and 0<=a<=b<13+g
            decoded.append(['and' if op else 'or',a,b])
        assert decoded==seed['gates']
    assert cursor==len(tokens)
    selftest=out/'direct-selftest.json'
    run('direct-selftest',[str(ENGINE),'--pack',str(PACK),'--output',str(selftest),'--self-test','--seed','134224'],{0})
    assert json.loads(selftest.read_text())==dict(status='SELF_TEST_DIRECT21_PASS',seeds=4,full_truth_inputs=2048,direct_start_controls=128,mutation_controls=512)
    legacy=out/'legacy-selftest.json'
    run('legacy-selftest',[str(ENGINE),'--pack',str(OLDPACK),'--output',str(legacy),'--self-test','--seed','134224'],{0})
    assert json.loads(legacy.read_text())==dict(status='SELF_TEST_PASS',baselines=4,deletion_controls=440,mutation_controls=440)
    # Old engine has no direct21 capability: rejection happens before any search.
    run('old-engine-rejects-direct',[str(OLDBIN),'--pack',str(PACK),'--output',str(out/'old-unused.json'),'--self-test'],{2})
    assert not (out/'old-unused.json').exists()
    replacements={'wrong-version':(1,'2'),'zero-count':(2,'0'),'large-count':(2,'10001'),
        'wrong-gate-count':(3,'22'),'negative-output':(4,'-1'),'out-of-range-output':(4,'34'),
        'wrong-fn':(5,'1'),'wrong-fp':(6,'50'),'wrong-truth':(7,'0'),'bad-operation':(8,'2'),
        'negative-wire':(9,'-1'),'forward-wire':(10,'13'),'unsorted-wire':(9,'3')}
    badpacks={name:tokens[:i]+[value]+tokens[i+1:] for name,(i,value) in replacements.items()}
    badpacks['truncated']=tokens[:-1];badpacks['trailing']=tokens+['garbage']
    for name,bad in badpacks.items():
        path=out/(name+'.pack');path.write_text(' '.join(bad)+'\n');result=out/(name+'-unused.json')
        run(name,[str(ENGINE),'--pack',str(path),'--output',str(result),'--self-test'],{2})
        assert not result.exists()
    # Fake engines exercise the unchanged wrapper's validator path; real engine is NOT searched.
    fake=out/'fake_candidate.py'
    fake.write_text('''#!/usr/bin/python3
import json,sys
from pathlib import Path
args=sys.argv[1:];output=Path(args[args.index('--output')+1])
data=json.loads(Path('''+repr(str(D/'seed-0.json'))+''').read_text())
data['status']='CANDIDATE_NEEDS_INDEPENDENT_VALIDATION'
output.write_text(json.dumps(data)+'\\n')
raise SystemExit(10)
''')
    fake.chmod(0o700)
    wrapper_out=out/'wrapper-rejects-inexact'
    run('wrapper-rejects-inexact',[sys.executable,'-B',str(WRAPPER),'run','--engine',str(fake),
        '--pack',str(PACK),'--output',str(wrapper_out),'--seconds','1','--iterations','1','--restart','100','--weight','16'],{1})
    result=json.loads((wrapper_out/'result.json').read_text())
    assert result['status']=='ERROR' and result['engine_exit']==10 and result['validator_exit']==2
    assert 'REJECTED:' in (wrapper_out/'validation.stdout.txt').read_text()
    # A tampered pack is rejected by the unchanged wrapper before any child starts.
    bad=out/'tampered.txt';bad.write_text(PACK.read_text()+'extra\n')
    bad.with_suffix('.json').write_bytes(PACK.with_suffix('.json').read_bytes())
    blocked=out/'wrapper-hash-blocked'
    run('wrapper-pack-hash-block',[sys.executable,'-B',str(WRAPPER),'run','--engine',str(fake),
        '--pack',str(bad),'--output',str(blocked),'--seconds','1','--iterations','1','--restart','100','--weight','16'],{1})
    assert not blocked.exists()
    for p,h in PINS.items():assert sha(p)==h
    review=dict(status='PASS_READY_FOR_MAIN_S08_REVIEW',elapsed_seconds=time.monotonic()-start,
        source_sha256=sha(D/'circuit_anneal_direct21.cpp'),binary_sha256=sha(ENGINE),pack_sha256=sha(PACK),
        engine_source_parent_sha256=PINS[OLDCPP],script_sha256=sha(Path(__file__)),
        direct_controls=json.loads(selftest.read_text()),legacy_controls=json.loads(legacy.read_text()),
        malformed_direct_pack_controls=len(badpacks),wrapper_raw_validation_rejects_inexact=True,
        wrapper_pack_hash_rejects_tamper=True,mutation_score_loop_and_candidate_path_unchanged=True,
        production_search_launched=False,sat_or_lean_launched=False,existing_tools_unchanged=True,
        exact21_positive_fixture_available=False,records=records)
    write(out/'review.json',review)
    print(json.dumps({k:v for k,v in review.items() if k!='records'}))

if __name__=='__main__':main()
