# Direct21 restart engine preservation

This is a research/candidate package, not a 21-gate witness or a proof.
The reviewed engine accepts explicitly tagged inexact 21-slot restart seeds.
Main owns production launches; unchanged wrapper and independent raw validation remain mandatory.
All original package files are byte preserved except ELF binaries, intentionally excluded.
Omitted binary sizes and SHA256 hashes are in manifest.json. Original handoff paths
are historical; archive members map them under scratch/ relative to the original root.

Rebuild the new binary from circuit_anneal_direct21.cpp using the command in
direct21-v1/build-result.json: g++ -std=c++17 -O3 -Wall -Wextra -Wpedantic SOURCE -o OUTPUT.
Compiler version, successful build stdout/stderr, source hash and observed binary
hash are preserved. Rebuilding on another compiler/environment may change binary bytes.
Parent circuit_anneal.cpp and derivation prepare_direct21_engine.py are included.
Finite controls and all full logs are preserved; test_direct21_controls.py records
the expected original scratch layout and pinned dependencies. No search is run by
this archive creator. Main/S08 reviewed exact original engine/pack independently.
