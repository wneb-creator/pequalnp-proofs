"""Three fresh triangle589 exact-target repairs; no solver or exhaustion claim."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path('/tmp/oec/pequalnp-pilot-18'); HERE = ROOT/'orch/S02'
WRAPPER_SHA = '7552f3d344d4e34a6f681b116b5ec748e032b2000315dfc9527c77f8de2bdb6b'
SOURCE = HERE/'triangle589-repair-analysis/source-augmented.json'
SOURCE_SHA = 'e5306aed955246a17957df3acf76d38049205535d3afc282c4445e458f66ec94'
HOLES = [1,3,5,6,7,8,14,15,16,19,20]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def dependencies():
    path = HERE/'prepare_positive_repairs.py'
    if sha(path.read_bytes()) != WRAPPER_SHA:
        raise ValueError('Reviewed wrapper hash mismatch')
    spec = importlib.util.spec_from_file_location('triangle589_wrapper',path)
    wrapper = importlib.util.module_from_spec(spec); spec.loader.exec_module(wrapper)
    free,distance,local,base = wrapper.dependencies()
    return wrapper,free,distance,local,base


def connected(gates, holes):
    seen = {holes[0]}
    while True:
        old = set(seen)
        for g in holes:
            for wire in gates[g][1:]:
                h = wire-13
                if h in holes and (g in seen or h in seen):
                    seen.update((g,h))
        if seen == old:
            return seen == set(holes)


def generate(output):
    if output.exists():
        raise ValueError('Fresh output directory required')
    raw = SOURCE.read_bytes()
    if sha(raw) != SOURCE_SHA:
        raise ValueError('Pinned triangle589 seed hash mismatch')
    wrapper,free,distance,local,base = dependencies()
    validator = local.load(ROOT/'validate_raw_candidate.py','triangle589_structure',local.RAW_SHA)
    offset,gates,outwire = validator.check_structure(json.loads(raw))
    local.require(offset == 13 and len(gates) == 21,'Expected21 augmented gates')
    data = {'inputs':11,'gate_wire_offset':13,'size':21,'output':outwire,
            'gates':[[op,*sorted((a,b))] for op,a,b in gates]}
    summary = local.source_summary(data)
    local.require(summary['full_2048_false_negative_count']==0 and
                  summary['full_2048_false_positive_count']==10 and
                  len(summary['boundary_false_positive_masks'])==6 and
                  len(summary['live_gates'])==21,'Expected triangle589 source semantics')
    local.require(connected(data['gates'],HOLES),'Disconnected local region')
    output.mkdir(parents=True,exist_ok=False)
    (output/'source.json').write_bytes(raw)
    (output/'source-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    manifest = {'kind':'candidate_only_triangle589_context_and_distance','complete':False,
                'program_sha256':sha(Path(__file__).read_bytes()),'source_sha256':SOURCE_SHA,
                'reviewed_wrapper_sha256':WRAPPER_SHA,'base_generator_sha256':local.BASE_SHA,
                'output_selection_free':True,'assigned_shard_exhaustion':False,'cases':[]}
    for name,budget in [('triangle589-h11',None),('triangle589-k04',4),('triangle589-k06',6)]:
        if budget is None:
            cnf,meta = wrapper.local_free_output(local,base,data,HOLES)
            info = {'kind':'connected_local','free_gates':HOLES,'budget':None,'connected_gate_region':True}
        else:
            cnf,meta = free.unrestricted_distance(distance,local,base,data,budget)
            info = {'kind':'gate_distance','free_gates':list(range(21)),'budget':budget}
        meta.update(program=Path(__file__).name,program_sha256=manifest['program_sha256'],
                    source_sha256=SOURCE_SHA,source_file='source.json',reviewed_wrapper_sha256=WRAPPER_SHA,
                    scope='Candidate-only exact-target repair of triangle589 seed; output free; no exhaustion claim.')
        raw_cnf = local.dimacs(cnf); meta['sha256'] = sha(raw_cnf)
        path = output/(name+'.cnf'); path.write_bytes(raw_cnf)
        path.with_suffix('.json').write_text(json.dumps(meta,indent=2)+'\n')
        manifest['cases'].append({'case':name,**info,'variables':cnf.variables,'clauses':len(cnf.clauses),
            'cnf_sha256':meta['sha256'],'metadata_sha256':sha(path.with_suffix('.json').read_bytes())})
    manifest['complete'] = True
    (output/'family.json').write_text(json.dumps(manifest,indent=2)+'\n')
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output',type=Path)
    result = generate(parser.parse_args().output)
    print(json.dumps({'cases':len(result['cases']),'generator_sha256':result['program_sha256'],'solver_launched':False}))
