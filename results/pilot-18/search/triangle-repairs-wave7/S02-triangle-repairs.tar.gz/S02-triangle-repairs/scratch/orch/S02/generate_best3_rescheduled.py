"""Two reserve candidate repairs after verified topological rescheduling; no solver."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode=True
ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S02'
PARENT_SHA='a32140b75f8c5d47a24cd8b05f0b25c3e9b3b0a239abdc857d5bc67f1108a598'
SOURCE_SHA='9a743d5d43f651198f908fd086b3307e036697ee9d9990f5c0edfcce6ff3fe96'
OLD_HOLES=[2,3,4,5,11,12,13,14,15,16,17,18,19,20]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def dependencies():
    path=HERE/'generate_triangle589_best3_repairs.py'
    if sha(path.read_bytes())!=PARENT_SHA:raise ValueError('Reviewed parent hash mismatch')
    spec=importlib.util.spec_from_file_location('best3_reschedule_parent',path)
    parent=importlib.util.module_from_spec(spec);spec.loader.exec_module(parent)
    return parent.dependencies()


def reorder(data, mode):
    gates=data['gates'];pred=[{w-13 for w in gate[1:] if w>=13} for gate in gates]
    def cone(g):
        seen={g};todo=[g]
        while todo:
            for h in pred[todo.pop()]:
                if h not in seen:seen.add(h);todo.append(h)
        return seen
    inner=cone(17);outer=cone(19)
    done=set();order=[]
    while len(order)<21:
        available=[g for g in range(21) if g not in done and pred[g]<=done]
        if not available:raise ValueError('No topological schedule')
        if mode=='dirty-early':key=lambda g:(0 if g in inner else 1 if g in outer else 2,g)
        elif mode=='reverse-ready':key=lambda g:-g
        else:raise ValueError('Unknown schedule')
        g=min(available,key=key);order.append(g);done.add(g)
    old_to_new={old:new for new,old in enumerate(order)}
    wire=lambda w:w if w<13 else 13+old_to_new[w-13]
    transformed=[[gates[g][0],*sorted((wire(gates[g][1]),wire(gates[g][2])))] for g in order]
    result={'inputs':11,'gate_wire_offset':13,'size':21,'gates':transformed,'output':wire(data['output'])}
    return result,order,old_to_new


def generate(output):
    if output.exists():raise ValueError('Fresh output required')
    raw=(HERE/'triangle589-best3-source.json').read_bytes()
    if sha(raw)!=SOURCE_SHA:raise ValueError('Source hash mismatch')
    source=json.loads(raw);wrapper,free,distance,local,base=dependencies()
    validator=local.load(ROOT/'validate_raw_candidate.py','rescheduled_best3_structure',local.RAW_SHA)
    offset,gates,out=validator.check_structure(source)
    local.require(offset==13 and len(gates)==21,'Expected21 augmented gates')
    before=[local.scalar_values(gates,m) for m in range(2048)]
    output.mkdir(parents=True,exist_ok=False);(output/'original-source.json').write_bytes(raw)
    manifest={'kind':'candidate_only_rescheduled_best3_reserve','complete':False,
              'program_sha256':sha(Path(__file__).read_bytes()),'source_sha256':SOURCE_SHA,
              'reviewed_parent_sha256':PARENT_SHA,'base_generator_sha256':local.BASE_SHA,
              'output_selection_free':True,'assigned_shard_exhaustion':False,'sources':{},'cases':[]}
    for mode,kind in [('dirty-early','local14'),('reverse-ready','distance6')]:
        data,order,mapping=reorder(source,mode)
        local.require(order!=list(range(21)) and len(set(order))==21,'Schedule is not a new permutation')
        validator.check_structure(data)
        for mask in range(2048):
            after=local.scalar_values(data['gates'],mask)
            local.require(before[mask][source['output']]==after[data['output']],'Output changed')
            local.require(all(before[mask][13+g]==after[13+mapping[g]] for g in range(21)),'Intermediate wire changed')
        summary=local.source_summary(data)
        local.require(summary['full_2048_false_negative_count']==0 and summary['full_2048_false_positive_count']==5
                      and len(summary['live_gates'])==21,'Source semantics or liveness changed')
        name=mode+'-source.json';(output/name).write_text(json.dumps(data,indent=2)+'\n')
        provenance={'file':name,'sha256':sha((output/name).read_bytes()),'new_to_old_gate':order,
                    'old_to_new_gate':[mapping[g] for g in range(21)],'junk_gate_positions':[mapping[17],mapping[19]],
                    'summary':summary,'full2048_output_and_all21_gate_values_preserved':True}
        manifest['sources'][mode]=provenance
        if kind=='local14':
            holes=sorted(mapping[g] for g in OLD_HOLES)
            cnf,meta=wrapper.local_free_output(local,base,data,holes)
            case='dirty-early-h14';budget=None
        else:
            holes=list(range(21));budget=6;case='reverse-ready-k06'
            cnf,meta=free.unrestricted_distance(distance,local,base,data,budget)
        meta.update(program=Path(__file__).name,program_sha256=manifest['program_sha256'],
                    source_sha256=provenance['sha256'],source_file=name,original_source_sha256=SOURCE_SHA,
                    schedule=mode,new_to_old_gate=order,old_to_new_gate=provenance['old_to_new_gate'],
                    scope='Candidate-only repair after value-preserving rescheduling; no exhaustion or strict-superset claim.')
        cnf_raw=local.dimacs(cnf);meta['sha256']=sha(cnf_raw)
        path=output/(case+'.cnf');path.write_bytes(cnf_raw)
        path.with_suffix('.json').write_text(json.dumps(meta,indent=2)+'\n')
        manifest['cases'].append({'case':case,'kind':kind,'budget':budget,'free_gates':holes,
                                 'source_file':name,'schedule':mode,'variables':cnf.variables,'clauses':len(cnf.clauses),
                                 'cnf_sha256':meta['sha256'],'metadata_sha256':sha(path.with_suffix('.json').read_bytes())})
    manifest['complete']=True
    (output/'family.json').write_text(json.dumps(manifest,indent=2)+'\n')
    return manifest


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('output',type=Path)
    result=generate(parser.parse_args().output)
    print(json.dumps({'cases':len(result['cases']),'generator_sha256':result['program_sha256'],'solver_launched':False}))
