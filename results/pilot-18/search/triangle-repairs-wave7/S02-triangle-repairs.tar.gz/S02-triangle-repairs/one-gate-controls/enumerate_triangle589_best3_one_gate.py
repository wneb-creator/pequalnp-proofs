"""Bounded exhaustive one-gate rewiring with free output; no SAT solver."""
from pathlib import Path
import hashlib
import json
import resource
import time

ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S02'
SOURCE=HERE/'triangle589-best3-source.json'
OUT=HERE/'triangle589-best3-one-gate-control'
resource.setrlimit(resource.RLIMIT_CPU,(30,30))
started=time.process_time();OUT.mkdir(exist_ok=False)
raw=SOURCE.read_bytes();assert hashlib.sha256(raw).hexdigest()=='9a743d5d43f651198f908fd086b3307e036697ee9d9990f5c0edfcce6ff3fe96'
source=json.loads(raw);gates=source['gates'];assert len(gates)==21
edges=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
target=lambda m:any(m>>a&1 and m>>b&1 for a,b in edges)
positive=[(1<<a)|(1<<b) for a,b in edges]
negative=[m for m in range(2048) if not target(m) and all(m>>i&1 or target(m|(1<<i)) for i in range(11))]
assert len(positive)==16 and len(negative)==24
rows=positive+negative; wanted=(1<<16)-1; allbits=(1<<40)-1
inputs=[sum(((m>>i)&1)<<r for r,m in enumerate(rows)) for i in range(11)]+[0,allbits]
baseline=list(inputs)
for op,a,b in gates:baseline.append(baseline[a]&baseline[b] if op=='and' else baseline[a]|baseline[b])
assert (baseline[source['output']]&wanted)==wanted
best_positive_fp=(baseline[source['output']]^wanted).bit_count()
assert best_positive_fp==3
expected=sum((13+g)*(14+g) for g in range(21))
checked=0;wire_checks=0;exact=[];improvements=[];complete=True
for g in range(21):
    if not complete:break
    for a in range(13+g):
        if not complete:break
        for b in range(a,13+g):
            if not complete:break
            for op in ('and','or'):
                if time.process_time()-started>25:
                    complete=False;break
                values=baseline[:13+g]
                values.append(values[a]&values[b] if op=='and' else values[a]|values[b])
                for tailop,x,y in gates[g+1:]:
                    values.append(values[x]&values[y] if tailop=='and' else values[x]|values[y])
                checked+=1
                for output,actual in enumerate(values):
                    wire_checks+=1
                    if actual==wanted:
                        changed=[list(t) for t in gates];changed[g]=[op,a,b]
                        candidate={'inputs':11,'gate_wire_offset':13,'size':21,'gates':changed,'output':output}
                        for mask in range(2048):
                            scalar=[bool(mask>>i&1) for i in range(11)]+[False,True]
                            for sop,x,y in changed:scalar.append(scalar[x] and scalar[y] if sop=='and' else scalar[x] or scalar[y])
                            assert scalar[output]==target(mask)
                        name=f'exact-{len(exact):04d}.json';p=OUT/name;p.write_text(json.dumps(candidate,indent=2)+'\n')
                        exact.append({'file':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'changed_gate':g,
                                      'replacement':[op,a,b],'output':output,'all_2048_scalar_checked':True,'requires_Lean_proof':True})
                    if actual&wanted==wanted:
                        fp=(actual^wanted).bit_count()
                        if fp<best_positive_fp:
                            best_positive_fp=fp;changed=[list(t) for t in gates];changed[g]=[op,a,b]
                            candidate={'inputs':11,'gate_wire_offset':13,'size':21,'gates':changed,'output':output}
                            name=f'positive-improvement-{len(improvements):02d}.json';p=OUT/name;p.write_text(json.dumps(candidate,indent=2)+'\n')
                            improvements.append({'file':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'boundary_FN':0,'boundary_FP':fp,'changed_gate':g,'replacement':[op,a,b],'output':output})
assert not complete or checked==expected
report={'verdict':'COMPLETE_FINITE_ONE_GATE_ENUMERATION' if complete else 'PARTIAL_CPU_BOUNDED_ENUMERATION',
        'source_sha256':hashlib.sha256(raw).hexdigest(),'program_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'complete':complete,'expected_gate_descriptions':expected,'checked_gate_descriptions':checked,'output_wire_checks':wire_checks,
        'boundary_rows':rows,'exact_candidates':exact,'all_positive_improvements':improvements,'best_all_positive_boundary_FP':best_positive_fp,
        'cpu_seconds':time.process_time()-started,'solver_launched':False,
        'scope':'One gate operator and both fanins can change, free output; all other numbered gates fixed. No global/shard exhaustion or multi-gate impossibility claim.'}
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['verdict','checked_gate_descriptions','output_wire_checks','best_all_positive_boundary_FP','cpu_seconds']}))
