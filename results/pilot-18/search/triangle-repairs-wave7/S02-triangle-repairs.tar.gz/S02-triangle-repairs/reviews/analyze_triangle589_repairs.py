"""Read-only source analysis and unlaunched repair proposals for a new shape."""
from pathlib import Path
import hashlib
import json

ROOT = Path('/tmp/oec/pequalnp-pilot-18'); HERE = ROOT/'orch/S02'
source = ROOT/'orch/S05/triangle589-positive21.json'
raw = source.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '2d99849c19f69c76b232e4d55ce487638721291dac4faea3e82dc3274414bfbe'
data = json.loads(raw)
assert data['inputs'] == 11 and data['gate_wire_offset'] == 11 and len(data['gates']) == 21
edges = [(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
         (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]


def target(mask):
    return any(mask>>a&1 and mask>>b&1 for a,b in edges)


def evaluate(mask, suppressed=None):
    values = [bool(mask>>i&1) for i in range(11)]
    for g,(op,a,b) in enumerate(data['gates']):
        assert op in ('and','or') and type(a) is int and type(b) is int and 0<=a<11+g and 0<=b<11+g
        values.append(False if g==suppressed else (values[a] and values[b] if op=='and' else values[a] or values[b]))
    return values


fn = []; fp = []; junk = set()
for mask in range(2048):
    values = evaluate(mask); actual = values[data['output']]; wanted = target(mask)
    formula = wanted or (bool(mask>>2&1) and bool(mask&129) and bool(mask&18))
    assert actual == formula
    if wanted and not actual: fn.append(mask)
    if actual and not wanted: fp.append(mask)
    if not wanted:
        junk.update(g for g,(op,_,_) in enumerate(data['gates']) if op=='and' and values[11+g])
minimal = [m for m in fp if not any(n!=m and n&m==n for n in fp)]
assert not fn and fp == [7,15,21,29,71,85,134,135,148,149]
assert minimal == [7,21,134,148] and junk == {6,8}
live = {data['output']-11}
for g in reversed(range(21)):
    if g in live:live.update(w-11 for w in data['gates'][g][1:] if w>=11)
assert len(live)==21
positive = [(1<<a)|(1<<b) for a,b in edges]
negative = [m for m in range(2048) if not target(m) and all(m>>i&1 or target(m|(1<<i)) for i in range(11))]
wrong_negative = [m for m in negative if evaluate(m)[data['output']]]
influence = []
for g in range(21):
    fixed = [m for m in wrong_negative if not evaluate(m,g)[data['output']]]
    lost = [m for m in positive if not evaluate(m,g)[data['output']]]
    influence.append({'gate':g,'suppression_fixes_negative_masks':fixed,'suppression_loses_positive_masks':lost})
lift = lambda w:w if w<11 else w+2
augmented = {'inputs':11,'gate_wire_offset':13,'size':21,
             'gates':[[op,*sorted((lift(a),lift(b)))] for op,a,b in data['gates']],
             'output':lift(data['output'])}
out = HERE/'triangle589-repair-analysis';out.mkdir(exist_ok=False)
(out/'source-augmented.json').write_text(json.dumps(augmented,indent=2)+'\n')
report = {'verdict':'PASS_FINITE_SOURCE_ANALYSIS_ONLY_NO_CNF_OR_SOLVER',
          'source_sha256':hashlib.sha256(raw).hexdigest(),
          'analysis_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'augmented_source_sha256':hashlib.sha256((out/'source-augmented.json').read_bytes()).hexdigest(),
          'exact_shape':'F OR (x2 AND (x0 OR x7) AND (x1 OR x4))',
          'full_2048_shape_checks':2048,'full_FN':0,'full_FP':len(fp),
          'minimal_extras':[{ 'mask':m,'vertices':[i for i in range(11) if m>>i&1]} for m in minimal],
          'boundary_FP_masks':wrong_negative,'live_gates':sorted(live),'junk_AND_gates':sorted(junk),
          'gate_suppression_analysis':influence,
          'proposals':[{'kind':'free_output_distance','budget':3,
                        'reason':'Different sparse higher-degree error shape; let solver choose edits and output, rather than replay old singleton-error windows.'},
                       {'kind':'free_output_local','free_gates':[1,3,5,6,7,8,20],
                        'reason':'Free both dirty ANDs, their three OR factors, center OR, and output; retain clean residual stars.'},
                       {'kind':'free_output_local','free_gates':[1,3,5,6,7,8,14,15,16,20],
                        'reason':'Also admit variable10-star sharing/refactoring with the variable2 leaf; broader alternative if restricted template is closed.'}],
          'limitations':['No repair feasibility or performance evidence.','Suppression is diagnostic, not an allowed gate operation or proof.','No source is an exact21 witness.','Main chooses any generation or launch; no additional portfolio prepared.']}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['verdict','source_sha256','full_FN','full_FP','minimal_extras','junk_AND_gates']}))
