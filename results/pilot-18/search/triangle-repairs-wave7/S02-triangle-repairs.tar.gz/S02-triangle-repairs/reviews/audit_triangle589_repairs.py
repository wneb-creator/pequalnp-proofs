"""Exact CNF reconstruction and independent scalar/counter controls; no solver."""
from pathlib import Path
import hashlib
import importlib.util
import json
import random
import sys

sys.dont_write_bytecode=True
ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S02'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
edges=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
reports=[];tested_budgets=set();counter_tests=0;keep_tests=0


def totalizer(cnf, literals, cap, nodes):
    if len(literals)==1:return list(literals)
    mid=len(literals)//2
    left=totalizer(cnf,literals[:mid],cap,nodes)
    right=totalizer(cnf,literals[mid:],cap,nodes)
    out=[cnf.var() for _ in range(min(cap,len(left)+len(right)))]
    for i in range(len(left)+1):
        for j in range(len(right)+1):
            if 0<i+j<=len(out):
                cnf.clauses.append(([-left[i-1]] if i else [])+([-right[j-1]] if j else [])+[out[i+j-1]])
    for i in range(len(left)+1):
        for j in range(len(right)+1):
            if i+j<len(out):
                cnf.clauses.append([-out[i+j]]+([left[i]] if i<len(left) else [])+([right[j]] if j<len(right) else []))
    nodes.append((list(literals),out))
    return out


for suffix,best in [('',False),('_best3',True)]:
    stem='triangle589-best3' if best else 'triangle589'
    script=HERE/('generate_triangle589'+suffix+'_repairs.py')
    spec=importlib.util.spec_from_file_location('audit_'+stem,script)
    generator=importlib.util.module_from_spec(spec);spec.loader.exec_module(generator)
    wrapper,free,distance,local,base=generator.dependencies()
    family=HERE/(stem+'-repair-family');manifest=json.loads((family/'family.json').read_text())
    assert manifest['complete'] and manifest['program_sha256']==sha(script) and len(manifest['cases'])==3
    source=json.loads((family/'source.json').read_text());gates=source['gates'];assert sha(family/'source.json')==generator.SOURCE_SHA
    assert source['gate_wire_offset']==13 and len(gates)==21
    fn=[];fp=[];junk=set();intermediate_checks=0
    for mask in range(2048):
        values=[bool(mask>>i&1) for i in range(11)]+[False,True]
        for g,(op,a,b) in enumerate(gates):
            assert op in ('and','or') and type(a)is int and type(b)is int and 0<=a<=b<13+g
            values.append(values[a] and values[b] if op=='and' else values[a] or values[b]);intermediate_checks+=1
        target=any(mask>>a&1 and mask>>b&1 for a,b in edges)
        expected=target or (values[2] and (values[0] or values[7]) and (values[4] if best else values[1] or values[4]))
        actual=values[source['output']];assert actual==expected
        if target and not actual:fn.append(mask)
        if actual and not target:fp.append(mask)
        if not target:junk.update(g for g,(op,_,_) in enumerate(gates) if op=='and' and values[13+g])
    assert not fn and fp==([21,29,85,148,149] if best else [7,15,21,29,71,85,134,135,148,149])
    assert junk==({17,19} if best else {6,8})
    holes=generator.HOLES;adjacency={g:set() for g in holes}
    for g in holes:
        for w in gates[g][1:]:
            if w-13 in adjacency:adjacency[g].add(w-13);adjacency[w-13].add(g)
    todo=[holes[0]];seen=set()
    while todo:
        g=todo.pop()
        if g not in seen:seen.add(g);todo.extend(adjacency[g]-seen)
    assert seen==set(holes) and 8<=len(holes)<=12
    case_reports=[]
    for row in manifest['cases']:
        path=family/(row['case']+'.cnf');meta=json.loads(path.with_suffix('.json').read_text())
        assert sha(path)==row['cnf_sha256']==meta['sha256'] and sha(path.with_suffix('.json'))==row['metadata_sha256']
        cnf,original=base.build(size=21,first_junk=0,second_junk=False,prefix_sort=False,last_output=False,live=False,productive_prefix=False)
        before=local.dimacs(cnf);marker=[original['junk'][0]];assert cnf.clauses.count(marker)==1
        removal=cnf.clauses.index(marker);cnf.clauses.pop(removal)
        assert meta['base_with_forced_junk_sha256']==hashlib.sha256(before).hexdigest()
        assert meta['removed_unit_original_index']==removal
        if row['budget'] is None:
            pins=[]
            for g,(op,a,b) in enumerate(gates):
                if g not in holes:pins.extend([[original['ops'][g] if op=='and' else -original['ops'][g]],[original['lefts'][g][a]],[original['rights'][g][b]]])
            cnf.clauses.extend(pins);assert pins==meta['pin_clauses'] and row['free_gates']==holes
        else:
            budget=row['budget'];keeps=[cnf.var() for _ in range(21)]
            assert keeps==meta['keep_gate_flags'] and meta['gate_distance_budget']==budget
            for g,(op,a,b) in enumerate(gates):
                match=[original['ops'][g] if op=='and' else -original['ops'][g],original['lefts'][g][a],original['rights'][g][b]]
                assert match==meta['keep_gate_match_literals'][g]
                gadget=[[-keeps[g],v] for v in match]+[[keeps[g],*[-v for v in match]]]
                cnf.clauses.extend(gadget)
                for mask in range(8):
                    for keep in [False,True]:
                        assignment={abs(v):(bool(mask>>i&1)==(v>0)) for i,v in enumerate(match)};assignment[keeps[g]]=keep
                        sat=all(any(assignment[abs(v)]==(v>0) for v in c) for c in gadget)
                        assert sat==(keep==(mask==7));keep_tests+=1
            start=len(cnf.clauses);nodes=[];thresholds=totalizer(cnf,[-k for k in keeps],budget+1,nodes)
            cnf.clauses.append([-thresholds[budget]])
            assert thresholds==meta['changed_gate_thresholds'] and not meta['pin_clauses'] and not meta['fixed_gates']
            if budget not in tested_budgets:
                rng=random.Random(134218+budget)
                masks=[(1<<n)-1 for n in range(22)]+[rng.getrandbits(21) for _ in range(128)]
                for mask in masks:
                    assignment={k:not bool(mask>>i&1) for i,k in enumerate(keeps)}
                    for leaves,outputs in nodes:
                        count=sum(assignment[abs(v)]==(v>0) for v in leaves)
                        assignment.update({v:count>=i+1 for i,v in enumerate(outputs)})
                    assert all(any(assignment[abs(v)]==(v>0) for v in c) for c in cnf.clauses[start:-1])
                    assert (not assignment[thresholds[budget]])==(mask.bit_count()<=budget)
                    for flip in thresholds:
                        assignment[flip]=not assignment[flip]
                        assert not all(any(assignment[abs(v)]==(v>0) for v in c) for c in cnf.clauses[start:-1])
                        assignment[flip]=not assignment[flip]
                    counter_tests+=1
                tested_budgets.add(budget)
        assert path.read_bytes()==local.dimacs(cnf)
        assert meta['variables']==cnf.variables and meta['clauses']==len(cnf.clauses)
        assert [original['output_selectors'][source['output']]] not in cnf.clauses
        assert meta['output_selection_free'] and 'fixed_output_wire' not in meta
        assert meta['clean_prefix_length']==0 and meta['candidate_only']
        assert all(not meta[k] for k in ['enforce_junk','second_junk','prefix_sort','live','last_output','productive_prefix','assigned_shard_exhaustion'])
        case_reports.append({**row,'complete_clause_bytes_reconstructed':True,'source_output_pin_absent':True})
    try:generator.generate(family)
    except ValueError:pass
    else:raise AssertionError('Existing output accepted')
    reproduced=HERE/(stem+'-repair-reproduced');generator.generate(reproduced)
    names=sorted(p.name for p in family.iterdir());assert len(names)==9
    assert all((family/n).read_bytes()==(reproduced/n).read_bytes() for n in names)
    report={'verdict':'PASS_SELF_SCALAR_EXACT_CNF_AND_DISTANCE_SEMANTICS_READY_MAIN_REVIEW',
            'generator_sha256':sha(script),'audit_sha256':sha(Path(__file__)),'source_sha256':generator.SOURCE_SHA,
            'family_manifest_sha256':sha(family/'family.json'),'full_FN':0,'full_FP_masks':fp,'junk_AND_gates':sorted(junk),
            'scalar_inputs':2048,'intermediate_evaluations':intermediate_checks,'connected_free_gates':holes,
            'cases':case_reports,'byte_identical_reproduction_files':9,'existing_directory_rejected':True,
            'prior_reviewed_wrapper_sha256':generator.WRAPPER_SHA,'solver_launched':False,'blocking_findings':[],
            'scope':'Three exact-target candidate neighborhoods; unrestricted output; no global/shard exhaustion.'}
    p=HERE/(stem+'-repair-review.json');p.write_text(json.dumps(report,indent=2)+'\n')
    reports.append({'review':str(p),'sha256':sha(p),'generator_sha256':sha(script)})
(HERE/'triangle589-repair-control-totals.json').write_text(json.dumps({'full_inputs':4096,'source_intermediate_evaluations':86016,'exact_CNF_reconstructions':6,'keep_equivalence_assignments':keep_tests,'actual21_counter_assignments':counter_tests,'counter_caps':[5,7],'all_root_threshold_single_flip_rejected':True,'solver_launched':False},indent=2)+'\n')
print(json.dumps({'reports':reports,'keep_equivalence_assignments':keep_tests,'counter_assignments':counter_tests}))
