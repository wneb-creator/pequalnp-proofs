"""Independent renumbering, full-input value and exact-CNF checks; no solver."""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode=True
ROOT=Path('/tmp/oec/pequalnp-pilot-18');HERE=ROOT/'orch/S02';FAMILY=HERE/'best3-rescheduled-family'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
script=HERE/'generate_best3_rescheduled.py'
spec=importlib.util.spec_from_file_location('rescheduled_best3_audit',script)
generator=importlib.util.module_from_spec(spec);spec.loader.exec_module(generator)
wrapper,free,distance,local,base=generator.dependencies()
manifest=json.loads((FAMILY/'family.json').read_text())
assert manifest['complete'] and manifest['program_sha256']==sha(script) and len(manifest['cases'])==2
original=json.loads((FAMILY/'original-source.json').read_text())
assert sha(FAMILY/'original-source.json')==generator.SOURCE_SHA
edges=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]


def scalar(data,mask):
    values=[bool(mask>>i&1) for i in range(11)]+[False,True]
    for g,(op,a,b) in enumerate(data['gates']):
        assert op in ('and','or') and type(a)is int and type(b)is int and 0<=a<=b<13+g
        values.append(values[a] and values[b] if op=='and' else values[a] or values[b])
    return values


def cone(g):
    result={g};todo=[g]
    while todo:
        for w in original['gates'][todo.pop()][1:]:
            if w>=13 and w-13 not in result:result.add(w-13);todo.append(w-13)
    return result


before=[scalar(original,m) for m in range(2048)];inner=cone(17);outer=cone(19)
source_reports={};gate_comparisons=0
for mode,entry in manifest['sources'].items():
    path=FAMILY/entry['file'];assert sha(path)==entry['sha256']
    data=json.loads(path.read_text());order=entry['new_to_old_gate'];mapping=entry['old_to_new_gate']
    assert sorted(order)==list(range(21)) and order!=list(range(21))
    assert all(mapping[g]==order.index(g) for g in range(21))
    done=set()
    for i,g in enumerate(order):
        ready=[h for h in range(21) if h not in done and all(w<13 or w-13 in done for w in original['gates'][h][1:])]
        if mode=='dirty-early':assert g==min(ready,key=lambda h:(0 if h in inner else 1 if h in outer else 2,h))
        else:assert mode=='reverse-ready' and g==max(ready)
        done.add(g)
        op,a,b=original['gates'][g];lift=lambda w:w if w<13 else 13+mapping[w-13]
        assert data['gates'][i]==[op,*sorted((lift(a),lift(b)))]
    assert data['output']==13+mapping[original['output']-13]
    fn=[];fp=[];junk=set()
    for mask in range(2048):
        after=scalar(data,mask);target=any(mask>>a&1 and mask>>b&1 for a,b in edges)
        assert before[mask][:13]==after[:13]
        assert before[mask][original['output']]==after[data['output']]
        for g in range(21):assert before[mask][13+g]==after[13+mapping[g]];gate_comparisons+=1
        assert after[data['output']]==(target or (after[2] and after[4] and (after[0] or after[7])))
        if target and not after[data['output']]:fn.append(mask)
        if not target and after[data['output']]:fp.append(mask)
        if not target:junk.update(g for g,(op,_,_) in enumerate(data['gates']) if op=='and' and after[13+g])
    assert not fn and fp==[21,29,85,148,149] and junk=={mapping[17],mapping[19]}
    source_reports[mode]={'file':entry['file'],'sha256':sha(path),'new_to_old_gate':order,
                          'junk_gate_positions':sorted(junk),'full_FN':0,'full_FP_masks':fp}

counter_path=HERE/'audit_triangle589_repairs.py'
counter_source=ast.parse(counter_path.read_text())
node=next(n for n in counter_source.body if isinstance(n,ast.FunctionDef) and n.name=='totalizer')
namespace={};exec(compile(ast.Module(body=[node],type_ignores=[]),str(counter_path),'exec'),namespace)
case_reports=[]
for row in manifest['cases']:
    data=json.loads((FAMILY/row['source_file']).read_text())
    path=FAMILY/(row['case']+'.cnf');meta=json.loads(path.with_suffix('.json').read_text())
    assert sha(path)==row['cnf_sha256']==meta['sha256'] and sha(path.with_suffix('.json'))==row['metadata_sha256']
    cnf,base_meta=base.build(size=21,first_junk=0,second_junk=False,prefix_sort=False,last_output=False,live=False,productive_prefix=False)
    original_bytes=local.dimacs(cnf);unit=[base_meta['junk'][0]];assert cnf.clauses.count(unit)==1
    cnf.clauses.remove(unit)
    assert meta['base_with_forced_junk_sha256']==hashlib.sha256(original_bytes).hexdigest()
    if row['budget'] is None:
        mapping=manifest['sources'][row['schedule']]['old_to_new_gate']
        holes=sorted(mapping[g] for g in [2,3,4,5,11,12,13,14,15,16,17,18,19,20])
        assert holes==row['free_gates'] and len(holes)==14
        adjacency={g:set() for g in holes}
        for g in holes:
            for w in data['gates'][g][1:]:
                if w-13 in adjacency:adjacency[g].add(w-13);adjacency[w-13].add(g)
        seen=set();todo=[holes[0]]
        while todo:
            g=todo.pop()
            if g not in seen:seen.add(g);todo.extend(adjacency[g]-seen)
        assert seen==set(holes)
        pins=[]
        for g,(op,a,b) in enumerate(data['gates']):
            if g not in holes:pins.extend([[base_meta['ops'][g] if op=='and' else -base_meta['ops'][g]],[base_meta['lefts'][g][a]],[base_meta['rights'][g][b]]])
        cnf.clauses.extend(pins);assert pins==meta['pin_clauses'] and len(pins)==21
    else:
        assert row['budget']==6 and row['free_gates']==list(range(21))
        keeps=[cnf.var() for _ in range(21)];assert keeps==meta['keep_gate_flags']
        for g,(op,a,b) in enumerate(data['gates']):
            match=[base_meta['ops'][g] if op=='and' else -base_meta['ops'][g],base_meta['lefts'][g][a],base_meta['rights'][g][b]]
            assert match==meta['keep_gate_match_literals'][g]
            cnf.clauses.extend([[-keeps[g],lit] for lit in match]+[[keeps[g],*[-lit for lit in match]]])
        thresholds=namespace['totalizer'](cnf,[-v for v in keeps],7,[]);cnf.clauses.append([-thresholds[6]])
        assert thresholds==meta['changed_gate_thresholds'] and not meta['pin_clauses']
    assert path.read_bytes()==local.dimacs(cnf) and meta['variables']==cnf.variables and meta['clauses']==len(cnf.clauses)
    assert [base_meta['output_selectors'][data['output']]] not in cnf.clauses
    assert meta['output_selection_free'] and 'fixed_output_wire' not in meta and meta['clean_prefix_length']==0
    assert all(not meta[k] for k in ['enforce_junk','second_junk','prefix_sort','live','last_output','productive_prefix','assigned_shard_exhaustion'])
    case_reports.append({**row,'complete_clause_bytes_reconstructed':True,'output_unit_absent':True})
reproduced=HERE/'best3-rescheduled-reproduced';generator.generate(reproduced)
names=sorted(p.name for p in FAMILY.iterdir());assert len(names)==8
assert all((FAMILY/n).read_bytes()==(reproduced/n).read_bytes() for n in names)
try:generator.generate(FAMILY)
except ValueError:pass
else:raise AssertionError('Existing output accepted')
report={'verdict':'PASS_SELF_ALL_WIRE_VALUES_TOPOLOGICAL_AND_EXACT_CNF_READY_MAIN_REVIEW',
        'generator_sha256':sha(script),'audit_sha256':sha(Path(__file__)),'family_manifest_sha256':sha(FAMILY/'family.json'),
        'source_sha256':generator.SOURCE_SHA,'scalar_output_checks':4096,'intermediate_wire_comparisons':gate_comparisons,
        'sources':source_reports,'cases':case_reports,'byte_identical_reproduction_files':8,'existing_directory_rejected':True,
        'reviewed_counter_reconstruction_source_sha256':sha(counter_path),'blocking_findings':[],
        'solver_launched':False,'scope':'Two reserve candidate neighborhoods only. Rescheduling preserves the seed; search domains need not contain one another.'}
p=HERE/'best3-rescheduled-review.json';p.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'review_sha256':sha(p),'generator_sha256':sha(script),'wire_comparisons':gate_comparisons,
                  'junk_gate_positions':{k:v['junk_gate_positions'] for k,v in source_reports.items()}}))
