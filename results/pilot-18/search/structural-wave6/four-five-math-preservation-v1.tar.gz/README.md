# Four/five common-neighbor factor review preservation

Independent S04 mathematical and finite PASS for S01's27-artifact handoff.
All49 eligible supports,211876 four-factor and1906884 five-factor combinations,
1112320 independently traversed position/ancestry choices, and every stored
decision are checked. The four-factor class retains115 abstract support
patterns. The bespoke five-factor and position filters each leave a different
single survivor; their exclusion union covers all331 joint-feasible k5/r0
families (290one-spare+40position+1reverse-owner). The first reviewer harness
mistakenly asserted those single survivors equal; its complete source/logs
are preserved, and the final reviewer explicitly validates the union.

Scope: minimal distinct proper full-cover factors in17-gate productive
ambient-clean prefixes, with a common neighbor for every factor support.
All r>0 cases remain open; k3/r0 retains262 and k4/r0 retains115. This is
mathematical finite support-family exclusion, not a Lean theorem, SAT proof,
whole-shard/global lower bound, or accepted generated CNF cut. The resulting
AAAA existence normalization needs minimal-factor selection and reviewed
repeat padding; it is not a clause valid for every nonminimal five-leaf model.

All sources, proofs, finite tables, independent results and complete producer
and reviewer stdout/stderr are included. Source paths and hashes are bound by
manifest. No raw CNFs or binaries. Sources retain original fixed workspace
paths and timing-dependent logs; preservation does not rerun or alter them.
The sibling multi-hitting-math-preservation-v1 archive separately preserves
the stronger irrelevant-input charge and75 actual-DAG controls.
