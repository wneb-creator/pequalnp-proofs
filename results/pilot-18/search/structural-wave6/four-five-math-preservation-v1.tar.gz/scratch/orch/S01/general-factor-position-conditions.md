# General selected-output position relaxation for four/five factors

For independent review. This generalizes the reviewed three-factor position
conditions to minimal families of k=4 or5 proper full-cover prefix outputs.
All supports in the finite census have one common-neighbor owner. Nothing
here exhausts families containing a no-common-neighbor support.

The script filter_four_five_positions.py enumerates every allowed distinct
output-position tuple and every transitive ancestry relation compatible with
the chronological order. There are40transitive relations on four ordered
vertices and357on five; the script checks these counts explicitly. A real
prefix circuit supplies one of those tuples and relations.

It applies the reviewed individual/support-owner/raw-essentiality cone bounds,
the need for an intervening unselected AND between incomparable selected
ancestor outputs, and these three general counting conditions.

## Selected-source component count

If r selected outputs are ancestors of a chosen selected output, at least r
unselected gates occur between the earliest of those sources and the output.
The complete OR-component/first-AND-boundary proof is in
five-factor-two-spare-bound.md. It applies to arbitrary k>=3: every pair of
selected factors is dirty, and their supports are incomparable. It counts
nodes in the actual DAG and permits sharing. The finite filter checks the
number of available unselected positions against r.

## Gates excluded by an outside ancestry chain

For output i, let O be the earlier selected outputs which are not ancestors
of i. Each such selected gate is excluded from i's ancestor cone. If O
contains a selected-ancestry chain of length ell, at least ell-1 additional
AND gates are also excluded. Consecutive chain members have incomparable
supports, so each transition needs an AND in the open interval between them.
These intervals are disjoint. Every such AND has an outside selected ancestor;
if it were ancestral to i, that selected output would be ancestral too.
These ANDs are distinct from the selected OR outputs.

Thus the cone upper bound is the gate position plus1, minus |O|, minus the
maximum outside-chain length minus1 (zero when there is no nontrivial chain).
This is exactly the earlier three-output extra-AND bound when ell=2.

## Ancestor-cone union lower bounds

If selected output j is an ancestor of i, at least two gates outside j's cone
are required: a new AND to remove j's incomparable support, and i's OR output.
Hence M_i>=M_j+2.

More generally, take r>=2 pairwise-unrelated selected ancestors of i. Their
cone union contains at least max_j M_j + r-1 gates: all other r-1 selected
outputs lie outside whichever cone realizes the maximum. The first-AND
component count supplies at least r additional unselected gates outside that
union. Each such OR/boundary-AND gate is a descendant of at least one of the
chosen sources and cannot be ancestral to a different chosen source, because
the sources are pairwise unrelated. Finally i itself is a new selected OR
gate, distinct from the boundary nodes (an OR-only path to i is impossible).
Therefore

    M_i >= max_j M_j + 2*r.

The script applies this to every ancestry-antichain subset of the selected
ancestors and propagates lower bounds in chronological order. This uses actual
ancestry relations, not an assumption that all selected factors are unrelated.

## Result and scope

Of the312 four-factor families left by the one-spare filter,197 are rejected
and115 remain. Of41five-factor families,40 are rejected and one remains:

    supports417,562,772,584,1152; costs11,12,13,14,15.

This last family satisfies the separate unique-cost11/reverse-owner obstruction
in five-factor-two-spare-bound.md. Conversely the bespoke argument's remaining
family417,560,1282,84,1160 is rejected by this position filter. Thus combining
the two finite classifications excludes all331joint-feasible k5/r0families.
All earlier individual/slot/minimality/joint tests are necessary as documented
in the complete49-support census. The aggregate is a finite mathematical
support-family exclusion, pending independent review, not a Lean or SAT proof.

The finite run checked1,018,884position/relation assignments in about1second.
Every rejected family has all its candidates checked; for a survivor the code
retains one concrete abstract tuple/relation. It does not claim that such an
abstract survivor is a realizable circuit. All r>0cases remain open.

After independent review this would justify an existence normalization for
the AAAA chain: if every minimal retained factor has a common neighbor, at
most four distinct factors are needed. Padding repeats as in the reviewed
chain normalization preserves the shard. It would not be a logical clause
implied by every nonminimal five-leaf representation of the original CNF.
