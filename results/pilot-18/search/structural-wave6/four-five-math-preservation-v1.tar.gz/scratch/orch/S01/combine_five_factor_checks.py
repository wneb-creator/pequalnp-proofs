#!/usr/bin/env python3
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parent
census=ROOT/'common-four-five-enumeration.json'
bespoke=ROOT/'five-factor-bound-validation.json'
position=ROOT/'four-five-position-filter.json'
c=json.loads(census.read_text());b=json.loads(bespoke.read_text());p=json.loads(position.read_text())
assert c['verdict']=='COMPLETE_FINITE_COMMON_NEIGHBOR_CENSUS'
assert p['verdict']=='COMPLETE_FINITE_POSITION_RELAXATION'
assert b['census_sha256']==hashlib.sha256(census.read_bytes()).hexdigest()==p['input_sha256']
base=next(r for r in c['results'] if r['counts']['k']==5)
pos=next(r for r in p['results'] if r['k']==5)
bmap={tuple(sorted(r['supports'])):r for r in b['families']}
pmap={tuple(sorted(r['supports'])):r for r in pos['families']}
assert len(base['survivors'])==len(bmap)==331 and len(pmap)==41
records=[]
for family in base['survivors']:
    key=tuple(sorted(family['supports']))
    B=bmap[key]
    if family['pattern']['excluded']:
        assert B['reason']=='ONE_SPARE_PATTERN'
        reason='ONE_SPARE_PATTERN'
    elif pmap[key]['excluded']:
        reason='POSITION_AND_ANCESTOR_CONES'
    else:
        assert B['reason']=='UNIQUE_COST11_SOURCE_REVERSE_OWNER_CHARGE'
        reason=B['reason']
    records.append(dict(supports=family['supports'],reason=reason))
from collections import Counter
counts=dict(Counter(r['reason'] for r in records))
assert counts=={'ONE_SPARE_PATTERN':290,'POSITION_AND_ANCESTOR_CONES':40,
               'UNIQUE_COST11_SOURCE_REVERSE_OWNER_CHARGE':1}
out=dict(verdict='ALL_331_K5_R0_SUPPORT_FAMILIES_EXCLUDED_PENDING_INDEPENDENT_REVIEW',
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    inputs=[dict(path=str(q),sha256=hashlib.sha256(q.read_bytes()).hexdigest()) for q in (census,bespoke,position)],
    counted_k5_combinations=1906884,slot_pass=679398,minimal_joint_pass=331,
    covered_counts=counts,remaining=0,families=records,
    r_positive_status='OPEN_NOT_EXHAUSTED',k4_r0_remaining=115,k3_r0_remaining=262,
    solver_run=False,Lean_proof=False)
(ROOT/'five-factor-combined-coverage.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ('verdict','covered_counts','remaining','source_sha256')}))
