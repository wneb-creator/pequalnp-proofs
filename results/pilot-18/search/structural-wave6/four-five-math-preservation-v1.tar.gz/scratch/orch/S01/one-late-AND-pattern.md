# Reusable three-factor pattern with only one spare late gate

Mathematical generalization for independent review. Source coverage script:
classify_three_common_factors.py. No Lean/solver conclusion.

Assume three incomparable proper full-cover factors in a productive clean
prefix of17gates. Their minimal family computes F; each proper subproduct is
dirty. Let S_i, L_i, v_i be their supports, individual ancestor bounds and
unique common-neighbor owners. Assume every L_i>=14. Each factor output is
an OR gate, at an index at least13. Thus among positions13..16 the three
outputs leave just one unselected gate q.

There are exactly two possibilities for ancestry among selected outputs.

1. None is an ancestor of another. Each selected output then has at most15
   ancestor gates, since the other two distinct output gates are excluded.
   Consequently this pattern requires every L_i<=15.

2. There is ancestry. Incomparable supports require an intervening AND, so
   q is that AND. All such paths pass through q. At most one selected factor
   B can be an ancestor of q. Two on opposite input sides make q dirty by
   minimality of the family. Two on the same side need an additional OR merge
   before q, impossible with the single spare gate; neither incomparable
   selected output can be that OR merge. Hence the selected ancestry is a
   star, with source B and a nonempty subset of the other outputs as children.

For this star, write q=B AND R. The other operand has support {v_B} by
productivity and the unique-common-neighbor property. Each child C is
q OR P_C with support P_C=S_C. The operands R and P_C are raw inputs or
gates0..12: none can be another selected factor because of support sizes and
incomparability. Since |S_C|>=2, P_C is a gate, not a raw input or constant.

The source B and each nonchild selected output have at most14ancestor gates:
the other two selected outputs and q are excluded. Thus their bounds must
equal14. B's ancestor cone consequently contains every gate0..12. Each child
has exactly16ancestor gates: the common thirteen, B, q, and the child itself.
The other selected output cannot be its ancestor, because that would need
another intervening AND.

These facts imply the following necessary conditions for each candidate star.

- The source and nonchildren have L=14.
- For each child C, L_C + indicator(v_B in S_C) <=16. If v_B lies in S_C,
  restricting S_C deletes q in addition to the support OR gates, as in the
  reviewed joint charge.
- For each child C, v_C is not in S_B. Otherwise P_C is an ancestor of B,
  its support is S_C, and its only common neighbor belongs to S_B. The
  arbitrary-supported-ancestor restriction charge raises B's bound to15,
  contradicting its exact14-gate cone. This uses the generalization in
  tight-survivor-obstruction.md; P_C need not cover all edges.
- If S_B=N(v_B), R must be raw x_(v_B). If it were a gate in0..12, it would
  be an ancestor of B and the same charge for support {v_B} would contradict
  the14-gate cone. Consequently each P_C must accept all target edges not
  incident to v_B. Let p_C be its partial-support lower bound on edges outside
  S_C and not incident to v_B. Necessarily p_C<=12. A bound>=13 puts P_C at
  gate12 (or later), but gate12 must directly feed B's OR: there is no
  intervening ancestor gate before B. Its incomparable support makes this
  impossible.
- In the preceding raw-input case, two children cannot both have p_C>=12.
  Their distinct P_C gates would occupy11and12, again putting one incompatible
  operand at gate12. Thus the code rejects this case as well.

All these conditions are necessary, not sufficient. The script enumerates
the ancestry-free possibility and all nine source/child-subset stars, records
each failed condition, and excludes a family only when every possibility
fails. Families with some L<14 are left untouched. The finite result is
233excluded and282remaining among the515 supplied k3/r0 survivors. This
does not cover r>0 or four/five-factor families, nor prove AAAA exhaustion.

For the original triple810/910/46, B=910 would be the required source of C=46.
But v_C=10 lies in S_B, so the third bullet already excludes it. The longer
raw-x0/eight-edge argument is a separate valid way to reach that contradiction.
