#!/usr/bin/env python3
"""Bounded finite position/poset relaxation, no SAT solver."""
import hashlib
import itertools
import json
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
P=ROOT/'common-four-five-enumeration.json'
data=json.loads(P.read_text())
assert data['verdict']=='COMPLETE_FINITE_COMMON_NEIGHBOR_CENSUS'
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
   (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
N=[sum(1<<(b if a==v else a) for a,b in E if v in(a,b)) for v in range(11)]
START=time.monotonic();checked=0
class Limit(Exception):pass

def posets(k):
    out=[]
    for masks in itertools.product(*(range(1<<i) for i in range(k))):
        if any(masks[j]&~masks[i] for i in range(k) for j in range(i) if masks[i]>>j&1):continue
        ancestors=[[j for j in range(i) if masks[i]>>j&1] for i in range(k)]
        excluded=[];antichains=[]
        for i in range(k):
            outside=[j for j in range(i) if not masks[i]>>j&1]
            longest={}
            for j in outside:
                longest[j]=1+max([0]+[longest[a] for a in outside if a<j and masks[j]>>a&1])
            excluded.append(max([0]+list(longest.values()))-1 if outside else 0)
            aa=[]
            for n in range(2,len(ancestors[i])+1):
                for group in itertools.combinations(ancestors[i],n):
                    if all(not masks[b]>>a&1 for a,b in itertools.combinations(group,2)):
                        aa.append(group)
            antichains.append(aa)
        out.append((masks,ancestors,excluded,antichains))
    return out

def analyze(family,k,table):
    global checked
    L=family['individual_costs'];S=family['supports'];O=family['owners']
    for p in itertools.product(*(range(l-1,17) for l in L)):
        if len(set(p))<k:continue
        order=sorted(range(k),key=lambda i:p[i]);positions=[p[i] for i in order]
        costs=[L[i] for i in order];supports=[S[i] for i in order];owners=[O[i] for i in order]
        essential=[sum(1<<v for v in range(11) if s>>v&1 or N[v]&~s) for s in supports]
        irrelevant=[sum(1<<v for v in range(11) if not s>>v&1 and not N[v]&~s) for s in supports]
        allowed=[sum(1<<j for j in range(i) if any(t not in positions for t in range(positions[j]+1,positions[i]))) for i in range(k)]
        spare={(j,i):sum(t not in positions for t in range(positions[j]+1,positions[i])) for i in range(k) for j in range(i)}
        for masks,ancestors,excluded,antichains in table:
            checked+=1
            if checked%4096==0 and time.monotonic()-START>55:raise Limit
            if any(masks[i]&~allowed[i] for i in range(k)):continue
            if any(ancestors[i] and spare[(ancestors[i][0],i)]<len(ancestors[i]) for i in range(k)):continue
            lows=[];uppers=[];bad=False
            for i in range(k):
                owner_mask=0
                for j in ancestors[i]:owner_mask|=1<<owners[j]
                charge=(owner_mask&supports[i]).bit_count()
                raw=int(any(essential[j]&irrelevant[i] for j in ancestors[i]))
                lower=costs[i]+max(charge,raw)
                if ancestors[i]:lower=max(lower,max(lows[j]+2 for j in ancestors[i]))
                for group in antichains[i]:
                    lower=max(lower,max(lows[j] for j in group)+2*len(group))
                upper=positions[i]+1-(i-len(ancestors[i]))-excluded[i]
                if lower>upper:bad=True;break
                lows.append(lower);uppers.append(upper)
            if not bad:
                return dict(order=order,positions=positions,ancestry_masks=list(masks),lower=lows,upper=uppers)
    return None

results=[];unfinished=None
try:
    for k in (4,5):
        original=next(x for x in data['results'] if x['counts']['k']==k)
        families=[x for x in original['survivors'] if not x['pattern']['excluded']]
        table=posets(k)
        assert len(table)==(40 if k==4 else 357)
        records=[]
        for index,family in enumerate(families):
            unfinished=dict(k=k,index=index,supports=family['supports'])
            witness=analyze(family,k,table)
            records.append(dict(supports=family['supports'],individual_costs=family['individual_costs'],
                                owners=family['owners'],excluded=witness is None,abstract_pattern=witness))
        result=dict(k=k,starting_families=len(families),excluded=sum(r['excluded'] for r in records),
                    remaining=sum(not r['excluded'] for r in records),families=records,complete=True)
        results.append(result);unfinished=None
        print(json.dumps({k:result[k] for k in ('k','starting_families','excluded','remaining')}),flush=True)
except Limit:
    if 'records' in globals():
        results.append(dict(k=k,complete=False,families=records,completed_families=len(records)))

result=dict(verdict='COMPLETE_FINITE_POSITION_RELAXATION' if unfinished is None else 'UNKNOWN_TIME_LIMIT',
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    input_sha256=hashlib.sha256(P.read_bytes()).hexdigest(),
    elapsed_seconds=time.monotonic()-START,assignments_checked=checked,
    results=results,unfinished=unfinished,solver_run=False,Lean_proof=False,
    scope='Generalized selected-source component count and antichain union bounds pending independent review. Survivors are abstract necessary-condition patterns only.')
(ROOT/'four-five-position-filter.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('verdict','elapsed_seconds','assignments_checked','source_sha256')}),flush=True)
