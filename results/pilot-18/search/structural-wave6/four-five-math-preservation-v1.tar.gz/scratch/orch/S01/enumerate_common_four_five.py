#!/usr/bin/env python3
"""Complete small all-common-neighbor support census, with 55s ceiling."""
import hashlib
import itertools
import json
import time
from functools import lru_cache
from pathlib import Path

ROOT=Path(__file__).resolve().parent
START=time.monotonic()
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
   (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
EM=[(1<<a)|(1<<b) for a,b in E]
N=[sum(1<<(b if a==v else a) for a,b in E if v in(a,b)) for v in range(11)]
IND=[a for a in range(2048) if all(a&e!=e for e in EM)]
MIS=[a for a in IND if not any(a!=b and a&b==a for b in IND)]
ALL=(1<<24)-1
assert len(MIS)==24
@lru_cache(None)
def cover(edges):
    return min(c.bit_count() for c in range(2048) if all(c&e for e in edges))
def partial_cost(s,deleted=0):
    residual=tuple(e for e in EM if not (s|deleted)&e)
    return s.bit_count()+len(residual)+cover(residual)-1
pool=[]
for s in range(2047):
    owners=[v for v in range(11) if N[v]&s==s]
    if len(owners)!=1:continue
    cost=partial_cost(s)
    z=sum(1<<i for i,a in enumerate(MIS) if not a&s)
    if cost<=17 and z:pool.append(dict(s=s,cost=cost,owner=owners[0],z=z))
pool.sort(key=lambda r:(r['cost'],r['s']))
assert len(pool)==49

def one_spare_patterns(family):
    k=len(family);costs=[a['cost'] for a in family]
    if min(costs)<17-k:return dict(excluded=False,reason='BELOW_ONE_SPARE_THRESHOLD')
    if max(costs)<=18-k:return dict(excluded=False,reason='ANCESTRY_FREE_PATTERN')
    core=16-k
    feasible=[]
    for b in range(k):
        if costs[b]!=17-k:continue
        rest=[j for j in range(k) if j!=b]
        for choice in range(1,1<<(k-1)):
            children=[rest[t] for t in range(k-1) if choice>>t&1]
            if any(costs[j]!=17-k for j in rest if j not in children):continue
            partial=[];bad=False
            for j in children:
                if costs[j]+int(bool(family[j]['s']&(1<<family[b]['owner'])))>19-k:
                    bad=True;break
                if family[b]['s']&(1<<family[j]['owner']):
                    bad=True;break
                if family[b]['s']==N[family[b]['owner']]:
                    partial.append(partial_cost(family[j]['s'],1<<family[b]['owner']))
            if bad:continue
            if partial and any(p>cap for p,cap in zip(sorted(partial),range(core-len(partial),core))):
                continue
            feasible.append(dict(source=b,children=children,partial_operand_costs=partial))
    return dict(excluded=not feasible,
                reason='ALL_ONE_SPARE_PATTERNS_EXCLUDED' if not feasible else 'ONE_AND_STAR_REMAINS',
                feasible_patterns=feasible)

results=[];interrupted=None
for k in (3,4,5):
    counts=dict(k=k,combinations=0,slot_pass=0,coverage_pass=0,minimal_pass=0,joint_pass=0,
                one_spare_excluded=0,remaining=0)
    survivors=[]
    for family in itertools.combinations(pool,k):
        counts['combinations']+=1
        if counts['combinations']%8192==0 and time.monotonic()-START>55:
            interrupted=counts;break
        if any(a['cost']>cap for a,cap in zip(family,range(18-k,18))):continue
        counts['slot_pass']+=1
        union=0
        for a in family:union|=a['z']
        if union!=ALL:continue
        counts['coverage_pass']+=1
        minimal=True
        for i,a in enumerate(family):
            others=0
            for j,b in enumerate(family):
                if j!=i:others|=b['z']
            if not a['z']&~others:minimal=False;break
        if not minimal:continue
        # Minimal negative cover implies support incomparability; verify it.
        assert all(a['s']&b['s'] not in(a['s'],b['s']) for a,b in itertools.combinations(family,2))
        counts['minimal_pass']+=1
        owners=0
        for a in family:owners|=1<<a['owner']
        joint=[a['cost']+(a['s']&owners).bit_count() for a in family]
        if max(joint)>17:continue
        counts['joint_pass']+=1
        pattern=one_spare_patterns(family)
        counts['one_spare_excluded']+=int(pattern['excluded'])
        counts['remaining']+=int(not pattern['excluded'])
        survivors.append(dict(supports=[a['s'] for a in family],
                              individual_costs=[a['cost'] for a in family],
                              owners=[a['owner'] for a in family],joint_costs=joint,
                              pattern=pattern))
    results.append(dict(counts=counts,survivors=survivors,complete=interrupted is None))
    print(json.dumps(counts),flush=True)
    if interrupted is not None:break
    if k==3:
        assert counts['combinations']==18424 and counts['joint_pass']==515
        assert counts['one_spare_excluded']==233

result=dict(verdict='COMPLETE_FINITE_COMMON_NEIGHBOR_CENSUS' if interrupted is None else 'UNKNOWN_TIME_LIMIT',
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    elapsed_seconds=time.monotonic()-START,pool=pool,MIS=MIS,results=results,
    solver_run=False,Lean_proof=False,
    scope='Only all-common-neighbor factors r=0. Pattern proof for k4/k5 is a new generalization pending review. Survivors are not circuits.')
(ROOT/'common-four-five-enumeration.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'verdict':result['verdict'],'elapsed_seconds':result['elapsed_seconds'],'source_sha256':result['source_sha256']}))
