#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
P=ROOT/'common-four-five-enumeration.json'
r=json.loads(P.read_text())
assert r['verdict']=='COMPLETE_FINITE_COMMON_NEIGHBOR_CENSUS'
result=next(a for a in r['results'] if a['counts']['k']==5)
assert result['counts']['joint_pass']==331 and result['counts']['one_spare_excluded']==290
records=[]
for a in result['survivors']:
    if a['pattern']['excluded']:
        reason='ONE_SPARE_PATTERN'
    elif max(a['individual_costs'])>15:
        reason='TWO_SPARES_BOUND_15'
    else:
        low=[i for i,c in enumerate(a['individual_costs']) if c==11]
        owners=a['owners'];S=a['supports']
        if (max(a['individual_costs'])==15 and len(low)==1 and
            len(set(owners))==5 and any(i!=low[0] and S[low[0]]>>v&1 for i,v in enumerate(owners))):
            reason='UNIQUE_COST11_SOURCE_REVERSE_OWNER_CHARGE'
        else:reason='REMAINS'
    records.append(dict(supports=a['supports'],individual_costs=a['individual_costs'],
                        owners=a['owners'],reason=reason))
from collections import Counter
counts=dict(Counter(a['reason'] for a in records))
assert counts=={'ONE_SPARE_PATTERN':290,'TWO_SPARES_BOUND_15':35,
               'UNIQUE_COST11_SOURCE_REVERSE_OWNER_CHARGE':5,'REMAINS':1}
remaining=next(a for a in records if a['reason']=='REMAINS')
assert remaining['supports']==[417,560,1282,84,1160]
out=dict(verdict='FINITE_FIVE_FACTOR_COVERAGE_PENDING_MATH_REVIEW',counts=counts,
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    census_sha256=hashlib.sha256(P.read_bytes()).hexdigest(),
    mathematical_argument_sha256=hashlib.sha256((ROOT/'five-factor-two-spare-bound.md').read_bytes()).hexdigest(),
    remaining=remaining,families=records,solver_run=False,Lean_proof=False)
(ROOT/'five-factor-bound-validation.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'counts':counts,'remaining':remaining,'source_sha256':out['source_sha256']}))
