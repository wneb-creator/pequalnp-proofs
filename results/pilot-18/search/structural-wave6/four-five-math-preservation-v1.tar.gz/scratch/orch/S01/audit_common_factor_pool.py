#!/usr/bin/env python3
"""Independent complete support-pool check using maximum independent sets."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
P=ROOT/'common-four-five-enumeration.json'
r=json.loads(P.read_text())
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
   (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
EM=[(1<<a)|(1<<b) for a,b in E]
N=[sum(1<<(b if a==v else a) for a,b in E if v in(a,b)) for v in range(11)]
I=[a for a in range(2048) if not any(a&e==e for e in EM)]
MIS=[a for a in I if all(any((a|(1<<v))&e==e for e in EM) for v in range(11) if not a>>v&1)]
assert MIS==r['MIS'] and len(I)==125
expected={}
for s in range(2047):
    common=[v for v in range(11) if N[v]&s==s]
    if not common:continue
    m=sum(not s&e for e in EM)
    alpha=max(a.bit_count() for a in I if not a&s)
    tau=11-s.bit_count()-alpha
    cost=s.bit_count()+m+tau-1
    z=sum(1<<i for i,a in enumerate(MIS) if not a&s)
    if cost<=17 and z:
        assert len(common)==1 and s.bit_count()>=2
        expected[s]=dict(s=s,cost=cost,owner=common[0],z=z)
assert len(expected)==49 and {a['s']:a for a in r['pool']}==expected
families=0
for group in r['results']:
    k=group['counts']['k']
    for family in group['survivors']:
        S=family['supports'];rows=[expected[s] for s in S]
        assert len(S)==len(set(S))==k
        assert family['individual_costs']==[a['cost'] for a in rows]
        assert all(c<=cap for c,cap in zip(sorted(a['cost'] for a in rows),range(18-k,18)))
        zeros=[a['z'] for a in rows]
        union=0
        for z in zeros:union|=z
        assert union==(1<<24)-1
        for i,z in enumerate(zeros):
            others=0
            for j,w in enumerate(zeros):
                if i!=j:others|=w
            assert z&~others
        families+=1
out=dict(verdict='PASS_COMPLETE_49_SUPPORT_POOL_AND_RECORDED_MINIMAL_FAMILIES',
         source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         census_sha256=hashlib.sha256(P.read_bytes()).hexdigest(),
         support_masks_checked=2047,pool_size=49,recorded_families_checked=families,
         cover_method='tau=remaining_vertex_count-maximum_independent_set_size; independent of census exhaustive-cover routine',
         solver_run=False,Lean_proof=False)
(ROOT/'common-factor-pool-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
