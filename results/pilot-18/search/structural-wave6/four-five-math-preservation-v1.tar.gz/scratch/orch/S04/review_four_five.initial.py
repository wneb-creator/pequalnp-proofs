from pathlib import Path
import collections,functools,hashlib,itertools,json,time
O=Path('/tmp/oec/pequalnp-pilot-18/orch/S04');I=O.parent/'S01';START=time.monotonic()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def bounded():assert time.monotonic()-START<50,'scalar review exceeded 50 second bound'
expected={
 'common-four-five-enumeration.json':'97a162256ab546260c85602dde0a2fe8632e90830bfadfde206a43fba069f589',
 'enumerate_common_four_five.py':'92b9f4c8caee05184403ee054657e61c15d99bf1c9e2c563c8b0e478dbdf27bb',
 'five-factor-bound-validation.json':'6ac8705596b10f16a30fa6b24e60f8cf731ae1904ced5f590436ccf77f177272',
 'check_five_factor_bound.py':'a8622180b24982aedfdf8d6c0a00cdab207877ad8c915526477f15bfcfb38f85',
 'five-factor-two-spare-bound.md':'18f85d2797a8d83bbde12d9d7a1d8ba5413db30d835f1b75b497379e2336fa24',
 'filter_four_five_positions.py':'7d883996bc9c568aa8c402020661a4aae3b9eea88549e7bc73769e120897e74b'}
for name,digest in expected.items():assert sha(I/name)==digest,name
census=json.loads((I/'common-four-five-enumeration.json').read_text())
positions=json.loads((I/'four-five-position-filter.json').read_text())
five=json.loads((I/'five-factor-bound-validation.json').read_text())
assert positions['source_sha256']==expected['filter_four_five_positions.py'] and positions['input_sha256']==expected['common-four-five-enumeration.json']
assert census['source_sha256']==expected['enumerate_common_four_five.py']
assert five['source_sha256']==expected['check_five_factor_bound.py'] and five['census_sha256']==expected['common-four-five-enumeration.json'] and five['mathematical_argument_sha256']==expected['five-factor-two-spare-bound.md']
expected['four-five-position-filter.json']=sha(I/'four-five-position-filter.json')
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
EM=[(1<<a)|(1<<b) for a,b in E]
N=[sum(1<<(a if b==v else b) for a,b in E if v in (a,b)) for v in range(11)]
ind=[s for s in range(2048) if all(s&e!=e for e in EM)]
mis=[s for s in ind if all((s|(1<<v)) not in ind for v in range(11) if not s>>v&1)]
assert len(ind)==125 and len(mis)==24 and mis==census['MIS']
# Minimum covers are computed by an edge-branching recurrence, independent of
# the producer's scan over all 2048 vertex subsets.
@functools.lru_cache(None)
def cover(edges):
 if not edges:return 0
 a,b=next((a,b) for a,b in E if ((1<<a)|(1<<b))==edges[0])
 return 1+min(cover(tuple(e for e in edges if not e>>v&1)) for v in (a,b))
@functools.lru_cache(None)
def cost(s,deleted=0):
 edges=tuple(e for e in EM if not e&(s|deleted))
 return s.bit_count()+len(edges)+cover(edges)-1
pool=[]
for s in range(2047):
 owners=[v for v in range(11) if s&~N[v]==0]
 z=sum(1<<i for i,m in enumerate(mis) if not m&s)
 if owners and cost(s)<=17 and z:
  assert len(owners)==1 and s.bit_count()>=2
  pool.append({'s':s,'owner':owners[0],'cost':cost(s),'z':z})
pool.sort(key=lambda r:(r['cost'],r['s']))
assert pool==census['pool'] and len(pool)==49 and min(r['cost'] for r in pool)==11

def star_patterns(fam):
 k=len(fam);c=[r['cost'] for r in fam];s=[r['s'] for r in fam];v=[r['owner'] for r in fam]
 if min(c)<17-k:return False,[]
 if max(c)<=18-k:return False,[]
 good=[]
 for source in range(k):
  for childmask in range(1,1<<k):
   if childmask>>source&1 or c[source]!=17-k:continue
   children=[j for j in range(k) if childmask>>j&1]
   if any(c[j]!=17-k for j in range(k) if j!=source and j not in children):continue
   if any(c[j]+int(bool(s[j]>>v[source]&1))>19-k or s[source]>>v[j]&1 for j in children):continue
   partial=[]
   if s[source]==N[v[source]]:
    partial=[cost(s[j],1<<v[source]) for j in children]
    # Match distinct operands to permissible core positions by a bipartite
    # assignment, not the producer's sorted-capacity comparison.
    slots=list(range(16-k))[:-1]
    if not any(all(p<=slot+1 for p,slot in zip(partial,assignment)) for assignment in itertools.permutations(slots,len(partial))):continue
   good.append((source,tuple(children),tuple(partial)))
 return not good,good

all_records={};finite_summary=[];allmis=(1<<24)-1
for entry in census['results']:
 k=entry['counts']['k'];assert entry['complete']
 old={tuple(r['supports']):r for r in entry['survivors']}
 count=dict(k=k,combinations=0,slot_pass=0,coverage_pass=0,minimal_pass=0,joint_pass=0,one_spare_excluded=0,remaining=0)
 found={}
 for fam in itertools.combinations(pool,k):
  count['combinations']+=1
  if count['combinations']%16384==0:bounded()
  if any(r['cost']+k-j>18 for j,r in enumerate(fam)):continue
  count['slot_pass']+=1
  zero_masks=[r['z'] for r in fam]
  joined=functools.reduce(int.__or__,zero_masks,0)
  if joined!=allmis:continue
  count['coverage_pass']+=1
  if any(functools.reduce(int.__or__,zero_masks[:j]+zero_masks[j+1:],0)==allmis for j in range(k)):continue
  count['minimal_pass']+=1
  supports=tuple(r['s'] for r in fam);owners=tuple(r['owner'] for r in fam)
  assert all((a&b)!=a and (a&b)!=b for a,b in itertools.combinations(supports,2))
  joint=[r['cost']+len({u for u in owners if r['s']>>u&1}) for r in fam]
  if max(joint)>17:continue
  count['joint_pass']+=1
  excluded,patterns=star_patterns(fam)
  count['one_spare_excluded']+=excluded;count['remaining']+=not excluded
  r=old[supports]
  assert r['individual_costs']==[a['cost'] for a in fam] and r['owners']==list(owners) and r['joint_costs']==joint
  assert r['pattern']['excluded']==excluded
  if 'feasible_patterns' in r['pattern']:
   assert set(patterns)=={(a['source'],tuple(a['children']),tuple(a['partial_operand_costs'])) for a in r['pattern']['feasible_patterns']}
  found[supports]={'supports':list(supports),'individual_costs':[a['cost'] for a in fam],'owners':list(owners),'one_spare_excluded':excluded}
 assert count==entry['counts'] and set(found)==set(old),(k,count,entry['counts'])
 finite_summary.append(count);all_records[k]=found
 print(json.dumps({'census_checked':count}),flush=True)

def relation_table(k):
 pairs=list(itertools.combinations(range(k),2));out=[]
 for bits in range(1<<len(pairs)):
  anc=[set() for _ in range(k)]
  for t,(a,b) in enumerate(pairs):
   if bits>>t&1:anc[b].add(a)
  if any(not anc[j]<=anc[i] for i in range(k) for j in anc[i]):continue
  antichains=[];outside_chains=[]
  for i in range(k):
   groups=[]
   for mask in range(1<<i):
    group={j for j in range(i) if mask>>j&1}
    if len(group)>=2 and group<=anc[i] and all(a not in anc[b] and b not in anc[a] for a,b in itertools.combinations(group,2)):groups.append(group)
   antichains.append(groups)
   outside=set(range(i))-anc[i];longest=0
   for size in range(len(outside)+1):
    for chain in itertools.combinations(sorted(outside),size):
     if all(a in anc[b] for a,b in itertools.combinations(chain,2)):longest=max(longest,size)
   outside_chains.append(max(0,longest-1))
  out.append((anc,antichains,outside_chains))
 assert len(out)=={4:40,5:357}[k]
 return out
checks=0
def assess(fam,positions,table_record):
 global checks
 checks+=1
 if checks%16384==0:bounded()
 anc,antichains,removed=table_record;k=len(fam);occupied=set(positions)
 lower=[];upper=[]
 for i in range(k):
  for j in anc[i]:
   if not any(t not in occupied for t in range(positions[j]+1,positions[i])):return None
  if anc[i] and sum(t not in occupied for t in range(positions[min(anc[i])]+1,positions[i]))<len(anc[i]):return None
  support=fam[i][0];base=fam[i][1]
  owner_charge=len({fam[j][2] for j in anc[i] if support>>fam[j][2]&1})
  raw_charge=any(not support>>v&1 and N[v]&~support==0 and any(fam[j][0]>>v&1 or N[v]&~fam[j][0] for j in anc[i]) for v in range(11))
  lo=base+max(owner_charge,int(raw_charge))
  for j in anc[i]:lo=max(lo,lower[j]+2)
  for group in antichains[i]:lo=max(lo,max(lower[j] for j in group)+2*len(group))
  hi=positions[i]+1-(i-len(anc[i]))-removed[i]
  if lo>hi:return None
  lower.append(lo);upper.append(hi)
 return lower,upper

position_results=[]
for entry in positions['results']:
 k=entry['k'];assert entry['complete'];table=relation_table(k)
 records=[]
 for old in entry['families']:
  supports=tuple(old['supports']);r=all_records[k][supports];assert not r['one_spare_excluded']
  original=list(zip(r['supports'],r['individual_costs'],r['owners']))
  witness=old['abstract_pattern']
  if witness is not None:
   fam=[original[j] for j in witness['order']]
   matching=next(t for t in table if [sum(1<<j for j in a) for a in t[0]]==witness['ancestry_masks'])
   assert assess(fam,witness['positions'],matching)==(witness['lower'],witness['upper'])
  # Reverse position traversal and independently enumerated edge relations.
  found=None
  for p in itertools.product(*(range(16,cost-2,-1) for _,cost,_ in original)):
   if len(set(p))!=k:continue
   order=sorted(range(k),key=lambda j:p[j]);ps=[p[j] for j in order];fam=[original[j] for j in order]
   for relation in reversed(table):
    verdict=assess(fam,ps,relation)
    if verdict is not None:
     found={'order':order,'positions':ps,'ancestry_masks':[sum(1<<j for j in a) for a in relation[0]],'lower':verdict[0],'upper':verdict[1]};break
   if found:break
  assert (found is None)==old['excluded'],(k,supports,found,old)
  records.append({'supports':list(supports),'excluded':found is None,'independent_witness':found})
 assert len(records)==entry['starting_families'] and sum(r['excluded'] for r in records)==entry['excluded']
 position_results.append({'k':k,'starting_families':len(records),'excluded':sum(r['excluded'] for r in records),'remaining':sum(not r['excluded'] for r in records),'families':records})
 print(json.dumps({key:value for key,value in position_results[-1].items() if key!='families'}),flush=True)

five_records=[]
for old in five['families']:
 r=all_records[5][tuple(old['supports'])];S=r['supports'];C=r['individual_costs'];V=r['owners']
 if r['one_spare_excluded']:reason='ONE_SPARE_PATTERN'
 elif max(C)>15:reason='TWO_SPARES_BOUND_15'
 elif C.count(11)==1 and max(C)==15 and len(set(V))==5 and any(j!=C.index(11) and S[C.index(11)]>>V[j]&1 for j in range(5)):reason='UNIQUE_COST11_SOURCE_REVERSE_OWNER_CHARGE'
 else:reason='REMAINS'
 assert old=={'supports':S,'individual_costs':C,'owners':V,'reason':reason}
 five_records.append(old)
counts=dict(collections.Counter(r['reason'] for r in five_records));assert counts==five['counts']
remaining=[r for r in five_records if r['reason']=='REMAINS'];assert len(remaining)==1 and remaining[0]==five['remaining']
assert {tuple(r['supports']) for r in position_results[1]['families'] if not r['excluded']}=={tuple(remaining[0]['supports'])}
result={'verdict':'PASS_K4_K5_MATH_FINITE_CENSUS_POSITION_RELAXATION_AND_FIVE_FACTOR_BOUND','source_sha256':sha(Path(__file__)),'producer_bindings':expected,'census':finite_summary,'position_assignments_checked':checks,'position_results':position_results,'five_factor_counts':counts,'five_factor_records':five_records,'five_factor_remaining':remaining[0],'seconds':time.monotonic()-START,'solver_run':False,'Lean_build':False,'scope':'Minimal proper full-cover all-common-neighbor families in17-gate productive clean prefixes only. k4 retains115 abstract patterns; k5 retains1. No circuit realization, r>0 coverage, actual CNF cut or global/Lean claim.'}
(O/'four-five-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key not in ['position_results','five_factor_records','producer_bindings']},indent=2))
