from pathlib import Path
import json,hashlib,tarfile,gzip,io,datetime
R=Path('/workspace/pequalnp-proofs');S=Path('/tmp/oec/pequalnp-pilot-18');O=S/'orch/S04';I=S/'orch/S01';P=O/'three-factor-classification-preservation-v1'
P.mkdir(exist_ok=False)
handoff=I/'three-factor-classification-handoff.json';h=json.loads(handoff.read_text())
assert hashlib.sha256(handoff.read_bytes()).hexdigest()=='9a48bf0acf8e5aca20a6bda737506b33897e13841f9b5577aee06188822c3f7e'
files=[handoff]
for row in h['files']:
 p=Path(row['path']);raw=p.read_bytes();assert p.is_relative_to(I) and not p.is_symlink()
 assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'];files.append(p)
files += [I/'joint-factor-cost.md',I/'tight-survivor-obstruction.md',O/'joint-enumeration-review.json',R/'results/orch/lemmas/S04-redteam.md']
files += [O/n for n in ['review_three_factor_classification.py','three-factor-classification-review.json','three-factor-classification-review.stdout.log','three-factor-classification-review.stderr.log','preserve_three_factor_review.py']]
records=[]
for p in files:
 assert p.is_file() and not p.is_symlink() and p.suffix!='.cnf'
 raw=p.read_bytes();rel=Path('repo')/p.relative_to(R) if p.is_relative_to(R) else Path('scratch')/p.relative_to(S)
 q=P/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw)
 records.append(dict(source_path=str(p),archive_path=str(rel),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
readme='''# Independent three-factor classification review

PASS:253 of the supplied515 minimal k3/r0 full-cover support families are
excluded from a productive clean prefix of at most17 gates;262 remain.
The one-spare-late-AND proof excludes233; the independent position filter
excludes199, with20 new, so the union is253. Every original handoff binding,
family decision and saved abstract witness passes independent review.

The S04 scalar script uses a different complete traversal:57560 position/
relation assignments,9007 abstract feasible models,1545 pair truth-function
checks,0.27seconds. S01's13927 count reflects first-witness early exits.
No solver or Lean ran; no raw CNF is archived. The complete input515 list,
original11-file handoff, proof dependencies, both source/result/log sets,
and S04's final report are included.

The one-spare-AND proof assumes all three individual costs are at least14;
other families receive only separately justified position conditions.
The position filter must use max(owner charge, raw-input bit), not their
sum, since the deleted gates may overlap. Partial/non-full-cover selected
wires do not inherit these family exclusions. The final report supplies
all hypotheses and explains safe scope for future finite or generic cuts.
A cut implementation needs a separate source/clause/projection review.

The metadata label pure_singleton_OR means F OR OR(intersection), not a
standalone linear OR; the exclusion filters do not use it. The262 retained
patterns are necessary-condition witnesses, not circuits. There is no
claim covering r>0, k4/k5, larger/dirty prefixes, whole AAAA exhaustion,
UNSAT certification, or Lean acceptance. The proposed +2 extension is not
included or reviewed here. The previous archives remain unchanged.

repo/ and scratch/ mirror the authorized original roots. Historical scripts
and logs retain their original paths. SHA-bound original sources are not
modified to accommodate an extraction location.
'''
(P/'README.md').write_text(readme);records.append(dict(source_path='generated preservation README',archive_path='README.md',bytes=len(readme.encode()),sha256=hashlib.sha256(readme.encode()).hexdigest()))
manifest=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Independent generic-proof and supplied515-family finite classification PASS;253excluded/262abstract survivors, no exhaustion or implemented cut.',raw_CNF_count=0,files=records)
(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=O/'three-factor-classification-preservation-v1.tar.gz'
with archive.open('wb') as stream,gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for p in sorted(P.rglob('*')):
  if not p.is_file():continue
  raw=p.read_bytes();info=tarfile.TarInfo(P.name+'/'+str(p.relative_to(P)));info.size=len(raw);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(records)+1
 for member in members:
  assert member.isfile() and '..' not in Path(member.name).parts
  assert tar.extractfile(member).read()==(P/member.name.removeprefix(P.name+'/')).read_bytes()
result=dict(verdict='PASS_CLASSIFICATION_REVIEW_PRESERVATION',archive=str(archive),archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),archive_bytes=archive.stat().st_size,regular_members=len(records)+1,manifest_sha256=hashlib.sha256((P/'manifest.json').read_bytes()).hexdigest(),review_sha256=hashlib.sha256((O/'three-factor-classification-review.json').read_bytes()).hexdigest(),scope=manifest['scope'])
(O/'three-factor-classification-preservation-handoff.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
