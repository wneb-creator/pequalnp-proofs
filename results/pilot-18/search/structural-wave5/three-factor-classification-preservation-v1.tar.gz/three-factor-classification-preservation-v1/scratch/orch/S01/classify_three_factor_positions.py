#!/usr/bin/env python3
"""Necessary position/ancestry conditions for fixed triples; no solver."""
import hashlib
import itertools
import json
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PARENT=ROOT/'three-common-factor-classification.json'
EXPECTED='00269c8a022423fe72d9e2a5bb3c6c584c89b315919bbd84af55dcc02d85f3f8'
assert hashlib.sha256(PARENT.read_bytes()).hexdigest()==EXPECTED
data=json.loads(PARENT.read_text())
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
   (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
N=[sum(1<<(b if a==v else a) for a,b in E if v in(a,b)) for v in range(11)]
started=time.monotonic()
total_assignments=0
records=[]

for family in data['families']:
    S=family['supports'];L=family['individual_costs'];O=family['owners']
    irrelevant=[sum(1<<v for v in range(11) if not s>>v&1 and N[v]&~s==0) for s in S]
    essential=[sum(1<<v for v in range(11) if s>>v&1 or N[v]&~s) for s in S]
    example=None
    counts={}
    def reject(reason):
        counts[reason]=counts.get(reason,0)+1
    for positions in itertools.product(*(range(l-1,17) for l in L)):
        if len(set(positions))<3:
            continue
        pairs=[(a,b) for a in range(3) for b in range(3) if positions[a]<positions[b]]
        assert len(pairs)==3
        for flags in itertools.product((False,True),repeat=3):
            total_assignments+=1
            anc=[[False]*3 for _ in range(3)]
            for (a,b),flag in zip(pairs,flags):anc[a][b]=flag
            if any(anc[a][b] and anc[b][c] and not anc[a][c]
                   for a,b,c in itertools.permutations(range(3))):
                reject('TRANSITIVITY');continue
            bad=False
            for a,b in pairs:
                if anc[a][b] and not any(t not in positions for t in range(positions[a]+1,positions[b])):
                    reject('NO_INTERVENING_AND_SLOT');bad=True;break
            if bad:continue
            for i in range(3):
                sources=[j for j in range(3) if anc[j][i]]
                if len(sources)==2:
                    earliest=min(positions[j] for j in sources)
                    spare=sum(t not in positions for t in range(earliest+1,positions[i]))
                    if spare<2:
                        reject('TWO_ANCESTORS_REQUIRE_TWO_SPARE_GATES');bad=True;break
            if bad:continue
            bounds=[]
            for i in range(3):
                outside=[j for j in range(3) if positions[j]<positions[i] and not anc[j][i]]
                # With three outputs there is at most one other ordered pair.
                excluded_and=int(any(anc[a][b] and positions[b]<positions[i] and not anc[a][i]
                                     for a,b in pairs if i not in(a,b)))
                upper=positions[i]+1-len(outside)-excluded_and
                owners=0
                for j in range(3):
                    if anc[j][i]:owners|=1<<O[j]
                joint=(owners&S[i]).bit_count()
                raw=int(any(anc[j][i] and essential[j]&irrelevant[i] for j in range(3)))
                lower=L[i]+max(joint,raw)
                bounds.append(dict(output=i,lower=lower,upper=upper,
                                   excluded_selected=outside,excluded_AND=excluded_and,
                                   owner_charges=joint,raw_input_charge=raw))
                if lower>upper:
                    reject('ANCESTOR_CONE_BUDGET');bad=True;break
            if bad:continue
            example=dict(positions=list(positions),ancestry=anc,cone_bounds=bounds)
            break
        if example is not None:break
    positional_excluded=example is None
    records.append(dict(supports=S,individual_costs=L,owners=O,
                        positional_excluded=positional_excluded,
                        previously_excluded=family['excluded'],
                        combined_excluded=positional_excluded or family['excluded'],
                        rejecting_assignments_by_reason=counts,
                        remaining_abstract_pattern=example))
result=dict(verdict='NECESSARY_POSITION_PATTERN_FILTER_PENDING_REVIEW',
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),input_sha256=EXPECTED,
    summary=dict(total=515,prior_excluded=sum(r['previously_excluded'] for r in records),
      positional_excluded=sum(r['positional_excluded'] for r in records),
      newly_excluded=sum(r['positional_excluded'] and not r['previously_excluded'] for r in records),
      combined_excluded=sum(r['combined_excluded'] for r in records),
      remaining=sum(not r['combined_excluded'] for r in records),
      assignments_tested=total_assignments,elapsed_seconds=time.monotonic()-started),
    families=records,solver_run=False,Lean_proof=False,
    caveat='Only necessary conditions on positions and selected ancestry; remaining patterns need not admit circuits. Not an AAAA exhaustion result.')
(ROOT/'three-factor-position-classification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['summary']))
print(json.dumps({'source_sha256':result['source_sha256']}))
