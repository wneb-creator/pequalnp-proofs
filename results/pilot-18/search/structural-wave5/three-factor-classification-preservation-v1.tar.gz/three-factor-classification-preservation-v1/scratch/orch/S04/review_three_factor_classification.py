from pathlib import Path
import hashlib,itertools,json,time,collections
O=Path('/tmp/oec/pequalnp-pilot-18/orch/S04');I=O.parent/'S01';start=time.monotonic()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
handoff=I/'three-factor-classification-handoff.json';h=json.loads(handoff.read_text())
assert sha(handoff)=='9a48bf0acf8e5aca20a6bda737506b33897e13841f9b5577aee06188822c3f7e'
for row in h['files']:
 p=Path(row['path']);assert p.is_relative_to(I) and p.is_file() and not p.is_symlink()
 assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
assert len(h['files'])==11
original=O/'joint-enumeration-review.json';assert sha(original)=='88e668c2c060ffe4efc40c849a7aac11573c4542191bba5b090f9d8489df1017'
base=json.loads(original.read_text())['survivors']
star_report=json.loads((I/'three-common-factor-classification.json').read_text())
pos_report=json.loads((I/'three-factor-position-classification.json').read_text())
assert len(base)==len(star_report['families'])==len(pos_report['families'])==515
E={(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)}
EM=sorted((1<<a)|(1<<b) for a,b in E)
N=[{b if a==v else a for a,b in E if v in(a,b)} for v in range(11)]
cover_order=sorted(range(2048),key=lambda c:(c.bit_count(),c));cover_cache={}
def cost(s,omit=set()):
 edges=tuple(e for e in EM if not e&s and not any(e>>v&1 for v in omit))
 if edges not in cover_cache:cover_cache[edges]=next(c for c in cover_order if all(c&e for e in edges))
 return s.bit_count()+len(edges)+cover_cache[edges].bit_count()-1
sets={s:{v for v in range(11) if s>>v&1} for f in base for s in f['supports']}
owners={s:next(v for v,n in enumerate(N) if sets[s]<=n) for s in sets}
for s in sets:assert sum(sets[s]<=n for n in N)==1
F=sum(1<<x for x in range(2048) if any(x&e==e for e in EM))
linear={s:sum(1<<x for x in range(2048) if x&s) for s in set(sets)|{a&b for f in base for a,b in itertools.combinations(f['supports'],2)}}
values={s:F|linear[s] for s in sets}
rows=[];all_position_models=0;all_position_assignments=0;pair_checks=0;star_models=0
for original_row,oldstar,oldpos in zip(base,star_report['families'],pos_report['families']):
 masks=original_row['supports'];S=[sets[s] for s in masks];L=[cost(s) for s in masks];owner=[owners[s] for s in masks]
 assert masks==oldstar['supports']==oldpos['supports']
 assert L==original_row['individual_costs']==oldstar['individual_costs']==oldpos['individual_costs']
 assert owner==oldstar['owners']==oldpos['owners']
 assert all(any(not e&s for e in EM) for s in masks), 'owner charges require residual nonempty'
 assert values[masks[0]]&values[masks[1]]&values[masks[2]]==F
 for i,j in itertools.combinations(range(3),2):
  assert values[masks[i]]&values[masks[j]]!=F
  common=S[i]&S[j]
  bad=sorted({tuple(sorted((a,b))) for a in S[i]-common for b in S[j]-common if tuple(sorted((a,b))) not in E})
  rec=next(p for p in oldstar['pair_features'] if p['factor_indices']==[i,j])
  assert rec['singleton_mask']==masks[i]&masks[j] and rec['independent_pair_terms']==[list(e) for e in bad]
  pure=(values[masks[i]]&values[masks[j]])==(F|linear[masks[i]&masks[j]])
  assert rec['pure_singleton_OR']==pure==(not bad);pair_checks+=1
 # Independent predicate for the ancestry-free alternative and all9 one-AND stars.
 feasible_stars=[];star_decisions=[]
 for b in range(3):
  rest=set(range(3))-{b}
  for size in (1,2):
   for child_tuple in itertools.combinations(sorted(rest),size):
    children=set(child_tuple);nonchildren=rest-children
    source_ok=L[b]==14
    nonchild_ok=all(L[a]==14 for a in nonchildren)
    child_cap_ok=all(L[c]+(owner[b] in S[c])<=16 for c in children)
    source_charge_ok=all(owner[c] not in S[b] for c in children)
    p_costs=[cost(masks[c],{owner[b]}) for c in child_tuple] if S[b]==N[owner[b]] else []
    p_ok=all(v<=12 for v in p_costs) and not(len(p_costs)==2 and all(v>=12 for v in p_costs))
    ok=source_ok and nonchild_ok and child_cap_ok and source_charge_ok and p_ok
    if ok:feasible_stars.append((b,child_tuple));star_models+=1
    star_decisions.append(dict(source=b,children=list(child_tuple),passes=ok,partial_costs=p_costs))
 star_excluded=min(L)>=14 and max(L)>15 and not feasible_stars
 assert star_excluded==oldstar['excluded'],masks
 if min(L)>=14 and max(L)>15:
  old_remaining={(p['source'],tuple(p['children'])) for p in oldstar['remaining_patterns']}
  assert old_remaining==set(feasible_stars)
 # Exhaustively inspect every temporal ordering, position triple and transitive relation.
 # The traversal order differs from S01; no early exit is taken on surviving families.
 irrelevant=[set(range(11))-S[i] for i in range(3)]
 irrelevant=[{v for v in irrelevant[i] if N[v]<=S[i]} for i in range(3)]
 essential=[S[i]|{v for v in range(11) if N[v]-S[i]} for i in range(3)]
 def valid(p,relation):
  if any((a,c) not in relation for a,b in relation for b2,c in relation if b==b2):return False
  occupied=set(p)
  if any(not(set(range(p[a]+1,p[b]))-occupied) for a,b in relation):return False
  for i in range(3):
   predecessors={j for j in range(3) if (j,i) in relation}
   if len(predecessors)==2:
    if len(set(range(min(p[j] for j in predecessors)+1,p[i]))-occupied)<2:return False
   excluded={j for j in range(3) if p[j]<p[i] and (j,i) not in relation}
   extra=any(a!=i and b!=i and p[b]<p[i] and (a,i) not in relation for a,b in relation)
   upper=p[i]+1-len(excluded)-extra
   d=len({owner[j] for j in predecessors}&S[i])
   raw=bool(set().union(*(essential[j] for j in predecessors))&irrelevant[i]) if predecessors else False
   lower=L[i]+max(d,raw)
   if lower>upper:return False
  return True
 models=[]
 for ordered_positions in itertools.combinations(range(min(L)-1,17),3):
  for order in itertools.permutations(range(3)):
   p=[None]*3
   for i,t in zip(order,ordered_positions):p[i]=t
   if any(p[i]<L[i]-1 for i in range(3)):continue
   temporals=list(itertools.combinations(order,2))
   for bitmask in range(8):
    all_position_assignments+=1
    relation={edge for n,edge in enumerate(temporals) if bitmask>>n&1}
    if valid(p,relation):models.append((tuple(p),tuple(sorted(relation))))
 all_position_models+=len(models)
 pos_excluded=not models
 assert pos_excluded==oldpos['positional_excluded'],masks
 witness=oldpos['remaining_abstract_pattern']
 if witness is not None:
  p=tuple(witness['positions']);a=witness['ancestry'];relation={(i,j) for i in range(3) for j in range(3) if a[i][j]}
  assert (p,tuple(sorted(relation))) in set(models)
  for bound in witness['cone_bounds']:
   i=bound['output'];pred={j for j in range(3) if (j,i) in relation}
   outside=sorted(j for j in range(3) if p[j]<p[i] and (j,i) not in relation)
   extra=int(any(a!=i and b!=i and p[b]<p[i] and (a,i) not in relation for a,b in relation))
   joint=len({owner[j] for j in pred}&S[i]);raw=int(any(essential[j]&irrelevant[i] for j in pred))
   assert bound==dict(output=i,lower=L[i]+max(joint,raw),upper=p[i]+1-len(outside)-extra,excluded_selected=outside,excluded_AND=extra,owner_charges=joint,raw_input_charge=raw)
 combined=star_excluded or pos_excluded;assert combined==oldpos['combined_excluded']
 rows.append(dict(supports=masks,individual_costs=L,owners=owner,star_excluded=star_excluded,positional_excluded=pos_excluded,combined_excluded=combined,all_abstract_position_models=len(models),remaining_S01_witness_valid=(witness is not None),star_patterns=star_decisions))
summary=dict(total=len(rows),star_excluded=sum(r['star_excluded'] for r in rows),positional_excluded=sum(r['positional_excluded'] for r in rows),newly_excluded=sum(r['positional_excluded'] and not r['star_excluded'] for r in rows),combined_excluded=sum(r['combined_excluded'] for r in rows),remaining=sum(not r['combined_excluded'] for r in rows),all_position_assignments=all_position_assignments,all_abstract_position_models=all_position_models,pair_functions_checked=pair_checks)
assert [summary[k] for k in ['star_excluded','positional_excluded','newly_excluded','combined_excluded','remaining']]==[233,199,20,253,262]
result=dict(verdict='PASS_GENERIC_PROOFS_AND_COMPLETE_SUPPLIED_FAMILY_CLASSIFICATION',review_source_sha256=sha(Path(__file__)),handoff_sha256=sha(handoff),handoff_artifacts_verified=11,supplied_515_families_sha256=sha(original),summary=summary,families=rows,seconds=time.monotonic()-start,scope='Only supplied515 minimal k3/r0 full-cover support families in a17-gate productive clean prefix. Remaining abstract patterns are not circuits; no r>0 or k4/k5/global exhaustion. No cut implementation reviewed.',solver_run=False,Lean_build=False)
(O/'three-factor-classification-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['verdict','review_source_sha256','handoff_artifacts_verified','seconds']}))
print(json.dumps(summary))
