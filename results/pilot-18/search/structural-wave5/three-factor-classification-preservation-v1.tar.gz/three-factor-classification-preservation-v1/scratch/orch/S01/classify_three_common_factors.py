#!/usr/bin/env python3
"""Finite coverage of the one-extra-late-gate obstruction, no solver."""
import hashlib
import itertools
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'S04/joint-enumeration-review.json'
EXPECTED='88e668c2c060ffe4efc40c849a7aac11573c4542191bba5b090f9d8489df1017'
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==EXPECTED
review=json.loads(SOURCE.read_text())
assert len(review['survivors'])==515
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
   (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
EM=[(1<<a)|(1<<b) for a,b in E]
N=[sum(1<<(b if a==v else a) for a,b in E if v in(a,b)) for v in range(11)]
ind=[x for x in range(2048) if all(x&e!=e for e in EM)]
cover_cache={}
def cover(edges):
    key=tuple(edges)
    if key not in cover_cache:
        cover_cache[key]=min(c.bit_count() for c in range(2048) if all(c&e for e in edges))
    return cover_cache[key]
def partial_cost(s,deleted=0):
    edges=[e for e in EM if not (s|deleted)&e]
    return s.bit_count()+len(edges)+cover(edges)-1
def owner(s):
    out=[v for v in range(11) if N[v]&s==s]
    assert len(out)==1
    return out[0]

records=[]
for family in review['survivors']:
    S=family['supports'];L=family['individual_costs'];O=[owner(s) for s in S]
    assert L==[partial_cost(s) for s in S]
    pair_features=[]
    for a,b in itertools.combinations(range(3),2):
        intersection=S[a]&S[b]
        bad=[]
        for u in range(11):
            for v in range(u+1,11):
                e=(1<<u)|(1<<v)
                if not e&intersection and e&S[a] and e&S[b] and (u,v) not in E:
                    bad.append([u,v])
        pair_features.append(dict(factor_indices=[a,b],singleton_mask=intersection,
                                  independent_pair_terms=bad,
                                  pure_singleton_OR=(not bad)))
    record=dict(supports=S,individual_costs=L,owners=O,pair_features=pair_features)
    if min(L)<14:
        record.update(excluded=False,reason='OUTSIDE_MIN14_HYPOTHESES')
    elif max(L)<=15:
        record.update(excluded=False,reason='ANCESTRY_FREE_PATTERN_NOT_EXCLUDED')
    else:
        candidates=[]
        for source in range(3):
            rest=[i for i in range(3) if i!=source]
            for subset in (1,2,3):
                children=[rest[j] for j in range(2) if subset>>j&1]
                failures=[]
                if L[source]!=14:
                    failures.append('SOURCE_CONE_CAPACITY14')
                for i in rest:
                    if i not in children and L[i]>14:
                        failures.append(f'NONCHILD_{i}_CONE_CAPACITY14')
                p_costs=[]
                for child in children:
                    charged=int(bool(S[child]&(1<<O[source])))
                    if L[child]+charged>16:
                        failures.append(f'CHILD_{child}_CONE_CAPACITY16_WITH_CHARGE')
                    if S[source]&(1<<O[child]):
                        failures.append(f'CHILD_{child}_OPERAND_CHARGES_SOURCE')
                    if S[source]==N[O[source]]:
                        p=partial_cost(S[child],1<<O[source])
                        p_costs.append(p)
                        if p>=13:
                            failures.append(f'CHILD_{child}_PARTIAL_OPERAND_TOO_LATE_{p}')
                if len(p_costs)==2 and min(p_costs)>=12:
                    failures.append('TWO_DISTINCT_PARTIAL_OPERANDS_COST12_FORCE_GATE12')
                candidates.append(dict(source=source,children=children,
                                       partial_operand_costs=p_costs,failures=failures))
        feasible=[c for c in candidates if not c['failures']]
        record.update(excluded=not feasible,
                      reason='ALL_ONE_AND_STARS_EXCLUDED' if not feasible else 'ONE_AND_STAR_REMAINS',
                      candidate_patterns=candidates,remaining_patterns=feasible)
    records.append(record)

known=next(r for r in records if set(r['supports'])=={80,1280,1536})
assert known['excluded']
from collections import Counter
summary=dict(total=515,excluded=sum(r['excluded'] for r in records),
             remaining=sum(not r['excluded'] for r in records),
             reasons=dict(Counter(r['reason'] for r in records)),
             families_with_pure_singleton_pair=sum(any(p['pure_singleton_OR'] for p in r['pair_features']) for r in records),
             remaining_with_pure_singleton_pair=sum(not r['excluded'] and any(p['pure_singleton_OR'] for p in r['pair_features']) for r in records))
result=dict(verdict='FINITE_PATTERN_COVERAGE_CONDITIONAL_ON_MATHEMATICAL_LEMMAS',
            source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            input_sha256=EXPECTED,summary=summary,families=records,
            solver_run=False,Lean_proof=False,
            scope='All515 supplied k3/r0 support survivors; no assertion about r>0 or k4/5.')
(ROOT/'three-common-factor-classification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(summary))
print(json.dumps({'source_sha256':result['source_sha256']}))
