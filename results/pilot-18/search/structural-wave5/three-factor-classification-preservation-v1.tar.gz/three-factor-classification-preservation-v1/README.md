# Independent three-factor classification review

PASS:253 of the supplied515 minimal k3/r0 full-cover support families are
excluded from a productive clean prefix of at most17 gates;262 remain.
The one-spare-late-AND proof excludes233; the independent position filter
excludes199, with20 new, so the union is253. Every original handoff binding,
family decision and saved abstract witness passes independent review.

The S04 scalar script uses a different complete traversal:57560 position/
relation assignments,9007 abstract feasible models,1545 pair truth-function
checks,0.27seconds. S01's13927 count reflects first-witness early exits.
No solver or Lean ran; no raw CNF is archived. The complete input515 list,
original11-file handoff, proof dependencies, both source/result/log sets,
and S04's final report are included.

The one-spare-AND proof assumes all three individual costs are at least14;
other families receive only separately justified position conditions.
The position filter must use max(owner charge, raw-input bit), not their
sum, since the deleted gates may overlap. Partial/non-full-cover selected
wires do not inherit these family exclusions. The final report supplies
all hypotheses and explains safe scope for future finite or generic cuts.
A cut implementation needs a separate source/clause/projection review.

The metadata label pure_singleton_OR means F OR OR(intersection), not a
standalone linear OR; the exclusion filters do not use it. The262 retained
patterns are necessary-condition witnesses, not circuits. There is no
claim covering r>0, k4/k5, larger/dirty prefixes, whole AAAA exhaustion,
UNSAT certification, or Lean acceptance. The proposed +2 extension is not
included or reviewed here. The previous archives remain unchanged.

repo/ and scratch/ mirror the authorized original roots. Historical scripts
and logs retain their original paths. SHA-bound original sources are not
modified to accommodate an extraction location.
