# Irrelevant raw-input cost: independent mathematical/specification PASS

Reviewed source951fd0d38db513a2fcfa98ddad5ef9c9dbc8c5d58acc4ba37867d0bc564af48f.
For a proper-support wire in a productive ambient-clean prefix, a syntactic
ancestor raw input v with v outside S and N(v) contained in S adds one to
the support/partial-edge ancestor lower bound. Empty H is included using
|S|-1 OR nodes plus a distinct AND; empty S gives the trivial bound0.
H may be any chosen accepted residual edge subset. AND replacement preserves
all negative rows and increases other values; ambient cleanliness remains,
while cleanliness or exact equality for the smaller H is not assumed.

The3366 trigger implications pass. Existing pinned sourceb10d8832...c2f24f
creates each root threshold >=g+2 at overflow_flag-1. All17 original counter
blocks were reconstructed exactly, and799 threshold assignments passed
1043861 clause evaluations. One link [-p_g,-(overflow_flag-1)] per output
therefore gives17new variables and3383added clauses total, with no new
counter auxiliaries. The expected clause fixture is review data only.
Use minimum cover witnesses and p=false off-trigger, including full support.
No implication from every old nonminimum-cover auxiliary assignment or RUP
certificate is claimed. A different parent/counter must not assume these IDs.

The actual review source and complete logs/JSON retain360448 trigger checks,
24 partial-output DAGs,72 chosen-H bound checks, and8 empty-residual cases.
These are bounded controls supporting the separate mathematical proof.
No production postprocessor or child CNF is accepted by this review; an
implementation needs its own source/delta/metadata/projection review.
No solver or Lean process ran. No raw CNF is archived.

Parent38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08
can be reproduced by the prior immutable normalization archive
ab76bf72819cac52f98c13d133b94fceedc2dc7fa4952ef06f825d19081beea4.
Original absolute paths in historical scripts/logs describe the reviewed
workspace. repo/ and scratch/ mirror its two authorized roots.
