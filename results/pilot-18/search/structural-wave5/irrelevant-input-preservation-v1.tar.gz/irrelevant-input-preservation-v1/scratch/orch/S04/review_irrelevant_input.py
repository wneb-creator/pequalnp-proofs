from pathlib import Path
import hashlib,importlib.util,itertools,json,sys,time
sys.dont_write_bytecode=True
O=Path('/tmp/oec/pequalnp-pilot-18/orch/S04');S=O.parent.parent;R=Path('/workspace/pequalnp-proofs')
start=time.monotonic()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
math=S/'orch/S01/irrelevant-input-charge.md'
assert sha(math)=='951fd0d38db513a2fcfa98ddad5ef9c9dbc8c5d58acc4ba37867d0bc564af48f'
source=R/'results/pilot-18/search/search_l1342_shard17_ancestorreverse.py'
assert sha(source)=='b10d8832060d1c554fd3daa563b7159d515a3c55adc49718989eaa9bd0c2f24f'
spec=importlib.util.spec_from_file_location('reviewed_frozen_counter',source)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
parent=S/'original-dag-strong/original.cnf';meta=parent.with_suffix('.json')
assert sha(parent)=='38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08'
d=json.loads(meta.read_text());clauses=[tuple(map(int,line.split()[:-1])) for line in parent.read_text().splitlines()[1:]]
positions={c:i for i,c in enumerate(clauses)}
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
EM=[(1<<a)|(1<<b) for a,b in E]
N=[sum(1<<(b if a==v else a) for a,b in E if v in(a,b)) for v in range(11)]
# Independently interpret all distinct Boolean antecedents, including empty/full support.
trigger_checks=0
for support in range(2048):
 for v in range(11):
  eligible=not(support>>v&1) and not(N[v]&~support)
  for ancestor,read,penalty in itertools.product([False,True],repeat=3):
   clause=penalty or bool(support>>v&1) or bool(N[v]&~support) or not ancestor or not read
   assert clause==(not(eligible and ancestor and read) or penalty)
   diagonal=penalty or bool(support>>v&1) or bool(N[v]&~support) or not read
   assert diagonal==(not(eligible and read) or penalty)
   trigger_checks+=2
# Recover all17 existing root thresholds without changing any source or CNF.
thresholds=[];network_clause_checks=0;counter_models=0
for g,row in enumerate(d['partial_edge_cost_restrictions']):
 inputs=d['prefix_support_tables'][13+g]+row['residual_edge_flags']+row['vertex_cover_flags']+[-x for x in d['prefix_ancestor_flags'][g]]
 bound=g+2;cap=bound+1;initial=row['vertex_cover_flags'][-1]
 cnf=m.CNF();cnf.variables=initial
 outputs=m.totalizer_atleast(cnf,inputs,cap)
 assert len(outputs)==cap and outputs[-1]==row['overflow_flag'] and outputs[-2]==row['overflow_flag']-1
 generated=list(map(tuple,cnf.clauses));at=positions[generated[0]]
 assert clauses[at:at+len(generated)]==generated
 for weight in range(len(inputs)+1):
  assignment={abs(lit):(i<weight)==(lit>0) for i,lit in enumerate(inputs)}
  assert len(assignment)==len(inputs)
  cursor=[initial]
  def reconstruct(lits):
   if len(lits)==1:return lits,sum(assignment[abs(t)]==(t>0) for t in lits)
   mid=len(lits)//2;left,nl=reconstruct(lits[:mid]);right,nr=reconstruct(lits[mid:])
   out=list(range(cursor[0]+1,cursor[0]+1+min(len(left)+len(right),cap)));cursor[0]+=len(out)
   for k,lit in enumerate(out):assignment[lit]=(nl+nr>=k+1)
   return out,nl+nr
  recovered,total=reconstruct(inputs)
  assert recovered==outputs and total==weight
  assert all(any(assignment[abs(lit)]==(lit>0) for lit in clause) for clause in generated)
  network_clause_checks+=len(generated);counter_models+=1
  for penalty in [False,True]:
   linked=(not penalty or not assignment[outputs[-2]])
   assert linked==(not penalty or weight<bound)
   # On proper support, the original constraint plus link is exactly weight+p<=bound.
   assert ((weight<=bound) and linked)==(weight+penalty<=bound)
 penalty=d['variables']+g+1
 thresholds.append(dict(gate=g,bound=bound,existing_overflow=outputs[-1],at_least_bound=outputs[-2],penalty_variable=penalty,link_clause=[-penalty,-outputs[-2]],network_clauses=len(generated),original_network_start_clause=at))
expected_triggers=[]
for g in range(17):
 support=d['prefix_support_tables'][13+g];penalty=d['variables']+g+1
 for h in range(g+1):
  for v in range(11):
   guard=[penalty,support[v]]+[-support[u] for u in range(11) if N[v]>>u&1]
   if h<g:guard.append(-d['prefix_ancestor_flags'][g][h])
   for side in ['lefts','rights']:expected_triggers.append(guard+[-d[side][h][v]])
assert len(expected_triggers)==3366
assert max(abs(x) for c in expected_triggers for x in c)==11985
# Actual clean productive circuits. H is any chosen accepted residual edge subset.
ALL=(1<<2048)-1
raw=[sum(1<<x for x in range(2048) if x>>v&1) for v in range(11)]+[0,ALL]
F=sum(1<<x for x in range(2048) if any(x&e==e for e in EM))
NEG=ALL^F;inputs_to_zero={}
cover_order=sorted(range(2048),key=lambda x:(x.bit_count(),x))
controls=[]
for v in (0,1,4,8):
 support=N[v];residual=[e for e in E if not support&((1<<e[0])|(1<<e[1]))]
 assert len(residual)>=3
 for mode in range(6):
  gates=[];values=raw[:]
  def add(op,a,b):
   gates.append((op,a,b));values.append(values[a]&values[b] if op=='and' else values[a]|values[b]);return 12+len(gates)
  def OR(xs):
   xs=list(xs);w=xs[0]
   for x in xs[1:]:w=add('or',w,x)
   return w
  support_sources=[u for u in range(11) if support>>u&1]
  s_or=OR(support_sources)
  # R carries the raw v, V carries one neighboring singleton plus residual edge e0.
  e0=add('and',*residual[0]);e1=add('and',*residual[1])
  u=add('or',v,e1);b=add('or',support_sources[0],e0);q=add('and',u,b)
  leaves=[s_or,q]
  if mode%3>=1:leaves.append(add('and',*residual[2]))
  if mode%3==2:leaves.extend(add('and',*e) for e in residual[3:5])
  output=OR(leaves)
  if mode>=3:
   zero=add('or',11,11);output=add('or',output,zero);output=add('or',output,output)
   add('or',12,12) # dead TRUE copy is outside the selected output cone
  sfun=lambda w:sum(1<<j for j in range(11) if values[w]>>(1<<j)&1)
  assert sfun(output)==support
  for g,(op,a,b2) in enumerate(gates):
   if op=='and':assert sfun(a) and sfun(b2) and not(values[g+13]&NEG)
  cone=set();rawanc=set()
  def visit(w):
   if w<13:
    if w<11:rawanc.add(w)
    return
   if w in cone:return
   cone.add(w);_,a,b2=gates[w-13];visit(a);visit(b2)
  visit(output);assert v in rawanc and not support>>v&1 and not(N[v]&~support)
  accepted=[(1<<a)|(1<<b2) for a,b2 in E if not support&((1<<a)|(1<<b2)) and values[output]>>((1<<a)|(1<<b2))&1]
  candidates=[[],accepted,accepted[:1]]
  checked=[]
  for H in candidates:
   cov=next(c for c in cover_order if all(c&e for e in H))
   lower=support.bit_count()+len(H)+cov.bit_count()
   assert len(cone)>=lower
   checked.append(dict(H=H,cover=cov,charged_bound=lower))
  assert len(accepted)<len(residual), 'controls must be partial, not full-cover'
  # Bypass q by b after restricting support. Check independent equality and pointwise growth.
  for x in range(2048):
   if x&support:continue
   old=[bool(x>>i&1) for i in range(11)]+[False,True];new=old[:]
   for g,(op,a,b2) in enumerate(gates):
    old.append(old[a] and old[b2] if op=='and' else old[a] or old[b2])
    new.append(new[b] if 13+g==q else (new[a] and new[b2] if op=='and' else new[a] or new[b2]))
    assert old[-1]<=new[-1]
    if NEG>>x&1:assert old[-1]==new[-1]
  controls.append(dict(raw_vertex=v,support=support,mode=mode,cone_gates=len(cone),accepted_residual_edges=accepted,subset_checks=checked,gates=gates,output=output,charged_AND=q,replacement=b))
result=dict(verdict='PASS_MATHEMATICS_TRIGGER_SPEC_AND_PINNED_COUNTER_REUSE',script_sha256=sha(Path(__file__)),reviewed_math_sha256=sha(math),parent_sha256=sha(parent),parent_metadata_sha256=sha(meta),parent_generator_sha256=sha(source),trigger_Boolean_checks=trigger_checks,expected_trigger_clauses=3366,existing_counter_thresholds=thresholds,original_counter_networks_exactly_reconstructed=17,exact_counter_assignments_checked=counter_models,network_clause_evaluations=network_clause_checks,expected_extra_variables=17,expected_extra_clauses_with_reused_thresholds=3383,circuit_controls=controls,edge_subset_cost_checks=sum(len(c['subset_checks']) for c in controls),actual_empty_residual_controls=sum(not c['accepted_residual_edges'] for c in controls),expected_trigger_clause_fixture=expected_triggers,seconds=time.monotonic()-start,solver_run=False,Lean_build=False,implementation_status='Specification and pinned-parent threshold reuse reviewed only; no emitted child CNF or production implementation accepted.',scope='Actual productive ambient-clean prefix circuits; arbitrary accepted residual H, including empty H and empty support. One Boolean charge, not one charge per qualifying input.')
(O/'irrelevant-input-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['verdict','script_sha256','reviewed_math_sha256','trigger_Boolean_checks','original_counter_networks_exactly_reconstructed','exact_counter_assignments_checked','network_clause_evaluations','expected_extra_variables','expected_extra_clauses_with_reused_thresholds','edge_subset_cost_checks','actual_empty_residual_controls','seconds']}))
