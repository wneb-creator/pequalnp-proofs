from pathlib import Path
import hashlib,json,tarfile,gzip,io,datetime
R=Path('/workspace/pequalnp-proofs');S=Path('/tmp/oec/pequalnp-pilot-18');O=S/'orch/S04';P=O/'irrelevant-input-preservation-v1'
P.mkdir(exist_ok=False)
files=[S/'orch/S01/irrelevant-input-charge.md',S/'math-analysis/partial-edge-cost-review.md',S/'math-analysis/support-cost-math-review.md',S/'original-dag-strong/original.json',R/'results/pilot-18/search/search_l1342_shard17_ancestorreverse.py',R/'results/orch/lemmas/S04-redteam.md']
files += [O/n for n in ['review_irrelevant_input.py','irrelevant-input-review.json','irrelevant-input-review.stdout.log','irrelevant-input-review.stderr.log','preserve_irrelevant_input_review.py']]
records=[]
for p in files:
 assert p.is_file() and not p.is_symlink() and p.suffix!='.cnf'
 raw=p.read_bytes();rel=Path('repo')/p.relative_to(R) if p.is_relative_to(R) else Path('scratch')/p.relative_to(S)
 q=P/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw)
 records.append(dict(source_path=str(p),archive_path=str(rel),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
readme='''# Irrelevant raw-input cost: independent mathematical/specification PASS

Reviewed source951fd0d38db513a2fcfa98ddad5ef9c9dbc8c5d58acc4ba37867d0bc564af48f.
For a proper-support wire in a productive ambient-clean prefix, a syntactic
ancestor raw input v with v outside S and N(v) contained in S adds one to
the support/partial-edge ancestor lower bound. Empty H is included using
|S|-1 OR nodes plus a distinct AND; empty S gives the trivial bound0.
H may be any chosen accepted residual edge subset. AND replacement preserves
all negative rows and increases other values; ambient cleanliness remains,
while cleanliness or exact equality for the smaller H is not assumed.

The3366 trigger implications pass. Existing pinned sourceb10d8832...c2f24f
creates each root threshold >=g+2 at overflow_flag-1. All17 original counter
blocks were reconstructed exactly, and799 threshold assignments passed
1043861 clause evaluations. One link [-p_g,-(overflow_flag-1)] per output
therefore gives17new variables and3383added clauses total, with no new
counter auxiliaries. The expected clause fixture is review data only.
Use minimum cover witnesses and p=false off-trigger, including full support.
No implication from every old nonminimum-cover auxiliary assignment or RUP
certificate is claimed. A different parent/counter must not assume these IDs.

The actual review source and complete logs/JSON retain360448 trigger checks,
24 partial-output DAGs,72 chosen-H bound checks, and8 empty-residual cases.
These are bounded controls supporting the separate mathematical proof.
No production postprocessor or child CNF is accepted by this review; an
implementation needs its own source/delta/metadata/projection review.
No solver or Lean process ran. No raw CNF is archived.

Parent38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08
can be reproduced by the prior immutable normalization archive
ab76bf72819cac52f98c13d133b94fceedc2dc7fa4952ef06f825d19081beea4.
Original absolute paths in historical scripts/logs describe the reviewed
workspace. repo/ and scratch/ mirror its two authorized roots.
'''
(P/'README.md').write_text(readme);records.append(dict(source_path='generated preservation README',archive_path='README.md',bytes=len(readme.encode()),sha256=hashlib.sha256(readme.encode()).hexdigest()))
manifest=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Mathematical and encoding specification PASS, including pinned-parent counter reuse; no production implementation/CNF/Lean/UNSAT acceptance.',base_reproduction_archive_sha256='ab76bf72819cac52f98c13d133b94fceedc2dc7fa4952ef06f825d19081beea4',files=records,raw_CNF_count=0)
(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=O/'irrelevant-input-preservation-v1.tar.gz'
with archive.open('wb') as stream,gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for p in sorted(P.rglob('*')):
  if not p.is_file():continue
  raw=p.read_bytes();info=tarfile.TarInfo(P.name+'/'+str(p.relative_to(P)));info.size=len(raw);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(records)+1
 for member in members:
  assert member.isfile() and '..' not in Path(member.name).parts
  assert tar.extractfile(member).read()==(P/member.name.removeprefix(P.name+'/')).read_bytes()
result=dict(verdict='PASS_REVIEW_PRESERVATION',archive=str(archive),archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),archive_bytes=archive.stat().st_size,regular_members=len(records)+1,manifest_sha256=hashlib.sha256((P/'manifest.json').read_bytes()).hexdigest(),review_sha256=hashlib.sha256((O/'irrelevant-input-review.json').read_bytes()).hexdigest(),scope=manifest['scope'])
(O/'irrelevant-input-preservation-handoff.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
