# Stable-only route: frozen source and control evidence

This package preserves S05's exact stable runner64958a6d0ef8eaa1e072547ade244cdb2de156815fca6545b4fcf829d331f7da, its source/diff/full50-artifact handoff, and S06's independent evidence/code review b75936e6798fc79508b451888bd612c1d21b9f89ae863f468740723fbbf9bbf4. The only three source replacements relative to the reviewed retained-proof runner are --unsat to --sat, the output ownership directory and its error label. The solver/checker/validator binaries remain hash-pinned; none is payload.

All full toy-control outputs are included, including the historical failed low-outer-AS attempt and corrected eight-byte binaryDRAT proof checked as UNSAT. This toy establishes only the control/proof path. Three completed hittingAAAO-RUP/T2/T3 UNKNOWN runs supplied full statistics:95% unstable CPU, approximately11conflicts/restart,113MiBRSS and308–324MiB incomplete traces. The old traces are not certificates and are not included/rehashed here. Their recorded hashes remain historical result data.

The proposed route is one600s stable-only --sat preset run on exactly the reviewed hittingAAAO-RUP CNF, with600s checker cap only after complete solver UNSAT,512MiB proof cap,1536MiBsolver/3072MiBcheckerAS and unchanged fullSATvalidation. Main subsequently admitted one run and explicitly supplied the existing default abort sentinel; its launch manifest and all final runtime outputs are preserved separately by main. Historical unexecuted/pending metadata is kept unchanged. This package neither reads nor includes active stable/T4 output directories, and contains no result claim for either case.

The unchanged real input is reconstructed from pinned original38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08 using the stored header and exact appended clause suffix. Full real-input metadata and the S08 actual hitting-cut review are retained. Earlier full hitting math/cut/source preservation is archive1b35774d63977b6e9f6660d2e011ab47316c690d1f0ff61585b85141b27af0ec; exact original generator dependencies are also included here. Small toyCNFs remain literal fixtures; no large CNF or compiled executable is payload.

    python3 scratch/orch/S06/restore_archive2_cnfs.py ARCHIVE ORIGINAL.cnf --verify-only

The standard-library restorer checks all manifest payloads and reconstructs the exact real input without historical scratch paths, solver or checker execution. Replace --verify-only with a fresh output path to materialize the real CNF. manifest.json binds payload; source-map.json records payload/recipe source correspondence. Bytecode caches are excluded from selection expectations and payload. External final build/restore logs are bound by stable-route-archive-v1-handoff.json to avoid self-referential manifests.

No new SAT, whole-case/shard UNSAT, Lean proof, performance guarantee, or exhaustive-search claim is made. Main alone owns final runtime preservation, copying, staging and pushing.
