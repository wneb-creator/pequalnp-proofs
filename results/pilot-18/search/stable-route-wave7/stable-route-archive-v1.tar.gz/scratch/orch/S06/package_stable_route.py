#!/usr/bin/env python3
"""Preserve only pinned stable-route evidence; exclude all active outputs."""
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import time

ROOT=Path('/tmp/oec/pequalnp-pilot-18')
OWN=ROOT/'orch/S06'
PEER=ROOT/'orch/S05'
ARCHIVE=OWN/'stable-route-archive-v1'


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text())
def dump(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')


def main():
    start=time.monotonic();ARCHIVE.mkdir(mode=0o700)
    s05=PEER/'stable-mode-handoff.json';s06=OWN/'stable-route-handoff.json'
    assert sha(s05)=='c2a1358bb7f0c1090fb1e36ad6d1916c8525a4148228e9c2a5369c9ee84c1015'
    assert sha(s06)=='9203f9e9819d44df01121e5f44404d67394a7453e6e176522cd00a193c1a10d9'
    paths={s05,s06}
    for item in read(s05)['artifacts']:
        p=Path(item['path']);assert p.is_relative_to(PEER)
        assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256'];paths.add(p)
    for name,pin in read(s06)['files'].items():
        p=Path(name);assert p.is_relative_to(OWN)
        assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256'];paths.add(p)
    # Select only frozen review copies, never S05's solver-mode-review directory.
    paths.update(p for p in (OWN/'stable-route-review').rglob('*') if p.is_file())
    paths.update(p for p in (OWN/'archive-wave1/reproduction').rglob('*') if p.is_file())
    for p in [OWN/'package_stable_route.py',OWN/'restore_archive2_cnfs.py',OWN/'offline_checked_cadical.py',
              ROOT/'lean-setup/validate_sat_candidate.py',
              ROOT/'orch/S08/offline-runner-review/review.json',
              ROOT/'orch/S08/offline-real-case13-review/review.json',
              ROOT/'orch/S08/hitting-charge-review/review.json',
              OWN/'hitting-charge-v1/AAAO-RUP/instance.cnf',
              OWN/'hitting-charge-v1/AAAO-RUP/instance.json',
              OWN/'hitting-charge-v1/AAAO-RUP/generation.json']:
        paths.add(p)
    original_path=ROOT/'original-dag-strong/original.cnf';original=original_path.read_bytes()
    original_sha='38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08'
    assert digest(original)==original_sha
    body=original.split(b'\n',1)[1];files={};recipes=[];source_map=[]

    def put(relative,raw,source):
        relative=Path(relative);assert not relative.is_absolute() and '..' not in relative.parts
        pin={'path':str(relative),'bytes':len(raw),'sha256':digest(raw),'source_path':source}
        if str(relative) in files:
            assert files[str(relative)]['sha256']==pin['sha256'];return
        target=ARCHIVE/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);files[str(relative)]=pin

    def generated(name,value):put(name,(json.dumps(value,indent=2,sort_keys=True)+'\n').encode(),'generated archive metadata')

    for p in sorted(paths):
        assert p.is_relative_to(ROOT) and p.is_file() and not p.is_symlink(),p
        assert '__pycache__' not in p.parts and p.suffix not in ['.pyc','.so','.o'],p
        raw=p.read_bytes();assert not raw.startswith(b'\x7fELF') and p.read_bytes()==raw
        relative=Path('scratch')/p.relative_to(ROOT)
        recipe=p.suffix=='.cnf' and len(raw)>65536
        source_map.append({'archive_path':str(relative),'source_path':str(p),'bytes':len(raw),'sha256':digest(raw),
            'disposition':'cnf_recipe' if recipe else 'payload'})
        if recipe:
            header,cnfbody=raw.split(b'\n',1);assert cnfbody.startswith(body)
            suffix=cnfbody[len(body):];delta=Path('cnf-deltas')/(digest(suffix)+'.clauses')
            put(delta,suffix,'exact clause suffix of pinned original CNF')
            recipes.append({'relative_path':str(relative),'header':header.decode(),'bytes':len(raw),'sha256':digest(raw),
                'delta_path':str(delta),'delta_sha256':digest(suffix)})
        else:put(relative,raw,str(p))
    assert len(recipes)==1
    generated('cnf-recipes.json',{'parent_sha256':original_sha,'parent_bytes':len(original),'recipes':recipes})
    generated('source-map.json',source_map)
    generated('summary.json',{'scope':'Frozen stable-preset runner/source/diff,50producerartifacts,S06independentreview,fulltoyproof/logs,threecompletedUNKNOWNstatistics and one exact real-input recipe. No active or final stable/T4 runtime outputs.',
        'runner_sha256':'64958a6d0ef8eaa1e072547ade244cdb2de156815fca6545b4fcf829d331f7da',
        'S05_handoff_sha256':sha(s05),'S06_handoff_sha256':sha(s06),
        'S06_review_sha256':'b75936e6798fc79508b451888bd612c1d21b9f89ae863f468740723fbbf9bbf4',
        'actual_hitting_input_review_sha256':'0ed0ac84baea1a88bf665fea4e6b78aff41b41c3993f1044d84f3665537a417d',
        'toy_UNSAT_only':True,'real_case_result':None,'runtime_launch_manifest':'Main preserves separately; not read by this packager.',
        'active_output_read':False,'solver_checker_Lean_launch':False,'compiled_payloads':0,
        'prior_hitting_archive_sha256':'1b35774d63977b6e9f6660d2e011ab47316c690d1f0ff61585b85141b27af0ec'})
    readme='''# Stable-only route: frozen source and control evidence

This package preserves S05's exact stable runner64958a6d0ef8eaa1e072547ade244cdb2de156815fca6545b4fcf829d331f7da, its source/diff/full50-artifact handoff, and S06's independent evidence/code review b75936e6798fc79508b451888bd612c1d21b9f89ae863f468740723fbbf9bbf4. The only three source replacements relative to the reviewed retained-proof runner are --unsat to --sat, the output ownership directory and its error label. The solver/checker/validator binaries remain hash-pinned; none is payload.

All full toy-control outputs are included, including the historical failed low-outer-AS attempt and corrected eight-byte binaryDRAT proof checked as UNSAT. This toy establishes only the control/proof path. Three completed hittingAAAO-RUP/T2/T3 UNKNOWN runs supplied full statistics:95% unstable CPU, approximately11conflicts/restart,113MiBRSS and308–324MiB incomplete traces. The old traces are not certificates and are not included/rehashed here. Their recorded hashes remain historical result data.

The proposed route is one600s stable-only --sat preset run on exactly the reviewed hittingAAAO-RUP CNF, with600s checker cap only after complete solver UNSAT,512MiB proof cap,1536MiBsolver/3072MiBcheckerAS and unchanged fullSATvalidation. Main subsequently admitted one run and explicitly supplied the existing default abort sentinel; its launch manifest and all final runtime outputs are preserved separately by main. Historical unexecuted/pending metadata is kept unchanged. This package neither reads nor includes active stable/T4 output directories, and contains no result claim for either case.

The unchanged real input is reconstructed from pinned original38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08 using the stored header and exact appended clause suffix. Full real-input metadata and the S08 actual hitting-cut review are retained. Earlier full hitting math/cut/source preservation is archive1b35774d63977b6e9f6660d2e011ab47316c690d1f0ff61585b85141b27af0ec; exact original generator dependencies are also included here. Small toyCNFs remain literal fixtures; no large CNF or compiled executable is payload.

    python3 scratch/orch/S06/restore_archive2_cnfs.py ARCHIVE ORIGINAL.cnf --verify-only

The standard-library restorer checks all manifest payloads and reconstructs the exact real input without historical scratch paths, solver or checker execution. Replace --verify-only with a fresh output path to materialize the real CNF. manifest.json binds payload; source-map.json records payload/recipe source correspondence. Bytecode caches are excluded from selection expectations and payload. External final build/restore logs are bound by stable-route-archive-v1-handoff.json to avoid self-referential manifests.

No new SAT, whole-case/shard UNSAT, Lean proof, performance guarantee, or exhaustive-search claim is made. Main alone owns final runtime preservation, copying, staging and pushing.
'''
    put('README.md',readme.encode(),'generated archive documentation')
    dump(ARCHIVE/'manifest.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'files':sorted(files.values(),key=lambda x:x['path']),'CNF_recipes':len(recipes),
        'large_raw_CNFs':0,'compiled_payloads':0,'active_runtime_outputs':0})
    command=['python3','-B',str(ARCHIVE/'scratch/orch/S06/restore_archive2_cnfs.py'),str(ARCHIVE),str(original_path),'--verify-only']
    with (OWN/'stable-route-archive-v1-restore.stdout').open('xb') as out,(OWN/'stable-route-archive-v1-restore.stderr').open('xb') as err:
        result=subprocess.run(command,cwd=OWN,stdout=out,stderr=err,timeout=15)
    assert result.returncode==0
    tarpath=OWN/'stable-route-archive-v1.tar.gz'
    with tarpath.open('xb') as stream,gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
        for p in sorted(ARCHIVE.rglob('*')):
            if not p.is_file():continue
            info=tar.gettarinfo(str(p),arcname=str(p.relative_to(ARCHIVE)));info.uid=info.gid=info.mtime=0;info.uname=info.gname='';info.mode=0o644
            with p.open('rb') as data:tar.addfile(info,data)
    expected={e['path']:e for e in files.values()};expected['manifest.json']={'bytes':(ARCHIVE/'manifest.json').stat().st_size,'sha256':sha(ARCHIVE/'manifest.json')};seen=set()
    with tarfile.open(tarpath,'r:gz') as tar:
        for m in tar:
            assert m.isfile() and not m.issym() and not m.islnk() and m.name not in seen
            assert not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
            seen.add(m.name);raw=tar.extractfile(m).read();pin=expected[m.name]
            assert len(raw)==pin['bytes'] and digest(raw)==pin['sha256']
    assert seen==set(expected)
    record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_LOCAL_PACKAGING_RECONSTRUCTION_PENDING_DELIVERY_REVIEW',
        'source_sha256':sha(Path(__file__)),'tar_path':str(tarpath),'tar_sha256':sha(tarpath),'tar_bytes':tarpath.stat().st_size,
        'manifest_sha256':sha(ARCHIVE/'manifest.json'),'manifest_files':len(files),'tar_members':len(seen),'CNF_recipes':1,
        'restore_command':command,'restore_exit_code':result.returncode,
        'restore_stdout_sha256':sha(OWN/'stable-route-archive-v1-restore.stdout'),'restore_stderr_sha256':sha(OWN/'stable-route-archive-v1-restore.stderr'),
        'active_output_read':False,'solver_checker_Lean_launch':False,'elapsed_seconds':time.monotonic()-start}
    dump(OWN/'stable-route-archive-v1.record.json',record);print(json.dumps(record,indent=2,sort_keys=True))


if __name__=='__main__':main()
