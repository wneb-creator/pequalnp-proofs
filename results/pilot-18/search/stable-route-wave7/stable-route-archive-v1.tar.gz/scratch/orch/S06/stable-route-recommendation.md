# One different bounded solver route

Recommend exactly one 600-second retained-proof run of the unchanged, reviewed hitting AAAO-RUP CNF using S05's CaDiCaL --sat preset runner. This enables stable-only search and the default random-walk machinery; it also lowers elimination/subsumption effort. Keep the same pinned solver, exact CNF, DRAT checker and full SAT validator. Allow the checker its separate600-second cap only after a complete solver UNSAT; keep one CPU slot through checker/validator/finalization. Main/S08 review and main admission remain required. Do not repeat all four cases before assessing this one result.

The completed three runs all explicitly selected --stabilize=false and --walk=false through --unsat. Independent full-log parsing agrees with S05's counts:

| Case | Conflicts | Restarts | Conflicts/restart | Unstable CPU | Peak RSS MiB | Retained partial proof MiB |
|---|---:|---:|---:|---:|---:|---:|
| AAAO-RUP | 2912372 | 274314 | 10.62 | 95.87% | 112.79 | 316.40 |
| T2 | 2908346 | 251139 | 11.58 | 95.13% | 112.91 | 308.01 |
| T3 | 2831325 | 253115 | 11.19 | 95.09% | 113.36 | 324.31 |

Each completed run was UNKNOWN at its wall limit, with only the solver phase present. Peak RSS is about7.4% of the1536MiB address-space cap; incomplete DRAT occupies60–64% of the512MiB file cap. Thus more memory or a larger proof cap does not address the observed termination. The statistics establish an untried mode, not that short restarts caused the difficulty or that stable mode will finish. New CEGAR/decomposition would require additional projection/coverage and proof integration; the one preset experiment fits the remaining deadline with an already checked acceptance path.

The supplied runner is byte-exactly the reviewed S06 runner after three unique replacements: OWN S06→S05, --unsat→--sat, and the output-ownership error label. No lifecycle, abort, pin, memory, proof, checker, SAT validation or acceptance logic changes. Independent audit rehashed all50 S05 handoff artifacts and verified the supplied toy solver20/checker0 result, exactlyfour full log keys/byte counts/hashes, input/proof/tool pins, and the intended preset options. The toy was not rerun and does not predict performance on the real CNF. Large incomplete proof files were not rehashed or replayed here; their recorded sizes are used only for performance analysis and remain unaccepted.

Use the exact command already in S05's solver-mode-review/recommendation.json, bound by its stable-mode-handoff.json SHA c2a1358bb7f0c1090fb1e36ad6d1916c8525a4148228e9c2a5369c9ee84c1015. Runner SHA64958a6d0ef8eaa1e072547ade244cdb2de156815fca6545b4fcf829d331f7da; CNF d47a48153e4b268587b8c3330c2e57d1756c554848f4cdfe50c2337cb0be5ec2; metadata0508fb3946c969a243ec5160ad9caed77839360a1c2f87ca63aa4cad398832ca. Fresh output/admission is main's responsibility; this audit did not inspect any proposed/active output directory.

S06 independent review stable-route-review/review.json SHA b75936e6798fc79508b451888bd612c1d21b9f89ae863f468740723fbbf9bbf4, source review_stable_route.py SHA bf7686c2036049fcd526ea5418b66920a7a9f397d520e5668327d28bf040e849. Full source, frozen evidence copies and stdout/stderr/execution records are retained. The audit exited0 in0.115471s; no solver/checker/Lean, production, or active-directory read/mutation.
