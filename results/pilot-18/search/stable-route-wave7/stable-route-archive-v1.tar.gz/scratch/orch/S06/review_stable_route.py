#!/usr/bin/env python3
"""Read-only independent audit of S05's single stable-mode proposal. No solver."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import time

ROOT = Path('/tmp/oec/pequalnp-pilot-18')
OWN = ROOT/'orch/S06'
PEER = ROOT/'orch/S05'
OUT = OWN/'stable-route-review'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def sha(path):
    return digest(path.read_bytes())


def main():
    started = time.monotonic()
    OUT.mkdir(mode=0o700)
    handpath = PEER/'stable-mode-handoff.json'
    assert sha(handpath) == 'c2a1358bb7f0c1090fb1e36ad6d1916c8525a4148228e9c2a5369c9ee84c1015'
    handoff = json.loads(handpath.read_text())
    bindings = {}
    for artifact in handoff['artifacts']:
        path = Path(artifact['path'])
        assert path.is_relative_to(PEER) and path.is_file() and not path.is_symlink()
        raw = path.read_bytes()
        assert len(raw) == artifact['bytes'] and digest(raw) == artifact['sha256'],path
        destination = OUT/'S05-evidence'/path.relative_to(PEER)
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_bytes(raw)
        bindings[str(path)] = {'bytes':len(raw),'sha256':digest(raw)}
    (OUT/'S05-handoff.json').write_bytes(handpath.read_bytes())
    parentpath = OWN/'offline_checked_cadical.py'
    childpath = PEER/'offline_stable_cadical.py'
    original,actual = parentpath.read_bytes(),childpath.read_bytes()
    assert digest(original) == 'aa5d13bb83ab79e47b9794809c3c06dc153544975cd1131afbdeaef7c18d484a'
    assert digest(actual) == '64958a6d0ef8eaa1e072547ade244cdb2de156815fca6545b4fcf829d331f7da'
    expected = original
    replacements = [(b"OWN=ROOT/'orch/S06'",b"OWN=ROOT/'orch/S05'"),
        (b"'--unsat'",b"'--sat'"),(b'output must be under S06 scratch',b'output must be under S05 scratch')]
    for before,after in replacements:
        assert expected.count(before) == 1
        expected = expected.replace(before,after)
    assert actual == expected
    recommendation = json.loads((PEER/'solver-mode-review/recommendation.json').read_text())
    stats = []
    for name in ['AAAO-RUP','T2','T3']:
        directory = OWN/f'offline-hitting-{name}-wave1'
        resultpath = directory/'result.json'
        result = json.loads(resultpath.read_text())
        assert result['state'] == 'FINISHED' and result['status'] == 'UNKNOWN' and result['exit_code'] == 2
        assert result['reason'] == 'ValueError: solver wall_time_limit'
        assert set(result['phases']) == {'solver'} and set(result['logs']) == {'solver.stdout','solver.stderr'}
        assert resultpath.read_bytes() == (PEER/'solver-mode-review'/name/'result.json').read_bytes()
        for log,pin in result['logs'].items():
            raw = (directory/log).read_bytes()
            assert len(raw) == pin['bytes'] and digest(raw) == pin['sha256']
            assert raw == (PEER/'solver-mode-review'/name/log).read_bytes()
        text = (directory/'solver.stdout').read_text()
        measures = {}
        for key in ['conflicts','restarts','fixed','learned','learned_lits','decisions','reduced']:
            matches = re.findall(r'^c '+key+r':\s+(\d+)\b',text,re.M)
            assert len(matches) == 1
            measures[key] = int(matches[0])
        unstable = re.findall(r'^c\s+([\d.]+)\s+([\d.]+)% unstable$',text,re.M)
        assert len(unstable) == 1 and not re.search(r'^c\s+[\d.]+\s+[\d.]+% stable$',text,re.M)
        assert '--stabilize=false' in text and '--walk=false' in text
        prior = next(x for x in recommendation['records'] if x['case'] == name)
        assert all(prior['statistics'][k] == v for k,v in measures.items())
        assert prior['profile']['unstable'] == {'seconds':float(unstable[0][0]),'percent':float(unstable[0][1])}
        phase = result['phases']['solver']
        assert phase['command'][1:4] == ['--unsat','--binary=true','--no-color']
        assert phase['reason'] == 'wall_time_limit' and phase['exit_code'] == -15
        proof = result['retained_proof_file']
        assert not proof['is_accepted_complete_certificate'] and proof['bytes'] < 512*1024**2
        metrics = {'case':name,'result_sha256':sha(resultpath),'full_stdout_sha256':sha(directory/'solver.stdout'),
            'statistics':measures,'unstable_percent':float(unstable[0][1]),
            'conflicts_per_restart':measures['conflicts']/measures['restarts'],
            'learned_clause_average_literals':measures['learned_lits']/measures['learned'],
            'sampled_peak_RSS_MiB':phase['sampled_peak_rss_kib']/1024,
            'RSS_fraction_of_AS_cap':phase['sampled_peak_rss_kib']/(1536*1024),
            'retained_partial_proof_bytes_reported':proof['bytes'],
            'proof_fraction_of_file_cap':proof['bytes']/(512*1024**2),
            'partial_proof_rehashed_by_this_audit':False,'solver_wall_seconds':phase['elapsed_seconds'],
            'child_CPU_seconds':phase['child_user_cpu_seconds']+phase['child_system_cpu_seconds']}
        stats.append(metrics)
    # Check the supplied real control and its exact four logs, not merely the verdict string.
    toy = PEER/'solver-mode-review/toy-stable-run-v2'
    result = json.loads((toy/'result.json').read_text())
    assert result['state'] == 'FINISHED' and result['status'] == 'VERIFIED_UNSAT' and result['exit_code'] == 0
    assert result['source_sha256'] == digest(actual)
    assert result['solver_verdicts'] == ['s UNSATISFIABLE'] and result['checker_verdicts'] == ['s VERIFIED UNSAT']
    assert set(result['logs']) == {'solver.stdout','solver.stderr','checker.stdout','checker.stderr'}
    for log,pin in result['logs'].items():
        raw = (toy/log).read_bytes()
        assert len(raw) == pin['bytes'] and digest(raw) == pin['sha256']
    assert result['phases']['solver']['exit_code'] == 20 and result['phases']['checker']['exit_code'] == 0
    assert result['phases']['solver']['reason'] is None and result['phases']['checker']['reason'] is None
    assert sha(toy/'instance.cnf') == result['cnf_sha256']
    assert sha(toy/'instance.json') == result['metadata_sha256']
    assert sha(toy/'proof.drat') == result['proof']['sha256'] and (toy/'proof.drat').stat().st_size == 8
    assert result['proof']['producer_complete'] is True and result['accepted_CNF_UNSAT'] is True
    toytext = (toy/'solver.stdout').read_text()
    assert '--stabilizeonly=true' in toytext and '--elimreleff=10' in toytext and '--subsumereleff=60' in toytext
    assert '--walk=false' not in toytext and '--stabilize=false' not in toytext
    helptext = (PEER/'cadical-help.stdout').read_text()
    assert '--sat          set internal options to target satisfiable instances' in helptext
    assert '--walk=bool                enable random walks [true]' in helptext
    for tool,pin in result['pins'].items():
        path = Path(pin['path'])
        assert path.is_relative_to(ROOT) and sha(path) == pin['sha256']
    # Independently inspect the complete proposed command; do not execute it or inspect output directories.
    cnf = OWN/'hitting-charge-v1/AAAO-RUP/instance.cnf'
    metadata = cnf.with_suffix('.json')
    expected_command = ['python3','-B',str(childpath),str(cnf),str(PEER/'solver-mode-review/AAAO-stable-600'),
        '--cnf-sha256','d47a48153e4b268587b8c3330c2e57d1756c554848f4cdfe50c2337cb0be5ec2',
        '--metadata-sha256','0508fb3946c969a243ec5160ad9caed77839360a1c2f87ca63aa4cad398832ca',
        '--solver-seconds','600','--checker-seconds','600','--proof-mib','512',
        '--max-records','100000000','--min-free-mib','1024']
    assert recommendation['command'] == expected_command
    assert sha(cnf) == expected_command[6] and sha(metadata) == expected_command[8]
    assert "default=ROOT/'DESK_ERROR.response'" in actual.decode()
    review = {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'verdict':'PASS_INDEPENDENT_STATIC_AND_COMPLETED_EVIDENCE_AUDIT_RECOMMEND_ONE_STABLE_ROUTE',
        'source_sha256':sha(Path(__file__)),'S05_handoff_sha256':sha(handpath),
        'stable_runner_sha256':digest(actual),'reviewed_parent_runner_sha256':digest(original),
        'bound_S05_artifacts':len(bindings),'bindings':bindings,'completed_case_statistics':stats,
        'exact_source_change':'Only --unsat to --sat, OWN directory S06 to S05 and error label; byte-for-byte equality otherwise.',
        'toy_control':'Supplied solver20/checker0 certificate and exactly4 full logs/input/proof/tool pins verified; not rerun.',
        'command':expected_command,'recommendation':'ONE 600s exact hitting-AAAO-RUP run in stable-only --sat preset, then independent checker if UNSAT. Main/S08 owns final review/admission.',
        'reason':'Completed runs selected no stable phase and spent95% CPU in unstable search with10.6-11.6 conflicts per restart; neither memory nor proof cap caused termination. This enables a previously unused search mode and random walks with lower elimination/subsumption effort.',
        'limitations':'No performance measurement on the real CNF in stable mode, no speedup or result guarantee. Certificate/control compatibility does not establish real CNF UNSAT. Recorded large incomplete proof hashes not independently replayed/rehashed here.',
        'alternatives_not_selected':'Fresh cube partitions or CEGAR need additional exact-coverage/projection and certificate integration work; use existing reviewed exact input and existing proof lifecycle for the requested one bounded route.',
        'elapsed_seconds':time.monotonic()-started,'solver_or_checker_launched':False,
        'active_output_directories_read':False,'worker_mutation':False}
    (OUT/'review.json').write_text(json.dumps(review,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'verdict':review['verdict'],'review_sha256':sha(OUT/'review.json'),
        'source_sha256':review['source_sha256'],'bound_S05_artifacts':len(bindings),
        'elapsed_seconds':review['elapsed_seconds'],'solver_or_checker_launched':False}))


if __name__ == '__main__':
    main()
