"""Read frozen completed logs and package one stable-preset recommendation."""
from pathlib import Path
import json,re,hashlib,datetime
R=Path('/tmp/oec/pequalnp-pilot-18');H=R/'orch/S05';D=H/'solver-mode-review'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    records=[]
    for case in ['AAAO-RUP','T2','T3']:
        directory=D/case;result=json.loads((directory/'result.json').read_text());text=(directory/'solver.stdout').read_text()
        assert result['status']=='UNKNOWN' and result['state']=='FINISHED'
        assert sha(directory/'solver.stdout')==result['logs']['solver.stdout']['sha256']
        phase=result['phases']['solver'];assert '--unsat' in phase['command'] and phase['reason']=='wall_time_limit'
        statistics={name:int(re.search(r'^c '+name+r':\s+(\d+)',text,re.M).group(1)) for name in ['conflicts','decisions','fixed','eliminated','restarts','propagations','learned','learned_lits','chronological','reduced']}
        prof={}
        for match in re.finditer(r'^c\s+(\d+\.\d+)\s+(\d+\.\d+)% (search|stable|unstable|simplify)\s*$',text,re.M):prof[match[3]]=dict(seconds=float(match[1]),percent=float(match[2]))
        assert prof['unstable']['percent']>95 and 'stable' not in prof
        records.append(dict(case=case,cnf_sha256=result['cnf_sha256'],metadata_sha256=result['metadata_sha256'],result_sha256=sha(directory/'result.json'),solver_stdout_sha256=sha(directory/'solver.stdout'),wall_seconds=phase['elapsed_seconds'],child_CPU_seconds=phase['child_user_cpu_seconds']+phase['child_system_cpu_seconds'],peak_RSS_MiB=phase['sampled_peak_rss_kib']/1024,proof_bytes=result['retained_proof_file']['bytes'],statistics=statistics,profile=prof,conflicts_per_restart=statistics['conflicts']/statistics['restarts'],average_learned_clause_literals=statistics['learned_lits']/statistics['learned']))
    parent=R/'orch/S06/offline_checked_cadical.py';new=H/'offline_stable_cadical.py'
    expected=parent.read_text().replace("OWN=ROOT/'orch/S06'","OWN=ROOT/'orch/S05'").replace("'--unsat','--binary=true'","'--sat','--binary=true'").replace('output must be under S06 scratch','output must be under S05 scratch')
    assert expected==new.read_text() and sha(parent)=='aa5d13bb83ab79e47b9794809c3c06dc153544975cd1131afbdeaef7c18d484a'
    toy=json.loads((D/'toy-stable-run-v2/result.json').read_text());assert toy['status']=='VERIFIED_UNSAT' and toy['accepted_CNF_UNSAT']
    toy_stdout=(D/'toy-stable-run-v2/solver.stdout').read_text();assert '--stabilizeonly=true' in toy_stdout
    cnf=R/'orch/S06/hitting-charge-v1/AAAO-RUP/instance.cnf';metadata=cnf.with_suffix('.json')
    assert sha(cnf)==records[0]['cnf_sha256'] and sha(metadata)==records[0]['metadata_sha256']
    command=['python3','-B',str(new),str(cnf),str(D/'AAAO-stable-600'),'--cnf-sha256',sha(cnf),'--metadata-sha256',sha(metadata),'--solver-seconds','600','--checker-seconds','600','--proof-mib','512','--max-records','100000000','--min-free-mib','1024']
    assert not (D/'AAAO-stable-600').exists()
    report=dict(status='ONE_APPROACH_READY_MAIN_S08_REVIEW_NO_PRODUCTION',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),records=records,recommendation='One stable-only --sat-preset retry of exact hitting AAAO-RUP input; same binary/DRAT checker/full SAT validator. Do not repeat all cases before this result.',source_sha256=sha(new),parent_source_sha256=sha(parent),command=command,command_executed=False,resource_bound=dict(solver_seconds=600,checker_seconds=600,SAT_validator_seconds=30,solver_AS_MiB=1536,checker_AS_MiB=3072,proof_MiB=512,minimum_free_MiB=1024,active_children=1),finite_control=dict(status=toy['status'],source_sha256=toy['source_sha256'],proof=toy['proof'],execution_sha256=sha(D/'toy-runner-v2.execution.json')),limitations='Mode change has no measured performance on the real CNF yet. Finite toy verifies preset and existing proof-path compatibility only. UNKNOWN is not a proof; no guarantee of a SAT/UNSAT verdict. Any real SAT still needs full validator and Lean. Any real UNSAT is exact-CNF scope only.')
    with (D/'recommendation.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
    print(json.dumps(dict(status=report['status'],source_sha256=report['source_sha256'],statistics=[dict(case=r['case'],unstable_percent=r['profile']['unstable']['percent'],conflicts=r['statistics']['conflicts'],restarts=r['statistics']['restarts'],conflicts_per_restart=r['conflicts_per_restart'],peak_RSS_MiB=r['peak_RSS_MiB']) for r in records])))
if __name__=='__main__':main()
