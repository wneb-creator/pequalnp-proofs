from pathlib import Path
import json,hashlib,datetime,fcntl
R=Path('/tmp/oec/pequalnp-pilot-18');H=R/'orch/S05';D=H/'solver-mode-review'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
(D/'packaging-initial.stderr').write_text('  File "<stdin>", line 25\n    f.write( ... )\nIndentationError: unexpected indent\n')
(D/'packaging-initial-note.txt').write_text('First inline packaging block failed to parse before any writes; corrected dedicated builder follows. Solver source, controls and inputs unchanged.\n')
p=D/'parent-offline_checked_cadical.py';p.write_bytes((R/'orch/S06/offline_checked_cadical.py').read_bytes())
files=sorted(p for p in D.rglob('*') if p.is_file())+[H/'offline_stable_cadical.py',H/'analyze_hitting_modes.py',H/'cadical-help.stdout',H/'cadical-help.stderr',Path(__file__)]
out=H/'stable-mode-handoff.json'
with out.open('x') as f:json.dump(dict(status='READY_MAIN_S08_REVIEW_ONE_UNLAUNCHED_APPROACH',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),recommendation_sha256=sha(D/'recommendation.json'),source_sha256=sha(H/'offline_stable_cadical.py'),artifacts=[dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size) for p in files]),f,indent=2);f.write('\n')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
s=f'S05 ONE DIFFERENT SOLVER APPROACH READY_MAIN/S08: exact hittingAAAO-RUP retrywithpinnedCaDiCaL --sat preset(stableonly),sameCNF/DRATchecker/fullSATvalidator. FinishedAAAO/T2/T3 all95.09–95.87%unstable/zeroStable,2.83–2.91mconflicts,251139–274314restarts(10.6–11.6conflicts/restart),~113MBRSS;allwalllimit,notmemory/proofcap. Actualtinycontrol showsstabilizeonly=true,lowerelim/subsume effort,walkdefaulttrue; four-clauseUNSAT20→checker0VERIFIED_UNSATviawholeunchangedlifecycle in0.142s. Ownrunner offline_stable_cadical.py SHA64958a6d0ef8eaa1e072547ade244cdb2de156815fca6545b4fcf829d331f7da differsfromreviewedaa5d13 ONLY --unsat→--sat plusOWN S06→S05/errorlabel. FirstcontrolouterAS768 preventedchildstart; correctedouter4096 passes,fullfailure retained, runnerunchanged. ActualAAAOpreflightPASS/nooutputcreated. Handoff stable-mode-handoff.json SHA{sha(out)},full3completedlogs+stats/parser/help/source/diff/controlproof/logs/preflight/unexecutedcommand. RecommendONE600solver+600checker/1536+3072MiB/512MiBproof,<=20minsingleCPU;main/S08review+admission beforelaunch, noproductionbyS05. Performanceunmeasured; noverdictguarantee/globalclaim. No activeT4read/mutation.'
with (R/'orch-notes.lock').open('a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    with Path('/workspace/pequalnp-proofs/results/orch/NOTES.md').open('a') as f:f.write('\n- '+now+' — '+s+'\n')
report='''
## Completed-solver statistics and one different approach

Following main's05:05 request, only completed hitting AAAO-RUP/T2/T3 logs were inspected and copied. Each used the pinned CaDiCaL --unsat preset and spent95.09–95.87percent of process time in unstable search, with no stable phase. They reached2.83–2.91million conflicts and251139–274314 restarts (10.6–11.6 conflicts perrestart), while peakRSS stayed112.79–113.36MiB. They hit the600second wall limit, not the1536MiB memory or512MiB proof cap. This supports changing the search regime before another identical ten-minute attempt; it does not predict satisfiability.

ONE recommendation: rerun the exact reviewed strongest AAAO-RUP input with the same pinned solver's --sat preset, which sets stabilizeonly=true and retains random walks. The preset is a heuristic, not a restriction on the answer: a finite four-clause UNSAT control generated DRAT and passed the unchanged checker through the complete runner. Bound the first real retry to600solver+600checker seconds, oneCPU held through finalization,1536/3072MiB AS,512MiBproof,>=1024MiBfree. Keep full-validation and provenance requirements. A run returns within20minutes including checking, but SAT/UNSAT is not guaranteed; UNKNOWN is not a proof.

New disjoint runner offline_stable_cadical.py SHA64958a6d0ef8eaa1e072547ade244cdb2de156815fca6545b4fcf829d331f7da has exactly three literal changes from reviewedaa5d13: --unsat to --sat, OWN S06 to S05, matching error label. Resource handling, pin/snapshot checks, proof checker, SAT validator, verdicts and cleanup remain byte-identical. Actual-parent preflight passes and creates no production directory. Tiny proof-path control passes in0.142s. Initial outer-control768MiB AS prevented the child's unchanged1536/3072MiB limit setup; its fullfailure was preserved before correcting the outer cap to4096MiB. No runner change was needed. A later inline packaging indentation error also occurred before any writes and is retained separately.

Full snapshots/statistics, pinnedbinaryhelp, source/diff/parent, toyproof/full logs, actual-parent preflight and one UNEXECUTED command are in solver-mode-review. Main/S08 review and main resource admission precede production. No active T4 file was read or changed.
'''
with Path('/workspace/pequalnp-proofs/results/orch/lemmas/S05-algebraic-construction.md').open('a') as f:f.write(report+'\nHandoff stable-mode-handoff.json SHA'+sha(out)+'.\n')
print(json.dumps(dict(handoff_sha256=sha(out),artifacts=len(files),recommendation_sha256=sha(D/'recommendation.json'))))
