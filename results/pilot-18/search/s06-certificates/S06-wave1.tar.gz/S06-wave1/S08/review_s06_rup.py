#!/usr/bin/env python3
"""Independent package reconstruction and bounded certificate replay, no solver."""
from pathlib import Path
import datetime
import hashlib
import json
import resource
import subprocess
import time

ROOT = Path('/workspace/pequalnp-proofs')
SCRATCH = Path('/tmp/oec/pequalnp-pilot-18')
SOURCE = SCRATCH / 'orch/S06'
OUT = SCRATCH / 'orch/S08/s06-rup-review'
OUT.mkdir(exist_ok=False)
SNAP = OUT / 'snapshot'
SNAP.mkdir()
hashes = {}


def sha(b):
    return hashlib.sha256(b).hexdigest()


def capture(p, name):
    data = p.read_bytes()
    target = SNAP / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    hashes[str(p)] = {'sha256': sha(data), 'bytes': len(data), 'snapshot': str(target)}
    return data


def get(name):
    return capture(SOURCE / name, name)


def clauses(data, nv):
    out = []
    for line in data.decode('ascii').splitlines():
        ls = [int(x) for x in line.split()]
        assert ls and ls[-1] == 0 and all(0 < abs(x) <= nv for x in ls[:-1])
        out.append(ls[:-1])
    return out


started = datetime.datetime.now(datetime.timezone.utc).isoformat()
raw = capture(SCRATCH / 'original-dag-strong/original.cnf', 'parent.cnf')
assert sha(raw) == '38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08'
header, body = raw.split(b'\n', 1)
_, _, nv, nc = header.decode().split()
nv, nc = int(nv), int(nc)
assert (nv, nc) == (11968, 114566)
assert len(clauses(body, nv)) == nc
meta = json.loads(capture(SCRATCH / 'original-dag-strong/original.json', 'parent.json'))
assert (meta['variables'], meta['clauses']) == (nv, nc)
pack = json.loads(get('package.json'))
assert pack['parent_sha256'] == sha(raw)
assert sha(get('probe.cpp')) == pack['source_sha256']
assert sha(get('build_probe_package.py')) == pack['builder_sha256']
get('second_level.py')
get('check_subcases.py')
capture(ROOT / 'results/orch/lemmas/S06-solver-performance.md', 'S06-report.md')

root = get('root-units.drat')
root_stats = json.loads(get('root-probe.stdout'))
assert root_stats == pack['root_statistics']
assert len(clauses(root, nv)) == root_stats['learned_units'] == 195
assert all(len(c) == 1 for c in clauses(root, nv))
reconstructed = root
for c in pack['cases']:
    name = c['case']
    cube = [v if op == 'A' else -v for op, v in zip(name, meta['ops'][17:])]
    assert cube == c['cube'] and len(cube) == 4
    expected = f'p cnf {nv} {nc + len(root.splitlines()) + 4}\n'.encode() + body + root + ''.join(f'{v} 0\n' for v in cube).encode()
    local_cnf = get(f'probe-{name}.cnf')
    assert local_cnf == expected and sha(local_cnf) == c['cnf_sha256']
    local_proof = get(f'probe-{name}.drat')
    assert sha(local_proof) == c['local_proof_sha256']
    local_clauses = clauses(local_proof, nv)
    lifted = ''.join(' '.join(map(str, [-v for v in cube] + cl)) + ' 0\n' for cl in local_clauses).encode()
    assert get(f'lifted-{name}.drat') == lifted and sha(lifted) == c['lifted_proof_sha256']
    assert len(local_clauses) == c['added_clauses'] and c['exit_code'] == 0
    assert get(f'probe-{name}.stdout').decode() == c['stdout']
    assert get(f'probe-{name}.stderr') == b''
    reconstructed += lifted
combined = get('combined.drat')
assert combined == reconstructed and sha(combined) == pack['proof_sha256']
assert len(clauses(combined, nv)) == pack['new_clauses'] == 569
augmented = get('augmented.cnf')
assert augmented == f'p cnf {nv} {nc + 569}\n'.encode() + body + combined
assert sha(augmented) == pack['augmented_cnf_sha256']

second = json.loads(get('second-level.json'))
assert [c['assumption'] for c in second] == [15, 16, 14, 27] + [meta['rights'][g][1] for g in range(16, 0, -1)]
reconstructed = combined
for case in second:
    v = case['assumption']
    expected = f'p cnf {nv} {nc + len(reconstructed.splitlines()) + 1}\n'.encode() + body + reconstructed + f'{v} 0\n'.encode()
    cnf = get(f'second-{v}.cnf')
    assert cnf == expected and sha(cnf) == case['local_cnf_sha256']
    local = get(f'second-{v}.drat')
    assert len(clauses(local, nv)) == case['learned_clauses']
    assert get(f'second-{v}.stdout').decode() == case['stdout']
    assert get(f'second-{v}.stderr') == b''
    reconstructed += ''.join(f'{-v} ' + line + '\n' for line in local.decode().splitlines()).encode()
strong = get('strong.drat')
assert strong == reconstructed and len(clauses(strong, nv)) == 994
assert all(clauses(strong, nv))
strong_cnf = get('strong.cnf')
assert strong_cnf == f'p cnf {nv} {nc + 994}\n'.encode() + body + strong

subcases = json.loads(get('certified-subcases/manifest.json'))
assert subcases['parent_sha256'] == sha(raw)
assert subcases['strong_cnf_sha256'] == sha(strong_cnf)
assert subcases['strong_proof_sha256'] == sha(strong)
subproof = get('certified-subcases/subcases.drat')
assert subproof == strong + b'0\n' and sha(subproof) == subcases['proof_sha256']
assert len(subproof) == subcases['proof_bytes'] and len(clauses(subproof, nv)) == subcases['proof_clauses'] == 995
assert [c['gate'] for c in subcases['cases']] == list(range(1, 17))
for c in subcases['cases']:
    gate, v = c['gate'], c['assumption']
    assert v == meta['rights'][gate][1]
    name = f'certified-subcases/gate-{gate:02d}-right-input1'
    cnf = get(name + '.cnf')
    assert cnf == f'p cnf {nv} {nc + 1}\n'.encode() + body + f'{v} 0\n'.encode()
    assert sha(cnf) == c['cnf_sha256']
    for ext in ['stdout', 'stderr']:
        assert sha(get(name + '.' + ext)) == c[ext + '_sha256']
    assert c['exit_code'] == 0 and c['verdict'] == ['s VERIFIED UNSAT']
    assert c['checker_command'][1:3] == ['--forward', '--rup-only']

checker = SCRATCH / 'solver/dsr-trim/bin/dsr-trim'
checker_hash = sha(checker.read_bytes())
assert checker_hash == subcases['checker_sha256'] == 'e6894b5b74ac2c09b494344f397ec5111547aaa782cdb399f1a8b6835ecef84b'
checker_sources = json.loads(capture(ROOT / 'results/pilot-18/search/streaming-checker-source-manifest.json', 'checker-source-manifest.json'))
for entry in checker_sources:
    data = (SCRATCH / 'solver/dsr-trim' / entry['path']).read_bytes()
    assert sha(data) == entry['sha256'] and len(data) == entry['bytes']

def limits():
    resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
    resource.setrlimit(resource.RLIMIT_CPU, (5, 5))


replays = []


def replay(name, cnf, proof, expected_exit, expected_verdict):
    argv = [str(checker), '--forward', '--rup-only', str(SNAP / cnf), str(SNAP / proof)]
    before = time.monotonic()
    with (OUT / (name + '.stdout')).open('wb') as stdout, (OUT / (name + '.stderr')).open('wb') as stderr:
        p = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr, preexec_fn=limits, timeout=6)
    so = (OUT / (name + '.stdout')).read_bytes()
    se = (OUT / (name + '.stderr')).read_bytes()
    verdict = [s for s in so.decode().splitlines() if s.startswith('s ')]
    record = {'name': name, 'argv': argv, 'cwd': str(ROOT), 'exit_code': p.returncode,
              'wall_seconds': time.monotonic() - before, 'verdict': verdict,
              'stdout_file': str(OUT / (name + '.stdout')), 'stdout_sha256': sha(so),
              'stderr_file': str(OUT / (name + '.stderr')), 'stderr_sha256': sha(se)}
    replays.append(record)
    (OUT / 'replay-progress.json').write_text(json.dumps(replays, indent=2) + '\n')
    assert p.returncode == expected_exit and verdict == expected_verdict


replay('combined-replay', 'parent.cnf', 'combined.drat', 0, ['s VALID'])
replay('strong-replay', 'parent.cnf', 'strong.drat', 0, ['s VALID'])
for c in subcases['cases']:
    gate = c['gate']
    replay(f'subcase-{gate:02d}-replay', f'certified-subcases/gate-{gate:02d}-right-input1.cnf', 'certified-subcases/subcases.drat', 0, ['s VERIFIED UNSAT'])
replay('negative-no-assumption', 'parent.cnf', 'certified-subcases/subcases.drat', 1, [])
assert sha(checker.read_bytes()) == checker_hash
changed = [str(p) for p, value in hashes.items() if sha(Path(p).read_bytes()) != value['sha256']]
assert not changed, changed
report = {'verdict': 'PASS_FOR_EXACT_RUP_PACKAGES_AND_16_SCOPED_SUBCASES',
          'started_utc': started, 'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'parent_sha256': sha(raw), 'parent_variables': nv, 'parent_clauses': nc,
          'combined_proof_sha256': sha(combined), 'combined_added_clauses': 569,
          'augmented_cnf_sha256': sha(augmented), 'augmented_clauses': nc + 569,
          'strong_proof_sha256': sha(strong), 'strong_added_clauses': 994,
          'strong_cnf_sha256': sha(strong_cnf), 'strong_clauses': nc + 994,
          'subcase_proof_sha256': sha(subproof), 'subcase_assumptions': [c['assumption'] for c in subcases['cases']],
          'checker_sha256': checker_hash, 'checker_source_manifest_entries_match': len(checker_sources),
          'every_CNF_exact_parent_plus_declared_proof_and_assumptions': True,
          'every_lift_negates_exact_recorded_assumptions': True,
          'source_generator_reviews': ['probe.cpp', 'build_probe_package.py', 'second_level.py', 'check_subcases.py'],
          'input_artifacts': hashes, 'replays': replays, 'input_changes_during_review': changed,
          'scope': 'RUP consequences of the exact original CNF and UNSAT only under each of 16 explicit overlapping assumptions; no exhaustive partition or global/original-shard UNSAT, no Lean theorem, no performance claim.',
          'not_reviewed': 'Later suffix-fanin package, newly generated CDCL control, any source/output after these hashes.',
          'limitations': ['No regeneration of the probe executable was required because all produced clauses were independently replayed against the exact parent.',
                         'Future UNSAT on augmented formulas must retain preprocessing proof/provenance; a SAT model still requires original-CNF/all-input checks and Lean proof.',
                         'Main must preserve checker exit/command/log hashes in an archival package; package.json by itself records generation but not checker completion.']}
(OUT / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'verdict': report['verdict'], 'review_sha256': sha((OUT / 'review.json').read_bytes()),
                  'replays': len(replays), 'wall_seconds': sum(x['wall_seconds'] for x in replays)}))
