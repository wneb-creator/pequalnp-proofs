#!/usr/bin/env python3
"""Review final S06 consequences, exact AAAA partition and retained direct proof."""
from pathlib import Path
from collections import defaultdict, deque
import datetime
import hashlib
import json
import resource
import subprocess
import time

ROOT = Path('/workspace/pequalnp-proofs')
SCRATCH = Path('/tmp/oec/pequalnp-pilot-18')
S = SCRATCH / 'orch/S06'
O = SCRATCH / 'orch/S08/s06-final-review'
O.mkdir(exist_ok=False)
SNAP = O / 'snapshot'
SNAP.mkdir()
bindings = {}
sha = lambda b: hashlib.sha256(b).hexdigest()


def read(p, name=None):
    data = p.read_bytes()
    bindings[str(p)] = {'sha256': sha(data), 'bytes': len(data)}
    if name:
        q = SNAP / name
        q.parent.mkdir(parents=True, exist_ok=True)
        q.write_bytes(data)
        bindings[str(p)]['snapshot'] = str(q)
    return data


started = datetime.datetime.now(datetime.timezone.utc).isoformat()
raw = read(SCRATCH / 'original-dag-strong/original.cnf', 'original.cnf')
assert sha(raw) == '38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08'
header, body = raw.split(b'\n', 1)
nv, nc = map(int, header.split()[2:])
meta = json.loads(read(SCRATCH / 'original-dag-strong/original.json', 'original.json'))
ops, selectors = meta['ops'][17:], meta['rights'][17]
assert ops == [2807, 3072, 3341, 3614] and len(selectors) == 30
artifact_manifest = json.loads(read(S / 'artifact-manifest.json', 'artifact-manifest.json'))
for name, expected in artifact_manifest['files'].items():
    data = read(S / name)
    assert len(data) == expected['bytes'] and sha(data) == expected['sha256'], name
assert sha(read(ROOT / 'results/orch/lemmas/S06-solver-performance.md', 'S06-report.md')) == artifact_manifest['report_sha256']
for name in ['suffix_fanin.py', 'prepare_partition.py', 'bounded_control.py']:
    read(S / name, name)

previous = json.loads((SCRATCH / 'orch/S08/s06-rup-review/review.json').read_text())
strong = read(S / 'strong.drat', 'strong.drat')
assert sha(strong) == previous['strong_proof_sha256']
current = strong
stages = json.loads(read(S / 'suffix-fanin/manifest.json', 'suffix-manifest.json'))
assert [stage['right_source_wire'] for stage in stages] == list(range(13, 30))
for stage in stages:
    wire = stage['right_source_wire']
    cube = ops + [selectors[wire]]
    assert stage['cube'] == cube and stage['suffix'] == 'AAAA' and stage['gate'] == 17
    prefix = f'AAAA-r17-{wire}'
    cnf = read(S / 'suffix-fanin' / (prefix + '.cnf'))
    assert cnf == f'p cnf {nv} {nc + len(current.splitlines()) + 5}\n'.encode() + body + current + ''.join(f'{v} 0\n' for v in cube).encode()
    local = read(S / 'suffix-fanin' / (prefix + '.drat'))
    assert len(local.splitlines()) == stage['learned_clauses'] and stage['exit_code'] == 0
    assert read(S / 'suffix-fanin' / (prefix + '.stdout')).decode() == stage['stdout']
    assert read(S / 'suffix-fanin' / (prefix + '.stderr')) == b''
    current += ''.join(' '.join(str(-v) for v in cube) + ' ' + line + '\n' for line in local.decode().splitlines()).encode()
proof = read(S / 'suffix-fanin/lifted-all.drat', 'final.drat')
assert proof == current and len(proof.splitlines()) == 3692 and len(proof) == 119955
assert all(line.strip() != b'0' for line in proof.splitlines())
final_cnf = read(S / 'suffix-fanin/augmented.cnf', 'augmented.cnf')
assert final_cnf == f'p cnf {nv} {nc + 3692}\n'.encode() + body + proof
summary = json.loads(read(S / 'suffix-fanin-summary.json', 'suffix-summary.json'))
assert summary['proof_sha256'] == sha(proof) and summary['cnf_sha256'] == sha(final_cnf)
assert summary['new_clauses'] == 3692 and summary['clauses'] == nc + 3692
part = json.loads(read(S / 'AAAA-right17-partition/manifest.json', 'partition-manifest.json'))
assert part['parent_sha256'] == sha(raw) and part['rup_proof_sha256'] == sha(proof)
assert [c['wire'] for c in part['excluded_sources']] == list(range(12))
assert [c['wire'] for c in part['cases']] == list(range(12, 30))
assert part['proposed_order'] == [14, 15, 16, 17] + list(range(18, 30)) + [12]
assert part['maximum_new_solver_wall_seconds'] == 340 and part['concurrency'] == 1

# Independently check the actual sequential at-most-one clauses via binary implication.
binary = defaultdict(list)
positive_selector_clause_found = False
for line in body.decode().splitlines():
    clause = list(map(int, line.split()))[:-1]
    if clause == selectors:
        positive_selector_clause_found = True
    if len(clause) == 2:
        a, b = clause
        binary[-a].append(b)
        binary[-b].append(a)
assert positive_selector_clause_found
for v in selectors:
    seen = {v}
    q = deque([v])
    while q:
        x = q.popleft()
        for y in binary[x]:
            if y not in seen:
                seen.add(y)
                q.append(y)
    assert all(-w in seen for w in selectors if w != v)

checker = SCRATCH / 'solver/dsr-trim/bin/dsr-trim'
checker_sha = sha(read(checker))
assert checker_sha == 'e6894b5b74ac2c09b494344f397ec5111547aaa782cdb399f1a8b6835ecef84b'
runner = SCRATCH / 'lean-setup/run_checked_kissat.py'
runner_sha = sha(read(runner, 'run_checked_kissat.py'))
assert runner_sha == '535ff6e32a68a31eefa1545f031483d0e9b73acd79066d1bbb2a2f42c86685bb'
assert read(runner) == read(ROOT / 'results/pilot-18/search/run_checked_kissat.py')
solver = SCRATCH / 'lean-4.36.0-linux/bin/cadical'
solver_sha = sha(read(solver))
assert solver_sha == '2a0137451efde370d67b88aec26f1e902870f095b1204b07049a103bc6bbd647'
for case in part['cases']:
    wire = case['wire']
    cube = ops + [selectors[wire]]
    assert case['cube'] == cube and case['already_refuted_original_plus_cube'] == (wire == 13)
    cnf_path = S / f'AAAA-right17-partition/case-{wire:02d}.cnf'
    assert case['cnf'] == str(cnf_path)
    cnf = read(cnf_path)
    assert cnf == f'p cnf {nv} {nc + 3692 + 5}\n'.encode() + body + proof + ''.join(f'{v} 0\n' for v in cube).encode()
    assert sha(cnf) == case['cnf_sha256']
    metadata = read(cnf_path.with_suffix('.json'))
    assert sha(metadata) == case['metadata_sha256']
    expected_meta = dict(meta, variables=nv, clauses=nc + 3692 + 5, sha256=sha(cnf),
                         s06_rup_parent_sha256=sha(raw), s06_rup_proof_sha256=sha(proof), s06_cube=cube)
    assert json.loads(metadata) == expected_meta
    expected_command = ['python3', str(runner), str(cnf_path), str(cnf_path.parent / f'run-{wire:02d}'),
                        '--solver', str(solver), '--solver-arg=--unsat', '--checker', str(checker),
                        '--checker-sha256', checker_sha, '--cnf-sha256', sha(cnf), '--max-seconds', '20',
                        '--solver-memory-mb', '1024', '--checker-memory-mb', '2048',
                        '--abort-file', str(SCRATCH / 'DESK_ERROR.response')]
    assert case['proposed_command_NOT_EXECUTED'] == expected_command
    # Sentinel is a path only: its content is never read by this review.

composed = proof + b'0\n'
(SNAP / 'composed-empty.drat').write_bytes(composed)
for excluded in part['excluded_sources']:
    wire = excluded['wire']
    cube = ops + [selectors[wire]]
    assert excluded['cube'] == cube
    cnf = read(S / f'AAAA-right17-partition/excluded-{wire:02d}.cnf')
    assert cnf == f'p cnf {nv} {nc + 3692 + 5}\n'.encode() + body + proof + ''.join(f'{v} 0\n' for v in cube).encode()
    assert sha(cnf) == excluded['cnf_sha256']
    (SNAP / f'original-excluded-{wire:02d}.cnf').write_bytes(f'p cnf {nv} {nc + 5}\n'.encode() + body + ''.join(f'{v} 0\n' for v in cube).encode())
coverage = ops + [-selectors[w] for w in range(12, 30)]
cov = read(S / 'AAAA-right17-partition/coverage.cnf')
assert cov == f'p cnf {nv} {nc + 3692 + len(coverage)}\n'.encode() + body + proof + ''.join(f'{v} 0\n' for v in coverage).encode()
assert sha(cov) == part['coverage_check']['cnf_sha256']
(SNAP / 'original-coverage.cnf').write_bytes(f'p cnf {nv} {nc + len(coverage)}\n'.encode() + body + ''.join(f'{v} 0\n' for v in coverage).encode())

direct = json.loads(read(S / 'bounded-control/result.json', 'direct-result.json'))
cube13 = ops + [selectors[13]]
assert direct['cube'] == cube13 and direct['solver_exit'] == 20 and not direct['timeout']
assert direct['checker_exit'] == 0 and direct['certified_subcase_unsat']
assert direct['solver_verdicts'] == ['s UNSATISFIABLE'] and direct['checker_verdicts'] == ['s VERIFIED UNSAT']
assert direct['solver_sha256'] == solver_sha and direct['checker_sha256'] == checker_sha
for name, expected in direct['files'].items():
    data = read(S / 'bounded-control' / name, 'direct/' + name)
    assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
direct_cnf = (SNAP / 'direct/instance.cnf').read_bytes()
assert direct_cnf == f'p cnf {nv} {nc + 5}\n'.encode() + body + ''.join(f'{v} 0\n' for v in cube13).encode()
assert sha(direct_cnf) == direct['cnf_sha256']
assert sha((SNAP / 'direct/proof.drat').read_bytes()) == direct['proof_sha256']
assert (SNAP / 'direct/proof.drat').stat().st_size == direct['proof_bytes'] == 1243473


def limits():
    resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
    resource.setrlimit(resource.RLIMIT_CPU, (10, 10))


replays = []


def replay(label, cnf, proof_path, expected_exit, expected_verdict, rup=True):
    cmd = [str(checker), '--forward'] + (['--rup-only'] if rup else []) + [str(SNAP / cnf), str(SNAP / proof_path)]
    start = time.monotonic()
    with (O / (label + '.stdout')).open('wb') as stdout, (O / (label + '.stderr')).open('wb') as stderr:
        p = subprocess.run(cmd, cwd=ROOT, stdout=stdout, stderr=stderr, preexec_fn=limits, timeout=12)
    so, se = (O / (label + '.stdout')).read_bytes(), (O / (label + '.stderr')).read_bytes()
    verdict = [line for line in so.decode().splitlines() if line.startswith('s ')]
    replays.append({'label': label, 'argv': cmd, 'cwd': str(ROOT), 'exit_code': p.returncode, 'verdict': verdict,
                    'seconds': time.monotonic() - start, 'stdout_sha256': sha(so), 'stderr_sha256': sha(se),
                    'stdout_file': str(O / (label + '.stdout')), 'stderr_file': str(O / (label + '.stderr'))})
    (O / 'replay-progress.json').write_text(json.dumps(replays, indent=2) + '\n')
    assert p.returncode == expected_exit and verdict == expected_verdict


replay('final-rup', 'original.cnf', 'final.drat', 0, ['s VALID'])
for w in range(12):
    replay(f'exclusion-{w:02d}', f'original-excluded-{w:02d}.cnf', 'composed-empty.drat', 0, ['s VERIFIED UNSAT'])
replay('coverage', 'original-coverage.cnf', 'composed-empty.drat', 0, ['s VERIFIED UNSAT'])
replay('direct-source13', 'direct/instance.cnf', 'direct/proof.drat', 0, ['s VERIFIED UNSAT'], rup=False)
replay('negative-without-cube', 'original.cnf', 'composed-empty.drat', 1, [])
changed = [p for p, e in bindings.items() if sha(Path(p).read_bytes()) != e['sha256']]
assert not changed, changed
report = {'verdict': 'PASS_FINAL_RUP_EXACT_AAAA_PARTITION_DIRECT_PROOF_AND_PROPOSED_COMMANDS',
          'started_utc': started, 'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'parent_sha256': sha(raw), 'final_proof_sha256': sha(proof), 'final_cnf_sha256': sha(final_cnf),
          'proof_clauses': 3692, 'proof_bytes': len(proof), 'final_clauses': nc + 3692,
          'partition_manifest_sha256': bindings[str(S / 'AAAA-right17-partition/manifest.json')]['sha256'],
          'artifact_manifest_sha256': bindings[str(S / 'artifact-manifest.json')]['sha256'],
          'artifact_manifest_entries_verified': len(artifact_manifest['files']),
          'all_18_case_CNF_and_metadata_and_command_arrays_match': True,
          'partition_coverage': 'Composed RUP+empty replay against ORIGINAL+AAAA+negation of all18 remaining selectors',
          'partition_disjointness': 'Actual original binary clauses imply -every_other_selector from each of30 selectors; positive30-selector clause present',
          'excluded_source_wires': list(range(12)), 'remaining_source_wires': list(range(12, 30)),
          'directly_refuted_wire': 13, 'direct_proof_sha256': direct['proof_sha256'],
          'reviewed_sweep_order': part['proposed_order'], 'reviewed_sweep_wall_budget': 340,
          'sweep_concurrency': 1, 'checker_sha256': checker_sha, 'runner_sha256': runner_sha, 'solver_sha256': solver_sha,
          'replays': replays, 'bindings': bindings, 'input_changes': changed,
          'findings': ['The bounded-control started_utc is populated after solver completion, so it is a completion observation mislabeled as start; measured wall duration remains correct.',
                       'Direct solver proof was checked with DSR --forward; it is separate from the --rup-only consequence package.',
                       'No solver was launched by S08 and this review does not launch or schedule the proposed sweep.',
                       'All remaining cubes must individually receive completed certified verdicts to exhaust AAAA; other suffixes and the global Lean statement remain open.',
                       'Every augmented-cube result must retain the preprocessing proof hash and original parent mapping.']}
(O / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'verdict': report['verdict'], 'sha256': sha((O / 'review.json').read_bytes()),
                  'replays': len(replays), 'seconds': sum(x['seconds'] for x in replays)}))
