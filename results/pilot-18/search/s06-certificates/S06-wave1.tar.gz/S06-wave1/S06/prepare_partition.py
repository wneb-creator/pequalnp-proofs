"""Prepare a finite exact cube manifest and replay checks. Starts no solver."""
import hashlib,json,subprocess
from pathlib import Path
R=Path('/tmp/oec/pequalnp-pilot-18');O=R/'orch/S06';D=O/'AAAA-right17-partition';D.mkdir(exist_ok=True)
parent=R/'original-dag-strong/original.cnf';raw=parent.read_bytes();h,body=raw.split(b'\n',1);n,c=map(int,h.split()[2:]);m=json.loads(parent.with_suffix('.json').read_text());ops=m['ops'][17:];sels=m['rights'][17]
proof=(O/'suffix-fanin/lifted-all.drat').read_bytes();base=body+proof;newc=c+len(proof.splitlines());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();checker=R/'solver/dsr-trim/bin/dsr-trim'
assert sha(parent)=='38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08'
empty=D/'empty.drat';empty.write_text('0\n');tests=[]
for wire in range(12):
 cube=ops+[sels[wire]];name=f'excluded-{wire:02d}';cnf=D/(name+'.cnf');cnf.write_bytes(f'p cnf {n} {newc+5}\n'.encode()+base+''.join(f'{v} 0\n' for v in cube).encode())
 with (D/(name+'.stdout')).open('w') as out,(D/(name+'.stderr')).open('w') as err:
  p=subprocess.run([str(checker),'--forward','--rup-only',str(cnf),str(empty)],stdout=out,stderr=err,timeout=10)
 assert p.returncode==0 and 's VERIFIED UNSAT\n' in (D/(name+'.stdout')).read_text()
 tests.append({'wire':wire,'cube':cube,'cnf_sha256':sha(cnf),'exit_code':p.returncode,'stdout_sha256':sha(D/(name+'.stdout'))})
coverage=ops+[-sels[w] for w in range(12,30)];cnf=D/'coverage.cnf';cnf.write_bytes(f'p cnf {n} {newc+len(coverage)}\n'.encode()+base+''.join(f'{v} 0\n' for v in coverage).encode())
with (D/'coverage.stdout').open('w') as out,(D/'coverage.stderr').open('w') as err:
 p=subprocess.run([str(checker),'--forward','--rup-only',str(cnf),str(empty)],stdout=out,stderr=err,timeout=10)
assert p.returncode==0 and 's VERIFIED UNSAT\n' in (D/'coverage.stdout').read_text()
cases=[]
for wire in range(12,30):
 cube=ops+[sels[wire]];cnf=D/f'case-{wire:02d}.cnf';cnf.write_bytes(f'p cnf {n} {newc+5}\n'.encode()+base+''.join(f'{v} 0\n' for v in cube).encode())
 meta=dict(m,variables=n,clauses=newc+5,sha256=sha(cnf),s06_rup_parent_sha256=sha(parent),s06_rup_proof_sha256=sha(O/'suffix-fanin/lifted-all.drat'),s06_cube=cube)
 cnf.with_suffix('.json').write_text(json.dumps(meta,indent=2)+'\n')
 command=['python3',str(R/'lean-setup/run_checked_kissat.py'),str(cnf),str(D/f'run-{wire:02d}'),'--solver',str(R/'lean-4.36.0-linux/bin/cadical'),'--solver-arg=--unsat','--checker',str(checker),'--checker-sha256',sha(checker),'--cnf-sha256',sha(cnf),'--max-seconds','20','--solver-memory-mb','1024','--checker-memory-mb','2048','--abort-file',str(R/'DESK_ERROR.response')]
 cases.append({'wire':wire,'cube':cube,'cnf':str(cnf),'cnf_sha256':sha(cnf),'metadata_sha256':sha(cnf.with_suffix('.json')),'proposed_command_NOT_EXECUTED':command,'already_refuted_original_plus_cube':wire==13})
manifest={'parent_sha256':sha(parent),'rup_proof_sha256':sha(O/'suffix-fanin/lifted-all.drat'),'scope':'Complete disjoint partition of ONLY the AAAA operation case, after checked RUP exclusions. Other suffix operations remain untouched. No candidate worker started.','excluded_sources':tests,'coverage_check':{'exit_code':p.returncode,'cnf_sha256':sha(D/'coverage.cnf'),'stdout_sha256':sha(D/'coverage.stdout'),'proof_sha256':sha(empty)},'cases':cases,'proposed_order':[14,15,16,17]+list(range(18,30))+[12],'maximum_new_solver_wall_seconds':340,'concurrency':1,'reason':'Source13 refuted in measured0.22s; prioritize nearby cases with>10000 propagated variables. Runtime of all unsolved cases is unknown.'}
(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('18 cases generated; 12 excluded-source and one coverage RUP checks passed; no solver launched.')
