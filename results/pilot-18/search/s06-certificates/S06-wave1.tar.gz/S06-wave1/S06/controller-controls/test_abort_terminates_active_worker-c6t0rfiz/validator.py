
import hashlib,json,sys
from pathlib import Path
cnf=Path(sys.argv[1]);model=Path(sys.argv[2]);meta=json.loads(cnf.with_suffix('.json').read_text())
(cnf.parent/'validator-invoked').write_text('yes')
if meta['mode']=='sat_bad_validator':sys.exit(1)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r={'status':'VALIDATED','meets_posted_gate_limit':meta['mode']!='sat_bad_size','verified_inputs_per_circuit':2048,
 'provenance':{'cnf_sha256':sha(cnf),'metadata_sha256':sha(cnf.with_suffix('.json')),'kissat_stdout_sha256':sha(model)}}
if meta['mode']=='sat_bad_hash':r['provenance']['cnf_sha256']='0'*64
cnf.with_suffix('.validated.json').write_text(json.dumps(r))
