
import hashlib,json,os,shutil,signal,sys,time
from pathlib import Path
cnf=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir()
def arg(n):return sys.argv[sys.argv.index(n)+1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
mode=json.loads(cnf.with_suffix('.json').read_text())['mode']
(out/'test-started').write_text(str(os.getpid()))
if mode in ['hang','ignore_term']:
 if mode=='ignore_term':signal.signal(signal.SIGTERM,signal.SIG_IGN)
 while True:time.sleep(.05)
shutil.copyfile(cnf,out/'instance.cnf')
sat=mode in ['sat','sat_bad_validator','sat_bad_size','sat_bad_hash','sat_failed_runner']
unsat=mode in ['unsat','wrong_exit','valid_only','forged_result','missing_logs','missing_bytes','wrong_bytes','wrong_log_hash']
sv=['s SATISFIABLE'] if sat else (['s UNSATISFIABLE'] if unsat else ['s UNKNOWN'])
cv=['s VERIFIED UNSAT'] if unsat and mode!='valid_only' else ['s VALID']
for name,lines in [('solver.stdout.txt',sv),('checker.stdout.txt',cv),('solver.stderr.txt',[]),('checker.stderr.txt',[])]:
 (out/name).write_text(''.join(x+'\n' for x in lines))
status='SAT_UNVALIDATED' if sat else ('VERIFIED_UNSAT' if unsat else ('ABORTED' if mode=='limit' else 'UNKNOWN'))
code=10 if sat else (0 if unsat else (3 if mode=='limit' else 2))
r={'status':status,'accepted_CNF_UNSAT':unsat,'proof_stream_complete':True,'reason':'wall_time_limit' if mode=='limit' else None,
 'solver_exit':10 if sat else (20 if unsat else 0),'checker_exit':0,'solver_verdicts':sv,'checker_verdicts':cv,
 'cnf_sha256':sha(cnf),'solver_sha256':sha(arg('--solver')),'checker_sha256':sha(arg('--checker')),
 'logs':{name:{'sha256':sha(out/name),'bytes':(out/name).stat().st_size} for name in ['solver.stdout.txt','solver.stderr.txt','checker.stdout.txt','checker.stderr.txt']}}
if mode=='wrong_exit':code=2
if mode=='forged_result':r['proof_stream_complete']=False
if mode=='missing_logs':r['logs']={}
if mode=='missing_bytes':r['logs']['solver.stdout.txt'].pop('bytes')
if mode=='wrong_bytes':r['logs']['solver.stdout.txt']['bytes']+=1
if mode=='wrong_log_hash':r['logs']['solver.stdout.txt']['sha256']='0'*64
if mode=='sat_failed_runner':code=1;r['status']='FAILED'
(out/'result.json').write_text(json.dumps(r))
sys.exit(code)
