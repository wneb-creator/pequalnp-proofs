#!/usr/bin/env python3
"""Snapshot completed S06 evidence. No solver, checker, Lean or network starts."""
import datetime,hashlib,json,shutil
from pathlib import Path
R=Path('/tmp/oec/pequalnp-pilot-18');O=R/'orch/S06';A=O/'archive-wave1';REPO=Path('/workspace/pequalnp-proofs')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
wave=json.loads((O/'serial-wave1/result.json').read_text());assert wave['status']=='COMPLETED' and len(wave['cases'])==17 and wave['verified_unsat_count']==5
assert sha(O/'serial_controller.py')==wave['source_sha256']=='bd2366dc9770fe35268092f06cbdbec0511a90585fee54bbd5fbb0b72cfc3e98'
parent=R/'original-dag-strong/original.cnf';parentraw=parent.read_bytes();parentbody=parentraw.split(b'\n',1)[1];parenthash=sha(parent)
A.mkdir(exist_ok=False);entries=[];omitted=[];recipes=[]
def copy(p,dest):
 target=A/dest;target.parent.mkdir(parents=True,exist_ok=True);raw=p.read_bytes();target.write_bytes(raw)
 entries.append({'path':str(dest),'source_path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
for p in sorted(O.rglob('*')):
 if not p.is_file() or p.relative_to(O).parts[0].startswith('archive-wave1') or '__pycache__' in p.parts:continue
 rel=p.relative_to(O)
 if p.suffix=='.cnf':
  raw=p.read_bytes();head,_,body=raw.partition(b'\n');info={'relative_path':str(rel),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};omitted.append(info)
  if body.startswith(parentbody):
   delta=body[len(parentbody):];ds=hashlib.sha256(delta).hexdigest();dest=Path('cnf-deltas')/(ds+'.clauses');target=A/dest
   if not target.exists():
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(delta);entries.append({'path':str(dest),'source_path':'derived clause suffix of '+str(p),'bytes':len(delta),'sha256':ds})
   recipes.append(dict(info,header=head.decode(),delta_path=str(dest),delta_sha256=ds))
 elif p.name=='probe' or p.suffix=='.tsv':
  omitted.append({'relative_path':str(rel),'bytes':p.stat().st_size,'sha256':sha(p),'reason':'rebuildable executable or scalar probing statistics; full checker/runner diagnostics retained'})
 else:copy(p,Path('S06')/rel)
copy(parent.with_suffix('.json'),Path('parent/original.json'))
for kind in ['s06-rup-review','s06-final-review']:
 folder=R/'orch/S08'/kind
 for p in sorted(folder.iterdir()):
  if p.is_file():copy(p,Path('S08')/kind/p.name)
for p in sorted((R/'orch/S08').glob('*s06*.py')):copy(p,Path('S08')/p.name)
for name in ['run_checked_kissat.py','validate_sat_candidate.py','build_original_strong.py','add_ancestor_support.py','README.md','streaming-runner.md','cadical-streaming-review.md','streaming-checker-source-manifest.json']:
 copy(REPO/'results/pilot-18/search'/name,Path('reproduction')/name)
for p in sorted((REPO/'results/pilot-18/search').glob('search_l1342_shard17*.py')):copy(p,Path('reproduction')/p.name)
copy(REPO/'results/orch/lemmas/S06-solver-performance.md',Path('S06-report.md'))
copy(REPO/'results/orch/lemmas/S08-integration-review.md',Path('S08-report.md'))
recipes_obj={'parent_sha256':parenthash,'parent_bytes':len(parentraw),'recipes':recipes,'not_restored':[x for x in omitted if x.get('relative_path','').endswith('.cnf') and x['relative_path'] not in {r['relative_path'] for r in recipes}],'scope':'Exact original-parent-derived CNFs; synthetic controller test fixtures are recreated by their retained test source.'}
(A/'cnf-recipes.json').write_text(json.dumps(recipes_obj,indent=2)+'\n')
(A/'omitted-files.json').write_text(json.dumps(omitted,indent=2)+'\n')
summary={'status':'COMPLETED','controller_exit_code':wave['controller_exit_code'],'source_sha256':wave['source_sha256'],'started_utc':wave['started_utc'],'finished_utc':wave['finished_utc'],'new_verified_unsat_wires':[c['wire'] for c in wave['cases'] if c['status']=='VERIFIED_UNSAT'],'unresolved_wires':[c['wire'] for c in wave['cases'] if c['status']!='VERIFIED_UNSAT'],'SAT_candidates':0,'AAAA_exhausted':False,'assigned_shard_exhausted':False,'Lean_proof':False,'production_wave_proofs_retained':False,'retained_replayable_proofs':['S06/combined.drat','S06/strong.drat','S06/suffix-fanin/lifted-all.drat','S06/certified-subcases/subcases.drat','S06/bounded-control/proof.drat'],'S08_final_review_sha256':sha(R/'orch/S08/s06-final-review/review.json')}
(A/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(A/'README.md').write_text('''# S06 finite-case archive, wave1

The17-case serial sweep completed at03:44:07UTC: five new online-checked CNF UNSAT cases (right-source wires14..18), twelve time limits (12,19..29), no SAT candidate. AAAA and the assigned shard remain open. Controller exit0 means the queue completed, not that all cases are UNSAT.

`summary.json` states the scope. `manifest.json` binds every archived file. `S06/serial-wave1/` contains complete final controller/runner records, atomic progress, event journal, copied metadata, all four solver/checker logs per case (including empty logs), and controller stdout/stderr. The production online runner retains proof hashes but no replayable proof stream. Its five verified results must not be described as retained certificates.

Replayable evidence is retained separately: all3692 RUP additions and earlier stages; the16 prefix-selector subcase proof; the1.24MB direct wire13 DRAT certificate; all local/independent checker logs and reviews; exact partition/coverage metadata. S08's final review is copied with full checker diagnostics under `S08/s06-final-review/`; earlier reviews/diagnostics are under `S08/s06-rup-review/`. Original review paths and hashes remain unchanged inside records.

No raw CNF or compiled solver/probe binary is archived. `omitted-files.json` retains their exact hashes and sizes. `cnf-recipes.json` plus deduplicated `cnf-deltas/` reconstruct every actual parent-derived input/snapshot exactly. Synthetic controller fixtures are reproduced by `S06/test_serial_controller.py`. Scalar TSV statistics are omitted with hashes; all full checker and solver diagnostics are retained.

To verify reconstruction without starting any worker:

    python3 S06/restore_archive_cnfs.py ARCHIVE ORIGINAL.cnf --verify-only

To restore raw CNFs into a fresh external directory:

    python3 S06/restore_archive_cnfs.py ARCHIVE ORIGINAL.cnf FRESH_EXTERNAL_DIRECTORY

ORIGINAL.cnf must have SHA25638d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08. Its exact metadata is in `parent/original.json`. Original generator dependencies are copied in `reproduction/`; use the recorded reverse-counter generator with --distinct-prefix to create a fresh parent, then build_original_strong.py on its prefix-distinct.cnf. These reproduce the source-pinned original DAG; they start no solver. The retained scripts' historical absolute scratch paths identify the tested layout.

`S06/probe.cpp` and generation scripts reproduce the RUP packages in their recorded scratch layout. Build with g++ -std=c++17 -O2 -Wall -Wextra, then run the root probe using all-vars.txt, build_probe_package.py, second_level.py, suffix_fanin.py, check_subcases.py and prepare_partition.py as documented in S06-report.md. Timings/timestamps may vary; proof and CNF bytes are bound in manifests. The archived RUP proofs can instead be checked directly with the pinned unchanged DSR binary, without rerunning generation.

`S06/serial_controller.py` is the frozen reviewed source bd2366dc9770fe35268092f06cbdbec0511a90585fee54bbd5fbb0b72cfc3e98. Final controller tests used simulated processes only; the completed production wave was separately launched by main. The default runner limit is20seconds and the total controller case budget is50seconds including up to30seconds cleanup/validation overhead. Hash pins, fresh-directory refusal, abort sentinel, strict four-log size/hash checks and SAT-stop/full-validator handling are retained. No second wave is authorized by this archive.

The package is prepared in S06 scratch for main's independent review/copy/push. Packaging itself starts no solver, checker, Lean or remote operation.
''')
# Include generated metadata and README, but keep the manifest's own hash external.
for name in ['cnf-recipes.json','omitted-files.json','summary.json','README.md']:
 p=A/name;entries.append({'path':name,'source_path':'generated archive metadata','bytes':p.stat().st_size,'sha256':sha(p)})
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Reproducible finite-case research archive; no AAAA/shard/global exhaustion or Lean proof.','files':sorted(entries,key=lambda x:x['path']),'raw_cnf_count':0,'archived_bytes':sum(x['bytes'] for x in entries),'restorable_parent_derived_cnf_count':len(recipes),'omitted_files_manifest':'omitted-files.json','summary':'summary.json'}
(A/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for entry in entries:
 p=A/entry['path'];assert p.stat().st_size==entry['bytes'] and sha(p)==entry['sha256']
assert not list(A.rglob('*.cnf'))
print(json.dumps({'archive':str(A),'manifest_sha256':sha(A/'manifest.json'),'files':len(entries),'bytes':manifest['archived_bytes'],'restorable_cnfs':len(recipes),'raw_cnf_files':0},indent=2))
