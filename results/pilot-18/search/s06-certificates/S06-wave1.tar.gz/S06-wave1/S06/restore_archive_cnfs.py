#!/usr/bin/env python3
"""Restore exact omitted CNFs from a pinned original and archived clause deltas.
No solver starts. --verify-only checks reconstructed bytes without writing them.
"""
import argparse,hashlib,json
from pathlib import Path

def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('archive',type=Path);p.add_argument('original',type=Path);p.add_argument('output',type=Path,nargs='?');p.add_argument('--verify-only',action='store_true');a=p.parse_args()
 m=json.loads((a.archive/'cnf-recipes.json').read_text());raw=a.original.read_bytes();assert sha(raw)==m['parent_sha256'];body=raw.split(b'\n',1)[1]
 if not a.verify_only:
  assert a.output is not None;a.output.mkdir(parents=True,exist_ok=False)
 for recipe in m['recipes']:
  delta=(a.archive/recipe['delta_path']).read_bytes();assert sha(delta)==recipe['delta_sha256']
  result=recipe['header'].encode()+b'\n'+body+delta;assert sha(result)==recipe['sha256'] and len(result)==recipe['bytes']
  if not a.verify_only:
   relative=Path(recipe['relative_path']);assert not relative.is_absolute() and '..' not in relative.parts
   target=a.output/relative
   target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(result)
 print(json.dumps({'status':'PASS','reconstructed_CNF_count':len(m['recipes']),'wrote_files':not a.verify_only}))
if __name__=='__main__':main()
