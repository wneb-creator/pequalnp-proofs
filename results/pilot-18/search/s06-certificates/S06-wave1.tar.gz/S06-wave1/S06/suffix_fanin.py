import hashlib,json,subprocess
from pathlib import Path
R=Path('/tmp/oec/pequalnp-pilot-18');O=R/'orch/S06';D=O/'suffix-fanin';D.mkdir(exist_ok=True)
p=R/'original-dag-strong/original.cnf';raw=p.read_bytes();hdr,body=raw.split(b'\n',1);n,nc=map(int,hdr.split()[2:]);m=json.loads(p.with_suffix('.json').read_text())
proof=(O/'strong.drat').read_bytes();manifest=[];ops=m['ops'][17:]
for wire in range(13,30):
 sel=m['rights'][17][wire];cube=ops+[sel];prefix=f'AAAA-r17-{wire}';cnf=D/(prefix+'.cnf');local=D/(prefix+'.drat')
 cnf.write_bytes(f'p cnf {n} {nc+len(proof.splitlines())+len(cube)}\n'.encode()+body+proof+''.join(f'{v} 0\n' for v in cube).encode())
 with (D/(prefix+'.stdout')).open('w') as out,(D/(prefix+'.stderr')).open('w') as err:
  res=subprocess.run([str(O/'probe'),str(cnf),str(O/'all-vars.txt'),str(local),str(D/(prefix+'.tsv')),'3'],stdout=out,stderr=err,timeout=10)
 assert res.returncode in [0,20]
 lines=local.read_text().splitlines();proof+=''.join(' '.join(str(-v) for v in cube)+' '+line+'\n' for line in lines).encode()
 manifest.append({'suffix':'AAAA','gate':17,'right_source_wire':wire,'cube':cube,'exit_code':res.returncode,'learned_clauses':len(lines),'stdout':(D/(prefix+'.stdout')).read_text()})
(D/'lifted-all.drat').write_bytes(proof)
(D/'augmented.cnf').write_bytes(f'p cnf {n} {nc+len(proof.splitlines())}\n'.encode()+body+proof)
(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))
