import datetime,hashlib,json,os,resource,signal,subprocess,time
from pathlib import Path
R=Path('/tmp/oec/pequalnp-pilot-18');O=R/'orch/S06/bounded-control';O.mkdir(exist_ok=False)
parent=R/'original-dag-strong/original.cnf';meta=json.loads(parent.with_suffix('.json').read_text());raw=parent.read_bytes();h,b=raw.split(b'\n',1);n,c=map(int,h.split()[2:]);cube=meta['ops'][17:]+[meta['rights'][17][13]];cnf=O/'instance.cnf';cnf.write_bytes(f'p cnf {n} {c+5}\n'.encode()+b+''.join(f'{x} 0\n' for x in cube).encode());proof=O/'proof.drat'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
solver=R/'lean-4.36.0-linux/bin/cadical';checker=R/'solver/dsr-trim/bin/dsr-trim'
assert sha(parent)=='38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08'
assert sha(solver)=='2a0137451efde370d67b88aec26f1e902870f095b1204b07049a103bc6bbd647'
assert sha(checker)=='e6894b5b74ac2c09b494344f397ec5111547aaa782cdb399f1a8b6835ecef84b'
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(1024*1024**2,1024*1024**2));resource.setrlimit(resource.RLIMIT_FSIZE,(32*1024**2,32*1024**2))
cmd=[str(solver),'--unsat','--binary=false','--no-color','-c','10000','-t','5',str(cnf),str(proof)];started=time.monotonic();timeout=False
with (O/'solver.stdout').open('w') as out,(O/'solver.stderr').open('w') as err:
 p=subprocess.Popen(cmd,stdout=out,stderr=err,start_new_session=True,preexec_fn=limits)
 try:code=p.wait(timeout=7)
 except subprocess.TimeoutExpired:
  timeout=True;os.killpg(p.pid,signal.SIGKILL);code=p.wait()
result={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'solver_command':cmd,'solver_exit':code,'wall_seconds':time.monotonic()-started,'timeout':timeout,'cube':cube,'cnf_sha256':sha(cnf),'solver_sha256':sha(solver),'checker_sha256':sha(checker),'solver_verdicts':[l for l in (O/'solver.stdout').read_text().splitlines() if l.startswith('s ')]}
if code==20 and not timeout:
 with (O/'checker.stdout').open('w') as out,(O/'checker.stderr').open('w') as err:
  p=subprocess.run([str(checker),'--forward',str(cnf),str(proof)],stdout=out,stderr=err,timeout=10)
 result.update(checker_exit=p.returncode,checker_verdicts=[l for l in (O/'checker.stdout').read_text().splitlines() if l.startswith('s ')],proof_sha256=sha(proof),proof_bytes=proof.stat().st_size)
 result['certified_subcase_unsat']=result['solver_verdicts']==['s UNSATISFIABLE'] and p.returncode==0 and result['checker_verdicts']==['s VERIFIED UNSAT']
result['files']={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in O.iterdir() if p.is_file()}
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
