#!/usr/bin/env python3
"""Bounded exact failed-literal preprocessing; every clause requires RUP checking."""
import datetime,hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/tmp/oec/pequalnp-pilot-18');OUT=ROOT/'orch/S06';PARENT=ROOT/'original-dag-strong/original.cnf'
EXPECTED='38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(PARENT)==EXPECTED
raw=PARENT.read_bytes();body=raw.split(b'\n',1)[1]
meta=json.loads(PARENT.with_suffix('.json').read_text());n=meta['variables'];nc=meta['clauses']
root=(OUT/'root-units.drat').read_bytes()
manifest={'parent_sha256':EXPECTED,'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cases':[],'scope':'Only replay-checked RUP additions; no SAT or UNSAT claim.'}
full=root
for name in ['AAAA','AOAA','AAOA','AAAO']:
 cube=[v if c=='A' else -v for c,v in zip(name,meta['ops'][17:])]
 cnf=OUT/f'probe-{name}.cnf';local=OUT/f'probe-{name}.drat';stats=OUT/f'probe-{name}.tsv'
 cnf.write_bytes(f'p cnf {n} {nc+len(root.splitlines())+4}\n'.encode()+body+root+''.join(f'{u} 0\n' for u in cube).encode())
 cmd=[str(OUT/'probe'),str(cnf),str(OUT/'all-vars.txt'),str(local),str(stats),'45']
 with (OUT/f'probe-{name}.stdout').open('w') as o,(OUT/f'probe-{name}.stderr').open('w') as e:
  proc=subprocess.run(cmd,stdout=o,stderr=e,timeout=55)
 assert proc.returncode in [0,20]
 lifted=[]
 for line in local.read_text().splitlines():
  vals=list(map(int,line.split()));assert vals[-1]==0
  cl=[-u for u in cube]+vals[:-1]
  lifted.append(' '.join(map(str,cl))+' 0\n')
 data=''.join(lifted).encode();(OUT/f'lifted-{name}.drat').write_bytes(data);full+=data
 manifest['cases'].append({'case':name,'cube':cube,'cnf_sha256':sha(cnf),'local_proof_sha256':sha(local),'lifted_proof_sha256':sha(OUT/f'lifted-{name}.drat'),'added_clauses':len(lifted),'exit_code':proc.returncode,'stdout':(OUT/f'probe-{name}.stdout').read_text()})
proof=OUT/'combined.drat';proof.write_bytes(full)
aug=OUT/'augmented.cnf';aug.write_bytes(f'p cnf {n} {nc+len(full.splitlines())}\n'.encode()+body+full)
manifest.update(root_statistics=json.loads((OUT/'root-probe.stdout').read_text()),new_clauses=len(full.splitlines()),proof_sha256=sha(proof),augmented_cnf_sha256=sha(aug),source_sha256=sha(OUT/'probe.cpp'),builder_sha256=sha(Path(__file__)))
(OUT/'package.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
