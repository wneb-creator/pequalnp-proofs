import hashlib,json,subprocess
from pathlib import Path
R=Path('/tmp/oec/pequalnp-pilot-18');O=R/'orch/S06';D=O/'certified-subcases';D.mkdir(exist_ok=True)
parent=R/'original-dag-strong/original.cnf';raw=parent.read_bytes();h,b=raw.split(b'\n',1);n,nc=map(int,h.split()[2:]);checker=R/'solver/dsr-trim/bin/dsr-trim'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(parent)=='38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08'
assert sha(checker)=='e6894b5b74ac2c09b494344f397ec5111547aaa782cdb399f1a8b6835ecef84b'
proof=D/'subcases.drat';proof.write_bytes((O/'strong.drat').read_bytes()+b'0\n');meta=json.loads(parent.with_suffix('.json').read_text());cases=[]
for gate in range(1,17):
 v=meta['rights'][gate][1];stem=D/f'gate-{gate:02d}-right-input1';cnf=stem.with_suffix('.cnf');cnf.write_bytes(f'p cnf {n} {nc+1}\n'.encode()+b+f'{v} 0\n'.encode())
 cmd=[str(checker),'--forward','--rup-only',str(cnf),str(proof)]
 with stem.with_suffix('.stdout').open('w') as out,stem.with_suffix('.stderr').open('w') as err:
  p=subprocess.run(cmd,stdout=out,stderr=err,timeout=10)
 verdict=[x for x in stem.with_suffix('.stdout').read_text().splitlines() if x.startswith('s ')]
 assert p.returncode==0 and verdict==['s VERIFIED UNSAT']
 cases.append({'gate':gate,'assumption':v,'exact_statement':f'No satisfying assignment of parent CNF has variable {v}=true (rights[{gate}][1]).','cnf_sha256':sha(cnf),'checker_command':cmd,'exit_code':p.returncode,'verdict':verdict,'stdout_sha256':sha(stem.with_suffix('.stdout')),'stderr_sha256':sha(stem.with_suffix('.stderr'))})
report={'parent_sha256':sha(parent),'checker_sha256':sha(checker),'proof_sha256':sha(proof),'proof_bytes':proof.stat().st_size,'proof_clauses':len(proof.read_text().splitlines()),'strong_cnf_sha256':sha(O/'strong.cnf'),'strong_proof_sha256':sha(O/'strong.drat'),'cases':cases,'scope':'16 exact overlapping subcases refuted by replayable RUP, not an exhaustive partition or assigned-shard/global UNSAT.'}
(D/'manifest.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='cases'},indent=2))
