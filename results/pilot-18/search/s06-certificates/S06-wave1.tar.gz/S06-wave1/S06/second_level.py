import hashlib,json,subprocess
from pathlib import Path
R=Path('/tmp/oec/pequalnp-pilot-18');O=R/'orch/S06';p=R/'original-dag-strong/original.cnf';raw=p.read_bytes();hdr,body=raw.split(b'\n',1);n,nc=map(int,hdr.split()[2:]);meta=json.loads(p.with_suffix('.json').read_text())
assert hashlib.sha256(raw).hexdigest()=='38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08'
proof=(O/'combined.drat').read_bytes();manifest=[]
vars=[15,16,14,27]+[meta['rights'][g][1] for g in range(16,0,-1)]
for v in vars:
 prefix=f'second-{v}';cnf=O/(prefix+'.cnf');local=O/(prefix+'.drat')
 cnf.write_bytes(f'p cnf {n} {nc+len(proof.splitlines())+1}\n'.encode()+body+proof+f'{v} 0\n'.encode())
 with (O/(prefix+'.stdout')).open('w') as out,(O/(prefix+'.stderr')).open('w') as err:
  res=subprocess.run([str(O/'probe'),str(cnf),str(O/'all-vars.txt'),str(local),str(O/(prefix+'.tsv')),'3'],stdout=out,stderr=err,timeout=10)
 assert res.returncode in [0,20]
 lines=local.read_text().splitlines();proof+=''.join(f'{-v} '+line+'\n' for line in lines).encode()
 manifest.append({'assumption':v,'exit_code':res.returncode,'learned_clauses':len(lines),'local_cnf_sha256':hashlib.sha256(cnf.read_bytes()).hexdigest(),'stdout':(O/(prefix+'.stdout')).read_text()})
(O/'strong.drat').write_bytes(proof)
(O/'strong.cnf').write_bytes(f'p cnf {n} {nc+len(proof.splitlines())}\n'.encode()+body+proof)
(O/'second-level.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))
