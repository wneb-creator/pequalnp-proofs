"""Plumbing controls only: fake runner/validator; no solver or Lean starts."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import unittest

BASE=Path('/tmp/oec/pequalnp-pilot-18/orch/S06')
spec=importlib.util.spec_from_file_location('s06_controller',BASE/'serial_controller.py')
C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)
CONTROLS=BASE/'controller-controls';CONTROLS.mkdir(exist_ok=True)

RUNNER=r'''
import hashlib,json,os,shutil,signal,sys,time
from pathlib import Path
cnf=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir()
def arg(n):return sys.argv[sys.argv.index(n)+1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
mode=json.loads(cnf.with_suffix('.json').read_text())['mode']
(out/'test-started').write_text(str(os.getpid()))
if mode in ['hang','ignore_term']:
 if mode=='ignore_term':signal.signal(signal.SIGTERM,signal.SIG_IGN)
 while True:time.sleep(.05)
shutil.copyfile(cnf,out/'instance.cnf')
sat=mode in ['sat','sat_bad_validator','sat_bad_size','sat_bad_hash','sat_failed_runner']
unsat=mode in ['unsat','wrong_exit','valid_only','forged_result','missing_logs','missing_bytes','wrong_bytes','wrong_log_hash']
sv=['s SATISFIABLE'] if sat else (['s UNSATISFIABLE'] if unsat else ['s UNKNOWN'])
cv=['s VERIFIED UNSAT'] if unsat and mode!='valid_only' else ['s VALID']
for name,lines in [('solver.stdout.txt',sv),('checker.stdout.txt',cv),('solver.stderr.txt',[]),('checker.stderr.txt',[])]:
 (out/name).write_text(''.join(x+'\n' for x in lines))
status='SAT_UNVALIDATED' if sat else ('VERIFIED_UNSAT' if unsat else ('ABORTED' if mode=='limit' else 'UNKNOWN'))
code=10 if sat else (0 if unsat else (3 if mode=='limit' else 2))
r={'status':status,'accepted_CNF_UNSAT':unsat,'proof_stream_complete':True,'reason':'wall_time_limit' if mode=='limit' else None,
 'solver_exit':10 if sat else (20 if unsat else 0),'checker_exit':0,'solver_verdicts':sv,'checker_verdicts':cv,
 'cnf_sha256':sha(cnf),'solver_sha256':sha(arg('--solver')),'checker_sha256':sha(arg('--checker')),
 'logs':{name:{'sha256':sha(out/name),'bytes':(out/name).stat().st_size} for name in ['solver.stdout.txt','solver.stderr.txt','checker.stdout.txt','checker.stderr.txt']}}
if mode=='wrong_exit':code=2
if mode=='forged_result':r['proof_stream_complete']=False
if mode=='missing_logs':r['logs']={}
if mode=='missing_bytes':r['logs']['solver.stdout.txt'].pop('bytes')
if mode=='wrong_bytes':r['logs']['solver.stdout.txt']['bytes']+=1
if mode=='wrong_log_hash':r['logs']['solver.stdout.txt']['sha256']='0'*64
if mode=='sat_failed_runner':code=1;r['status']='FAILED'
(out/'result.json').write_text(json.dumps(r))
sys.exit(code)
'''
VALIDATOR=r'''
import hashlib,json,sys
from pathlib import Path
cnf=Path(sys.argv[1]);model=Path(sys.argv[2]);meta=json.loads(cnf.with_suffix('.json').read_text())
(cnf.parent/'validator-invoked').write_text('yes')
if meta['mode']=='sat_bad_validator':sys.exit(1)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r={'status':'VALIDATED','meets_posted_gate_limit':meta['mode']!='sat_bad_size','verified_inputs_per_circuit':2048,
 'provenance':{'cnf_sha256':sha(cnf),'metadata_sha256':sha(cnf.with_suffix('.json')),'kissat_stdout_sha256':sha(model)}}
if meta['mode']=='sat_bad_hash':r['provenance']['cnf_sha256']='0'*64
cnf.with_suffix('.validated.json').write_text(json.dumps(r))
'''

class Controls(unittest.TestCase):
 def fixture(self,modes):
  d=Path(tempfile.mkdtemp(prefix=self._testMethodName+'-',dir=CONTROLS));pins={}
  for name,source in [('runner',RUNNER),('validator',VALIDATOR),('solver','fake solver identity'),('checker','fake checker identity')]:
   path=d/(name+'.py');path.write_text(source);pins[name]=(path,C.digest(path))
  cases=[]
  for i,mode in enumerate(modes):
   cnf=d/f'fixture-{i}.cnf';cnf.write_text('p cnf 1 1\n1 0\n');cnf.with_suffix('.json').write_text(json.dumps({'mode':mode}))
   cases.append({'wire':i,'cube':[1],'cnf':str(cnf),'cnf_sha256':C.digest(cnf),'metadata_sha256':C.digest(cnf.with_suffix('.json'))})
  return d,pins,cases
 def execute(self,modes,**kw):
  d,pins,cases=self.fixture(modes)
  rc=C.run_queue(d/'run',cases,pins=pins,abort=d/'abort',search_seconds=.1,case_seconds=5,**kw)
  return d,rc,json.loads((d/'run/result.json').read_text())
 def test_serial_verdicts_progress_and_no_case13(self):
  d,rc,r=self.execute(['unsat','limit','unknown','unsat'])
  self.assertEqual(rc,0);self.assertEqual([x['status'] for x in r['cases']],['VERIFIED_UNSAT','TIME_LIMIT','UNKNOWN','VERIFIED_UNSAT'])
  self.assertEqual(r['verified_unsat_count'],2);self.assertFalse(r['all_scheduled_cases_verified_unsat'])
  events=[json.loads(x) for x in (d/'run/events.jsonl').read_text().splitlines()]
  self.assertEqual(sum(x['event']=='case_finished' for x in events),4)
  self.assertNotIn(13,C.ORDER);self.assertEqual(len(C.ORDER),17)
 def test_reject_false_acceptance_and_stop_queue(self):
  for mode in ['wrong_exit','valid_only','forged_result','missing_logs','missing_bytes','wrong_bytes','wrong_log_hash']:
   with self.subTest(mode=mode):
    d,rc,r=self.execute([mode,'unsat']);self.assertEqual(rc,1);self.assertEqual(r['verified_unsat_count'],0);self.assertEqual(len(r['cases']),1)
 def test_sat_stops_queue_and_full_validator_is_invoked(self):
  for mode in ['sat','sat_failed_runner']:
   with self.subTest(mode=mode):
    d,rc,r=self.execute([mode,'unsat']);self.assertEqual(rc,10);self.assertEqual(len(r['cases']),1)
    self.assertTrue((d/'run/case-00/validator-invoked').exists());self.assertEqual(r['status'],'VALIDATED_SAT')
    self.assertFalse(Path(r['cases'][0]['runner_execution']['command'][2]).with_suffix('.validated.json').parent==d)
 def test_invalid_candidate_size_hash_or_validator_rejection(self):
  for mode in ['sat_bad_validator','sat_bad_size','sat_bad_hash']:
   with self.subTest(mode=mode):
    d,rc,r=self.execute([mode,'unsat']);self.assertEqual(rc,1);self.assertEqual(len(r['cases']),1);self.assertEqual(r['status'],'SAT_NOT_VALIDATED')
 def test_preexisting_abort_starts_no_process(self):
  d,pins,cases=self.fixture(['unsat']);(d/'abort').touch()
  self.assertEqual(C.run_queue(d/'run',cases,pins=pins,abort=d/'abort'),3)
  r=json.loads((d/'run/result.json').read_text());self.assertEqual(r['cases'],[])
 def test_hash_mismatch_starts_no_process(self):
  d,pins,cases=self.fixture(['unsat']);Path(cases[0]['cnf']).write_text('altered')
  self.assertEqual(C.run_queue(d/'run',cases,pins=pins,abort=d/'abort'),1)
  self.assertFalse((d/'run/case-00').exists())
 def test_existing_output_is_refused(self):
  d,pins,cases=self.fixture(['unsat']);(d/'run').mkdir();(d/'run/marker').write_text('preserve')
  with self.assertRaises(FileExistsError):C.run_queue(d/'run',cases,pins=pins,abort=d/'abort')
  self.assertEqual((d/'run/marker').read_text(),'preserve')
 def test_abort_terminates_active_worker(self):
  d,pins,cases=self.fixture(['hang','unsat']);timer=threading.Timer(.25,lambda:(d/'abort').touch());timer.start()
  try:rc=C.run_queue(d/'run',cases,pins=pins,abort=d/'abort',case_seconds=5)
  finally:timer.cancel();timer.join()
  r=json.loads((d/'run/result.json').read_text());self.assertEqual(rc,3);self.assertEqual(len(r['cases']),1)
  self.assertIsNotNone(r['cases'][0]['runner_execution']['exit_code'])
 def test_deadline_escalates_and_stops_queue(self):
  d,pins,cases=self.fixture(['ignore_term','unsat'])
  rc=C.run_queue(d/'run',cases,pins=pins,abort=d/'abort',case_seconds=2.3)
  r=json.loads((d/'run/result.json').read_text());self.assertEqual(rc,1);self.assertEqual(len(r['cases']),1)
  self.assertEqual(r['cases'][0]['runner_execution']['exit_code'],-9)
  self.assertLess(r['cases'][0]['elapsed_seconds'],3.5)

if __name__=='__main__':unittest.main(verbosity=2)
