#!/usr/bin/env python3
"""Coordinator-invoked serial AAAA cube search. No worker starts on import/preflight.

CLI: serial_controller.py preflight
     serial_controller.py run NEW_OUTPUT_DIRECTORY
Production paths, hashes, cube order and bounds are fixed below. No network calls.
"""
import argparse
import ctypes
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path('/tmp/oec/pequalnp-pilot-18')
OWN = ROOT/'orch/S06'
PARTITION = OWN/'AAAA-right17-partition'
ABORT = ROOT/'DESK_ERROR.response'
ORDER = list(range(14,30)) + [12]
SEARCH_SECONDS = 20
OVERHEAD_SECONDS = 30
CASE_SECONDS = SEARCH_SECONDS + OVERHEAD_SECONDS
PINS = {
 'manifest': (PARTITION/'manifest.json', '571bbb81339f2538aaeb9c013a0117db7d526ac485ed44af0f5cd335356d5213'),
 'parent': (ROOT/'original-dag-strong/original.cnf', '38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08'),
 'rup': (OWN/'suffix-fanin/lifted-all.drat', 'f319ae4b04ce7c6910389dc7f60ed61c353417192c47a44def9b35cc784683c8'),
 'runner': (ROOT/'lean-setup/run_checked_kissat.py', '535ff6e32a68a31eefa1545f031483d0e9b73acd79066d1bbb2a2f42c86685bb'),
 'validator': (ROOT/'lean-setup/validate_sat_candidate.py', 'b807c1a580ce1fa49da51d859e6bc5d94bab2f9f0cd359c35cef35686f826529'),
 'solver': (ROOT/'lean-4.36.0-linux/bin/cadical', '2a0137451efde370d67b88aec26f1e902870f095b1204b07049a103bc6bbd647'),
 'checker': (ROOT/'solver/dsr-trim/bin/dsr-trim', 'e6894b5b74ac2c09b494344f397ec5111547aaa782cdb399f1a8b6835ecef84b'),
}


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def atomic_json(path, value):
    temp = path.with_suffix(path.suffix+'.tmp')
    with temp.open('w') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
    os.replace(temp, path)


def verify_pins(pins):
    for name, (path, expected) in pins.items():
        require(Path(path).is_file() and not Path(path).is_symlink(), name+' must be a regular nonsymlink file')
        require(digest(path) == expected, name+' SHA256 mismatch')


def verify_case(case):
    path = Path(case['cnf'])
    require(not path.is_symlink() and not path.with_suffix('.json').is_symlink(), 'symlink case input')
    require(digest(path) == case['cnf_sha256'], 'case CNF SHA256 mismatch')
    require(digest(path.with_suffix('.json')) == case['metadata_sha256'], 'case metadata SHA256 mismatch')


def preflight():
    verify_pins(PINS)
    manifest = json.loads(PINS['manifest'][0].read_text())
    require(manifest['proposed_order'] == ORDER, 'cube order mismatch')
    require(manifest['parent_sha256'] == PINS['parent'][1] and manifest['rup_proof_sha256'] == PINS['rup'][1], 'provenance mismatch')
    cases = {case['wire']: case for case in manifest['cases']}
    require(len(cases) == 18 and set(cases) == set(range(12,30)), 'partition case set mismatch')
    ordered = []
    for wire in ORDER:
        case = cases[wire]
        require(Path(case['cnf']) == PARTITION/f'case-{wire:02d}.cnf', 'case path mismatch')
        require(case['already_refuted_original_plus_cube'] is False, 'unexpected already-solved case')
        verify_case(case); ordered.append(case)
    return ordered


def verdicts(path):
    if not path.exists():
        return []
    return [line.strip() for line in path.read_text(errors='replace').splitlines() if line.startswith('s ')]


def parent_death(parent):
    def setup():
        libc = ctypes.CDLL(None, use_errno=True)
        if libc.prctl(1, signal.SIGTERM, 0, 0, 0) != 0 or os.getppid() != parent:
            os._exit(125)
    return setup


def stop_process(proc, grace=2.0):
    if proc.poll() is None:
        try: os.killpg(proc.pid, signal.SIGTERM)
        except ProcessLookupError: pass
        try: proc.wait(timeout=grace)
        except subprocess.TimeoutExpired:
            try: os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError: pass
            proc.wait()


def supervise(command, directory, label, deadline, stop, abort, on_started):
    started = time.monotonic(); proc = None; reason = None
    with (directory/(label+'.stdout')).open('xb') as stdout, (directory/(label+'.stderr')).open('xb') as stderr:
        try:
            if stop[0] or abort.exists():
                return {'exit_code':None, 'reason':stop[0] or 'external_abort_file', 'elapsed_seconds':0.0, 'command':command}
            proc = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                cwd=directory, start_new_session=True, preexec_fn=parent_death(os.getpid()))
            on_started(proc.pid)
            while proc.poll() is None:
                if stop[0] or abort.exists():
                    reason = stop[0] or 'external_abort_file'; break
                # Reserve two seconds of this case's total bound for termination.
                if time.monotonic() >= deadline-2:
                    reason = 'controller_case_deadline'; break
                time.sleep(0.05)
        finally:
            if proc is not None:
                stop_process(proc)
    return {'exit_code':proc.returncode if proc else None, 'reason':reason,
            'elapsed_seconds':round(time.monotonic()-started,6), 'command':command,
            'stdout_sha256':digest(directory/(label+'.stdout')), 'stderr_sha256':digest(directory/(label+'.stderr'))}


def read_report(path):
    if not path.exists(): return None
    data = json.loads(path.read_text())
    require(isinstance(data, dict), 'result is not an object')
    return data


def classify(execution, report, directory, case, pins):
    solver_status = verdicts(directory/'run/solver.stdout.txt')
    checker_status = verdicts(directory/'run/checker.stdout.txt')
    sat = execution['exit_code'] == 10 or 's SATISFIABLE' in solver_status or (report and
        (report.get('status') == 'SAT_UNVALIDATED' or report.get('solver_exit') == 10))
    if sat: return 'SAT_INDICATION'
    if execution['reason']: return 'CONTROLLER_ABORTED'
    if report is None: return 'MISSING_RESULT'
    identities = {'cnf_sha256':case['cnf_sha256'], 'solver_sha256':pins['solver'][1], 'checker_sha256':pins['checker'][1]}
    require(all(report.get(k)==v for k,v in identities.items()), 'runner result identity mismatch')
    require(digest(directory/'run/instance.cnf') == case['cnf_sha256'], 'runner snapshot changed')
    require(report.get('solver_verdicts') == solver_status and report.get('checker_verdicts') == checker_status, 'runner verdict/log mismatch')
    require(set(report.get('logs', {})) == {'solver.stdout.txt','solver.stderr.txt','checker.stdout.txt','checker.stderr.txt'}, 'runner result missing full log bindings')
    for name, item in report.get('logs', {}).items():
        require(name in ['solver.stdout.txt','solver.stderr.txt','checker.stdout.txt','checker.stderr.txt'], 'unexpected runner log name')
        require(type(item.get('bytes')) is int and item['bytes'] == (directory/'run'/name).stat().st_size, 'runner log byte count mismatch')
        require(digest(directory/'run'/name) == item['sha256'], 'runner log SHA256 mismatch')
    if (execution['exit_code'] == 0 and report.get('status') == 'VERIFIED_UNSAT' and
        report.get('accepted_CNF_UNSAT') is True and report.get('proof_stream_complete') is True and
        report.get('reason') is None and report.get('solver_exit') == 20 and report.get('checker_exit') == 0 and
        solver_status == ['s UNSATISFIABLE'] and checker_status == ['s VERIFIED UNSAT']):
        return 'VERIFIED_UNSAT'
    if execution['exit_code'] == 2 and report.get('status') == 'UNKNOWN' and report.get('accepted_CNF_UNSAT') is False:
        return 'UNKNOWN'
    if execution['exit_code'] == 3 and report.get('status') == 'ABORTED' and report.get('reason') == 'wall_time_limit' and report.get('accepted_CNF_UNSAT') is False:
        return 'TIME_LIMIT'
    return 'RUNNER_FAILURE'


def valid_candidate(report, cnf, model, case):
    return (report is not None and report.get('status') == 'VALIDATED' and
        report.get('meets_posted_gate_limit') is True and report.get('verified_inputs_per_circuit') == 2048 and
        report.get('provenance') == {'cnf_sha256':case['cnf_sha256'], 'metadata_sha256':case['metadata_sha256'], 'kissat_stdout_sha256':digest(model)})


def run_queue(output, cases, pins=PINS, abort=ABORT, search_seconds=SEARCH_SECONDS, case_seconds=CASE_SECONDS):
    output.mkdir(mode=0o700)  # Fresh exclusive directory; never resume/overwrite.
    stop = [None]; handlers = {}
    def handler(sig, _frame): stop[0] = 'signal_'+signal.Signals(sig).name
    for sig in [signal.SIGINT, signal.SIGTERM]:
        handlers[sig] = signal.signal(sig, handler)
    state = {'started_utc':utc(), 'status':'STARTING', 'cases':[], 'order':[c['wire'] for c in cases],
        'source_sha256':digest(Path(__file__)), 'pins':{k:{'path':str(v[0]),'sha256':v[1]} for k,v in pins.items()},
        'limits':{'solver_checker_wall_seconds':search_seconds,'total_case_seconds':case_seconds,'concurrency':1},
        'scope':'Only scheduled AAAA cubes; no full-shard/global/Lean acceptance.'}
    def persist(event):
        state['updated_utc'] = utc()
        atomic_json(output/'progress.json', state)
        with (output/'events.jsonl').open('a') as log:
            log.write(json.dumps({'utc':utc(),'event':event,'status':state['status'],'completed_cases':sum('finished_utc' in c for c in state['cases'])})+'\n')
            log.flush(); os.fsync(log.fileno())
    exit_code = 1
    try:
        persist('created')
        for case in cases:
            if stop[0] or abort.exists():
                state.update(status='ABORTED', reason=stop[0] or 'external_abort_file'); exit_code=3; break
            verify_pins(pins); verify_case(case)
            directory = output/f"case-{case['wire']:02d}"; directory.mkdir()
            cnf = directory/'input.cnf'
            shutil.copyfile(case['cnf'], cnf); shutil.copyfile(Path(case['cnf']).with_suffix('.json'), cnf.with_suffix('.json'))
            local_case = dict(case, cnf=str(cnf)); verify_case(local_case)
            record = {'wire':case['wire'], 'cube':case['cube'], 'cnf_sha256':case['cnf_sha256'], 'metadata_sha256':case['metadata_sha256'], 'started_utc':utc(), 'status':'RUNNING'}
            state['cases'].append(record); state['status']='RUNNING'; persist('case_started')
            started=time.monotonic(); deadline=started+case_seconds
            command=[sys.executable,str(pins['runner'][0]),str(cnf),str(directory/'run'),
                '--solver',str(pins['solver'][0]),'--solver-arg=--unsat','--checker',str(pins['checker'][0]),
                '--checker-sha256',pins['checker'][1],'--cnf-sha256',case['cnf_sha256'],
                '--max-seconds',str(search_seconds),'--solver-memory-mb','1024','--checker-memory-mb','2048','--abort-file',str(abort)]
            def runner_started(pid): record['runner_pid']=pid; persist('runner_started')
            execution=supervise(command,directory,'runner',deadline,stop,abort,runner_started)
            record['runner_execution']=execution
            report=read_report(directory/'run/result.json'); record['runner_result']=report
            if report is not None: record['runner_result_sha256']=digest(directory/'run/result.json')
            record['status']=classify(execution,report,directory,case,pins)
            if record['status']=='SAT_INDICATION':
                # Stop the queue for every SAT signal, including a bad checker outcome.
                state['status']='SAT_STOP'; persist('sat_detected')
                verify_pins(pins); verify_case(local_case)
                require(digest(directory/'run/instance.cnf')==case['cnf_sha256'], 'SAT snapshot changed')
                model=directory/'run/solver.stdout.txt'
                command=[sys.executable,str(pins['validator'][0]),str(cnf),str(model)]
                def validator_started(pid): record['validator_pid']=pid; persist('validator_started')
                validation=supervise(command,directory,'validator',min(deadline,time.monotonic()+30),stop,abort,validator_started)
                record['validator_execution']=validation
                candidate=read_report(cnf.with_suffix('.validated.json')); record['validation_report']=candidate
                good=validation['exit_code']==0 and validation['reason'] is None and valid_candidate(candidate,cnf,model,case)
                record['status']='VALIDATED_SAT' if good else 'SAT_NOT_VALIDATED'
                state['status']=record['status']; exit_code=10 if good else 1
            verify_pins(pins); verify_case(local_case)
            require(digest(Path(__file__)) == state['source_sha256'], 'controller source changed')
            record.update(finished_utc=utc(),elapsed_seconds=round(time.monotonic()-started,6))
            atomic_json(directory/'case-result.json',record); persist('case_finished')
            if record['status'] in ['VALIDATED_SAT','SAT_NOT_VALIDATED']: break
            if stop[0] or abort.exists():
                state.update(status='ABORTED',reason=stop[0] or 'external_abort_file');exit_code=3;break
            if record['status'] not in ['VERIFIED_UNSAT','UNKNOWN','TIME_LIMIT']:
                state.update(status='STOPPED_FAILURE',reason=record['status']);exit_code=1;break
        else:
            state['status']='COMPLETED';exit_code=0
    except Exception as error:
        state.update(status='FAILED',error_type=type(error).__name__,error=str(error));exit_code=1
        if state['cases'] and 'finished_utc' not in state['cases'][-1]:
            state['cases'][-1].update(status='FAILED',finished_utc=utc(),error_type=type(error).__name__,error=str(error))
            atomic_json(output/f"case-{state['cases'][-1]['wire']:02d}"/'case-result.json',state['cases'][-1])
    finally:
        state['finished_utc']=utc()
        state['verified_unsat_count']=sum(c['status']=='VERIFIED_UNSAT' for c in state['cases'])
        state['all_scheduled_cases_verified_unsat']=len(state['cases'])==len(cases) and all(c['status']=='VERIFIED_UNSAT' for c in state['cases'])
        state['controller_exit_code']=exit_code
        persist('finished');atomic_json(output/'result.json',state)
        for sig,prior in handlers.items():signal.signal(sig,prior)
    return exit_code


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=['preflight','run']);parser.add_argument('output',nargs='?',type=Path)
    args=parser.parse_args()
    cases=preflight()
    if args.mode=='preflight':
        require(args.output is None,'preflight takes no output directory')
        print(json.dumps({'status':'PREFLIGHT_PASS','cases':len(cases),'order':ORDER,'source_sha256':digest(Path(__file__)),'abort_sentinel_present':ABORT.exists(),'solver_launched':False}));return 0
    require(args.output is not None,'run requires a fresh output directory')
    output=args.output.absolute()
    require(output.parent.resolve().is_relative_to(OWN.resolve()),'output must be under S06 scratch')
    require(not output.exists() and not output.is_symlink(),'output already exists')
    code=run_queue(output,cases)
    print(json.dumps({'controller_exit':code,'result':str(output/'result.json')}));return code


if __name__=='__main__':
    sys.exit(main())
