# S04 original-shard completeness red-team

Verdict: **PASS, with the precise mathematical scope below.** No unsound cut or current metadata/model mismatch was found. This is an independent source/mathematics review plus bounded composition controls, not a Lean normalization proof, a SAT verdict, or a global refutation. Completed 2026-11-24 about 03:30 UTC, within the requested first 20 minutes.

The implication reviewed is: an original-model circuit computing the posted graph function, having at most 21 gates, first junk AND at index 17 and another junk AND later, gives a model of the specified originalDAG CNF after the reviewed normalizations. The all-live step depends on the clean-circuit lower bound 22 and its constant-propagation extension. Earlier-junk and one-junk circuits are outside this implication. A future `verifiedCNFUNSAT` result for these bytes would exclude this shard under those mathematical reductions; it would not be a Lean global refutation of the posted existential.

## Exact artifact binding

| Artifact | SHA-256 |
|---|---|
| Running originalDAG CNF | `38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08` |
| Current `original-dag-strong/original.json` | `5a430e86affc12584f964af39920201684505bafca4d34c1d30e6a10de3b9f51` |
| Actual `search_l1342_shard17_ancestorreverse.py` | `b10d8832060d1c554fd3daa563b7159d515a3c55adc49718989eaa9bd0c2f24f` |
| Actual `build_original_strong.py` | `9e5ae318f33ff8fea98dd8c4a201c82674023102340fdbe86bd69083419e33f1` |
| Ancestor-support helper | `6bd7f7a2120d7d5446d9609a0551308b224d91d23463354514cefe631803e38b` |

Fresh generation from the repository sources reproduced all 11968 variables and 114566 clauses byte for byte. The generated metadata also equaled the current metadata as a complete parsed object. This checks the original DAG before the generator's fixed-tail rewriting; the seven formula templates do not enter this artifact. The builder's parent metadata is not independently hash-pinned by the builder itself, but the current exact metadata is bound above and reproduced, so this is not a current mismatch.

The actual Lean evaluator was read: unavailable reads are FALSE, nullary AND is TRUE, nullary OR is FALSE, unary gates copy, and output indices are unrestricted. The augmented 13-source binary model can represent every raw gate without increasing its count. Free TRUE makes it an overapproximation; a SAT candidate still requires original-model normalization and gate counting. These conventions do not invalidate the UNSAT direction.

## Normalizations and their composition

Productivity is safe only in the clean prefix. A zero-support clean-prefix operand is false on all independent inputs. Replacing an AND containing it by that operand preserves those values and increases edge values. Cleanliness and suffix junk status therefore survive.

Dominance compares a prefix AND against an earlier zero-support prefix gate. The required comparison is only on the 16 edge rows. Replacing the AND by the earlier gate preserves all independent values and cannot reduce an edge value. The positive witness clauses encode exactly the existential failure of this dominance condition; they do not require the witnesses to be equivalences.

For strict OR, equality to an operand on singleton and edge rows is enough to delete the OR: clean-prefix singleton supports determine all nonempty independent values. Duplicate descriptions and OR aliases can also be deleted. Full-support substitution by free TRUE preserves all nonempty values. It can change an intermediate empty-input value, but the correct output remains false on a singleton, so monotonicity keeps its empty-input value false.

A single decreasing measure resolves interaction between the cuts: prune dead prefix gates, sort the remaining core, and delete a core gate whenever productivity, dominance, duplicate-description, absorbed-OR, or full-support canonicalization fails. Recheck after every deletion and re-sort. Every rewrite removes a core gate; none adds one. Once stable, append the required OR-copy chain exactly once. This avoids assuming that separately valid normalizations automatically commute.

If the stable core has k>0 gates, its last gate must feed the suffix, since it is live and has no later core reader. Pad a chain from that gate and redirect one suffix occurrence through its endpoint. If k=0, use any source consumed by the suffix. Every padded copy is live, has a fresh description, and has maximum operand index above all core descriptions. Copies are exempt from strict OR and full-support restrictions, add no ANDs, and occur after every core AND, so they create no new earlier dominance comparison. The four suffix operations and their independent-input values remain unchanged and regain indices 17–20.

Lexicographic ordering by `(right,left,AND-first)` is schedulable: emit the least available key. A newly enabled gate references the just-emitted output, whose wire index exceeds all older operands; its primary key cannot undercut the emitted key. Equal operand pairs can occur for opposite operations, but equal full descriptions are removed. Actual lex equality flags are one-way implications; unequal pairs must be allowed to choose FALSE. The tested auxiliary extension makes that choice explicitly.

The prior output-last/all-live case split was re-read, including the exceptional first-live-junk-at-19 case. If gate 19 is AND(18,18) and 18 is a dirty OR, deleting that alias leaves a clean output cone, contradicted by the clean lower bound. Otherwise a dirty prefix operand allows dead gate 17 to be replaced by a live junk copy without changing the live computation. Dead suffix slots can be filled by junk AND copies, then the prefix can be pruned/padded. This is a target-specific lower-bound argument, not an arbitrary graph or arbitrary-size WLOG.

## Ancestor bounds and suffix restriction

The ancestor flags encode structural transitive dependency, including repeated operands. The partial-edge bound counts the root plus its strict ancestors. For proper support S and accepted residual graph H, its actual constraint is

`|S| + |E(H)| + |cover(H)| <= 2 + number_of_strict_ancestor_gates`.

Moving negative ancestor literals to the left gives precisely the generator's bound `g+2`. Full support remains exempt. The 604 composition controls independently computed ancestor cones and minimum covers, checking 10268 instances of this inequality. The common-neighbor consequence uses productivity: a first descendant AND would require a nonempty opposite support adjacent to every inherited support vertex. Thus no such AND can follow an ancestor support without a common neighbor. Suffix gates are not constrained by this prefix consequence.

The three-suffix-AND cut is valid after all-live normalization. Choose the latest junk AND and an independent input making it true. A live path to the false output must encounter another AND; an OR-only path would propagate TRUE. That later AND is clean by maximality of the chosen junk index. Together with the two junk ANDs, this gives three distinct suffix ANDs. The six pairwise operation clauses say exactly that at most one of the four suffix gates is OR. No one-junk impossibility is used.

## New bounded controls and an adversarial example

The new controls exercise the composition, rather than replaying every old individual-gadget test:

- 600 deterministic random clean-prefix circuits plus four targeted circuits; truth functions are represented on all 2048 inputs.
- 548 full-support deletions, 560 absorbed-OR deletions, 233 unproductive-AND deletions, 21 duplicate deletions, and a targeted dominance deletion. Core sizes 0–11 and 15–17 occur, covering empty-core, single-copy padding, and no-padding endpoints.
- Every retained suffix preserves its nonempty independent-input values, its edge values never decrease, and all final liveness/order/distinctness/productivity/canonicalization checks pass.
- 34 normalized circuits extend to complete assignments satisfying every retained actual CNF clause: 3861992 clause evaluations. Exactly 978 clauses are omitted in these synthetic controls: 970 target-output requirements, the first/second-junk requirements, and six suffix-operation clauses. These samples are not claimed to compute the target. The separate byte reproduction uses the entire unmodified CNF.
- Final run: exit 0, 9.33 seconds, empty stderr. No solver or Lean process was launched.

A concrete counterexample rules out an overstrong proof of dominance, without blocking the actual normalization. Let

`B=x0∧x9`, `C=x2∧x10`, `D=x9∨C`, `g=x0∧D`.

All ANDs are clean; g and B are false on every independent input, and every edge accepted by g is accepted by B. Yet on input `{0,2,10}`, g is TRUE and B is FALSE. Replacing g by B can therefore decrease an intermediate value on a larger positive input. A future Lean proof must use independent-row equality plus edge-row nondecrease, not pointwise equality or pointwise monotone increase. The current review already uses the correct weaker invariant. Similarly, replacing the OR of all eleven inputs by free TRUE changes its empty-input value; final-output monotonicity is essential.

## Evidence files and next direction

All scratch paths below are under `/tmp/oec/pequalnp-pilot-18/orch/S04/`.

- Reproducible control source: `audit_composition.py`, SHA `742d75ca6cde0e8601616dd4d9e9eaefab67eb8bb248275b8f789c40c817be5d`.
- Result and complete final stdout: `composition-result.json`, `composition4.stdout.log`, both SHA `13745e1ce044a791246730732c40571cbafa0d0ac2b766ea2468a0998ca5e8ee`.
- Complete final stderr: `composition4.stderr.log`, empty. Generation log: `recreation.log`. Recreated CNFs and metadata remain in the same owned directory.
- Adversarial scalar check: `semantic-caveats.json`, SHA `b7db36d8fc5990761cc398c28fce01a0ce3d97cd16b29be96a9ca202c49ab3d1`.
- Earlier harness diagnostics are retained as `composition*.stdout.log` and `composition*.stderr.log`. The first two attempts exposed only harness bookkeeping: source-line tagging and arbitrary TRUE defaults for one-way lex flags. Both were corrected before the successful controls.

Read the updated NOTES and S02/S03/S06/S08 reports before this recommendation. There is no completeness reason from this audit to restart the current originalDAG run. S06's checked redundant clauses can be considered with their certificate provenance. The now-compiling 40-row boundary theorem gives a useful basis for future formal normalization: define equality on negative rows and implication on positive edge rows, prove propagation through a fixed monotone suffix, then formalize deletion/prune/pad with its decreasing core count. S02's candidate repairs remain a separate constructive route. Exhausting this shard alone still leaves the global theorem open.

No named proof file, other agent output, worker, lease, credential, remote, or git history was modified. No new Lean fragment is claimed.

## Independent review of S01 consecutive junk: PASS

Additional review requested by the orchestrator at about 03:31 UTC; completed about 03:33 UTC. Reviewed S01 snapshot SHA `26f17ec6c2b3bc13411f42143d3a94b358e627e8fdad64725d9e4742bf4cfbc7`, preserved as `orch/S04/S01-reviewed-snapshot.md`. This verdict covers the main consecutive-junk normalization and its prefix composition. It does not cover S01's additional sorted-chain restrictions or any not-yet-supplied generator/CNF delta.

**The H-clean argument is valid.** In each applicable case the original factorization gives `F = H AND O`, hence `F <= H` pointwise. By definition, clean H is false on every graph-independent input, so `H <= F` pointwise. Thus H=F. Equivalently, if only edge coverage has been recorded, monotonicity takes H from every positive edge to all positive inputs; cleanliness excludes every negative input. Higher-degree terms cannot introduce an exception: any additional accepted input is either positive, where F is already true, or independent, where cleanliness forbids it. No assertion that clean signals have only degree-two terms is needed.

**The prefix-pair contradiction uses exactly the stated clean bound.** When R and T are both prefix wires, `H=R AND T` can be computed by the 17 clean-prefix gates plus one AND. If H is clean and `F=H AND O`, that 18-gate circuit computes F with every AND clean. Propagate free constants and delete aliases without increasing gate count, obtaining an original-model clean circuit, contrary to the lower bound 22. This argument is not applied when one factor is the dirty gate D. In those cases a clean H is instead realized by the retained dirty D, two dirty AND copies, and the clean final AND; there is no illicit appeal to a global clean bound for a dirty circuit.

The reference analysis is exhaustive. In AOAA let D=g17, O=g18, J=g19. Liveness forces J to feed the final AND. If J reads O, write `J=O AND T` and `F=J AND R`. T is prefix, D or O. R cannot be J or O because either would make the output equal the dirty J; thus R is prefix or D. These are all available wires. The cases below preserve the entire output function before prefix normalization.

| Case | Independent check |
|---|---|
| J does not read O | Swapping O/J is topologically valid, preserves all references after remapping, and yields AAOA with junk18. |
| T=O, R=D | If O read D, absorption would make F=D dirty. O therefore uses only prefix wires. D, copy(D), O, copy(D) AND O is live AAOA. |
| T=O, R prefix | D can reach the output only through O, so O=D OR Q. D, copy(D), copy(D) OR Q, R AND that OR is live AAOA; Q=D is allowed. |
| T=D, R prefix | If O reads D, absorb it and use a two-copy D chain before the final R AND D. Otherwise form H=R AND D: dirty H gives D,H,O,H AND O; clean H equals F and gives the same D-copy construction. |
| T prefix, R=D | The preceding case applies with T/R interchanged; no role of a dirty operand is lost. |
| T,R prefix | Liveness forces O to read D. H=R AND T covers F and must be dirty by the 18-clean-gate contradiction. D,H,O,H AND O is live AAOA with junk17 and junk18. |

For AAAA, if gate18 is clean and gate19 dirty, gate19 cannot read gate18 because an AND with a clean operand is clean. Swapping those adjacent gates is therefore valid and gives junk18. In AAOA, gate18 is the only possible second junk. In AAAO, live gate19 is an operand of the clean final OR and must itself be clean, so the second junk again must be gate18. Every constructed suffix contains four gates, is fully live, leaves gate17 dirty, and makes gate18 a dirty AND. Repeated operands and constants cause no omitted port case.

**Prefix composition remains sound.** The suffix rewrites may discard prefix dependencies, so the previously encoded liveness/ancestor variables cannot simply be reused as a Boolean model. Instead prune and normalize the prefix core to a fixed point, then insert the final OR-copy chain as in the earlier audit. Each surviving suffix signal keeps its values on every nonempty independent input, preserving the dirty witnesses at gates17 and18; edge values can only increase. Since the suffix computed F before those prefix steps, the final 40-row values still determine F. Prefix rewrites do not remove suffix-to-suffix edges, so all four suffix gates stay live. The final padding restores their indices and supplies a newly satisfying assignment for exact ancestor flags, cost covers, lex flags and other auxiliaries. No commutation of successive rewrites is assumed.

The safe SAT conclusion is existence of a representative satisfying the additional unit `junk[18]`. It excludes AOAA because junk18 implies AND18. **This unit is a normalization restriction, not an implied clause of the existing originalDAG CNF.** Any checked UNSAT for the new formula must retain the mathematical normalization as part of its interpretation; it cannot be appended to an old RUP/DSR derivation without separately proving a suitable implication. The original solver inputs remain untouched.

The independent bounded control enumerated 259200 syntactic suffix configurations over five independent prefix signals plus FALSE/TRUE, with four representative shapes for D. Of these, 4616 satisfy all-live, junk17, at least two junk ANDs, and the explicit no-clean-prefix-pair-output premise. It checks exact output truth on all 32 assignments, all four suffix gates live, unchanged D, and junk17/junk18 after rewriting. Counts: AAAA2070, AOAA1088, AAOA971, AAAO487. Every listed AOAA branch was exercised, including 126 clean-H collapses and 243 dirty-H cases. These finite controls do not enumerate all possible graph-specific prefix functions; the mathematical argument above supplies that generality.

Evidence in `orch/S04/`: `review_consecutive_junk.py` SHA `2572b8402d419ed6b9fd637bcbe53c64de9b5ca471eaa9e0697e7e449c145c57`; full result with representative before/after gates `consecutive-junk-result.json`; complete logs `consecutive-junk-final.stdout.log` and `consecutive-junk-final.stderr.log` (empty stderr, exit0, under one second). No solver or Lean build was launched. The orchestrator was notified through locked NOTES before this report addition. Next concrete review is the fresh candidate CNF's exact parent-plus-J18 delta and provenance, once supplied.

## Fresh J18 family delta review: PASS

Completed 03:35 UTC, then cross-checked against S01's newly supplied audit at 03:39 UTC. Exact scope: `orch/S01/consecutive-junk-v2/{normalized,AAAA,AAOA,AAAO}`. Generator SHA `3802650c1492cb267a8f8ae5e44715b9b86fe88e642617b85ffbbe857184bb71`; family manifest SHA `fad819eb7f39b301255cb2cedfcadd7d616dd80be15f591b1beea69b4faafb76`.

The normalized file is the original body plus exactly unit3243, with 11968 variables and 114567 clauses. Each operation case is the original body plus unit3243 and its four signed operation units, with 114571 clauses. The operation variables are `[2807,3072,3341,3614]`. All original metadata fields except CNF hash and clause count are preserved. No chain clauses are hidden in the four scoped files.

| File | CNF SHA-256 |
|---|---|
| normalized | `3fefefe3949bc703fc2b9f023be12bc42f1afe7619e8ed5ed63be2f8e7648812` |
| AAAA | `f50627e82144e04dd204302967e5d95b21e7fb6504cf964a35657173eacc3d02` |
| AAOA | `70308894ffc6f4c3b682140c7df3d17ed3035c79dc66f56dc51bd47020004e91` |
| AAAO | `af8cf38d730b3ffaa1245321ce87d3e2dcec43b2a64f180f7962a6f255a4bf29` |

All sixteen Boolean operation assignments were checked: AND17, AND18, and at least three suffix ANDs give exactly these three disjoint cases. Parent-clause preservation is byte exact. Independent review JSON `orch/S04/j18-delta-review.json` SHA `a12ddf32ac70dc5a84f50982bbd7c76b56a6a27b262c937c8ac4cb110c58a599` records all metadata hashes and exact added clauses; complete logs are `j18-delta.stdout.log` / `j18-delta.stderr.log` (empty stderr, exit0). Source `review_j18_delta.py` is retained separately from S01's self-audit. The latter's new source and `encoding-validation.json` agree on all four scoped artifacts.

The metadata's pending-review wording predates this external hash-bound PASS. Keep this review attached rather than treating that wording as a mathematical failure. `AAAA-chain` and `AAAO-chain` remain outside this review. No solver or existing input was modified. Authorized S07 restriction work is reported separately in `S07-restriction.md`.

## Extension at 03:48 UTC: AAAA/AAAO chains PASS

This subsequent review extends the earlier scope to both v2 chain variants. **PASS for the mathematical existence normalizations and exact CNF deltas**, with the degenerate-final-OR repair stated below. No solver or new Lean run was made by S04.

For AAAA, the four live AND gates have at most five external prefix-wire occurrences: among their eight input ports, at least three read suffix gates. Associativity and idempotence express the output as their product. Choose an inclusion-minimal subfamily Q whose product is clean on independent inputs. Removing factors increases the function, while cleanliness bounds the result above by F; hence its product remains exactly F. The empty family is not clean. A one-factor family would give F in the clean prefix, and a two-factor family would add only one clean AND. The clean bound22 excludes both, so 3<=|Q|<=5.

Each retained factor has a private independent witness where all other Q factors are TRUE and it is FALSE. A witness extends to a maximal independent input: the other factors remain TRUE by monotonicity, and the missing factor must remain FALSE because the whole product is clean. Thus the existing 24 negative rows suffice. Distinct retained factors have distinct negative-row functions; no TRUE-like factor is retained.

Sort Q by wire index and repeat its least index until there are five leaf occurrences. The chain's first three AND outputs all omit its greatest retained factor. The same private negative row makes all three outputs TRUE, giving junk17,junk18,junk19. The last output is F. The construction supplies the canonical patterns stated by S01. The implemented inequalities `a<=b<=c<d<e` also admit `a<b=c<d<e`; that additional pattern only weakens the restriction and is safe.

For AAAO, live g19 feeds the final clean OR and is clean. Gate18 must be the second junk AND. Dirty g17/g18 cannot feed the final OR directly, so all three suffix ANDs reach g19 and their branch has at most four external factors. **One omitted case in the original prose needs repair:** the final OR may be `OR(g19,g19)`. Replace this by `OR(FALSE,g19)`, using existing free-FALSE source11. The function and all four suffix gates' liveness are unchanged; the actual chain CNF already permits this value of P. Otherwise the final OR's other operand is directly a clean prefix wire P.

Choose a minimal clean factor subfamily for g19. Its product may be larger than old g19, but remains below F, and `P OR product(Q)` remains F. A one-factor family would yield a clean circuit with at most18 gates; a two-factor family would yield at most19. Hence |Q| is3 or4. Sort it, repeat the least factor if needed, and use the four-factor chain. The private negative witness for its greatest factor makes g17/g18 dirty and g19 clean. P stays clean. This uses only clean22, not a one-junk or arbitrary-circuit22 bound.

**Joint prefix composition:** first prune discarded dependencies and stabilize the prefix core under all reviewed rewrites. Negative functions of every retained factor and P are unchanged; factor minimality and the private witnesses survive. An alias cannot identify two retained Q factors, since their negative functions are distinct. In AAAO it also cannot identify P with a Q factor: P is clean and each Q factor is dirty. If padding is needed, the highest live core gate is a selected factor or P. Attach the final OR-copy chain there and redirect its selected role through the chain endpoint. Then re-sort the retained Q representatives and rebuild the suffix chain, repeating the new least representative as required. Redirect every repeated occurrence of that representative consistently. This preserves padding liveness and avoids claiming that the old sorted occurrence list remains sorted after renumbering. Core lex order and all prefix cuts survive as in the earlier audit; recompute the auxiliary assignments.

The independent exact-delta reconstruction found:

| Case | CNF SHA-256 | Clauses | Added to original |
|---|---|---:|---:|
| AAAA-chain | `41995c72708a950daa154eb3dfa50447b4a4f6ce6199082f14a28a8cfdda1730` |116381|1815|
| AAAO-chain | `a8e94b6cfeaafb8b6c4e01d33e6f552a984e395d224dc3d6281d99cc49850753` |115946|1380|

Both retain11968 variables and every original body byte. Their deltas are J18 plus four operation units, three predecessor-right-port units, six prohibitions on suffix-valued left ports, the signed J19 unit, and the stated sorted-leaf clauses. The latter contribute1800 or1365 clauses. AAAA forces J19; AAAO forces its negation. The final AAAO left port remains an arbitrary prefix source, including FALSE. All source, parent, family and metadata hashes match.

Controls checked6300 leaf-order assignments and1038 factor-permutation/padding configurations on27696 Boolean rows, including padding a factor, padding P and no padding. These controls verify the local normal form; the mathematical argument supplies the general existence implication. Review `orch/S04/chain-review.json` SHA `299f6bdc23ac20e8f9b54cae7eb3a787c1aacf951ab08b8314be212c67f1472d`; source `review_chain_variants.py` SHA `c0059c6e170b5ff5a8c3c55ca82ba5bd8e0148bbccb4e5f5fa972f15a3e15345`; complete logs `chain-review.stdout.log` and `.stderr.log` (empty stderr, exit0). Main received the PASS before launching its new chain run. These remain fresh normalization targets, not implied clauses of the unchanged original CNF.

## Extension at 03:50 UTC: four AAOA forms plus AAAA fallback PASS

**PASS for S01's mathematical coverage and permitted leaf symmetries.** No newly generated AAOA-template CNF is covered by this verdict yet. Four template UNSAT results alone do not exclude every original AAOA circuit: the absorbed cases move to AAAA and require that fallback as well.

Write D=g17, J=g18, O=g19. D/J are dirty ANDs, O is OR, and the final output is `O AND R`. Liveness forces O into the output. R cannot be O: J would reach O through only an OR and make the output dirty. Thus R is a prefix wire, D or J. J either is `D AND C`, with C prefix or D, or is an independent prefix pair.

The following case review covers every available operand, including repeated operands and constants:

| Final R | J shape | Result |
|---|---|---|
| Prefix | D AND C | J must feed O. A prefix other OR operand gives T1. Other operand D or J absorbs the OR and gives the AAAA fallback. If C=D, repeat one prefix factor of D to represent the same product. |
| Prefix | Independent pair | D must be O's other operand, giving T2. |
| D | D AND C | Actually impossible: J<=D and liveness gives J<=O, hence J<=F, contradicting dirty J. S01's extra rewrite branch is harmless but unreachable. |
| D | Independent pair | J must feed O. Other operand D is impossible; J gives an absorbed conjunction/AAAA; a prefix wire gives T3. |
| J | D AND C | O cannot read D or J, since either would make the output J dirty. O has two prefix operands, giving T4, including a repeated factor when J=D. |
| J | Independent pair | D must feed O. Other operand J is impossible; D gives AAAA; a prefix wire gives T3 after swapping the independent dirty pairs into their required outer/inner roles. |

The reviewed schedules are exactly:

| Form | g17 | g18 | g19 | g20 |
|---|---|---|---|---|
| T1: a(b+cde) | c AND d | e AND g17 | b OR g18 | a AND g19 |
| T2: a(bc+de) | b AND c | d AND e | g17 OR g18 | a AND g19 |
| T3: ab(c+de) | a AND b | d AND e | c OR g18 | g17 AND g19 |
| T4: abc(d+e) | a AND b | c AND g17 | d OR e | g18 AND g19 |

For T1/T4 the three-factor product is dirty, so any two-factor subproduct is dirty; sorting that triple preserves both junk gates. For T2 each pair may be sorted and the two OR branches exchanged. For T3 sort the two pairs independently, but do not exchange the outer/inner roles as an extra symmetry. Sort the T4 OR pair freely. Repeated factors are allowed. Every displayed gate has a later reader. Absorption fallbacks are exact pure conjunctions and can use the already reviewed minimal-factor AAAA chain, preserving the junk requirements.

Prune/stabilize/pad remains compatible. Prefix rewrites preserve every leaf's negative values and cannot reduce edge values, so the fixed monotone suffix still computes F on the boundary and retains both junk flags. Redirect a needed leaf through the final prefix copy chain; if the same selected signal occurs several times, use a consistent representative. Rebuild only the template's permitted sorted groups. There is no additional whole-leaf ordering or exchange of T3 roles. All auxiliary flags can be recomputed. Unlike the chain forms, the four AAOA templates may overlap; they form an existence cover together with AAAA, not a disjoint operation partition.

Independent bounded enumeration examined453600 syntactic port configurations over five independent prefix signals plus constants. The5960 cases satisfying all-live, dirty D/J and the necessary no-prefix-pair-output premise all passed exact output equality on32 rows, suffix liveness, dirty17/18 and the approved leaf reorderings. Counts: T1=1260,T2=660,T3=2040,T4=1100,AAAA=900;190720 rows total. The impossible R=D/chained-J branch has no eligible example, as the direct argument predicts. These are algebraic controls, not graph witnesses or exhaustive prefix-function enumeration.

With five distinct terminals, minimal-term-size/intersection signatures are T1=(2,4;1), T2=(3,3;1), T3=(3,4;2), T4=(4,4;3). They are invariant under relabeling and all distinct. Repeating a terminal or using a constant loses a fifth essential variable. Thus removing T3/T4 requires a further graph-specific theorem; generic Boolean rewriting does not suffice.

Review `orch/S04/aaOA-review.json` SHA `43c372c7bf7ce40f262a907323708c182e5e67b58b660ab8ff03922ce4a27b48`; source `review_aaOA_forms.py` SHA `ef6dfe937175278d68c9b8583e14034055d8ae9fa69669fb81ea823bc2da4fdd`; complete logs `aaOA-review.stdout.log` / `.stderr.log` (empty stderr, exit0). Main/S01 were notified through locked NOTES before this report addition. Exact future template deltas require a separate review against these schedules and symmetries.

## Extension at 03:53 UTC: fresh four-AAOA CNF deltas PASS

The subsequently available `orch/S01/aaoa-four-v1/` is now independently reviewed. **PASS** for exact parent preservation, intended topology, permitted symmetry cuts and metadata binding. Source `build_aaoa_shapes.py` SHA `6bcb7e1abdb2c65ffdc9a6a1ced8554509ed2f96a40a756f30d718708256ae63`; family SHA `b05805738736e9b04257657dd8bd39d0fe1c6c31428f191a9fa727fb32109401`. The parent is the reviewed AAOA case SHA `70308894ffc6f4c3b682140c7df3d17ed3035c79dc66f56dc51bd47020004e91`, metadata SHA `0f530e106a5811be95fb87df8802be78bd6a45f91c4ef548acf1d4688c00857f`.

| Case | CNF SHA-256 | Clauses | Added |
|---|---|---:|---:|
| T1 | `422b20c5d9fd5c7eff0ec8a4d7283c70750686da38e3bc3e1dc68e7a1dd5353c` |115450|879|
| T2 | `a295babc305737a921da6bb5c0e990f6c91b2a4c200544d57bcd3abc3e574c3b` |115884|1313|
| T3 | `0ab8fcacbcfe9fa8e094d8db4d0a52eb5d885a032313992ac7c02f312eaffbdf` |115448|877|
| T4 | `661f44876da7e7f8d24d9a06f64ae3708037fc19048e9e20153c47e6a49ea5e3` |115884|1313|

All have11968 variables. Every original AAOA parent clause is byte-preserved; no junk or correctness clause is removed. Fixed selector units implement exactly the table above. Every free terminal port excludes suffix sources. Orders are non-strict: T1/T4's three-factor product is sorted, T4's OR pair is sorted, T3's pairs are independently sorted, and T2 sorts each pair then compares the first leaf of the first pair with the first leaf of the second. The latter is weaker than full lexicographic branch ordering and is justified by the permitted OR-branch exchange. No exchange of T3 outer/inner roles is imposed. Repeated terminals and constants remain available.

Independently reconstructed added clauses match every child byte and each complete `aaoa_added_clauses` field. All inherited metadata fields except hash/count are unchanged. Parent/source/family/CNF/metadata hashes match. Metadata explicitly retains the AAAA fallback requirement and disclaims logical implication of the parent; its pending-review wording predates this external PASS.

In addition to source/delta inspection,1000 canonical selector assignments satisfied1095500 added clauses. Script `orch/S04/review_aaoa_deltas.py` SHA `56fb0f205bbb25fd9d248caed7e13d300636f2dcf8373fac885b571080c5a0e1`; result `aaoa-delta-review.json`; complete logs `aaoa-delta.stdout.log` and `.stderr.log` (empty stderr, exit0, under one second). Main/S01 were notified immediately under the notes lock. No solver or Lean process was started.

The reviewed complete existence cover is now the two chain CNFs plus T1–T4, subject to the documented mathematical normalizations. The four AAOA CNFs by themselves are not an exhaustion of AAOA, and none of these reviews is a solver verdict or a Lean global refutation.

## Joint factor charge: independent mathematical PASS, 04:08 UTC

Reviewed S01's `orch/S01/joint-factor-cost.md`, SHA
`78070f3939d1ac081e67f1b4f18e1655e1aaaed7e4efa4b0d9fa3a4cf24d865f`.
For a minimal family of at least three proper-support full-cover factors in
a productive clean prefix, with distinguished support S and a nonempty
residual graph, the bound is sound:

    m >= |S| + |E(G-S)| + tau(G-S) - 1 + z + d.

Here z counts other factors with no common neighbor, and d counts distinct
owners in S which are the unique common neighbor of another factor's
support. Owners outside S and repeated copies of the same owner receive no
extra charge. This is a mathematical review, not a Lean theorem, implemented
cut, or UNSAT certificate.

Minimality gives incomparable supports because a clean full-cover wire with
proper support T computes exactly F OR OR(T). It also makes each pair dirty:
the pair is a proper subfamily when the family has at least three members.
These two consequences are used at different points and must both survive
any later application to a selected tail family.

If another chosen factor is an ancestor of the distinguished output, choose
the first AND along a path from it. The path up to that AND consists of ORs,
so the entering operand A dominates the chosen factor and accepts every
ambient edge. Productivity and cleanliness force the other operand B to
have a nonempty support contained in the factor's common-neighbor set.
An empty common-neighbor set therefore forbids ancestry. For a unique owner
v, B has support exactly {v}.

If v is in S, set S to zero. On every residual independent input, both B
and A AND B are false; this includes the empty input. On every residual
edge row, A is true, so A AND B equals B. Redirecting this AND's output to
B consequently preserves every downstream wire on all these boundary
rows. It may change larger positive rows, which is harmless: the actual
partial-edge lower bound needs ambient cleanliness, zero output support,
and acceptance of the residual edges. It does not need all intermediate
functions to remain pointwise equal.

Different charged owners give different AND gates. If their paths enter
the same operand of one gate, the other operand's support is contained in
two distinct singleton owner sets, contradicting productivity. If they
enter opposite operands, that AND dominates the conjunction of the two
chosen factors. That conjunction is dirty, contradicting cleanliness.

The overlap concern is resolved by one invariant on the original DAG:
every rewritten wire has its original value on all residual independent
and edge rows. Process gates in topological order, redirecting charged
ANDs to their designated original B operands. Earlier redirections preserve
both operands on the boundary, so the local equality still applies even
when B contains another charged gate. This produces an acyclic circuit and
deletes each charged original node once. If ordinary constant simplification
already deleted a charged node, it has already paid that charge.

Independently mark the pure-S OR nodes and their boundary OR nodes in the
original OR-only ancestry of the distinguished output. Their component
count gives at least |S| distinct OR nodes. Pure-S inputs remain exactly
FALSE after restriction; the marked boundary ORs remain exact aliases of
their other operands. These OR nodes cannot coincide with charged ANDs.
Thus the cone loses at least |S|+t original nodes, even with shared edges,
copies, repeated operands, and constants. FALSE may be included among the
zero sources in the component argument; TRUE cannot enter this OR-only
ancestry because the distinguished support is proper. Eliminate any
remaining constant/alias gates before applying the actual partial-edge
theorem; the nonempty residual guarantees a nonconstant retained output.

Each of the z factors with no common neighbor is outside the cone. Each
owner group without an ancestor representative supplies a distinct output
gate outside it. Minimality excludes raw-input/constant factors and repeated
output nodes; an output cannot represent two distinct unique-owner groups.
These outside gates pay z+d-t. Adding their count to the cone bound proves
the claimed inequality. Dead nodes can only increase m.

For N(1), N(4), N(8), the individual bounds are 16,13,12. Distinguish N(1):
owners4 and8 are distinct and lie in N(1), giving a joint bound18. For
N(3), N(6), N(7), the bounds are17,14,14; owners6 and7 lie in N(3), giving19.
Both triples are minimal (the three triangle singleton inputs are private
witnesses), and their products equal F on all2048 inputs. Thus **all twelve
S02 cases with these exact factors in a17-gate clean productive prefix
can be retired**, regardless of output order or last-three placement. This
does not exclude a larger clean prefix or all possible AAAA factor families.

Independent finite controls are in `orch/S04/review_joint_factor.py`, SHA
`411d45e3f0e0cd6de9e3fe5838ffdad0bdb3346dd4be022ed0eece571c0c10dc`;
results and complete circuits/redirections are in `joint-factor-review.json`.
All4096 triangle product rows, exact residual minimum covers, and eight
ancestor/nonancestor charge cases pass. Eight actual productive clean DAGs
with shared edge gates and overlapping charged cones pass34696 all-wire
boundary comparisons after simultaneous OR/AND deletion. Variants include
repeated OR inputs, FALSE copies, and dead TRUE copies. Full logs are
`joint-factor-review.stdout.log` and `.stderr.log` (empty stderr, exit0).
These controls stress the local proof mechanisms; they are not an exhaustive
enumeration of circuits or a substitute for the mathematical argument.

The original triangle generator delta review was superseded by this
obstruction before any solver launch, following main's direction. Its source
SHA is `e24f9c066ab8a37fa9dbe0d028acb594b8d6d8bc83e9f482fd62e8a390920538`;
its candidate-only status remains. S04 does not claim an independent exact
unit-delta PASS for that retired generator.

Next application: enumerate minimal support families using the joint bound,
then independently review the enumeration's coverage. A later AAAA cut must
either retain this minimal-family witness normalization or explicitly encode
the needed antichain and dirty-pair hypotheses. The joint inequality is not
automatically a logical consequence for every redundant family permitted
by the weaker chain encoding. No active CNF was changed.
