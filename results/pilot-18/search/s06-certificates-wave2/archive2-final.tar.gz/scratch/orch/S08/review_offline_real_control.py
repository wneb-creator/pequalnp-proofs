from pathlib import Path
import datetime,hashlib,json,subprocess,resource,time,fcntl
R=Path('/tmp/oec/pequalnp-pilot-18');S=R/'orch/S06';A=S/'offline-real-case13';D=R/'orch/S08/offline-real-case13-review';D.mkdir(exist_ok=False);W=Path('/workspace/pequalnp-proofs')
h=lambda b:hashlib.sha256(b).hexdigest();bindings={}
def read(p,save=True):
 assert not p.is_symlink() and p.is_relative_to(R);b=p.read_bytes();bindings[str(p)]={'bytes':len(b),'sha256':h(b)}
 if save:
  q=D/'snapshot'/str(p.relative_to(R));q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
 return b
b={p.name:read(p) for p in sorted(A.iterdir()) if p.is_file()};assert len(b)==9
for n in ['offline-real-control.json','offline-real-control.stdout','offline-real-control.stderr']:read(S/n)
r=json.loads(b['result.json']);outer=json.loads((S/'offline-real-control.json').read_text());assert b['result.json']==b['progress.json']
assert r['status']=='VERIFIED_UNSAT' and r['accepted_CNF_UNSAT'] and r['exit_code']==outer['exit_code']==0 and not r['validated_SAT']
assert r['source_sha256']==h(read(S/'offline_checked_cadical.py'))=='aa5d13bb83ab79e47b9794809c3c06dc153544975cd1131afbdeaef7c18d484a'
assert json.loads((S/'offline-real-control.stdout').read_text())=={'exit_code':0,'result':str(A/'result.json')} and (S/'offline-real-control.stderr').read_bytes()==b''
cnf=read(S/'AAAA-right17-partition/case-13.cnf');meta=read(S/'AAAA-right17-partition/case-13.json')
assert cnf==b['instance.cnf'] and meta==b['instance.json']
assert h(cnf)==r['cnf_sha256']=='f131cf70c0ba2ab234ccebbdab41a11fa156d01dae915ccba57f06563d94f1af'
assert h(meta)==r['metadata_sha256']=='9e8c71be49a913314d13ea6d7fc479a1ddb708a5a7c15c9894c65fb1c9e2938c'
assert h(read(S/'AAAA-right17-partition/manifest.json'))=='571bbb81339f2538aaeb9c013a0117db7d526ac485ed44af0f5cd335356d5213'
prior=json.loads(read(R/'orch/S08/s06-final-review/review.json'));assert h((R/'orch/S08/s06-final-review/review.json').read_bytes())=='6a5daee23ed457fecf8c280e23dea6a42bfbd4eb98eb3f0fb9ff012ac748efad'
parent=read(R/'original-dag-strong/original.cnf',False);rup=read(S/'suffix-fanin/lifted-all.drat');assert h(parent)==prior['parent_sha256'] and h(rup)==prior['final_proof_sha256']
header,body=parent.split(b'\n',1);nv,nc=map(int,header.split()[2:]);cube=[2807,3072,3341,3614,2851]
expected=f'p cnf {nv} {nc+len(rup.splitlines())+len(cube)}\n'.encode()+body+rup+b''.join(f'{v} 0\n'.encode() for v in cube);assert cnf==expected
assert set(r['phases'])=={'solver','checker'};sv=r['phases']['solver'];ck=r['phases']['checker']
assert sv['exit_code']==20 and ck['exit_code']==0 and sv['reason'] is None and ck['reason'] is None
assert ck['started_utc']>=sv['finished_utc'] and r['finished_utc']>=ck['finished_utc']
assert sv['command']==[str(R/'lean-4.36.0-linux/bin/cadical'),'--unsat','--binary=true','--no-color',str(A/'instance.cnf'),str(A/'proof.drat')]
assert ck['command']==[str(R/'solver/dsr-trim/bin/dsr-trim'),'--forward',str(A/'instance.cnf'),str(A/'proof.drat')]
assert r['solver_verdicts']==['s UNSATISFIABLE'] and r['checker_verdicts']==['s VERIFIED UNSAT']
for phase,vs in [('solver',r['solver_verdicts']),('checker',r['checker_verdicts'])]:assert [s for s in b[phase+'.stdout'].decode().splitlines() if s.startswith('s ')]==vs
assert set(r['logs'])=={'solver.stdout','solver.stderr','checker.stdout','checker.stderr'}
for n,x in r['logs'].items():assert {'bytes':len(b[n]),'sha256':h(b[n])}==x
for k,x in r['pins'].items():assert h(read(Path(x['path']),False))==x['sha256']
proof=b['proof.drat'];assert len(proof)==r['proof']['bytes']==r['retained_proof_file']['bytes']==417878
assert h(proof)==r['proof']['sha256']==r['retained_proof_file']['sha256']=='8125b968b7872be6b0c65d3d9fce9231364fd6e1e06a19c951b7752d730c320d'
assert r['proof']['retained'] and r['proof']['producer_complete'] and r['retained_proof_file']['is_accepted_complete_certificate']
assert proof[0] in (97,100) and proof[-1]==0 and proof.count(0)==r['proof']['zero_bytes']==61208
assert outer['command']==['python','-B',str(S/'offline_checked_cadical.py'),str(S/'AAAA-right17-partition/case-13.cnf'),str(A),'--cnf-sha256',h(cnf),'--metadata-sha256',h(meta),'--solver-seconds','20','--checker-seconds','20','--proof-mib','64']
(D/'instance.cnf').write_bytes(cnf);(D/'proof.drat').write_bytes(proof)
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2));resource.setrlimit(resource.RLIMIT_CPU,(10,10))
cmd=[r['pins']['checker']['path'],'--forward',str(D/'instance.cnf'),str(D/'proof.drat')];start=time.monotonic()
with (D/'replay.stdout').open('wb') as o,(D/'replay.stderr').open('wb') as e:q=subprocess.run(cmd,cwd=D,stdout=o,stderr=e,timeout=12,preexec_fn=limits)
stdout=(D/'replay.stdout').read_bytes();stderr=(D/'replay.stderr').read_bytes();assert q.returncode==0 and [s for s in stdout.decode().splitlines() if s.startswith('s ')]==['s VERIFIED UNSAT']
review={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':'PASS_REAL_OFFLINE_CASE13_CONTROL_AND_INDEPENDENT_REPLAY','scope':'Known strongerAAAA right17wire13 subcase only; compatibility/control evidence, no newAAAO/global/shard/Lean claim.','runner_source_sha256':r['source_sha256'],'source_result_sha256':h(b['result.json']),'input_cnf_sha256':h(cnf),'metadata_sha256':h(meta),'reconstructed_as':'Reviewed original parent+3692RUP+cube2807,3072,3341,3614,2851','proof_sha256':h(proof),'proof_bytes':len(proof),'complete_original_logs_verified':4,'source_exit_codes':{'outer':0,'solver':20,'checker':0},'source_child_phases_sequential':True,'replay':{'command':cmd,'exit_code':q.returncode,'verdict':'s VERIFIED UNSAT','elapsed_seconds':time.monotonic()-start,'memory_mib':512,'cpu_seconds':10,'wall_seconds':12,'stdout_sha256':h(stdout),'stderr_sha256':h(stderr)},'bindings':bindings,'new_solver_or_Lean':False}
assert all(h(Path(p).read_bytes())==x['sha256'] for p,x in bindings.items())
(D/'review.json').write_text(json.dumps(review,indent=2)+'\n');rh=h((D/'review.json').read_bytes())
msg=f'\n- {datetime.datetime.now(datetime.timezone.utc).isoformat()} — S08 REAL OFFLINE CASE13 PASS: orch/S08/offline-real-case13-review/review.json SHA{rh}. Exactaa5d13runner, outer0/solver20/checker0+soleVERIFIED_UNSAT, sequentialphases, all4fullloghashes, progress/result, readonlycopiedCNF+metadata and3toolpins verified. Inputf131cf...f1af independentlyreconstructedoriginal38d93+3692RUP+cube[2807,3072,3341,3614,2851]; priorpartitionreview6a5d...efad coversprovenance. Retained417878byte binaryproof8125b968b7872be6b0c65d3d9fce9231364fd6e1e06a19c951b7752d730c320d independentlyreplayedDSR--forward exit0/sVERIFIED_UNSAT in{review["replay"]["elapsed_seconds"]:.3f}s under512MiB/10CPU/12wall. Fullsnapshots+replaylogs inS08scratch. Includecontrol+thisreview inarchive2. Compatibilityconfirmed; no newAAAO/global/shard/Lean refutation, no newsolver/workeraction.\n'
with (R/'orch-notes.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 with (W/'results/orch/NOTES.md').open('a') as f:f.write(msg)
with (W/'results/orch/lemmas/S08-integration-review.md').open('a') as f:f.write(msg)
print(json.dumps({'verdict':review['verdict'],'review_sha256':rh,'replay_elapsed_seconds':review['replay']['elapsed_seconds'],'bindings':len(bindings)},indent=2))
