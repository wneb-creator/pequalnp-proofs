from pathlib import Path
import ast,datetime,hashlib,importlib.util,json,os,signal,threading,time,unittest,traceback
R=Path('/tmp/oec/pequalnp-pilot-18');O=R/'orch/S06';D=R/'orch/S08/offline-runner-review';D.mkdir(exist_ok=False)
h=lambda b:hashlib.sha256(b).hexdigest();bindings={}
def read(p):
 b=p.read_bytes();bindings[str(p)]={'bytes':len(b),'sha256':h(b)};q=D/'source-snapshot'/p.name;q.write_bytes(b);return b
(D/'source-snapshot').mkdir()
source=read(O/'offline_checked_cadical.py');tests=read(O/'test_offline_checked_cadical.py')
assert h(source)=='aa5d13bb83ab79e47b9794809c3c06dc153544975cd1131afbdeaef7c18d484a'
assert h(tests)=='a1990de9397fdccaf2d7d8d772a6d1fc9265f49a3c269d2bc5acd1f93e345271'
for n in ['offline-controls-final-result.json','offline-controls-final.stdout','offline-controls-final.stderr','offline-preflight-result.json','offline-preflight.stdout','offline-preflight.stderr','offline-resource-summary.json']:
 read(O/n)
for label in ['offline-controls-final','offline-preflight']:
 q=json.loads((D/'source-snapshot'/(label+'-result.json')).read_text());assert q['exit_code']==0 and q['source_sha256']==h(source)
 for stream in ['stdout','stderr']:assert q[stream+'_sha256']==h((D/'source-snapshot'/(label+'.'+stream)).read_bytes())
# Exact runner bytes. Only the test harness's O assignment is redirected.
(D/'offline_checked_cadical.py').write_bytes(source)
module=ast.parse(tests,filename=str(O/'test_offline_checked_cadical.py'))
changed=0
for n in module.body:
 if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='O' for t in n.targets):
  n.value=ast.Call(func=ast.Name(id='Path',ctx=ast.Load()),args=[ast.Constant(str(D))],keywords=[]);changed+=1
assert changed==1;ast.fix_missing_locations(module)
ns={'__name__':'S08_review_controls','__file__':str(O/'test_offline_checked_cadical.py')};exec(compile(module,str(O/'test_offline_checked_cadical.py'),'exec'),ns)
M=ns['M'];Base=ns['Controls']
class Additional(Base):
 def replace_pin(self,a,k,text):
  p=a.pins[k][0];p.write_text(text);p.chmod(0o700);a.pins[k]=(p,M.digest(p))
 def test_snapshot_mutation_rejected_after_checker(self):
  root,a=self.fixture('unsat')
  self.replace_pin(a,'checker',ns['CHECKER'].replace("print('s VALID'", "cnf.chmod(0o600);cnf.write_text('p cnf 1 0\\n')\nprint('s VALID'"))
  self.assertEqual(M.run(a),2);r=json.loads((a.output/'result.json').read_text());self.assertFalse(r['accepted_CNF_UNSAT']);self.assertIn('snapshot changed',r['reason'])
 def test_mixed_checker_verdict_rejected(self):
  root,a=self.fixture('unsat');self.replace_pin(a,'checker',ns['CHECKER']+"\nprint('s VALID')\n")
  self.assertEqual(M.run(a),2);r=json.loads((a.output/'result.json').read_text());self.assertFalse(r['accepted_CNF_UNSAT'])
 def test_input_changed_by_solver_stops_before_checker(self):
  root,a=self.fixture('unsat');self.replace_pin(a,'solver',ns['SOLVER'].replace("proof.write_bytes(b'a\\x00')", "Path("+repr(str(a.cnf))+ ").write_text('p cnf 1 0\\n')\nproof.write_bytes(b'a\\x00')"))
  self.assertEqual(M.run(a),2);r=json.loads((a.output/'result.json').read_text());self.assertFalse(r['accepted_CNF_UNSAT']);self.assertNotIn('checker',r['phases'])
 def test_external_abort_during_checker(self):
  root,a=self.fixture('checker_hang')
  def abort_when_started():
   end=time.monotonic()+3
   while time.monotonic()<end:
    if (a.output/'checker-started').exists():a.abort_file.touch();return
    time.sleep(.01)
  t=threading.Thread(target=abort_when_started);t.start()
  try:self.assertEqual(M.run(a),2)
  finally:t.join()
  r=json.loads((a.output/'result.json').read_text());self.assertFalse(r['accepted_CNF_UNSAT']);self.assertEqual(r['phases']['checker']['reason'],'external_abort_file')
 def test_completed_result_hashes_logs_and_children_reaped(self):
  root,a,rc,r=self.execute('unsat');self.assertEqual(rc,0);self.assertEqual(r,json.loads((a.output/'progress.json').read_text()))
  self.assertEqual(r['source_sha256'],h(source));self.assertEqual(set(r['logs']),{'solver.stdout','solver.stderr','checker.stdout','checker.stderr'})
  for n,x in r['logs'].items():self.assertEqual(x,{'bytes':(a.output/n).stat().st_size,'sha256':M.digest(a.output/n)})
  for phase in r['phases'].values():
   with self.assertRaises(ProcessLookupError):os.kill(phase['pid'],0)
# Inherited9controls plus5independentcontrols, eachonce.
suite=unittest.defaultTestLoader.loadTestsFromTestCase(Additional)
start=time.monotonic()
with (D/'tests.stdout').open('w') as out:
 result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
r={'verdict':'PASS_RETAINED_OFFLINE_RUNNER_SIMULATED_CONTROLS' if result.wasSuccessful() else 'FAIL_CONTROLS','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':h(source),'test_source_sha256':h(tests),'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'elapsed_seconds':time.monotonic()-start,'bindings':bindings,'scope':'Static control-flow review and simulated processes only; no production solver/checker/validator launch or resource admission.','test_harness_redirect':'AST changed test module O path only, one assignment. Runner bytes unchanged; fake pinned programs in S08 own scratch.','findings':['Strict20+UNSAT before retainedproof checking; strictchecker0+VERIFIED_UNSAT and stable input/proof/tool hashes before acceptance.','Timeout/abort/limits/errors map toUNKNOWN; finalacceptedproofretainedbyhash; SATrequiresfull2048gate-limited provenance-bound validator.','One child phase at a time; process-group TERM/KILL and parent-death signal; snapshots read-only; fresh outputdirs; memory/file/disk/record/wallguards.','ProductionCLI output is intentionallyrestrictedtoS06scratch; review callsrun(args) withS08localfixtures, noCLIproductionadmission.'],'new_production_solver_checker_Lean':False,'tests_stdout_sha256':h((D/'tests.stdout').read_bytes())}
# Preserve every generated fixture/result/log hash for reproducibility.
r['control_files']={str(p.relative_to(D)):{'bytes':p.stat().st_size,'sha256':h(p.read_bytes())} for p in sorted((D/'offline-controls').rglob('*')) if p.is_file()}
r['input_changes']=[p for p,x in bindings.items() if h(Path(p).read_bytes())!=x['sha256']]
assert not r['input_changes']
(D/'review.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:r[k] for k in ['verdict','source_sha256','tests_run','failures','errors','elapsed_seconds']}|{'review_sha256':h((D/'review.json').read_bytes())},indent=2))
