from pathlib import Path
import json,hashlib,subprocess,resource,time,datetime,traceback
R=Path('/tmp/oec/pequalnp-pilot-18');O=R/'orch/S06';D=R/'orch/S08/aaao-chain-review';D.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest();bindings={};saved={}
def read(p,save=False):
 p=Path(p);assert p.is_relative_to(R) or p.is_relative_to(Path('/workspace/pequalnp-proofs'));assert not p.is_symlink();b=p.read_bytes();bindings[str(p)]={'bytes':len(b),'sha256':sha(b)}
 if save or p.suffix not in ['.cnf','.tsv']:
  q=D/'snapshot'/str(p).lstrip('/');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
 return b
j=lambda p:json.loads(read(p))
H=j(O/'AAAO-chain-handoff.json');M=j(O/'AAAO-chain-absorption-family/manifest.json');P=R/'orch/S01/consecutive-junk-v2/AAAO-chain.cnf';p=read(P,True);pm=j(P.with_suffix('.json'))
assert sha(p)==H['parent_sha256']==M['parent_sha256']=='a8e94b6cfeaafb8b6c4e01d33e6f552a984e395d224dc3d6281d99cc49850753'
assert sha(read(R/'orch/S04/chain-review.json'))==H['normalization_review_sha256']=='299f6bdc23ac20e8f9b54cae7eb3a787c1aacf951ab08b8314be212c67f1472d'
for n,v in H['sources'].items():assert sha(read(O/n))==v,n
for n,v in H['files'].items():
 b=read(O/n);assert len(b)==v['bytes'] and sha(b)==v['sha256'],n
head,body=p.split(b'\n',1);nv,nc=map(int,head.split()[2:]);assert (nv,nc)==(11968,115946) and body.count(b'\n')==nc
mk=lambda proof,cube: f'p cnf {nv} {nc+proof.count(bytes([10]))+len(cube)}\n'.encode()+body+proof+b''.join(f'{x} 0\n'.encode() for x in cube)
# Check literal semantics against the reviewed chain parent itself.
units={int(z.split()[0]) for z in body.splitlines() if len(z.split())==2}
assert pm['lefts'][20][29]==3644 and pm['lefts'][19][29]==3371
assert all(pm['ops'][g] in units for g in [17,18,19]) and -pm['ops'][20] in units
assert all(pm['rights'][g][w] in units for g,w in [(18,30),(19,31),(20,32)])
# Exact incremental proof/input reconstruction, without rerunning the probe.
base=read(O/'suffix-fanin/lifted-all.drat');assert sha(base)=='f319ae4b04ce7c6910389dc7f60ed61c353417192c47a44def9b35cc784683c8'
assert mk(base,[])==read(O/'AAAO-chain-probe/seeded.cnf')
nu=read(O/'AAAO-chain-probe/new-units.drat');assert len(nu.splitlines())==67
proof=base+nu;assert proof==read(O/'AAAO-chain-probe/combined.drat')
assert mk(proof,[])==read(O/'AAAO-chain-probe/augmented.cnf')
split=j(O/'AAAO-chain-split/manifest.json');conditional=0
for c in split['cases']:
 n=c['label'];cube=c['cube'];assert len(cube)==1
 assert mk(proof,cube)==read(O/'AAAO-chain-split'/(n+'.cnf'))
 local=read(O/'AAAO-chain-split'/(n+'.drat'));assert sha(local)==c['local_proof_sha256'];assert sha(mk(proof,cube))==c['local_cnf_sha256']
 lines=local.splitlines();assert len(lines)==c['new_conditional_clauses'];conditional+=len(lines)
 proof+=b''.join(f'{-cube[0]} '.encode()+line+b'\n' for line in lines)
assert conditional==12 and proof==read(O/'AAAO-chain-split/combined.drat')
assert mk(proof,[])==read(O/'AAAO-chain-split/augmented.cnf')
expected=[(w,k) for w in range(29,12,-1) for k in ['d','c','b','a']];assert [(c['wire'],c['leaf']) for c in M['cases']]==expected
ports={'a':pm['lefts'][17],'b':pm['rights'][17],'c':pm['lefts'][18],'d':pm['lefts'][19]}
for c in M['cases']:
 cube=[pm['lefts'][20][c['wire']],ports[c['leaf']][c['wire']]];assert cube==c['cube'] and c['probe_exit']==20
 stem=f"wire-{c['wire']:02d}-{c['leaf']}";localcnf=mk(proof,cube);assert localcnf==read(O/'AAAO-chain-absorption-family'/(stem+'.cnf'))
 assert sha(localcnf)==c['local_cnf_sha256']
 local=read(O/'AAAO-chain-absorption-family'/(stem+'.drat'));assert sha(local)==c['local_proof_sha256'] and local.endswith(b'0\n')
 lines=local.splitlines();assert lines[-1]==b'0' and len(lines)==c['new_lifted_clauses']
 proof+=b''.join((' '.join(str(-v) for v in cube)+' ').encode()+line+b'\n' for line in lines)
proof+=b'3644 3371 0\n'
assert proof==read(O/'AAAO-chain-absorption-family/combined.drat')
assert sha(proof)==H['proof_sha256']==M['proof_sha256']=='8e937b00f88bc1b24b1dec5586c774af36215fc8f2ddbb7397bcdba55a3dcdc8'
assert len(proof.splitlines())==H['proof_clauses']==3895
assert all(line.split()[-1:]==[b'0'] and all(0<abs(int(x))<=nv for x in line.split()[:-1]) for line in proof.splitlines())
assert all(len(line.split())>1 for line in proof.splitlines())
clauses={tuple(map(int,line.split()[:-1])) for line in proof.splitlines()}
assert all(tuple(-v for v in c['cube']) in clauses for c in M['cases'])
aug=mk(proof,[]);assert aug==read(O/'AAAO-chain-absorption-family/augmented.cnf') and sha(aug)==H['augmented_cnf_sha256']
assert H['partition']==M['partition'];assert [c['cube'] for c in M['partition']]==[[3644,-3371],[-3644,3371]]
partition=[]
for c in M['partition']:
 b=mk(proof,c['cube']);assert b==read(O/'AAAO-chain-absorption-family'/(c['name']+'.cnf')) and sha(b)==c['cnf_sha256']
 mp=O/'AAAO-chain-absorption-family'/(c['name']+'.json');cm=j(mp);assert sha(mp.read_bytes())==c['metadata_sha256']
 assert cm['sha256']==sha(b) and cm['clauses']==nc+3895+2 and cm['s06_cube']==c['cube'] and cm['s06_chain_parent_sha256']==sha(p) and cm['s06_rup_proof_sha256']==sha(proof)
 for k in ['rows','ops','lefts','rights','values','nvars']:
  if k in pm:assert cm[k]==pm[k],k
 partition.append({'name':c['name'],'cube':c['cube'],'cnf_sha256':sha(b),'metadata_sha256':sha(mp.read_bytes())})
# All4 truth assignments are exactly the2 disjoint surviving cubes or certified excluded cubes.
assert {tuple(x['cube']) for x in M['partition']+M['excluded_boolean_assignments']}=={(a,b) for a in [3644,-3644] for b in [3371,-3371]}
excludedproof=read(O/'AAAO-chain-absorption-family/excluded-pairs.drat');assert excludedproof==proof+b'0\n' and sha(excludedproof)==M['exclusion_proof_sha256']
checker=R/'solver/dsr-trim/bin/dsr-trim';checkerhash=sha(read(checker));assert checkerhash=='e6894b5b74ac2c09b494344f397ec5111547aaa782cdb399f1a8b6835ecef84b'
(D/'parent.cnf').write_bytes(p);(D/'final.drat').write_bytes(proof);(D/'refutation.drat').write_bytes(excludedproof)
def cap():
 resource.setrlimit(resource.RLIMIT_AS,(512*1024*1024,512*1024*1024));resource.setrlimit(resource.RLIMIT_CPU,(10,10))
replays=[]
def run(label,cnf,pr,verdict,code):
 cmd=[str(checker),'--forward','--rup-only',str(cnf),str(pr)];start=time.monotonic()
 with (D/(label+'.stdout')).open('wb') as o,(D/(label+'.stderr')).open('wb') as e:q=subprocess.run(cmd,cwd=D,stdout=o,stderr=e,timeout=12,preexec_fn=cap)
 out=(D/(label+'.stdout')).read_bytes();err=(D/(label+'.stderr')).read_bytes();vs=[s for s in out.decode().splitlines() if s.startswith('s ')]
 rec={'label':label,'command':cmd,'exit_code':q.returncode,'elapsed_seconds':time.monotonic()-start,'verdicts':vs,'input_sha256':sha(cnf.read_bytes()),'proof_sha256':sha(pr.read_bytes()),'stdout_sha256':sha(out),'stderr_sha256':sha(err)};replays.append(rec)
 assert q.returncode==code and verdict in vs,rec
run('final-rup',D/'parent.cnf',D/'final.drat','s VALID',0)
for x in M['excluded_boolean_assignments']:
 b=mk(b'',x['cube']);assert b==read(O/'AAAO-chain-absorption-family'/(x['name']+'.cnf')) and sha(b)==x['cnf_sha256']
 q=D/(x['name']+'.cnf');q.write_bytes(b);run(x['name'],q,D/'refutation.drat','s VERIFIED UNSAT',0)
# Negative control confirms no source-independent empty-clause acceptance.
run('reject-global-refutation',D/'parent.cnf',D/'refutation.drat','s INVALID',1)
changes=[p for p,x in bindings.items() if sha(Path(p).read_bytes())!=x['sha256']];assert not changes
r={'verdict':'PASS_AAAO_CHAIN_3895_RUP_AND_EXACT_TWO_CASE_PARTITION','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Only exact reviewed AAAO-chain parent. Neither surviving case nor whole chain is refuted. No global/Lean acceptance.','parent_sha256':sha(p) if isinstance(p,bytes) else H['parent_sha256'],'handoff_sha256':bindings[str(O/'AAAO-chain-handoff.json')]['sha256'],'normalization_review_sha256':H['normalization_review_sha256'],'proof_sha256':sha(proof),'proof_clauses':3895,'proof_bytes':len(proof),'augmented_cnf_sha256':sha(aug),'new_root_units':67,'new_conditional_clauses':conditional,'all68_absorption_inputs_lifts_and_exclusion_clauses_reconstructed':True,'selector_semantics':{'3644':'lefts[20][29] final OR operand P=lastcleanprefix wire29','3371':'lefts[19][29] productfactor d=lastcleanprefix wire29'},'partition':partition,'coverage':'both-positive and both-negative assignments replay-refuted on parent+cube; remaining2cubes disjoint and cover all models','replays':replays,'checker_sha256':checkerhash,'checker_caps':{'memory_mib':512,'cpu_seconds':10,'wall_seconds_each':12},'bindings':bindings,'input_changes':changes,'new_solver_or_Lean':False}
(D/'review.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'verdict':r['verdict'],'review_sha256':sha((D/'review.json').read_bytes()),'bindings':len(bindings),'replays':[(x['label'],x['exit_code'],x['verdicts'],x['elapsed_seconds']) for x in replays]},indent=2))
