import datetime
import hashlib
import itertools
import json
import subprocess
import sys
from pathlib import Path

root=Path('/tmp/oec/pequalnp-pilot-18')
here=root/'orch/S01'; generated=here/'consecutive-junk-v2'
program=here/'build_consecutive_junk.py'
parent=root/'original-dag-strong/original.cnf'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
raw=parent.read_bytes(); header,body=raw.split(b'\n',1)
assert sha(parent)=='38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08'
meta=read(parent.with_suffix('.json'))
family=read(generated/'family.json')
assert family['program_sha256']==sha(program)
assert family['parent_sha256']==sha(parent)
assert family['parent_metadata_sha256']==sha(parent.with_suffix('.json'))
assert family['added_J18_claimed_as_parent_logical_consequence'] is False
ops=meta['ops'][17:];j=meta['junk'][17:]
assert ops==[2807,3072,3341,3614] and j==[2974,3243,3516,3793]
parent_clauses={tuple(map(int,line.split()[:-1])) for line in body.splitlines()}
assert (j[0],) in parent_clauses
assert (-j[0],ops[0]) in parent_clauses and (-j[1],ops[1]) in parent_clauses
assert all((ops[a],ops[b]) in parent_clauses for a,b in itertools.combinations(range(4),2))

names=['AAAA','AAOA','AAAO']
coverage=[]
for bits in itertools.product([False,True],repeat=4):
    eligible=bits[0] and bits[1] and sum(bits)>=3
    matches=[name for name in names if bits==tuple(c=='A' for c in name)]
    assert len(matches)==int(eligible)
    coverage.append({'AND_bits':bits,'eligible':eligible,'matching_cases':matches})

expected={'normalized':[[j[1]]]}
for name in names:
    expected[name]=[[j[1]]]+[[op if c=='A' else -op] for op,c in zip(ops,name)]
leaf_controls=0
for name in ['AAAA','AAAO']:
    clauses=list(expected[name])
    L,R=meta['lefts'],meta['rights']
    for gate,previous in [(18,30),(19,31),(20,32)]:
        clauses.append([R[gate][previous]])
        clauses.extend([-L[gate][port]] for port in range(30,13+gate))
    clauses.append([j[2] if name=='AAAA' else -j[2]])
    leaf_tables=[L[17],R[17],L[18][:30],L[19][:30]]
    strict=[False,True,True]
    if name=='AAAA':leaf_tables.append(L[20][:30]);strict=[False,False,True,True]
    for first,second,strict_order in zip(leaf_tables,leaf_tables[1:],strict):
        forbidden={(a,b) for a in range(30) for b in range(30)
                   if not(a<b if strict_order else a<=b)}
        block=[[-first[a],-second[b]] for a,b in sorted(forbidden)]
        clauses.extend(block)
        encoded={(first.index(-a),second.index(-b)) for a,b in block}
        for a,b in itertools.product(range(30),repeat=2):
            assert ((a,b) not in encoded)==(a<b if strict_order else a<=b)
            leaf_controls+=1
    expected[name+'-chain']=clauses

entries=[]
for name,delta in expected.items():
    p=generated/(name+'.cnf');m=generated/(name+'.json')
    record=read(m);blob=p.read_bytes();h,b=blob.split(b'\n',1)
    expected_extra=''.join(' '.join(map(str,c))+' 0\n' for c in delta).encode()
    assert h==f'p cnf 11968 {114566+len(delta)}'.encode()
    assert b==body+expected_extra
    assert len(b.splitlines())==114566+len(delta)
    assert all(0<abs(v)<=11968 for c in delta for v in c)
    assert record['consecutive_junk_added_clauses']==delta
    assert record['sha256']==sha(p)==family['files'][name]['cnf_sha256']
    assert sha(m)==family['files'][name]['metadata_sha256']
    assert record['consecutive_junk_generator_sha256']==sha(program)
    assert record['consecutive_junk_claimed_as_logical_consequence'] is False
    for key,value in meta.items():
        if key not in ('sha256','clauses'): assert record[key]==value,key
    entries.append({'case':name,'variables':11968,'clauses':114566+len(delta),
                    'added_clauses':len(delta),'cnf_sha256':sha(p),'metadata_sha256':sha(m),
                    'exact_original_body_preserved':True})

# Negative controls execute only the generator, never a solver.
bad=here/'control-bad-parent.cnf'
bad.write_text('p cnf 1 1\n1 0\n')
bad.with_suffix('.json').write_bytes(parent.with_suffix('.json').read_bytes())
controls=[]
for label,args in [
    ('bad-parent',[str(bad),str(here/'control-must-not-exist')]),
    ('existing-output',[str(parent),str(generated)])]:
    before={p.name:sha(p) for p in generated.iterdir() if p.is_file()}
    with (here/(label+'.stdout.txt')).open('w') as out,(here/(label+'.stderr.txt')).open('w') as err:
        r=subprocess.run([sys.executable,str(program),*args],stdout=out,stderr=err)
    assert r.returncode!=0
    assert before=={p.name:sha(p) for p in generated.iterdir() if p.is_file()}
    controls.append({'case':label,'exit_code':r.returncode,'rejected_without_output_changes':True})
assert not (here/'control-must-not-exist').exists()

report={
 'verdict':'PASS_ENCODING_CONTROLS',
 'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'program_sha256':sha(program),'audit_program_sha256':sha(Path(__file__)),
 'parent_cnf_sha256':sha(parent),'parent_metadata_sha256':sha(parent.with_suffix('.json')),
 'family_sha256':sha(generated/'family.json'),'cases':entries,
 'boolean_operation_assignments_checked':16,'coverage':coverage,
 'leaf_order_projection_assignments_checked':leaf_controls,
 'negative_controls':controls,
 'mathematical_scope': 'S04 independently passed the consecutive-junk normalization. The chain variants retain their separate minimal-factor/sorting justification and require its independent review. No implication of the old parent by the added J18 unit is claimed.',
 'all_original_clauses_preserved_byte_for_byte':True,
 'no_new_variables':True,'all_original_metadata_keys_except_sha_and_clause_count_preserved':True,
 'solver_started':False,'lease_calls':False,'repository_Lean_modified':False,
 'files':[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
          for p in [program,Path(__file__),generated/'family.json']+
                   sorted(generated.glob('*.cnf'))+sorted(generated.glob('*.json'))
          if p.is_file()],
 'Sub-agents':'none'}
(here/'encoding-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'verdict':report['verdict'],'program_sha256':sha(program),
                  'family_sha256':report['family_sha256'],'cases':len(entries),
                  'projection_controls':leaf_controls,'report':str(here/'encoding-validation.json')}))
