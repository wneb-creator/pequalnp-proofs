#!/usr/bin/env python3
import json,os,signal,sys,time
from pathlib import Path
cnf=Path(sys.argv[-2]);proof=Path(sys.argv[-1]);mode=json.loads(cnf.with_suffix('.json').read_text())['mode']
(cnf.parent/'solver-started').write_text(str(os.getpid()))
if mode=='hang':
 signal.signal(signal.SIGTERM,signal.SIG_IGN)
 while True:time.sleep(.05)
if mode=='overflow':
 with proof.open('wb',buffering=0) as f:f.write(b'x'*32768)
 sys.exit(20)
proof.write_bytes(b'a\x00')
if mode=='record_cap':proof.write_bytes(b'a\x00'*20)
if mode=='no_proof':proof.unlink()
if mode=='crash':sys.exit(1)
if mode in ['unknown','timeout_fake']:print('s UNKNOWN',flush=True);sys.exit(0)
if mode.startswith('sat'):
 print('s SATISFIABLE',flush=True);sys.exit(10)
print('s UNSATISFIABLE',flush=True)
if mode=='mixed':print('s SATISFIABLE',flush=True)
sys.exit(0 if mode=='wrong_exit' else 20)
