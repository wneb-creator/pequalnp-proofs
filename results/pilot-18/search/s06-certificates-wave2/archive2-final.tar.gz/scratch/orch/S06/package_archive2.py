#!/usr/bin/env python3
"""Snapshot reviewed AAAO evidence and retained-proof runner controls; no workers."""
import argparse
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path('/tmp/oec/pequalnp-pilot-18')
OWN = ROOT / 'orch/S06'
REPO = Path('/workspace/pequalnp-proofs')
PARENT_SHA = '38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08'
RUNNER_SHA = 'aa5d13bb83ab79e47b9794809c3c06dc153544975cd1131afbdeaef7c18d484a'
AAAO_REVIEW_SHA = '5ce1515a74ede401f5324f2940a08e4276e069887f960a080f14c038891cbe97'
RUNNER_REVIEW_SHA = 'e3a1dfb01fe24acf900e34ae15012c78b3ab15a574240334de0fdfc535ac7b03'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    parser.add_argument('--real-control', type=Path)
    parser.add_argument('--extra-record', type=Path, action='append', default=[])
    args = parser.parse_args()
    archive = args.output.absolute()
    assert archive.parent.resolve() == OWN.resolve()
    archive.mkdir(mode=0o700)
    parent = ROOT / 'original-dag-strong/original.cnf'
    parent_raw = parent.read_bytes()
    assert sha(parent_raw) == PARENT_SHA
    parent_body = parent_raw.split(b'\n', 1)[1]
    assert sha((OWN / 'offline_checked_cadical.py').read_bytes()) == RUNNER_SHA
    for kind, expected in [('aaao-chain-review-v2', AAAO_REVIEW_SHA), ('offline-runner-review', RUNNER_REVIEW_SHA)]:
        assert sha((ROOT / 'orch/S08' / kind / 'review.json').read_bytes()) == expected

    files = {}
    recipes = []
    omitted = []
    source_map = []
    paths = set()

    def add(path):
        assert path.exists(), path
        if path.is_dir():
            paths.update(p for p in path.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
        else:
            paths.add(path)

    def layout(path):
        if path.is_relative_to(ROOT):
            return Path('scratch') / path.relative_to(ROOT)
        assert path.is_relative_to(REPO), path
        return Path('repo') / path.relative_to(REPO)

    def put(relative, raw, source):
        assert not relative.is_absolute() and '..' not in relative.parts
        name = str(relative)
        info = {'path': name, 'source_path': source, 'bytes': len(raw), 'sha256': sha(raw)}
        if name in files:
            assert files[name]['sha256'] == info['sha256']
            return
        target = archive / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        files[name] = info

    def metadata(name, value):
        put(Path(name), (json.dumps(value, indent=2, sort_keys=True) + '\n').encode(), 'generated archive metadata')

    aaao = read_json(OWN / 'AAAO-chain-handoff.json')
    for relative, binding in aaao['files'].items():
        p = OWN / relative
        raw = p.read_bytes()
        assert len(raw) == binding['bytes'] and sha(raw) == binding['sha256'], p
        add(p)
    for relative, expected in aaao['sources'].items():
        p = OWN / relative
        assert sha(p.read_bytes()) == expected
        add(p)
    for name in ['AAAO-chain-handoff.json', 'all-vars.txt', 'suffix-fanin/lifted-all.drat',
                 'offline_checked_cadical.py', 'test_offline_checked_cadical.py',
                 'offline-runner-handoff.json', 'offline-runner-review.md',
                 'package_archive2.py', 'restore_archive2_cnfs.py',
                 'package_archive2.initial.py', 'archive2-build.stdout',
                 'archive2-build.stderr', 'archive2-build.result.json']:
        add(OWN / name)
    handoff = read_json(OWN / 'offline-runner-handoff.json')
    for entry in handoff['artifacts']:
        p = OWN / entry['path']
        raw = p.read_bytes()
        assert len(raw) == entry['bytes'] and sha(raw) == entry['sha256'], p
        add(p)

    # All source and full diagnostic files of the final independent reviews.
    for kind, source, prefix in [
        ('aaao-chain-review-v2', 'review_aaao_chain.py', 'aaao-chain-review-v2'),
        ('offline-runner-review', 'review_offline_runner.py', 'offline-runner-review')]:
        for p in [ROOT / 'orch/S08' / kind, ROOT / 'orch/S08' / source,
                  ROOT / 'orch/S08' / (prefix + '.stdout'), ROOT / 'orch/S08' / (prefix + '.stderr')]:
            add(p)
    # Earlier failed review harness is retained as history, not a PASS record.
    for name in ['review_aaao_chain.initial.py', 'aaao-chain-review.stdout', 'aaao-chain-review.stderr']:
        add(ROOT / 'orch/S08' / name)

    # Chain normalization provenance, sources, exact inputs and full checks.
    add(ROOT / 'orch/S01/consecutive-junk-v2')
    for name in ['build_consecutive_junk.py', 'audit_consecutive_junk_encoding.py']:
        add(ROOT / 'orch/S01' / name)
    for name in ['chain-review.json', 'chain-review.stdout.log', 'chain-review.stderr.log',
                 'review_chain_variants.py', 'review_consecutive_junk.py',
                 'consecutive-junk-result.json', 'consecutive-junk-final.stdout.log',
                 'consecutive-junk-final.stderr.log']:
        add(ROOT / 'orch/S04' / name)
    for name in ['S01-late-junk.md', 'S04-redteam.md', 'S06-solver-performance.md', 'S08-integration-review.md']:
        add(REPO / 'results/orch/lemmas' / name)
    # Original generator dependencies are copied from the frozen first archive.
    add(OWN / 'archive-wave1/reproduction')
    add(OWN / 'archive-wave1/manifest.json')
    add(parent.with_suffix('.json'))
    for name in ['run_checked_kissat.py', 'validate_sat_candidate.py']:
        add(ROOT / 'lean-setup' / name)

    real = {'status': 'PENDING_MAIN_CONTROL', 'executed_by_packager': False}
    if args.real_control is not None:
        control = args.real_control.resolve(strict=True)
        assert control.is_relative_to(ROOT)
        result = read_json(control / 'result.json')
        assert result['state'] == 'FINISHED' and result['source_sha256'] == RUNNER_SHA
        assert result['status'] == 'VERIFIED_UNSAT' and result['exit_code'] == 0
        assert result['accepted_CNF_UNSAT'] and result['solver_verdicts'] == ['s UNSATISFIABLE']
        assert result['checker_verdicts'] == ['s VERIFIED UNSAT']
        assert result['phases']['solver']['exit_code'] == 20 and result['phases']['checker']['exit_code'] == 0
        assert result['phases']['solver']['reason'] is None and result['phases']['checker']['reason'] is None
        assert set(result['logs']) == {'solver.stdout', 'solver.stderr', 'checker.stdout', 'checker.stderr'}
        for filename, binding in result['logs'].items():
            raw = (control / filename).read_bytes()
            assert len(raw) == binding['bytes'] and sha(raw) == binding['sha256']
        for filename, expected in [('instance.cnf', result['cnf_sha256']), ('instance.json', result['metadata_sha256'])]:
            assert sha((control / filename).read_bytes()) == expected
        proof = (control / 'proof.drat').read_bytes()
        assert sha(proof) == result['proof']['sha256'] and len(proof) == result['proof']['bytes']
        add(control)
        real = {'status': 'MAIN_CONTROL_VERIFIED_UNSAT', 'executed_by_packager': False,
                'directory': str(layout(control)), 'result_sha256': sha((control / 'result.json').read_bytes()),
                'cnf_sha256': result['cnf_sha256'], 'proof_bytes': len(proof), 'proof_sha256': sha(proof)}
    for p in args.extra_record:
        add(p.resolve(strict=True))

    for path in sorted(paths):
        assert path.is_file() and not path.is_symlink(), path
        raw = path.read_bytes()
        assert sha(path.read_bytes()) == sha(raw), 'changed during snapshot: ' + str(path)
        relative = layout(path)
        source_map.append({'source_path': str(path), 'archive_path': str(relative), 'bytes': len(raw), 'sha256': sha(raw)})
        if raw.startswith(b'\x7fELF') or path.suffix in ['.pyc', '.o', '.so']:
            omitted.append({'relative_path': str(relative), 'source_path': str(path),
                'bytes': len(raw), 'sha256': sha(raw), 'reason': 'compiled binary excluded; source/pin provenance retained'})
            continue
        if path.suffix == '.cnf' and len(raw) > 65536:
            header, separator, body = raw.partition(b'\n')
            assert separator and body.startswith(parent_body), path
            delta = body[len(parent_body):]
            delta_path = Path('cnf-deltas') / (sha(delta) + '.clauses')
            put(delta_path, delta, 'deduplicated clause suffix against pinned original parent')
            recipe = {'relative_path': str(relative), 'source_path': str(path), 'bytes': len(raw),
                      'sha256': sha(raw), 'header': header.decode('ascii'),
                      'delta_path': str(delta_path), 'delta_sha256': sha(delta)}
            recipes.append(recipe)
            omitted.append(dict(recipe, reason='large CNF exactly reconstructible from pinned original and delta'))
            assert sha(header + b'\n' + parent_body + delta) == sha(raw)
        else:
            put(relative, raw, str(path))

    metadata('cnf-recipes.json', {'parent_sha256': PARENT_SHA, 'parent_bytes': len(parent_raw),
        'recipes': recipes, 'small_fixture_max_bytes': 65536,
        'scope': 'Every omitted CNF is byte-exact pinned original body plus archived suffix and recorded header.'})
    metadata('omitted-files.json', omitted)
    metadata('source-map.json', source_map)
    summary = {'scope': 'AAAO-chain redundant RUP and exact partition; offline runner review and controls. No chain/shard/global exhaustion or Lean claim.',
        'AAAO_parent_sha256': aaao['parent_sha256'], 'AAAO_proof_sha256': aaao['proof_sha256'],
        'AAAO_proof_clauses': aaao['proof_clauses'], 'AAAO_partition': aaao['partition'],
        'AAAO_independent_review_sha256': AAAO_REVIEW_SHA, 'runner_source_sha256': RUNNER_SHA,
        'runner_independent_review_sha256': RUNNER_REVIEW_SHA, 'runner_simulated_controls': {'S06': 9, 'S08': 14},
        'real_compatibility_control': real, 'production_AAAO_runs_included': False,
        'prior_archive_manifest_sha256': sha((OWN / 'archive-wave1/manifest.json').read_bytes()),
        'starts_any_worker': False, 'pending': [] if args.real_control else ['Main real compatibility control']}
    metadata('summary.json', summary)
    readme = '''# S06 archive2: AAAO chain and retained-proof runner

This archive preserves all3895 checked RUP additions on the exact reviewed AAAO-chain parent, all local probing outputs/statistics, both excluded-assignment RUP refutations, and the exact remaining two-case partition. Neither remaining AAAO case nor the whole chain is refuted here. Chain existence normalization is a separate reviewed premise; the extra chain restrictions are not implied by the original input.

The unchanged retained-proof runner is independently reviewed with14 simulated control groups, following9 S06 groups. Its input/pin-only preflight and full fake-process logs/fixtures are retained. `summary.json` separately reports whether main's real wire13 binary-DRAT compatibility control is included. Such a control proves only its specific CNF UNSAT. This package performs no search, checking, validator, Lean, remote or worker-control action.

`manifest.json` binds all archived files; `source-map.json` maps original paths to snapshots or recipes. Paths beginning `scratch/` reproduce the scratch-root-relative layout; `repo/` reproduces repository-relative paths. Historical paths/hashes in copied records are intentionally unchanged. Earlier failed controls/review harness logs are historical, not current PASS evidence. The immutable handoff/review documents can describe a pending state that a later record in `summary.json` supersedes. Current report snapshots are timestamped context, not substitutes for the frozen review and result records.

No compiled binaries or large raw CNFs are archived. Tiny simulated fixtures are retained byte-for-byte, including deliberately malformed negative controls. Every larger CNF is represented by an exact header plus pinned original clause body plus a deduplicated suffix in `cnf-deltas/`. Hashes and byte sizes are retained for all omitted files. To verify every file and recipe, without starting workers:

    python3 scratch/orch/S06/restore_archive2_cnfs.py ARCHIVE ORIGINAL.cnf --verify-only

To materialize omitted CNFs into a fresh external directory, replace `--verify-only` with that output path. The original SHA256 must be38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08. Generator sources/dependencies are under `scratch/orch/S06/archive-wave1/reproduction/`; use the reverse-counter generator with --distinct-prefix then build_original_strong.py as recorded in archive1. Exact original metadata is under `scratch/original-dag-strong/`. S01 chain generation and S04 normalization/delta reviews are included; source and snapshot hashes bind the archived parent.

Direct replay needs only the exact restored chain parent, retained `combined.drat`, and independently obtained pinned DSR checker. All original and S08 full checker diagnostics, commands, exits and pin hashes are retained. To regenerate the probing evidence in the historical layout, compile retained `probe.cpp` then use probe_AAAO_chain.py, split_AAAO_chain.py and probe_AAAO_absorption.py with all-vars.txt and the retained base3692-RUP proof. Those source programs can start bounded probing/checking and should be run only under explicit resource coordination; reconstruction and this packager do not.

The offline runner has one active child per controller. Main must hold each slot through its checker/validator and budget disk across all slots. Limits are600seconds per solver and checker separately,1536/3072MiB AS,512MiB per solver file by default,30seconds SAT validation, plus controller hash/snapshot overhead. UNKNOWN partial proofs are retained but are never accepted certificates. Full solver/checker/validator logs are retained for attempted stages; hashes bind exact files. No launch authorization is conveyed by an archived proposed command.
'''
    put(Path('README.md'), readme.encode(), 'generated archive documentation')
    manifest = {'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope': summary['scope'], 'files': sorted(files.values(), key=lambda x: x['path']),
        'archived_bytes': sum(e['bytes'] for e in files.values()),
        'restorable_large_cnf_count': len(recipes),
        'small_raw_cnf_count': sum(e['path'].endswith('.cnf') for e in files.values()),
        'large_raw_cnf_count': 0, 'compiled_binary_count': 0}
    (archive / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    for item in files.values():
        raw = (archive / item['path']).read_bytes()
        assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
    tarpath = archive.with_suffix('.tar.gz')
    with tarpath.open('xb') as rawfile:
        with gzip.GzipFile(filename='', mode='wb', fileobj=rawfile, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as tar:
                for p in sorted(archive.rglob('*')):
                    if not p.is_file():
                        continue
                    info = tar.gettarinfo(str(p), arcname=str(p.relative_to(archive)))
                    info.uid = info.gid = info.mtime = 0
                    info.uname = info.gname = ''
                    info.mode = 0o644
                    with p.open('rb') as content:
                        tar.addfile(info, content)
    record = {'archive': str(archive), 'manifest_sha256': sha((archive / 'manifest.json').read_bytes()),
        'tar_path': str(tarpath), 'tar_sha256': sha(tarpath.read_bytes()), 'tar_bytes': tarpath.stat().st_size,
        'files_in_manifest': len(files), 'large_cnfs_reconstructed': len(recipes),
        'small_fixture_cnfs': manifest['small_raw_cnf_count'], 'compiled_binary_count': 0,
        'real_control': real, 'production_launched': False}
    archive.with_suffix('.record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
