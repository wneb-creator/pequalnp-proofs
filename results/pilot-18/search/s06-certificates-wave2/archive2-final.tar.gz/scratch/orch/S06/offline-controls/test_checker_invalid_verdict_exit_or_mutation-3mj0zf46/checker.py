#!/usr/bin/env python3
import json,signal,sys,time
from pathlib import Path
cnf=Path(sys.argv[-2]);proof=Path(sys.argv[-1]);mode=json.loads(cnf.with_suffix('.json').read_text())['mode'];(cnf.parent/'checker-started').write_text('yes')
if mode=='checker_hang':
 signal.signal(signal.SIGTERM,signal.SIG_IGN)
 while True:time.sleep(.05)
if mode=='checker_mutates':proof.chmod(0o600);proof.write_bytes(b'changed')
if mode=='checker_bad':print('s VERIFIED UNSAT');sys.exit(1)
print('s VALID' if mode=='valid_only' else 's VERIFIED UNSAT')
