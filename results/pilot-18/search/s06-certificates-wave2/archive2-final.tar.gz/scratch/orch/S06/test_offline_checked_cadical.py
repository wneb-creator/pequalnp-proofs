"""Offline runner plumbing tests: simulated programs only, no real SAT/checker run."""
import importlib.util,json,signal,tempfile,threading,unittest
from pathlib import Path
from types import SimpleNamespace
O=Path('/tmp/oec/pequalnp-pilot-18/orch/S06');D=O/'offline-controls';D.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('offline',O/'offline_checked_cadical.py');M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
SOLVER='''#!/usr/bin/env python3
import json,os,signal,sys,time
from pathlib import Path
cnf=Path(sys.argv[-2]);proof=Path(sys.argv[-1]);mode=json.loads(cnf.with_suffix('.json').read_text())['mode']
(cnf.parent/'solver-started').write_text(str(os.getpid()))
if mode=='hang':
 signal.signal(signal.SIGTERM,signal.SIG_IGN)
 while True:time.sleep(.05)
if mode=='overflow':
 with proof.open('wb',buffering=0) as f:f.write(b'x'*32768)
 sys.exit(20)
proof.write_bytes(b'a\\x00')
if mode=='record_cap':proof.write_bytes(b'a\\x00'*20)
if mode=='ascii_proof':proof.write_bytes(b'0\\n')
if mode=='truncated_binary':proof.write_bytes(b'a\\x02')
if mode=='no_proof':proof.unlink()
if mode=='crash':sys.exit(1)
if mode in ['unknown','timeout_fake']:print('s UNKNOWN',flush=True);sys.exit(0)
if mode.startswith('sat'):
 print('s SATISFIABLE',flush=True);sys.exit(10)
print('s UNSATISFIABLE',flush=True)
if mode=='mixed':print('s SATISFIABLE',flush=True)
sys.exit(0 if mode=='wrong_exit' else 20)
'''
CHECKER='''#!/usr/bin/env python3
import json,signal,sys,time
from pathlib import Path
cnf=Path(sys.argv[-2]);proof=Path(sys.argv[-1]);mode=json.loads(cnf.with_suffix('.json').read_text())['mode'];(cnf.parent/'checker-started').write_text('yes')
if mode=='checker_hang':
 signal.signal(signal.SIGTERM,signal.SIG_IGN)
 while True:time.sleep(.05)
if mode=='checker_mutates':proof.chmod(0o600);proof.write_bytes(b'changed')
if mode=='checker_bad':print('s VERIFIED UNSAT');sys.exit(1)
print('s VALID' if mode=='valid_only' else 's VERIFIED UNSAT')
'''
VALIDATOR='''#!/usr/bin/env python3
import hashlib,json,sys
from pathlib import Path
cnf=Path(sys.argv[1]);model=Path(sys.argv[2]);mode=json.loads(cnf.with_suffix('.json').read_text())['mode'];(cnf.parent/'validator-started').write_text('yes')
if mode=='sat_bad':sys.exit(1)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r={'status':'VALIDATED','meets_posted_gate_limit':mode!='sat_22','verified_inputs_per_circuit':2048,'provenance':{'cnf_sha256':sha(cnf),'metadata_sha256':sha(cnf.with_suffix('.json')),'kissat_stdout_sha256':sha(model)}}
if mode=='sat_hash':r['provenance']['metadata_sha256']='0'*64
cnf.with_suffix('.validated.json').write_text(json.dumps(r))
'''
class Controls(unittest.TestCase):
 def fixture(self,mode):
  root=Path(tempfile.mkdtemp(prefix=self._testMethodName+'-',dir=D));pins={}
  for k,source in [('solver',SOLVER),('checker',CHECKER),('validator',VALIDATOR)]:
   p=root/(k+'.py');p.write_text(source);p.chmod(0o700);pins[k]=(p,M.digest(p))
  cnf=root/'fixture.cnf';cnf.write_text('p cnf 1 1\n1 0\n');cnf.with_suffix('.json').write_text(json.dumps({'mode':mode}))
  a=SimpleNamespace(cnf=cnf,output=root/'run',cnf_sha256=M.digest(cnf),metadata_sha256=M.digest(cnf.with_suffix('.json')),pins=pins,abort_file=root/'abort',solver_seconds=4,checker_seconds=4,proof_bytes=4096,min_free_bytes=0,max_records=100)
  return root,a
 def execute(self,mode):
  root,a=self.fixture(mode);rc=M.run(a);r=json.loads((a.output/'result.json').read_text());return root,a,rc,r
 def test_verified_unsat_is_sequential_and_retained(self):
  root,a,rc,r=self.execute('unsat');self.assertEqual(rc,0);self.assertTrue(r['accepted_CNF_UNSAT'])
  self.assertEqual(set(r['phases']),{'solver','checker'});self.assertTrue((a.output/'proof.drat').exists());self.assertEqual(r['retained_proof_file']['sha256'],M.digest(a.output/'proof.drat'))
  self.assertGreaterEqual(r['phases']['checker']['started_utc'],r['phases']['solver']['finished_utc'])
 def test_unknown_and_invalid_solver_outcomes_never_start_checker(self):
  for mode in ['unknown','crash','wrong_exit','mixed','overflow','no_proof','ascii_proof','truncated_binary']:
   with self.subTest(mode=mode):
    root,a,rc,r=self.execute(mode);self.assertEqual(rc,2);self.assertFalse(r['accepted_CNF_UNSAT']);self.assertNotIn('checker',r['phases']);self.assertFalse((a.output/'checker-started').exists())
 def test_record_guard_before_checker(self):
  root,a=self.fixture('record_cap');a.max_records=10;self.assertEqual(M.run(a),2);self.assertFalse((a.output/'checker-started').exists())
 def test_checker_invalid_verdict_exit_or_mutation(self):
  for mode in ['valid_only','checker_bad','checker_mutates']:
   with self.subTest(mode=mode):
    root,a,rc,r=self.execute(mode);self.assertEqual(rc,2);self.assertFalse(r['accepted_CNF_UNSAT']);self.assertTrue((a.output/'checker-started').exists())
 def test_sat_full_validation_and_gate_limit(self):
  for mode,expected in [('sat',10),('sat_bad',2),('sat_22',2),('sat_hash',2)]:
   with self.subTest(mode=mode):
    root,a,rc,r=self.execute(mode);self.assertEqual(rc,expected);self.assertTrue((a.output/'validator-started').exists());self.assertNotIn('checker',r['phases']);self.assertFalse(r['accepted_CNF_UNSAT'])
 def test_preexisting_abort_and_hash_mismatch_start_nothing(self):
  for mode in ['abort','hash','disk']:
   root,a=self.fixture('unsat')
   if mode=='abort':a.abort_file.touch()
   elif mode=='disk':a.min_free_bytes=2**63
   else:a.cnf_sha256='0'*64
   self.assertEqual(M.run(a),2);self.assertFalse((a.output/'solver-started').exists())
 def test_fresh_directory(self):
  root,a=self.fixture('unsat');a.output.mkdir();(a.output/'marker').write_text('keep')
  with self.assertRaises(FileExistsError):M.run(a)
  self.assertEqual((a.output/'marker').read_text(),'keep')
 def test_solver_timeout_and_checker_timeout(self):
  for mode in ['hang','checker_hang']:
   with self.subTest(mode=mode):
    root,a=self.fixture(mode);a.solver_seconds=a.checker_seconds=1.2;self.assertEqual(M.run(a),2)
    r=json.loads((a.output/'result.json').read_text());last=r['phases']['solver' if mode=='hang' else 'checker'];self.assertEqual(last['exit_code'],-9);self.assertEqual(last['reason'],'wall_time_limit');self.assertLess(last['elapsed_seconds'],2)
 def test_external_abort_during_solver(self):
  root,a=self.fixture('hang');timer=threading.Timer(.2,a.abort_file.touch);timer.start()
  try:self.assertEqual(M.run(a),2)
  finally:timer.cancel();timer.join()
  r=json.loads((a.output/'result.json').read_text());self.assertEqual(r['phases']['solver']['reason'],'external_abort_file');self.assertNotIn('checker',r['phases'])
if __name__=='__main__':unittest.main(verbosity=2)
