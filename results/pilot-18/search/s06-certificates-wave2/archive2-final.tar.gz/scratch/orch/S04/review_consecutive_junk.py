"""Independent finite port/Boolean-algebra controls for S01's J18 normal form."""
from pathlib import Path
import collections
import hashlib
import itertools
import json
import time

OUT=Path('/tmp/oec/pequalnp-pilot-18/orch/S04')
FULL=(1<<32)-1
PREFIX=[sum(1<<m for m in range(32) if m&(1<<v)) for v in range(5)]+[0,FULL]
BASE=7
COUNTS=collections.Counter()
EXAMPLES={}

def evaluate(gates):
    values=PREFIX[:]
    for op,a,b in gates:
        assert 0<=a<len(values) and 0<=b<len(values)
        values.append(values[a]&values[b] if op else values[a]|values[b])
    return values

def live(gates):
    return all(any(BASE+g in (a,b) for _,a,b in gates[g+1:]) for g in range(3))

def swap(gates):
    def subst(x):return 9 if x==8 else 8 if x==9 else x
    order=[gates[0],gates[2],gates[1],gates[3]]
    return [(op,subst(a),subst(b)) for op,a,b in order]

def triple_copy(d,r):
    return [d,(True,7,7),(True,8,8),(True,9,r)]

def normalize(gates,vals):
    d,o,j,last=gates
    f=vals[-1]
    dirty=lambda value:bool(value&~f)
    operations=''.join('A' if op else 'O' for op,_,_ in gates)
    if dirty(vals[8]) and o[0]:return gates,'already_junk18'
    if operations=='AAAA':
        assert not dirty(vals[8]) and dirty(vals[9])
        assert 8 not in j[1:]
        return swap(gates),'AAAA_swap'
    assert operations=='AOAA',operations
    assert dirty(vals[9]) and 9 in last[1:]
    if 8 not in j[1:]:return swap(gates),'AOAA_swap'
    t=j[2] if j[1]==8 else j[1]
    r=last[2] if last[1]==9 else last[1]
    assert r not in (8,9)
    if t==8:
        if r==7:
            assert 7 not in o[1:]
            return [d,(True,7,7),o,(True,8,9)],'T_O_R_D'
        assert r<7 and 7 in o[1:]
        q=o[2] if o[1]==7 else o[1]
        return [d,(True,7,7),(False,8,q),(True,r,9)],'T_O_R_prefix'
    if t==7 or r==7:
        p=r if t==7 else t
        assert p<7
        role='T_D' if t==7 else 'R_D'
        if 7 in o[1:]:return triple_copy(d,p),role+'_absorb'
        h=vals[p]&vals[7]
        if dirty(h):return [d,(True,p,7),o,(True,8,9)],role+'_H_dirty'
        assert h==f
        return triple_copy(d,p),role+'_H_clean'
    assert t<7 and r<7 and 7 in o[1:]
    h=vals[t]&vals[r]
    assert dirty(h),('would contradict clean-prefix-pair premise',t,r)
    return [d,(True,t,r),o,(True,8,9)],'T_R_prefix'

def main():
    start=time.monotonic()
    shapes=['AAAA','AOAA','AAOA','AAAO']
    # Every D is one of a conjunction of two independent prefix signals,
    # a repeated signal, TRUE with a signal, or TRUE with TRUE. FALSE D
    # cannot satisfy the dirty premise. Extra independent sources permit
    # all five external leaf occurrences of a four-gate connected DAG.
    first_gates=[(True,0,1),(True,0,0),(True,0,6),(True,6,6)]
    pairs_o=list(itertools.combinations_with_replacement(range(8),2))
    pairs_j=list(itertools.combinations_with_replacement(range(9),2))
    prefix_pair_values={a&b for a in PREFIX for b in PREFIX}
    for shape in shapes:
        for d in first_gates:
            for oa,ob in pairs_o:
                for ja,jb in pairs_j:
                    for r in range(10):
                        gates=[d,(shape[1]=='A',oa,ob),(shape[2]=='A',ja,jb),(shape[3]=='A',r,9)]
                        COUNTS['syntactic_cases']+=1
                        if not live(gates):continue
                        vals=evaluate(gates);f=vals[-1]
                        junk=[op and bool(vals[7+i]&~f) for i,(op,_,_) in enumerate(gates)]
                        if not junk[0] or sum(junk)<2:continue
                        # This is precisely the only lower-bound consequence
                        # used in S01's difficult both-prefix-port branch.
                        if f in prefix_pair_values:
                            COUNTS['excluded_prefix_pair_outputs']+=1;continue
                        new,case=normalize(gates,vals)
                        nvals=evaluate(new)
                        assert nvals[-1]==f,('function changed',gates,new,case)
                        assert live(new),('dead suffix gate',gates,new,case)
                        assert new[0][0] and new[1][0]
                        assert nvals[7]&~f and nvals[8]&~f
                        assert new[0]==d
                        COUNTS['checked_cases']+=1
                        COUNTS['shape_'+shape]+=1
                        COUNTS['branch_'+case]+=1
                        if case not in EXAMPLES:
                            EXAMPLES[case]={'before':gates,'after':new,'target_truth_word':f}
    # The controls include semantic clean-H collapses; additionally enumerate
    # all eight possible pointwise values of H,O,F,
    # checking the implication H clean + F=H&O => H=F.
    pointwise=0
    for h,o,f in itertools.product([False,True],repeat=3):
        if f==(h and o) and (not h or f):
            assert h==f;pointwise+=1
    result={'verdict':'PASS_FINITE_CONTROLS','scope':'Port rewrites, Boolean equality, suffix liveness; mathematical prefix-bound premise remains explicit',
            'counts':dict(COUNTS),'rows_per_case':32,'clean_H_pointwise_assignments':pointwise,
            'seconds':time.monotonic()-start,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'reviewed_S01_snapshot_sha256':hashlib.sha256((OUT/'S01-reviewed-snapshot.md').read_bytes()).hexdigest(),
            'examples':EXAMPLES}
    (OUT/'consecutive-junk-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='examples'},indent=2))

if __name__=='__main__':main()
