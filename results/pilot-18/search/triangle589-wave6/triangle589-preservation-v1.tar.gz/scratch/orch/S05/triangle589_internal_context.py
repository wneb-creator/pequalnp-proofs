"""At most three fresh operations replacing one triangle589 internal wire.

All 2048 contexts are retained. The live original-cone union plus new operations
must have at most 21 gates. This does not search simultaneous unrelated rewrites.
"""
from pathlib import Path
import hashlib,json,time,resource,os
from prepare_triangle589 import EDGES
H=Path('/tmp/oec/pequalnp-pilot-18/orch/S05');SOURCE=H/'triangle589-positive21.json'
PIN='2d99849c19f69c76b232e4d55ce487638721291dac4faea3e82dc3274414bfbe'
def main():
    resource.setrlimit(resource.RLIMIT_CPU,(50,50));os.nice(10);start=time.monotonic()
    raw=SOURCE.read_bytes();assert hashlib.sha256(raw).hexdigest()==PIN
    d=json.loads(raw);gates=d['gates'];ones=(1<<2048)-1
    target=sum(1<<m for m in range(2048) if any(m>>a&1 and m>>b&1 for a,b in EDGES))
    sig=[sum(1<<m for m in range(2048) if m>>v&1) for v in range(11)];reach=[0]*11
    for g,(op,a,b) in enumerate(gates):
        sig.append(sig[a]&sig[b] if op=='and' else sig[a]|sig[b]);reach.append(reach[a]|reach[b]|(1<<g))
    assert len(gates)==21 and (sig[d['output']]&~target).bit_count()==10 and not target&~sig[d['output']]
    allrecords=[];status='COMPLETE_ALL21_ROOTS';found=None
    def export(root,expr):
        memo={};canonical={};out=[]
        def mk(op,a,b):
            if a==b:return a
            key=(op,*sorted((a,b)))
            if key not in canonical:canonical[key]=11+len(out);out.append(list(key))
            return canonical[key]
        def old(w):
            if w<11:return w
            key=('old',w)
            if key not in memo:
                op,a,b=gates[w-11];memo[key]=mk(op,old(a),old(b))
            return memo[key]
        def ex(x):
            if isinstance(x,int):return old(x)
            op,a,b=x;return mk(op,ex(a),ex(b))
        def new(w):
            if w==root:return ex(expr)
            if w<11:return w
            key=('new',w)
            if key not in memo:
                op,a,b=gates[w-11];memo[key]=mk(op,new(a),new(b))
            return memo[key]
        output=new(d['output'])
        for m in range(2048):
            v=[bool(m>>i&1) for i in range(11)]
            for op,a,b in out:v.append(v[a] and v[b] if op=='and' else v[a] or v[b])
            assert v[output]==bool(target>>m&1)
        return dict(inputs=11,gate_wire_offset=11,gate_count=len(out),gates=out,output=output,source_sha256=PIN,replace_gate=root-11,replacement=expr,all_2048_scalar_checks_pass=True,Lean_proof=False)
    try:
        for root in [17,19,12,14,16,18,31]+[r for r in range(11,32) if r not in [17,19,12,14,16,18,31]]:
            r=root-11
            contexts=[]
            for value in (0,ones):
                v=sig[:11]
                for g,(op,a,b) in enumerate(gates):v.append(value if g==r else v[a]&v[b] if op=='and' else v[a]|v[b])
                contexts.append(v[d['output']])
            low,high=contexts;assert not low&~high
            if target&~high or low&~target:
                allrecords.append(dict(root_gate=r,status='CANNOT_REPAIR_BY_ONE_WIRE',false_negative_uncontrollable=(target&~high).bit_count(),false_positive_uncontrollable=(low&~target).bit_count()));continue
            must1=target&~low;must0=high&~target
            # Remove the replacement wire from original output ancestry, retaining other branches.
            memo={root:0}
            def context_reach(w):
                if w<11:return 0
                if w not in memo:
                    _,a,b=gates[w-11];memo[w]=context_reach(a)|context_reach(b)|(1<<(w-11))
                return memo[w]
            base=context_reach(d['output'])
            wires=[w for w in range(32) if w<11 or not reach[w]&(1<<r)]
            checked=0;first=[];t0=time.monotonic()
            def test(expr,value,mask,cost):
                nonlocal checked,found
                if (base|mask).bit_count()+cost>21:return
                checked+=1
                if value&must1!=must1 or value&must0:return
                result=export(root,expr);assert result['gate_count']<=21
                p=H/'triangle589-internal-exact21.json'
                with p.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
                found=dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),gates=result['gate_count'],root=r,expr=expr)
                raise RuntimeError('EXACT')
            for ai,a in enumerate(wires):
                test(a,sig[a],reach[a],0)
                for b in wires[ai+1:]:
                    mask=reach[a]|reach[b]
                    if (base|mask).bit_count()+1>21:continue
                    for op,value in [('and',sig[a]&sig[b]),('or',sig[a]|sig[b])]:
                        expr=(op,a,b);test(expr,value,mask,1)
                        if (base|mask).bit_count()+2<=21:first.append((expr,value,mask))
            for x,xv,xm in first:
                for c in wires:
                    m=xm|reach[c]
                    if (base|m).bit_count()+2>21:continue
                    test(('and',x,c),xv&sig[c],m,2);test(('or',x,c),xv|sig[c],m,2)
            for outer in ('and','or'):
                allowed=[t for t in first if (t[1]&must1==must1 if outer=='and' else not t[1]&must0)]
                for i,(x,xv,xm) in enumerate(allowed):
                    for y,yv,ym in allowed[i:]:
                        m=xm|ym
                        if (base|m).bit_count()+3>21:continue
                        test((outer,x,y),xv&yv if outer=='and' else xv|yv,m,3)
                    if time.monotonic()-start>45:raise TimeoutError()
            leaves={op:[w for w in wires if (sig[w]&must1==must1 if op=='and' else not sig[w]&must0)] for op in ('and','or')}
            for x,xv,xm in first:
                for c in wires:
                    mask=xm|reach[c]
                    if (base|mask).bit_count()+3>21:continue
                    for inner,yv in [('and',xv&sig[c]),('or',xv|sig[c])]:
                        for outer in ('and','or'):
                            if outer=='and' and yv&must1!=must1:continue
                            if outer=='or' and yv&must0:continue
                            for e in leaves[outer]:
                                m=mask|reach[e]
                                if (base|m).bit_count()+3>21:continue
                                test((outer,(inner,x,c),e),yv&sig[e] if outer=='and' else yv|sig[e],m,3)
                if time.monotonic()-start>45:raise TimeoutError()
            allrecords.append(dict(root_gate=r,status='COMPLETE_COST_FILTERED_UP_TO3',base_gate_count=base.bit_count(),available_wires=wires,must_true_inputs=must1.bit_count(),must_false_inputs=must0.bit_count(),checked=checked,elapsed_seconds=time.monotonic()-t0))
    except TimeoutError:status='TIME_LIMIT_PARTIAL'
    except RuntimeError as e:
        if str(e)!='EXACT':raise
        status='EXACT_AT_MOST21_NEEDS_RAW_VALIDATOR_AND_LEAN'
    result=dict(status=status,source_sha256=PIN,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),elapsed_seconds=time.monotonic()-start,records=allrecords,checked=sum(r.get('checked',0) for r in allrecords),candidate=found,scope='One internal substitution at a time, <=3 fresh-operation trees, no source descendant of replacement root as a leaf, original live-cone union + fresh cost <=21.')
    with (H/'triangle589-internal-context-result.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k!='records'}))
if __name__=='__main__':main()
