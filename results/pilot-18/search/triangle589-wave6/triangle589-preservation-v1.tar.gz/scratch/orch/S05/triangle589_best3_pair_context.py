"""Finite coupled repair of roots6 and17 in the improved triangle589 circuit.

Two-root shapes: one root <=1 new op and other <=2 using that root; or
two one-op roots sharing a single fresh intermediate. Total fresh gates <=3.
Includes alias roots, excludes general3+0 trees and arbitrary simultaneous edits.
"""
from pathlib import Path
import time,json,hashlib,resource,os
from prepare_triangle589 import EDGES
H=Path('/tmp/oec/pequalnp-pilot-18/orch/S05');P=H/'triangle589-best3-analysis/original-offset11.json'
PIN='f3c2bacb85a0ce0e080072ad39b0a695f90affb6f7204880c44acdf496195790'
def main():
    resource.setrlimit(resource.RLIMIT_CPU,(50,50));os.nice(10);t0=time.monotonic()
    assert hashlib.sha256(P.read_bytes()).hexdigest()==PIN
    data=json.loads(P.read_text());gates=data['gates'];ones=(1<<2048)-1
    target=sum(1<<m for m in range(2048) if any(m>>a&1 and m>>b&1 for a,b in EDGES))
    sig=[sum(1<<m for m in range(2048) if m>>v&1) for v in range(11)];reach=[0]*11
    for g,(op,a,b) in enumerate(gates):sig.append(sig[a]&sig[b] if op=='and' else sig[a]|sig[b]);reach.append(reach[a]|reach[b]|(1<<g))
    roots=(17,28);cut=sum(1<<(r-11) for r in roots)
    wires=[w for w in range(32) if not reach[w]&cut]
    def context(x,y):
        vals=sig[:11]
        for g,(op,a,b) in enumerate(gates):
            w=11+g;vals.append(x if w==roots[0] else y if w==roots[1] else vals[a]&vals[b] if op=='and' else vals[a]|vals[b])
        return vals[data['output']]
    c00=context(0,0);c01=context(0,ones);c10=context(ones,0);c11=context(ones,ones)
    assert not c00&~target and not target&~c11
    memo={r:0 for r in roots}
    def remaining(w):
        if w<11:return 0
        if w not in memo:
            _,a,b=gates[w-11];memo[w]=remaining(a)|remaining(b)|(1<<(w-11))
        return memo[w]
    base=remaining(data['output']);assert base.bit_count()==16
    # Each term carries expression, complete truth table, original cone mask, fresh DAG nodes.
    leaves=[(w,sig[w],reach[w],frozenset()) for w in wires]
    def combine(op,x,y):
        e=(op,x[0],y[0]);return (e,x[1]&y[1] if op=='and' else x[1]|y[1],x[2]|y[2],x[3]|y[3]|{e})
    def cost(x,y):return (base|x[2]|y[2]).bit_count()+len(x[3]|y[3])
    first=[]
    for i,x in enumerate(leaves):
        for y in leaves[i+1:]:
            for op in ('and','or'):
                z=combine(op,x,y)
                if (base|z[2]).bit_count()+1<=21:first.append(z)
    checked=0;condition_feasible=0;found=None;counts={};best22=[]
    def export(x,y):
        original={};replaced={};canonical={};out=[]
        def mk(op,a,b):
            if a==b:return a
            key=(op,*sorted((a,b)))
            if key not in canonical:canonical[key]=11+len(out);out.append(list(key))
            return canonical[key]
        def old(w):
            if w<11:return w
            if w not in original:
                op,a,b=gates[w-11];original[w]=mk(op,old(a),old(b))
            return original[w]
        def ex(e):
            if isinstance(e,int):return old(e)
            op,a,b=e;return mk(op,ex(a),ex(b))
        def new(w):
            if w==roots[0]:return ex(x[0])
            if w==roots[1]:return ex(y[0])
            if w<11:return w
            if w not in replaced:
                op,a,b=gates[w-11];replaced[w]=mk(op,new(a),new(b))
            return replaced[w]
        output=new(data['output'])
        for m in range(2048):
            v=[bool(m>>i&1) for i in range(11)]
            for op,a,b in out:v.append(v[a] and v[b] if op=='and' else v[a] or v[b])
            assert v[output]==bool(target>>m&1)
        return dict(inputs=11,gate_wire_offset=11,gate_count=len(out),gates=out,output=output,source_sha256=PIN,replaced_roots=[r-11 for r in roots],replacement_x=x[0],replacement_y=y[0],all_2048_scalar_checks_pass=True,Lean_proof=False)
    def test(x,y,tag):
        nonlocal checked,found
        if len(x[3]|y[3])>3 or cost(x,y)>21:return
        checked+=1;counts[tag]=counts.get(tag,0)+1
        actual=c00|(x[1]&c10)|(y[1]&c01)|(x[1]&y[1]&c11)
        if actual!=target:return
        result=export(x,y);assert result['gate_count']<=21
        p=H/'triangle589-best3-pair-exact21.json'
        with p.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
        found=dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),gate_count=result['gate_count'])
        raise RuntimeError('EXACT')
    def requirements(x,swap):
        nonlocal condition_feasible
        lo=c00|(x[1]&(c01 if swap else c10));hi=(c10 if swap else c01)|(x[1]&c11)
        if lo&~target or target&~hi:return None
        condition_feasible+=1;return target&~lo,hi&~target
    status='COMPLETE_STATED_TWO_ROOT_SHAPES'
    try:
        for swap in (False,True):
            for x in leaves+first:
                req=requirements(x,swap)
                if req is None:continue
                must1,must0=req
                def emit(y,tag):
                    if y[1]&must1==must1 and not y[1]&must0:test(y,x,tag) if swap else test(x,y,tag)
                candidates=leaves+[x]
                for y in candidates:emit(y,'alias')
                mids=[]
                for i,a in enumerate(candidates):
                    for b in candidates[i+1:]:
                        for op in ('and','or'):
                            z=combine(op,a,b)
                            if len(x[3]|z[3])<=3 and cost(x,z)<=21:
                                emit(z,'one_plus_one');mids.append(z)
                for z in mids:
                    for w in candidates:
                        for op in ('and','or'):
                            value=z[1]&w[1] if op=='and' else z[1]|w[1]
                            if value&must1!=must1 or value&must0:continue
                            emit(combine(op,z,w),'one_plus_two')
                if time.monotonic()-t0>45:raise TimeoutError()
        # Both new roots can share a fresh first gate, with neither root equal to it.
        for common in first:
            outer=[combine(op,common,w) for w in leaves for op in ('and','or')]
            for x in outer:
                req=requirements(x,False)
                if req is None:continue
                must1,must0=req
                for y in outer:
                    if y[1]&must1==must1 and not y[1]&must0:test(x,y,'shared_first_gate')
            if time.monotonic()-t0>45:raise TimeoutError()
    except TimeoutError:status='TIME_LIMIT_PARTIAL'
    except RuntimeError as e:
        if str(e)!='EXACT':raise
        status='EXACT_AT_MOST21_NEEDS_RAW_VALIDATOR_AND_LEAN'
    report=dict(status=status,source_sha256=PIN,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),roots=[r-11 for r in roots],base_original_gate_count=base.bit_count(),available_wires=wires,conditional_contexts_feasible=condition_feasible,fully_matching_checks=checked,matching_shapes=counts,candidate=found,elapsed_seconds=time.monotonic()-t0,scope='Two roots6/17; one root <=1 fresh and other <=2 with reuse, or two roots sharing fresh first gate. All original cone sharing counted; <=3 fresh DAG nodes; <=21 total. Excludes general3+0 trees and other root pairs.')
    with (H/'triangle589-best3-pair-context-result.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
    print(json.dumps(report))
if __name__=='__main__':main()
