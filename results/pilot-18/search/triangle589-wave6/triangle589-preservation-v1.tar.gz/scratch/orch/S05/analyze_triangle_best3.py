"""Immutable finite analysis of the improved triangle589 seed; no search launch."""
from pathlib import Path
from itertools import combinations
import importlib.util,json,hashlib,time,datetime
from prepare_triangle589 import EDGES,NEG,evaluate,write,sha
R=Path('/tmp/oec/pequalnp-pilot-18');H=R/'orch/S05'
P=R/'triangle589-candidate-134226/engine-result.json.best-3.json'
PIN='9a743d5d43f651198f908fd086b3307e036697ee9d9990f5c0edfcce6ff3fe96'
def main():
    start=time.monotonic();out=H/'triangle589-best3-analysis';out.mkdir(exist_ok=False)
    raw=P.read_bytes();assert hashlib.sha256(raw).hexdigest()==PIN
    (out/'source.json').write_bytes(raw);d=json.loads(raw)
    assert d['size']==21 and d['gate_wire_offset']==13
    target=[any(m>>a&1 and m>>b&1 for a,b in EDGES) for m in range(2048)]
    vals=[evaluate(d,m) for m in range(2048)];values=[v[d['output']] for v in vals]
    fp=[m for m in range(2048) if values[m] and not target[m]];fn=[m for m in range(2048) if target[m] and not values[m]]
    assert not fn and fp==[21,29,85,148,149]
    assert all(values[m]==(target[m] or bool(m>>2&1 and m>>4&1 and (m&129))) for m in range(2048))
    live=set();todo=[d['output']]
    while todo:
        w=todo.pop()
        if w>=13 and w-13 not in live:live.add(w-13);todo.extend(d['gates'][w-13][1:])
    junk=[g for g,(op,a,b) in enumerate(d['gates']) if op=='and' and any(not target[m] and vals[m][13+g] for m in range(2048))]
    rows=[(1<<a)|(1<<b) for a,b in EDGES]+NEG;full=(1<<40)-1;pos=(1<<16)-1;neg=full^pos
    inputs=[sum(1<<i for i,m in enumerate(rows) if m>>v&1) for v in range(11)]+[0,full]
    def vector(holes=(),forced=0):
        v=inputs[:]
        for g,(op,a,b) in enumerate(d['gates']):v.append(forced if g in holes else v[a]&v[b] if op=='and' else v[a]|v[b])
        return v
    base=vector()[d['output']];impacts=[]
    for g in range(21):
        low=vector([g],0)[d['output']];high=vector([g],full)[d['output']]
        impacts.append(dict(gate=g,op=d['gates'][g][0],fixed_false_positive_masks=[m for i,m in enumerate(rows) if i>=16 and base>>i&1 and not low>>i&1],lost_positive_edges=[EDGES[i] for i in range(16) if not low>>i&1],influence_rows=[m for i,m in enumerate(rows) if (low^high)>>i&1]))
    # Structural proposals include the two genuinely dirty ANDs and their OR contexts.
    proposals=[[4,5,17],[3,4,5,17,19],[3,4,5,17,18,19,20],[0,3,4,5,6,17,18,19],[3,4,5,11,12,13,17,18,19,20]]
    windows=[]
    for holes in proposals:
        low=vector(holes,0)[d['output']];high=vector(holes,full)[d['output']]
        windows.append(dict(free_gates=holes,hole_count=len(holes),row_oracle_necessary_pass=not (low&neg or pos&~high),live_junk_included=sorted(set(holes)&set(junk)),negative_rows_touched=len({m for g in holes for m in impacts[g]['fixed_false_positive_masks']}),positive_edges_at_risk=sorted({tuple(e) for g in holes for e in impacts[g]['lost_positive_edges']})))
    # Preserve a normalized, constant-free original-wire version for algebra/emitter intake.
    assert all(w not in [11,12] for row in d['gates'] for w in row[1:])
    remap=lambda w:w if w<11 else w-2
    normalized=dict(inputs=11,gate_wire_offset=11,gate_count=21,gates=[[op,remap(a),remap(b)] for op,a,b in d['gates']],output=remap(d['output']),source_sha256=PIN,exact_target=False)
    for m in range(2048):
        v=evaluate(normalized,m);assert v[normalized['output']]==values[m]
        for g in range(21):assert v[11+g]==vals[m][13+g]
    write(out/'original-offset11.json',normalized)
    assert P.read_bytes()==raw
    report=dict(status='INEXACT_BETTER_NONLINEAR_SEED',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_path=str(P),source_sha256=PIN,source_stable_after_read=True,script_sha256=sha(Path(__file__)),live_gates=sorted(live),dead_slots=sorted(set(range(21))-live),junk_gates=junk,full_fn=fn,full_fp=fp,boundary_fp=[m for m in NEG if values[m]],minimal_extra_masks=[21,148],minimal_extra_sets=[[0,2,4],[2,4,7]],exact_shape='F OR (x2 AND x4 AND (x0 OR x7))',full_2048_shape_checks_pass=True,normalization_intermediate_comparisons=2048*21,normalization_sha256=sha(out/'original-offset11.json'),suppression_impact=impacts,proposed_windows=windows,window_oracle_warning='Only necessary per-row free-output relaxation, not simultaneous implementability or SAT feasibility.',elapsed_seconds=time.monotonic()-start)
    write(out/'report.json',report)
    print(json.dumps({k:v for k,v in report.items() if k not in ['suppression_impact','proposed_windows']}))
if __name__=='__main__':main()
