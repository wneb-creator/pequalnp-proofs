"""Bounded scalar enumeration of a distinct one-component algebra family.

D = OR(A) AND (xc OR (OR(B) AND OR(C))). Remaining target edges are
implemented independently by clean stars; no cross-component sharing is counted.
"""
from pathlib import Path
from functools import lru_cache
import json,time,hashlib,resource,os
from prepare_triangle589 import EDGES,NEG
H=Path('/tmp/oec/pequalnp-pilot-18/orch/S05')
def main():
    os.nice(15);resource.setrlimit(resource.RLIMIT_CPU,(5,5));start=time.monotonic()
    rows=[(1<<a)|(1<<b) for a,b in EDGES]+NEG;pos=(1<<16)-1
    linear=[sum(1<<i for i,m in enumerate(rows) if m&s) for s in range(2048)]
    incident=[sum(1<<i for i,e in enumerate(EDGES) if v in e) for v in range(11)]
    @lru_cache(None)
    def cover(mask):
        if not mask:return 0
        a,b=EDGES[(mask&-mask).bit_length()-1]
        return 1+min(cover(mask&~incident[a]),cover(mask&~incident[b]))
    best=100;records=[];count=0;ab_count=0;complete=True;best_by_edges={}
    for c in range(11):
        neighborhood=sum(1<<(b if a==c else a) for a,b in EDGES if c in (a,b))
        A=neighborhood
        while A:
            bad=[m for m in NEG if m&A]
            av=linear[A];cv=linear[1<<c];ac=A.bit_count()
            for B in range(1,2048):
                ab_count+=1
                if ab_count%1024==0 and time.monotonic()-start>2.0:complete=False;break
                forbidden=0
                for m in bad:
                    if m&B:forbidden|=m
                allowed=2047^forbidden;C=allowed;bv=linear[B];bc=B.bit_count()
                while C:
                    if C<=B and not (B&C==B or B&C==C):
                        count+=1;cost=ac+bc+C.bit_count()
                        edges=av&(cv|(bv&linear[C]));assert not edges>>16
                        residual=pos^edges
                        total=cost+(residual.bit_count()+cover(residual) if residual else 0)
                        if edges not in best_by_edges or cost<best_by_edges[edges][0]:best_by_edges[edges]=(cost,c,A,B,C)
                        if total<best:best=total;records=[]
                        if total==best and len(records)<100:records.append(dict(c=c,A=A,B=B,C=C,contributor_cost=cost,edges=edges,residual=residual,total=total))
                    C=(C-1)&allowed
            if not complete:break
            A=(A-1)&neighborhood
        if not complete:break
    data=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='No cross-component sharing; literal three-clause linear OR cost, one raw center c; independent clean-star residual with optimal vertex cover. B/C nonnested by absorption.',complete=complete,ab_pairs=ab_count,triples=count,distinct_edge_masks=len(best_by_edges),minimum_total=best,best=records,elapsed_seconds=time.monotonic()-start,exact21_found=best<=21)
    with (H/'guarded-component-result.json').open('x') as f:json.dump(data,f,indent=2);f.write('\n')
    with (H/'guarded-component-costs.json').open('x') as f:json.dump(best_by_edges,f);f.write('\n')
    print(json.dumps({k:v for k,v in data.items() if k!='best'}))
if __name__=='__main__':main()
