"""Small full-context algebraic completion of a positive dirty source."""
from pathlib import Path
import hashlib
import json
import time

HERE=Path('/tmp/oec/pequalnp-pilot-18/orch/S05')
SOURCE=HERE/'dirty22-positive-shapes/d16-right-absorbed18.json'
PIN='f54738c35881deea8ba24b6f15cc533042e7db6342e6c31e481528868bc0b8cd'
EDGES=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
       (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]

def main():
    start=time.monotonic();raw=SOURCE.read_bytes();assert hashlib.sha256(raw).hexdigest()==PIN
    data=json.loads(raw);gates=data['gates'];allbits=(1<<2048)-1
    target=sum(1<<m for m in range(2048) if any(m>>a&1 and m>>b&1 for a,b in EDGES))
    sig=[sum(1<<m for m in range(2048) if m>>v&1) for v in range(11)]+[0,allbits]
    reach=[0]*13
    for g,(op,a,b) in enumerate(gates):
        sig.append(sig[a]&sig[b] if op=='and' else sig[a]|sig[b]);reach.append(reach[a]|reach[b]|(1<<g))
    wires=list(range(11))+list(range(13,34))
    assert not target&~sig[data['output']] and reach[data['output']].bit_count()==18
    checked=0;hits=[];status='COMPLETE_COST_FILTERED_THREE_OPERATION_TREES'
    def export(expr):
        memo={i:i for i in range(11)};canonical={};new=[]
        def rec(x):
            if x in memo:return memo[x]
            op,a,b=gates[x-13] if isinstance(x,int) else x
            a,b=sorted((rec(a),rec(b)))
            if a==b:ans=a
            else:
                key=(op,a,b)
                if key not in canonical:canonical[key]=11+len(new);new.append([op,a,b])
                ans=canonical[key]
            memo[x]=ans;return ans
        output=rec(expr)
        result=dict(inputs=11,gate_wire_offset=11,gate_count=len(new),gates=new,output=output)
        for mask in range(2048):
            v=[bool(mask>>i&1) for i in range(11)]
            for op,a,b in new:v.append(v[a] and v[b] if op=='and' else v[a] or v[b])
            assert v[output]==bool(target>>mask&1)
        return result
    def test(expr,value,mask,cost):
        nonlocal checked
        checked+=1
        if value!=target:return
        if mask.bit_count()+cost>22:return
        result=export(expr)
        hits.append(dict(cost=result['gate_count'],expr=expr))
        if result['gate_count']<=21:
            result.update(source_sha256=PIN,all_2048_inputs_pass=True,lean_proof=False)
            with (HERE/'positive-context-exact21.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
            raise RuntimeError('FOUND_EXACT_AT_MOST_21')
    first=[]
    try:
        for ai,a in enumerate(wires):
            test(a,sig[a],reach[a],0)
            for b in wires[ai+1:]:
                mask=reach[a]|reach[b]
                for op,value in [('and',sig[a]&sig[b]),('or',sig[a]|sig[b])]:
                    expr=(op,a,b);test(expr,value,mask,1)
                    if mask.bit_count()+2<=22:first.append((expr,value,mask))
        for x,xv,xm in first:
            for c in wires:
                m=xm|reach[c]
                if m.bit_count()+2>22:continue
                test(('and',x,c),xv&sig[c],m,2);test(('or',x,c),xv|sig[c],m,2)
        for outer in ('and','or'):
            allowed=[t for t in first if (t[1]&target==target if outer=='and' else not t[1]&~target)]
            for i,(x,xv,xm) in enumerate(allowed):
                for y,yv,ym in allowed[i:]:
                    m=xm|ym
                    if m.bit_count()+3>22:continue
                    test((outer,x,y),xv&yv if outer=='and' else xv|yv,m,3)
                if time.monotonic()-start>10:raise TimeoutError()
        leaves={op:[w for w in wires if (sig[w]&target==target if op=='and' else not sig[w]&~target)] for op in ('and','or')}
        for x,xv,xm in first:
            for c in wires:
                mask=xm|reach[c]
                if mask.bit_count()+3>22:continue
                for inner,yv in [('and',xv&sig[c]),('or',xv|sig[c])]:
                    for outer in ('and','or'):
                        if outer=='and' and yv&target!=target:continue
                        if outer=='or' and yv&~target:continue
                        for d in leaves[outer]:
                            m=mask|reach[d]
                            if m.bit_count()+3>22:continue
                            test((outer,(inner,x,c),d),yv&sig[d] if outer=='and' else yv|sig[d],m,3)
            if time.monotonic()-start>10:raise TimeoutError()
    except TimeoutError:status='TIME_LIMIT'
    except RuntimeError as e:
        if str(e)!='FOUND_EXACT_AT_MOST_21':raise
        status='FOUND_EXACT_AT_MOST_21'
    report=dict(status=status,elapsed_seconds=time.monotonic()-start,source_sha256=PIN,
                script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                checked=checked,exact_target_hits=hits,best_exact_gate_count=min((x['cost'] for x in hits),default=None),
                scope='Up to three fresh operation trees over existing nonlinear positive-source wires, including arbitrary shared original subcircuits. Cost-filtered with one-gate margin; no global completeness claim.',no_solver=True)
    with (HERE/'positive-context-completion.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
    print(json.dumps(report))

if __name__=='__main__':main()
