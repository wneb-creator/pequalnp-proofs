"""Small scalar extension: reuse full contributor clauses in residual clean stars."""
from pathlib import Path
from functools import lru_cache
import json,time,hashlib,resource,os
from prepare_triangle589 import EDGES,NEG
H=Path('/tmp/oec/pequalnp-pilot-18/orch/S05')
def main():
    os.nice(15);resource.setrlimit(resource.RLIMIT_CPU,(5,5));start=time.monotonic()
    rows=[(1<<a)|(1<<b) for a,b in EDGES]+NEG;pos=(1<<16)-1
    linear=[sum(1<<i for i,m in enumerate(rows) if m&s) for s in range(2048)]
    incident=[sum(1<<i for i,e in enumerate(EDGES) if v in e) for v in range(11)]
    neighborhoods=[sum(1<<(b if a==v else a) for a,b in EDGES if v in (a,b)) for v in range(11)]
    @lru_cache(None)
    def cover(mask):
        if not mask:return (0,0)
        a,b=EDGES[(mask&-mask).bit_length()-1]
        opts=[]
        for v in (a,b):
            cost,vertices=cover(mask&~incident[v]);opts.append((cost+1,vertices|(1<<v)))
        return min(opts)
    owners={s:[v for v,n in enumerate(neighborhoods) if not s&~n] for s in range(1,2048)}
    star={(v,s):sum(1<<i for i,(a,b) in enumerate(EDGES) if (a==v and s>>b&1) or (b==v and s>>a&1)) for s,vs in owners.items() for v in vs}
    best=100;records=[];count=0;ab_count=0;complete=True;shared_checked=0;improvements=0
    for c in range(11):
        A=neighborhoods[c]
        while A:
            bad=[m for m in NEG if m&A];av=linear[A];cv=linear[1<<c];ac=A.bit_count()
            for B in range(1,2048):
                ab_count+=1
                if ab_count%1024==0 and time.monotonic()-start>2.5:complete=False;break
                forbidden=0
                for m in bad:
                    if m&B:forbidden|=m
                allowed=2047^forbidden;C=allowed;bv=linear[B];bc=B.bit_count()
                while C:
                    if C<=B and not (B&C==B or B&C==C):
                        count+=1;cost=ac+bc+C.bit_count()
                        if cost<=21:
                            edges=av&(cv|(bv&linear[C]));assert not edges>>16
                            residual=pos^edges
                            original=cost+residual.bit_count()+cover(residual)[0]
                            choices=[(v,s) for s in set((A,B,C)) if s.bit_count()>1 for v in owners[s] if (star[(v,s)]&residual).bit_count()>1]
                            for subset in range(1,1<<len(choices)):
                                shared_checked+=1;selected=[choices[j] for j in range(len(choices)) if subset>>j&1]
                                active=set(v for v,s in selected);covered=0;active_incident=0
                                for v,s in selected:covered|=star[(v,s)];active_incident|=incident[v]
                                remaining=residual&~covered
                                # Merge the selected clause signals for a shared center, then add
                                # any nonfree leaves assigned to it. New centers pay ordinary stars.
                                total=cost+len(selected)+len(active)+remaining.bit_count()+cover(remaining&~active_incident)[0]
                                if total<original:improvements+=1
                                if total<best:best=total;records=[]
                                if total==best and len(records)<100:records.append(dict(c=c,A=A,B=B,C=C,contributor_cost=cost,edges=edges,residual=residual,selected=selected,total=total,independent_total=original))
                    C=(C-1)&allowed
            if not complete:break
            A=(A-1)&neighborhoods[c]
        if not complete:break
    data=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='One guarded raw-center component, full A/B/C clause reuse in clean residual stars; no arbitrary nonlinear sharing.',complete=complete,ab_pairs=ab_count,triples=count,shared_choices_checked=shared_checked,improved_over_separate=improvements,minimum_shared_total=best if records else None,best=records,elapsed_seconds=time.monotonic()-start,has_recipe_at_most21=bool(records) and best<=21)
    with (H/'shared-guarded-component-result.json').open('x') as f:json.dump(data,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in data.items() if k!='best'}))
if __name__=='__main__':main()
