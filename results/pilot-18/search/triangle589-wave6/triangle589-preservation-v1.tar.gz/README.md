# Triangle589 and improved best3 research preservation

These are inexact 21-gate search seeds, not witnesses for the posted theorem.
Initial seed: F OR x2(x0 OR x7)(x1 OR x4), 0 full FN / 10 full FP / 6 boundary FP.
Best3 seed: F OR x2*x4*(x0 OR x7), 0 full FN / 5 full FP / 3 boundary FP.
Both contain only AND/OR operations and 21 live gates. Original sources, both
packs (16 and 8 schedules), complete self-test logs, main scalar reviews, all
bounded triangle-context sources/results/logs and supporting algebra are retained.
No context enumeration found an exact <=21 circuit. These local failures are not
a global lower bound or a shard refutation. No new Lean theorem is claimed.

The reviewed-engine/ tree is the exact flattened contents of the independently
reviewed direct21-preservation-v1 archive SHA256
70858a65855a12f1345980afbfd2c490bec7963fcf3c1c3aa58847108b441323.
It has engine and parent source, derivation, compiler/build provenance, complete
finite controls, unchanged wrapper/raw-validator sources, and review. The compiled
engine is deliberately absent; its observed binary hash remains in build-result.json.
Build recipe: g++ -std=c++17 -O3 -Wall -Wextra -Wpedantic SOURCE -o OUTPUT.
Do not launch a production search from this archive without main's admission.
Any candidate still requires the unchanged independent raw validator and Lean.

The original scripts and metadata retain historical absolute scratch paths. Their
archive mapping is scratch/<path relative to /tmp/oec/pequalnp-pilot-18>. They are
verbatim provenance, not instructions to overwrite those locations. Pack semantics
and all payload hashes can be checked anywhere, without compiling or launching:

python3 scratch/orch/S05/verify_triangle589_archive.py ARCHIVE.tar.gz --report REPORT.json

This portable verifier reads members without extraction, checks their exact hashes,
all 49152 packed outputs, all 1032192 remapped original intermediate values, FNV
metadata, source functions and gate-index structure. It never executes an engine.
The two generators are included; reproducing them in a fresh copied root requires
relocating their hardcoded ROOT/R/H paths. Generated pack bytes are deterministic;
metadata source paths and preparer hashes record the original generation location.

Completed production-wave logs are separately preserved by main; this archive
contains immutable source snapshots and finite controls, and does not read active
worker output directories. The proposed broader six-gate core-prefix enumeration
has NOT been run or claimed. Free-E results are formula and one-shared-intermediate
families only. Main alone handles review, copying into repository and publication.
