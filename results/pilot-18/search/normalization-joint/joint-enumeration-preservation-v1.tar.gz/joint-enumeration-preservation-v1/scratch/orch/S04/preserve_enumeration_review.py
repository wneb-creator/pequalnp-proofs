from pathlib import Path
import hashlib,json,tarfile,gzip,io,datetime
R=Path('/workspace/pequalnp-proofs');S=Path('/tmp/oec/pequalnp-pilot-18');O=S/'orch/S04';P=O/'joint-enumeration-preservation-v1'
P.mkdir(exist_ok=False)
files=[S/'orch/S01'/n for n in ['enumerate_joint_supports.py','joint-support-enumeration.json','joint-support-enumeration.stdout.txt','joint-support-enumeration.stderr.txt']]
files += [O/n for n in ['review_joint_enumeration.py','joint-enumeration-review.json','joint-enumeration-review.stdout.log','joint-enumeration-review.stderr.log','preserve_enumeration_review.py']]
files += [R/'results/orch/lemmas/S04-redteam.md']
records=[]
for p in files:
 assert p.is_file() and not p.is_symlink()
 rel=Path('repo')/p.relative_to(R) if p.is_relative_to(R) else Path('scratch')/p.relative_to(S)
 raw=p.read_bytes();q=P/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw)
 records.append(dict(source_path=str(p),archive_path=str(rel),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw)))
manifest=dict(scope='Independent positive-survivor/pruning review and complete k3/r0 support-relaxation traversal only; no circuit construction or global exhaustion.',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),base_archive_sha256='ab76bf72819cac52f98c13d133b94fceedc2dc7fa4952ef06f825d19081beea4',files=records,raw_CNF_count=0,solver_run=False,Lean_build=False)
(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
a=O/'joint-enumeration-preservation-v1.tar.gz'
with a.open('wb') as stream,gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for p in sorted(P.rglob('*')):
  if not p.is_file():continue
  raw=p.read_bytes();info=tarfile.TarInfo('joint-enumeration-preservation-v1/'+str(p.relative_to(P)));info.size=len(raw);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
with tarfile.open(a,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==11
 for member in members:
  assert member.isfile() and '..' not in Path(member.name).parts
  rel=member.name.removeprefix('joint-enumeration-preservation-v1/')
  assert tar.extractfile(member).read()==(P/rel).read_bytes()
result=dict(verdict='PASS_PRESERVATION',archive=str(a),archive_sha256=hashlib.sha256(a.read_bytes()).hexdigest(),archive_bytes=a.stat().st_size,regular_members=11,manifest_sha256=hashlib.sha256((P/'manifest.json').read_bytes()).hexdigest(),files=records,base_archive_unchanged=True)
(O/'joint-enumeration-preservation-handoff.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['verdict','archive','archive_sha256','archive_bytes','regular_members','manifest_sha256']}))
