from pathlib import Path
import hashlib,itertools,json,time
O=Path('/tmp/oec/pequalnp-pilot-18/orch/S04');I=O.parent/'S01'
start=time.monotonic()
source=I/'enumerate_joint_supports.py';reported=I/'joint-support-enumeration.json'
claim=json.loads(reported.read_text())
assert hashlib.sha256(source.read_bytes()).hexdigest()==claim['source_sha256']=='1fa83032ddea490b4c7909362d9bd3e3b7b40e99f306cafc20845c2a220567a0'
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
EM=[(1<<a)|(1<<b) for a,b in E]
def F(x):return any(x&e==e for e in EM)
ind=[x for x in range(2048) if not F(x)]
# Maximal independent sets by direct one-vertex extension test.
mis=[x for x in ind if all(F(x|(1<<v)) for v in range(11) if not x>>v&1)]
assert mis==claim['MIS'] and len(mis)==24
neighbors=[{b if a==v else a for a,b in E if v in(a,b)} for v in range(11)]
covers=sorted(range(2048),key=lambda c:(c.bit_count(),c));costcache={};pool=[]
for s in range(2047):
 residual=tuple(e for e in EM if not s&e)
 if residual not in costcache:
  c=next(c for c in covers if all(c&e for e in residual));costcache[residual]=c
 c=costcache[residual];cost=s.bit_count()+len(residual)+c.bit_count()-1
 zero=sum(1<<b for b,x in enumerate(mis) if not x&s)
 support={v for v in range(11) if s>>v&1}
 common=[v for v,n in enumerate(neighbors) if support<=n]
 if cost<=17 and zero:
  pool.append(dict(s=s,z=zero,cost=cost,cn=sum(1<<v for v in common),residual=len(residual),tau=c.bit_count(),cover=c))
assert len(pool)==claim['support_candidate_count']==958
for a in claim['survivor']:
 b=next(x for x in pool if x['s']==a['s'])
 assert all(b[k]==v for k,v in a.items())
common_pool=[a for a in pool if a['cn']]
assert len(common_pool)==49
FULL=(1<<24)-1

def evaluate_family(family):
 masks=[a['z'] for a in family]
 covered=0
 for z in masks:covered|=z
 if covered!=FULL:return None
 private=[]
 for i,z in enumerate(masks):
  other=0
  for j,w in enumerate(masks):
   if j!=i:other|=w
  z &= ~other
  if not z:return None
  private.append([mis[b] for b in range(24) if z>>b&1])
 if any(cost>capacity for cost,capacity in zip(sorted(a['cost'] for a in family),[15,16,17])):return None
 joint=[]
 for i,a in enumerate(family):
  owners=0;z=0
  for j,b in enumerate(family):
   if j==i:continue
   if not b['cn']:z+=1
   else:owners|=b['cn']
  d=(owners&a['s']).bit_count()
  bound=a['cost']+z+d if a['residual'] else a['cost']
  if bound>17:return None
  joint.append(bound)
 return dict(supports=[a['s'] for a in family],individual_costs=[a['cost'] for a in family],joint_costs=joint,private_MIS=private)
reported_review=evaluate_family(claim['survivor']);assert reported_review
for x in range(2048):
 values=[F(x) or bool(x&a['s']) for a in claim['survivor']]
 assert all(values)==F(x)
complete=[];triples=0
for family in itertools.combinations(common_pool,3):
 triples+=1
 r=evaluate_family(family)
 if r:complete.append(r)
assert triples==18424 and any(set(r['supports'])==set(reported_review['supports']) for r in complete)
# The tight distinguished C={4,6} cost16 with charge owner4 forces the
# other output B={9,10} inside its ancestor cone under the 17-gate budget.
ancestry=[]
for Ain,Bin in itertools.product([False,True],repeat=2):
 cone=16+int(Ain);outside=int(not Ain)+int(not Bin);total=cone+outside
 ancestry.append(dict(A_is_ancestor_of_C=Ain,B_is_ancestor_of_C=Bin,cone_minimum=cone,outside_count=outside,total_minimum=total,compatible_with_17=total<=17))
assert all(a['B_is_ancestor_of_C'] for a in ancestry if a['compatible_with_17'])
result=dict(verdict='PASS_SURVIVOR_AND_PRUNING_REVIEW_NO_EXHAUSTION_CLAIM',script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_sha256=claim['source_sha256'],reported_result_sha256=hashlib.sha256(reported.read_bytes()).hexdigest(),support_candidates=958,common_neighbor_candidates=49,independent_complete_scope='All 18424 unordered triples from the 49 all-common-neighbor candidates; exact individual/slot/joint/minimal-MIS tests only.',triples_examined=triples,surviving_triples=len(complete),survivors=complete,reported_survivor=reported_review,all_input_identity_rows=2048,forced_ancestry_for_reported_survivor=ancestry,seconds=time.monotonic()-start,solver_run=False,Lean_proof=False,limitation='These are support relaxation survivors, not shared productive clean prefixes or <=21 witnesses. S01 stopped at first survivor; no exhaustive negative result was claimed.')
(O/'joint-enumeration-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['verdict','script_sha256','source_sha256','support_candidates','triples_examined','surviving_triples','seconds']}))
print(json.dumps(reported_review))
print('Conditional on a 17-gate prefix: H_{9,10} must be an ancestor of H_{4,6}.')
