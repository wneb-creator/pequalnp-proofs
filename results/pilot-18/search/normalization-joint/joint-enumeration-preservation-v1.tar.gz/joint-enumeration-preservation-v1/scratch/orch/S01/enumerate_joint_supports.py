#!/usr/bin/env python3
"""Exact finite support search, bounded to one CPU and 55 seconds per run.

No SAT/Lean invocation. A completed negative result is conditional on the
separately reviewed joint-factor-cost argument. Edgeless residuals deliberately
receive only the individual cost bound, as requested.
"""
import hashlib
import json
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
START=time.monotonic()
EDGES=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
       (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
EM=[(1<<a)|(1<<b) for a,b in EDGES]
N=[sum(1<<(b if a==v else a) for a,b in EDGES if v in (a,b)) for v in range(11)]
IND=[s for s in range(2048) if all(s&e!=e for e in EM)]
MIS=[s for s in IND if all(s==t or s&t!=s for t in IND)]
ALL=(1<<len(MIS))-1
assert len(IND)==125 and len(MIS)==24
SUPPORTS=[]
for s in range(2047):
    residual=sum(not s&e for e in EM)
    tau=11-s.bit_count()-max(t.bit_count() for t in IND if not t&s)
    cost=s.bit_count()+residual+tau-1
    z=sum(1<<i for i,t in enumerate(MIS) if not t&s)
    if cost>17 or not z:
        continue
    cn=sum(1<<v for v in range(11) if N[v]&s==s)
    assert s.bit_count()>=2 and cn.bit_count()<=1
    SUPPORTS.append(dict(s=s,z=z,cost=cost,cn=cn,residual=residual,tau=tau))
SUPPORTS.sort(key=lambda a:(-a['z'].bit_count(),a['cost'],a['s']))
COUNTS=[]
TOTAL_NODES=0
FOUND=None
CURRENT=None

class Limit(Exception):
    pass

def check_time():
    if time.monotonic()-START>55:
        raise Limit

def run_case(k,r):
    global TOTAL_NODES,CURRENT
    check_time()
    pool=[a for a in SUPPORTS if
          (not a['residual'] or a['cost']+r-(not a['cn'])<=17) and
          (r>0 or a['cn']) and (r<k or not a['cn'])]
    n=len(pool)
    byrow=[sum(1<<i for i,a in enumerate(pool) if a['z']>>b&1) for b in range(24)]
    none=sum(1<<i for i,a in enumerate(pool) if not a['cn'])
    whole=(1<<n)-1
    common=whole^none
    # Pairwise comparability, including equal zero sets, precludes minimality.
    compatible=[]
    for a in pool:
        compatible.append(sum(1<<j for j,b in enumerate(pool)
            if a['s']&b['s'] not in (a['s'],b['s']) and
               a['z']&b['z'] not in (a['z'],b['z'])))
    cache={}
    stats=dict(k=k,no_common_neighbor_count=r,pool_size=n,nodes=0,
               coverage_prunes=0,budget_prunes=0,joint_prunes=0,minimality_prunes=0)
    CURRENT=stats
    capacity=list(range(18-k,18))
    def owner_allowed(owners):
        if owners not in cache:
            cache[owners]=sum(1<<i for i,a in enumerate(pool)
                if not a['residual'] or a['cost']+r-(not a['cn'])+(a['s']&owners).bit_count()<=17)
        return cache[owners]
    def rec(chosen,available,covered,owners,used_none):
        global TOTAL_NODES
        stats['nodes']+=1
        TOTAL_NODES+=1
        if TOTAL_NODES%128==0:
            check_time()
        remaining=k-len(chosen)
        if remaining==0:
            return chosen if covered==ALL and used_none==r else None
        if covered==ALL:
            # Additional factors would make this family nonminimal.
            return None
        if used_none>r or used_none+remaining<r:
            return None
        if used_none==r:
            available&=common
        elif r-used_none==remaining:
            available&=none
        if available.bit_count()<remaining:
            return None
        if (available&none).bit_count()<r-used_none:
            return None
        if (available&common).bit_count()<remaining-(r-used_none):
            return None
        available&=owner_allowed(owners)
        if available.bit_count()<remaining:
            return None
        missing=ALL^covered
        best=None
        zunion=0
        counts=[]
        bits=available
        while bits:
            low=bits&-bits;bits-=low;i=low.bit_length()-1
            z=pool[i]['z']&missing
            zunion|=z
            counts.append(z.bit_count())
        if zunion!=missing or sum(sorted(counts,reverse=True)[:remaining])<missing.bit_count():
            stats['coverage_prunes']+=1
            return None
        bits=missing
        while bits:
            low=bits&-bits;bits-=low;b=low.bit_length()-1
            opts=available&byrow[b]
            if not opts:
                return None
            if best is None or opts.bit_count()<best.bit_count():
                best=opts
        # At each branch exclude earlier choices for the selected uncovered
        # row. Every covering family is assigned to its first such choice.
        while best:
            low=best&-best;best-=low;i=low.bit_length()-1
            available&=~low
            a=pool[i]
            newchosen=chosen+[i]
            costs=sorted([pool[j]['cost'] for j in newchosen]+[6]*(remaining-1))
            if any(x>y for x,y in zip(costs,capacity)):
                stats['budget_prunes']+=1
                continue
            newowners=owners|a['cn']
            if any(pool[j]['residual'] and pool[j]['cost']+r-(not pool[j]['cn'])+
                   (pool[j]['s']&newowners).bit_count()>17 for j in newchosen):
                stats['joint_prunes']+=1
                continue
            masks=[pool[j]['z'] for j in newchosen]
            if any(not (z & ~union_other(masks,t)) for t,z in enumerate(masks)):
                stats['minimality_prunes']+=1
                continue
            result=rec(newchosen,available&compatible[i],covered|a['z'],newowners,
                       used_none+(not a['cn']))
            if result is not None:
                return result
        return None
    result=rec([],whole,0,0,0)
    stats['status']='SURVIVOR' if result is not None else 'NO_FAMILY'
    COUNTS.append(stats)
    print(json.dumps(stats),flush=True)
    return [pool[i] for i in result] if result is not None else None

def union_other(masks,index):
    out=0
    for i,x in enumerate(masks):
        if i!=index:out|=x
    return out

status='NO_FEASIBLE_SUPPORT_FAMILY_UNDER_JOINT_BOUND'
try:
    for k in (3,4,5):
        for r in range(k+1):
            FOUND=run_case(k,r)
            if FOUND is not None:
                status='SURVIVING_SUPPORT_FAMILY'
                raise StopIteration
except StopIteration:
    pass
except Limit:
    status='UNKNOWN_TIME_LIMIT'

result=dict(status=status,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            elapsed_seconds=time.monotonic()-START,total_nodes=TOTAL_NODES,
            graph_edges=EDGES,MIS=MIS,support_candidate_count=len(SUPPORTS),
            completed_cases=COUNTS,unfinished_case=CURRENT if status=='UNKNOWN_TIME_LIMIT' else None,
            survivor=FOUND,edgeless_residual_joint_bound='BYPASSED',
            solver_run=False,Lean_proof=False,
            interpretation='Finite support relaxation only; relies on reviewed joint-factor-cost theorem. A survivor need not admit a shared prefix.')
(ROOT/'joint-support-enumeration.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('status','elapsed_seconds','total_nodes','survivor')}),flush=True)
