from pathlib import Path
import ast
import hashlib
import importlib.util
import itertools
import json
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path('/tmp/oec/pequalnp-pilot-18')
OUT = ROOT / 'math-analysis'
start = time.monotonic()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load_cnf(path):
    meta = json.loads(path.with_suffix('.json').read_text())
    assert isinstance(meta,dict)
    raw = path.read_bytes()
    assert digest(path) == meta['sha256']
    lines = raw.splitlines()
    assert lines[0] == f"p cnf {meta['variables']} {meta['clauses']}".encode()
    clauses = []
    for line in lines[1:]:
        row = tuple(map(int,line.split()))
        assert row[-1] == 0 and all(0 < abs(v) <= meta['variables'] for v in row[:-1])
        clauses.append(row[:-1])
    assert len(clauses) == meta['clauses'] and raw.endswith(b'\n')
    return meta,raw,clauses

parent_path = ROOT/'tail7-ancestorreverse/prefix-distinct.cnf'
parent,raw,clauses = load_cnf(parent_path)
assert parent['sha256'] == '811937a8a658d01fac36418e9fb3087218820a9f9dc571ef09246f936df8168e'
generator = ROOT/'search_l1342_shard17_ancestorreverse.py'
assert digest(generator) == parent['program_sha256'] == 'b10d8832060d1c554fd3daa563b7159d515a3c55adc49718989eaa9bd0c2f24f'
assert parent['size']==21 and parent['first_junk']==17
assert all(parent[k] for k in ['second_junk','live','last_output','productive_prefix','prefix_sort',
    'prefix_lex','prefix_distinct','prefix_dominance','prefix_copy_chain','prefix_strict_or',
    'prefix_constant_canonical','prefix_cover_cost','prefix_partial_edge_cost','prefix_ancestor_cost',
    'prefix_totalizer_reverse'])
assert parent['last_op'] is None
assert 'tail_template' not in parent and parent.get('enforce_junk',True)
clause_set = set(clauses)
assert (parent['junk'][17],) in clause_set
assert tuple(parent['junk'][18:]) in clause_set
assert all((-v,) in clause_set for v in parent['junk'][:17])
assert (parent['output_selectors'][-1],) in clause_set
for g in range(20):
    live = tuple(selectors[13+g] for later in range(g+1,21)
                 for selectors in (parent['lefts'][later],parent['rights'][later]))
    assert live in clause_set
unit_variables = {abs(c[0]) for c in clauses if len(c)==1}
assert not unit_variables.intersection(parent['ops'][17:])
assert not unit_variables.intersection(v for row in parent['lefts'][17:]+parent['rights'][17:] for v in row)
assert [len(row) for row in parent['lefts'][17:]] == [30,31,32,33]

base,base_raw,base_clauses = load_cnf(ROOT/'tail7-ancestorreverse/prefix-base.cnf')
lex,lex_raw,lex_clauses = load_cnf(ROOT/'tail7-ancestorreverse/prefix-lex.cnf')
assert lex_clauses[:len(base_clauses)] == base_clauses
assert clauses[:len(lex_clauses)] == lex_clauses
distinct = []
for g,(right,left) in enumerate(parent['prefix_equality_flags']):
    a,b = parent['ops'][g:g+2]
    distinct.extend([(-right,-left,a,b),(-right,-left,-a,-b)])
assert clauses[len(lex_clauses):] == distinct and len(distinct)==32

def definitions(path):
    return {x.name:ast.dump(x,include_attributes=False) for x in ast.parse(path.read_text()).body
            if isinstance(x,(ast.FunctionDef,ast.ClassDef))}

current = definitions(generator)
historical = {
 'add_prefix_dominance':'search_l1342_shard17_dominance.py',
 'add_prefix_copy_chain':'search_l1342_shard17_copychain.py',
 'add_prefix_strict_or':'search_l1342_shard17_strict.py',
 'prefix_ancestor_flags':'search_l1342_shard17_ancestorcost.py',
 'add_prefix_constant_canonical':'search_l1342_shard17_ancestorconstant.py'}
for function,filename in historical.items():
    assert current[function] == definitions(ROOT/filename)[function]

helper_path = ROOT/'add_ancestor_support.py'
spec = importlib.util.spec_from_file_location('reviewed_cn',helper_path)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
cn_review = json.loads((OUT/'ancestor-support-independent-review.json').read_text())
assert cn_review['verdict']=='PASS' and digest(helper_path)==cn_review['source_sha256']
variables,cn_extra,flags,some = helper.append_gadget(parent)
three_and = [list(pair) for pair in itertools.combinations(parent['ops'][17:],2)]
assert len(three_and)==6
for bits in itertools.product((False,True),repeat=4):
    assignment = dict(zip(parent['ops'][17:],bits))
    assert all(any(assignment[v] for v in clause) for clause in three_and) == (sum(bits)>=3)
extra = cn_extra+three_and
assert len(cn_extra)==3536 and variables-parent['variables']==204
expected = f"p cnf {variables} {parent['clauses']+len(extra)}\n".encode()+raw.split(b'\n',1)[1]
expected += ''.join(' '.join(map(str,c))+' 0\n' for c in extra).encode()

artifacts = {}
for dirname in ['original-dag-proposed','original-dag-strong']:
    path = ROOT/dirname/'original.cnf'
    meta,generated,generated_clauses = load_cnf(path)
    assert generated==expected
    assert generated_clauses[:len(clauses)]==clauses
    assert generated_clauses[len(clauses):]==[tuple(c) for c in extra]
    assert all(parent[k]==meta[k] for k in parent if k not in {'variables','clauses','sha256'})
    assert meta['ancestor_support_parent_sha256']==parent['sha256']
    assert meta['ancestor_support_postprocessor_sha256']==digest(helper_path)
    assert meta['prefix_common_neighbor_flags']==flags and meta['prefix_has_common_neighbor']==some
    assert meta['original_DAG'] and meta['suffix_at_least_three_ANDs']
    assert 'tail_template' not in meta and meta['second_junk']
    artifacts[dirname] = dict(cnf_sha256=digest(path),metadata_sha256=digest(path.with_suffix('.json')),
        variables=meta['variables'],clauses=meta['clauses'],exact_parent_plus_reviewed_delta=True)

builder_path = ROOT/'build_original_strong.py'
spec = importlib.util.spec_from_file_location('reviewed_original_builder',builder_path)
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)
assert builder.PARENT_GENERATOR==digest(generator)
assert builder.PARENT_CNF==parent['sha256']
assert builder.SUPPORT_SOURCE==digest(helper_path)
strong_meta = json.loads((ROOT/'original-dag-strong/original.json').read_text())
assert strong_meta['original_DAG_generator_sha256']==digest(builder_path)
assert strong_meta['ancestor_support_added_variables']==204
assert strong_meta['ancestor_support_added_clauses']==3536
assert strong_meta['suffix_three_AND_clauses']==three_and

report = dict(verdict='PASS',scope='Original-DAG shard completeness, three-AND consequence, pinned builder, and both fresh CNF artifacts.',
    parent=str(parent_path),parent_sha256=parent['sha256'],parent_metadata_sha256=digest(parent_path.with_suffix('.json')),
    parent_generator_sha256=digest(generator),builder_source=str(builder_path),builder_source_sha256=digest(builder_path),
    CN_helper_sha256=digest(helper_path),original_junk17_unit_preserved=True,original_second_junk_clause_preserved=True,
    all_twenty_liveness_clauses_preserved=True,output_last_unit_preserved=True,no_fixed_tail_constraints_in_parent=True,
    suffix_port_widths=[30,31,32,33],fixed_tail_transformation_occurs_after_parent_save=True,
    historical_normalization_functions_AST_identical=list(historical),
    three_AND_proof='Choose the latest junk AND and a maximal independent input on which it is true. Liveness supplies a path to the false output. If that path had only OR gates the output would be true. A later AND therefore exists and is clean by maximality of the junk index; together with the two junk ANDs it gives three distinct suffix AND gates.',
    prefix_normalization_scope='No fixed-tail assumption: productivity/dominance preserve independent-input values; strict OR/duplicate/alias removal preserve boundary values; full-support substitution preserves all nonempty inputs. Every surviving suffix operation and MIS truth value stays unchanged. Prune only prefix nodes, stabilize the core, pad a final OR-copy chain to 17, and renumber the retained four suffix gates.',
    universal_prefix_bounds_scope='Cover, partial-edge and ancestor costs constrain each clean prefix cone independently of suffix shape; full support remains exempt for free TRUE. Reverse totalizer clauses preserve existential projection.',
    all_live_prerequisite='Previously reviewed output-last/all-live normalization using the clean lower bound 22. Constants can be propagated away in a nonconstant clean counterexample without increasing gate count.',
    three_AND_clauses=three_and,operation_assignments_checked=16,CN_added_variables=204,CN_added_clauses=3536,
    total_added_clauses=3542,artifacts=artifacts,issues=[],
    conclusion='A verified UNSAT of this single original-DAG strengthened parent excludes the assigned firstjunk17/two-junk shard under the reviewed normalizations; seven-template exhaustion is unnecessary.',
    limitations=['No solver was started and no SAT/UNSAT verdict is claimed.','This audit does not itself formalize the normalizations or translate a solver certificate into the posted Lean theorem.','The builder checks parent CNF and generator provenance; this report additionally binds the reviewed parent and output metadata files by SHA256.'],
    repository_modified=False,source_modified=False,CNF_files_written=False,lease_calls=False,solver_started=False,
    seconds=time.monotonic()-start,subagents='none')
(OUT/'original-dag-independent-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['verdict','parent_sha256','builder_source_sha256','total_added_clauses','artifacts','seconds']},indent=2))
