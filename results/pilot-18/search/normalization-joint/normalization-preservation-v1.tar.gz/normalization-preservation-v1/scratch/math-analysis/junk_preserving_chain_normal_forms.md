# Two suffix normal forms preserving FIRSTJ17 and two junk gates

This is a mathematical reduction, not a completed Lean proof or a SAT result.
It applies to the reviewed all-live, output-last 21-gate normalization with
17 clean prefix gates. Free constants and repeated operands remain allowed.
No running search or generator has been changed.

When invoking clean-22 in the augmented free-constant model, first propagate
constants and delete constant or alias gates. A nonconstant exact output F
then has a circuit in the repository's constant-free model with no more gates
and with every retained AND still clean.

## Minimal clean products

Call a wire dirty if it is true on some independent input, and clean otherwise.
The 24 maximal independent inputs suffice to test this for monotone wires.
Let a product of a finite set of prefix wires be clean. Choose an
inclusion-minimal subset whose product is clean. Every proper subset then has
a dirty product. In particular, each retained factor has a private negative
row: all the other retained factors are true there and this factor is false.
Factors with equal functions on the negative rows cannot both be retained.
Neither free TRUE nor free FALSE is retained in a minimal family of size > 1.

Removing AND factors increases every positive-row value. Consequently, if the
original clean product was a subterm of an exact graph-function circuit using
only AND/OR, replacing that product by the smaller clean product preserves
the output whenever it is the complete output or an operand of the final OR:
all old true edge rows stay true, and every negative row stays false.

The argument chooses a minimal family of factors, not a globally smallest
circuit. It therefore applies to redundant gates and repeated operands.

## AAAA: a sorted five-leaf chain, all three proper products dirty

Four live AND gates have eight operand occurrences. At least three occurrences
read earlier suffix gates, so there are at most five external occurrences.
Idempotence reduces their output to a conjunction of at most five prefix
wires, including input and constant wires. Since the output is F, every one
of those factors covers all sixteen edge rows.

Choose a minimal clean subfamily Q. Its product still covers every edge row,
and is therefore F. Write q = |Q|. We have q <= 5. If q = 1, a prefix wire
already computes F. If q = 2, one additional clean AND computes F. Either
would be an entirely clean circuit of at most 18 gates, contradicting the
formal clean lower bound of 22. Thus 3 <= q <= 5.

Sort the q distinct retained wire indices. Repeat the smallest one 5-q times
at the beginning. Let the resulting five occurrences be a <= b <= c < d < e.
The possible equality patterns are exactly

    a=b=c<d<e,   a=b<c<d<e,   a<b<c<d<e.

Compute

    g17 = a AND b
    g18 = c AND g17
    g19 = d AND g18
    g20 = e AND g19.

Each of the first three products omits the largest retained factor e.
Minimality gives an independent input on which every retained factor except
e is true. The SAME input makes g17, g18, and g19 true. Their operations are
AND, so all three are junk; g20 computes F and is clean. FIRSTJ17 and the
at-least-two-junk requirement are preserved exactly.

The inputs a,...,e all cover F. In this concrete graph no raw input or constant
is a retained factor: a raw input misses an edge, FALSE misses every edge,
and TRUE is redundant. Thus they are outputs of clean prefix gates. This last
observation is specific to this all-AND case, not to the next case.

## AAAO: a clean prefix wire OR a sorted four-leaf AND chain

Gate 19 is live and has only gate 20 as a possible later reader. Since g20 is
OR and clean, g19 is clean. Gate 17 is junk and at least one of 18,19 must be
a second junk AND, so g18 is junk. Gate 18 cannot feed the final OR directly;
it must feed g19. Neither g17 nor g18 can be the final OR's other operand.
Thus g20 = P OR g19 for a clean prefix/input/constant wire P. In the compressed
prefix semantics this says that P has empty singleton support.

All three preceding suffix gates are AND, and all reach g19. Their product
therefore has at most four external prefix factors, including raw inputs and
constants. Choose a minimal clean subfamily Q for that product. Removing
factors only enlarges the clean branch, so P OR product(Q) still computes F.
If q = 1 or q = 2, the prefix, the optional single clean AND, and the final OR
would be an entirely clean circuit with at most 19 gates. Clean-22 excludes
both. Therefore q is 3 or 4.

Sort the retained indices and repeat the smallest if q=3. The four occurrences
satisfy a <= b < c < d. Compute

    g17 = a AND b
    g18 = c AND g17
    g19 = d AND g18
    g20 = P OR g19.

The private negative row for d makes g17 and g18 true, while g19 and P are
false. Thus g17 and g18 are junk, g19 is clean, and the exact original shard
conditions hold. P may be FALSE; no essentiality of the final OR is assumed.
For the existing ordered-operand convention P < wire(g19), so the final OR
port order poses no additional restriction.

## Compatibility with the reviewed prefix restrictions

Discarding factors can leave unused prefix gates. Prune them; apply the
previously reviewed productivity, dominance, strict-OR and duplicate
normalizations to the remaining prefix; prune again and pad its final OR-copy
chain back to 17 gates. Such transformations preserve every retained wire's
values on independent inputs, and preserve or increase its edge-row values.
They therefore preserve the clean/dirty product conditions and the final
exact boundary values above. Stabilization and padding add no junk AND.

Re-sort the prefix and then re-sort the retained factors. Redirecting a used
factor or P through the padding chain restores all-prefix liveness. Factor
minimality depends on negative functions, not wire numbering, and survives.
If a normalization aliases two retained factors, their negative functions
would have been equal already, contradicting minimality. Repeated padding
occurrences refer to the same final retained wire.

The prefix support/partial-edge/ancestor cost bounds and common-neighbor
consequence remain applicable because they are universal facts of any clean
prefix circuit. Their auxiliary SAT assignments can be recomputed. No claim
is made that old auxiliary variable assignments remain unchanged.

## Safe use and scope

For complete search, AAAA can be replaced by the above meet-five chain and
AAAO by the above P-OR-meet-four chain. Both retain the original junk units.
The stronger sorted equality patterns are justified by this minimal-factor
argument; arbitrary fixed-tail sorting alone did not justify them.

This does not normalize AOAA or AAOA. Their separate cases must remain in a
complete partition unless a further argument handles them. In particular it
does not prove that one-junk circuits are impossible, that every junk circuit
can be made clean, or that the shard is UNSAT. It provides two smaller complete
case encodings, with junk conditions preserved, rather than a new gate lower
bound. No claim about global circuit minimality is used.
