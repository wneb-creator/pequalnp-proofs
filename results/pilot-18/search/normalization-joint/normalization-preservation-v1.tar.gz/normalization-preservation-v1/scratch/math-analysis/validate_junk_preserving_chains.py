import hashlib
import itertools
import json
from pathlib import Path

here = Path('/tmp/oec/pequalnp-pilot-18/math-analysis')
counts = {'abstract_truth_rows': 0, 'private_negative_rows': 0,
          'concrete_full_input_rows': 0}
for length in (4, 5):
    for q in range(3, length + 1):
        for order in itertools.permutations(range(q)):
            leaves = [order[0]] * (length-q) + list(order)
            for mask in range(1 << q):
                bits = [bool(mask >> v & 1) for v in range(q)]
                outputs = []
                value = bits[leaves[0]]
                for v in leaves[1:]:
                    value = value and bits[v]
                    outputs.append(value)
                assert outputs[-1] == all(bits)
                counts['abstract_truth_rows'] += 1
            # Minimality supplies this private negative row for the last factor.
            bits = [True] * q
            bits[order[-1]] = False
            value = bits[leaves[0]]
            outputs = []
            for v in leaves[1:]:
                value = value and bits[v]
                outputs.append(value)
            assert all(outputs[:-1]) and not outputs[-1]
            counts['private_negative_rows'] += 1

graph = json.loads((here / 'graph.json').read_text())
supports = [24, 80, 1280]
mis = graph['maximal_independent_masks']
assert all(not all(s & row for s in supports) for row in mis)
for omitted in range(3):
    assert any(not (supports[omitted] & row)
               and all(s & row for i,s in enumerate(supports) if i != omitted)
               for row in mis)
for row in range(2048):
    expected = any(row >> u & 1 and row >> v & 1 for u,v in graph['edges'])
    values = [bool(expected or row & s) for s in supports]
    assert all(values) == expected
    for length in (4,5):
        padded = [values[0]] * (length-3) + values
        value = padded[0]
        for v in padded[1:]:
            value = value and v
        assert value == expected
        counts['concrete_full_input_rows'] += 1

proof = here / 'junk_preserving_chain_normal_forms.md'
script = Path(__file__)
report = {
    'verdict': 'PASS',
    'scope': 'Mathematical case-normalization argument with finite Boolean cross-checks; not a Lean proof, solver result, or construction of a 17-gate prefix.',
    'argument_sha256': hashlib.sha256(proof.read_bytes()).hexdigest(),
    'validation_program_sha256': hashlib.sha256(script.read_bytes()).hexdigest(),
    'cases': {
        'AAAA': {'normal_form': 'left-fold meet5', 'minimal_distinct_factors': [3,4,5],
                 'junk_gates': [17,18,19], 'clean_gate': 20,
                 'sorted_patterns': ['a=b=c<d<e','a=b<c<d<e','a<b<c<d<e']},
        'AAAO': {'normal_form': 'P OR left-fold meet4', 'minimal_distinct_factors': [3,4],
                 'junk_gates': [17,18], 'clean_AND_gate': 19,
                 'P_singleton_support': 0, 'sorted_patterns': ['a=b<c<d','a<b<c<d']}
    },
    'premises': ['Previously reviewed all-live/output-last normalization',
                 '17 clean prefix gates', 'The concrete clean-circuit lower bound 22',
                 'Repeated operands and free constants remain permitted'],
    'validation_counts': counts,
    'concrete_fixture_note': 'Supports 24,80,1280 give an abstract minimal product of F OR support-clause leaves. This validates suffix behavior only and does not construct those leaves with 17 prefix gates.',
    'unresolved_cases': ['AOAA','AAOA'],
    'repository_modified': False, 'generator_modified': False,
    'solver_started': False, 'lease_calls': False, 'subagents': 'none'
}
path = here / 'junk-preserving-chain-validation.json'
path.write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({'verdict': 'PASS', 'counts': counts, 'report': str(path)}))
