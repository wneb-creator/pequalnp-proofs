from pathlib import Path
import hashlib
import importlib.util
import itertools
import json
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path('/tmp/oec/pequalnp-pilot-18')
OUT = ROOT / 'math-analysis'
START = time.monotonic()
SOURCE = ROOT / 'add_ancestor_support.py'
SOURCE_HASH = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
SELF = json.loads((ROOT / 'ancestor-support-self-controls.json').read_text())
assert SELF['source_sha256'] == SOURCE_HASH
spec = importlib.util.spec_from_file_location('reviewed_ancestor_support', SOURCE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

EDGES = [(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
         (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
NEIGHBORS = [0] * 11
for a, b in EDGES:
    NEIGHBORS[a] |= 1 << b
    NEIGHBORS[b] |= 1 << a

def clause_true(clause, assignment):
    return any(assignment[abs(lit)] == (lit > 0) for lit in clause)

def equiv_or(output, inputs):
    return [[-output, *inputs], *[[-literal, output] for literal in inputs]]

def independent_delta(parent):
    supports = parent['prefix_support_tables'][13:30]
    flags = [[parent['variables'] + 12*g + v + 1 for v in range(11)] for g in range(17)]
    some = [parent['variables'] + 12*g + 12 for g in range(17)]
    helpers = []
    for g in range(17):
        for v in range(11):
            absent = [supports[g][u] for u in range(11) if not (NEIGHBORS[v] >> u) & 1]
            helpers.extend([[-flags[g][v], -bit] for bit in absent])
            helpers.append([flags[g][v], *absent])
        helpers.append([-some[g], *flags[g]])
        helpers.extend([[-flag, some[g]] for flag in flags[g]])
    implications = []
    for g in range(17):
        for h in range(g):
            ancestor = parent['prefix_ancestor_flags'][g][h]
            implications.append([-ancestor, some[h], -parent['ops'][g]])
            for v in range(11):
                implications.append([-ancestor, some[h], -supports[h][v], supports[g][v]])
    return helpers + implications, flags, some

def parent_required_clauses(meta):
    clauses = []
    supports = meta['prefix_support_tables'][13:30]
    for g in range(17):
        op = meta['ops'][g]
        left, right = [row[:11] for row in meta['prefix_operand_boundaries'][g]]
        clauses.extend([[-op, *left], [-op, *right]])
        for a, b, y in zip(left, right, supports[g]):
            clauses.extend([[-op,-y],[op,y,-a],[op,y,-b],[op,-y,a,b]])
        for u in range(11):
            for v in range(11):
                if not ((NEIGHBORS[u] >> v) & 1):
                    clauses.append([-op,-left[u],-right[v]])
    readers = meta['prefix_reader_flags']
    roots = meta['prefix_ancestor_flags']
    for g in range(17):
        for h in range(g):
            clauses.extend(equiv_or(readers[g][h], [meta['lefts'][g][13+h], meta['rights'][g][13+h]]))
    next_var = max(v for row in readers for v in row)
    for g in range(17):
        for h in reversed(range(g)):
            terms = [readers[g][h]]
            for k in range(h+1, g):
                next_var += 1
                term, a, b = next_var, roots[g][k], readers[k][h]
                clauses.extend([[-term,a],[-term,b],[term,-a,-b]])
                terms.append(term)
            next_var += 1
            assert next_var == roots[g][h]
            clauses.extend(equiv_or(next_var, terms))
    return clauses

case_reports = {}
all_parent_clauses = 0
base_parent = None
for name in module.CASES:
    p = ROOT / 'tail7-ancestorreverse-onejunk' / (name + '.cnf')
    q = ROOT / 'tail7-ancestor-support' / (name + '.cnf')
    parent = json.loads(p.with_suffix('.json').read_text())
    child = json.loads(q.with_suffix('.json').read_text())
    assert isinstance(parent, dict) and isinstance(child, dict)
    raw_parent, raw_child = p.read_bytes(), q.read_bytes()
    assert hashlib.sha256(raw_parent).hexdigest() == parent['sha256']
    assert hashlib.sha256(raw_child).hexdigest() == child['sha256'] == SELF['cases'][name]
    assert child['ancestor_support_parent_sha256'] == parent['sha256']
    assert child['ancestor_support_postprocessor_sha256'] == SOURCE_HASH
    lines_parent, lines_child = raw_parent.splitlines(), raw_child.splitlines()
    assert lines_parent[0] == f"p cnf {parent['variables']} {parent['clauses']}".encode()
    assert lines_child[0] == f"p cnf {child['variables']} {child['clauses']}".encode()
    assert len(lines_parent) == parent['clauses'] + 1
    assert len(lines_child) == child['clauses'] + 1
    assert lines_child[1:len(lines_parent)] == lines_parent[1:]
    expected, flags, some = independent_delta(parent)
    nvar, actual, actual_flags, actual_some = module.append_gadget(parent)
    assert actual == expected and actual_flags == flags and actual_some == some
    assert child['prefix_common_neighbor_flags'] == flags
    assert child['prefix_has_common_neighbor'] == some
    assert nvar == child['variables'] == parent['variables'] + 204
    assert len(expected) == child['ancestor_support_added_clauses'] == 3536
    assert child['ancestor_support_added_variables'] == 204
    assert lines_child[len(lines_parent):] == [(' '.join(map(str,c))+' 0').encode() for c in expected]
    assert all(0 < abs(lit) <= nvar for clause in expected for lit in clause)
    assert all(parent[key] == child[key] for key in parent if key not in {'variables','clauses','sha256'})
    parsed = []
    for line in lines_parent[1:]:
        row = tuple(map(int, line.split()))
        assert row[-1] == 0 and all(0 < abs(v) <= parent['variables'] for v in row[:-1])
        parsed.append(row[:-1])
    clause_set = set(parsed)
    required = parent_required_clauses(parent)
    assert all(tuple(c) in clause_set for c in required)
    all_parent_clauses += len(parsed)
    case_reports[name] = dict(sha256=child['sha256'], parent_sha256=parent['sha256'],
        variables=child['variables'],clauses=child['clauses'],old_body_preserved_exactly=True,
        delta_matches_independent_reconstruction=True,parent_semantic_clauses_verified=len(required))
    if base_parent is None:
        base_parent = parent

delta, flags, some = independent_delta(base_parent)
support = base_parent['prefix_support_tables'][13]
first_helper = delta[:112]
assert len(delta) == 17*112 + 136*12
forced_helper_bits = 0
common_masks = []
for mask in range(2048):
    common = sum(1 << v for v in range(11) if mask & ~NEIGHBORS[v] == 0)
    common_masks.append(common)
    assignment = {abs(lit): bool(mask & (1 << u)) == (lit > 0) for u, lit in enumerate(support)}
    while True:
        added = 0
        for clause in first_helper:
            if any(abs(lit) in assignment and assignment[abs(lit)] == (lit > 0) for lit in clause):
                continue
            remaining = [lit for lit in clause if abs(lit) not in assignment]
            assert remaining
            if len(remaining) == 1:
                lit = remaining[0]
                assignment[abs(lit)] = lit > 0
                added += 1
        if not added:
            break
    assert all(flag in assignment for flag in flags[0] + [some[0]])
    assert all(assignment[flags[0][v]] == bool(common & (1 << v)) for v in range(11))
    assert assignment[some[0]] == bool(common)
    assert all(clause_true(c,assignment) for c in first_helper)
    forced_helper_bits += 12

superset_checks = 0
for small in range(2048):
    complement = 2047 ^ small
    subset = complement
    while True:
        large = small | subset
        assert common_masks[large] & ~common_masks[small] == 0
        if not common_masks[small]:
            assert not common_masks[large]
        superset_checks += 1
        if subset == 0:
            break
        subset = (subset - 1) & complement

guard_checks = 0
cursor = 17*112
supports = base_parent['prefix_support_tables'][13:30]
for g in range(17):
    for h in range(g):
        ancestor = base_parent['prefix_ancestor_flags'][g][h]
        for a, neighbor, is_and in itertools.product((False,True), repeat=3):
            assignment = {ancestor:a,some[h]:neighbor,base_parent['ops'][g]:is_and}
            assert clause_true(delta[cursor],assignment) == (not a or neighbor or not is_and)
            guard_checks += 1
        cursor += 1
        for v in range(11):
            for a, neighbor, old, new in itertools.product((False,True), repeat=4):
                assignment = {ancestor:a,some[h]:neighbor,supports[h][v]:old,supports[g][v]:new}
                assert clause_true(delta[cursor],assignment) == (not a or neighbor or not old or new)
                guard_checks += 1
            cursor += 1
assert cursor == len(delta)

report = dict(verdict='PASS',source=str(SOURCE),source_sha256=SOURCE_HASH,
    scope='Independent mathematics, helper projection, parent semantic guards, and all seven generated CNF deltas.',
    mathematics='Along an ancestry path from support S with no common neighbor, each OR retains S. The first AND would have a nonempty other-operand support by productivity; cleanliness makes each of its vertices adjacent to every element of S, contradiction. Hence every prefix descendant is an OR and retains S.',
    assumptions=['All 17 prefix ANDs are clean for the stated graph','Every prefix AND operand has nonempty singleton support','Ancestry flags are exact transitive dependency flags; suffix gates are excluded'],
    needs_C4_free=False,allows_repeated_operands=True,allows_free_constants=True,needs_liveness=False,
    source_self_controls_reviewed=True,self_controls_source_hash_matches=True,
    exhaustive_support_masks=2048,forced_helper_bits=forced_helper_bits,
    support_superset_pairs=superset_checks,guard_truth_table_assignments=guard_checks,
    added_variables=204,added_clauses=3536,all_parent_clauses_parsed=all_parent_clauses,
    case_audits=case_reports,issues=[],repository_modified=False,source_modified=False,
    CNF_files_written=False,solver_started=False,lease_calls=False,
    claim='Necessary consequence only; no SAT/UNSAT, exhaustion, acceptance or runtime-improvement claim.',
    seconds=time.monotonic()-START,subagents='none')
(OUT/'ancestor-support-independent-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ('verdict','source_sha256','exhaustive_support_masks','forced_helper_bits',
    'support_superset_pairs','guard_truth_table_assignments','added_variables','added_clauses','seconds')},indent=2))
