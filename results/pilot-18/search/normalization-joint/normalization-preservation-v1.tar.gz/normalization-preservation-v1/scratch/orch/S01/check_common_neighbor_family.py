#!/usr/bin/env python3
"""Bounded scalar verification; no SAT solver or external dependencies."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EDGES = [(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
         (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
EDGE_MASKS = [(1 << u) | (1 << v) for u, v in EDGES]
independent = [x for x in range(2048) if all(x & e != e for e in EDGE_MASKS)]
mis = [x for x in independent if all(x == y or x & y != x for y in independent)]
assert len(independent) == 125 and len(mis) == 24
families = []
for v in (1, 4, 8):
    support = sorted(b if a == v else a for a, b in EDGES if v in (a, b))
    smask = sum(1 << x for x in support)
    residual = [(a, b) for a, b in EDGES if not smask & ((1 << a) | (1 << b))]
    covers = [c for c in range(2048) if all(c & ((1 << a) | (1 << b)) for a, b in residual)]
    tau = min(c.bit_count() for c in covers)
    common = [w for w in range(11) if all((min(w, u), max(w, u)) in EDGES for u in support)]
    families.append(dict(owner=v, support=support, support_mask=smask,
                         residual_edges=residual, residual_cover=tau,
                         lower_bound=len(support)+len(residual)+tau-1,
                         common_neighbors=common,
                         zero_MIS=[i for i, m in enumerate(mis) if not m & smask]))

assert [r['lower_bound'] for r in families] == [16, 13, 12]
assert [r['common_neighbors'] for r in families] == [[1], [4], [8]]
assert set().union(*(set(r['zero_MIS']) for r in families)) == set(range(24))
checks = 0
for mask in range(2048):
    x = [bool(mask & (1 << v)) for v in range(11)]
    target = any(x[a] and x[b] for a, b in EDGES)
    A = (x[3] and x[6]) or (x[3] and x[7]) or (x[6] and x[7])
    B = x[10] and (x[0] or x[2] or x[6])
    C = x[9] and (x[0] or x[5] or x[7])
    D = x[2] and x[5]
    h = [A or B or C or D or x[4] or x[8],
         A or C or D or x[1] or x[8] or x[10],
         A or B or x[1] or x[4] or x[5] or x[9]]
    assert h == [target or bool(mask & r['support_mask']) for r in families]
    assert all(h) == target
    checks += 4
for i, row in enumerate(families):
    mask = 1 << row['owner']
    assert [bool(mask & r['support_mask']) for r in families] == [j != i for j in range(3)]

result = dict(verdict='PASS_SCALAR_IDENTITIES_AND_COSTS', source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              truth_checks=checks, MIS=mis, families=families, independent_inputs=len(independent),
              refined_cap=17, no_common_neighbor_count=0, minimal_family=True,
              shared_17_gate_construction=False, solver_run=False)
(ROOT / 'common-neighbor-family-validation.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k: result[k] for k in ('verdict','source_sha256','truth_checks','shared_17_gate_construction')}))
