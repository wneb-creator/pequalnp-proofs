import hashlib,itertools,json,subprocess,sys
from pathlib import Path

here=Path('/tmp/oec/pequalnp-pilot-18/orch/S01')
out=here/'aaoa-four-v1';parent=here/'consecutive-junk-v2/AAOA.cnf'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
meta=read(parent.with_suffix('.json'));fam=read(out/'family.json')
body=parent.read_bytes().split(b'\n',1)[1]
assert sha(parent)=='70308894ffc6f4c3b682140c7df3d17ed3035c79dc66f56dc51bd47020004e91'
assert fam['program_sha256']==sha(here/'build_aaoa_shapes.py')
assert fam['four_cases_alone_claimed_complete_for_AAOA'] is False
tables=[meta['lefts'],meta['rights']]
port_specs={
 'T1':[(None,None),(None,30),(None,31),(None,32)],
 'T2':[(None,None),(None,None),(30,31),(None,32)],
 'T3':[(None,None),(None,None),(None,31),(30,32)],
 'T4':[(None,None),(None,30),(None,None),(31,32)]}
order_specs={
 'T1':[(17,0,17,1),(17,1,18,0)],
 'T2':[(17,0,17,1),(18,0,18,1),(17,0,18,0)],
 'T3':[(17,0,17,1),(18,0,18,1)],
 'T4':[(17,0,17,1),(17,1,18,0),(19,0,19,1)]}
expected_counts={'T1':879,'T2':1313,'T3':877,'T4':1313}
records=[];projection_tests=0
for name,spec in port_specs.items():
 delta=[]
 for g,sides in zip(range(17,21),spec):
  for side,source in enumerate(sides):
   if source is None:
    delta += [[-tables[side][g][v]] for v in range(30,13+g)]
   else:delta += [[tables[side][g][source]]]
 for g,s,h,t in order_specs[name]:
  first,second=tables[s][g][:30],tables[t][h][:30]
  pairs={(i,j) for i,j in itertools.product(range(30),repeat=2) if i>j}
  block=[[-first[i],-second[j]] for i,j in sorted(pairs)]
  delta.extend(block)
  actual={(first.index(-a),second.index(-b)) for a,b in block}
  for i,j in itertools.product(range(30),repeat=2):
   assert ((i,j) not in actual)==(i<=j);projection_tests+=1
 assert len(delta)==expected_counts[name]
 p=out/(name+'.cnf');m=out/(name+'.json');record=read(m)
 expected=f'p cnf 11968 {114571+len(delta)}\n'.encode()+body+''.join(' '.join(map(str,c))+' 0\n' for c in delta).encode()
 assert p.read_bytes()==expected
 assert record['aaoa_added_clauses']==delta
 assert record['sha256']==sha(p)==fam['files'][name]['cnf_sha256']
 assert sha(m)==fam['files'][name]['metadata_sha256']
 assert record['aaoa_generator_sha256']==sha(here/'build_aaoa_shapes.py')
 assert record['aaoa_coverage_requires_AAAA_fallback'] is True
 for key,value in meta.items():
  if key not in ('sha256','clauses','research_status'):assert record[key]==value,key
 records.append({'case':name,'added_clauses':len(delta),'cnf_sha256':sha(p),'metadata_sha256':sha(m),'exact_parent_body_preserved':True})

# Five independent terminals suffice to check each formula identity under every
# substitution, including constant or repeated external signals.
gates={
 'T1':[(2,3),(4,30),(1,31),(0,32)],
 'T2':[(1,2),(3,4),(30,31),(0,32)],
 'T3':[(0,1),(3,4),(2,31),(30,32)],
 'T4':[(0,1),(2,30),(3,4),(31,32)]}
truth_checks=0
for bits in itertools.product([False,True],repeat=5):
 a,b,c,d,e=bits
 wanted={'T1':a and (b or c and d and e),'T2':a and (b and c or d and e),
         'T3':a and b and (c or d and e),'T4':a and b and c and (d or e)}
 for name,gs in gates.items():
  vals=list(bits)+[False]*25
  for i,(u,v) in enumerate(gs):vals.append(vals[u] or vals[v] if i==2 else vals[u] and vals[v])
  assert vals[33]==wanted[name];truth_checks+=1

controls=[]
for name,src,dst in [('bad-parent',here/'consecutive-junk-v2/normalized.cnf',here/'aaoa-must-not-exist'),
                     ('existing-output',parent,out)]:
 before={p.name:sha(p) for p in out.iterdir()}
 with (here/('aaoa-'+name+'.stdout.txt')).open('w') as stdout,(here/('aaoa-'+name+'.stderr.txt')).open('w') as stderr:
  result=subprocess.run([sys.executable,str(here/'build_aaoa_shapes.py'),str(src),str(dst)],stdout=stdout,stderr=stderr)
 assert result.returncode!=0
 assert before=={p.name:sha(p) for p in out.iterdir()}
 controls.append({'name':name,'exit_code':result.returncode,'no_output_changes':True})
assert not (here/'aaoa-must-not-exist').exists()
report={'verdict':'PASS_ENCODING_CONTROLS_PENDING_INDEPENDENT_REVIEW',
 'source_sha256':sha(here/'build_aaoa_shapes.py'),'audit_sha256':sha(Path(__file__)),
 'parent_sha256':sha(parent),'family_sha256':sha(out/'family.json'),'cases':records,
 'selector_order_projections':projection_tests,'formula_truth_rows':truth_checks,'negative_controls':controls,
 'scope':'Candidate-only until independently reviewed. Full normal-form coverage uses these four forms together with the AAAA fallback; the four files alone do not exhaust the original AAOA case.',
 'no_original_clause_removed':True,'no_new_variables':True,'junk17_and_junk18_retained':True,
 'solver_started':False,'repository_Lean_modified':False,
 'files':[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in
          [here/'build_aaoa_shapes.py',Path(__file__)]+sorted(out.iterdir())]}
(here/'aaoa-encoding-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'verdict':report['verdict'],'source_sha256':report['source_sha256'],
 'family_sha256':report['family_sha256'],'clauses':{r['case']:114571+r['added_clauses'] for r in records},
 'projection_tests':projection_tests,'formula_truth_rows':truth_checks}))
