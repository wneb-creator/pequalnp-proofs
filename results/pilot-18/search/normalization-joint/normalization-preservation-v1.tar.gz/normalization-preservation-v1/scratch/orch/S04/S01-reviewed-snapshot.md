# S01: consecutive first junk gates

Updated 2026-11-24 03:29 UTC. Mathematical result; not yet a Lean theorem or an
independently reviewed SAT restriction. No solver or generator has been changed.

## Main result

Under the already reviewed all-live/output-last normalization for this shard,
**gate 18 can also be required to be a junk AND**. Thus the original `AOAA`
operation case can be eliminated by normalization to `AAOA` or `AAAA`.
The remaining operation strings are `AAAA`, `AAOA`, and `AAAO`, with both
gates 17 and 18 junk. This is an existence-preserving normalization, not a
logical implication satisfied by every unmodified circuit.

The only graph-specific ingredient in the proof below is the existing formal
clean-circuit lower bound 22. No global one-junk lower bound is assumed. Repeated
operands, aliases, free constants and semantically redundant gates are allowed.
Free constants are propagated away when applying the clean-circuit lower bound.

## Definitions and premises

F is the target graph function. A signal is clean if it is false on every
independent input, and dirty otherwise. A junk gate is a dirty AND. All 17
prefix gates have clean ANDs. There are four live suffix gates 17..20, output20
computes F, gate17 is junk, and there is another junk AND. The established
three-AND argument leaves exactly AAAA, AAOA, AOAA and AAAO.

Any prefix signals R,T whose product is clean and covers every target edge
would give F with one additional clean AND, using at most18 clean gates.
Consequently such a pair cannot occur. This observation applies to functions
computed by prefix wires, not just raw input variables.

## The three easy operation cases

- AAOA: gate19 is OR and gate20 is clean, so the second junk must be gate18.
- AAAO: gate19 feeds the clean final OR, so gate19 is clean. Again gate18 is
  the second junk AND.
- AAAA: if gate18 is already junk, nothing is needed. Otherwise gate19 is
  junk, and it cannot read the clean AND gate18: an AND with a clean operand
  is clean. Swap gates18 and19 and update references. Both were available in
  this order; gate17 stays unchanged and the new gate18 is junk.

The last argument uses only cleanliness and a topological swap, not a
minimal-factor or minimal-circuit assumption.

## Direct normalization of AOAA

Write D = g17, O = g18, J = g19. Both D and J are dirty ANDs; O is OR.
Gate19 is live and therefore is an operand of the final gate.

If J does not read O, swap gates18 and19. This gives AAOA with both first
ANDs junk and the function unchanged. Otherwise, using commutativity, write

    D = A AND B,   J = O AND T,   F = J AND R.

Here A,B are prefix wires; T is a prefix wire, D, or O. R cannot be J or O,
because J <= O and either choice would make the dirty J the output. Hence R
is a prefix wire or D. These exhaust the possible references.

### Case T = O (J is an AND-copy of O)

If R = D, O cannot read D: absorption would make F = D dirty. Thus O reads
only prefix wires. Replace the suffix by D, AND-copy(D), O, D AND O. This
is AAOA; its first two ANDs are dirty and every suffix gate is live after the
copy is used by the final AND.

If R is a prefix wire, liveness of D forces O = D OR Q for a prefix wire Q
or Q=D. Replace the suffix by D, AND-copy(D), copy(D) OR Q, R AND that OR.
Again this is AAOA, both first ANDs are dirty, and the function is unchanged.

### Case T = D

R=D would give output J and is impossible, so R is a prefix wire.
If O reads D, absorption gives F = R AND D. Use D, AND-copy(D), AND-copy(D),
R AND D, with the copies chained and the final gate reading the last copy.
This is AAAA with three dirty intermediate ANDs.

Otherwise O reads only prefix wires. Set H = R AND D. If H is dirty, order
the suffix as D, H, O, H AND O. This is AAOA with two junk ANDs. If H is
clean, then H = F: it contains F and is false on all negative inputs. Use
the preceding three-dirty-copies AAAA construction for H = R AND D.

### Case T is a prefix wire and R = D

If O reads D, absorption gives F = T AND D. Use the AAAA construction just
described. Otherwise set H = T AND D; if dirty use D,H,O,H AND O, and if
clean use the same AAAA construction for H=F.

### Case T and R are both prefix wires

Liveness forces D to feed O, so O = D OR Q, where Q is a prefix wire or D.
Set H = R AND T. Since F = H AND O, H covers all target edges. H cannot be
clean by the clean-prefix-plus-one-AND contradiction above. Hence H is dirty.
Use D,H,D OR Q,H AND (D OR Q), with the last two gates referencing their
predecessor outputs. This is AAOA and preserves the entire Boolean function.

These cases allow repeated operands throughout. Each replacement has exactly
four live suffix gates, keeps gate17 dirty, and makes gate18 dirty.

## Prefix normalization and safe SAT consequence

Some absorption replacements discard prefix dependencies. Prune unused prefix
gates and restore 17 with the reviewed final OR-copy chain, then reapply the
reviewed ordering and prefix normal forms. These changes preserve retained
signals on all independent inputs and preserve or increase their edge values.
The suffix remains exact on the 40 boundary rows, both first junk gates stay
dirty, and all prefix ANDs stay clean. Universal support/ancestor-cost and
common-neighbor consequences can be reassigned on the resulting prefix.

Therefore a fresh complete search may add the unit `J18` to the reviewed
original-DAG parent, provided this normalization receives independent review.
It must not be described as a clause implied by the existing parent. Adding
it to a future search is a symmetry/normal-form restriction with the proof
above. Existing searches and their certificate claims remain unchanged.

## Additional stronger forms already derived

For AAAA, take a minimal clean subfamily of its at most five external prefix
factors. Its size is 3..5: one or two would give a clean circuit with at most18
gates. Sort the factors and pad with copies of the smallest. A left-fold chain
has g17,g18,g19 all dirty and g20 clean. The leaf equality patterns are exactly
`a=b=c<d<e`, `a=b<c<d<e`, or `a<b<c<d<e`.

For AAAO, the final OR is P OR g19 with clean prefix wire P, and the three
preceding ANDs form a clean product of at most four external factors. A minimal
clean factor family has size3 or4; a smaller one would give an all-clean circuit
with at most19 gates. Sort and pad its smallest factor, obtaining `a<=b<c<d`.
The chain has junk17,junk18,clean19, and output P OR g19. Minimality supplies
one independent input witnessing all proper chain products dirty.

Detailed arguments and finite checks are preserved at
`/tmp/oec/pequalnp-pilot-18/math-analysis/junk_preserving_chain_normal_forms.md`
and `junk-preserving-chain-validation.json` (4,704 abstract truth rows,
180 private-negative-row checks, 4,096 concrete fixture input checks).
These checks do not construct a17-gate prefix or prove shard exhaustion.

## Boundaries of the result

No one-junk impossibility, global22 lower bound for arbitrary monotone circuits,
or full posted theorem is claimed. The useful new consequence is the existence
of a representative with consecutive first junk gates. No code, CNF, lease,
solver, git or named Lean file was modified for this argument.

Sub-agents: none
