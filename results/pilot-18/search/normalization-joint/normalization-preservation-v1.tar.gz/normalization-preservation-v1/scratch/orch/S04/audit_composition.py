"""Bounded independent normalization composition controls; no SAT solver."""
from pathlib import Path
import collections
import contextlib
import hashlib
import importlib.util
import inspect
import itertools
import json
import random
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path('/workspace/pequalnp-proofs')
SCRATCH = Path('/tmp/oec/pequalnp-pilot-18')
OUT = SCRATCH / 'orch/S04'
EDGES = [(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
         (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
ALL = (1 << 2048) - 1
EDGE_ROWS = [(1 << u) | (1 << v) for u,v in EDGES]
NEG_ROWS = [m for m in range(2048) if not any(m & (1<<u) and m & (1<<v) for u,v in EDGES)]
NEG = sum(1 << m for m in NEG_ROWS)
NONEMPTY_NEG = NEG ^ 1
EMASK = sum(1 << m for m in EDGE_ROWS)
SROWS = [1 << v for v in range(11)]
BOUNDARY = EMASK | sum(1 << m for m in SROWS)
SOURCES = [sum(1 << m for m in range(2048) if m & (1 << v)) for v in range(11)] + [0,ALL]
NEIGHBORS = [sum(1 << w for w in range(11) if (v,w) in EDGES or (w,v) in EDGES) for v in range(11)]
COUNTS = collections.Counter()
MINCOVER = {}
COVERS = sorted(range(2048),key=lambda x:(x.bit_count(),x))
COVERED = {s:sum(1 << e for e,(u,v) in enumerate(EDGES) if s & ((1<<u)|(1<<v))) for s in COVERS}

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def values(gates):
    vals=SOURCES[:]
    for op,a,b in gates:
        vals.append(vals[a] & vals[b] if op else vals[a] | vals[b])
    return vals

def support(val):
    return sum(1 << v for v in range(11) if (val >> (1 << v)) & 1)

def remove(prefix,suffix,g,source):
    wire=13+g
    assert source < wire
    def remap(x):
        return source if x==wire else x-1 if x>wire else x
    old=prefix+suffix
    changed=[(op,remap(a),remap(b)) for i,(op,a,b) in enumerate(old) if i!=g]
    COUNTS['core_deletions']+=1
    return changed[:len(prefix)-1],changed[len(prefix)-1:]

def prune(prefix,suffix):
    needed=set(a for _,a,b in suffix if a<13+len(prefix)) | set(b for _,a,b in suffix if b<13+len(prefix))
    for g in reversed(range(len(prefix))):
        if 13+g in needed:
            _,a,b=prefix[g];needed.update([a,b])
    for g in reversed(range(len(prefix))):
        if 13+g not in needed:
            prefix,suffix=remove(prefix,suffix,g,11)
            COUNTS['pruned']+=1
    return prefix,suffix

def sort_prefix(prefix,suffix):
    mapping={i:i for i in range(13)}
    todo=dict(enumerate(prefix));new=[]
    while todo:
        candidates=[]
        for g,(op,a,b) in todo.items():
            if a in mapping and b in mapping:
                a,b=sorted((mapping[a],mapping[b]))
                candidates.append(((b,a,0 if op else 1),g,(op,a,b)))
        _,g,gate=min(candidates)
        mapping[13+g]=13+len(new);new.append(gate);del todo[g]
    mapping.update({13+len(prefix)+i:13+len(prefix)+i for i in range(len(suffix))})
    return new,[(op,*sorted((mapping[a],mapping[b]))) for op,a,b in suffix]

def normalize(prefix,suffix):
    original=values(prefix+suffix)
    old_suffix=original[-4:]
    for iteration in range(19):
        prefix,suffix=prune(prefix,suffix)
        prefix,suffix=sort_prefix(prefix,suffix)
        vals=values(prefix);supports=list(map(support,vals))
        deletion=None;seen={}
        for g,(op,a,b) in enumerate(prefix):
            out=13+g
            if supports[out]==2047:
                deletion=(g,12,'full_support');break
            if (op,a,b) in seen:
                deletion=(g,seen[(op,a,b)],'duplicate');break
            seen[(op,a,b)]=out
            if not op:
                if not ((vals[a]&~vals[b]) & BOUNDARY):
                    deletion=(g,b,'absorbed_or');break
                if not ((vals[b]&~vals[a]) & BOUNDARY):
                    deletion=(g,a,'absorbed_or');break
            elif supports[a]==0 or supports[b]==0:
                deletion=(g,a if supports[a]==0 else b,'unproductive');break
            else:
                for earlier in range(13,out):
                    if supports[earlier]==0 and not (vals[out]&~vals[earlier]&EMASK):
                        deletion=(g,earlier,'dominance');break
                if deletion:break
        if deletion is None:break
        g,src,reason=deletion
        before=values(prefix+suffix)[-4:]
        prefix,suffix=remove(prefix,suffix,g,src)
        after=values(prefix+suffix)[-4:]
        for a,b in zip(before,after):
            assert not ((a^b)&NONEMPTY_NEG),('negative_changed',reason)
            assert not (a&~b&EMASK),('edge_decreased',reason)
        COUNTS[reason]+=1
    else:raise AssertionError('normalization did not decrease')
    k=len(prefix)
    COUNTS['stable_core_'+str(k)]+=1
    if k<17:
        if k:
            source=13+k-1
        else:
            source=next(x for _,a,b in suffix for x in (a,b) if x<13)
        padding=17-k
        for i in range(padding):
            prev=source if i==0 else 13+k+i-1
            prefix.append((False,prev,prev))
        redirected=False;new_suffix=[]
        for op,a,b in suffix:
            ports=[]
            for x in (a,b):
                if x>=13+k:x+=padding
                elif x==source and not redirected:x=29;redirected=True
                ports.append(x)
            new_suffix.append((op,*sorted(ports)))
        assert redirected
        suffix=new_suffix
    vals=values(prefix+suffix)
    for a,b in zip(old_suffix,vals[-4:]):
        assert not ((a^b)&NONEMPTY_NEG)
        assert not (a&~b&EMASK)
    check_form(prefix,suffix,vals)
    return prefix,suffix,vals

def cover(residual):
    if residual not in MINCOVER:
        MINCOVER[residual]=next(c for c in COVERS if not residual&~COVERED[c])
    return MINCOVER[residual]

def check_form(prefix,suffix,vals):
    assert len(prefix)==17 and len(suffix)==4
    supports=list(map(support,vals[:30]));keys=[];descriptions=set();anc=[]
    copy_started=False
    for g,(op,a,b) in enumerate(prefix):
        assert a<=b<13+g
        keys.append((b,a,0 if op else 1))
        assert (op,a,b) not in descriptions
        descriptions.add((op,a,b))
        if not op and a==b:
            assert g==0 or a==12+g
            copy_started=True
        else:assert not copy_started
        if supports[13+g]==2047:assert a==b
        if op:
            assert not (vals[13+g]&NEG)
            assert supports[a] and supports[b]
            for h in range(g):
                if supports[13+h]==0:assert vals[13+g]&~vals[13+h]&EMASK
        elif a!=b:
            assert vals[a]&~vals[b]&BOUNDARY and vals[b]&~vals[a]&BOUNDARY
        cone=set()
        for x in (a,b):
            if x>=13:cone.update(anc[x-13]);cone.add(x-13)
        anc.append(cone)
        for h in cone:
            sh=supports[13+h]
            if not any(sh&~n==0 for n in NEIGHBORS):
                assert not op and sh&~supports[13+g]==0
        s=supports[13+g]
        residual=sum(1<<e for e,(u,v) in enumerate(EDGES)
                     if not s&((1<<u)|(1<<v)) and (vals[13+g]>>EDGE_ROWS[e])&1)
        if s!=2047:
            assert s.bit_count()+residual.bit_count()+cover(residual).bit_count()<=2+len(cone)
        COUNTS['ancestor_bound_instances']+=1
    assert keys==sorted(keys)
    for g in range(20):
        assert any(13+g in (a,b) for _,a,b in (prefix+suffix)[g+1:])

def sample(rng,index):
    prefix=[];vals=SOURCES[:]
    if index%10==0:
        for v in range(1,11):
            a=0 if v==1 else 13+len(prefix)-1
            prefix.append((False,a,v));vals.append(vals[a]|vals[v])
    elif index%10==1:
        # Existing early edge plus a repeated, absorbed AND later.
        prefix=[(False,9,10),(True,0,13),(False,0,14),(True,9,15)]
        vals=values(prefix)
    elif index%10==2:
        # A clean AND with an empty-support operand.
        prefix=[(True,0,9),(True,14-1,10)]
        vals=values(prefix)
    while len(prefix)<17:
        a,b=rng.randrange(len(vals)),rng.randrange(len(vals))
        op=bool(rng.randrange(2)) and not (vals[a]&vals[b]&NEG)
        prefix.append((op,a,b));vals.append(vals[a]&vals[b] if op else vals[a]|vals[b])
    dirty=[w for w,v in enumerate(vals) if v&NONEMPTY_NEG]
    a,b=rng.choice(dirty),rng.choice(dirty)
    if not (vals[a]&vals[b]&NONEMPTY_NEG):b=a
    suffix=[(True,a,b),(True,30,30),(bool(rng.randrange(2)),31,29),(True,32,rng.randrange(30))]
    return prefix,suffix

def targeted_samples():
    prefix=[(True,0,9),(True,2,10),(False,0,14),(True,9,15)]
    while len(prefix)<17:
        source=12+len(prefix);prefix.append((False,source,source))
    yield prefix,[(True,0,0),(True,30,30),(False,31,13),(True,32,29)]
    for edge_count,add_singleton in [(9,False),(8,True),(8,False)]:
        prefix=[(True,u,v) for u,v in EDGES[:edge_count]]
        root=13
        for i in range(1,edge_count):
            prefix.append((False,root,13+i));root=12+len(prefix)
        if add_singleton:
            prefix.append((False,root,8));root=12+len(prefix)
        while len(prefix)<17:
            prefix.append((False,root,root));root=12+len(prefix)
        yield prefix,[(True,0,0),(True,30,30),(False,31,29),(True,32,12)]

def recreate():
    path=ROOT/'results/pilot-18/search/search_l1342_shard17_ancestorreverse.py'
    mod=load('audited_generator',path)
    omitted=[];old_add=mod.CNF.add
    def tagged_add(self,*literals):
        frame=inspect.currentframe().f_back
        # Output-target clauses only: retain selectors and all normalization clauses.
        if frame.f_code.co_name=='build' and frame.f_lineno in (200,205,208):
            omitted.append(len(self.clauses))
        old_add(self,*literals)
    mod.CNF.add=tagged_add
    cnf,data=mod.build(prefix_sort=True,live=True,productive_prefix=True)
    assert len(omitted)==970,len(omitted)
    # Synthetic suffixes need not be target circuits, so shard restrictions are omitted too.
    for i,clause in enumerate(cnf.clauses):
        if clause==[data['junk'][17]] or clause==data['junk'][18:]:omitted.append(i)
    for name in ['add_prefix_dominance','add_prefix_copy_chain','add_prefix_cover_cost',
                 'add_prefix_strict_or','add_prefix_partial_edge_cost','add_prefix_constant_canonical']:
        getattr(mod,name)(cnf,data)
    data['prefix_totalizer_reverse']=True
    rebuilt_dir=OUT/('recreated-'+str(time.time_ns()))
    with (OUT/'recreation.log').open('w') as log,contextlib.redirect_stdout(log):
        mod.write(cnf,data,OUT/'prefix-base.cnf')
        mod.add_prefix_lex(OUT/'prefix-base.cnf',OUT/'prefix-lex.cnf')
        mod.add_distinct_prefix(OUT/'prefix-lex.cnf',OUT/'prefix-distinct.cnf')
        builder=load('audited_builder',ROOT/'results/pilot-18/search/build_original_strong.py')
        builder.transform(OUT/'prefix-distinct.cnf',rebuilt_dir)
    actual=SCRATCH/'original-dag-strong/original.cnf'
    rebuilt=rebuilt_dir/'original.cnf'
    assert actual.read_bytes()==rebuilt.read_bytes()
    meta=json.loads(actual.with_suffix('.json').read_text())
    rebuilt_meta=json.loads(rebuilt.with_suffix('.json').read_text())
    assert rebuilt_meta==meta
    clauses=[list(map(int,line.split()))[:-1] for line in actual.read_text().splitlines()[1:]]
    omitted+=list(range(len(clauses)-6,len(clauses)))
    omitted=set(omitted)
    return meta,[c for i,c in enumerate(clauses) if i not in omitted],{
        'cnf_sha256':sha(actual),'metadata_sha256':sha(actual.with_suffix('.json')),
        'generator_sha256':sha(path),'builder_sha256':sha(ROOT/'results/pilot-18/search/build_original_strong.py'),
        'CNF_byte_reproduction':True,'metadata_exact_reproduction':True,
        'control_omitted_clause_count':len(omitted),'control_omission_scope':'target output clauses, first/second junk requirements, three suffix AND bound'}

def extension_check(meta,clauses,gates,vals):
    assignment={}
    def fix(lit,b):
        var=abs(lit);value=bool(b) if lit>0 else not bool(b)
        assert var not in assignment or assignment[var]==value
        assignment[var]=value
    for g,(op,a,b) in enumerate(gates):
        fix(meta['ops'][g],op)
        for row,choice in [(meta['lefts'][g],a),(meta['rights'][g],b)]:
            for i,v in enumerate(row):fix(v,i==choice)
    for i,v in enumerate(meta['output_selectors']):fix(v,i==33)
    for g,(equal_right,equal_left) in enumerate(meta['prefix_equality_flags']):
        fix(equal_right,gates[g][2]==gates[g+1][2])
        fix(equal_left,gates[g][1]==gates[g+1][1])
    for row,val in zip(meta['prefix_support_tables'],vals):
        s=support(val)
        for v,literal in enumerate(row):fix(literal,s&(1<<v))
    for row,val in zip(meta['prefix_edge_tables'],vals):
        for literal,mask in zip(row,EDGE_ROWS):fix(literal,(val>>mask)&1)
    for g,description in enumerate(meta['partial_edge_cost_restrictions']):
        s=support(vals[13+g])
        residual=sum(1<<e for e,(u,v) in enumerate(EDGES)
                     if not s&((1<<u)|(1<<v)) and (vals[13+g]>>EDGE_ROWS[e])&1)
        c=cover(residual)
        for v,literal in enumerate(description['vertex_cover_flags']):fix(literal,c&(1<<v))
    # Scalar unit propagation followed by the maximal extension of unconstrained
    # directional witnesses. Verify every retained clause, not just the units.
    pending=clauses
    rounds=0
    while True:
        next_pending=[];changed=False
        for clause in pending:
            rest=[];satisfied=False
            for lit in clause:
                value=assignment.get(abs(lit))
                if value is None:rest.append(lit)
                elif value==(lit>0):satisfied=True;break
            if satisfied:continue
            assert rest,('unit conflict',clause)
            if len(rest)==1:fix(rest[0],True);changed=True
            else:next_pending.append(rest)
        pending=next_pending;rounds+=1
        if not changed:break
    for var in range(1,meta['variables']+1):assignment.setdefault(var,True)
    failed=[i for i,c in enumerate(clauses) if not any(assignment[abs(v)]==(v>0) for v in c)]
    if failed:
        (OUT/('extension-failure-'+str(time.time_ns())+'.json')).write_text(json.dumps({
            'gates':gates,'failed_clauses':[(i,clauses[i]) for i in failed],
            'assignment':assignment},indent=2)+'\n')
    assert not failed,('extension clauses fail',failed[:20])
    COUNTS['CNF_extension_models']+=1
    COUNTS['CNF_clauses_checked']+=len(clauses)
    COUNTS['unit_rounds']+=rounds

def main():
    start=time.monotonic()
    meta,clauses,artifact=recreate()
    rng=random.Random(134204)
    for i in range(600):
        prefix,suffix=sample(rng,i)
        original=values(prefix+suffix)
        result=normalize(prefix,suffix)
        new_prefix,new_suffix,vals=result
        for g in range(17,21):
            assert bool(original[13+g]&NONEMPTY_NEG)==bool(vals[13+g]&NONEMPTY_NEG)
        if i<30:extension_check(meta,clauses,new_prefix+new_suffix,vals)
        COUNTS['circuits']+=1
    for prefix,suffix in targeted_samples():
        prefix,suffix,vals=normalize(prefix,suffix)
        extension_check(meta,clauses,prefix+suffix,vals)
        COUNTS['circuits']+=1
        COUNTS['targeted_circuits']+=1
    assert COUNTS['dominance'] and COUNTS['stable_core_17']
    report={'verdict':'PASS','scope':'Composition controls and exact artifact binding; no global or shard UNSAT claim',
            'artifact':artifact,'counts':dict(COUNTS),'truth_rows_per_circuit':2048,
            'seed':134204,'script_sha256':sha(Path(__file__)),'elapsed_seconds':time.monotonic()-start}
    (OUT/'composition-result.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
