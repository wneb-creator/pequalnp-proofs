from pathlib import Path
import hashlib,json,datetime,shutil
R=Path('/workspace/pequalnp-proofs');S=Path('/tmp/oec/pequalnp-pilot-18');O=S/'orch/S04';P=O/'normalization-preservation-v1'
assert not P.exists();P.mkdir()
items={}
def add(path,category):
 p=Path(path);assert p.is_file() and not p.is_symlink(),str(p)
 assert p.suffix!='.cnf',str(p)
 rel=Path('repo')/p.relative_to(R) if p.is_relative_to(R) else Path('scratch')/p.relative_to(S)
 raw=p.read_bytes();d=P/rel;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(raw)
 items[str(rel)]=dict(source_path=str(p),archive_path=str(rel),category=category,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def names(base,names,cat):
 for name in names.split():add(base/name,cat)
# Exact generator closure; standard library only.
names(R/'results/pilot-18/search','search_l1342_shard17_ancestorreverse.py build_original_strong.py add_ancestor_support.py','reproduction_source')
names(S/'orch/S01','build_consecutive_junk.py build_aaoa_shapes.py audit_consecutive_junk_encoding.py audit_aaoa_shapes.py','normalization_source_and_self_audit')
names(R/'results/orch/lemmas','S01-late-junk.md S04-redteam.md','current_mathematical_reviews_snapshot')
add(R/'results/orch/NOTES.md','shared_notes_snapshot')
names(O,'S04-six-case-reviewed.md S01-reviewed-snapshot.md six-case-review-manifest.json','historical_review_snapshots')
# S04 independent controls and all diagnostics, including unsuccessful early runs.
names(O,'audit_composition.py composition-result.json initial-metadata-summary.json semantic-caveats.json review_consecutive_junk.py consecutive-junk-result.json review_j18_delta.py j18-delta-review.json review_chain_variants.py chain-review.json review_aaOA_forms.py aaOA-review.json review_aaoa_deltas.py aaoa-delta-review.json review_joint_factor.py joint-factor-review.json','independent_source_and_results')
for pattern in ['composition*.log','consecutive-junk*.log','j18-delta*.log','chain-review*.log','aaOA-review*.log','aaoa-delta*.log','joint-factor-review*.log']:
 for p in sorted(O.glob(pattern)):add(p,'full_independent_diagnostics')
add(O/'recreation.log','full_independent_diagnostics')
# Dependencies of the mathematical review and parent encoding.
M=S/'math-analysis'
names(M,'sat_mono_prefix17_assumptions.md prefix-dominance-review.md prefix-dominance-review.json prefix-copychain-review.md prefix-copychain-review.json strict-or-review.md strict-or-review.json support-cost-math-review.md support-cost-math-review.json partial-edge-cost-review.md partial-edge-cost-review.json ancestor-cost-math-review.md ancestor-cost-math-review.json original-dag-independent-review.json review_original_strong.py original-dag-review.stdout.txt original-dag-review.stderr.txt ancestor-support-independent-review.json review_ancestor_support.py ancestor-support-review.stdout.txt ancestor-support-review.stderr.txt junk_preserving_chain_normal_forms.md validate_junk_preserving_chains.py junk-preserving-chain-validation.json junk-preserving-chain-validation.stdout.txt junk-preserving-chain-validation.stderr.txt','normalization_dependencies_and_reviews')
# Bound source preserved for reference; no new Lean claim.
add(R/'lean/PEqualNP/Outside/L_meta_1407.lean','existing_clean_bound_reference')
# S01 logs/results and independently reviewed Boolean partial; historical failures retained.
for pat in ['generation*.txt','encoding-validation*','aaoa-generation*.txt','aaoa-encoding-validation*','bad-parent*.txt','existing-output*.txt','aaoa-bad-parent*.txt','aaoa-existing-output*.txt','late-junk-bool-*','LateJunkBool*.lean']:
 for p in sorted((S/'orch/S01').glob(pat)):add(p,'self_audit_and_partial_logs')
# Joint lower bound and concrete family controls.
names(S/'orch/S01','joint-factor-cost.md check_triangle_joint_cost.py triangle-joint-cost-validation.json triangle-joint-cost.stdout.txt triangle-joint-cost.stderr.txt check_common_neighbor_family.py common-neighbor-family-counterexample.json common-neighbor-family-validation.json common-neighbor-family.stdout.txt common-neighbor-family.stderr.txt','joint_cost_source_and_controls')
# Exact inputs for S01 triangle finite controls only; generator retired, independently unaudited.
names(S/'orch/S02','generate_triangle_factors.py triangle-factor-handoff.json triangle-factor-review.json','retired_triangle_provenance_not_S04_delta_PASS')
for p in sorted((S/'orch/S02/triangle-upper-factors').glob('*.json')):add(p,'retired_triangle_metadata_for_joint_hypotheses')
# Original/normal form metadata carries exact clauses for every child; no CNF bodies.
cnfs=[]
def omitted(original,reproduced):
 p=Path(original);meta=p.with_suffix('.json');add(meta,'exact_CNF_metadata')
 rel=Path('repo')/meta.relative_to(R) if meta.is_relative_to(R) else Path('scratch')/meta.relative_to(S)
 cnfs.append(dict(source_path=str(p),reproduced_path=reproduced,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size,metadata_archive_path=str(rel)))
for name in ['prefix-base','prefix-lex','prefix-distinct']:omitted(O/(name+'.cnf'),'prefix/'+name+'.cnf')
omitted(S/'original-dag-strong/original.cnf','original/original.cnf')
for family in ['consecutive-junk-v2','aaoa-four-v1']:
 base=S/'orch/S01'/family
 add(base/'family.json','exact_family_manifest')
 for p in sorted(base.glob('*.cnf')):omitted(p,family+'/'+p.name)
# Recipe and packaging provenance.
add(O/'reproduce_six_cases.py','portable_exact_recipe')
add(Path(__file__),'preservation_builder')
manifest=dict(format='S04_six_normal_forms_and_joint_cost_v1',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Research preservation: complete six-case existence normalization under stated mathematics, plus joint factor cost mathematical PASS. No CNF UNSAT/global/Lean verdict.',raw_CNF_files_in_archive=0,historical_bindings={'six-case-review-manifest.json original S04 report':'scratch/orch/S04/S04-six-case-reviewed.md'},files=sorted(items.values(),key=lambda r:r['archive_path']),omitted_raw_CNF_recipes=cnfs)
(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(package=str(P),files=len(items),bytes=sum(x['bytes'] for x in items.values()),reconstructable_CNF_count=len(cnfs),raw_CNF_archived=0)))
