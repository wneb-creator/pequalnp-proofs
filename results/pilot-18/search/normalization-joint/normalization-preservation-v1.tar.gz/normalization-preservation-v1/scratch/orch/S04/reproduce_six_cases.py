"""Recreate the reviewed parent and six normal forms from archived sources; no solver."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(name,p):
 spec=importlib.util.spec_from_file_location(name,p)
 m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('package',type=Path);p.add_argument('output',type=Path)
 args=p.parse_args();package=args.package.resolve();out=args.output.resolve()
 if out.exists():raise ValueError('Output must be fresh')
 manifest=json.loads((package/'manifest.json').read_text())
 for r in manifest['files']:
  file=package/r['archive_path']
  assert file.is_file() and not file.is_symlink()
  assert file.stat().st_size==r['bytes'] and sha(file)==r['sha256'],r['archive_path']
 out.mkdir(parents=True,exist_ok=False);(out/'prefix').mkdir()
 sources=package/'repo/results/pilot-18/search'
 g=load('preserved_parent_generator',sources/'search_l1342_shard17_ancestorreverse.py')
 cnf,data=g.build(prefix_sort=True,live=True,productive_prefix=True)
 for name in ['add_prefix_dominance','add_prefix_copy_chain','add_prefix_cover_cost','add_prefix_strict_or','add_prefix_partial_edge_cost','add_prefix_constant_canonical']:
  getattr(g,name)(cnf,data)
 data['prefix_totalizer_reverse']=True
 g.write(cnf,data,out/'prefix/prefix-base.cnf')
 g.add_prefix_lex(out/'prefix/prefix-base.cnf',out/'prefix/prefix-lex.cnf')
 g.add_distinct_prefix(out/'prefix/prefix-lex.cnf',out/'prefix/prefix-distinct.cnf')
 b=load('preserved_original_builder',sources/'build_original_strong.py')
 b.transform(out/'prefix/prefix-distinct.cnf',out/'original')
 s01=package/'scratch/orch/S01'
 j=load('preserved_consecutive_builder',s01/'build_consecutive_junk.py')
 j.generate(out/'original/original.cnf',out/'consecutive-junk-v2')
 a=load('preserved_aaoa_builder',s01/'build_aaoa_shapes.py')
 a.generate(out/'consecutive-junk-v2/AAOA.cnf',out/'aaoa-four-v1')
 checks=[]
 for r in manifest['omitted_raw_CNF_recipes']:
  cnf=out/r['reproduced_path'];metadata=cnf.with_suffix('.json')
  assert cnf.stat().st_size==r['bytes'] and sha(cnf)==r['sha256'],str(cnf)
  oldmeta=package/r['metadata_archive_path']
  assert metadata.read_bytes()==oldmeta.read_bytes(),str(metadata)
  checks.append(dict(file=r['reproduced_path'],sha256=sha(cnf),bytes=cnf.stat().st_size,metadata_byte_equal=True))
 for family in ['consecutive-junk-v2','aaoa-four-v1']:
  assert (out/family/'family.json').read_bytes()==(s01/family/'family.json').read_bytes()
 result=dict(verdict='PASS_EXACT_REPRODUCTION',CNFs=checks,CNF_count=len(checks),metadata_byte_matches=len(checks),family_byte_matches=2,solver_launched=False,Lean_build=False)
 (out/'reproduction-result.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:result[k] for k in ['verdict','CNF_count','metadata_byte_matches','family_byte_matches','solver_launched']}))
if __name__=='__main__':main()
