from pathlib import Path
import hashlib
import itertools
import json
import time

ROOT=Path('/tmp/oec/pequalnp-pilot-18')
OUT=ROOT/'orch/S04'
PARENT=ROOT/'original-dag-strong/original.cnf'
FAMILY=ROOT/'orch/S01/consecutive-junk-v2'
SOURCE=ROOT/'orch/S01/build_consecutive_junk.py'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    start=time.monotonic()
    raw=PARENT.read_bytes();meta=json.loads(PARENT.with_suffix('.json').read_text())
    assert sha(PARENT)==meta['sha256']=='38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08'
    family=json.loads((FAMILY/'family.json').read_text())
    assert family['program_sha256']==sha(SOURCE)
    assert family['parent_sha256']==meta['sha256']
    assert family['parent_metadata_sha256']==sha(PARENT.with_suffix('.json'))
    assert family['operation_partition']==['AAAA','AAOA','AAAO']
    assert family['added_J18_claimed_as_parent_logical_consequence'] is False
    ops=meta['ops'][17:];j18=meta['junk'][18]
    assert ops==[2807,3072,3341,3614] and j18==3243
    body=raw.split(b'\n',1)[1]
    files={}
    for name in ['normalized','AAAA','AAOA','AAAO']:
        delta=[[j18]]
        if name!='normalized':delta += [[op if c=='A' else -op] for c,op in zip(name,ops)]
        extra=''.join(' '.join(map(str,c))+' 0\n' for c in delta).encode()
        expected=f"p cnf 11968 {114566+len(delta)}\n".encode()+body+extra
        path=FAMILY/(name+'.cnf');child=json.loads(path.with_suffix('.json').read_text())
        assert path.read_bytes()==expected
        assert child['sha256']==sha(path)==family['files'][name]['cnf_sha256']
        assert sha(path.with_suffix('.json'))==family['files'][name]['metadata_sha256']
        assert child['clauses']==114566+len(delta) and child['variables']==11968
        for key,value in meta.items():
            if key not in ['sha256','clauses']:assert child[key]==value,key
        assert child['consecutive_junk_added_clauses']==delta
        assert child['consecutive_junk_unit']==j18 and child['consecutive_junk']
        assert child['consecutive_junk_parent_sha256']==meta['sha256']
        assert child['consecutive_junk_parent_metadata_sha256']==sha(PARENT.with_suffix('.json'))
        assert child['consecutive_junk_generator_sha256']==sha(SOURCE)
        assert child['consecutive_junk_claimed_as_logical_consequence'] is False
        assert child['operation_case']==(None if name=='normalized' else name)
        assert child['fixed_chain'] is False
        assert family['files'][name]['added_clauses']==len(delta)
        files[name]={'cnf_sha256':sha(path),'metadata_sha256':sha(path.with_suffix('.json')),
                     'clauses':child['clauses'],'exact_added_clauses':delta}
    accepted=[]
    for bits in itertools.product([False,True],repeat=4):
        valid=bits[0] and bits[1] and sum(bits)>=3
        matches=[name for name in family['operation_partition'] if bits==tuple(c=='A' for c in name)]
        assert len(matches)==(1 if valid else 0)
        if valid:accepted+=matches
    result={'verdict':'PASS_EXACT_J18_AND_THREE_OPERATION_DELTAS',
            'scope':'Only normalized/AAAA/AAOA/AAAO in consecutive-junk-v2; chain variants excluded',
            'source_sha256':sha(SOURCE),'family_manifest_sha256':sha(FAMILY/'family.json'),
            'parent_sha256':sha(PARENT),'parent_metadata_sha256':sha(PARENT.with_suffix('.json')),
            'operation_assignments_checked':16,'accepted_patterns':accepted,'files':files,
            'math_prerequisite':'Reviewed existence normalization; J18 is not claimed as parent logical implication',
            'metadata_note':'Pending-review wording is historical and superseded by this external bound review',
            'script_sha256':sha(Path(__file__)),'seconds':time.monotonic()-start}
    (OUT/'j18-delta-review.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
