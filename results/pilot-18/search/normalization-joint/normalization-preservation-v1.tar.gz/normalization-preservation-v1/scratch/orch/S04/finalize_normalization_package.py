from pathlib import Path
import hashlib,json,tarfile,datetime,io,gzip
O=Path('/tmp/oec/pequalnp-pilot-18/orch/S04');P=O/'normalization-preservation-v1'
manifest=json.loads((P/'manifest.json').read_text())
def sha(raw):return hashlib.sha256(raw).hexdigest()
def add(src,rel,cat):
 raw=src.read_bytes();dest=P/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
 manifest['files'].append(dict(source_path=str(src),archive_path=str(rel),category=cat,bytes=len(raw),sha256=sha(raw)))
for n in ['preservation-preparation.stdout.log','preservation-preparation.stderr.log','preservation-reproduction.stdout.log','preservation-reproduction.stderr.log','finalize_normalization_package.py']:
 add(O/n,Path('scratch/orch/S04')/n,'preservation_full_diagnostics_and_source')
add(O/'preservation-reproduction-v1/reproduction-result.json',Path('reproduction-result.json'),'exact_reconstruction_validation')
readme='''# Six-case normalization and joint-factor-cost preservation

Research evidence only: the two chain forms plus four AAOA forms have an
independent mathematical and exact-delta PASS. The joint factor inequality
has an independent mathematical PASS and bounded DAG controls. This archive
contains no global refutation, accepted gap proof, or new UNSAT certificate.

The six final cases are AAAA-chain, AAAO-chain, T1, T2, T3, T4. The four AAOA
forms require the absorbed AAAA fallback. These are existence normalizations,
not clauses proved to follow from every model of the original CNF. Preserve
the OR(H,H) to OR(FALSE,H) repair and the prefix prune/pad/re-sort argument.
The weaker encoded AAAA leaf order is safe. See the complete S04 report.

The joint bound requires a minimal family of at least three proper full-cover
factors, productivity, clean prefix ANDs, and a nonempty residual for the
distinguished factor. It excludes both retired 17-prefix triangle families:
N(1),N(4),N(8) requires at least18 gates; N(3),N(6),N(7) requires at least19.
It is not yet a Lean lemma or an implemented cut. The retired triangle
metadata/source is preserved only to identify the hypotheses; S04 did not
complete an independent unit-delta audit of that superseded generator.

## Exact reproduction without raw CNF archival

From any extraction location, with Python3 and a fresh writable OUTPUT:

    python PACKAGE/scratch/orch/S04/reproduce_six_cases.py PACKAGE OUTPUT

No third-party package, solver, Lean, network, credentials, or environment
variables are needed. The recipe verifies all manifest-listed artifact hashes,
uses unchanged archived generators, and builds prefix-base/lex/distinct,
the original DAG parent, all six consecutive-junk-v2 files, and T1-T4.
It verifies all14 CNF hashes and sizes, byte equality of all14 metadata files,
and both family manifests. Output is approximately28MB and is not archived.
The retained reproduction run passed all checks; its full logs and result
are included. Reconstruction files must stay outside this package.

The original parent hash is
38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08.
The full case hashes and dimensions are in the metadata and independent
chain-review.json/aaoa-delta-review.json; manifest.json records every omitted
CNF's exact size/hash and reproduction path. No raw .cnf is included.

## Path and historical-hash resolution

repo/ mirrors /workspace/pequalnp-proofs/; scratch/ mirrors
/tmp/oec/pequalnp-pilot-18/. Original paths inside old logs/manifests describe
the original execution, not the extraction directory. The newly supplied
recipe is portable; historical review scripts remain unmodified evidence.
The old six-case-review-manifest.json binds S04-redteam.md at its earlier
hash a284417b...c42ef. That exact historical report is preserved as
scratch/orch/S04/S04-six-case-reviewed.md. The current report additionally
contains the joint bound review. Existing pending-review fields in generated
metadata are historical generation statuses, superseded by separate S04
reviews, not silently rewritten. NOTES and reports are timestamped snapshots;
other agents may append after this preservation cut.

Early failed control/compile logs are retained beside final successful logs;
only the corresponding final hash-bound results establish their stated
PASS. The S01 Lean Boolean helpers are limited compiled partials already
reported by S01; no new Lean build was performed by this packaging step.
'''
(P/'README.md').write_text(readme)
manifest['files'].append(dict(source_path='generated preservation README',archive_path='README.md',category='preservation_scope_and_recipe',bytes=len(readme.encode()),sha256=sha(readme.encode())))
manifest['files'].sort(key=lambda r:r['archive_path'])
assert len({r['archive_path'] for r in manifest['files']})==len(manifest['files'])
(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Validate exact directory inventory, then archive regular files only.
expected={r['archive_path']:r for r in manifest['files']}
actual={str(p.relative_to(P)):p for p in P.rglob('*') if p.is_file()}
assert set(actual)==set(expected)|{'manifest.json'}
for name,r in expected.items():
 p=actual[name];assert not p.is_symlink() and p.suffix!='.cnf'
 assert p.stat().st_size==r['bytes'] and sha(p.read_bytes())==r['sha256'],name
hist=json.loads((P/'scratch/orch/S04/six-case-review-manifest.json').read_text())
old=hist['/workspace/pequalnp-proofs/results/orch/lemmas/S04-redteam.md']
assert sha((P/'scratch/orch/S04/S04-six-case-reviewed.md').read_bytes())==old['sha256']
archive=O/'normalization-preservation-v1.tar.gz'
with archive.open('wb') as stream,gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for name,p in sorted(actual.items()):
  raw=p.read_bytes();info=tarfile.TarInfo('normalization-preservation-v1/'+name)
  info.size=len(raw);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(actual)
 for member in members:
  assert member.isfile() and '..' not in Path(member.name).parts and not member.name.startswith('/')
  name=member.name.removeprefix('normalization-preservation-v1/')
  assert tar.extractfile(member).read()==actual[name].read_bytes(),name
result=dict(verdict='PASS_PRESERVATION_AND_EXACT_REPRODUCTION',archive=str(archive),archive_sha256=sha(archive.read_bytes()),archive_bytes=archive.stat().st_size,manifest_sha256=sha((P/'manifest.json').read_bytes()),regular_members=len(actual),bound_artifacts=len(expected),uncompressed_bytes=sum(p.stat().st_size for p in actual.values()),raw_CNF_count=0,exact_reproduced_CNF_count=14,exact_reproduced_metadata_count=14,exact_reproduced_families=2,historical_report_binding_resolved=True,solver_run=False,Lean_build=False,git_write=False,scope=manifest['scope'])
(O/'normalization-preservation-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
