from pathlib import Path
import json,hashlib,tarfile,gzip,io,datetime
R=Path('/workspace/pequalnp-proofs');S=Path('/tmp/oec/pequalnp-pilot-18');O=S/'orch/S04';I=S/'orch/S01';P=O/'tight-survivor-preservation-v1'
P.mkdir(exist_ok=False)
handoff=I/'joint-cost-handoff.json';h=json.loads(handoff.read_text())
assert hashlib.sha256(handoff.read_bytes()).hexdigest()=='d187d5ef0337b54dfcd25bf2722851604463f382e9fad5ca30943b56e41cf328'
files=[handoff]
for a in h['files']:
 p=Path(a['path']);assert p.is_relative_to(I) and not p.is_symlink()
 raw=p.read_bytes();assert len(raw)==a['bytes'] and hashlib.sha256(raw).hexdigest()==a['sha256'];files.append(p)
files += [O/n for n in ['review_tight_survivor.py','tight-survivor-review.json','tight-survivor-review.stdout.log','tight-survivor-review.stderr.log','review_tight_survivor.initial.py','tight-survivor-initial.json','tight-survivor-initial.stdout.log','tight-survivor-initial.stderr.log','preserve_tight_review.py']]
files += [R/'results/orch/lemmas/S04-redteam.md']
records=[]
for p in files:
 assert p.is_file() and not p.is_symlink() and p.suffix!='.cnf'
 rel=Path('repo')/p.relative_to(R) if p.is_relative_to(R) else Path('scratch')/p.relative_to(S)
 raw=p.read_bytes();q=P/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(raw)
 records.append(dict(source_path=str(p),archive_path=str(rel),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
readme='''# Tight surviving support triple: independent mathematical review

The full-cover support triple {8,10}, {9,10}, {4,6} needs at least18
gates in a productive clean prefix. S04 mathematical PASS applies to
S01 tight-survivor-obstruction.md SHA69bb5f1587acceb0fd5ecebf3ed4a525919c439eef62c70a7c11e9ae149a1acc.
All18 joint-cost-handoff bindings pass. All source/proof/result/log artifacts
are included, with S04's independent controls and final report.

The final S04 report gives a shorter proof: after establishing B's exact
14-gate cone, the companion OR operand P has support {4,6} and belongs to
that cone. Its common-neighbor set {10} lies inside support(B)={9,10}.
The newly reviewed arbitrary-ancestor restriction charge makes B's cone
at least15, contradiction. The raw-x0 and eight-edge matching4 derivation
in S01's original proof is valid but is not needed for this shorter proof.

The final local control source is SHA437a6441a10c31fe45d9e46b864cb46c1da8b68f226471104371e09daec12422;
its full stdout/stderr and JSON retain8 actual DAGs and all redirects.
They cover strict edge increases (equality is not required), constants,
copies,16192 negative-wire equalities and94208 pointwise nondecreases.
Initial controls are preserved as historical diagnostics; final source
removed an irrelevant tautological assertion and is authoritative.

This is not a Lean theorem or a CNF UNSAT certificate. No dirty-prefix or
global circuit refutation follows. The earlier all-common-neighbor support
relaxation had515 surviving triples; only this one is excluded here.
The base normalization archive ab76bf72819cac52f98c13d133b94fceedc2dc7fa4952ef06f825d19081beea4
and enumeration addendum136bc083a89edf8e5ff08e146f131fa3c094b90ca1d22f6748f0c7ef0332bffa
remain unchanged. No raw CNF, solver, binary, or credential is included.
repo/ and scratch/ mirror the original repository and pilot scratch roots.
'''
(P/'README.md').write_text(readme)
records.append(dict(source_path='generated review README',archive_path='README.md',bytes=len(readme.encode()),sha256=hashlib.sha256(readme.encode()).hexdigest()))
manifest=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Independent mathematical proof review of one productive clean prefix lower bound18, plus original S01 handoff and bounded scalar controls.',raw_CNF_count=0,solver_run=False,Lean_build=False,files=records)
(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=O/'tight-survivor-preservation-v1.tar.gz'
with archive.open('wb') as stream,gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for p in sorted(P.rglob('*')):
  if not p.is_file():continue
  raw=p.read_bytes();info=tarfile.TarInfo(P.name+'/'+str(p.relative_to(P)));info.size=len(raw);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(records)+1
 for m in members:
  assert m.isfile() and '..' not in Path(m.name).parts
  assert tar.extractfile(m).read()==(P/m.name.removeprefix(P.name+'/')).read_bytes()
result=dict(verdict='PASS_TIGHT_REVIEW_PRESERVATION',archive=str(archive),archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),archive_bytes=archive.stat().st_size,regular_members=len(records)+1,manifest_sha256=hashlib.sha256((P/'manifest.json').read_bytes()).hexdigest(),review_json_sha256=hashlib.sha256((O/'tight-survivor-review.json').read_bytes()).hexdigest(),source_math_sha256='69bb5f1587acceb0fd5ecebf3ed4a525919c439eef62c70a7c11e9ae149a1acc',shorter_proof_in='repo/results/orch/lemmas/S04-redteam.md',scope=manifest['scope'])
(O/'tight-survivor-preservation-handoff.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
