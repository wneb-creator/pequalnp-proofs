#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
   (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
M=[(1<<u)|(1<<v) for u,v in E]
SUPPORTS=[(8,10),(9,10),(4,6)]
masks=[sum(1<<v for v in s) for s in SUPPORTS]
I=[x for x in range(2048) if all(x&e!=e for e in M)]
MIS=[x for x in I if not any(x!=y and x&y==x for y in I)]
assert len(I)==125 and len(MIS)==24
rows=[]
for support,sm in zip(SUPPORTS,masks):
    edges=[e for e in M if not sm&e]
    covers=[c for c in range(2048) if all(c&e for e in edges)]
    tau=min(c.bit_count() for c in covers)
    cn=[v for v in range(11) if all((min(v,u),max(v,u)) in E for u in support)]
    rows.append(dict(support=list(support),mask=sm,residual_edge_count=len(edges),
                     cover=tau,cover_witness=next(c for c in covers if c.bit_count()==tau),
                     cost=len(support)+len(edges)+tau-1,common_neighbors=cn,
                     zero_MIS_mask=sum(1<<i for i,x in enumerate(MIS) if not x&sm)))
owners=sum(1<<r['common_neighbors'][0] for r in rows)
for r in rows:
    r['joint_bound']=r['cost']+(r['mask']&owners).bit_count()
assert [r['cost'] for r in rows]==[14,14,16]
assert [r['joint_bound'] for r in rows]==[15,15,17]
assert sorted(r['cost'] for r in rows)==[14,14,16]
assert all(a<=b for a,b in zip(sorted(r['cost'] for r in rows),[15,16,17]))
for a,b in ((0,1),(0,2),(1,2)):
    assert masks[a]&masks[b] not in (masks[a],masks[b])
private=[]
for j in range(3):
    candidates=[x for x in I if not x&masks[j] and all(x&masks[k] for k in range(3) if k!=j)]
    assert candidates
    private.append(min(candidates,key=lambda x:(x.bit_count(),x)))
for x in range(2048):
    target=any(x&e==e for e in M)
    h=[target or bool(x&s) for s in masks]
    assert all(h)==target
    assert (h[0] and h[1])==(target or bool(x&(1<<10)))
data=json.loads((ROOT/'joint-support-enumeration.json').read_text())
assert [a['s'] for a in data['survivor']]==masks
result=dict(verdict='PASS_SURVIVING_SUPPORT_RELAXATION',
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    enumeration_sha256=hashlib.sha256((ROOT/'joint-support-enumeration.json').read_bytes()).hexdigest(),
    factors=rows,private_independent_inputs=private,truth_checks=4096,
    sorted_capacities=[15,16,17],actual_shared_prefix=False,solver_run=False,
    forced_ancestry={'ancestor_support':[9,10],'descendant_support':[4,6],
      'reason':'Joint charge16+1 already uses17 gates. This other factor is not in the charged owner4 group; if outside the descendant cone it adds another gate, forcing18.',
      'first_AND_other_operand_support':[0]},
    product_of_first_two='F OR x10')
(ROOT/'joint-survivor-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'verdict':result['verdict'],'source_sha256':result['source_sha256'],
                  'costs':[r['cost'] for r in rows],'joint_bounds':[r['joint_bound'] for r in rows],
                  'private_inputs':private}))
