# Tight surviving support triple: independent mathematical review

The full-cover support triple {8,10}, {9,10}, {4,6} needs at least18
gates in a productive clean prefix. S04 mathematical PASS applies to
S01 tight-survivor-obstruction.md SHA69bb5f1587acceb0fd5ecebf3ed4a525919c439eef62c70a7c11e9ae149a1acc.
All18 joint-cost-handoff bindings pass. All source/proof/result/log artifacts
are included, with S04's independent controls and final report.

The final S04 report gives a shorter proof: after establishing B's exact
14-gate cone, the companion OR operand P has support {4,6} and belongs to
that cone. Its common-neighbor set {10} lies inside support(B)={9,10}.
The newly reviewed arbitrary-ancestor restriction charge makes B's cone
at least15, contradiction. The raw-x0 and eight-edge matching4 derivation
in S01's original proof is valid but is not needed for this shorter proof.

The final local control source is SHA437a6441a10c31fe45d9e46b864cb46c1da8b68f226471104371e09daec12422;
its full stdout/stderr and JSON retain8 actual DAGs and all redirects.
They cover strict edge increases (equality is not required), constants,
copies,16192 negative-wire equalities and94208 pointwise nondecreases.
Initial controls are preserved as historical diagnostics; final source
removed an irrelevant tautological assertion and is authoritative.

This is not a Lean theorem or a CNF UNSAT certificate. No dirty-prefix or
global circuit refutation follows. The earlier all-common-neighbor support
relaxation had515 surviving triples; only this one is excluded here.
The base normalization archive ab76bf72819cac52f98c13d133b94fceedc2dc7fa4952ef06f825d19081beea4
and enumeration addendum136bc083a89edf8e5ff08e146f131fa3c094b90ca1d22f6748f0c7ef0332bffa
remain unchanged. No raw CNF, solver, binary, or credential is included.
repo/ and scratch/ mirror the original repository and pilot scratch roots.
