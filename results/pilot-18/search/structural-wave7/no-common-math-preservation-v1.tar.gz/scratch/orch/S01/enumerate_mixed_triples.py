#!/usr/bin/env python3
"""Complete scalar triple census from all exact supports, without solver."""
import hashlib
import itertools
import json
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
start=time.monotonic()
parent=ROOT/'no-common-cover-probe.json'
data=json.loads(parent.read_text())
E=data['edges'];MIS=data['MIS'];ALL=(1<<24)-1
N=[sum(1<<(b if a==x else a) for a,b in E if x in(a,b)) for x in range(11)]
raw=sorted([r for p in data['pool'] for r in p['representatives']],key=lambda a:a['s'])
assert len(raw)==958 and len({a['s'] for a in raw})==958
def common(s):return any(n&s==s for n in N)
unions=[0]*2048
for a in range(1,2048):
    bit=a&-a;unions[a]=unions[a^bit]|N[bit.bit_length()-1]
bycost=sorted(range(2048),key=int.bit_count)
gamma=[next(a.bit_count() for a in bycost if unions[a]&s==s) for s in range(2048)]

def simple_position(family):
    # Existing reviewed generic position conditions, omitting optional raw charges.
    S=[a['s'] for a in family];L=[a['cost'] for a in family]
    O=[a['owner'] for a in family];empty=[a['empty_cn'] for a in family]
    for pos in itertools.product(*(range(l-1,17) for l in L)):
        if len(set(pos))<3:continue
        pairs=[(a,b) for a in range(3) for b in range(3) if pos[a]<pos[b]]
        for flags in itertools.product((False,True),repeat=3):
            anc=[[False]*3 for _ in range(3)]
            for (a,b),flag in zip(pairs,flags):anc[a][b]=flag
            if any(empty[a] and anc[a][b] for a,b in pairs):continue
            if any(anc[a][b] and anc[b][c] and not anc[a][c] for a,b,c in itertools.permutations(range(3))):continue
            if any(anc[a][b] and not any(t not in pos for t in range(pos[a]+1,pos[b])) for a,b in pairs):continue
            bounds=[];valid=True
            for i in range(3):
                sources=[j for j in range(3) if anc[j][i]]
                if len(sources)>1:
                    lo=min(pos[j] for j in sources)
                    if sum(t not in pos for t in range(lo+1,pos[i]))<len(sources):valid=False;break
                outside=[j for j in range(3) if pos[j]<pos[i] and not anc[j][i]]
                excluded=int(any(anc[a][b] and pos[b]<pos[i] and not anc[a][i] for a,b in pairs if i not in(a,b)))
                upper=pos[i]+1-len(outside)-excluded
                ownermask=0
                for j in sources:
                    assert O[j] is not None
                    ownermask|=1<<O[j]
                # To use only previously reviewed joint charge, skip empty H.
                lower=L[i]+((S[i]&ownermask).bit_count() if family[i]['residual_edges'] else 0)
                bounds.append((lower,upper))
                if lower>upper:valid=False;break
            if valid:return dict(positions=pos,ancestry=anc,cone_bounds=bounds)
    return None

results=[]
for r in (1,2,3):
    pool=[a for a in raw if a['cost']<=17-r+int(a['empty_cn'])]
    bitsets=[sum(1<<i for i,a in enumerate(pool) if a['z']>>b&1) for b in range(24)]
    full=(1<<len(pool))-1
    counts=dict(r=r,pool=len(pool),pairs=0,covered_triples=0,exact_r=0,minimal=0,slots=0,
                joint_pass=0,position_pass=0,region_pass=0)
    rows=[]
    for i,a in enumerate(pool):
        for j in range(i+1,len(pool)):
            counts['pairs']+=1
            missing=ALL&~(a['z']|pool[j]['z'])
            possible=full&~((1<<(j+1))-1)
            while missing and possible:
                b=missing&-missing;possible&=bitsets[b.bit_length()-1];missing-=b
            while possible:
                b=possible&-possible;h=b.bit_length()-1;possible-=b
                family=[a,pool[j],pool[h]]
                counts['covered_triples']+=1
                if sum(t['empty_cn'] for t in family)!=r:continue
                counts['exact_r']+=1
                if any(not family[t]['z']&~(family[(t+1)%3]['z']|family[(t+2)%3]['z']) for t in range(3)):continue
                counts['minimal']+=1
                if any(l>c for l,c in zip(sorted(t['cost'] for t in family),(15,16,17))):continue
                counts['slots']+=1
                ownermask=sum(1<<o for o in {t['owner'] for t in family if t['owner'] is not None})
                joint=[t['cost']+r-int(t['empty_cn'])+(t['s']&ownermask).bit_count() for t in family]
                if any(v>17 and t['residual_edges'] for t,v in zip(family,joint)):continue
                counts['joint_pass']+=1
                positions=simple_position(family)
                counts['position_pass']+=int(positions is not None)
                region=[]
                for t,f in enumerate(family):
                    eligible=[u for u in range(3) if u!=t and family[u]['empty_cn'] and common(f['s']&family[u]['s'])]
                    extra=0
                    for choice in range(1<<len(eligible)):
                        picked=[eligible[b] for b in range(len(eligible)) if choice>>b&1]
                        if all(common(family[u]['s']&family[v]['s']) for u,v in itertools.combinations(picked,2)):
                            extra=max(extra,sum(gamma[family[u]['s']]-2 for u in picked))
                    # New S04 extension includes empty residual; separate output.
                    region.append(joint[t]+extra)
                region_pass=max(region)<=17
                counts['region_pass']+=int(positions is not None and region_pass)
                rows.append(dict(supports=[t['s'] for t in family],individual_costs=[t['cost'] for t in family],
                    owners=[t['owner'] for t in family],residual_edges=[t['residual_edges'] for t in family],
                    joint_costs=joint,position_witness=positions,region_costs=region,
                    gamma=[gamma[t['s']] for t in family],region_pass=region_pass))
    results.append(dict(counts=counts,families=rows))
    print(json.dumps(counts),flush=True)
    assert time.monotonic()-start<55
out=dict(verdict='COMPLETE_MIXED_THREE_FACTOR_SUPPORT_CENSUS_PENDING_REVIEW',
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    input_sha256=hashlib.sha256(parent.read_bytes()).hexdigest(),elapsed_seconds=time.monotonic()-start,
    results=results,gamma=gamma,solver_run=False,Lean_proof=False,
    scope='All958exact support rows. Joint/position constraints use reviewed nonempty-residual charge; region column additionally uses proposed S04 gamma/outside-region and empty-residual charge, separately marked pending review.')
(ROOT/'mixed-triple-census.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ('source_sha256','input_sha256','elapsed_seconds')}))
