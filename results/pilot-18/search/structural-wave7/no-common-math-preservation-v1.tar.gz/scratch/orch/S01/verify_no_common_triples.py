#!/usr/bin/env python3
"""Separate exhaustive pair/bitset check of a three-factor relaxation."""
import hashlib
import json
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
start=time.monotonic()
edges=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
       (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
edge_masks=[(1<<u)|(1<<v) for u,v in edges]
neighborhoods=[{v if u==x else u for u,v in edges if x in (u,v)} for x in range(11)]
independent=[s for s in range(2048) if not any(s&e==e for e in edge_masks)]
maximal=[s for s in independent if all(s>>v&1 or (s|(1<<v)) not in independent for v in range(11))]
assert len(maximal)==24
all_rows=(1<<24)-1
memo={}
def cover(es):
    if not es:return 0
    if es not in memo:
        u,v=es[0]
        memo[es]=1+min(cover(tuple(e for e in es if u not in e)),
                       cover(tuple(e for e in es if v not in e)))
    return memo[es]
table={}
raw=0
for s in range(2047):
    vertices={v for v in range(11) if s>>v&1}
    if any(vertices<=n for n in neighborhoods):continue
    es=tuple(e for e in edges if not any(v in vertices for v in e))
    cost=len(vertices)+len(es)+cover(es)-1
    z=sum(1<<i for i,a in enumerate(maximal) if not a&s)
    if not z or cost>17:continue
    raw+=1
    if z not in table or (cost,s)<(table[z]['cost'],table[z]['s']):
        table[z]=dict(s=s,cost=cost,z=z)
assert raw==909 and len(table)==339
cases=[]
for budget in (15,16,17):
    pool=sorted((a for a in table.values() if a['cost']<=budget),key=lambda a:a['s'])
    bits=[sum(1<<i for i,a in enumerate(pool) if a['z']>>b&1) for b in range(24)]
    full=(1<<len(pool))-1
    pair_checks=0; witnesses=[]; seen_triples=set()
    for i,a in enumerate(pool):
        for j in range(i+1,len(pool)):
            pair_checks+=1
            missing=all_rows&~(a['z']|pool[j]['z'])
            possible=full&~((1<<(j+1))-1)
            while missing and possible:
                bit=missing&-missing
                possible &= bits[bit.bit_length()-1]
                missing-=bit
            while possible:
                bit=possible&-possible;t=bit.bit_length()-1;possible-=bit
                trio=[a,pool[j],pool[t]]
                assert a['z']|pool[j]['z']|pool[t]['z']==all_rows
                seen_triples.add((i,j,t))
                if len(witnesses)<4:witnesses.append(trio)
    cases.append(dict(budget=budget,pool=len(pool),pairs=pair_checks,
                      cover_triples=len(seen_triples),examples=witnesses))
    print(json.dumps(cases[-1]),flush=True)
assert cases[0]['cover_triples']==0
result=dict(verdict='NO_THREE_CN_EMPTY_FACTORS_AT_COST_15_FINITE_RECHECK',
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    elapsed_seconds=time.monotonic()-start,raw_supports=raw,coverage_patterns=len(table),
    MIS=maximal,cases=cases,solver_run=False,Lean_proof=False,
    scope='All distinct rejection-pattern triples; independent cover recursion, minimum representative costs. No ancestry enumeration or circuit claim.')
(ROOT/'no-common-triples-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('verdict','source_sha256','elapsed_seconds')}))
