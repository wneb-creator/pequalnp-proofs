# No-common-neighbor factor families: a finite necessary relaxation

For independent review. No new normalization, circuit construction, Lean
theorem, SAT result or global exhaustion is claimed.

In the already reviewed productive clean-prefix setting, retain a minimal
family of proper full-cover factors W_i=F OR OR(S_i). Equal rejection patterns
cannot occur in such a family. Every support is at least size two by the
proved full-cover cost bound. Constants/full-support factors are redundant.
Write k for the family size, r for the number of supports with no common
neighbor, and L(S)=|S|+|E(G-S)|+tau(G-S)-1. This cost remains valid for
edgeless residuals, where it is simply |S|-1.

A no-common-neighbor factor cannot reach any other chosen factor through a
productive AND, by the reviewed ancestry lemma. An OR-only path would imply
support inclusion, contrary to minimality. Therefore its output gate lies
outside every other chosen output's ancestor cone. For a distinguished
factor i the other r-1 such gates, or all r if i has a common neighbor, lie
outside its cone. Consequently

    L(S_i) <= 17-r+1   if S_i has no common neighbor,
    L(S_i) <= 17-r     otherwise.

This statement needs no nonempty-residual premise or joint-owner charge.
Moreover distinct output positions require sorted individual costs to fit
the final k capacities 18-k,...,17. These are necessary bounds only.

There are 958 eligible proper supports with L<=17 and a nonempty rejection
set on the 24 maximal independent sets: 909 without a common neighbor and
49 with one. Grouping by the exact 24-bit rejection pattern and common-
neighbor status gives 382 groups: 339 without and43 with. In this graph no
pattern has both statuses. Retain the minimum L in each group. This only
weakens the constraints: every real family induces distinct pattern groups
whose retained costs are at most its actual costs. It does not identify
actual circuit wires or preserve owner/ancestry properties beyond the status.

The bounded scalar probe exhausts or finds a first minimal cover for each
(k,r), 3<=k<=5 and1<=r<=k. It applies the cone bounds, distinct position costs
and exact minimality of the pattern cover; no owner or selected-ancestry
restrictions are imposed. All twelve cases completed in under one second.

For k=r=3 there is NO relaxed cover. The independent pair/bitset verification
uses a separate edge-branch recurrence for tau and exhausts all pattern
triples with L<=15. Thus a productive17-gate clean prefix cannot supply a
minimal three-factor full-cover family all of whose supports have no common
neighbor. The finite computation and this implication require independent
review before use as an accepted pruning result.

The other eleven cases have explicit relaxation witnesses. They are support
families, not shared-prefix circuits. In particular no claim closes r=1/2
for k=3, or any r>0 class for k=4/5. The existing all-common-neighbor k5
closure is a separate independently reviewed result.

The probe stores all 958 supports grouped by pattern, complete case counters,
and explicit representative witnesses. The separate verifier stores every
case count, example triples at larger budgets, source hashes and full logs.
