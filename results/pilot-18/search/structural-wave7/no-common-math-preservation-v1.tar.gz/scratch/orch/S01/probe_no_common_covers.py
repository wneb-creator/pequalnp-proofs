#!/usr/bin/env python3
"""Bounded scalar necessary-condition search; no circuit or SAT claim."""
import hashlib
import itertools
import json
import time
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
START = time.monotonic()
E = [(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
     (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
EM = [(1 << u) | (1 << v) for u,v in E]
N = [sum(1 << (v if u == x else u) for u,v in E if x in (u,v)) for x in range(11)]
IND = [a for a in range(2048) if all(a&e != e for e in EM)]
MIS = [a for a in IND if not any(a != b and a&b == a for b in IND)]
ALL = (1 << len(MIS))-1
assert len(MIS) == 24
groups = {}
raw = []
for s in range(2047):
    rem = 2047 ^ s
    edges = sum(not s&e for e in EM)
    cover = rem.bit_count() - max((i&rem).bit_count() for i in IND)
    cost = s.bit_count()+edges+cover-1
    z = sum(1 << j for j,a in enumerate(MIS) if not a&s)
    owners = [v for v,n in enumerate(N) if n&s == s]
    if cost > 17 or not z:
        continue
    assert s.bit_count() >= 2 and len(owners) <= 1
    row = dict(s=s,cost=cost,z=z,empty_cn=not owners,owner=owners[0] if owners else None,
               residual_edges=edges)
    raw.append(row)
    groups.setdefault((z,not owners), []).append(row)
pool = []
for (z,empty),rows in groups.items():
    rows.sort(key=lambda r:(r['cost'],r['s']))
    pool.append(dict(z=z,empty_cn=empty,cost=rows[0]['cost'],representative=rows[0],
                     representatives=rows))
pool.sort(key=lambda r:(-r['z'].bit_count(),r['cost'],r['representative']['s']))
assert len(raw)==958 and len(pool)==382
assert len({r['z'] for r in pool})==len(pool)

class Budget(Exception):
    pass

def run(k,r,seconds):
    case_start=time.monotonic()
    ids=[i for i,a in enumerate(pool) if a['cost']<=17-r+int(a['empty_cn'])]
    bybit=[[i for i in ids if pool[i]['z']>>b&1] for b in range(24)]
    seen=set(); nodes=0
    def dfs(chosen,union,nempty):
        nonlocal nodes
        nodes+=1
        if nodes%256==0 and (time.monotonic()-case_start>seconds or time.monotonic()-START>54):
            raise Budget
        left=k-len(chosen)
        if nempty>r or nempty+left<r:
            return None
        costs=sorted(pool[i]['cost'] for i in chosen)
        # Remaining factors can only reduce the slots available to the chosen ones.
        if any(v>cap for v,cap in zip(costs,range(18-len(costs),18))):
            return None
        if union==ALL:
            if left or nempty!=r:
                return None
            return chosen
        if not left:
            return None
        key=tuple(sorted(chosen))
        if key in seen:
            return None
        seen.add(key)
        candidates=[]
        oldz=[pool[i]['z'] for i in chosen]
        priv=[]
        for j,z in enumerate(oldz):
            others=0
            for t,w in enumerate(oldz):
                if j!=t:others|=w
            priv.append(z&~others)
        for i in ids:
            a=pool[i]
            if not a['z']&~union:
                continue
            ne=nempty+int(a['empty_cn'])
            if ne>r or ne+left-1<r:
                continue
            if any(not p&~a['z'] for p in priv):
                continue
            candidates.append(i)
        cover_union=union
        for i in candidates:cover_union|=pool[i]['z']
        if cover_union!=ALL:
            return None
        gains=sorted(((pool[i]['z']&~union).bit_count() for i in candidates),reverse=True)
        if sum(gains[:left])<(ALL&~union).bit_count():
            return None
        available=set(candidates)
        bit=min((b for b in range(24) if not union>>b&1),
                key=lambda b:sum(i in available for i in bybit[b]))
        branch=[i for i in bybit[bit] if i in available]
        branch.sort(key=lambda i:(-(pool[i]['z']&~union).bit_count(),pool[i]['cost'],i))
        for i in branch:
            result=dfs(chosen+(i,),union|pool[i]['z'],nempty+int(pool[i]['empty_cn']))
            if result is not None:return result
        return None
    try:
        witness=dfs((),0,0)
        verdict='RELAXATION_FEASIBLE' if witness is not None else 'NO_RELAXED_MINIMAL_COVER'
    except Budget:
        witness=None; verdict='UNKNOWN_TIME_LIMIT'
    result=dict(k=k,r=r,verdict=verdict,nodes=nodes,seconds=time.monotonic()-case_start,
                pattern_count=len(ids),witness=None)
    if witness is not None:
        rows=[pool[i]['representative'] for i in witness]
        assert len(rows)==k and sum(a['empty_cn'] for a in rows)==r
        assert all(a['cost']<=17-r+int(a['empty_cn']) for a in rows)
        assert all(v<=cap for v,cap in zip(sorted(a['cost'] for a in rows),range(18-k,18)))
        unions=[]
        for j,a in enumerate(rows):
            others=0
            for t,b in enumerate(rows):
                if j!=t:others|=b['z']
            assert a['z']&~others
            unions.append(a['z'])
        assert __import__('functools').reduce(int.__or__,unions,0)==ALL
        ownermask=sum(1<<o for o in {a['owner'] for a in rows if a['owner'] is not None})
        for a in rows:
            a=dict(a)
        result['witness']=rows
        result['joint_charge_values']=[a['cost']+r-int(a['empty_cn'])+
             (a['s']&ownermask).bit_count() for a in rows]
        result['representative_joint_charge_pass']=all(a['residual_edges']==0 or b<=17
             for a,b in zip(rows,result['joint_charge_values']))
    return result

results=[]
for k in (3,4,5):
    for r in range(1,k+1):
        if time.monotonic()-START>53:
            results.append(dict(k=k,r=r,verdict='NOT_STARTED_TOTAL_TIME_LIMIT'))
            continue
        row=run(k,r,4.0)
        results.append(row)
        print(json.dumps(row),flush=True)
output=dict(verdict='FINITE_NECESSARY_CONDITION_PROBE',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    elapsed_seconds=time.monotonic()-START,edges=E,MIS=MIS,raw_support_count=len(raw),
    pattern_count=len(pool),pattern_types=dict(Counter(str(a['empty_cn']) for a in pool)),pool=pool,
    results=results,solver_run=False,Lean_proof=False,
    scope='Exact minimal 24-MIS cover size k with exactly r no-common-neighbor patterns; minimum support costs, necessary cone caps and distinct output slot budgets. Feasible patterns are not circuits. No joint-owner or full ancestry filter imposed.')
(ROOT/'no-common-cover-probe.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({k:output[k] for k in ('source_sha256','elapsed_seconds','raw_support_count','pattern_count','pattern_types')}))
