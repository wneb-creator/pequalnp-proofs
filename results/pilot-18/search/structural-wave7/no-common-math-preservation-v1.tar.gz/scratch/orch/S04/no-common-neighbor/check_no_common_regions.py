from pathlib import Path
import collections,functools,hashlib,itertools,json,time
O=Path('/tmp/oec/pequalnp-pilot-18/orch/S04/no-common-neighbor');I=O.parents[1]/'S01';START=time.monotonic()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
EM=[(1<<a)|(1<<b) for a,b in E];N=[sum(1<<(b if a==v else a) for a,b in E if v in (a,b)) for v in range(11)]
def CN(s):return sum(1<<v for v in range(11) if s&~N[v]==0)
@functools.lru_cache(None)
def gamma(s):
 if not s:return (0,0)
 v=(s&-s).bit_length()-1
 return min((1+gamma(s&~N[u])[0],gamma(s&~N[u])[1]|(1<<u)) for u in range(11) if N[u]>>v&1)
# Independent exhaustive owner subsets and superset transform.
direct=[(99,0)]*2048
for d in range(2048):
 union=functools.reduce(int.__or__,(N[v] for v in range(11) if d>>v&1),0)
 direct[union]=min(direct[union],(d.bit_count(),d))
for v in range(11):
 for s in range(2048):
  if not s>>v&1:direct[s]=min(direct[s],direct[s|(1<<v)])
assert all(gamma(s)==direct[s] for s in range(2048))
ind=[s for s in range(2048) if not any(s&e==e for e in EM)]
mis=[s for s in ind if all((s|(1<<v)) not in ind for v in range(11) if not s>>v&1)]
assert len(ind)==125 and len(mis)==24
@functools.lru_cache(None)
def cover(edges):
 if not edges:return 0
 return 1+min(cover(tuple(e for e in edges if not e>>v&1)) for v in range(11) if edges[0]>>v&1)
def cost(s):
 residual=tuple(e for e in EM if not s&e)
 return s.bit_count()+len(residual)+cover(residual)-1
pool=[]
for s in range(2047):
 zero=[m for m in mis if not m&s]
 if cost(s)<=17 and zero:pool.append({'support':s,'cost':cost(s),'common_neighbors':CN(s),'gamma':gamma(s)[0],'gamma_witness':gamma(s)[1],'MIS':zero,'residual_edges':[e for e in EM if not e&s]})
assert len(pool)==958
nocn=[r for r in pool if not r['common_neighbors']];pure=[r for r in pool if not r['residual_edges']]
assert len(nocn)==909 and collections.Counter(r['gamma'] for r in nocn)=={2:568,3:341}
assert len(pure)==24 and collections.Counter(r['gamma'] for r in pure)=={2:2,3:22}
assert all(len(r['MIS'])==1 and r['support']^r['MIS'][0]==2047 for r in pure)
assert gamma(1778)==(3,(1<<0)|(1<<3)|(1<<8))
two_cover_obstruction=[]
for owners in range(2048):
 if owners.bit_count()>2:continue
 covered=functools.reduce(int.__or__,(N[v] for v in range(11) if owners>>v&1),0)
 missing=1778&~covered;assert missing
 two_cover_obstruction.append({'owners':owners,'uncovered_vertex':(missing&-missing).bit_length()-1})
assert len(two_cover_obstruction)==67

def bounds(supports):
 r=sum(not CN(s) for s in supports);records=[]
 for i,s in enumerate(supports):
  z=r-int(not CN(s));owners={v for a in supports for v in range(11) if CN(a)==1<<v and s>>v&1}
  eligible=[j for j,t in enumerate(supports) if j!=i and not CN(t) and CN(s&t)]
  candidates=[]
  for mask in range(1<<len(eligible)):
   J=[j for bit,j in enumerate(eligible) if mask>>bit&1]
   if all(CN(supports[a]&supports[b]) for a,b in itertools.combinations(J,2)):
    candidates.append((sum(gamma(supports[j])[0]-2 for j in J),J))
  extra,J=max(candidates,key=lambda row:(row[0],[-j for j in row[1]]))
  records.append({'i':i,'support':s,'L':cost(s),'d':len(owners),'z':z,'extra':extra,'J':J,'B':z+extra,'old_joint':cost(s)+len(owners)+z,'new_joint':cost(s)+len(owners)+z+extra})
 return records

producer=I/'no-common-cover-probe.json'
assert sha(producer)=='3039248ed2df7b51b217057d6b34d7b41c3d4caa90ebbd540ccdd35021fe1e23'
data=json.loads(producer.read_text());families=[]
for row in data['results']:
 if not row.get('witness'):continue
 supports=[r['s'] for r in row['witness']]
 # Verify these specific representatives directly, without accepting the
 # producer's compressed-pattern search or any entire-class exclusion.
 zeros=[sum(1<<j for j,m in enumerate(mis) if not s&m) for s in supports]
 assert functools.reduce(int.__or__,zeros)==(1<<24)-1
 assert all(functools.reduce(int.__or__,zeros[:i]+zeros[i+1:])!=(1<<24)-1 for i in range(len(zeros)))
 assert all((a&b) not in(a,b) for a,b in itertools.combinations(supports,2))
 rec=bounds(supports);assert [x['old_joint'] for x in rec]==row['joint_charge_values']
 families.append({'k':row['k'],'r':row['r'],'supports':supports,'bounds':rec,'old_pass':max(x['old_joint'] for x in rec)<=17,'new_pass':max(x['new_joint'] for x in rec)<=17})
newly=[f for f in families if f['old_pass'] and not f['new_pass']]
assert [(f['k'],f['r']) for f in newly]==[(5,1),(5,2),(5,5)]

ALL=(1<<2048)-1
V=[sum(1<<x for x in range(2048) if x>>v&1) for v in range(11)]+[0,ALL]
F=functools.reduce(int.__or__,(V[a]&V[b] for a,b in E),0)
controls=[]
for family in families:
 supports=family['supports']
 for mode in range(3):
  gates=[];values=list(V);wire_support=[1<<v for v in range(11)]+[0,2047];cones=[set() for _ in range(13)];cache={}
  def add(op,a,b):
   key=(op,min(a,b),max(a,b))
   if mode!=2 and key in cache:return cache[key]
   w=13+len(gates);gates.append((op,a,b));values.append(values[a]&values[b] if op=='and' else values[a]|values[b]);wire_support.append(sum(1<<v for v in range(11) if values[w]>>(1<<v)&1));cones.append(cones[a]|cones[b]|{w});cache[key]=w
   if op=='and':assert wire_support[a] and wire_support[b] and not values[w]&~F
   return w
  def OR(wires):
   wires=sorted(set(wires)) if mode!=2 else list(wires)
   if not wires:return 11
   if len(wires)==1:return wires[0]
   if mode==1:
    mid=len(wires)//2;return add('or',OR(wires[:mid]),OR(wires[mid:]))
   w=wires[0]
   for u in wires[1:]:w=add('or',w,u)
   return w
  edge_wires={e:add('and',a,b) for (a,b),e in zip(E,EM)}
  roots=[]
  for s in supports:
   linear=OR([v for v in range(11) if s>>v&1]);residual=OR([edge_wires[e] for e in EM if not s&e]);root=linear if residual==11 else add('or',linear,residual)
   if mode==2:root=add('or',root,11);root=add('or',root,root)
   roots.append(root);assert wire_support[root]==s and values[root]==F|functools.reduce(int.__or__,(V[v] for v in range(11) if s>>v&1),0)
  assert functools.reduce(int.__and__,(values[w] for w in roots),ALL)==F
  live=set().union(*(cones[w] for w in roots));m=len(live)
  regions=[];boundary_records=[]
  for i,w in enumerate(roots):
   region={g for g in cones[w] if not CN(wire_support[g])};regions.append(region)
   if CN(supports[i]):assert not region;continue
   assert w in region and all(gates[g-13][0]=='or' for g in region)
   boundary=[u for g in region for u in gates[g-13][1:] if u not in region]
   assert len(boundary)<=len(region)+1
   assert all(CN(wire_support[u]) for u in boundary)
   assert functools.reduce(int.__or__,(wire_support[u] for u in boundary),0)==supports[i]
   assert len(region)>=gamma(supports[i])[0]-1
   boundary_records.append({'factor':i,'region':sorted(region),'boundary_occurrences':boundary,'gamma':gamma(supports[i])[0]})
  for a,b in itertools.combinations(range(len(roots)),2):
   if CN(supports[a]&supports[b]):assert regions[a].isdisjoint(cones[roots[b]]) and regions[b].isdisjoint(cones[roots[a]])
   if not CN(supports[a]):assert roots[a] not in cones[roots[b]]
   if not CN(supports[b]):assert roots[b] not in cones[roots[a]]
  for rec in family['bounds']:
   i=rec['i'];outside={w for w in live-cones[roots[i]] if not CN(wire_support[w])}
   assert len(outside)>=rec['B'] and m>=rec['new_joint']
   chosen=set()
   for j in rec['J']:assert not chosen&regions[j];chosen|=regions[j]
   assert chosen<=outside
  controls.append({'supports':supports,'mode':mode,'gates':gates,'roots':roots,'live_gates':m,'regions':boundary_records,'bounds':family['bounds'],'all2048_target_product_verified':True})
assert len(controls)==33
result={'verdict':'S04_DERIVATION_AND_SCALAR_CONTROLS_READY_FOR_INDEPENDENT_MATH_REVIEW','source_sha256':sha(Path(__file__)),'math_sha256':sha(O/'no-common-regions.md'),'producer_examples_sha256':sha(producer),'all2048_gamma_methods_agree':True,'gamma_distribution':dict(collections.Counter(gamma(s)[0] for s in range(2048))),'eligible_noCN_gamma_distribution':dict(collections.Counter(r['gamma'] for r in nocn)),'pureOR_gamma_distribution':dict(collections.Counter(r['gamma'] for r in pure)),'gamma_rows':[{'support':s,'gamma':gamma(s)[0],'owner_mask':gamma(s)[1]} for s in range(2048)],'pureOR_candidates':pure,'support1778_no_two_cover_witnesses':two_cover_obstruction,'eleven_specific_family_controls':families,'newly_excluded_specific_families':newly,'actual_DAG_controls':controls,'seconds':time.monotonic()-START,'solver_run':False,'Lean_build':False,'scope':'New family-dependent joint-cost derivation; three specific old-joint-feasible representative families excluded. No whole r-positive class, compressed-pattern exclusion, emitted CNF or Lean/global claim.'}
(O/'no-common-regions-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['gamma_rows','actual_DAG_controls','eleven_specific_family_controls','pureOR_candidates','support1778_no_two_cover_witnesses']},indent=2))
