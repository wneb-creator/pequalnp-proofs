# No-common-neighbor OR regions and a stronger joint cost

S04 derivation for independent mathematical review. No Lean, solver, CNF cut,
or whole-shard conclusion. The setting is the reviewed productive ambient-clean
binary prefix for the concrete11-vertex graph. Selected factors are distinct
proper full-cover outputs forming a minimal product family of size at least3.
Write S_i for singleton supports, C(S) for common neighbors, and

    L(S) = |S| + |E(G-S)| + cover(G-S) - 1.

Define gamma(S) as the minimum number of open neighborhoods N(v) whose union
contains S. There are no isolated vertices, so gamma is finite. Empty support
has gamma0; a nonempty support with a common neighbor has gamma1; a support
with no common neighbor has gamma at least2.

## 1. No-common-neighbor wires have only OR descendants

Suppose C(S_W) is empty. On any path from W, a first AND would have an
operand A reached through OR gates, hence S_W contained in S_A. Cleanliness
forces the other operand's support into C(S_A), contained in C(S_W). This
contradicts productivity. Therefore every descendant path consists entirely
of OR gates and its support contains S_W. In particular W cannot be an
ancestor of a distinct selected factor: selected supports are incomparable.
It also cannot be an ancestor of any wire whose support has a common neighbor.

This uses syntactic ancestry, including dead/copy paths; it is not a statement
only about semantic relevance. The productivity hypothesis is essential.

## 2. Each such output needs gamma(S)-1 OR gates of this type

For a proper-support output W with C(S_W) empty, let T_W be all gate ancestors
of W, including W, whose supports have no common neighbor. All are OR gates,
and the subgraph they induce is connected toward W: every intermediate gate
on a path from one of them to W is also an OR with no common neighbor.

If t=|T_W|, the t binary OR gates have2t operand occurrences and at least t-1
internal operand occurrences. At most t+1 occurrences enter from outside this
region. The supports of those boundary wires cover exactly S_W. Every such
boundary support has a common neighbor, so lies in one open neighborhood;
an empty boundary support may be assigned any owner. A raw variable also has
a neighbor. TRUE cannot enter this OR region because S_W is proper; FALSE
has empty support. Consequently gamma(S_W)<=t+1, or

    |T_W| >= gamma(S_W)-1.

Repeated operands and shared edges only decrease the number of distinct
boundary wires relative to occurrences and do not weaken the inequality.

## 3. Regions that cannot overlap

If C(S_i intersect S_j) is nonempty, T_i and T_j are disjoint. Indeed a shared
wire's support is contained in both S_i and S_j, because all its descendant
paths are OR-only. A common neighbor of their intersection would therefore
be a common neighbor of this wire, a contradiction.

More generally, if C(S_i intersect S_j) is nonempty, the entire region T_j
lies outside the full ancestor cone of output i, even if i itself has a
common neighbor. Each selected no-common-neighbor output also lies outside
every other selected output's cone, by part1 and support incomparability.

Fix i. Let r be the number of selected factors with no common neighbor, and
z_i=r-1 if i is one of them, otherwise z_i=r. Choose any subset J of the
other no-common-neighbor factors such that

* C(S_i intersect S_j) is nonempty for every j in J;
* C(S_j intersect S_l) is nonempty for every distinct j,l in J.

The regions T_j for j in J are disjoint and outside i's cone. The z_i-|J|
remaining selected no-common-neighbor outputs are also outside that cone and
outside these regions: otherwise one selected output would be an ancestor
of another. Thus at least

    B_i = z_i + sum_(j in J) (gamma(S_j)-2)

no-common-neighbor OR gates lie outside i's ancestor cone. Maximize the sum
over eligible J, including the empty set. With at most five factors this is
a tiny subset calculation. If C(S_i) is nonempty, every no-common-neighbor
j is eligible against i; only the pairwise condition within J remains.

## 4. Combine with the reviewed owner charge, including empty residuals

Let d_i count distinct unique common-neighbor owners belonging to S_i among
the other selected factors. Of these, t_i have an ancestor representative in
the cone of i. The reviewed first-AND argument removes t_i distinct clean
ANDs in addition to the support OR deletions, giving M_i>=L(S_i)+t_i when the
residual graph has an edge. Each remaining owner group has a selected output
outside the cone. Those outputs have common-neighbor supports, so cannot
coincide with any of the B_i no-common-neighbor OR gates. Therefore

    m >= L(S_i) + d_i + B_i.

The same formula holds for an EMPTY residual graph, repairing the explicit
gap in scope of the older joint-cost statement. A proper output with support
S_i needs at least |S_i|-1 OR nodes in its OR-only singleton-support ancestry:
each supported raw variable must be connected to the output by OR-only paths;
a binary merging DAG with |S_i| such sources has at least |S_i|-1 OR nodes.
The t_i identified ANDs are distinct from those ORs. Hence M_i>=|S_i|-1+t_i
=L(S_i)+t_i directly, without a residual-edge theorem or any bypass equality.
The same disjoint outside-cone count finishes. There is no double charge of
ANDs or ORs. Owner distinctness and pair-product dirtiness retain the reviewed
minimal-family hypotheses. Full support remains excluded.

For r and fixed i this yields the explicit bound

    r <= m-L(S_i)-d_i + indicator(C(S_i)=empty)
         - max_J sum_(j in J)(gamma(S_j)-2).

This is a family-dependent bound, not a universal numerical cap on r.

## 5. Concrete graph consequences and limitations

Of the909 eligible no-common-neighbor supports,568 have gamma2 and341 have
gamma3. The24 relevant vertex-cover/pure-OR supports each reject exactly one
maximal independent input;22 have gamma3 despite their low individual costs.
A nonredundant pure-OR full-cover factor has support V minus a maximal
independent set: its complement is independent and must contain a maximal
independent input, hence equal it. Large pure-OR covers therefore still
contribute two no-common-neighbor OR gates to the shared-prefix count when
their gamma is3.

One concrete obstruction is the minimal support family

    [1280,85,1160,584,1778].

Its first four factors have common-neighbor owners4,10,6,7; the last factor
has none. Support1778={1,4,5,6,7,9,10} is a vertex cover and has cost6, but
gamma3 (the neighborhoods of0,3,8 cover it, while no two suffice). For the
distinguished support1160={3,7,10}, L=14 and the two other owners7,10 lie in
it. The older joint bound is14+2+1=17. The new region bound counts at least
two no-common-neighbor OR gates outside that cone, giving14+2+2=18. Thus this
specific17-prefix family is impossible even though the cheap pure-OR factor
passed the previous joint bound. Other concrete examples and all scalar
checks are retained by check_no_common_regions.py.

This argument does not permit dropping support identity when compressing
families solely by their rejected maximal-independent-set rows. Different
supports with the same row pattern can have different gamma, intersection
compatibility and owners. It also does not sum gamma-2 over arbitrary
overlapping regions: the stated disjointness conditions are necessary for
this charge. No blanket exclusion of an r>0 class or circuit construction
is asserted here. New cuts need independent mathematical and encoding review.
