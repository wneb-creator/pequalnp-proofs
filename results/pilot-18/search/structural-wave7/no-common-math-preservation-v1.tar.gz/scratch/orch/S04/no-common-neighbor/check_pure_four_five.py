from pathlib import Path
import functools,hashlib,itertools,json,time
O=Path('/tmp/oec/pequalnp-pilot-18/orch/S04/no-common-neighbor');START=time.process_time();WALL=time.monotonic()
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
EM=[(1<<a)|(1<<b) for a,b in E];N=[sum(1<<(b if a==v else a) for a,b in E if v in(a,b)) for v in range(11)]
ind=[x for x in range(2048) if not any(x&e==e for e in EM)];mis=[x for x in ind if all((x|(1<<v)) not in ind for v in range(11) if not x>>v&1)];ALL=(1<<24)-1
@functools.lru_cache(None)
def tau(edges):
 if not edges:return 0
 return 1+min(tau(tuple(e for e in edges if not e>>v&1)) for v in range(11) if edges[0]>>v&1)
@functools.lru_cache(None)
def gamma(s):
 if not s:return 0
 v=(s&-s).bit_length()-1
 return 1+min(gamma(s&~N[u]) for u in range(11) if N[u]>>v&1)
raw=[]
for s in range(2047):
 if any(s&~n==0 for n in N):continue
 edges=tuple(e for e in EM if not e&s);L=s.bit_count()+len(edges)+tau(edges)-1;z=sum(1<<j for j,x in enumerate(mis) if not x&s)
 if z and L<=14 and gamma(s)==2:raw.append({'support':s,'L':L,'z':z,'gamma':2,'residual_edges':list(edges)})
assert len(mis)==24
class Budget(Exception):pass
def solve(k):
 cap=18-k;groups={}
 for r in raw:
  if r['L']>cap:continue
  z=r['z']
  if z not in groups or (r['L'],r['support'])<(groups[z]['L'],groups[z]['support']):groups[z]=r
 rows=sorted(groups.values(),key=lambda r:(-r['z'].bit_count(),r['L'],r['support']))
 byrow=[[i for i,r in enumerate(rows) if r['z']>>j&1] for j in range(24)]
 seen=set();nodes=0
 def rec(chosen,covered):
  nonlocal nodes
  nodes+=1
  if nodes%64==0 and time.process_time()-START>25:raise Budget
  if covered==ALL:return chosen if len(chosen)==k else None
  if len(chosen)==k:return None
  key=tuple(sorted(chosen))
  if key in seen:return None
  seen.add(key)
  zchosen=[rows[i]['z'] for i in chosen]
  private=[z&~functools.reduce(int.__or__,zchosen[:j]+zchosen[j+1:],0) for j,z in enumerate(zchosen)]
  options=[i for i,r in enumerate(rows) if r['z']&~covered and all(p&~r['z'] for p in private)]
  if functools.reduce(int.__or__,(rows[i]['z'] for i in options),covered)!=ALL:return None
  gains=sorted(((rows[i]['z']&~covered).bit_count() for i in options),reverse=True)
  if sum(gains[:k-len(chosen)])<(ALL&~covered).bit_count():return None
  allowed=set(options);missing=[j for j in range(24) if not covered>>j&1]
  row=min(missing,key=lambda j:sum(i in allowed for i in byrow[j]))
  for i in sorted((i for i in byrow[row] if i in allowed),key=lambda i:(-(rows[i]['z']&~covered).bit_count(),rows[i]['L'],rows[i]['support'])):
   ans=rec(chosen+(i,),covered|rows[i]['z'])
   if ans is not None:return ans
  return None
 try:
  answer=rec((),0);status='EXPLICIT_RELAXATION_WITNESS' if answer is not None else 'NO_GAMMA2_ONLY_COVER'
 except Budget:answer=None;status='UNKNOWN_CPU_CAP'
 result={'k':k,'r':k,'cost_cap':cap,'gamma2_pattern_count':len(rows),'nodes':nodes,'status':status}
 if answer is None:return result
 family=[rows[i] for i in answer];S=[a['support'] for a in family];zs=[a['z'] for a in family]
 assert len(set(S))==k and max(a['L'] for a in family)<=cap
 assert functools.reduce(int.__or__,zs)==ALL
 private=[z&~functools.reduce(int.__or__,zs[:i]+zs[i+1:],0) for i,z in enumerate(zs)];assert all(private)
 assert all((a&b) not in(a,b) for a,b in itertools.combinations(S,2))
 outputs=[]
 for x in range(2048):
  F=any(x&e==e for e in EM);values=[F or bool(x&s) for s in S]
  assert all(values)==F;outputs.append({'input':x,'F':F,'factors':values})
 result.update(family=family,private_MIS=[mis[(z&-z).bit_length()-1] for z in private],joint_and_region_costs=[a['L']+k-1 for a in family],output_positions=list(range(17-k,17)),selected_ancestry='NONE',all2048_truth_rows=outputs)
 return result
results=[solve(k) for k in(4,5)]
out={'verdict':'PURE_FOUR_FIVE_COST_MIS_RELAXATION_CHECK','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'results':results,'cpu_seconds':time.process_time()-START,'wall_seconds':time.monotonic()-WALL,'solver_run':False,'Lean_build':False,'scope':'Explicit exact-support minimal full-cover function families only; cost+MIS+slot+current region relaxations, no shared-prefix circuits. Negative gamma2-only status, if any, would not exclude other gamma supports.'}
(O/'pure-four-five-validation.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({**{k:v for k,v in out.items() if k!='results'},'results':[{k:v for k,v in r.items() if k!='all2048_truth_rows'} for r in results]},indent=2))
