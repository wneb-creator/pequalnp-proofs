from pathlib import Path
import collections,functools,hashlib,itertools,json,time
O=Path('/tmp/oec/pequalnp-pilot-18/orch/S04');I=O.parent/'S01';START=time.monotonic()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
bindings={}
for name,digest in [('no-common-cover-handoff.json','a4f80666a2c3de18353fbc10a24ec0bcf6a035a7b027f31854086baf15aa4a76'),('mixed-triple-handoff.json','159ca97f5b0d24fec9f727e8a58d93648f23cec92b6ef6e323ab7f754b570b8d')]:
 assert sha(I/name)==digest;bindings[name]=digest
 for rec in json.loads((I/name).read_text())['files']:
  p=Path(rec['path']);assert p.is_relative_to(I) and not p.is_symlink() and p.is_file()
  assert sha(p)==rec['sha256'] and p.stat().st_size==rec['bytes'];bindings[p.name]=rec['sha256']
probe=json.loads((I/'no-common-cover-probe.json').read_text());mixed=json.loads((I/'mixed-triple-census.json').read_text());triple=json.loads((I/'no-common-triples-verification.json').read_text())
for d,src in [(probe,'probe_no_common_covers.py'),(mixed,'enumerate_mixed_triples.py'),(triple,'verify_no_common_triples.py')]:assert d['source_sha256']==sha(I/src)
assert mixed['input_sha256']==sha(I/'no-common-cover-probe.json')
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
EM=[(1<<a)|(1<<b) for a,b in E];N=[sum(1<<(b if a==v else a) for a,b in E if v in(a,b)) for v in range(11)]
def cn(s):return sum(1<<v for v in range(11) if s&~N[v]==0)
ind=[s for s in range(2048) if not any(s&e==e for e in EM)]
mis=[s for s in ind if all((s|(1<<v)) not in ind for v in range(11) if not s>>v&1)]
assert len(ind)==125 and len(mis)==24 and mis==probe['MIS']==triple['MIS'];ALL=(1<<24)-1
# Cover calculation by maximum independent submasks of each residual vertex
# set, with a separate edge-branch recursion to check every residual cost.
@functools.lru_cache(None)
def tau(edges):
 if not edges:return 0
 return 1+min(tau(tuple(e for e in edges if not e>>v&1)) for v in range(11) if edges[0]>>v&1)
pool=[]
for s in range(2047):
 rem=2047^s;edges=tuple(e for e in EM if not e&s);alpha=max(x.bit_count() for x in ind if x&~rem==0)
 assert tau(edges)==rem.bit_count()-alpha
 cost=s.bit_count()+len(edges)+tau(edges)-1;z=sum(1<<j for j,x in enumerate(mis) if not x&s);owners=cn(s)
 if cost>17 or not z:continue
 assert s.bit_count()>=2 and owners.bit_count()<=1
 pool.append({'s':s,'cost':cost,'z':z,'empty_cn':not owners,'owner':owners.bit_length()-1 if owners else None,'residual_edges':len(edges)})
assert len(pool)==958
by_support={r['s']:r for r in pool}
groups={}
for r in pool:groups.setdefault((r['z'],r['empty_cn']),[]).append(r)
for rows in groups.values():rows.sort(key=lambda r:(r['cost'],r['s']))
assert len(groups)==382 and len({z for z,e in groups})==382
assert collections.Counter(e for z,e in groups)=={True:339,False:43}
for old in probe['pool']:
 rows=groups[(old['z'],old['empty_cn'])]
 assert old['representatives']==rows and old['representative']==rows[0] and old['cost']==rows[0]['cost']
assert {r['s'] for p in probe['pool'] for r in p['representatives']}==set(by_support)
# No pair of eligible rejection patterns covers all MIS. This makes every
# covering triple minimal and ensures three distinct patterns, allowing a
# different enumeration: pattern triples first, exact supports expanded later.
patterns=sorted(groups)
assert all(a[0]|b[0]!=ALL for a,b in itertools.combinations(patterns,2))
relaxation_witnesses=[]
for case in probe['results']:
 if case['k']==case['r']==3:
  assert case['verdict']=='NO_RELAXED_MINIMAL_COVER' and case['witness'] is None;continue
 assert case['verdict']=='RELAXATION_FEASIBLE'
 rows=case['witness'];k=case['k'];r=case['r']
 assert len(rows)==k and all(by_support[a['s']]==a for a in rows)
 assert sum(a['empty_cn'] for a in rows)==r and all(a['cost']<=17-r+int(a['empty_cn']) for a in rows)
 assert all(v<=c for v,c in zip(sorted(a['cost'] for a in rows),range(18-k,18)))
 zs=[a['z'] for a in rows];assert functools.reduce(int.__or__,zs)==ALL
 assert all(functools.reduce(int.__or__,zs[:i]+zs[i+1:])!=ALL for i in range(k))
 relaxation_witnesses.append({'k':k,'r':r,'supports':[a['s'] for a in rows]})
assert len(relaxation_witnesses)==11

def covering_pattern_triples(items):
 n=len(items);full=(1<<n)-1
 bits=[sum(1<<i for i,(z,_) in enumerate(items) if z>>v&1) for v in range(24)]
 for a in range(n):
  for b in range(a+1,n):
   missing=ALL&~(items[a][0]|items[b][0]);candidates=full^((1<<(b+1))-1)
   # Intersect the rarest missing rows first, unlike the producer's low-bit
   # traversal over958 actual supports.
   requirements=sorted((bits[v] for v in range(24) if missing>>v&1),key=int.bit_count)
   for requirement in requirements:
    candidates&=requirement
    if not candidates:break
   while candidates:
    bit=candidates&-candidates;candidates-=bit
    yield a,b,bit.bit_length()-1

budget_checks=[]
for old in triple['cases']:
 budget=old['budget'];items=sorted((key for key,rs in groups.items() if key[1] and rs[0]['cost']<=budget),key=lambda key:groups[key][0]['s'])
 choices=list(covering_pattern_triples(items))
 assert len(items)==old['pool'] and len(items)*(len(items)-1)//2==old['pairs'] and len(choices)==old['cover_triples']
 budget_checks.append({'budget':budget,'patterns':len(items),'pattern_triples':len(choices)})
assert budget_checks[0]['pattern_triples']==0

relations=[]
for bits in range(8):
 pairs=[(0,1),(0,2),(1,2)];anc=[set() for _ in range(3)]
 for bit,(a,b) in enumerate(pairs):
  if bits>>bit&1:anc[b].add(a)
 if all(anc[j]<=anc[i] for i in range(3) for j in anc[i]):relations.append(anc)
assert len(relations)==7
position_checks=0
def assess(family,ps,anc):
 global position_checks
 position_checks+=1;occupied=set(ps);bounds=[]
 for i in range(3):
  if any(family[j]['empty_cn'] for j in anc[i]):return None
  if any(not any(t not in occupied for t in range(ps[j]+1,ps[i])) for j in anc[i]):return None
  if len(anc[i])>1 and sum(t not in occupied for t in range(ps[min(anc[i])]+1,ps[i]))<len(anc[i]):return None
  outside=set(range(i))-anc[i]
  excluded=int(any(a in anc[b] for a,b in itertools.combinations(sorted(outside),2)))
  upper=ps[i]+1-len(outside)-excluded
  owner_set={family[j]['owner'] for j in anc[i]}
  assert None not in owner_set
  extra=sum(bool(family[i]['s']>>v&1) for v in owner_set) if family[i]['residual_edges'] else 0
  lower=family[i]['cost']+extra
  if lower>upper:return None
  bounds.append([lower,upper])
 return bounds
def find_position(family):
 for ps in itertools.product(*(range(16,a['cost']-2,-1) for a in family)):
  if len(set(ps))<3:continue
  order=sorted(range(3),key=lambda j:ps[j]);ordered=[family[j] for j in order];positions=[ps[j] for j in order]
  for anc in reversed(relations):
   b=assess(ordered,positions,anc)
   if b is not None:return {'order':order,'positions':positions,'ancestry_masks':[sum(1<<j for j in a) for a in anc],'bounds':b}
 return None
def validate_saved(family,witness):
 ps=witness['positions'];order=sorted(range(3),key=lambda j:ps[j]);anc=[{a for a,j in enumerate(order) if witness['ancestry'][j][i]} for i in order]
 assert anc in relations
 b=assess([family[j] for j in order],[ps[j] for j in order],anc)
 assert b==[witness['cone_bounds'][j] for j in order]
@functools.lru_cache(None)
def gamma(s):
 if not s:return 0
 v=(s&-s).bit_length()-1
 return 1+min(gamma(s&~N[u]) for u in range(11) if N[u]>>v&1)
assert [gamma(s) for s in range(2048)]==mixed['gamma']

results=[];total_exact_expansions=0;noCN_occurrences=0;empty_residual_survivors={1:0,2:0,3:0}
for oldcase in mixed['results']:
 r=oldcase['counts']['r'];eligible={key:[a for a in rows if a['cost']<=17-r+int(a['empty_cn'])] for key,rows in groups.items()}
 eligible={key:rows for key,rows in eligible.items() if rows};items=sorted(eligible)
 n=sum(len(rows) for rows in eligible.values());counts=dict(r=r,pool=n,pairs=n*(n-1)//2,covered_triples=0,exact_r=0,minimal=0,slots=0,joint_pass=0,position_pass=0,region_pass=0)
 oldrows={tuple(a['supports']):a for a in oldcase['families']};checked_rows={}
 for triple_ids in covering_pattern_triples(items):
  for chosen in itertools.product(*(eligible[items[j]] for j in triple_ids)):
   counts['covered_triples']+=1;total_exact_expansions+=1
   if sum(a['empty_cn'] for a in chosen)!=r:continue
   counts['exact_r']+=1
   family=sorted(chosen,key=lambda a:a['s']);ss=tuple(a['s'] for a in family)
   assert all((a['s']&b['s']) not in(a['s'],b['s']) for a,b in itertools.combinations(family,2))
   counts['minimal']+=1
   if any(c>cap for c,cap in zip(sorted(a['cost'] for a in family),(15,16,17))):continue
   counts['slots']+=1
   owners={a['owner'] for a in family if a['owner'] is not None}
   joint=[a['cost']+r-int(a['empty_cn'])+sum(bool(a['s']>>v&1) for v in owners) for a in family]
   if any(v>17 and a['residual_edges'] for a,v in zip(family,joint)):continue
   counts['joint_pass']+=1;old=oldrows[ss]
   assert old['individual_costs']==[a['cost'] for a in family] and old['owners']==[a['owner'] for a in family] and old['residual_edges']==[a['residual_edges'] for a in family] and old['joint_costs']==joint
   if old['position_witness'] is not None:validate_saved(family,old['position_witness'])
   found=find_position(family);assert (found is None)==(old['position_witness'] is None)
   counts['position_pass']+=found is not None
   g=[gamma(a['s']) for a in family];assert old['gamma']==g
   region=[]
   for i,a in enumerate(family):
    eligible_J=[j for j,b in enumerate(family) if i!=j and b['empty_cn'] and cn(a['s']&b['s'])]
    extra=max(sum(g[j]-2 for j in J) for nJ in range(len(eligible_J)+1) for J in itertools.combinations(eligible_J,nJ) if all(cn(family[u]['s']&family[v]['s']) for u,v in itertools.combinations(J,2)))
    region.append(joint[i]+extra)
   assert region==old['region_costs'] and (max(region)<=17)==old['region_pass']
   counts['region_pass']+=found is not None and max(region)<=17
   if found:
    assert all(g[i]==2 for i,a in enumerate(family) if a['empty_cn'])
    noCN_occurrences+=sum(a['empty_cn'] for a in family)
    empty_residual_survivors[r]+=any(not a['residual_edges'] for a in family)
   checked_rows[ss]={'supports':ss,'position_pass':found is not None,'independent_witness':found,'joint_costs':joint,'region_costs':region}
 assert counts==oldcase['counts'] and set(checked_rows)==set(oldrows),(counts,oldcase['counts'])
 results.append({'counts':counts,'families':[checked_rows[s] for s in sorted(checked_rows)]})
 print(json.dumps(counts),flush=True)
 assert time.monotonic()-START<50
assert noCN_occurrences==936 and empty_residual_survivors=={1:3,2:0,3:0}
result={'verdict':'PASS_NO_COMMON_TRIPLE_EXCLUSION_AND_COMPLETE_MIXED_EXACT_SUPPORT_CENSUS','source_sha256':sha(Path(__file__)),'producer_bindings':bindings,'eligible_supports':958,'compressed_patterns':382,'noCN_patterns':339,'CN_patterns':43,'no_eligible_pattern_pair_covers_all_MIS':True,'eleven_relaxation_witnesses':relaxation_witnesses,'independent_noCN_triple_budget_checks':budget_checks,'pattern_first_exact_support_expansions':total_exact_expansions,'position_assignments_checked':position_checks,'results':results,'surviving_noCN_occurrences_all_gamma2':noCN_occurrences,'edgeless_residual_surviving_family_counts':empty_residual_survivors,'seconds':time.monotonic()-START,'solver_run':False,'Lean_build':False,'scope':'k3/r3 minimal proper full-cover no-CN class excluded in17-gate productive clean prefixes; exact r1 leaves800 and r2 leaves68 abstract support/position patterns. Other k/r probes provide witnesses only. Proposed S04 region/empty-residual column reproduces no additional mixed exclusions and is unnecessary to these counts. No circuit realization, actual cut, whole AAAA/shard or Lean/global claim.'}
(O/'mixed-triple-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['results','producer_bindings']},indent=2))
