#!/usr/bin/env python3
"""Finite hypotheses/aggregation for a new simultaneous birth-count lemma."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
parent=ROOT/'two-sink-tight-cones-v2.json'
data=json.loads(parent.read_text())
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
   (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
N=[sum(1<<(v if u==x else u) for u,v in E if x in(u,v)) for x in range(11)]
def cn(s):return [v for v,n in enumerate(N) if n&s==s]
records=[]
for row in data['families']:
    if row['excluded']:continue
    S=row['supports'];L=row['individual_costs'];c=row['common_output']
    assert len(S)==3 and all(s.bit_count()>=2 and s!=2047 for s in S)
    assert L[c]>=14 and cn(S[c])
    assert all(not cn(s) for i,s in enumerate(S) if i!=c)
    H=[e for e in E if any(not s&((1<<e[0])|(1<<e[1])) for s in S)]
    forbidden=[]
    for i,s in enumerate(S):
        for u in cn(s):
            for v in range(11):
                if s>>v&1:
                    e=tuple(sorted((u,v)))
                    assert e in E
                    if e in H:forbidden.append(dict(output=i,edge=e))
    strict_available=not forbidden
    bound=len(H)+3+int(strict_available)
    assert len(H)>=14 and bound>17
    records.append(dict(supports=S,individual_costs=L,common_output=c,
        common_owner=cn(S[c])[0],forced_birth_edges=H,forced_birth_count=len(H),
        terminal_support_births_in_H=forbidden,strict_lemma_available=strict_available,
        prefix_gate_lower_bound=bound,excluded=True,
        reason='BASIC_CORE_BIRTH_COUNT' if len(H)>14 else 'STRICT_TERMINAL_BIRTH_COUNT'))
assert len(records)==18
old={tuple(r['supports']) for r in data['families'] if r['excluded']}
new={tuple(r['supports']) for r in records}
assert len(old)==50 and not old&new
assert old|new=={tuple(r['supports']) for r in data['families']}
out=dict(verdict='ALL68_K3_R2_PROPOSED_MATH_EXCLUSION_PENDING_INDEPENDENT_REVIEW',
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    input_sha256=hashlib.sha256(parent.read_bytes()).hexdigest(),
    math_sha256=hashlib.sha256((ROOT/'forced-birth-terminal-bound.md').read_bytes()).hexdigest(),
    prior_excluded=50,basic_birth_count_excluded=sum(r['reason']=='BASIC_CORE_BIRTH_COUNT' for r in records),
    strict_birth_count_excluded=sum(r['reason']=='STRICT_TERMINAL_BIRTH_COUNT' for r in records),
    total_excluded=68,remaining=0,families=records,solver_run=False,Lean_proof=False,
    scope='Only complete supplied k3/r2 family census plus its prior reviewed-hypothesis pipeline, pending independent review of new structural proofs and census. No global shard claim.')
(ROOT/'forced-birth-terminal-bound.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ('verdict','prior_excluded','basic_birth_count_excluded','strict_birth_count_excluded','total_excluded','remaining','source_sha256','input_sha256','math_sha256')}))
