# Forced births and terminal support signals

New mathematical lemma for immediate independent review. Its counting engine
is the existing Lean edge_finset_gate_bound_partial (current named file
lines615-666), or equivalently edge_finset_gate_bound applied to the graph of
all births. No new SAT, Lean theorem or whole-shard result is asserted here.

## Setting

Take a productive clean binary AND/OR prefix with m gates in C4-free ambient G.
Its k selected outputs are proper full-cover factors with singleton supports
S_1,...,S_k of size at least two. Assume these selected outputs form a syntactic
ancestry antichain. Each is OR because clean ANDs have empty singleton support.

Prune gates not ancestral to any selected output. The k selected outputs are
now terminal gates. Delete just those output gates to leave the core; it has
at most m-k gates and retains every AND and its complete operand computations.
Free TRUE cannot occur in this pruned prefix: its support has no common neighbor,
so productivity forces all its descendant paths to be OR-only, contradicting
the proper support of each selected descendant. Raw inputs and free FALSE have
supports of size at most one, exactly the input premise of the counting helper.

Let H be the subgraph consisting of ambient edges missed by at least one
selected singleton support:

    uv in H iff uv in G and there exists i with u,v outside S_i.

Such an edge is accepted by output i despite neither endpoint lying in its
singleton support. The existing edge_birth argument supplies an AND on its
ancestor path at which the endpoints occur in opposite operand supports.
That AND is in the core. Hence H is contained in the core birth graph B,
the union of the cross-support edge sets of all core AND gates.

The existing counting helper applied to B gives

    |E(H)| <= |E(B)| <= (#core ANDs)+(#core ORs with support size>1)
                          <= #core gates <= m-k.                 (1)

This is a simultaneous-output statement, not a separate per-output cost.
It requires no exact function for any single core signal and no new bound
on the number of ANDs. Repeated operands, shared edges and dead gates are
already covered by the cited count and the initial pruning.

## Equality cannot hold when terminal supports cannot help birth H

Assume in addition that for every selected support S_i,

    for every u common to all neighborhoods of vertices in S_i,
    and every v in S_i, the edge uv does NOT belong to H.           (2)

This condition is vacuous when S_i has no common neighbor. If |E(H)|=m-k,
all inequalities in(1) are equalities: the core has exactly m-k gates,
B=H, and no slack exists in the gate count.

First, every core gate must be an ancestor of some AND, counting an AND as
its own ancestor. Otherwise retain only the ancestor union of all AND gates.
This removes at least that gate, keeps every AND with unchanged operands and
supports, and keeps B=H. Applying the same birth-count helper to this smaller
core gives |E(H)|<=m-k-1, a contradiction. This pruning does not use or retain
the selected output equations; the birth-count helper needs only the core
support recurrence and cross-support birth cover, all preserved.

Second, no core signal can have support exactly S_i. If it did, its path to
some AND has a first AND q, with only OR gates before q. One operand support
contains S_i. The other operand is nonempty by productivity and contained in
the common-neighbor set of S_i. If that set is empty, this is immediately
impossible. Otherwise choose u in the other operand and v in S_i. Gate q births
edge uv, which is outside H by(2), contradicting B=H.

Finally choose the chronologically last core gate q. By the first observation
it must itself be AND. Since the original pruned prefix was ancestral to its
selected outputs, q must directly feed one of those terminal OR outputs W_i:
there is no later core gate, and selected outputs cannot be intermediates.
The clean AND q has empty singleton support. Thus the other OR operand of W_i
has support exactly S_i. Since |S_i|>=2, it is a gate rather than a raw input
or constant; it is a core gate because the selected outputs are unrelated.
This contradicts the second observation.

Therefore under(2) the simultaneous bound is strict:

    m >= |E(H)|+k+1.                                             (3)

The lemma does not use a minimum-size circuit assumption. It proves an actual
gate lower bound for every prefix satisfying the stated hypotheses.

## Application to the remaining18 two-sink families

All18 have one common-neighbor output with individual cost at least14 and
two no-CN outputs. The previously supplied three-new-gates lemma makes all
three selected outputs an ancestry antichain in17 gates. Their supports all
have size at least two, and k=3.

Family [384,592,1034] has |E(H)|=16, contradicting(1)'s limit14 immediately.
Each other family has |E(H)|=14. Its only nonvacuous instance of(2) comes from
the common-neighbor support S_C. That support has a unique owner u, and u
belongs to both other selected supports. Every edge uv with v in S_C meets
all three selected supports: it meets S_C at v and the others at u. Therefore
it is outside H. Condition(2) holds and(3) requires14+3+1=18 gates.

This excludes all18 survivors of the previous50-of68 proposal. Combined,
the proposed mathematical classification excludes all68 k3/r2 families.
The finite script checks every support/owner/cost/ancestry-criterion and H
count, retains all forced edges and exceptions, and verifies exact set union
with the prior50 exclusions. The earlier independently complete mixed census
must also be reviewed before treating this as a complete k3/r2 case result.
No claim here covers k3/r1, k4/r>0, or the entire assigned shard.
