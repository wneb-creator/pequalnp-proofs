from pathlib import Path
import datetime,functools,hashlib,itertools,json,time
O=Path('/tmp/oec/pequalnp-pilot-18/orch/S04');I=O.parent/'S01';R=Path('/workspace/pequalnp-proofs');start=time.monotonic()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pins={'forced-birth-terminal-bound.md':'ce4af7f97ca5ac57c10f10d85467daa6f9e9e33ec79a66f461769dfbc55c980a','check_forced_birth_terminal_bound.py':'a836ed755b33d7325a29036581c66138de2fe57fc7d4f6cff445617a7f48d19f','forced-birth-terminal-bound.json':'b5757c889fd7c426ba3a24b472043cf87d60104230c01db61dd514d431ae06f1','forced-birth-reviewed17-binding.json':'d22bbe8235e2867ae32a9b4af6b2d9eea2eee88f8eb4a9078ee2dd30c98e4aad','two-sink-tight-cones-v2.json':'65280e9f54b25efc6233895363975bb45737dc91ebbfacf501f69ba2d2e3bb10'}
for n,h in pins.items():assert sha(I/n)==h
forest=json.loads((O/'forest-sinks-review.json').read_text());assert sha(O/'forest-sinks-review.json')=='b57049af7a3c7e56f8bf964357e9ef5451876dd98483589be529be22599dad8c'
birth=json.loads((I/'forced-birth-terminal-bound.json').read_text());binding=json.loads((I/'forced-birth-reviewed17-binding.json').read_text());v2=json.loads((I/'two-sink-tight-cones-v2.json').read_text())
assert birth['source_sha256']==pins['check_forced_birth_terminal_bound.py'] and birth['math_sha256']==pins['forced-birth-terminal-bound.md'] and birth['input_sha256']==pins['two-sink-tight-cones-v2.json']
assert binding['input_review_sha256']==sha(O/'forest-sinks-review.json') and binding['birth_result_sha256']==pins['forced-birth-terminal-bound.json'] and binding['math_sha256']==pins['forced-birth-terminal-bound.md']
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)];edge_masks=[(1<<u)|(1<<v) for u,v in E]
N=[{v if u==x else u for u,v in E if x in (u,v)} for x in range(11)]
assert all(len(N[u]&N[v])<=1 for u,v in itertools.combinations(range(11),2))
def vertices(s,n=11):return {v for v in range(n) if s>>v&1}
def common(s):return sorted(set.intersection(*(N[v] for v in vertices(s))))
@functools.lru_cache(None)
def cost(s):
 h=[e for e in edge_masks if not e&s]
 t=min(x.bit_count() for x in range(2048) if all(x&e for e in h))
 return s.bit_count()+len(h)+t-1
F=[any(x&e==e for e in edge_masks) for x in range(2048)]
results=[];truth_checks=0
assert len(birth['families'])==18
assert {tuple(r['supports']) for r in birth['families']}=={tuple(r['supports']) for r in v2['families'] if not r['excluded']}
for old in birth['families']:
 S=old['supports'];sets=[vertices(s) for s in S];C=[common(s) for s in S];L=[cost(s) for s in S]
 assert L==old['individual_costs']
 assert all(2<=len(t)<11 for t in sets)
 c=next(i for i,u in enumerate(C) if u);assert c==old['common_output'] and len(C[c])==1 and all(not C[i] for i in range(3) if i!=c) and L[c]>=14
 assert all(not sets[i]<=sets[j] for i,j in itertools.permutations(range(3),2))
 H={e for e in E if any(set(e).isdisjoint(s) for s in sets)}
 forbidden=[{'output':i,'edge':list(sorted((u,v)))} for i in range(3) for u in C[i] for v in sorted(sets[i]) if tuple(sorted((u,v))) in H]
 strict=bool(H) and not forbidden
 assert [list(e) for e in sorted(H)]==old['forced_birth_edges'] and len(H)==old['forced_birth_count']
 assert forbidden==old['terminal_support_births_in_H'] and strict==old['strict_lemma_available']
 lower=len(H)+3+int(strict);assert lower==old['prefix_gate_lower_bound'] and lower>17
 if strict:assert all(C[c][0] in sets[i] for i in range(3) if i!=c)
 funcs=[[F[x] or bool(x&s) for x in range(2048)] for s in S]
 private=[]
 for i in range(3):
  witnesses=[x for x in range(2048) if not F[x] and all(funcs[j][x] for j in range(3) if j!=i)]
  assert witnesses;private.append(witnesses[0])
 assert all(all(f[x] for f in funcs)==F[x] for x in range(2048));truth_checks+=2048
 results.append({'supports':S,'costs':L,'forced_edges':sorted(H),'condition2':not forbidden,'nonempty_H':bool(H),'prefix_lower_bound':lower,'private_negative_inputs':private})
old50={tuple(r['supports']) for r in v2['families'] if r['excluded']};all68={tuple(r['supports']) for r in v2['families']};new18={tuple(r['supports']) for r in results}
assert len(old50)==50 and not old50&new18 and old50|new18==all68 and len(all68)==68
remaining17={tuple(s) for s in forest['remaining_k3_r2']};assert remaining17==new18-{(276,518,1056)}
assert {tuple(r['supports']) for r in binding['families']}==remaining17
birthmap={tuple(r['supports']):r for r in birth['families']}
assert all(r==birthmap[tuple(r['supports'])] for r in binding['families'])
assert sum(birthmap[s]['forced_birth_count']==16 for s in remaining17)==1 and sum(birthmap[s]['forced_birth_count']==14 for s in remaining17)==16
assert set(tuple(r['supports']) for r in forest['sink_records'])==all68

# Literal small-DAG controls: general empty-core counterexample and sharp
# repaired-lemma example. Gates use n raw inputs, then binary AND/OR gates.
def control(n,edges,gates,outputs):
 es={tuple(sorted(e)) for e in edges};adj=[{v if u==x else u for u,v in es if x in (u,v)} for x in range(n)]
 vals=[[bool(x>>v&1) for x in range(1<<n)] for v in range(n)]
 supports=[{v} for v in range(n)];anc=[set() for _ in range(n)]
 target=[any(x>>u&1 and x>>v&1 for u,v in es) for x in range(1<<n)];births=set()
 for j,(op,a,b) in enumerate(gates):
  w=n+j;assert a<w and b<w
  vals.append([vals[a][x] and vals[b][x] if op=='and' else vals[a][x] or vals[b][x] for x in range(1<<n)])
  s={v for v in range(n) if vals[w][1<<v]};supports.append(s);anc.append({w}|anc[a]|anc[b])
  if op=='and':
   assert supports[a] and supports[b] and not s
   assert all(not vals[w][x] for x in range(1<<n) if not target[x])
   births|={tuple(sorted((u,v))) for u in supports[a] for v in supports[b]}
 assert births<=es
 ss=[supports[w] for w in outputs];assert all(2<=len(s)<n for s in ss)
 assert all(all(not target[x] or vals[w][x] for x in range(1<<n)) for w in outputs)
 assert all(a not in anc[b] for a,b in itertools.permutations(outputs,2))
 live=set.union(*(anc[w] for w in outputs));core=live-set(outputs)
 assert live==set(range(n,n+len(gates)))
 H={e for e in es if any(set(e).isdisjoint(s) for s in ss)}
 cn=[set.intersection(*(adj[v] for v in s)) for s in ss]
 cond=all(tuple(sorted((u,v))) not in H for s,c in zip(ss,cn) for u in c for v in s)
 assert H<=births
 helper_count=sum(op=='and' or len(supports[n+j])>1 for j,(op,a,b) in enumerate(gates) if n+j in core)
 assert len(births)<=helper_count<=len(core)
 return {'n':n,'edges':sorted(es),'gates':gates,'outputs':outputs,'supports':[sorted(s) for s in ss],'truth_rows':[[int(t)]+[int(vals[w][x]) for w in outputs] for x,t in enumerate(target)],'m':len(gates),'k':len(outputs),'core':sorted(core),'H':sorted(H),'birth_graph':sorted(births),'condition2':cond,'unrepaired_strict_bound_holds':len(gates)>=len(H)+len(outputs)+1}
triangle=control(3,[(0,1),(0,2),(1,2)],[('or',0,1),('or',0,2),('or',1,2)],[3,4,5])
assert not triangle['H'] and not triangle['core'] and triangle['condition2'] and not triangle['unrepaired_strict_bound_holds']
assert all(bool(row[0])==all(row[1:]) for row in triangle['truth_rows'])
sharp=control(4,[(0,1),(2,3)],[('or',0,1),('and',2,3),('or',4,5)],[6])
assert len(sharp['H'])==1 and sharp['condition2'] and sharp['m']==len(sharp['H'])+sharp['k']+1
lean=R/'lean/PEqualNP/Outside/L_meta_1342.lean';txt=lean.read_text();a=txt.index('theorem edge_finset_gate_bound (');b=txt.index('theorem total_from_model_partial',a);snippet=txt[a:b]
assert 'hcover' in snippet and 'hsmall' in snippet and 'hside' in snippet
(O/'birth-count-helper-readonly-snapshot.txt').write_text(snippet)
out={'verdict':'PASS_K3_R2_ALL68_CLOSURE_WITH_NONEMPTY_H_GUARD','timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':sha(Path(__file__)),'producer_bindings':pins,'prior_review_sha256':sha(O/'forest-sinks-review.json'),'all18_applications':results,'reviewed17_families':[list(s) for s in sorted(remaining17)],'new_basic_excluded':1,'new_strict_excluded':16,'prior_excluded':51,'total_excluded':68,'remaining':0,'full_truth_rows':truth_checks,'generic_statement_correction':'Original strict lemma is false for empty core/H: require |E(H)|>0, or separately nonempty core. All reviewed applications have14/16 forced edges.','empty_core_countermodel':triangle,'sharp_nonempty_control':sharp,'helper_snapshot_sha256':sha(O/'birth-count-helper-readonly-snapshot.txt'),'named_lean_readonly_sha256':sha(lean),'seconds':time.monotonic()-start,'solver_run':False,'Lean_build':False,'scope':'Only independently reviewed complete k3/r2 census for minimal proper full-cover selected factors of17-gate productive clean prefix; generic birth bound requires ancestry antichain and nonempty H for strict bonus. No actual CNF, Lean or whole-shard claim.'}
(O/'forced-birth-review.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['producer_bindings','all18_applications','empty_core_countermodel','sharp_nonempty_control']},indent=2))
