from pathlib import Path
import datetime,hashlib,json,shutil,tarfile
O=Path('/tmp/oec/pequalnp-pilot-18/orch/S04');I=O.parent/'S01';S=O.parents[1];R=Path('/workspace/pequalnp-proofs');ROOT=O/'forced-birth-math-preservation-v1';assert not ROOT.exists();ROOT.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):p.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
files={}
def take(p,digest=None):
 p=Path(p);assert p.is_file() and not p.is_symlink() and p.suffix not in ('.cnf','.drat','.lrat','.pyc')
 if digest:assert sha(p)==digest
 rel=Path('scratch')/p.relative_to(S) if p.is_relative_to(S) else Path('repo')/p.relative_to(R)
 dest=ROOT/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
 files[str(rel)]={'source':str(p),'sha256':sha(dest),'bytes':dest.stat().st_size}
review=json.loads((O/'forced-birth-review.json').read_text());assert sha(O/'forced-birth-review.json')=='8ccc9ad77b0a23d8c91c7141cf7627e26b2f0d64589a994cd35a21f1f26fa500'
for n,h in review['producer_bindings'].items():take(I/n,h)
for n in ['forced-birth-terminal-bound.stdout.txt','forced-birth-terminal-bound.stderr.txt','two-sink-tight-cones-v2.md','two-sink-partial-twins.md','mixed-triple-handoff.json','mixed-triple-census.json']:take(I/n)
for n in ['review_forced_birth.py','forced-birth-review.json','forced-birth-review.stdout.log','forced-birth-review.stderr.log','forced-birth-math-review.md','birth-count-helper-readonly-snapshot.txt','forest-sinks-review.json','forest-sinks-math-review.md','mixed-triple-review.json','preserve_forced_birth_review.py','forest-sinks-math-preservation-handoff.json','no-common-math-preservation-handoff.json']:take(O/n)
report=R/'results/orch/lemmas/S04-redteam.md'
with report.open('a') as f:f.write('\n\n'+(O/'forced-birth-math-review.md').read_text())
take(report)
(ROOT/'README.md').write_text('''# Guarded forced-birth mathematics review

Mathematical/finite PASS for the exact remaining17 mixed k3/r2 families:
ONE basic H=16 bound19 and SIXTEEN strict H=14 bound18. Earlier51+17=68;
the full mixed-r2 class under the reviewed17-gate productive-clean-prefix
normalization is excluded. No actual CNF cut, Lean theorem or global claim.

IMPORTANT CORRECTION: the retained original producer general strict lemma
omits a necessary guard. Require H nonempty (or nonempty retained core).
A literal triangle/three-OR countermodel is included in the reviewer result.
All applications have14 or16 forced edges and satisfy the corrected guard.
The original producer files are preserved exactly, not silently repaired.
The independent reviewer proof explains the correction and actual Lean-helper
interface, including removal of unused TRUE before applying hsmall.

Complete finite rows, source, full stdout/stderr, countermodel, sharp positive
control and read-only helper snapshot are retained. The companion forest-sinks
and no-common archives contain full predecessor producer/reviewer provenance;
their exact handoffs are bound here. No original named Lean file was changed
or rebuilt. Scripts retain original filesystem assumptions. Extract anywhere
and run python verify_manifest.py to verify all payloads.
''')
shutil.copyfile(O/'forest-sinks-math-preservation-v1/verify_manifest.py',ROOT/'verify_manifest.py')
for n in ['README.md','verify_manifest.py']:files[n]={'source':'generated/copied by preserve_forced_birth_review.py','sha256':sha(ROOT/n),'bytes':(ROOT/n).stat().st_size}
scope='Guarded forced-birth proof and finite review closes17remaining/68total k3r2 families; original generic lemma needsHnonempty, explicitcountermodel retained. No CNF/Lean/global claim.'
write(ROOT/'manifest.json',{'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':scope,'files':files,'review_sha256':sha(O/'forced-birth-review.json'),'raw_cnfs':0})
archive=O/(ROOT.name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as tf:
 for p in sorted(ROOT.rglob('*')):
  if p.is_file():tf.add(p,arcname=p.relative_to(ROOT),recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 members=tf.getmembers();assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
 assert set(m.name for m in members)==set(files)|{'manifest.json'}
 for m in members:
  data=tf.extractfile(m).read();assert data==(ROOT/m.name).read_bytes()
  if m.name!='manifest.json':assert len(data)==files[m.name]['bytes'] and hashlib.sha256(data).hexdigest()==files[m.name]['sha256']
handoff={'verdict':'PASS_GUARDED_FORCED_BIRTH_REVIEW_PRESERVATION','archive':str(archive),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'regular_members':len(members),'manifest_sha256':sha(ROOT/'manifest.json'),'review_sha256':sha(O/'forced-birth-review.json'),'scope':scope}
write(O/'forced-birth-math-preservation-handoff.json',handoff)
print(json.dumps(handoff,indent=2))
