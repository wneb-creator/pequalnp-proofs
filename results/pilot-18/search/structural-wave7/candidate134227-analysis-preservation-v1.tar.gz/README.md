# S04 scalar candidate analysis preserved after routing correction

Only the work performed before the S04/S05 routing correction is here.
No repair search or solver run by S04. Immutable134227 best1 and best3 sources,
full4096 truth rows, pruned copies and repeated-expression elimination are
included with exact source hashes and full stdout/stderr.

best1 is F OR x9:20live gates,19 after merging duplicate8 OR9,22fullFP.
best3 is F with edge(2,5) deleted:20live clean gates,24fullFN and0FP.
These are INEXACT candidates. S05 owns subsequent repair/algebra work and has
independently checked these inputs; no duplicate repair search is claimed.
No exact21 witness, production change or Lean theorem.
