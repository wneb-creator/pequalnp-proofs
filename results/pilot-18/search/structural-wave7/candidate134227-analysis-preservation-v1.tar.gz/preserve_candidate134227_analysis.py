from pathlib import Path
import datetime,hashlib,json,shutil,tarfile
O=Path(__file__).resolve().parent;D=O/'candidate134227-analysis-preservation-v1';assert not D.exists();D.mkdir();files={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for p in sorted((O/'candidate-134227').glob('*.json'))+[O/n for n in ['analyze_134227.py','candidate-134227-analysis.stdout.log','candidate-134227-analysis.stderr.log','preserve_candidate134227_analysis.py']]:
 r=p.relative_to(O);t=D/r;t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,t);files[str(r)]={'source':str(p),'sha256':sha(t),'bytes':t.stat().st_size}
(D/'README.md').write_text('''# S04 scalar candidate analysis preserved after routing correction

Only the work performed before the S04/S05 routing correction is here.
No repair search or solver run by S04. Immutable134227 best1 and best3 sources,
full4096 truth rows, pruned copies and repeated-expression elimination are
included with exact source hashes and full stdout/stderr.

best1 is F OR x9:20live gates,19 after merging duplicate8 OR9,22fullFP.
best3 is F with edge(2,5) deleted:20live clean gates,24fullFN and0FP.
These are INEXACT candidates. S05 owns subsequent repair/algebra work and has
independently checked these inputs; no duplicate repair search is claimed.
No exact21 witness, production change or Lean theorem.
''')
files['README.md']={'source':'generated','sha256':sha(D/'README.md'),'bytes':(D/'README.md').stat().st_size}
(D/'manifest.json').write_text(json.dumps({'scope':'Historical scalar analysis only; routing restored to S04 math review.','files':files},indent=2,sort_keys=True)+'\n')
p=O/(D.name+'.tar.gz')
with tarfile.open(p,'w:gz') as tf:
 for f in sorted(D.rglob('*')):
  if f.is_file():tf.add(f,arcname=f.relative_to(D),recursive=False)
with tarfile.open(p,'r:gz') as tf:
 members=tf.getmembers();assert all(m.isfile() for m in members)
 assert {m.name for m in members}==set(files)|{'manifest.json'}
 for m in members:assert tf.extractfile(m).read()==(D/m.name).read_bytes()
handoff={'archive':str(p),'archive_sha256':sha(p),'bytes':p.stat().st_size,'members':len(members),'manifest_sha256':sha(D/'manifest.json'),'scope':'Historical scalar/pruning analysis; inexact candidates, no repair search, no Lean/global claim.'}
(O/'candidate134227-analysis-preservation-handoff.json').write_text(json.dumps(handoff,indent=2)+'\n');print(json.dumps(handoff,indent=2))
