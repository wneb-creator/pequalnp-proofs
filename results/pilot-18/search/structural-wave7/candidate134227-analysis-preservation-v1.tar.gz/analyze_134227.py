from pathlib import Path
import hashlib,json,time
BASE=Path('/tmp/oec/pequalnp-pilot-18');O=BASE/'orch/S04/candidate-134227';O.mkdir(exist_ok=True)
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):assert not p.exists();p.write_text(json.dumps(d,indent=2)+'\n')
def evaluate(d,x):
 v=[bool(x>>j&1) for j in range(11)]+[False,True]
 for op,a,b in d['gates']:v.append(v[a] and v[b] if op=='and' else v[a] or v[b])
 return v
summary=[]
for tag,pin in [('best-1','cc8551df6010fbcf8a1104919af06633d44a92063c4dba5d5d0598e07a22aa11'),('best-3','694cbc0206a00aecbd5ac6193158f21557213fa666c6b5b6b4b7ee826affba88')]:
 p=BASE/'triangle589-candidate-134227'/('engine-result.json.'+tag+'.json');assert sha(p)==pin
 d=json.loads(p.read_text());(O/(tag+'-source.json')).write_bytes(p.read_bytes())
 live=set()
 def visit(w):
  if w<13 or w in live:return
  live.add(w);_,a,b=d['gates'][w-13];visit(a);visit(b)
 visit(d['output']);assert len(live)==20
 remap={w:w for w in range(13)};gates=[]
 for w in sorted(live):
  op,a,b=d['gates'][w-13];remap[w]=13+len(gates);gates.append([op,remap[a],remap[b]])
 pruned={'inputs':11,'gate_wire_offset':13,'gates':gates,'size':len(gates),'output':remap[d['output']],'source_sha256':pin,'candidate_only':True}
 write(O/(tag+'-pruned20.json'),pruned)
 shared={w:w for w in range(13)};cache={};gg=[]
 for w in sorted(live):
  op,a,b=d['gates'][w-13];a,b=sorted((shared[a],shared[b]));key=(op,a,b)
  if a==b:shared[w]=a
  else:
   if key not in cache:cache[key]=13+len(gg);gg.append(list(key))
   shared[w]=cache[key]
 compact={'inputs':11,'gate_wire_offset':13,'gates':gg,'size':len(gg),'output':shared[d['output']],'source_sha256':pin,'candidate_only':True}
 write(O/(tag+'-common-subexpressions.json'),compact)
 rows=[];fn=[];fp=[];junk=set()
 for x in range(2048):
  v=evaluate(d,x);got=v[d['output']];F=any(x>>a&1 and x>>b&1 for a,b in E)
  expected=F or bool(x>>9&1) if tag=='best-1' else any(x>>a&1 and x>>b&1 for a,b in E if (a,b)!=(2,5))
  assert got==expected==evaluate(pruned,x)[pruned['output']]==evaluate(compact,x)[compact['output']]
  if got and not F:fp.append(x)
  if F and not got:fn.append(x)
  if not F:
   junk.update(g for g,(op,a,b) in enumerate(d['gates']) if op=='and' and v[13+g])
  rows.append({'input':x,'F':F,'candidate':got})
 rec={'tag':tag,'source_sha256':pin,'pruned20_sha256':sha(O/(tag+'-pruned20.json')),'compact_sha256':sha(O/(tag+'-common-subexpressions.json')),'compact_gate_count':len(gg),'live_gate_indices':sorted(w-13 for w in live),'dead_gate_indices':sorted(set(range(21))-{w-13 for w in live}),'live_junk':sorted(g for g in junk if 13+g in live),'full_false_negatives':fn,'full_false_positives':fp,'missing_edge_inputs':[e for e in E if (1<<e[0])|(1<<e[1]) in fn],'exact_function':'F OR x9' if tag=='best-1' else 'F with edge (2,5) deleted','all2048_rows':rows}
 write(O/(tag+'-analysis.json'),rec)
 summary.append({k:v for k,v in rec.items() if k!='all2048_rows'})
result={'source_sha256':sha(Path(__file__)),'summaries':summary,'scope':'Exact scalar function analysis and reversible prune/common-subexpression copies only. Inexact candidates, no witness/Lean/production claim.'}
write(O/'analysis-handoff.json',result);print(json.dumps(result,indent=2))
