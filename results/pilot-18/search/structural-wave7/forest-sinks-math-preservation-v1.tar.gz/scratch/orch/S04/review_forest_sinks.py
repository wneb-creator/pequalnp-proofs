from pathlib import Path
import collections,functools,hashlib,itertools,json,time
O=Path('/tmp/oec/pequalnp-pilot-18/orch/S04');I=O.parent/'S01';START=time.monotonic()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
bindings={}
for name,digest in [('two-spare-forest-handoff.json','5bcf4d6d1127b8a631b248073a6ce3b2bb9d51fa97e2aa4e4cd046aa6e7bb36a'),('two-sink-tight-cones-handoff.json','f65472630427ffe7a39f382696263708102eed3b5a0f880ae3586260f812b4e3'),('two-sink-v2-handoff.json','453ca7d9720bccaf8edfc681ed8308c7becd1a2e20f324a967f3ed7ff72ea984')]:
 assert sha(I/name)==digest;bindings[name]=digest
 for r in json.loads((I/name).read_text())['files']:
  p=Path(r['path']);assert p.is_relative_to(I) and p.is_file() and not p.is_symlink()
  assert sha(p)==r['sha256'] and p.stat().st_size==r['bytes'];bindings[p.name]=r['sha256']
forest=json.loads((I/'two-spare-forest-filter.json').read_text());v1=json.loads((I/'two-sink-tight-cones.json').read_text());v2=json.loads((I/'two-sink-tight-cones-v2.json').read_text());twins=json.loads((I/'two-sink-partial-twins.json').read_text())
for d,source,math in [(forest,'filter_two_spare_forests.py','two-spare-forest-filter.md'),(v1,'filter_two_sink_tight_cones.py','two-sink-tight-cones.md'),(v2,'filter_two_sink_tight_cones_v2.py','two-sink-tight-cones-v2.md'),(twins,'check_two_sink_partial_twins.py','two-sink-partial-twins.md')]:
 assert d['source_sha256']==sha(I/source) and d['math_sha256']==sha(I/math)
 bindings[source]=sha(I/source);bindings[math]=sha(I/math)
for n in ['two-sink-partial-twins.json','two-sink-partial-twins.stdout.txt','two-sink-partial-twins.stderr.txt']:bindings[n]=sha(I/n)
assert sha(I/'two-sink-partial-twins.json')=='f9fc23ab5d453a71878e4ed58361d59f87c81af382d47f128f620b20cf5e62b7'
assert twins['input_sha256']==sha(I/'two-sink-tight-cones-v2.json')
parent3=json.loads((I/'three-factor-position-classification.json').read_text());parent45=json.loads((I/'four-five-position-filter.json').read_text());mixed=json.loads((I/'mixed-triple-census.json').read_text())
for d in (v1,v2):assert d['input_sha256']==sha(I/'mixed-triple-census.json')
for r in forest['inputs']:assert sha(Path(r['path']))==r['sha256']
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
EM=[(1<<a)|(1<<b) for a,b in E];N=[sum(1<<(b if a==v else a) for a,b in E if v in(a,b)) for v in range(11)]
def cn(s):return sum(1<<v for v in range(11) if s&~N[v]==0)
@functools.lru_cache(None)
def tau(es):
 if not es:return 0
 return 1+min(tau(tuple(e for e in es if not e>>v&1)) for v in range(11) if es[0]>>v&1)
def cost(s):
 es=tuple(e for e in EM if not s&e);return s.bit_count()+len(es)+tau(es)-1
def subs(s):
 out=[];v=s
 while True:
  out.append(v)
  if not v:return sorted(out)
  v=(v-1)&s
expected_inputs={3:{tuple(r['supports']) for r in parent3['families'] if not r['combined_excluded']}}
for entry in parent45['results']:expected_inputs[entry['k']]={tuple(r['supports']) for r in entry['families'] if not r['excluded']}
forest_results=[];forest_assignments=0
for group in forest['results']:
 k=group['k'];core=15-k;records=[]
 assert {tuple(r['supports']) for r in group['families']}==expected_inputs[k]
 for old in group['families']:
  S=old['supports'];L=[cost(s) for s in S];V=[cn(s).bit_length()-1 for s in S]
  assert L==old['individual_costs'] and V==old['owners'] and all(cn(s).bit_count()==1 for s in S)
  applies=min(L)>=core+1 and max(L)>=core+5 and len(set(V))==k;valid=[]
  if applies:
   # Enumerate level partitions before choosing their distinguished sources.
   for levels in itertools.product(range(3),repeat=k):
    classes=[[i for i in range(k) if levels[i]==d] for d in range(3)]
    if not all(classes):continue
    if any(L[i]!=core+1 for i in classes[0]):continue
    if any(S[r]>>V[j]&1 for r in classes[0] for j in classes[1]+classes[2]):continue
    for a in classes[0]:
     for b in classes[1]:
      forest_assignments+=1
      if all(L[i]+sum(bool(S[i]>>V[j]&1) for j in ([a] if levels[i]==1 else [a,b] if levels[i]==2 else []))<=core+1+2*levels[i] for i in range(k)):
       valid.append((a,b,levels))
  assert old['hypotheses_apply']==applies and old['excluded']==(applies and not valid)
  if old['abstract_forest']:
   w=old['abstract_forest'];assert (w['first_source'],w['second_source'],tuple(w['levels'])) in valid
  records.append({'supports':S,'applies':applies,'excluded':applies and not valid,'all_feasible_forests':[{'first_source':a,'second_source':b,'levels':lev} for a,b,lev in valid]})
 summary={'k':k,'input_remaining':len(records),'newly_excluded':sum(r['excluded'] for r in records),'remaining':sum(not r['excluded'] for r in records)}
 assert all(summary[key]==group[key] for key in summary)
 forest_results.append({**summary,'families':records})
print(json.dumps({'forest':[{k:v for k,v in r.items() if k!='families'} for r in forest_results]}),flush=True)

rows={tuple(r['supports']):r for r in mixed['results'][1]['families'] if r['position_witness'] is not None};assert len(rows)==68
v1map={tuple(r['supports']):r for r in v1['families']};v2map={tuple(r['supports']):r for r in v2['families']};assert set(rows)==set(v1map)==set(v2map)
downward=0;allowed_cache={}
def allowed_table(tight,force_common=False):
 global downward
 key=(tuple(tight),force_common)
 if key not in allowed_cache:
  allowed=[u.bit_count()<=1 or ((not force_common or bool(cn(u))) and all(u&~s==0 or bool(cn(u)&~s) for s in tight)) for u in range(2048)]
  for u in range(2048):
   if allowed[u]:
    for v in range(11):
     if u>>v&1:assert allowed[u^(1<<v)];downward+=1
  assert allowed[0] and all(allowed[1<<v] for v in range(11))
  allowed_cache[key]=allowed
 return allowed_cache[key]
def splits(s,allowed):
 options=[u for u in subs(s) if allowed[u]]
 return [[u,v] for u in options for v in options if u<=v and u|v==s]
sink_records=[];absorption_families=[]
for ss,row in rows.items():
 S=list(ss);L=[cost(s) for s in S];V=[cn(s).bit_length()-1 if cn(s) else None for s in S]
 assert L==row['individual_costs'] and V==row['owners']
 c=next(i for i,v in enumerate(V) if v is not None);old1=v1map[ss];old2=v2map[ss]
 fail1=[];shared1=[];split1=[];intersection1=None
 if L[c]==15:
  allowed=allowed_table([S[c]],True)
  for i in range(3):
   if i==c:continue
   pairs=splits(S[i],allowed);split1.append({'output':i,'pairs':pairs})
   if not pairs:fail1.append(i)
  tight=[i for i in range(3) if i!=c and L[i]==15]
  if tight:
   intersection1=functools.reduce(int.__and__,(S[i] for i in tight),S[c])
   for i in tight:
    diff=S[i]&~intersection1
    if not allowed[diff]:shared1.append({'output':i,'difference':diff,'common_neighbors':cn(diff)})
 assert split1==old1['operand_decompositions'] and fail1==old1['failed_operand_outputs'] and shared1==old1['failed_shared_core_outputs'] and intersection1==old1['shared_core_intersection']
 assert old1['excluded']==bool(fail1 or shared1)
 tight=[i for i in range(3) if L[i]==15];split2=[];fail2=[];shared2=[];intersection2=None
 if L[c]>=14 and tight:
  allowed=allowed_table([S[i] for i in tight])
  for i in range(3):
   pairs=splits(S[i],allowed);split2.append({'output':i,'pairs':pairs})
   if not pairs:fail2.append(i)
  intersection2=functools.reduce(int.__and__,(S[i] for i in tight),2047)
  shared2=[i for i in tight if not allowed[S[i]&~intersection2]]
 assert split2==old2['operand_decompositions'] and fail2==old2['failed_operand_outputs'] and shared2==old2['failed_shared_core_outputs'] and intersection2==old2['shared_core_intersection']
 symmetric=bool(fail2 or shared2);assert symmetric==old2['symmetric_tight_excluded']
 pattern=any(S[a]==320 and L[a]==15 and V[a] is None and S[c] in (560,562) and S[b] in (392,1288,1408,1416) for a,b in itertools.permutations([i for i in range(3) if i!=c],2))
 assert pattern==old2['absorption_excluded']
 if pattern:
  a=S.index(320);b=next(i for i in range(3) if i not in(a,c))
  assert V[c]==8 and L[c]==(12 if S[c]==562 else 13)
  assert all(s>>8&1 for s in (S[a],S[b])) and not S[c]&S[a]
  assert all(cn(u)==1<<8 for u in subs(S[c]) if u.bit_count()>=2)
  assert row['joint_costs'][a]==17 and not symmetric
  absorption_families.append({'supports':S,'a':a,'b':b,'c':c})
 assert old2['excluded']==(symmetric or pattern)
 assert not old1['excluded'] or symmetric
 sink_records.append({'supports':S,'v1_excluded':old1['excluded'],'symmetric_excluded':symmetric,'absorption_excluded':pattern,'v2_excluded':symmetric or pattern})
assert len(absorption_families)==8 and sum(r['v1_excluded'] for r in sink_records)==23
assert sum(r['symmetric_excluded'] for r in sink_records)==42 and sum(r['v2_excluded'] for r in sink_records)==50
target=(276,518,1056);assert target in rows and not v2map[target]['excluded'] and twins['family']==list(target)
assert rows[target]['individual_costs']==[14,14,15] and N[2]==1056
twins_cases=[]
for old in twins['cases']:
 support=sum(1<<v for v in old['support']);deleted=sum(1<<v for v in old['deleted']);es=[e for e in EM if not e&deleted]
 assert len(es)==8 and tau(tuple(es))==4 and old['partial_cost']==13
 assert [list(e) for e in E if not ((1<<e[0])|(1<<e[1]))&deleted]==old['edges']
 cover=sum(1<<v for v in old['cover']);assert cover.bit_count()==4 and all(cover&e for e in es)
 triangle=old['triangle'];occupied=set(triangle)
 assert all(((1<<a)|(1<<b)) in es for a,b in itertools.combinations(triangle,2))
 for edge in old['disjoint_edges']:
  assert not occupied&set(edge) and sum(1<<v for v in edge) in es;occupied.update(edge)
 twins_cases.append({'support':support,'deleted':deleted,'residual_edges':es,'tau':4,'partial_cost':support.bit_count()+len(es)+4-1})
assert cn(272)==2 and 272&~514 and cn(272)&~514==0

# Actual clean/productive DAG controls for both absorption mechanisms. These
# need not fit17 gates; they check the deletion identities, not the budget proof.
ALL=(1<<2048)-1;raw=[sum(1<<x for x in range(2048) if x>>v&1) for v in range(11)]+[0,ALL]
F=functools.reduce(int.__or__,(raw[a]&raw[b] for a,b in E),0);indmask=ALL^F
controls=[];negative_equalities=0;full_output_checks=0
for family in absorption_families:
 for mode in ('raw_false','gate_redirect'):
  gates=[];values=list(raw)
  def add(op,a,b):
   gates.append([op,a,b]);values.append(values[a]&values[b] if op=='and' else values[a]|values[b]);return len(values)-1
  def OR(wires):
   wires=list(wires)
   if not wires:return 11
   w=wires[0]
   for u in wires[1:]:w=add('or',w,u)
   return w
  edge={e:add('and',a,b) for (a,b),e in zip(E,EM)}
  def factor(s):return OR([v for v in range(11) if s>>v&1]+[edge[e] for e in EM if not e&s])
  S=family['supports'];C=factor(S[family['c']]);A=factor(S[family['a']]);B=factor(S[family['b']])
  R=8 if mode=='raw_false' else add('or',8,edge[(1<<0)|(1<<10)])
  q=add('and',C,R)
  if mode=='raw_false':
   # Deliberately include an AND descendant to test the stronger fact that
   # q->FALSE preserves every negative wire value and all productivity.
   t=add('or',q,6);u=add('and',t,7);A=OR([A,q,u]);B=OR([B,u])
  else:A=add('or',A,q);B=add('or',B,q)
  outputs=[A,B,C];assert values[A]&values[B]&values[C]==F
  support=lambda val:sum(1<<v for v in range(11) if val>>(1<<v)&1)
  for g,(op,a,b) in enumerate(gates):
   if op=='and':assert support(values[a]) and support(values[b]) and not values[13+g]&indmask
  newer=list(raw);redirect=11 if mode=='raw_false' else R
  for g,(op,a,b) in enumerate(gates):
   w=13+g
   if w==q:newer.append(newer[redirect])
   else:newer.append(newer[a]&newer[b] if op=='and' else newer[a]|newer[b])
   if mode=='raw_false':assert not (newer[w]^values[w])&indmask;negative_equalities+=125
   if op=='and' and w!=q:assert support(newer[a]) and support(newer[b]) and not newer[w]&indmask
  assert all(newer[w]==values[w] for w in outputs);full_output_checks+=2048*3
  # Materialize the removed gate as a wire redirect, retaining all other gates.
  remap={w:w for w in range(13)};reduced=[]
  for g,(op,a,b) in enumerate(gates):
   w=13+g
   if w==q:remap[w]=remap[redirect]
   else:remap[w]=13+len(reduced);reduced.append([op,remap[a],remap[b]])
  assert len(reduced)==len(gates)-1
  controls.append({'supports':S,'mode':mode,'gates':gates,'outputs':outputs,'charged_AND':q,'redirect_wire':redirect,'reduced_gates':reduced,'reduced_outputs':[remap[w] for w in outputs],'all2048_outputs_unchanged':True,'all_remaining_ANDs_clean_productive':True})
assert len(controls)==16
result={'verdict':'PASS_FOREST_AND_TWO_SINK_V1_V2_PLUS_PARTIAL_TWINS_MATH_FINITE_CONTROLS','source_sha256':sha(Path(__file__)),'producer_bindings':bindings,'forest_assignments_checked':forest_assignments,'forest_results':forest_results,'allowed_table_count':len(allowed_cache),'immediate_downward_checks':downward,'sink_records':sink_records,'v1_excluded':23,'symmetric_excluded':42,'absorption_excluded':8,'v2_excluded':50,'partial_twins_newly_excluded':1,'k3_r2_remaining':17,'remaining_k3_r2':[list(s) for s in sorted(rows) if not v2map[s]['excluded'] and s!=target],'partial_twins_cases':twins_cases,'absorption_DAG_controls':controls,'negative_wire_equalities':negative_equalities,'full_output_equality_checks':full_output_checks,'seconds':time.monotonic()-START,'solver_run':False,'Lean_build':False,'scope':'Minimal proper full-cover factors of17-gate productive clean prefixes. Forest leaves258k3/r0 and112k4/r0; knownk5/r0closure unchanged. Two-sink plus partial twins leave17of68k3/r2. Purek4/r4 andk5/r5 remain OPEN with prior support-relaxation witnesses. No CNF/Lean/global claim.'}
(O/'forest-sinks-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['producer_bindings','forest_results','sink_records','absorption_DAG_controls']},indent=2))
