# S04 independent forest / two-sink / partial-twins review

Verdict: mathematical and finite PASS for the exact producer versions pinned
by forest-sinks-review.json (b57049af7a3c7e56f8bf964357e9ef5451876dd98483589be529be22599dad8c).
This is research evidence about minimal proper full-cover selected factors of
a 17-gate productive clean prefix for the fixed 11-vertex graph. It is not a
Lean proof, generated CNF cut, SAT certificate, or arbitrary circuit lower bound.

The independent script review_forest_sinks.py has SHA256
147af92a65bc8d07a1c370aa429be0c4cc1082219647008dd00d4f300a93d30e.
It checks all producer bindings, computes residual covers by edge branching,
enumerates the possible level partitions independently, and checks every
stored support family, operand split, shared-core obstruction and witness.
Its full stdout/stderr are preserved. It completed in 0.081 seconds with no
solver or Lean invocation. The four counted forest assignments are the ones
remaining after valid level/root/owner filters; this is not a claim that only
four total level assignments exist.

## Two-spare forests

With k selected outputs, c=15-k core gates and two additional nonselected
gates, min L>=c+1 and max L>=c+5 force a high-cost output to have two selected
ancestors. Distinct common-neighbor owners rule out merging these ancestors
at a single clean productive AND: on the same side their possible opposite
supports have empty intersection, and opposite sides would be dirty.
Two independent AND branches require another OR to form the proper final
support. Also an empty-support AND cannot directly feed another productive
AND. Thus the two spare ANDs form the chain A -> q1 -> B -> q2 -> C, with
selected outputs at levels zero, one and two. The corresponding cone limits
are c+1, c+3 and c+5. Level-zero outputs are tight and contain all c core gates.
The other operand forming a nonroot proper support is a core gate, not a raw
input or a different selected output. Its owner cannot belong to any root
support without forcing an extra gate in that tight root cone. All charged
gates are counted in the exact ancestor cones; no gate-minimality assumption
or global ancestry antichain has been inserted.

The independent finite enumeration reproduces four new exclusions among262
k3/r0 families and three among115 k4/r0 families, leaving258 and112. It also
excludes the last position-filter k5/r0 family, already covered by the earlier
k5/r0 closure. This does not address any r>0 class by itself.

## Two-sink tight cones

Let A,B have no common neighbors and let C have a common neighbor. Every
descendant of A or B is OR-only, so selected support incomparability makes
them terminal among the three. C -> A requires at least three gates outside
the C cone: the first AND must erase support, and an AND plus a single final
OR cannot create a no-common-neighbor support from a raw or C-cone operand.
Thus L_C>=14 forces an ancestry antichain in17 gates.

Each selected cone then has at most15 gates. An L=15 cone contains every one
of the14 nonselected gates. For every such tight support S, any core operand
support U of size at least2 must satisfy U subset S or CN(U) not subset S;
otherwise the supported-ancestor extra-gate charge contradicts tightness.
Raw singletons remain explicit exceptions. These Allowed tables are downward
closed. Each selected OR support must split into two allowed operand supports.
The chronologically last shared core gate directly feeds each tight output,
so its support lies in their intersection; the complementary operand test
then gives the shared-core obstruction. All statements apply symmetrically
to tight outputs, not just to C.

The finite checks independently reproduce23 v1 exclusions and42 symmetric
v2 exclusions across all68 mixed-r2 families. All21 distinct Allowed tables,
1979 immediate downward-closure checks, and all operand decompositions and
shared-core tests match the producers.

## Eight absorption cases

These have A support{6,8}, L_A=15; C support{4,5,9} or N(8), L_C=13 or12;
and B one of{3,7,8},{3,8,10},{7,8,10},{3,7,8,10}. The unique owner8 belongs
to A and B. Joint cost is17. If C is not an ancestor of A, any C->B path
removes C, B and its first AND from A's cone, contradicting L_A=15. The
remaining antichain case makes all C operands lie in A's tight core, where
each nonsingleton subset of C's support triggers the owner charge; two raw
singletons cannot cover C's support.

If C is ancestral to A, the A cone has16 gates and C has12 or13. The first
AND q below C has other support{8}. For a13-gate C cone the only AND outside
it is q. Replacing q=C AND R by R preserves all positive values because C
covers every edge; on independent inputs R=x8, already accepted by A and B,
and all descendants are OR. It deletes one gate and contradicts joint17.

For a12-gate C cone, C=N(8). A gate R inside C's cone would give actual raw8
ancestry and contradict the irrelevant-input charge. If R is raw8, then
q<=x8 and A,B have unaffected OR-only raw8 paths, so q->FALSE preserves their
full functions. Since q is clean, it was already FALSE on every independent
input. Consequently EVERY retained wire value on those inputs, and hence all
singleton supports, remains unchanged: retained ANDs stay clean and productive
without any restoration. If R is a gate outside C, the fourth outside gate
must be OR, returning to the q-only-AND argument. No uncounted overlap or
constant/copy exception is used.

These eight cases are disjoint from the42 symmetric cases. Sixteen actual
DAG controls cover q->FALSE and q->R, including AND descendants in the FALSE
case, and materialize the one-gate deletion. They verify98304 selected-output
equalities and49000 negative-wire equalities. The controls are not17-gate
search results and do not replace the budget proof.

## Partial twins

Family[276,518,1056] has L=[14,14,15], C=N(2), and raw2 cannot be ancestral
to tight C. Thus A=2 OR P and B=2 OR Q with core supports P={4,8}, Q={1,9}.
Both accept all required edges not incident to2. Each residual graph has
eight edges and cover number4, witnessed independently by triangle{3,6,7}
plus two disjoint edges and a size-four cover. The partial-edge cone bound
is13. P and Q cannot be ancestral to one another without requiring at least
15 core gates. Their13-gate cones therefore share all12 remaining core gates.
The last shared core signal has empty support, forcing P's other operand to
have support{4,8}. This operand is ancestral to Q, and CN({4,8})={1} lies in
Q's support, while {4,8} is not contained there. The partial supported-ancestor
charge forces Q>=14, a contradiction. This excludes one additional family.

Thus this frozen package leaves17 of68 k3/r2 families. Any later birth-count
closure is separate and is NOT included in this PASS. k3/r1 remains800 here;
pure k4/r4 and k5/r5 remain open with explicit relaxation witnesses.
