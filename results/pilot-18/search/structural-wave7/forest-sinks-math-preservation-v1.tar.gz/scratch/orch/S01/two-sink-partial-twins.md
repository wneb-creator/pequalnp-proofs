# One further r2 family: two tight partial-edge outputs

Independent mathematical review requested. This is separate from the immutable
50-of68 proposal. It excludes the remaining support family

    S_A={2,4,8} (276), S_B={1,2,9} (518), S_C={5,10} (1056).

The individual full-factor costs are14,14,15. C has unique common neighbor2
and its support is exactly N(2). By the three-new-gates lemma all three selected
outputs are ancestrally unrelated. C's exact15-gate cone contains all14 other
prefix gates. The tight irrelevant-input charge forbids raw input2 anywhere
in C's cone.

A and B are OR outputs, and their operands can only be raw inputs/constants
or gates in that cone. Their singleton support includes2, so one operand of
each must be raw x2. The other operands P,Q are gates with supports

    S_P={4,8}, S_Q={1,9}.

They accept every target edge not incident to2. The partial-edge theorem gives
cost13 for each, using the following residual graphs outside their supports:

    H_P = G minus {2,4,8},
    H_Q = G minus {1,2,9}.

Each has8 edges and cover number4. For H_P, disjoint components of a covering
certificate are triangle{3,6,7}, edge{0,10}, edge{5,9}; they force2+1+1=4.
A cover of size4 is{3,6,9,10}. For H_Q use the same triangle and disjoint edges
{0,10},{4,8}; a cover is{3,6,8,10}. Therefore2+8+4-1=13 in both cases.

P and Q lie among the14 strict gate ancestors of C. They cannot be ancestors
of one another: their incomparable nonempty supports would require an AND
and a new OR, giving at least13+2=15 gates in the latter cone, exceeding14.
Thus each has exactly13 gate ancestors and contains all12 other core gates.

Let q be the latest of those12 shared gates. It directly feeds both P and Q,
so its support is contained in S_P intersect S_Q, which is empty. Since P is
OR, its other operand R has support exactly S_P={4,8}. R is a gate, not a raw
input; it is one of the12 shared gates and hence an ancestor of Q.

The common-neighbor set of S_R is{1}, contained in S_Q={1,9}, while S_R is not
contained in S_Q. The reviewed arbitrary-supported-ancestor extra AND charge
therefore raises Q's partial-edge lower bound from13 to14, contradicting its
exact13-gate cone.

The extra charge applies to this partial-edge output just as to a full-cover
factor: restrict S_Q to zero and bypass the first AND below R by its other
operand. Every independent row is unchanged and accepted target-edge rows
can only increase. The actual partial-edge bound requires no exact target
function. This argument does not assume P or Q is itself full-cover.

Thus this family needs at least18 prefix gates. Added to the preceding50
proposed exclusions, it leaves17 of the68 original r2 families. The finite
script checks the graph, covers, disjoint lower-bound certificates, support
owners, individual costs and disjointness from the prior50. No solver or
Lean theorem is claimed; independent proof review is still required.
