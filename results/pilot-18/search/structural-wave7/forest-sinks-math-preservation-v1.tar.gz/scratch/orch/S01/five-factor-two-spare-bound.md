# Five common-neighbor factors: two-spare-gate obstruction

For independent review. Mathematical and finite-support result only; no SAT,
Lean, or global shard conclusion. It applies to minimal full-cover families
of exactly five distinct proper factors, all with a common neighbor.

All49 candidate factor supports have individual ancestor cost at least11.
Thus the five chosen outputs, all OR gates, occupy five of positions10..16.
There are at most two unselected gates in this seven-position suffix. Call
gates0..9 the core. Constants and repeated operands remain allowed.

## General first-AND component count

If r selected factor outputs are ancestors of another selected output W,
there are at least r unselected gates after the earliest of these selected
sources and before W. Each source must meet an AND on any path to W, since
its support is not contained in W's. Follow OR-only paths from the r sources
to their first AND boundaries. No selected output can be an intermediate
OR-only node, by support incomparability.

There are initially r source components. Each unselected OR node can merge
at most two existing components and reduce their count by at most one. Each
remaining component must exit through a boundary AND. One boundary AND
cannot receive two components on opposite operands: its inputs would then
dominate two distinct selected factors, whose pair product is dirty by
minimality of a family of size at least3. Hence distinct components require
distinct boundary ANDs. OR-node count plus AND-boundary count is at least r.
All counted gates are unselected and occur in the specified interval. This
argument permits shared paths, fan-out, and ancestry among the selected
sources through earlier ANDs; those ANDs separate their OR components.

For five factors there are only two spare gates, so r<=2. Any selected output
then has at most10core gates,2spare gates,itself,and2selected ancestors: at
most15ancestor gates. Any factor with individual cost16or17 is impossible.
This excludes35of the41 families left by the one-spare filter.

## The five remaining families with maximum cost15

The finite table verifies these additional hypotheses for five of the six
remaining families:

- exactly one chosen factor A has cost11; every other factor has cost>11;
- all five common-neighbor owners are distinct;
- at least one other factor C has its owner in S_A;
- some chosen factor has cost15.

These hypotheses are impossible in17prefix gates. A cost15 output needs two
selected ancestors by the cone count above. Therefore both spare gates must
be ANDs. With only one AND, two unrelated selected ancestors would have to
merge through an OR before it and enter the same operand. Distinct owners
then leave the other operand no possible nonempty support. Opposite-side
entry is dirty. An ancestry chain needs two separate ANDs. Thus a single
AND and one OR cannot serve that cost15 output.

Both spare ANDs must carry selected-factor ancestry. If one occurred before
all relevant selected sources, the remaining AND could give any later output
at most one selected ancestor, again limiting its cone to14. The earliest
selected source therefore has no spare ancestor, so its cone has at most
the10core gates and itself. It must be the unique cost11factor A, and its
cone contains all ten core gates.

Both spare ANDs lie downstream of A. Since the other selected outputs cost
more than11, each must descend through one of those ANDs. Each such selected
OR output C has the form q OR P_C, where q is a spare clean AND and
support(P_C)=S_C. It cannot OR two clean AND outputs, which have empty
support, or directly OR another incomparable selected output. Consequently
P_C is a core gate, since its support has at least two vertices.

Every P_C is an ancestor of A because A uses the whole core. If v_C is in
S_A, the arbitrary-supported-ancestor charge applies to P_C: its nonempty
support S_C is incomparable with S_A and its unique common neighbor v_C is
in S_A. A then needs cost at least12, contradicting its exact11-gate cone.

This eliminates those five families. Together with the earlier290 one-spare
exclusions and35 large-cost exclusions,330of331 joint-feasible five-factor
families are excluded, leaving one finite support pattern.

## The single remaining five-factor pattern

Supports, costs, owners:

    {0,5,7,8}: 11, owner9
    {4,5,9}:   13, owner8
    {1,8,10}:  13, owner4
    {2,4,6}:   14, owner10
    {3,7,10}:  14, owner6

These are masks417,560,1282,84,1160. The family passes the finite support
conditions and is minimal. No17-gate shared prefix is known. It remains
outside the preceding cost15 argument; no operation type or ancestry pattern
is asserted for its two spare gates.

## Generalization of the one-spare filter used by the census

For k selected factors with all L>=17-k, the last k+1 positions have at most
one unselected gate. The k=3 one-spare proof carries over verbatim. With no
selected ancestry, every output cone is at most18-k. Otherwise selected
ancestry is a star through the single AND. The source and nonchildren have
exact17-k cones, containing all16-k core gates; children have19-k cones.
The reviewed reverse-owner charge and full-neighborhood raw-operand argument
apply unchanged. For j children in that raw-operand case, their distinct
partial OR operands must fit among the first15-k core gates, before the last
core gate that directly feeds the source. Their sorted cost capacities are
16-k-j,...,15-k. These are the exact tests used in enumerate_common_four_five.py.

The census rechecks the known k=3 counts515/233 as a control. Its k=4/k=5
generalization and this two-spare proof still need independent review.
