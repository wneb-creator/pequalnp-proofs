#!/usr/bin/env python3
import hashlib
import itertools
import json
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
start=time.monotonic()
parent=ROOT/'mixed-triple-census.json'
data=json.loads(parent.read_text())
rows=[r for r in data['results'][1]['families'] if r['position_witness'] is not None]
assert len(rows)==68
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
   (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
N=[sum(1<<(v if u==x else u) for u,v in E if x in(u,v)) for x in range(11)]
def cn(s):return sum(1<<v for v,n in enumerate(N) if n&s==s)
records=[];downward_checks=0
for row in rows:
    S=row['supports'];L=row['individual_costs'];O=row['owners']
    c=next(i for i,o in enumerate(O) if o is not None)
    tight=[i for i in range(3) if L[i]==15]
    splits=[];failed=[];shared_failed=[];intersection=None
    if L[c]>=14 and tight:
        def allowed(u):return u.bit_count()<=1 or all(u&~S[i]==0 or bool(cn(u)&~S[i]) for i in tight)
        for j,T in enumerate(S):
            options=[u for u in range(2048) if u&~T==0 and allowed(u)]
            for u in options:
                v=u
                while True:
                    assert allowed(v);downward_checks+=1
                    if not v:break
                    v=(v-1)&u
            pairs=[(u,v) for u,v in itertools.combinations_with_replacement(options,2) if u|v==T]
            splits.append(dict(output=j,pairs=pairs))
            if not pairs:failed.append(j)
        intersection=2047
        for i in tight:intersection&=S[i]
        shared_failed=[i for i in tight if not allowed(S[i]&~intersection)]
    symmetric=bool(failed or shared_failed)
    absorption=False;absorption_data=None
    if L[c]<14:
        a=next((i for i in range(3) if O[i] is None and S[i]==320 and L[i]==15),None)
        if a is not None:
            b=next(i for i in range(3) if i not in(a,c))
            absorption=(S[c] in (560,562) and S[b] in (392,1288,1408,1416))
            if absorption:
                assert O[c]==8 and all(S[i]>>8&1 for i in(a,b))
                assert not S[c]&S[a] and S[c].bit_count()>=3
                assert (S[c],L[c]) in ((560,13),(562,12))
                assert S[c]!=562 or N[8]==562
                assert row['joint_costs'][a]==17
                for t in range(2048):
                    if t&~S[c]==0 and t.bit_count()>=2:assert cn(t)==1<<8
                absorption_data=dict(high_sink=a,other_sink=b,common=c,owner=8,
                    exact_neighborhood=S[c]==N[8],common_cost=L[c],high_joint_bound=17)
    records.append(dict(supports=S,individual_costs=L,owners=O,common_output=c,tight_outputs=tight,
        operand_decompositions=splits,failed_operand_outputs=failed,
        shared_core_intersection=intersection,failed_shared_core_outputs=shared_failed,
        symmetric_tight_excluded=symmetric,absorption_excluded=absorption,
        absorption_hypotheses=absorption_data,excluded=symmetric or absorption))
summary=dict(total=68,symmetric_tight_excluded=sum(r['symmetric_tight_excluded'] for r in records),
    absorption_excluded=sum(r['absorption_excluded'] for r in records),
    overlap=sum(r['symmetric_tight_excluded'] and r['absorption_excluded'] for r in records),
    excluded=sum(r['excluded'] for r in records),remaining=sum(not r['excluded'] for r in records),
    downward_checks=downward_checks,elapsed_seconds=time.monotonic()-start)
assert (summary['symmetric_tight_excluded'],summary['absorption_excluded'],summary['overlap'])==(42,8,0)
out=dict(verdict='TWO_SINK_V2_MATH_AND_FINITE_APPLICATION_PENDING_REVIEW',summary=summary,
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    input_sha256=hashlib.sha256(parent.read_bytes()).hexdigest(),
    math_sha256=hashlib.sha256((ROOT/'two-sink-tight-cones-v2.md').read_bytes()).hexdigest(),
    families=records,solver_run=False,Lean_proof=False,
    scope='Only supplied68 k3/r2 families. Gate deletion restores productivity before applying joint17 lower bound. No SAT/Lean/globalclaim.')
(ROOT/'two-sink-tight-cones-v2.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(summary))
print(json.dumps({k:out[k] for k in ('source_sha256','input_sha256','math_sha256')}))
