# Two CN-empty sinks and one common-neighbor factor

New mathematical argument for independent review, not a Lean theorem or a
solver result. All existing productive-clean-prefix and minimal-full-factor
hypotheses remain in force. The prefix has at most17 gates. The three chosen
outputs have proper, pairwise incomparable supports; exactly two, A and B,
have no common neighbor. The remaining output C has a common neighbor.
All three outputs are OR gates. Denote their ancestor-cone sizes by M_A,M_B,M_C,
including the output gate. Their already proved individual bounds are L_A,L_B,L_C.

## 1. A common-neighbor source needs three new gates to reach a no-CN sink

Every gate in C's ancestor cone has a support with a common neighbor: a no-CN
ancestor would have only OR descendants, making C no-CN as well.

Suppose C is an ancestor of A. Their incomparable supports force an AND on
the path. Let q be the first AND. At least q and A lie outside C's cone. If
these were the only two new gates, q would be the only possible intermediate
gate. A is OR and q has empty singleton support. Its other operand would be
a raw input/constant or a wire in C's cone. Any proper such support has a
common neighbor; TRUE cannot feed the proper-support output A. Therefore A
would have a common neighbor, a contradiction. Hence

    M_A >= M_C+3.

The same holds for B. Since the other no-CN selected output is outside each
cone, M_A,M_B<=16. Thus L_C>=14 forbids C from being an ancestor of either
sink. In that case all three selected outputs are an ancestry antichain.
No assumption about global gate minimality, repeated operands or copies is
used. This lemma is only a necessary condition; no normalization is made.

## 2. Exact common cone when L_C=15

Both A and B lie outside C's cone, so M_C<=15. If L_C=15, equality holds.
All14 unselected prefix gates belong to C's cone, and every one has a support
with a common neighbor. Part1 makes all three selected outputs incomparable
in ancestry. Pad unused slots if needed; the15-gate cone and the two distinct
sink gates already use all17 slots, so no additional gate exists.

Every operand of A or B is therefore either a raw input/constant or a gate
inside C's cone. Neither selected output can be such an operand. Both sinks
are OR gates, so their two operand supports union to their full support.

Let U be the support of a gate operand in C's cone. The previously reviewed
arbitrary-supported-ancestor charge forbids

    U not contained in S_C, and C(U) contained in S_C,

because it would give M_C>=L_C+1=16. Empty support is harmless. For a raw
input, the operand may occur only in the sink and need not be ancestral to C,
so all singleton supports must remain allowed. Full TRUE cannot be used.

Define Allowed_C(U) to mean:

* U is empty or a singleton; or
* C(U) is nonempty and either U is contained in S_C or C(U) has a vertex
  outside S_C.

This set of supports is downward closed. Each actual sink operand satisfies
it. Consequently each sink S must have a decomposition U union V=S with
both U and V allowed. Exhausting all support subsets is tiny here. The raw
singleton exception is essential; omitting it would be an invalid cut.

## 3. The common last core gate

Suppose also that some sink has L=15. Because all three chosen outputs are
ancestrally unrelated, its cone has at most the14 unselected gates plus its
own output. It therefore includes all14 unselected gates, just like C.

Let q be the chronologically last of those14 gates. Its path to C must be a
direct operand edge: no unselected gate follows q, and the other selected
outputs cannot be intermediates. The same applies to every sink of cost15.
Thus q's support T is contained in

    I = S_C intersect (all cost15 sink supports).

The other operand of each such sink has an allowed support U and
S_sink=T union U. Hence S_sink minus I is a subset of U and must itself be
allowed, by downward closure. This yields the necessary condition

    Allowed_C(S_sink minus I)

for every cost15 sink. It remains valid when T is empty, q is a repeated-
operand gate, or the other sink operand is a raw input. In particular if I
is empty, a no-CN sink would have to get its entire support from one allowed
operand; this is impossible except for supports already having a common
neighbor, which a sink does not have.

## 4. Finite application

The exact68 mixed triples and their costs are hash-bound inputs from the
earlier complete census.38 have L_C=15. Among them:

* The two-operand allowed-support test excludes3 families.
* The shared-last-core-gate test excludes20 additional families.
* The exclusions are disjoint, so23 of68 are excluded and45 remain.

The source records every family, all allowed support decompositions or the
specific failed necessary condition, exact graph data, source/input/proof
hashes and complete logs. The three-new-gates lemma is proved above but is
not used to claim additional numerical exclusions beyond these23. Remaining
families are not circuit witnesses. All conclusions await independent review.
