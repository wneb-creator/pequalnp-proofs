# Reusable extra cost for an irrelevant ancestor input

Status: proposed mathematical generalization, for independent review. No
encoding or worker change. The nonempty-residual argument is the same extra
AND deletion used in tight-survivor-obstruction.md.

Let W be a wire in an ambient-G-clean binary prefix. Every AND is productive:
both operands have nonempty singleton support. Let S be W's proper singleton
support. Let H consist of any accepted minimal-edge rows outside S. Let M be
the number of actual gate ancestors of W, including W when it is a gate.

Suppose a raw input x_v is an ancestor of W, v is not in S, and N_G(v) is
contained in S. Then

    M >= |S| + |E(H)| + cover(H) - 1 + 1.

Here H need not contain every residual edge. For H nonempty use the proof
below; for H empty the final elementary gate count gives the same inequality.
The graph is C4-free when applying the existing partial-edge lower bound.

Choose a path from input v to W. Because v is not in S, it contains an AND.
At its first AND q, one operand U receives v through OR gates only, so v lies
in support(U). The other operand V has nonempty support contained in N_G(v),
by productivity and cleanliness. Thus support(V) is contained in S.

Restrict S to zero. V and q are both false on every independent residual
input. Replacing q by V deletes one AND, preserves every independent-input
value of all retained gates, and can only increase their edge values. The
replacement preserves ambient cleanliness. It may change larger positive
inputs; the partial-edge theorem does not require exact values there.

If H is nonempty, the OR-only pure-S component argument additionally removes
at least |S| original OR gates, disjoint from q. There remain at most
M-|S|-1 gates in a clean circuit whose output support is empty and accepts
every edge of H. The actual-circuit partial-edge theorem proves the claim.

If H is empty and |S|>=1, the OR-only ancestry of W has its |S| distinct raw
support inputs as sources and is connected at its root. Binary OR gates can
connect these sources only with at least |S|-1 OR nodes. There is also the
distinct AND q. Hence M>=|S|, exactly the asserted empty-H bound. If S is
empty, the asserted bound is just M>=0. Thus no residual-nonempty guard is
needed for this one-bit strengthening. Full support never triggers the
condition v not in S, so the free-TRUE exemption remains intact.

## Sound cheap implication encoding

Introduce one penalty bit p_g for each prefix output g. It contributes +1
to the existing signed ancestor-cost cardinality. For every raw input v and
every gate h in0..g, force p_g whenever

    h is an ancestor of g,
    a selected operand of h is raw input v,
    v is absent from support(g), and all neighbors of v are in support(g).

One clause per left/right selector suffices:

    p_g OR S_g[v] OR OR_{u in N(v)} NOT S_g[u]
        OR NOT ancestor(g,h) OR NOT left(h,v),

and similarly for right. For h=g omit the always-true ancestor test. The
clauses force the penalty for every genuine raw-input path without creating
new reachability variables. There are17penalty bits and
2*11*(1+...+17)=3366such implication clauses before any redundant simplification.
The cardinality encoding must be regenerated or soundly strengthened to count
the extra bit; this note does not validate an implementation.

No equivalence defining p_g is necessary: the existential model may choose it
false whenever no trigger holds, and choosing it true only strengthens the
valid lower bound. Merely using singleton support as reachability would be
wrong; the ancestor-plus-operand selector is essential.

For cost-tight W with M equal to the original lower bound, this says every
input v outside S with N(v) subset S is absent from W's syntactic ancestor
cone. In particular a14-ancestor full-cover factor with support {9,10} cannot
depend on raw x0 anywhere, since N(0)={9,10}.
