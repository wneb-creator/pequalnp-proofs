#!/usr/bin/env python3
import hashlib
import itertools
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
inputs=[ROOT/'three-factor-position-classification.json',ROOT/'four-five-position-filter.json']
t=json.loads(inputs[0].read_text());u=json.loads(inputs[1].read_text())
families={3:[a for a in t['families'] if not a['combined_excluded']]}
for result in u['results']:
    families[result['k']]=[a for a in result['families'] if not a['excluded']]
results=[]
for k,rows in families.items():
    out=[];c=15-k
    for row in rows:
        S=row['supports'];L=row['individual_costs'];O=row['owners']
        applies=min(L)>=c+1 and max(L)>=c+5 and len(set(O))==k
        witness=None
        if applies:
            for A,B in itertools.permutations(range(k),2):
                rest=[i for i in range(k) if i not in(A,B)]
                for assigned in itertools.product(range(3),repeat=k-2):
                    levels=[None]*k;levels[A]=0;levels[B]=1
                    for i,d in zip(rest,assigned):levels[i]=d
                    if 2 not in levels:continue
                    roots=[i for i,d in enumerate(levels) if d==0]
                    children=[i for i,d in enumerate(levels) if d>0]
                    if any(L[i]!=c+1 for i in roots):continue
                    if any(S[r]>>O[i]&1 for r in roots for i in children):continue
                    bad=False
                    for i,d in enumerate(levels):
                        owner_mask=0
                        if d>=1:owner_mask|=1<<O[A]
                        if d>=2:owner_mask|=1<<O[B]
                        if L[i]+(S[i]&owner_mask).bit_count()>c+1+2*d:
                            bad=True;break
                    if bad:continue
                    witness=dict(first_source=A,second_source=B,levels=levels)
                    break
                if witness is not None:break
        out.append(dict(supports=S,individual_costs=L,owners=O,hypotheses_apply=applies,
                        excluded=applies and witness is None,abstract_forest=witness))
    results.append(dict(k=k,input_remaining=len(rows),newly_excluded=sum(r['excluded'] for r in out),
                        remaining=sum(not r['excluded'] for r in out),families=out))
result=dict(verdict='FINITE_TWO_SPARE_FOREST_FILTER_PENDING_MATH_REVIEW',
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    math_sha256=hashlib.sha256((ROOT/'two-spare-forest-filter.md').read_bytes()).hexdigest(),
    inputs=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in inputs],
    results=results,solver_run=False,Lean_proof=False,r_positive_status='OPEN_NOT_EXHAUSTED')
(ROOT/'two-spare-forest-filter.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps([{k:r[k] for k in ('k','input_remaining','newly_excluded','remaining')} for r in results]))
print(json.dumps({'source_sha256':result['source_sha256'],'math_sha256':result['math_sha256']}))
