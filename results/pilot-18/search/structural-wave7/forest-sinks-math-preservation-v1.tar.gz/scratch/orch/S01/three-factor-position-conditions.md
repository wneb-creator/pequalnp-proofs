# Necessary position and ancestor-cone conditions

For independent review. This note justifies classify_three_factor_positions.py,
which adds20 exclusions to the233 one-late-AND exclusions:253of515 supplied
k3/r0 survivors are excluded,262remain. No claim covers r>0, k4 or k5.

The three chosen factors form a minimal clean product family. Their proper
singleton supports are incomparable; each is a distinct OR output, and its
individual ancestor lower bound L_i is known. Number prefix gates0..16.

Enumerate every distinct output-position tuple p_i in [L_i-1,16]. For each,
enumerate all eight possible ancestry relations on the three temporally
ordered output pairs. A real circuit supplies one such tuple and relation.
The following necessary checks reject only impossible choices.

1. Ancestry is transitive. An ancestor selected output cannot reach another
   through OR gates alone, because their supports are incomparable. Thus
   between their positions there must be at least one unselected gate for
   a clean AND; a selected output itself is OR and cannot serve this role.

2. If both other selected outputs are ancestors of i, there are at least two
   unselected gates between the earliest of them and i. If one selected
   output is an ancestor of the other, each incomparable-support transition
   needs its own intervening AND. If they are unrelated, take their first
   ANDs toward i. Distinct first ANDs already give two gates. A shared first
   AND cannot receive the two factors on opposite sides, since their pair
   product is dirty. On the same side they need an OR merge gate before
   that AND, distinct from the selected outputs by incomparability. Again
   there are two unselected gates. This includes repeated operands and
   shared paths and does not assume an ancestry antichain.

3. The ancestor cone of i has at most p_i+1 minus the number of earlier
   selected outputs not ancestral to i. If the other two outputs satisfy
   a->b, with b earlier than i and a not ancestral to i, also subtract one
   unselected AND: a first AND on a->b cannot be ancestral to i (otherwise
   a would be), is earlier than b, and is distinct from all selected outputs.
   With three selected outputs there is at most one such additional pair.

4. The cone lower bound is L_i plus the number of distinct common-neighbor
   owners in S_i among its ancestral selected outputs. This is the reviewed
   first-AND restriction charge. Separately, a raw input v outside S_i with
   N(v) subset S_i gives a one-bit extra charge if it is necessarily used by
   an ancestor factor. For a factor F OR OR(S_j), v is essential exactly if
   v belongs to S_j or has a neighbor outside S_j. Hence that essentiality
   plus selected ancestry forces actual raw-input reachability. Use the
   maximum of the owner charge and this one-bit charge, not their sum:
   their deleted ANDs might coincide. The raw-input charge is the separately
   proposed irrelevant-input-charge.md and requires its mathematical review.

If a lower bound exceeds the cone upper bound, reject the choice. A family
is excluded only when every position/relation choice fails. A surviving
choice is retained verbatim in the result as an abstract necessary-condition
witness, not as a Boolean circuit. The supplied515 input records and source
are hash-pinned. All13,927 tested choices and rejection counts are summarized
in the full JSON; each family records its counts and remaining witness.

An optional v2 experiment adds ancestor-cone union lower bounds but excludes
no additional families. It is preserved separately and is not needed for the
reported253 count. Prefer the simpler original source for independent review.
