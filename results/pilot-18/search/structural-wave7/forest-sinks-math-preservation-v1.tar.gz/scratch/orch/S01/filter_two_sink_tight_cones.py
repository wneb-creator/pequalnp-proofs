#!/usr/bin/env python3
"""Exact finite application of the two-sink tight-cone necessary conditions."""
import hashlib
import itertools
import json
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
start=time.monotonic()
parent=ROOT/'mixed-triple-census.json'
data=json.loads(parent.read_text())
rows=[a for a in data['results'][1]['families'] if a['position_witness'] is not None]
assert len(rows)==68 and data['results'][1]['counts']['r']==2
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
   (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
N=[sum(1<<(v if u==x else u) for u,v in E if x in(u,v)) for x in range(11)]
def cn(s):return sum(1<<v for v,n in enumerate(N) if n&s==s)
def allowed(u,c):
    return u.bit_count()<=1 or bool(cn(u)) and (u&~c==0 or bool(cn(u)&~c))
records=[];downward_checks=0
for row in rows:
    S=row['supports'];L=row['individual_costs'];O=row['owners']
    c=next(i for i,o in enumerate(O) if o is not None)
    assert sum(o is None for o in O)==2
    assert cn(S[c]) and all(not cn(S[i]) for i in range(3) if i!=c)
    splits=[];failed=[];shared_failed=[];intersection=None
    if L[c]==15:
        C=S[c]
        for i,T in enumerate(S):
            if i==c:continue
            options=[u for u in range(2048) if u&~T==0 and allowed(u,C)]
            for u in options:
                v=u
                while True:
                    assert allowed(v,C);downward_checks+=1
                    if not v:break
                    v=(v-1)&u
            pairs=[(u,v) for u,v in itertools.combinations_with_replacement(options,2) if u|v==T]
            splits.append(dict(output=i,pairs=pairs))
            if not pairs:failed.append(i)
        tight=[i for i in range(3) if i!=c and L[i]==15]
        if tight:
            intersection=C
            for i in tight:intersection&=S[i]
            for i in tight:
                difference=S[i]&~intersection
                if not allowed(difference,C):
                    shared_failed.append(dict(output=i,difference=difference,common_neighbors=cn(difference)))
    records.append(dict(supports=S,individual_costs=L,owners=O,common_output=c,
        tight_common_cone=L[c]==15,operand_decompositions=splits,
        failed_operand_outputs=failed,shared_core_intersection=intersection,
        failed_shared_core_outputs=shared_failed,excluded=bool(failed or shared_failed)))
summary=dict(total=68,common_cost15=sum(r['tight_common_cone'] for r in records),
    operand_excluded=sum(bool(r['failed_operand_outputs']) for r in records),
    shared_core_excluded=sum(bool(r['failed_shared_core_outputs']) for r in records),
    overlap=sum(bool(r['failed_operand_outputs']) and bool(r['failed_shared_core_outputs']) for r in records),
    excluded=sum(r['excluded'] for r in records),remaining=sum(not r['excluded'] for r in records),
    downward_closure_checks=downward_checks,elapsed_seconds=time.monotonic()-start)
assert (summary['operand_excluded'],summary['shared_core_excluded'],summary['overlap'],summary['excluded'])==(3,20,0,23)
out=dict(verdict='TWO_SINK_TIGHT_CONE_FILTER_READY_INDEPENDENT_REVIEW',summary=summary,
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    input_sha256=hashlib.sha256(parent.read_bytes()).hexdigest(),
    math_sha256=hashlib.sha256((ROOT/'two-sink-tight-cones.md').read_bytes()).hexdigest(),
    edges=E,neighborhoods=N,families=records,solver_run=False,Lean_proof=False,
    scope='Only the supplied68 minimal k3/r2 full-factor families in a productive17-gate clean prefix. No k4/5, circuit, SAT or shard claim.')
(ROOT/'two-sink-tight-cones.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(summary))
print(json.dumps({k:out[k] for k in ('source_sha256','input_sha256','math_sha256')}))
