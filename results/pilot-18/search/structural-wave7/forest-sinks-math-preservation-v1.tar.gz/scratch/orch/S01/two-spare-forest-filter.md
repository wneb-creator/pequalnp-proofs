# Two-spare-AND forest filter for k=3,4,5

New generalization for independent review. Assume a minimal k-factor family
of proper full-cover outputs with pairwise distinct common-neighbor owners,
all individual costs at least16-k, and some cost at least20-k. Put c=15-k.
The selected OR outputs start at position c, leaving at most two unselected
gates after the c-gate core. The selected-source component count bounds any
output to at most two selected ancestors and hence at most c+5=20-k gates.
The high-cost output therefore needs exactly two selected ancestors.

Both spare gates are ANDs. One AND cannot reset two distinct-owner selected
sources: their opposite-side product is dirty, and same-side OR merging
leaves no nonempty common-neighbor support on the other AND operand. A
selected ancestor chain likewise needs two ANDs. Thus there are no spare ORs.

Each spare AND has exactly one selected source as an operand whenever it
carries selected ancestry. It cannot directly read the other clean AND,
by productivity, nor two full-cover selected factors, by their dirty pair
product. Every selected nonroot output is OR(q,P), with P a core gate having
that output's support. It cannot OR two clean ANDs or another incomparable
selected output. Since the high-cost output has two selected ancestors, the
two ANDs must form a selected chain A -> B -> some C: the first AND reads
selected root A, the second reads a selected child B of the first.

Every selected output is consequently one of:

- level0: no spare AND ancestor, cone size c+1;
- level1: child of the first AND, selected ancestor A, cone size c+3;
- level2: child of the second AND, selected ancestors A,B, cone size c+5.

All roots have cost c+1 because their lower bound is at least c+1. Their
cones contain the whole c-gate core. Therefore every nonroot operand P is
an ancestor of every selected root R. The arbitrary-supported-ancestor charge
implies that no nonroot's common-neighbor owner may belong to S_R. Otherwise
R would need at least c+2 gates. This is the key reverse-owner condition.

Finally add the reviewed owner charges to the level1/2 cone bounds. Enumerate
every choice of A, B, and levels of the remaining outputs. Any actual circuit
gives one such assignment. A family is excluded only when all assignments
violate root cost, cone cost, or reverse-owner conditions. No operation or
ancestry condition is imposed on families outside the stated hypotheses.

This contains the previous unique-cost11 five-factor argument without needing
uniqueness. It is a finite necessary-condition filter, not a construction or
an assertion that all clean prefixes have this form.
