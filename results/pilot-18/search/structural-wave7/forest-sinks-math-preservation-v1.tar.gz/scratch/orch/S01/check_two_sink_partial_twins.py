#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
parent=ROOT/'two-sink-tight-cones-v2.json'
data=json.loads(parent.read_text())
target=[276,518,1056]
row=next(r for r in data['families'] if r['supports']==target)
assert not row['excluded'] and row['individual_costs']==[14,14,15]
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
   (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
N=[{v if u==x else u for u,v in E if x in(u,v)} for x in range(11)]
assert N[2]=={5,10}
assert [v for v,n in enumerate(N) if {4,8}<=n]==[1]
triangle={3,6,7}
assert all(tuple(sorted((u,v))) in E for u in triangle for v in triangle if u<v)
cases=[]
for support,deleted,cover,matching in [({4,8},{2,4,8},{3,6,9,10},[(0,10),(5,9)]),
                                      ({1,9},{1,2,9},{3,6,8,10},[(0,10),(4,8)])]:
    H=[e for e in E if not set(e)&deleted]
    assert len(H)==8 and all(set(e)&cover for e in H) and len(cover)==4
    occupied=set(triangle)
    for e in matching:
        assert e in H and not set(e)&occupied
        occupied.update(e)
    tau=min(m.bit_count() for m in range(2048) if all(any(m>>v&1 for v in e) for e in H))
    assert tau==4
    cases.append(dict(support=sorted(support),deleted=sorted(deleted),edges=H,
                      cover=sorted(cover),triangle=sorted(triangle),disjoint_edges=matching,
                      cover_number=tau,partial_cost=len(support)+len(H)+tau-1))
assert all(c['partial_cost']==13 for c in cases)
out=dict(verdict='PARTIAL_TWINS_CONTROLS_PASS_MATH_REVIEW_PENDING',
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    input_sha256=hashlib.sha256(parent.read_bytes()).hexdigest(),
    math_sha256=hashlib.sha256((ROOT/'two-sink-partial-twins.md').read_bytes()).hexdigest(),
    family=target,cases=cases,prior_excluded=50,newly_excluded=1,proposed_remaining=17,
    solver_run=False,Lean_proof=False)
(ROOT/'two-sink-partial-twins.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
