# Symmetric tight cones and eight common-factor ancestry cases

Independent review requested. This extends, without altering, the first
two-sink-tight-cones.md proof. It uses the same17-gate productive clean prefix,
minimal three proper full-cover outputs, two no-CN sinks, and one common-
neighbor output C. All residual graphs in the68 inputs are nonempty.

## A. Symmetric tight-cone obstruction

If L_C>=14, the proved three-new-gates lemma forbids C from reaching either
sink, since each sink's cone has at most16 gates. All three outputs therefore
form an ancestry antichain. Each output cone has at most15 gates.

Let Q be the chosen outputs whose individual bound is15. Every q in Q uses
all14 unselected gates. For any gate support U in that shared core and each
q in Q, either U is contained in S_q or the common neighbors of U must have
a vertex outside S_q. Indeed a no-CN U not contained in S_q cannot reach q;
a nonempty common-neighbor set contained in S_q triggers the reviewed extra
ancestor AND charge, contradicting the exact15-gate cone.

Thus define Allowed_Q(U) by

    |U|<=1, OR [for every q in Q,
        U subset S_q OR C(U) has a vertex outside S_q].

Singletons remain unconditionally allowed to include raw operands that need
not themselves be in every cone. This condition is downward closed. Each
chosen output's two OR operands are raw inputs/constants or shared-core
gates, hence its support must be the union of two allowed supports.

The latest shared-core gate directly feeds every output in Q. If I is the
intersection of their supports, every q in Q therefore also requires
Allowed_Q(S_q minus I), as in the earlier last-core-gate argument.

Finite application excludes42 of68 families: the previous23 with L_C=15,
and19 additional families with L_C=14. It leaves26 families. This does not
assume that arbitrary selected factors are always an ancestry antichain;
the three-new-gates lemma supplies that property only when L_C>=14.

## B. Eight remaining families with L_C=12 or13

These are exactly

    S_A={6,8}, S_C in {{4,5,9},{1,4,5,9}},
    S_B in {{3,7,8},{3,8,10},{7,8,10},{3,7,8,10}}.

Here L_A=15; C has unique common neighbor u=8; both no-CN supports contain u.
The first C support has L_C=13; the second is exactly N(8) and has L_C=12.
The reviewed joint charge for A is15+1+1=17, counting B's outside no-CN gate
and the owner8 of C. Consequently these outputs require at least17 gates
even after any boundary-preserving productive normalization.

### B1. C is not an ancestor of A

If C reached B, a clean AND on that path, C and B would all lie outside A's
cone: any such AND reaching A would make C reach A. That leaves at most14
gates for A, contradicting L_A=15. Thus all three chosen outputs are unrelated,
and A's cone contains all14 unselected gates.

C's two operands are raw inputs or gates in A's cone. Its support is disjoint
from S_A and has at least three elements. Every subset of S_C of size at
least two has the unique common neighbor8, by C4-freeness. Such a gate operand
would trigger A's extra ancestor charge, since8 belongs to S_A. Only singleton
operands remain possible, but two singletons cannot form S_C. Contradiction.

### B2. C is an ancestor of A

The owner charge raises A's cone bound to16. B is outside, so M_A=16 and every
gate except B lies in A's cone. The three-new-gates lemma gives M_C<=13.

Choose the first AND q on a C-to-A path. Its OR-side operand covers every
positive input, and its other operand R has support exactly{8}, by cleanliness
and productivity. There must be at least two OR gates outside C's cone in
addition to q to obtain the no-CN support of A: with just q and the final OR,
the remaining proper operand would have a common neighbor. The following
small gate-budget split makes this observation precise enough for deletion.

If M_C=13, exactly three gates of A's cone lie outside C's cone. They must be
q and two OR gates. Two ANDs and one OR could not create a no-CN output from
common-neighbor core signals. Thus every descendant of q is OR, including any
route to B (B is the only gate outside A's cone and is itself OR).

Replace q by R. Positive inputs are unchanged because q=R there. On an
independent input R=x8 while q=false; the only affected output paths are OR
paths, and both affected chosen outputs A and B already have singleton8 in
their supports. Their values are unchanged. C is not a descendant of q.
All retained ANDs are unaffected, so they remain clean and productive. Removing
q gives at most16 gates for the same three full-cover functions, contradicting17.

The only remaining possibility is M_C=12. This requires L_C=12 and S_C=N(8),
so C's cone is cost-tight. R cannot be a gate in that cone: singleton8 in R
would put raw input8 in C's cone, and N(8) subset S_C is exactly the reviewed
irrelevant-input extra charge, raising C's lower bound to13.

If R is raw x8, q<=x8 pointwise. Every chosen descendant output already has
an OR-only path from raw x8, which necessarily avoids the AND q. Replacing q
by free FALSE cannot change such an output: whenever q could matter, x8=true
already makes it true through that unaffected OR path. Other outputs are
unchanged; AND values only decrease on independent inputs, so cleanliness
is preserved. Restore productivity using the reviewed boundary-preserving
normalization if necessary. At most16 gates still produce the same three
full-cover functions, again contradicting17.

If R is a gate outside C's cone, it is an OR gate because its support is{8}.
There are only four gates of A's cone outside C's cone, including R,q,A.
The fourth must also be OR: if it were AND, A's last OR could obtain nonempty
support from at most one common-neighbor operand (R or a core signal), hence
could not be no-CN. Thus q is again the only AND outside C's cone; all its
descendants are OR. The q-to-R replacement from the M_C=13 case applies.

These cases exhaust M_C=12,13, including repeated operands, raw-only inputs,
OR intermediates before q and fan-out to B. They exclude all eight displayed
families. No implicit minimal-circuit assumption is used: deletion is followed
by the already reviewed productive normalization before the joint lower bound.

## Result and limits

The symmetric tight-core filter excludes42 families. The eight families in B
are disjoint from those42, so the combined proposal excludes50 of68 and leaves
18 exact support triples. The finite table verifies all arithmetic, adjacency,
owner, cost and support hypotheses, and stores the18 remaining triples. The
structural proof and finite code require independent review. No shared-prefix
circuit, solver verdict, Lean theorem or whole AAAA conclusion is claimed.
