# Forest, two-sink and partial-twins review snapshot

Independent mathematical/finite PASS, exactly as of the retained review.
Four new k3/r0 and three k4/r0 exclusions leave258 and112; k5/r0 was already
closed. Two-sink v1/v2 plus partial twins exclude51 of68 k3/r2 families,
leaving17. Full producer proofs, sources, complete input/output tables and
stdout/stderr, and independent recomputation/actual-DAG controls are retained.

The later forced-birth proposal is NOT part of this frozen PASS. No CNF cut,
SAT certificate, Lean theorem, arbitrary21-gate or global-shard result.
The companion no-common archive contains the independently reviewed complete
mixed census, k3/r3 exclusion, and pure k4/k5 relaxation witnesses. Those pure
classes remain open. No raw CNFs or solver binaries are included.

Extract anywhere and run python verify_manifest.py to verify every payload.
The original paths are retained in manifest.json; archived scripts retain
their original working-directory assumptions, rather than silently changing
the sources that produced the results. Logs and complete tables are portable.
