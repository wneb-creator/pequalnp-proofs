# Multiple irrelevant ancestor inputs with disjoint neighborhoods

For independent review. Extends the reviewed irrelevant-input-charge.md;
no implementation, CNF change, solver run or Lean claim.

In the same productive ambient-clean prefix, let W have proper singleton
support S, accepted residual-edge graph H, and M actual gate ancestors. Let
I be a set of distinct raw input vertices such that:

- every x_v for v in I is an actual ancestor of W;
- v is outside S and N(v) is contained in S for every v in I;
- N(v) and N(w) are disjoint for distinct v,w in I.

Then the strengthened partial-support bound is

    M >= |S| + |E(H)| + cover(H) - 1 + |I|.

## Distinct first ANDs

For each v choose a path from x_v to W and its first AND q_v. It exists
because an OR-only path would put v in S. One operand of q_v has v in its
support. Its other operand has nonempty support contained in N(v), by
productivity and cleanliness, hence contained in S.

The q_v are distinct. If q_v=q_w and their OR-only paths enter the same
operand, the other operand's nonempty support lies in N(v) intersect N(w),
which is empty. If they enter opposite operands, q_v is true on the input
{v,w}. That input is independent: an edge v-w would put w in N(v) subset S,
contrary to w outside S. Either case contradicts the hypotheses. This does
not assume disjoint paths or disjoint ancestor cones.

## Simultaneous deletion and counting

Restrict S to zero. At each named q_v, the other operand is false on every
independent residual input. Bypass q_v by that operand. It preserves all
independent-input values and only increases edge values. Perform the bypasses
in topological order. Earlier bypasses preserve the independent boundary and
monotone edge nondecrease at every later wire, so the argument remains valid
for each subsequent named gate. Any gate already pruned is already deleted.
There are at least |I| distinct original AND deletions.

For nonempty H, the usual pure-S OR-DAG count supplies another |S| original
OR deletions, disjoint from those ANDs. The partial-edge lower bound on the
retained clean circuit proves the claim. If H is empty and |S|>=1, at least
|S|-1 OR gates connect the distinct support inputs to W; the |I| AND gates
are additional, giving the same bound. If S is empty, the weaker required
bound M>=|I|-1 follows already from the distinct AND count. Full S cannot
trigger the outside-S input condition, preserving the free-TRUE exemption.

## Limitation for the current all-common-neighbor factor families

The concrete graph is C4-free and has minimum degree2. If S has a common
neighbor u and N(v) subset S for a vertex v outside S, then

    N(v) subset S subset N(u).

If v differs from u, two distinct neighbors of v give a C4 through u,v.
Thus v=u. There is at most one irrelevant vertex for every support having
a common neighbor. In fact it exists exactly when S=N(u).

Consequently the +2 charge cannot fire on any of the remaining k3/r0 factor
outputs. It cannot fire on their live prefix ancestors either. If an ancestor
support has no common neighbor, the proved productivity/ancestry lemma forces
all descendants to be OR and preserve that support. Such a wire cannot reach
a selected output whose larger support has a common neighbor. Empty support
also cannot trigger any irrelevant-input charge here, since every vertex has
positive degree. Thus the entire live prefix of an all-common-neighbor factor
family is outside the +2 condition.

The condition can still apply in the original DAG and other suffix families,
where live prefix supports without common neighbors are allowed. The finite
coverage table measures that broader potential; it does not assert that all
eligible inputs are actually ancestors of a particular output.

## Encoding scope

For +2, use a second penalty/threshold implication only when two actual raw
ancestor inputs satisfy the displayed neighborhood conditions. A support-only
test is insufficient. Existing first-charge p_g merges all input witnesses,
so it does not by itself identify two distinct inputs. Either retain per-input
witness flags or explicitly combine two guarded ancestor-port witnesses.
The latter has a quadratic port-pair cost. No implementation is proposed as
reviewed here; input/threshold counting requires separate code review.
