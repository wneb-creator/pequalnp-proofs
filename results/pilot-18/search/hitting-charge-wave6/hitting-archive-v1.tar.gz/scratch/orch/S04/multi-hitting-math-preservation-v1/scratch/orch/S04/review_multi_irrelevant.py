from pathlib import Path
import hashlib,itertools,json,collections,time
O=Path('/tmp/oec/pequalnp-pilot-18/orch/S04');I=O.parent/'S01';start=time.monotonic()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
handoff=I/'disjoint-charge-handoff.json';h=json.loads(handoff.read_text())
assert sha(handoff)=='c4ec0d309a0a8c7702629d51ab617138f59c5d663d4e80e972cd17cd7573582c'
for r in h['files']:
 p=Path(r['path']);assert p.is_relative_to(I) and p.is_file() and not p.is_symlink()
 assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
assert len(h['files'])==6
reported=json.loads((I/'disjoint-input-charge-coverage.json').read_text())
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
ES={frozenset(e) for e in E};EM=[(1<<a)|(1<<b) for a,b in E]
N=[{b if a==v else a for a,b in E if v in (a,b)} for v in range(11)]
assert all(len(n)>=2 for n in N)
assert all(len(N[a]&N[b])<=1 for a,b in itertools.combinations(range(11),2))
# Enumerate global compatible input sets first, independently of support masks.
compatible=[]
for mask in range(1,2048):
 vertices=[v for v in range(11) if mask>>v&1]
 if any(N[v]&N[w] or frozenset((v,w)) in ES for v,w in itertools.combinations(vertices,2)):continue
 required=set().union(*(N[v] for v in vertices))
 assert not(required&set(vertices))
 compatible.append(dict(inputs=vertices,required=sum(1<<v for v in required),forbidden=mask))
pairs=[r for r in compatible if len(r['inputs'])==2];triples=[r for r in compatible if len(r['inputs'])==3]
assert len(pairs)==14 and [r['inputs'] for r in triples]==[[0,1,3],[1,2,3],[1,2,7]]
assert max(len(r['inputs']) for r in compatible)==3
assert {tuple(r['inputs']) for r in reported['eligible_input_pairs']}=={tuple(r['inputs']) for r in pairs}
rows=[]
for support,old in enumerate(reported['support_rows']):
 S={v for v in range(11) if support>>v&1}
 qualifying=[r for r in compatible if not r['required']&~support and not r['forbidden']&support]
 maximum=max((len(r['inputs']) for r in qualifying),default=0)
 irrelevant=sorted(v for v in range(11) if v not in S and N[v]<=S)
 common=sorted(v for v in range(11) if S<=N[v])
 witnesses=sorted(r['inputs'] for r in qualifying if len(r['inputs'])==maximum) if maximum>=2 else []
 residual=[list(e) for e in E if not set(e)&S]
 expected=dict(support=support,support_size=len(S),irrelevant_inputs=irrelevant,common_neighbors=common,maximum_disjoint_charge=maximum,maximal_size_witnesses=witnesses,residual_edges=residual)
 assert expected==old,support
 if common:
  assert len(irrelevant)<=1
  assert all(v==u and S==N[u] for v in irrelevant for u in common)
 rows.append(expected)
classification=json.loads((I/'three-factor-position-classification.json').read_text())
assert sha(I/'three-factor-position-classification.json')==reported['classification_sha256']
remaining=[r for r in classification['families'] if not r['combined_excluded']]
supports=sorted({s for r in remaining for s in r['supports']})
assert len(remaining)==262 and len(supports)==43 and supports==reported['remaining_factor_supports']
assert all(rows[s]['maximum_disjoint_charge']<=1 for s in supports)
summary=dict(eligible_pairs=14,eligible_triples=3,charge2_supports=sum(r['maximum_disjoint_charge']>=2 for r in rows),nonempty_residual_charge2=sum(r['maximum_disjoint_charge']>=2 and bool(r['residual_edges']) for r in rows),charge3_supports=sum(r['maximum_disjoint_charge']>=3 for r in rows),maximum_charge=max(r['maximum_disjoint_charge'] for r in rows),distribution=dict(sorted(collections.Counter(r['maximum_disjoint_charge'] for r in rows).items())),remaining_families=262,remaining_factor_supports=43,remaining_factor_supports_with_charge2=0)
assert [summary[k] for k in ['charge2_supports','nonempty_residual_charge2','charge3_supports','maximum_charge']]==[202,132,9,3]
# Small exact arithmetic controls: separate rank thresholds, including the g=0/rank3 unit.
oldreview=json.loads((O/'irrelevant-input-review.json').read_text())
thresholds=[];arithmetic=0
for row in oldreview['existing_counter_thresholds']:
 g=row['gate'];bound=g+2;overflow=row['existing_overflow']
 for rank in (2,3):
  allowed=bound-rank
  threshold=None if allowed<0 else overflow-rank
  for weight in range(39+g):
   for penalty in (False,True):
    link=(not penalty) if allowed<0 else (not penalty or weight<allowed+1)
    assert ((weight<=bound) and link)==(weight+rank*penalty<=bound);arithmetic+=1
  thresholds.append(dict(gate=g,rank=rank,allowed_weight=allowed,threshold=threshold,unit_negative_penalty=(allowed<0)))
 for actual in range(4):
  for weight in range(39+g):
   separate=weight<=bound and all(actual<rank or weight+rank<=bound for rank in (1,2,3))
   assert separate==(weight+actual<=bound);arithmetic+=1
assert thresholds[1]['unit_negative_penalty'] and thresholds[1]['gate']==0 and thresholds[1]['rank']==3
# Actual clean DAGs with charged gates in overlapping cones; no target-size search.
def target(x):return any(x&e==e for e in EM)
def ev(gates,x):
 values=[bool(x>>i&1) for i in range(11)]+[False,True]
 for op,a,b in gates:values.append(values[a] and values[b] if op=='and' else values[a] or values[b])
 return values
cover_order=sorted(range(2048),key=lambda s:(s.bit_count(),s))
controls=[]
for group in pairs+triples:
 verts=group['inputs'];support=group['required'];S={v for v in range(11) if support>>v&1}
 residual=[e for e in E if not set(e)&S]
 for mode in range(3):
  gates=[]
  def add(op,a,b):gates.append((op,a,b));return 12+len(gates)
  def OR(xs):
   xs=list(xs);w=xs[0]
   for u in xs[1:]:w=add('or',w,u)
   return w
  edges={e:add('and',*e) for e in residual}
  extra=edges[residual[0]] if residual else 11
  charges={};prior=None
  for v in verts:
   b=OR(sorted(N[v])+[extra]+([prior] if prior is not None else []))
   if mode==2:b=add('or',b,b)
   q=add('and',v,b);charges[q]=b;prior=q
  sout=OR(sorted(S));out=OR([sout]+list(charges))
  if mode==1:out=OR([out]+list(edges.values()))
  if mode==2:
   if residual:out=add('or',out,extra)
   zero=add('or',11,11);out=add('or',out,zero);out=add('or',out,out)
   add('or',12,12)
  old=[ev(gates,x) for x in range(2048)]
  supp=lambda w:{v for v in range(11) if old[1<<v][w]}
  assert supp(out)==S
  for g,(op,a,b) in enumerate(gates):
   if op=='and':assert supp(a) and supp(b) and all(not old[x][13+g] for x in range(2048) if not target(x))
  cone=set();rawanc=set()
  def visit(w):
   if w<13:
    if w<11:rawanc.add(w)
    return
   if w in cone:return
   cone.add(w);_,a,b=gates[w-13];visit(a);visit(b)
  visit(out);assert set(verts)<=rawanc and set(charges)<=cone and len(charges)==len(verts)
  H=[em for e,em in zip(E,EM) if not set(e)&S and old[em][out]]
  cover=next(c for c in cover_order if all(c&e for e in H))
  lower=len(S)+len(H)+cover.bit_count()-1+len(verts)
  assert len(cone)>=lower
  oa=set()
  def orvisit(w):
   if w in oa:return
   oa.add(w)
   if w>=13 and gates[w-13][0]=='or':
    _,a,b=gates[w-13];orvisit(a);orvisit(b)
  orvisit(out);pure=S|{11}
  for g,(op,a,b) in enumerate(gates):
   if op=='or' and a in pure and b in pure:pure.add(13+g)
  pure_gates={w for w in oa&pure if w>=13};boundary={}
  for w in oa-pure:
   if w>=13:
    op,a,b=gates[w-13]
    if op=='or' and ((a in pure)!=(b in pure)):boundary[w]=b if a in pure else a
  assert len(pure_gates)+len(boundary)>=len(S)
  remap={i:i for i in range(13)};new=[]
  for g,(op,a,b) in enumerate(gates):
   w=13+g
   if w not in cone:continue
   if w in charges:remap[w]=remap[charges[w]]
   elif w in pure_gates:remap[w]=11
   elif w in boundary:remap[w]=remap[boundary[w]]
   else:new.append((op,remap[a],remap[b]));remap[w]=12+len(new)
  assert len(new)<=len(cone)-len(S)-len(verts)
  equal=0;nondecrease=0;strict_edges=0
  for x in range(2048):
   if x&support:continue
   nv=ev(new,x)
   for w in cone:
    assert old[x][w]<=nv[remap[w]];nondecrease+=1
    if not target(x):assert old[x][w]==nv[remap[w]];equal+=1
    elif x in EM and old[x][w]<nv[remap[w]]:strict_edges+=1
  controls.append(dict(inputs=verts,support=support,mode=mode,cone_size=len(cone),H=H,cover=cover,lower_bound=lower,charged_ANDs=charges,pure_OR_count=len(pure_gates),boundary_OR_count=len(boundary),remaining_gates=len(new),negative_wire_equalities=equal,pointwise_wire_nondecreases=nondecrease,strict_edge_gains=strict_edges,gates=gates,output=out,reduced_gates=new,redirect=remap))
# Overlapping-neighborhood control: two raw paths can share one first AND.
assert N[0]&N[2]=={10}
shared=[('or',0,2),('and',13,10),('or',5,9),('or',15,10),('or',16,14)]
assert all(not ev(shared,x)[14] for x in range(2048) if not target(x))
assert {v for v in range(11) if ev(shared,1<<v)[17]}=={5,9,10}
result=dict(verdict='PASS_MULTI_INPUT_MATHEMATICS_COVERAGE_AND_UNIMPLEMENTED_OUTLINE',review_source_sha256=sha(Path(__file__)),handoff_sha256=sha(handoff),bound_artifacts=6,summary=summary,global_compatible_sets=compatible,all_2048_rows_exactly_match=True,threshold_specifications=thresholds,threshold_arithmetic_checks=arithmetic,additive_unconditional_link_counts=dict(rank2_variables=204,rank2_clauses=3621,rank3_variables=221,rank3_clauses=3689),alternative_fullsupport_guarded_link_counts=dict(rank2_clauses=3791,rank3_clauses=4029),actual_DAG_controls=controls,negative_wire_equalities=sum(c['negative_wire_equalities'] for c in controls),pointwise_wire_nondecreases=sum(c['pointwise_wire_nondecreases'] for c in controls),strict_edge_gains=sum(c['strict_edge_gains'] for c in controls),overlapping_neighborhood_shared_AND_control=shared,seconds=time.monotonic()-start,solver_run=False,Lean_build=False,scope='Proper-support productive ambient-clean prefix; actual raw ancestry plus pairwise-disjoint neighborhoods. No production encoding or CNF accepted, no new exclusion of the262 all-common-neighbor families.')
(O/'multi-irrelevant-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['verdict','review_source_sha256','bound_artifacts','summary','threshold_arithmetic_checks','negative_wire_equalities','pointwise_wire_nondecreases','strict_edge_gains','seconds']}))
print('51 actual overlapping-cone DAGs pass; no 17-gate construction or solver search performed.')
