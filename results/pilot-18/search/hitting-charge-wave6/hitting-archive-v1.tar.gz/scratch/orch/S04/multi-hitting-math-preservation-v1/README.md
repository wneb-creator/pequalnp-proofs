# Multi-input and neighborhood-hitting charge preservation

S04 independent mathematical, finite-enumeration, actual-DAG and unimplemented
encoding-outline PASS. The proper-support, productive ambient-clean theorem is
M >= |S| + |E(H)| + cover(H) - 1 + eta(I), where I consists of ACTUAL irrelevant
raw ancestors and eta is their neighborhood hitting number. H may be partial
or empty. The package retains S01's proofs/finite tables/full logs and S04's
independent algorithms/full logs/75 actual-DAG controls, including shared first
ANDs and overlapping ancestor cones. There are24 minimal +2 and5 minimal +3
triggers,224/11 potentially eligible support masks. This is not circuit search.

There is NO stronger bound on the262 remaining common-neighbor factor families
or their factor-ancestor unions. No Lean theorem, global/shard refutation, SAT
certificate, or actual generated-cut acceptance is claimed. Future cut code
requires independent delta review. No raw CNFs or compiled files are included.

Exact original source paths, sizes and SHA256 hashes are recorded in manifest.
Historical report snapshot is intentional. Review sources retain their original
absolute workspace paths; they are evidence and must not be rerun over the
live producer outputs merely to regenerate timing-dependent JSON. For replay,
copy this archive's scratch tree to an isolated scratch root and rewrite only
the fixed root path in private copies of the two review scripts; the disjoint
handoff's six path fields also need mapping. Its exact original hash assertion
must then refer to the preserved original handoff, while only path lookup uses
the mapped root. Neither rewriting nor replay is part of this archive claim.

Dependencies: the included prior +1 review binds exact ancestor-counter IDs;
the included partial-edge/support-cost mathematics supplies the base theorem.
The complete earlier +1 and253/515 classification archives are retained intact
in the sibling math-review-delivery-v1 directory, with their own manifests.
