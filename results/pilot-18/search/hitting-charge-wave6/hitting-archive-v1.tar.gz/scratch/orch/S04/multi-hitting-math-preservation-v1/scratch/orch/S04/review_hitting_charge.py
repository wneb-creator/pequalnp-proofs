from pathlib import Path
import hashlib,itertools,json,collections,time
O=Path('/tmp/oec/pequalnp-pilot-18/orch/S04');I=O.parent/'S01';start=time.monotonic()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
math=I/'neighborhood-hitting-charge.md';source=I/'count_hitting_input_charges.py';datafile=I/'hitting-input-charge-coverage.json'
assert sha(math)=='f0af499ec1028b8093ec953d6654d286f20c9ddd035b19fbb485ad0b9ecb2ae6'
assert sha(source)=='a6c35817311cff2075e09888fda084bb95a8e9c504113c95f7fe6b573217bd84'
data=json.loads(datafile.read_text());assert data['math_sha256']==sha(math) and data['source_sha256']==sha(source)
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
EM=[(1<<a)|(1<<b) for a,b in E]
N=[{b if a==v else a for a,b in E if v in(a,b)} for v in range(11)]
NM=[sum(1<<v for v in n) for n in N]
ind=[s for s in range(2048) if not any(s&e==e for e in EM)];assert len(ind)==125
# Independent owner-cover DP instead of searching all2048 owner subsets.
eta={};witness={};groups_checked=0;feasible_groups=0
for mask in ind:
 dp={0:(0,0)}
 for owner in range(11):
  fresh=dict(dp)
  for covered,(cost,chosen) in dp.items():
   nxt=covered|(NM[owner]&mask);candidate=(cost+1,chosen|(1<<owner))
   if candidate<fresh.get(nxt,(99,0)):fresh[nxt]=candidate
  dp=fresh
 eta[mask],witness[mask]=dp[mask]
 def partitions(vertices):
  if not vertices:yield [];return
  v=vertices[0]
  for part in partitions(vertices[1:]):
   yield [(v,)]+part
   for i in range(len(part)):yield part[:i]+[(v,)+part[i]]+part[i+1:]
 minimum=99
 for partition in partitions([v for v in range(11) if mask>>v&1]):
  groups_checked+=1;owner_sets=[]
  for group in partition:
   common=set(range(11))
   for v in group:common &= N[v]
   if not common:break
   owner_sets.append(common)
  else:
   feasible_groups+=1;minimum=min(minimum,len(partition))
   D={min(s) for s in owner_sets}
   assert len(D)<=len(partition) and all(D&N[v] for v in range(11) if mask>>v&1)
 assert minimum==eta[mask]
for rec in data['input_sets']:assert (eta[rec['input_mask']],witness[rec['input_mask']])==(rec['eta'],rec['witness'])
triggers={rank:[mask for mask in ind if eta[mask]>=rank and not any(other!=mask and other&mask==other and eta[other]>=rank for other in ind)] for rank in (2,3)}
for rank in (2,3):
 assert triggers[rank]==[r['mask'] for r in data['minimal_threshold_witnesses'][str(rank)]]
assert len(triggers[2])==24 and len(triggers[3])==5 and max(eta.values())==3
old=json.loads((I/'disjoint-input-charge-coverage.json').read_text());rows=[];subset_trigger_checks=0
for support,rec in enumerate(data['support_rows']):
 irrelevant=sum(1<<v for v in range(11) if not support>>v&1 and not NM[v]&~support)
 assert irrelevant in eta
 expected=dict(support=support,irrelevant_input_mask=irrelevant,hitting_charge=eta[irrelevant],hitting_witness=witness[irrelevant],disjoint_charge=old['support_rows'][support]['maximum_disjoint_charge'],residual_edges=[e for e in EM if not e&support])
 assert rec==expected and eta[irrelevant]>=expected['disjoint_charge']
 assert not witness[irrelevant]&~support
 sub=irrelevant
 while True:
  for rank in (2,3):
   assert (eta[sub]>=rank)==any(sub&t==t for t in triggers[rank]);subset_trigger_checks+=1
  if sub==0:break
  sub=(sub-1)&irrelevant
 rows.append(expected)
summary=dict(independent_sets=125,eta2_minimal_triggers=24,eta3_minimal_triggers=5,supports_charge2=sum(r['hitting_charge']>=2 for r in rows),supports_charge3=sum(r['hitting_charge']>=3 for r in rows),nonempty_residual_charge2=sum(r['hitting_charge']>=2 and bool(r['residual_edges']) for r in rows),improved_over_disjoint=sum(r['hitting_charge']>r['disjoint_charge'] for r in rows),distribution=dict(sorted(collections.Counter(r['hitting_charge'] for r in rows).items())))
assert [summary[k] for k in ['supports_charge2','supports_charge3','nonempty_residual_charge2','improved_over_disjoint']]==[224,11,143,24]
# New overlapping-neighborhood patterns only: no rerun of the disjoint circuit controls.
new_patterns=[]
for rank,patterns in triggers.items():
 for mask in patterns:
  verts=[v for v in range(11) if mask>>v&1]
  pack=max(len(sub) for count in range(len(verts)+1) for sub in itertools.combinations(verts,count) if all(not N[v]&N[w] for v,w in itertools.combinations(sub,2)))
  if pack<rank:new_patterns.append((rank,mask,pack))
assert len(new_patterns)==12

def F(x):return any(x&e==e for e in EM)
def evaluate(gates,x,bypasses=None):
 val=[bool(x>>v&1) for v in range(11)]+[False,True]
 for g,(op,a,b) in enumerate(gates):
  if bypasses and 13+g in bypasses:val.append(val[bypasses[13+g]])
  else:val.append(val[a] and val[b] if op=='and' else val[a] or val[b])
 return val
controls=[]
for rank,mask,pack in new_patterns:
 vertices=[v for v in range(11) if mask>>v&1]
 chosen=[v for v in range(11) if witness[mask]>>v&1]
 groups={u:[] for u in chosen}
 for v in vertices:groups[next(u for u in chosen if u in N[v])].append(v)
 assert all(groups.values()) and len(groups)==rank
 support=set().union(*(N[v] for v in vertices));sm=sum(1<<v for v in support)
 residual=[e for e in E if not set(e)&support]
 for mode in (0,1):
  gates=[]
  def add(op,a,b):gates.append((op,a,b));return 12+len(gates)
  def OR(xs):
   xs=list(xs);w=xs[0]
   for v in xs[1:]:w=add('or',w,v)
   return w
  edges={e:add('and',*e) for e in residual};extra=edges[residual[0]] if residual else 11
  bypasses={};prior=None
  for owner,members in groups.items():
   u=OR(members);v=OR([owner,extra]+([prior] if prior is not None else []))
   q=add('and',u,v);bypasses[q]=v;prior=q
  out=OR(sorted(support)+list(bypasses)+(list(edges.values()) if mode else []))
  old=[evaluate(gates,x) for x in range(2048)]
  supp=lambda w:{v for v in range(11) if old[1<<v][w]}
  assert supp(out)==support
  for g,(op,a,b) in enumerate(gates):
   if op=='and':assert supp(a) and supp(b) and all(not old[x][13+g] for x in range(2048) if not F(x))
  eq=0;inc=0;strict=0
  for x in range(2048):
   if x&sm:continue
   new=evaluate(gates,x,bypasses)
   for wire in range(13,len(new)):
    assert old[x][wire]<=new[wire];inc+=1
    if not F(x):assert old[x][wire]==new[wire];eq+=1
    elif x in EM and old[x][wire]<new[wire]:strict+=1
  controls.append(dict(input_mask=mask,eta=rank,disjoint_packing=pack,owner_cover=witness[mask],groups=groups,support=sm,mode=mode,gates=gates,output=out,simultaneous_alias_bypasses=bypasses,negative_wire_equalities=eq,pointwise_wire_nondecreases=inc,strict_edge_gains=strict))
result=dict(verdict='PASS_HITTING_CHARGE_MATHEMATICS_FINITE_TRIGGERS_AND_OUTLINE',review_source_sha256=sha(Path(__file__)),math_sha256=sha(math),producer_source_sha256=sha(source),producer_result_sha256=sha(datafile),summary=summary,owner_partition_checks=groups_checked,feasible_owner_partitions=feasible_groups,all_2048_support_rows_match=True,actual_ancestor_subset_trigger_checks=subset_trigger_checks,minimal_trigger_masks=triggers,new_overlap_pattern_count=12,new_actual_DAG_controls=controls,negative_wire_equalities=sum(c['negative_wire_equalities'] for c in controls),pointwise_wire_nondecreases=sum(c['pointwise_wire_nondecreases'] for c in controls),strict_edge_gains=sum(c['strict_edge_gains'] for c in controls),unimplemented_additive_encoding=dict(new_variables=221,new_clauses=3893,input_trigger_clauses=3366,rank2_trigger_clauses=408,rank3_trigger_clauses=85,unconditional_rank_links=34,guarded_alternative_clauses=4233,rank3_gate0='unit negative p3; never index threshold zero',do_not_sum_rank_flags=True),seconds=time.monotonic()-start,solver_run=False,Lean_build=False,scope='Proper-support productive ambient-clean prefix and actual irrelevant raw ancestor witnesses. Stronger than disjoint packing but no extra reach into the262 all-common-neighbor factor ancestor unions; no emitted cut or CNF accepted.')
(O/'hitting-charge-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['verdict','review_source_sha256','summary','owner_partition_checks','feasible_owner_partitions','actual_ancestor_subset_trigger_checks','negative_wire_equalities','pointwise_wire_nondecreases','strict_edge_gains','seconds']}))
