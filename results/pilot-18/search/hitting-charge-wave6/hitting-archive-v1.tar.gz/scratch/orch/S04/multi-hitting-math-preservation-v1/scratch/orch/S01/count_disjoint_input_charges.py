#!/usr/bin/env python3
"""Finite graph coverage; no claims about actual ancestor reachability."""
import hashlib
import itertools
import json
from collections import Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parent
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
   (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
N=[sum(1<<(b if a==v else a) for a,b in E if v in(a,b)) for v in range(11)]
assert min(n.bit_count() for n in N)==2
assert all((N[u]&N[v]).bit_count()<=1 for u,v in itertools.combinations(range(11),2))
pairs=[]
for v,w in itertools.combinations(range(11),2):
    if N[v]&N[w] or N[v]>>w&1:
        continue
    pairs.append(dict(inputs=[v,w],required_support=N[v]|N[w],
                      forbidden_support=(1<<v)|(1<<w)))
rows=[]
for s in range(2048):
    I=[v for v in range(11) if not s>>v&1 and N[v]&~s==0]
    disjoint=[]
    for size in range(2,len(I)+1):
        for subset in itertools.combinations(I,size):
            if all(not N[v]&N[w] for v,w in itertools.combinations(subset,2)):
                disjoint.append(subset)
    maximum=max([int(bool(I))]+[len(t) for t in disjoint])
    cn=[v for v in range(11) if N[v]&s==s]
    if cn:
        assert len(I)<=1
    if maximum>=2:
        assert not cn
    residual=[list(e) for e in E if not s&((1<<e[0])|(1<<e[1]))]
    rows.append(dict(support=s,support_size=s.bit_count(),irrelevant_inputs=I,
                     common_neighbors=cn,maximum_disjoint_charge=maximum,
                     maximal_size_witnesses=[list(t) for t in disjoint if len(t)==maximum],
                     residual_edges=residual))

classification=ROOT/'three-factor-position-classification.json'
c=json.loads(classification.read_text())
remaining=[r for r in c['families'] if not r['combined_excluded']]
supports=sorted(set(s for r in remaining for s in r['supports']))
assert all(rows[s]['maximum_disjoint_charge']<=1 for s in supports)
summary=dict(all_support_masks=2048,eligible_input_pairs=len(pairs),
             support_masks_with_charge_at_least2=sum(r['maximum_disjoint_charge']>=2 for r in rows),
             support_masks_with_charge_at_least3=sum(r['maximum_disjoint_charge']>=3 for r in rows),
             maximum_charge=max(r['maximum_disjoint_charge'] for r in rows),
             charge_distribution=dict(sorted(Counter(r['maximum_disjoint_charge'] for r in rows).items())),
             support_sizes_for_charge2=dict(sorted(Counter(r['support_size'] for r in rows if r['maximum_disjoint_charge']>=2).items())),
             nonempty_residual_supports_charge2=sum(r['maximum_disjoint_charge']>=2 and bool(r['residual_edges']) for r in rows),
             remaining_factor_families=len(remaining),remaining_distinct_factor_supports=len(supports),
             remaining_factor_supports_with_charge2=sum(rows[s]['maximum_disjoint_charge']>=2 for s in supports))
result=dict(verdict='PASS_FINITE_DISJOINT_NEIGHBORHOOD_COVERAGE',summary=summary,
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    math_sha256=hashlib.sha256((ROOT/'disjoint-neighborhood-input-charge.md').read_bytes()).hexdigest(),
    classification_sha256=hashlib.sha256(classification.read_bytes()).hexdigest(),
    eligible_input_pairs=pairs,support_rows=rows,remaining_factor_supports=supports,
    actual_ancestor_reachability_assumed=False,solver_run=False,Lean_proof=False)
(ROOT/'disjoint-input-charge-coverage.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(summary))
print(json.dumps({'source_sha256':result['source_sha256'],'math_sha256':result['math_sha256']}))
