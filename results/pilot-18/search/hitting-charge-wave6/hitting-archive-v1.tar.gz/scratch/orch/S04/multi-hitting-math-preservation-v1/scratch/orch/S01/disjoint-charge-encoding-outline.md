# Optional encoding outline for multiple input charges

Unimplemented, pending independent mathematical and later code review.
This is an additive proposal relative to the current +1 variant. No generated
CNF or active worker has been changed.

The finite graph coverage source count_disjoint_input_charges.py reports
14eligible input pairs and3eligible input triples with pairwise-disjoint
neighborhoods. There are202support masks allowing at least one pair,132with
nonempty residual graph, and9support masks allowing a triple. None of the
all-common-neighbor factor family supports, or their live productive prefix
ancestors, can trigger a pair. Thus the value is for broader suffix cases.

Introduce an I[g,v] witness bit for each of17prefix outputs and11raw inputs:
187bits. It need only be forced when v is both irrelevant for support(g) and
an actual raw ancestor. For each h<=g and each left/right operand selector,
copy the reviewed +1 trigger clause, replacing its p_g literal by I[g,v].
This adds3366clauses and forces every genuine input witness. The other
direction is unnecessary for existential completeness: for an actual circuit,
choose the bits to represent precisely its true triggers. Spurious true
bits only strengthen the cost constraint, so cannot create a false witness.

Introduce17new p2[g] bits and for each of the14eligible vertex pairs(v,w),
add the clause

    NOT I[g,v] OR NOT I[g,w] OR p2[g].

This adds238clauses. Link p2[g] to the already-built ancestor-cost counter at
the threshold that imposes a two-unit tighter bound:17more clauses. The
total additive size is204variables and3621clauses. Existing +1 clauses are
preserved. p2 need not imply p1 explicitly: genuine pairs already trigger
the existing +1 clauses, and an actual assignment can choose exact flags.

For +3 add17p3bits,51triple-trigger clauses and17threshold links. Together
with +2 this is221variables and3689clauses. The three input triples are
{0,1,3}, {1,2,3}, and {1,2,7}. A negative allowed counter bound means the
corresponding p3 must be false, not an out-of-range counter lookup; e.g. at
g=0 the original bound2 cannot absorb a penalty3. The implementation must
handle that case explicitly and independently verify threshold indexing.

The three cardinality consequences are separate bounds, not summed penalties:
p1 tightens by1, p2 by2, p3 by3. Adding p1+p2+p3 as numeric literals to the
same original count would incorrectly charge6 for a triple. Reuse separate
threshold implications or one properly weighted/exact count representation.

This outline provides exact combinatorial clause/variable estimates assuming
the existing counter thresholds can be reused. It is not an implementation
review and does not certify any performance improvement.
