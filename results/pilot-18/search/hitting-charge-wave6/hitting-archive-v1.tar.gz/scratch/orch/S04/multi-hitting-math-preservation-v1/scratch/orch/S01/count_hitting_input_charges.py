#!/usr/bin/env python3
import hashlib
import itertools
import json
from collections import Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parent
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
   (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
EM=[(1<<a)|(1<<b) for a,b in E]
N=[sum(1<<(b if a==v else a) for a,b in E if v in(a,b)) for v in range(11)]
IND=[a for a in range(2048) if all(a&e!=e for e in EM)]
assert len(IND)==125
sets=sorted(range(2048),key=lambda x:(x.bit_count(),x))
eta={};witness={}
for a in IND:
    witness[a]=next(d for d in sets if all(d&N[v] for v in range(11) if a>>v&1))
    eta[a]=witness[a].bit_count()
thresholds={}
for t in range(2,max(eta.values())+1):
    thresholds[t]=[a for a in IND if eta[a]>=t and
                   all(eta[a^(1<<v)]<t for v in range(11) if a>>v&1)]
for a in IND:
    for t,patterns in thresholds.items():
        assert (eta[a]>=t)==any(a&p==p for p in patterns)

old=json.loads((ROOT/'disjoint-input-charge-coverage.json').read_text())
rows=[]
for s in range(2048):
    irrelevant=sum(1<<v for v in range(11) if not s>>v&1 and not N[v]&~s)
    assert irrelevant in eta
    charge=eta[irrelevant]
    packing=old['support_rows'][s]['maximum_disjoint_charge']
    assert charge>=packing
    cn=[v for v in range(11) if N[v]&s==s]
    if cn:assert charge<=1
    rows.append(dict(support=s,irrelevant_input_mask=irrelevant,
                     hitting_charge=charge,hitting_witness=witness[irrelevant],
                     disjoint_charge=packing,
                     residual_edges=[e for e in EM if not e&s]))
summary=dict(independent_input_sets=len(IND),maximum_hitting_charge=max(eta.values()),
    minimal_threshold_counts={t:len(p) for t,p in thresholds.items()},
    minimal_threshold_sizes={t:dict(Counter(p.bit_count() for p in ps)) for t,ps in thresholds.items()},
    support_charge_distribution=dict(sorted(Counter(r['hitting_charge'] for r in rows).items())),
    support_masks_improved_over_disjoint=sum(r['hitting_charge']>r['disjoint_charge'] for r in rows),
    supports_at_least2=sum(r['hitting_charge']>=2 for r in rows),
    supports_at_least3=sum(r['hitting_charge']>=3 for r in rows),
    nonempty_residual_supports_at_least2=sum(r['hitting_charge']>=2 and bool(r['residual_edges']) for r in rows))
result=dict(verdict='PASS_FINITE_NEIGHBORHOOD_HITTING_CERTIFICATE',summary=summary,
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    math_sha256=hashlib.sha256((ROOT/'neighborhood-hitting-charge.md').read_bytes()).hexdigest(),
    input_sets=[dict(input_mask=a,eta=eta[a],witness=witness[a]) for a in IND],
    minimal_threshold_witnesses={t:[dict(mask=p,vertices=[v for v in range(11) if p>>v&1]) for p in ps] for t,ps in thresholds.items()},
    support_rows=rows,solver_run=False,Lean_proof=False,encoding_implemented=False)
(ROOT/'hitting-input-charge-coverage.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(summary))
print(json.dumps({'source_sha256':result['source_sha256'],'math_sha256':result['math_sha256']}))
