# Neighborhood-hitting charge for irrelevant ancestor inputs

Mathematical extension for independent review; no encoding, solver or Lean
claim. It contains the disjoint-neighborhood charge as a special case.

Use the productive ambient-clean prefix and partial-support setup of the
reviewed +1 charge. Let I be any set of actual raw ancestor inputs v outside
output support S, with N(v) subset S. They need not have disjoint neighborhoods.
Define eta(I) to be the smallest size of a vertex set D meeting every N(v)
for v in I. Equivalently every input in I has a neighbor in D. Because all
these neighborhoods lie in S, D can be chosen inside S. In this concrete
graph all neighborhoods are nonempty; eta(empty)=0.

Then the strengthened ancestor lower bound is

    M >= |S| + |E(H)| + cover(H) - 1 + eta(I).

## Proof of the number of distinct charged ANDs

For each v in I, choose a path from raw input v to the output and its first
AND q_v. The other operand of q_v has nonempty support contained in N(v),
and therefore in S. The vertices in I are independent: if v-w were an edge,
w would lie in N(v) subset S, contradicting w outside S.

Partition I by the chosen first AND. All the assigned input paths for a
single AND q enter the same operand. If two entered opposite sides, q would
be true on their independent two-vertex input, contradicting cleanliness.
Choose one supported vertex u_q from q's other operand, which is nonempty by
productivity. Cleanliness makes u_q a neighbor of every input assigned to q.
Thus the vertices u_q, one per distinct charged AND, meet all neighborhoods
N(v). Their number is at most the number of charged ANDs. By minimality of
eta(I), at least eta(I) distinct ANDs have been identified.

Restrict S to zero and bypass each such AND by its other operand. As in the
reviewed +1 proof, every bypass preserves all independent-input values and
only increases edge values. The simultaneous bypass argument is unchanged:
earlier bypasses preserve the boundary used by later ones; already-pruned
named gates already count as deleted. For nonempty H, combine these AND
deletions with |S| distinct support-OR deletions and the partial-edge theorem.
For H empty, at least |S|-1 OR nodes and these distinct ANDs give the same
bound when S is nonempty; for S empty the resulting bound is weaker than
the AND count alone. This proves the displayed inequality.

Pairwise-disjoint neighborhoods require distinct vertices of D, recovering
the earlier |I| charge. The hitting-number bound may be stronger when several
overlapping neighborhoods have no common vertex.

## Finite trigger enumeration

The inputs of a potential witness set I must be independent, and a support
allowing them exists exactly when their neighborhood union is disjoint from
I. For the concrete graph, enumerate all125 independent input sets and compute
eta by exhaustive checking of2048 possible D. For each threshold t retain
only inclusion-minimal input sets with eta>=t. A trigger for one of those sets
requires every member to be an actual irrelevant ancestor, using the proposed
per-input witness flags. The finite script independently checks the resulting
threshold characterization for every independent input set and all2048
support masks. Its output is a graph certificate, not a circuit reachability
certificate or a checked encoding.

As before, this cannot affect a support with a common neighbor in this C4-free
minimum-degree2 graph: there is at most one irrelevant input for such a
support. It therefore does not directly reduce the262 current all-common-
neighbor support families or their live prefix ancestors.
