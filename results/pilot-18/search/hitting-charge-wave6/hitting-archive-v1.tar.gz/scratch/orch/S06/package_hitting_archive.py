#!/usr/bin/env python3
"""Preserve frozen hitting cuts, math/reviews/commands; never read runtime outputs."""
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import time

ROOT = Path('/tmp/oec/pequalnp-pilot-18')
OWN = ROOT/'orch/S06'
REPO = Path('/workspace/pequalnp-proofs')
ARCHIVE = OWN/'hitting-archive-v1'
ORIGINAL_SHA = '38d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08'
HANDOFF_SHA = '88556b6479b8b1ab2676ba63d376df475eab7d6401692af7516a30fe59391351'
REVIEW_SHA = '0ed0ac84baea1a88bf665fea4e6b78aff41b41c3993f1044d84f3665537a417d'
COMMANDS_SHA = '948ac6c2a8d186f1bfdc1b2e8473bb41df28bf6922a6e291bdf005a618454a06'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def sha(path):
    return digest(path.read_bytes())


def read(path):
    return json.loads(path.read_text())


def dump(path, value):
    path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')


def main():
    started = time.monotonic()
    ARCHIVE.mkdir(mode=0o700)
    original_path = ROOT/'original-dag-strong/original.cnf'
    original = original_path.read_bytes()
    assert digest(original) == ORIGINAL_SHA
    original_body = original.split(b'\n',1)[1]
    handpath = OWN/'hitting-charge-handoff.json'
    assert sha(handpath) == HANDOFF_SHA
    handoff = read(handpath)
    reviewpath = ROOT/'orch/S08/hitting-charge-review/review.json'
    assert sha(reviewpath) == REVIEW_SHA
    assert read(reviewpath)['verdict'] == 'PASS_FINAL_TEN_HITTING_INPUT_CHARGE_DELTAS_AND_CONTROLS'
    assert sha(OWN/'hitting-offline-plan/commands-manifest.json') == COMMANDS_SHA
    paths = set()

    def add(path):
        assert path.exists(),path
        if path.is_dir():
            paths.update(p for p in path.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc')
        else:
            paths.add(path)

    add(handpath)
    for name,pin in handoff['files'].items():
        path = OWN/name
        assert path.stat().st_size == pin['bytes'] and sha(path) == pin['sha256'],path
        add(path)
    for case in handoff['family']:
        parent = Path(case['parent'])
        assert sha(parent) == case['parent_cnf_sha256']
        assert sha(parent.with_suffix('.json')) == case['parent_metadata_sha256']
        add(parent)
        add(parent.with_suffix('.json'))
    for name in ['package_hitting_archive.py','restore_archive2_cnfs.py','offline_checked_cadical.py',
                 'prepare_hitting_commands.py','hitting-offline-plan','hitting-commands.stdout',
                 'hitting-commands.stderr','hitting-commands.execution.json',
                 'hitting-handoff.stdout','hitting-handoff.stderr','hitting-handoff.execution.json']:
        add(OWN/name)
    add(OWN/'archive-wave1/reproduction')
    add(original_path.with_suffix('.json'))
    add(ROOT/'lean-setup/validate_sat_candidate.py')
    add(ROOT/'orch/S04/multi-hitting-math-preservation-v1')
    for name in ['multi-hitting-math-preservation-handoff.json','multi-hitting-preservation.stdout.log','multi-hitting-preservation.stderr.log']:
        add(ROOT/'orch/S04'/name)
    add(ROOT/'orch/S08/hitting-charge-review')
    for name in ['review_hitting_charge.py','hitting-charge-review.stdout','hitting-charge-review.stderr',
                 'offline-runner-review/review.json','offline-real-case13-review/review.json',
                 'charge-wave5-delivery-review/review.json']:
        add(ROOT/'orch/S08'/name)
    add(REPO/'results/orch/lemmas/S06-solver-performance.md')
    # Explicit immutable-source allowlist only. No glob under any solver or supervisor output.
    files, source_map, recipes = {}, [], []

    def put(relative, raw, source):
        relative = Path(relative)
        assert not relative.is_absolute() and '..' not in relative.parts
        record = {'path': str(relative),'bytes': len(raw),'sha256': digest(raw),'source_path': source}
        if str(relative) in files:
            assert files[str(relative)]['sha256'] == record['sha256']
            return
        destination = ARCHIVE/relative
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_bytes(raw)
        files[str(relative)] = record

    def generated(name, value):
        put(name,(json.dumps(value,indent=2,sort_keys=True)+'\n').encode(),'generated archive metadata')

    for path in sorted(paths):
        assert path.is_file() and not path.is_symlink(),path
        assert path.suffix not in ['.pyc','.o','.so'] and '__pycache__' not in path.parts,path
        if path.is_relative_to(ROOT):
            relative = Path('scratch')/path.relative_to(ROOT)
        else:
            assert path.is_relative_to(REPO),path
            relative = Path('repo')/path.relative_to(REPO)
        raw = path.read_bytes()
        assert not raw.startswith(b'\x7fELF'),path
        assert path.read_bytes() == raw,'source changed during snapshot: '+str(path)
        is_cnf = path.suffix == '.cnf'
        source_map.append({'archive_path': str(relative),'source_path': str(path),
            'bytes': len(raw),'sha256': digest(raw),'disposition': 'cnf_recipe' if is_cnf else 'payload'})
        if is_cnf:
            header,body = raw.split(b'\n',1)
            assert body.startswith(original_body),path
            suffix = body[len(original_body):]
            delta_path = Path('cnf-deltas')/(digest(suffix)+'.clauses')
            put(delta_path,suffix,'deduplicated suffix of pinned original CNF')
            recipes.append({'relative_path': str(relative),'source_path': str(path),
                'bytes': len(raw),'sha256': digest(raw),'header': header.decode('ascii'),
                'delta_path': str(delta_path),'delta_sha256': digest(suffix)})
        else:
            put(relative,raw,str(path))
    generated('cnf-recipes.json',{'parent_sha256': ORIGINAL_SHA,'parent_bytes': len(original),'recipes': recipes})
    generated('source-map.json',source_map)
    generated('summary.json',{'scope': 'Ten independently reviewed hitting-charge children and four unexecuted command recipes; no solver results or global/shard/Lean acceptance.',
        'hitting_handoff_sha256': HANDOFF_SHA,'actual_code_delta_review_sha256': REVIEW_SHA,
        'mathematics_review_sha256': handoff['mathematical_review_sha256'],
        'generator_source_sha256': handoff['generator_source_sha256'],'delta_sha256': handoff['delta_sha256'],
        'new_variables': 221,'new_clauses': 4233,'full_support_exempt': True,
        'commands_manifest_sha256': COMMANDS_SHA,'command_execution_by_packager': False,
        'running_directories_read': False,'runtime_outputs_included': False,
        'raw_CNF_payloads': 0,'compiled_payloads': 0,
        'cached_bytecode_policy': '__pycache__ and .pyc are absent from selected source expectations and payload; historical records preserved.',
        'prior_plus1_archive_sha256': 'aeb918872f1a57b4ab4e3fb9afd48176dfe5022718b639063a4fd3f40d1ed0fd'})
    text = '''# S06 reviewed hitting-charge reproduction package

All ten new children append the same reviewed4233-clause +2/+3 hitting-charge delta to exact previously reviewed +1 parents. S08 actual-code/delta review PASS is0ed0ac84baea1a88bf665fea4e6b78aff41b41c3993f1044d84f3665537a417d. S04 mathematical/finite PASS is e4df03fa7c9077847bf16e2850b67b0a0331b79559dd0ca718829c3cb8b50609. Exact source, controls, all emitted metadata/deltas/thresholds, full producer/control/checker-review diagnostics, and S04's complete disjoint/hitting math preservation are included. The S08 review here is an independent scalar/code audit, not a new SAT/UNSAT certificate.

The221 new bits11986..12206 are187 per-input actual-ancestry witnesses and17 flags each for rank2/rank3. There are3366 raw trigger implications,408 rank2 implications for24 minimal patterns,85 rank3 implications for5 minimal patterns, and374 full-support guarded threshold clauses. A rank k demands T<=g+2-k, never a sum of rank flags. Gate0/rank3 explicitly forbids p3 on proper support without indexing a nonexistent threshold0. Old indices, metadata fields and clause body bytes are unchanged. Minimum-cover/exact-threshold choices are existential; this is not a new RUP entailment or extension of every old auxiliary assignment. The math does not yield new exclusions of the262 common-neighbor k3/r0 factor families, and no runtime/exhaustion/Lean claim is made.

The four command recipes prioritize AAAO-RUP,T2,T3,T4, use the unchanged reviewed retained-proof runner, and were not executed by S06. Each allows600 solver seconds and a subsequent600 checker seconds,512MiB retained binaryDRAT,1536MiB solver AS/3072MiB checker AS. Main owns admission and detached supervision; a slot remains occupied through checker/validator/finalization. Only strict verified UNSAT or fully validated SAT may be accepted. Historical pending-review fields remain unchanged and are superseded by the actual-code review above. Launch records, active outputs, and all solver runtime results are excluded.

Every raw CNF is replaced by a portable recipe. Supply the original CNF with SHA25638d93ec59a86378a8434b232d19b2b53e8cbc3c715e81432ee94db59ca6ace08. A recipe is exactly its recorded header, original body, then a deduplicated stored ASCII suffix. No historical scratch path is needed for reconstruction; source paths in records are provenance only. Both11985-variable parents and12206-variable children are covered, including duplicate independent-review snapshots.

    python3 scratch/orch/S06/restore_archive2_cnfs.py ARCHIVE ORIGINAL.cnf --verify-only

Replace --verify-only with a fresh output directory to materialize all CNFs. The unchanged standard-library restorer checks every payload hash, recipe hash, header and clause count. Original generator sources/dependencies are retained under scratch/orch/S06/archive-wave1/reproduction/. The prior +1 archive aeb918872f1a57b4ab4e3fb9afd48176dfe5022718b639063a4fd3f40d1ed0fd retains its full older normalization/RUP/runner controls and terminal AAOA evidence; this package does not duplicate those runtime outputs.

manifest.json binds every payload; source-map.json maps payloads and CNF recipes to exact frozen sources. No compiled binaries or bytecode caches are selected, expected or archived. Binary solver/checker hashes remain in the command manifest. Full final package-build/reconstruction logs are external delivery files bound by hitting-archive-v1-handoff.json, avoiding self-referential manifests. Main alone copies/pushes the independently reviewed delivery.
'''
    put('README.md',text.encode(),'generated archive documentation')
    manifest = {'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'files': sorted(files.values(),key=lambda x:x['path']),
        'archived_bytes': sum(p['bytes'] for p in files.values()),'CNF_recipes': len(recipes),
        'raw_CNF_payloads': 0,'compiled_payloads': 0,'runtime_outputs': 0}
    dump(ARCHIVE/'manifest.json',manifest)
    command = ['python3','-B',str(ARCHIVE/'scratch/orch/S06/restore_archive2_cnfs.py'),
        str(ARCHIVE),str(original_path),'--verify-only']
    with (OWN/'hitting-archive-v1-restore.stdout').open('xb') as out,(OWN/'hitting-archive-v1-restore.stderr').open('xb') as err:
        result = subprocess.run(command,cwd=OWN,stdout=out,stderr=err,timeout=20)
    assert result.returncode == 0
    tarpath = OWN/'hitting-archive-v1.tar.gz'
    with tarpath.open('xb') as stream,gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
        for path in sorted(ARCHIVE.rglob('*')):
            if not path.is_file():
                continue
            info = tar.gettarinfo(str(path),arcname=str(path.relative_to(ARCHIVE)))
            info.uid = info.gid = info.mtime = 0
            info.uname = info.gname = ''
            info.mode = 0o644
            with path.open('rb') as data:
                tar.addfile(info,data)
    expected = {p['path']: p for p in files.values()}
    expected['manifest.json'] = {'bytes': (ARCHIVE/'manifest.json').stat().st_size,'sha256': sha(ARCHIVE/'manifest.json')}
    seen = set()
    with tarfile.open(tarpath,'r:gz') as tar:
        for member in tar:
            relative = Path(member.name)
            assert member.isfile() and not member.issym() and not member.islnk()
            assert not relative.is_absolute() and '..' not in relative.parts and member.name not in seen
            seen.add(member.name)
            raw = tar.extractfile(member).read()
            assert len(raw) == expected[member.name]['bytes'] and digest(raw) == expected[member.name]['sha256']
    assert seen == set(expected)
    record = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'status': 'PASS_LOCAL_PACKAGING_RECONSTRUCTION_PENDING_INDEPENDENT_DELIVERY_REVIEW',
        'source_sha256': sha(Path(__file__)),'tar_path': str(tarpath),'tar_sha256': sha(tarpath),
        'tar_bytes': tarpath.stat().st_size,'tar_members': len(seen),'manifest_files': len(files),
        'manifest_sha256': sha(ARCHIVE/'manifest.json'),'CNF_recipes': len(recipes),
        'restore_command': command,'restore_exit_code': result.returncode,
        'restore_stdout_sha256': sha(OWN/'hitting-archive-v1-restore.stdout'),
        'restore_stderr_sha256': sha(OWN/'hitting-archive-v1-restore.stderr'),
        'actual_code_review_sha256': REVIEW_SHA,'commands_manifest_sha256': COMMANDS_SHA,
        'solver_checker_Lean_launch': False,'running_directories_read': False,
        'runtime_outputs_included': False,'wall_seconds': time.monotonic()-started}
    dump(OWN/'hitting-archive-v1.record.json',record)
    print(json.dumps(record,indent=2,sort_keys=True))


if __name__ == '__main__':
    main()
