#!/usr/bin/env python3
"""Freeze review evidence and portable recipes; no solver or input mutation."""
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path('/tmp/oec/pequalnp-pilot-18')
OWN = ROOT/'orch/S06'
REPO = Path('/workspace/pequalnp-proofs')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def binding(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': sha(raw)}


def main():
    evidence = OWN/'hitting-charge-review-evidence'
    evidence.mkdir(mode=0o700)
    sources = [
        ROOT/'orch/S01/neighborhood-hitting-charge.md',
        ROOT/'orch/S01/count_hitting_input_charges.py',
        ROOT/'orch/S01/hitting-input-charge-coverage.json',
        ROOT/'orch/S01/hitting-input-charge-coverage.stdout.txt',
        ROOT/'orch/S01/hitting-input-charge-coverage.stderr.txt',
        ROOT/'orch/S01/disjoint-neighborhood-input-charge.md',
        ROOT/'orch/S01/disjoint-charge-encoding-outline.md',
        ROOT/'orch/S04/review_hitting_charge.py',
        ROOT/'orch/S04/hitting-charge-review.json',
        ROOT/'orch/S04/hitting-charge-review.stdout.log',
        ROOT/'orch/S04/hitting-charge-review.stderr.log',
        ROOT/'orch/S04/review_multi_irrelevant.py',
        ROOT/'orch/S04/multi-irrelevant-review.json',
        ROOT/'orch/S04/multi-irrelevant-review.stdout.log',
        ROOT/'orch/S04/multi-irrelevant-review.stderr.log',
        ROOT/'orch/S08/irrelevant-charge-final-review-v2/review.json',
        OWN/'add_irrelevant_input_charge.py',
        OWN/'irrelevant-charge-handoff.json',
        ROOT/'lean-setup/validate_sat_candidate.py',
        REPO/'results/pilot-18/search/search_l1342_shard17_ancestorreverse.py',
    ]
    evidence_records = []
    for i, source in enumerate(sources):
        destination = evidence/f'{i:02d}-{source.name}'
        raw = source.read_bytes()
        destination.write_bytes(raw)
        assert destination.read_bytes() == raw
        evidence_records.append({'source_path': str(source), 'snapshot_path': str(destination), **binding(destination)})
    controls = json.loads((OWN/'hitting-charge-v1/controls.json').read_text())
    execution = json.loads((OWN/'hitting-charge-v1.execution.json').read_text())
    assert execution['exit_code'] == 0
    files = sorted((OWN/'hitting-charge-v1').rglob('*'))+sorted(evidence.iterdir())
    files += [OWN/name for name in ['add_hitting_input_charge.py','control_hitting_input_charge.py',
        'prepare_hitting_handoff.py','hitting-charge-v1-README.md','hitting-charge-plan.md',
        'hitting-charge-v1.stdout','hitting-charge-v1.stderr','hitting-charge-v1.execution.json']]
    bindings = {str(p.relative_to(OWN)): binding(p) for p in files if p.is_file()}
    recipes = []
    for case in controls['family']:
        directory = OWN/'hitting-charge-v1'/case['name']
        recipes.append({'name': case['name'], 'operation': 'replace_dimacs_header_then_append_ascii_clauses',
            'parent_sha256': case['parent_cnf_sha256'], 'parent_metadata_sha256': case['parent_metadata_sha256'],
            'new_header': f"p cnf {case['variables']} {case['clauses']}\n",
            'append_artifact': str((directory/'delta.clauses').relative_to(OWN)),
            'append_sha256': case['delta_sha256'],
            'expected_cnf_sha256': case['cnf_sha256'], 'expected_cnf_bytes': (directory/'instance.cnf').stat().st_size})
    result = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'status': 'READY_FOR_S08_ACTUAL_CODE_DELTA_REVIEW_NO_LAUNCH',
        'generator_source_sha256': binding(OWN/'add_hitting_input_charge.py')['sha256'],
        'control_source_sha256': binding(OWN/'control_hitting_input_charge.py')['sha256'],
        'controls_sha256': binding(OWN/'hitting-charge-v1/controls.json')['sha256'],
        'mathematical_review_sha256': binding(ROOT/'orch/S04/hitting-charge-review.json')['sha256'],
        'parent_actual_review_sha256': binding(ROOT/'orch/S08/irrelevant-charge-final-review-v2/review.json')['sha256'],
        'delta_sha256': controls['family'][0]['delta_sha256'],
        'added_variables': 221, 'added_clauses': 4233, 'full_support_exempt': True,
        'priority': ['AAAO-RUP','T1','T2','T3','T4'], 'family': controls['family'],
        'portable_CNF_recipes': recipes, 'evidence': evidence_records, 'files': bindings,
        'parent_recipe_archive': {'path': str(OWN/'charge-archive-v1.tar.gz'),
            'sha256': 'aeb918872f1a57b4ab4e3fb9afd48176dfe5022718b639063a4fd3f40d1ed0fd',
            'handoff_sha256': '29be436c4c78c47632e987d0df17f5b25357e00f407067f2933817c6bfae4677'},
        'scope': 'Fresh reviewed-math restrictions, actual implementation review pending; no solver/checker/Lean/production launch; old CNFs and indices unchanged; no every-old-aux-assignment extension or RUP claim.'}
    destination = OWN/'hitting-charge-handoff.json'
    destination.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status': result['status'], 'handoff': str(destination),
        'handoff_sha256': binding(destination)['sha256'], 'files': len(bindings),
        'evidence_snapshots': len(evidence_records), 'portable_recipes': len(recipes)}))


if __name__ == '__main__':
    main()
