#!/usr/bin/env python3
"""Append reviewed +2/+3 hitting-charge restrictions to fresh +1 children.

No solver/checker is invoked. New mathematical restrictions are not RUP
consequences of the old CNF. All parent clauses and variable IDs are retained.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = Path('/tmp/oec/pequalnp-pilot-18')
OWN = ROOT / 'orch/S06'
REPO = Path('/workspace/pequalnp-proofs')
PINS = {
    OWN/'add_irrelevant_input_charge.py': '56da4e9f313a18cabbcb582dffd999b212f8858e110c43c9f5dd7fb2c778b27d',
    ROOT/'orch/S01/neighborhood-hitting-charge.md': 'f0af499ec1028b8093ec953d6654d286f20c9ddd035b19fbb485ad0b9ecb2ae6',
    ROOT/'orch/S01/hitting-input-charge-coverage.json': '9b6c33623fa75e9c1a7796cd5e2c589b5e7bdb01d04488b31b183007f72e553f',
    ROOT/'orch/S04/hitting-charge-review.json': 'e4df03fa7c9077847bf16e2850b67b0a0331b79559dd0ca718829c3cb8b50609',
    ROOT/'orch/S08/irrelevant-charge-final-review-v2/review.json': 'b0af769b67da5f0b2f42aa1d4e341e217556b56cf17ea3a7a7aa5ffe9a0a2d7b',
}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(raw):
    import hashlib
    return hashlib.sha256(raw).hexdigest()


def sha(path):
    return digest(path.read_bytes())


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')


def load_dependencies():
    for path, expected in PINS.items():
        require(sha(path) == expected, 'review/source pin mismatch: '+str(path))
    spec = importlib.util.spec_from_file_location('s06_frozen_charge1', OWN/'add_irrelevant_input_charge.py')
    one = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(one)
    coverage = json.loads((ROOT/'orch/S01/hitting-input-charge-coverage.json').read_text())
    review = json.loads((ROOT/'orch/S04/hitting-charge-review.json').read_text())
    parent_review = json.loads((ROOT/'orch/S08/irrelevant-charge-final-review-v2/review.json').read_text())
    require(review['verdict'] == 'PASS_HITTING_CHARGE_MATHEMATICS_FINITE_TRIGGERS_AND_OUTLINE', 'math review not PASS')
    require(review['producer_result_sha256'] == PINS[ROOT/'orch/S01/hitting-input-charge-coverage.json'], 'coverage review binding')
    require(review['math_sha256'] == PINS[ROOT/'orch/S01/neighborhood-hitting-charge.md'], 'math review binding')
    require(parent_review['verdict'] == 'PASS_FINAL_TEN_IRRELEVANT_INPUT_CHARGE_DELTAS_AND_RUP_COMPATIBILITY', 'parent review not PASS')
    patterns = {int(k): [p['vertices'] for p in v] for k, v in coverage['minimal_threshold_witnesses'].items()}
    require(set(patterns) == {2, 3} and len(patterns[2]) == 24 and len(patterns[3]) == 5, 'wrong pattern dimensions')
    for k, rows in coverage['minimal_threshold_witnesses'].items():
        require([p['mask'] for p in rows] == review['minimal_trigger_masks'][k], 'independent pattern review mismatch')
        for p in rows:
            require(p['vertices'] == sorted(set(p['vertices'])) and all(0 <= v < 11 for v in p['vertices']), 'bad vertices')
            require(sum(1 << v for v in p['vertices']) == p['mask'], 'mask mismatch')
    return one, patterns, parent_review


def inspect_parent(raw, meta, one):
    require(meta['variables'] == 11985 and 'neighborhood_hitting_charge' not in meta, 'expected fresh +1 parent')
    header, body = raw.split(b'\n', 1)
    require(header == f"p cnf 11985 {meta['clauses']}".encode(), 'parent header mismatch')
    require(raw.endswith(b'\n') and len(body.splitlines()) == meta['clauses'], 'parent clause count mismatch')
    require(digest(raw) == meta['sha256'], 'parent metadata hash mismatch')
    old = meta['irrelevant_input_charge']
    require(old['generator_source_sha256'] == PINS[OWN/'add_irrelevant_input_charge.py'], 'unreviewed +1 generator')
    require(old['added_variables'] == 17 and old['added_clauses'] == 3553, 'wrong +1 dimensions')
    require(old['penalty_bits'] == list(range(11969, 11986)), 'wrong +1 bits')
    lines = body.splitlines(keepends=True)
    old_body, suffix = b''.join(lines[:-3553]), b''.join(lines[-3553:])
    require(digest(suffix) == old['delta_sha256'] == '2c69ea99739a06d291dbbc9ee3a26d1f4411f25645bc07a04805bb860ee279dc', 'wrong +1 suffix')
    base_meta = {k: v for k, v in meta.items() if k != 'irrelevant_input_charge'}
    base_meta.update(variables=11968, clauses=meta['clauses']-3553, sha256=old['parent_cnf_sha256'])
    base_raw = f"p cnf 11968 {base_meta['clauses']}\n".encode()+old_body
    require(digest(base_raw) == old['parent_cnf_sha256'], 'pre-+1 parent binding mismatch')
    counters = one.inspect_counters(base_raw, base_meta)
    penalties, clauses, trigger_records = one.build_delta(base_meta, counters)
    require(one.clause_bytes(clauses) == suffix and counters == old['counters'], 'reconstructed +1/counter mismatch')
    return counters, trigger_records


def build_delta(meta, counters, trigger_records, patterns):
    require(meta['variables'] == 11985, 'unexpected variable base')
    witnesses = [[11986+11*g+v for v in range(11)] for g in range(17)]
    rank_bits = {2: list(range(12173, 12190)), 3: list(range(12190, 12207))}
    implications = [[witnesses[r['root_gate']][r['input']]]+r['clause'][1:] for r in trigger_records]
    rank_clauses, guards, thresholds = [], [], []
    for g, counter in enumerate(counters):
        for rank in (2, 3):
            p = rank_bits[rank][g]
            rank_clauses.extend([[-witnesses[g][v] for v in pattern]+[p] for pattern in patterns[rank]])
            allowed = g+2-rank
            threshold = None
            if allowed >= 0:
                threshold = counter['root_thresholds'][allowed]
                require(threshold == counter['old_overflow']-rank, 'nonadjacent reused threshold')
            support = meta['prefix_support_tables'][13+g]
            guards.extend([[-p]+([] if threshold is None else [-threshold])+[bit] for bit in support])
            thresholds.append({'gate': g, 'rank': rank, 'penalty_bit': p, 'allowed_weight': allowed,
                'forbidden_threshold_weight': allowed+1, 'threshold_literal': threshold,
                'negative_penalty_when_proper_support': threshold is None,
                'support_guard_literals': support, 'old_overflow': counter['old_overflow']})
    require(len(implications) == 3366 and len(rank_clauses) == 493 and len(guards) == 374, 'wrong delta dimensions')
    clauses = implications+rank_clauses+guards
    require(len(clauses) == 4233 and all(1 <= abs(x) <= 12206 for c in clauses for x in c), 'invalid delta')
    require(len({tuple(c) for c in clauses}) == 4233, 'duplicate delta clauses')
    return witnesses, rank_bits, clauses, thresholds


def prepare(parent, output, expected_cnf, expected_metadata):
    parent = parent.resolve(strict=True)
    output = output.absolute()
    require(parent.is_relative_to(ROOT) or parent.is_relative_to(REPO), 'input outside workspace')
    require(output.parent.resolve().is_relative_to(OWN.resolve()), 'output outside owned scratch')
    require(not output.exists() and not output.is_symlink(), 'fresh output required')
    one, patterns, parent_review = load_dependencies()
    raw, metadata_raw = parent.read_bytes(), parent.with_suffix('.json').read_bytes()
    require(digest(raw) == expected_cnf and digest(metadata_raw) == expected_metadata, 'parent pin mismatch')
    bindings = parent_review['bindings']
    reviewed = any(p.endswith('.cnf') and b['sha256'] == expected_cnf
        and bindings.get(p[:-4]+'.json', {}).get('sha256') == expected_metadata for p, b in bindings.items())
    require(reviewed, 'parent/metadata pair not bound by final +1 review')
    meta = json.loads(metadata_raw)
    counters, triggers = inspect_parent(raw, meta, one)
    witnesses, ranks, clauses, thresholds = build_delta(meta, counters, triggers, patterns)
    delta = one.clause_bytes(clauses)
    child_raw = f"p cnf 12206 {meta['clauses']+4233}\n".encode()+raw.split(b'\n', 1)[1]+delta
    description = {'version': 's06-hitting-charge-v1', 'mathematics_status': 'S04_PASS',
        'implementation_status': 'PENDING_S08_ACTUAL_DELTA_REVIEW_NO_LAUNCH',
        'parent_cnf_sha256': expected_cnf, 'parent_metadata_sha256': expected_metadata,
        'generator_source_sha256': sha(Path(__file__)), 'dependency_pins': {str(p): s for p, s in PINS.items()},
        'counter_source_sha256': one.COUNTER_SHA, 'witness_bits': witnesses, 'rank_bits': ranks,
        'minimal_rank_patterns': patterns, 'thresholds': thresholds,
        'added_variables': 221, 'added_clauses': 4233, 'input_trigger_clauses': 3366,
        'rank2_trigger_clauses': 408, 'rank3_trigger_clauses': 85, 'guarded_threshold_clauses': 374,
        'delta_sha256': digest(delta), 'full_support_exempt': True,
        'rank_semantics': 'Each rank k independently requires T<=g+2-k on proper support; ranks are not added.',
        'parent_body_byte_preserved': True, 'all_old_indices_preserved': True,
        'not_an_RUP_certificate': True, 'no_every_old_auxiliary_assignment_extension_claim': True}
    child_meta = dict(meta, variables=12206, clauses=meta['clauses']+4233,
        sha256=digest(child_raw), neighborhood_hitting_charge=description)
    output.mkdir(mode=0o700)
    (output/'instance.cnf').write_bytes(child_raw)
    dump(output/'instance.json', child_meta)
    (output/'delta.clauses').write_bytes(delta)
    dump(output/'thresholds.json', thresholds)
    dump(output/'witness-patterns.json', patterns)
    record = {'parent': str(parent), 'parent_cnf_sha256': expected_cnf, 'parent_metadata_sha256': expected_metadata,
        'cnf_sha256': digest(child_raw), 'metadata_sha256': sha(output/'instance.json'),
        'source_sha256': sha(Path(__file__)), 'variables': 12206, 'clauses': child_meta['clauses'],
        'added_variables': 221, 'added_clauses': 4233, 'delta_sha256': digest(delta),
        'old_body_unchanged': True, 'independent_actual_review': 'PENDING', 'solver_launched': False}
    dump(output/'generation.json', record)
    require(parent.read_bytes() == raw and parent.with_suffix('.json').read_bytes() == metadata_raw,
        'parent changed during preparation')
    return record


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('parent', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--parent-sha256', required=True)
    parser.add_argument('--metadata-sha256', required=True)
    args = parser.parse_args()
    print(json.dumps(prepare(args.parent, args.output, args.parent_sha256, args.metadata_sha256), indent=2))
