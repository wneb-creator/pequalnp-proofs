# Hitting-charge preparation after charge archive delivery

Planning only: no new cut generator, CNF, solver process, or active-file change.
The existing charge archive remains frozen at SHA256
`aeb918872f1a57b4ab4e3fb9afd48176dfe5022718b639063a4fd3f40d1ed0fd`.

S04 now gives mathematical and finite-control PASS for S01's hitting charge:
`hitting-charge-review.json`, SHA256
`e4df03fa7c9077847bf16e2850b67b0a0331b79559dd0ca718829c3cb8b50609`.
It binds math `f0af499ec1028b8093ec953d6654d286f20c9ddd035b19fbb485ad0b9ecb2ae6`
and the complete producer table
`9b6c33623fa75e9c1a7796cd5e2c589b5e7bdb01d04488b31b183007f72e553f`.
This is not review of any emitted new cut.

The useful target order is AAAO and AAOA. For actual irrelevant raw ancestors
I, the charge is the minimum number of owners meeting every neighborhood N(v),
v in I. First-AND groups supply such owners. It is the number of distinct
charged ANDs, not the number of input witnesses. The complete graph table has
24 inclusion-minimal triggers for charge at least two (14 pairs and ten
triples), and five for charge at least three (three triples and two quartets).
Therefore an implementation containing only disjoint pairs/triples would miss
12 newly useful patterns. Coverage rises from202 to224 support masks for +2,
and from9 to11 for +3;143 +2 masks have nonempty residual graph. These are
support possibilities, not measurements of surviving SAT models. Common-neighbor
factor supports and their productive ancestor cones cannot trigger a pair, so
this gives no new exclusion of the262 remaining r0 factor families.

Use the existing reviewed counter T=|S|+|H|+selected_cover+g-A, where A counts
strict gate ancestors. A charge k requires T<=g+2-k. For k=2 the forbidden root
threshold is g+1, stored at old_overflow-2; for k=3 it is g, stored at
old_overflow-3 only when g>=1. At gate0, charge3 would require T<=-1 and must be
blocked explicitly: a negative p3 unit in the unguarded formulation. With
full-support guards use eleven clauses (-p3 OR S[v]) instead. Never use the
previous counter's variable as a synthetic threshold0. The companion JSON
records all34 safe specifications from the frozen root-output arrays.

The simplest review path follows S01's explicit-rank outline. Append187
per-input witness bits after the existing11985 variables, then17 p2 and17 p3
bits, preserving all existing indices and clauses. Copy the3366 reviewed
raw-selector/ancestor/support trigger clauses with the per-input witness in
place of the old p1. Add408 rank2 trigger clauses and85 rank3 trigger clauses,
then34 counter links, including the gate0 boundary unit. This is221 new
variables and3893 new clauses, with final variable bound12206. Using eleven
full-support guards per link instead gives4233 clauses. Both are existential
formulations: exact witness/rank flags may be chosen false off trigger; for
full support every actual irrelevant-input witness is false. Matching the
existing guarded +1 style costs340 extra clauses and avoids an additional
full-support convention. This is a review choice, not a performance result.

Each rank imposes an absolute tighter bound. Do not add p1+p2+p3 as numerical
penalties: a rank3 case is charged3, not6. Likewise, support eligibility alone
must not force a witness; actual raw ancestry is required. Preserve self-reader
h=g handling and exclude constant selector positions11/12.

Finite review has already checked all125 independent input sets, all2048
supports,9512 actual-ancestor subset trigger cases,680 owner partitions and
the new overlapping-neighborhood DAG controls. There is no need to repeat
that census. Future implementation controls should instead check the actual
emitted trigger/delta bytes, all34 threshold cases including gate0/rank3,
correct new-variable bounds, metadata/validator compatibility, and old-parent
body preservation. The new math cut is not RUP-entailment of the old encoding.
Minimum covers and canonical totalizer values may need reselection; old valid
RUP clauses survive because they are consequences of the old parent. The
previous S08 review established that argument for the existing AAAO RUP family;
any new AAOA RUP parent needs its own exact parent/proof binding.

Prepare fresh children from reviewed immutable parents when implementation is
admitted. Do not patch running inputs or rebuild the delivered archive. Main
owns independent actual-delta review and any later production scheduling.
