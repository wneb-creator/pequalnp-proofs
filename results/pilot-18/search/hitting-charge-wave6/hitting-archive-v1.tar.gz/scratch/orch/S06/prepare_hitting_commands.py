#!/usr/bin/env python3
"""Write four pinned retained-proof commands; do not execute runner or solvers."""
import datetime
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path('/tmp/oec/pequalnp-pilot-18')
OWN = ROOT/'orch/S06'
DEST = OWN/'hitting-offline-plan'
PINS = {
    OWN/'offline_checked_cadical.py': 'aa5d13bb83ab79e47b9794809c3c06dc153544975cd1131afbdeaef7c18d484a',
    ROOT/'lean-4.36.0-linux/bin/cadical': '2a0137451efde370d67b88aec26f1e902870f095b1204b07049a103bc6bbd647',
    ROOT/'solver/dsr-trim/bin/dsr-trim': 'e6894b5b74ac2c09b494344f397ec5111547aaa782cdb399f1a8b6835ecef84b',
    ROOT/'lean-setup/validate_sat_candidate.py': 'b807c1a580ce1fa49da51d859e6bc5d94bab2f9f0cd359c35cef35686f826529',
    ROOT/'orch/S08/offline-runner-review/review.json': 'e3a1dfb01fe24acf900e34ae15012c78b3ab15a574240334de0fdfc535ac7b03',
    ROOT/'orch/S08/offline-real-case13-review/review.json': 'c1a22439752d28b1a1640d87553de7ae14246a8ab697fd80775f6495a9534f99',
    OWN/'hitting-charge-handoff.json': '88556b6479b8b1ab2676ba63d376df475eab7d6401692af7516a30fe59391351',
}


def binding(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    DEST.mkdir(mode=0o700)
    for p, expected in PINS.items():
        assert p.is_file() and not p.is_symlink() and binding(p)['sha256'] == expected,p
    handoff = json.loads((OWN/'hitting-charge-handoff.json').read_text())
    family = {c['name']: c for c in handoff['family']}
    cases = []
    for priority,name in enumerate(['AAAO-RUP','T2','T3','T4'],1):
        case = family[name]
        cnf = OWN/'hitting-charge-v1'/name/'instance.cnf'
        metadata = cnf.with_suffix('.json')
        output = OWN/f'offline-hitting-{name}-wave1'
        assert not output.exists() and not output.is_symlink()
        assert binding(cnf)['sha256'] == case['cnf_sha256']
        assert binding(metadata)['sha256'] == case['metadata_sha256']
        command = ['python3','-B',str(OWN/'offline_checked_cadical.py'),str(cnf),str(output),
            '--cnf-sha256',case['cnf_sha256'],'--metadata-sha256',case['metadata_sha256'],
            '--solver-seconds','600','--checker-seconds','600','--proof-mib','512',
            '--max-records','100000000','--min-free-mib','1024',
            '--abort-file',str(ROOT/'DESK_ERROR.response')]
        cases.append({'priority': priority,'case': name,'cnf': str(cnf),'metadata': str(metadata),
            'cnf_sha256': case['cnf_sha256'],'metadata_sha256': case['metadata_sha256'],
            'variables': case['variables'],'clauses': case['clauses'],'output': str(output),
            'output_fresh_at_preparation': True,'command': command,'executed': False})
    result = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'status': 'COMMANDS_ONLY_PENDING_S08_ACTUAL_CUT_REVIEW_AND_MAIN_ADMISSION',
        'source_sha256': binding(Path(__file__))['sha256'],
        'pins': {str(p): {'sha256': v,'bytes': p.stat().st_size} for p,v in PINS.items()},
        'case_priority': ['AAAO-RUP','T2','T3','T4'],'cases': cases,
        'limits_per_case': {'solver_wall_seconds': 600,'checker_wall_seconds': 600,
            'solver_address_space_mib': 1536,'checker_address_space_mib': 3072,
            'SAT_validator_wall_seconds': 30,'SAT_validator_address_space_mib': 1536,
            'proof_file_cap_mib': 512,'max_proof_zero_bytes': 100000000,
            'minimum_free_disk_mib': 1024,'active_child_processes_maximum': 1},
        'acceptance': {'UNSAT': 'Runner exit0 and VERIFIED_UNSAT after solver20/soleUNSAT plus independent checker0/soleVERIFIED_UNSAT, stable pins/proof and complete logs.',
            'SAT': 'Stop further admissions on any SAT indication; accept only runner exit10/VALIDATED_SAT with pinned full2048-input validator and complete provenance.',
            'failure_limit_abort': 'UNKNOWN, not a proof; preserve full result/progress/logs and partial proof.'},
        'launch_requirements': ['S08 actual-code/delta PASS binds hitting handoff88556b...1351 and exact four input/metadata hashes.',
            'Main independently verifies runner source pin and fresh output, rechecks pins and supplies detached supervision.',
            'Main admits only available CPU/memory/disk slots; hold each slot through checker or validator and final hash/log persistence.',
            'Do not reuse or mutate an existing output/input; this manifest installs no scheduler.'],
        'disk_snapshot': {'free_bytes': shutil.disk_usage(OWN).free,'four_proof_caps_bytes': 4*512*1024**2,
            'reservation': 'No global reservation; solver logs, snapshots and existing retained files require separate headroom.'},
        'scope': 'Four exact strengthened CNFs only. No case/shard exhaustion or Lean acceptance claim.',
        'executed_runner_preflight': False,'executed_production': False}
    destination = DEST/'commands-manifest.json'
    destination.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status': result['status'],'manifest': str(destination),**binding(destination),
        'cases': len(cases),'free_bytes': result['disk_snapshot']['free_bytes'],'executed': False}))


if __name__ == '__main__':
    main()
