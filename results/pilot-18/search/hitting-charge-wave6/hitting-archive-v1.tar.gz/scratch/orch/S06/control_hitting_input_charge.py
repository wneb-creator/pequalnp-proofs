#!/usr/bin/env python3
"""Bounded scalar controls, fresh ten-child generation, no solver/checker."""
import copy
import datetime
import importlib.util
import itertools
import json
from pathlib import Path
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path('/tmp/oec/pequalnp-pilot-18')
OWN = ROOT/'orch/S06'
DEST = OWN/'hitting-charge-v1'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


M = load('hitting', OWN/'add_hitting_input_charge.py')


def holds(clause, assignment):
    return any(assignment[abs(x)] == (x > 0) for x in clause)


def exact_counter(values, cap, next_variable, assignment):
    """Assign each subtree threshold from its actual signed population count."""
    if len(values) == 1:
        x = values[0]
        return values, next_variable, int(assignment[abs(x)] == (x > 0))
    middle = len(values)//2
    left, next_variable, a = exact_counter(values[:middle], cap, next_variable, assignment)
    right, next_variable, b = exact_counter(values[middle:], cap, next_variable, assignment)
    output = []
    for j in range(1, min(len(left)+len(right), cap)+1):
        next_variable += 1
        output.append(next_variable)
        assignment[next_variable] = a+b >= j
    return output, next_variable, a+b


def rejects(label, fn, controls):
    try:
        fn()
    except ValueError as exc:
        controls.append({'name': label, 'error': str(exc)})
    else:
        raise AssertionError('negative control accepted: '+label)


def main():
    started = time.monotonic()
    DEST.mkdir(mode=0o700)
    one, patterns, parent_review = M.load_dependencies()
    first = OWN/'irrelevant-charge-AAAO-v1/AAAO-RUP/instance.cnf'
    raw = first.read_bytes()
    meta = json.loads(first.with_suffix('.json').read_text())
    counters, records = M.inspect_parent(raw, meta, one)
    witnesses, rank_bits, clauses, thresholds = M.build_delta(meta, counters, records, patterns)
    assert witnesses == [list(range(11986+11*g, 11997+11*g)) for g in range(17)]
    assert rank_bits == {2: list(range(12173,12190)), 3: list(range(12190,12207))}
    # Derive graph from original edge rows, independently of generator constants.
    neighbors = [set() for _ in range(11)]
    for row in meta['rows'][:16]:
        vertices = [v for v in range(11) if row >> v & 1]
        assert len(vertices) == 2
        a,b = vertices
        neighbors[a].add(b)
        neighbors[b].add(a)
    expected_inputs = []
    for g in range(17):
        support = meta['prefix_support_tables'][13+g]
        for h in range(g+1):
            for side in ('lefts','rights'):
                for v in range(11):
                    clause = [witnesses[g][v], support[v]]+[-support[u] for u in sorted(neighbors[v])]
                    if h < g:
                        clause.append(-meta['prefix_ancestor_flags'][g][h])
                    clause.append(-meta[side][h][v])
                    expected_inputs.append(clause)
    assert clauses[:3366] == expected_inputs
    review = json.loads((ROOT/'orch/S04/hitting-charge-review.json').read_text())
    reviewed_patterns = {int(k): [[v for v in range(11) if mask >> v & 1] for mask in masks]
        for k,masks in review['minimal_trigger_masks'].items()}
    assert patterns == reviewed_patterns
    expected_ranks, expected_guards = [], []
    for g in range(17):
        for rank in (2,3):
            p = rank_bits[rank][g]
            expected_ranks.extend([[-witnesses[g][v] for v in vs]+[p] for vs in reviewed_patterns[rank]])
            threshold = None if (g,rank) == (0,3) else counters[g]['root_thresholds'][g+2-rank]
            for bit in meta['prefix_support_tables'][13+g]:
                expected_guards.append([-p]+([] if threshold is None else [-threshold])+[bit])
    assert clauses[3366:3859] == expected_ranks
    assert clauses[3859:] == expected_guards
    # Test all input-witness Boolean masks against the actual gate0 rank clauses.
    rank_truth_checks = 0
    for mask in range(2048):
        assignment = {witnesses[0][v]: bool(mask >> v & 1) for v in range(11)}
        for rank, section in [(2,expected_ranks[:24]), (3,expected_ranks[24:29])]:
            triggered = any(all(mask >> v & 1 for v in vs) for vs in reviewed_patterns[rank])
            for flag in (False,True):
                assignment[rank_bits[rank][0]] = flag
                assert all(holds(c,assignment) for c in section) == (not triggered or flag)
                rank_truth_checks += 1
    module = one.load_counter()
    actual_counter_models = actual_counter_clause_checks = guard_checks = 0
    for g,counter in enumerate(counters):
        values = counter['input_literals']
        initial = counter['counter_first_variable']-1
        network = module.CNF()
        network.variables = initial
        out = module.totalizer_atleast(network,values,g+3)
        counts = sorted({0,len(values)} | {n for k in (2,3) for n in (g+1-k,g+2-k,g+3-k,g+4-k) if 0 <= n <= len(values)})
        for count in counts:
            assignment = {abs(x): ((i < count) == (x > 0)) for i,x in enumerate(values)}
            expected,nv,total = exact_counter(values,g+3,initial,assignment)
            assert expected == out and nv == network.variables and total == count
            assert all(holds(c,assignment) for c in network.clauses)
            for rank in (2,3):
                t = thresholds[2*g+rank-2]
                if t['threshold_literal'] is not None:
                    assert assignment[t['threshold_literal']] == (count > g+2-rank)
                else:
                    assert g == 0 and rank == 3 and count > g+2-rank
            actual_counter_models += 1
            actual_counter_clause_checks += len(network.clauses)
        # Exact emitted guard truth tables, including all11 choices of missing support bit.
        for rank in (2,3):
            t = thresholds[2*g+rank-2]
            links = expected_guards[(2*g+rank-2)*11:(2*g+rank-1)*11]
            for count in range(len(values)+1):
                for missing,flag in itertools.product(range(-1,11),(False,True)):
                    assignment = {bit: i != missing for i,bit in enumerate(t['support_guard_literals'])}
                    assignment[t['penalty_bit']] = flag
                    if t['threshold_literal'] is not None:
                        assignment[t['threshold_literal']] = count > t['allowed_weight']
                    assert all(holds(c,assignment) for c in links) == (missing == -1 or not flag or count <= g+2-rank)
                    guard_checks += 1
    negatives = []
    bad = copy.deepcopy(meta)
    bad['variables'] = 11986
    rejects('wrong_parent_variable_bound',lambda: M.inspect_parent(raw,bad,one),negatives)
    bad = copy.deepcopy(meta)
    bad['irrelevant_input_charge']['counters'][0]['root_thresholds'][0] += 1
    rejects('tampered_counter_metadata',lambda: M.inspect_parent(raw,bad,one),negatives)
    changed = raw.replace(b'11969 ',b'11968 ',1)
    bad = copy.deepcopy(meta)
    bad['sha256'] = M.digest(changed)
    rejects('tampered_reviewed_plus1_suffix',lambda: M.inspect_parent(changed,bad,one),negatives)
    rejects('wrong_parent_pin',lambda: M.prepare(first,DEST/'bad-pin','0'*64,M.sha(first.with_suffix('.json'))),negatives)
    assert not (DEST/'bad-pin').exists()
    pin_path = ROOT/'orch/S01/hitting-input-charge-coverage.json'
    correct = M.PINS[pin_path]
    M.PINS[pin_path] = '0'*64
    rejects('wrong_coverage_source_pin',M.load_dependencies,negatives)
    M.PINS[pin_path] = correct
    assert thresholds[1]['threshold_literal'] is None
    assert thresholds[0]['threshold_literal'] == 8157
    assert thresholds[3]['threshold_literal'] == 8296
    # Wrong old overflow-1 links accept the new forbidden boundary; detect this explicitly.
    for g in range(17):
        for rank in (2,3):
            count = max(0,g+3-rank)
            assert count > g+2-rank
            assert not (count >= g+2)
    # Numerical rank summation wrongly rejects a rank3 case at its exact allowed boundary.
    assert 0+3 <= 1+2 and not (0+1+2+3 <= 1+2)
    families = {c['name']: c for c in json.loads((OWN/'irrelevant-charge-handoff.json').read_text())['family']}
    order = ['AAAO-RUP','T1','T2','T3','T4','AAAO-P-RUP','AAAO-d-RUP','AAAO-chain','AAAA-chain','original']
    validator_path = ROOT/'lean-setup/validate_sat_candidate.py'
    assert M.sha(validator_path) == 'b807c1a580ce1fa49da51d859e6bc5d94bab2f9f0cd359c35cef35686f826529'
    validator = load('pinned_candidate_validator',validator_path)
    family = []
    for name in order:
        group = 'irrelevant-charge-AAAO-v1' if name in ['AAAO-RUP','AAAO-P-RUP','AAAO-d-RUP'] else 'irrelevant-charge-v1'
        parent = OWN/group/name/'instance.cnf'
        binding = families[name]
        before, before_meta = parent.read_bytes(),parent.with_suffix('.json').read_bytes()
        record = M.prepare(parent,DEST/name,binding['cnf_sha256'],binding['metadata_sha256'])
        child = (DEST/name/'instance.cnf').read_bytes()
        metadata = validator.load_metadata((DEST/name/'instance.json').read_bytes())
        old = json.loads(before_meta)
        assert child.split(b'\n',1)[1] == before.split(b'\n',1)[1]+one.clause_bytes(clauses)
        assert metadata['variables'] == 12206 and metadata['clauses'] == old['clauses']+4233
        assert metadata['sha256'] == M.digest(child)
        assert set(metadata) == set(old)|{'neighborhood_hitting_charge'}
        assert all(metadata[k] == v for k,v in old.items() if k not in ['variables','clauses','sha256'])
        assert len(child.splitlines()) == metadata['clauses']+1
        assert max(abs(x) for c in clauses for x in c) == 12206
        for g in range(21):
            validator.variable(metadata['ops'][g],metadata,'operation')
            for side in ['lefts','rights']:
                assert len(metadata[side][g]) == 13+g
                for x in metadata[side][g]:
                    validator.variable(x,metadata,'operand')
        for x in metadata['output_selectors']:
            validator.variable(x,metadata,'output')
        assert parent.read_bytes() == before and parent.with_suffix('.json').read_bytes() == before_meta
        record.update(name=name,metadata_structural_compatibility='PASS_NOT_SAT_VALIDATION')
        family.append(record)
    rejects('fresh_directory_reuse',lambda: M.prepare(first,DEST/'AAAO-RUP',M.sha(first),M.sha(first.with_suffix('.json'))),negatives)
    again = json.loads((DEST/'AAAO-RUP/instance.json').read_text())
    rejects('double_charge_application',lambda: M.inspect_parent((DEST/'AAAO-RUP/instance.cnf').read_bytes(),again,one),negatives)
    assert len({c['delta_sha256'] for c in family}) == 1
    result = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'status': 'PASS_SCALAR_AND_FRESH_DELTA_CONTROLS_INDEPENDENT_ACTUAL_REVIEW_PENDING',
        'seconds': time.monotonic()-started, 'source_sha256': M.sha(Path(__file__)),
        'generator_source_sha256': M.sha(OWN/'add_hitting_input_charge.py'),
        'math_review_sha256': M.PINS[ROOT/'orch/S04/hitting-charge-review.json'],
        'controls': {'exact_input_trigger_shapes': len(expected_inputs), 'exact_rank_trigger_shapes': len(expected_ranks),
            'exact_guard_shapes': len(expected_guards), 'rank_truth_checks': rank_truth_checks,
            'actual_counter_models': actual_counter_models, 'actual_counter_clause_checks': actual_counter_clause_checks,
            'guard_truth_checks': guard_checks, 'threshold_specifications': len(thresholds),
            'wrong_rank_threshold_negative_checks': 34, 'summed_rank_negative_control': True,
            'negative_rejection_controls': negatives, 'fresh_parent_body_and_metadata_checks': len(family)},
        'family': family, 'solver_launched': False, 'checker_launched': False, 'Lean_build': False,
        'scope': 'New math restriction, not RUP; metadata parsing only, no SAT model validation; current parents immutable.'}
    M.dump(DEST/'controls.json',result)
    print(json.dumps(result,indent=2,sort_keys=True))


if __name__ == '__main__':
    main()
