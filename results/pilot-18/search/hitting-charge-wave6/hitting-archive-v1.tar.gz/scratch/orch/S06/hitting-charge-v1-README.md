# Fresh +2/+3 neighborhood-hitting cuts

Prepared for S08 actual-code/delta review; no production launch. All ten inputs
are fresh children of the exact +1 inputs covered by S08 final review
`b0af769b67da5f0b2f42aa1d4e341e217556b56cf17ea3a7a7aa5ffe9a0a2d7b`.
Priority is AAAO-RUP and AAOA T1..T4. Existing inputs and running directories
were not modified; running directories were not read.

Generator `add_hitting_input_charge.py` SHA256
`58bc217a57c3bb8a7819925e17f86b4c13435e006b9f3028731e4d1e10533398`.
Control driver `control_hitting_input_charge.py` SHA256
`93f2feed9d2f3effbcc1bda0f08ac0305833acaf2e684f4588dcf26b1998c4f7`.
Shared appended delta SHA256
`3f5cc4b71971641479dfb1e6c418fd7dfbd26c375421f0047e732cf2a5eb6a5d`.

Each child adds221 variables and4233 clauses. Raw-input witnesses are11986..12172;
rank2 bits12173..12189; rank3 bits12190..12206. Existing1..11985 retain their
meanings. The delta comprises3366 actual-raw-ancestor trigger implications,
408 rank2 implications for24 minimal patterns,85 rank3 implications for5
minimal patterns, and374 full-support guarded counter links. All existing
clause bytes, including old RUP additions and +1 cuts, remain unchanged.

For gate g and charge k, the signed ancestor-cost counter must obey
T<=g+2-k. Its forbidden root threshold is g+3-k, at old_overflow-k when
g+2-k>=0. Gate0/rank3 instead emits11 clauses (-p3 OR support[v]); it never
references threshold0. Full support remains exempt for any rank flag value.
The three ranks impose separate absolute bounds; they are not summed.

S04 mathematical and finite review is PASS
`e4df03fa7c9077847bf16e2850b67b0a0331b79559dd0ca718829c3cb8b50609`.
The generator pins it, its producer table/math and the final +1 parent review.
It reconstitutes the pre-+1 parent and regenerates every original counter block
and the exact +1 suffix before appending new clauses. The input CNF/metadata pair
must occur in the pinned +1 review, including when supplied from another path.

Controls passed in1.920338s wall under10CPU/30wall seconds and1GiB address space:
4233 independently reconstructed clause shapes,8192 actual rank-clause truth
checks,113 actual signed-counter models/146039 original counter-clause checks,
38352 full-support/boundary guard truth checks,34 wrong-threshold negative
checks, an incorrect summed-rank negative control, and7 fail-closed rejection
controls. All10 exact parent suffixes and metadata passed, including unchanged
pinned-validator metadata parsing/decoder shapes. This is not SAT validation;
a future candidate needs all12206 assignments and the unchanged full audit.
Full stdout, stderr and execution record are adjacent to this README.

Reproduce one child using the generator's positional parent CNF and a fresh
output directory under S06 scratch, plus `--parent-sha256` and
`--metadata-sha256` from its generation.json or hitting-charge-handoff.json.
The dependency files must have the exact recorded hashes. It writes instance.cnf,
instance.json, delta.clauses, thresholds.json, witness-patterns.json and
generation.json. No solver is called. The control driver's fixed output path
intentionally refuses a second run over the delivered inputs.

Portable CNF reproduction needs only the exact +1 parent, the shared ASCII
delta, and the child's new header; the handoff records all ten recipes. The
previous charge archive contains portable recipes for these +1 parents. No
large raw CNF needs repository storage.

These restrictions use reviewed mathematics, not RUP entailment of the parent.
At circuit level choose actual witness/rank flags, minimum covers and canonical
counter thresholds. The claim is existential completeness, not extension of
every old auxiliary assignment. Old RUP clauses remain satisfied because they
are consequences of the pre-cut parent. Metadata records independent actual
review as pending; later review records should supersede that historical field
without rewriting the delivered source or children.

The earlier hitting-charge-plan.md is a historical preimplementation plan.
Its suggested planning JSON was superseded by the actual per-child
thresholds.json files and this handoff.
