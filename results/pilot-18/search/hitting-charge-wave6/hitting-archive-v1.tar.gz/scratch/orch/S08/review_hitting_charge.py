from wave5_delivery_helpers import *
import ast,itertools,time
v=Review('hitting-charge-review');started=time.monotonic();S=R/'orch/S06';handraw=v.bind(S/'hitting-charge-handoff.json','handoff.json');hand=json.loads(handraw)
assert sha(handraw)=='88556b6479b8b1ab2676ba63d376df475eab7d6401692af7516a30fe59391351'
for n,row in hand['files'].items():
 raw=v.bind(S/n,'snapshot/'+n);assert sha(raw)==row['sha256'] and len(raw)==row['bytes'],n
assert len(hand['files'])==89 and len(hand['evidence'])==20
for row in hand['evidence']:
 p=Path(row['source_path']);q=Path(row['snapshot_path']);assert p.is_relative_to(R) or p.is_relative_to(W)
 raw=v.bind(p);assert raw==q.read_bytes() and sha(raw)==row['sha256'] and len(raw)==row['bytes']
math=json.loads(v.bind(R/'orch/S04/hitting-charge-review.json'));oldreview=json.loads(v.bind(S08/'irrelevant-charge-final-review-v2/review.json'))
assert sha((R/'orch/S04/hitting-charge-review.json').read_bytes())==hand['mathematical_review_sha256']=='e4df03fa7c9077847bf16e2850b67b0a0331b79559dd0ca718829c3cb8b50609'
assert sha((S08/'irrelevant-charge-final-review-v2/review.json').read_bytes())==hand['parent_actual_review_sha256']=='b0af769b67da5f0b2f42aa1d4e341e217556b56cf17ea3a7a7aa5ffe9a0a2d7b'
source=v.bind(S/'add_hitting_input_charge.py');assert sha(source)==hand['generator_source_sha256']=='58bc217a57c3bb8a7819925e17f86b4c13435e006b9f3028731e4d1e10533398'
sourcecounter=v.bind(W/'results/pilot-18/search/search_l1342_shard17_ancestorreverse.py');assert sha(sourcecounter)=='b10d8832060d1c554fd3daa563b7159d515a3c55adc49718989eaa9bd0c2f24f'
tree=ast.parse(sourcecounter);picked=[n for n in tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name in ['CNF','totalizer_atleast']];assert len(picked)==2;ns={};exec(compile(ast.Module(body=picked,type_ignores=[]),'hash-pinned-in-memory-counter','exec'),ns)
CNF=ns['CNF'];totalizer=ns['totalizer_atleast'];encode=lambda cs:''.join(' '.join(map(str,c))+' 0\n' for c in cs).encode()
meta=json.loads((S/'hitting-charge-v1/AAAO-RUP/instance.json').read_text());desc=meta['neighborhood_hitting_charge'];counters=meta['irrelevant_input_charge']['counters'];edges=meta['rows'][:16]
N=[sum(1<<(e^(1<<v)).bit_length()-1 for e in edges if e>>v&1) for v in range(11)]
assert all(e.bit_count()==2 for e in edges) and all(x>0 for x in N)
# Independent finite hitting minimum, restricted to independent sets as required by the actual-input theorem.
ind=[mask for mask in range(2048) if all(mask&e!=e for e in edges)];assert len(ind)==125
eta={}
for mask in ind:
 eta[mask]=min(d.bit_count() for d in range(2048) if all(d&N[x] for x in range(11) if mask>>x&1))
patterns={k:[mask for mask in ind if eta[mask]>=k and all(eta[mask^(1<<x)]<k for x in range(11) if mask>>x&1)] for k in (2,3)}
assert patterns=={int(k):vv for k,vv in math['minimal_trigger_masks'].items()} and [len(patterns[k]) for k in (2,3)]==[24,5]
for mask in ind:
 for k in (2,3):assert any(mask&p==p for p in patterns[k])==(eta[mask]>=k)
# Independently rebuild exact new delta directly from graph/old metadata; never call the producer generator.
w=[[11986+11*g+x for x in range(11)] for g in range(17)];ranks={2:list(range(12173,12190)),3:list(range(12190,12207))};triggers=[];rankclauses=[];guards=[];thresholds=[];networks=[]
assert sorted(sum(w,[])+ranks[2]+ranks[3])==list(range(11986,12207))
for g in range(17):
 sup=meta['prefix_support_tables'][13+g]
 for h in range(g+1):
  for side in ['lefts','rights']:
   for x in range(11):
    c=[w[g][x],sup[x]]+[-sup[y] for y in range(11) if N[x]>>y&1]
    if h!=g:c.append(-meta['prefix_ancestor_flags'][g][h])
    c.append(-meta[side][h][x]);triggers.append(c)
 row=meta['partial_edge_cost_restrictions'][g];inputs=sup+row['residual_edge_flags']+row['vertex_cover_flags']+[-x for x in meta['prefix_ancestor_flags'][g]]
 c=CNF();c.variables=row['vertex_cover_flags'][-1];out=totalizer(c,inputs,g+3);assert out[-1]==row['overflow_flag'] and out==counters[g]['root_thresholds'];assert inputs==counters[g]['input_literals'] and sha(encode(c.clauses))==counters[g]['counter_clause_block_sha256'];networks.append((inputs,c,out))
 for k in (2,3):
  p=ranks[k][g];rankclauses += [[-w[g][x] for x in range(11) if mask>>x&1]+[p] for mask in patterns[k]]
  allowed=g+2-k;t=None if allowed<0 else out[allowed]
  assert t is None and (g,k)==(0,3) or t==row['overflow_flag']-k
  guards.extend([[-p]+([] if t is None else [-t])+[b] for b in sup])
  thresholds.append({'gate':g,'rank':k,'penalty_bit':p,'allowed_weight':allowed,'forbidden_threshold_weight':allowed+1,'threshold_literal':t,'negative_penalty_when_proper_support':t is None,'support_guard_literals':sup,'old_overflow':row['overflow_flag']})
assert [len(triggers),len(rankclauses),len(guards)]==[3366,493,374];expected=triggers+rankclauses+guards;delta=encode(expected);assert len(expected)==len(set(map(tuple,expected)))==4233 and sha(delta)==hand['delta_sha256']=='3f5cc4b71971641479dfb1e6c418fd7dfbd26c375421f0047e732cf2a5eb6a5d'
assert desc['witness_bits']==w and desc['rank_bits']=={str(k):vv for k,vv in ranks.items()} and desc['thresholds']==thresholds
# Evaluate actual clauses for all masks/flags, including off-trigger auxiliary choices and full-support exemption.
holds=lambda c,a:any(a[abs(x)]==(x>0) for x in c)
rankchecks=guardchecks=triggerchecks=countermodels=counterchecks=0
for mask in range(2048):
 a={w[0][x]:bool(mask>>x&1) for x in range(11)}
 for k,start,end in [(2,0,24),(3,24,29)]:
  forced=any(mask&p==p for p in patterns[k])
  for flag in (False,True):
   a[ranks[k][0]]=flag;assert all(holds(c,a) for c in rankclauses[start:end])==(flag or not forced);rankchecks+=1
for sup in range(2048):
 for x in range(11):
  eligibility=not(sup>>x&1) and N[x]&~sup==0
  for anc,read,flag in itertools.product((False,True),repeat=3):
   a={meta['prefix_support_tables'][14][y]:bool(sup>>y&1) for y in range(11)};a[w[1][x]]=flag;a[meta['prefix_ancestor_flags'][1][0]]=anc;a[meta['lefts'][0][x]]=read
   clause=[w[1][x],meta['prefix_support_tables'][14][x]]+[-meta['prefix_support_tables'][14][y] for y in range(11) if N[x]>>y&1]+[-meta['prefix_ancestor_flags'][1][0],-meta['lefts'][0][x]]
   assert holds(clause,a)==(flag or not(eligibility and anc and read));triggerchecks+=1
# Independently populate complete signed totalizer models, all integer weights, checking every actual clause.
def model(values,cap,nxt,a):
 if len(values)==1:return values,nxt,int(a[abs(values[0])]==(values[0]>0))
 mid=len(values)//2;l,nxt,lc=model(values[:mid],cap,nxt,a);r,nxt,rc=model(values[mid:],cap,nxt,a);out=[]
 for t in range(1,min(len(l)+len(r),cap)+1):nxt+=1;out.append(nxt);a[nxt]=lc+rc>=t
 return out,nxt,lc+rc
for g,(inputs,cnf,out) in enumerate(networks):
 for weight in range(len(inputs)+1):
  a={abs(x):((i<weight)==(x>0)) for i,x in enumerate(inputs)};out2,last,total=model(inputs,g+3,meta['partial_edge_cost_restrictions'][g]['vertex_cover_flags'][-1],a)
  assert out==out2 and last==cnf.variables and total==weight and all(holds(c,a) for c in cnf.clauses);countermodels+=1;counterchecks+=len(cnf.clauses)
  for k in (2,3):
   rec=thresholds[2*g+k-2];links=guards[(2*g+k-2)*11:(2*g+k-1)*11]
   assert rec['threshold_literal'] is None or a[rec['threshold_literal']]==(weight>g+2-k)
   for missing,flag in itertools.product(range(-1,11),(False,True)):
    b={x:i!=missing for i,x in enumerate(rec['support_guard_literals'])};b[rec['penalty_bit']]=flag
    if rec['threshold_literal'] is not None:b[rec['threshold_literal']]=a[rec['threshold_literal']]
    assert all(holds(c,b) for c in links)==(missing==-1 or not flag or weight<=g+2-k);guardchecks+=1
# All ten old bodies and indices, exact metadata and portable recipes, pinned by prior final review.
children=[]
for row in hand['family']:
 parent=Path(row['parent']);praw=v.bind(parent);pmraw=v.bind(parent.with_suffix('.json'));pm=json.loads(pmraw);name=row['name'];cp=S/'hitting-charge-v1'/name;raw=(cp/'instance.cnf').read_bytes();cmraw=(cp/'instance.json').read_bytes();cm=json.loads(cmraw)
 assert v.bindings[str(parent)]==oldreview['bindings'][str(parent)] and v.bindings[str(parent.with_suffix('.json'))]==oldreview['bindings'][str(parent.with_suffix('.json'))]
 assert sha(praw)==row['parent_cnf_sha256'] and sha(pmraw)==row['parent_metadata_sha256']
 assert raw==f"p cnf 12206 {pm['clauses']+4233}\n".encode()+praw.split(b'\n',1)[1]+delta and len(raw.splitlines())==pm['clauses']+4234
 assert sha(raw)==row['cnf_sha256']==cm['sha256'] and sha(cmraw)==row['metadata_sha256'] and cm['variables']==12206 and cm['clauses']==pm['clauses']+4233
 assert set(cm)==set(pm)|{'neighborhood_hitting_charge'} and all(cm[k]==value for k,value in pm.items() if k not in ['variables','clauses','sha256'])
 cd=cm['neighborhood_hitting_charge'];assert cd['thresholds']==thresholds and cd['witness_bits']==w and cd['rank_bits']==desc['rank_bits'] and cd['generator_source_sha256']==sha(source)
 assert cd['parent_cnf_sha256']==sha(praw) and cd['parent_metadata_sha256']==sha(pmraw) and cd['delta_sha256']==sha(delta) and cd['full_support_exempt'] and cd['not_an_RUP_certificate'] and cd['no_every_old_auxiliary_assignment_extension_claim']
 assert (cp/'delta.clauses').read_bytes()==delta and json.loads((cp/'thresholds.json').read_text())==thresholds
 for x in cd['dependency_pins']:
  assert sha(v.bind(Path(x)))==cd['dependency_pins'][x]
 recipe=next(x for x in hand['portable_CNF_recipes'] if x['name']==name)
 assert recipe['new_header'].encode()+praw.split(b'\n',1)[1]+(S/recipe['append_artifact']).read_bytes()==raw and recipe['expected_cnf_bytes']==len(raw) and recipe['expected_cnf_sha256']==sha(raw)
 children.append({'name':name,'cnf_sha256':sha(raw),'metadata_sha256':sha(cmraw),'variables':12206,'clauses':cm['clauses']})
assert len(children)==10
controls=json.loads((S/'hitting-charge-v1/controls.json').read_text());execution=json.loads((S/'hitting-charge-v1.execution.json').read_text());assert execution['exit_code']==0 and controls==json.loads((S/'hitting-charge-v1.stdout').read_text()) and not (S/'hitting-charge-v1.stderr').read_bytes()
assert controls['source_sha256']==hand['control_source_sha256'] and controls['generator_source_sha256']==sha(source) and len(controls['controls']['negative_rejection_controls'])==7
for n,row in execution['logs'].items():assert sha((S/n).read_bytes())==row['sha256'] and len((S/n).read_bytes())==row['bytes']
assert sha(v.bind(Path(hand['parent_recipe_archive']['path'])))==hand['parent_recipe_archive']['sha256']
for n,row in v.bindings.items():assert sha(Path(n).read_bytes())==row['sha256'],('changed during review',n)
v.checks={'handoff_sha256':sha(handraw),'source_sha256':sha(source),'all89_artifacts_and20_evidence_copies':True,'delta_sha256':sha(delta),'new_variables':221,'new_variable_range':[11986,12206],'clause_groups':{'raw_triggers':3366,'rank2':408,'rank3':85,'proper_support_links':374},'minimal_triggers':patterns,'independent_graph_sets':125,'trigger_truth_rows':triggerchecks,'rank_clause_rows':rankchecks,'actual_counter_models_all_weights':countermodels,'actual_counter_clause_checks':counterchecks,'guard_boundary_rows':guardchecks,'gate0_rank3':'11 clauses (-p3 OR S[v]); no threshold-zero lookup','rank_semantics':'T+k<=g+2 separately for triggered ranks, never p1+2p2+3p3. T=|S|+|H|+minimum_cover+g-A; M=1+A. Full S exempt. Empty H allowed. Raw reachability uses strict ancestor plus actual selector; self-reader requires no diagonal flag; constants excluded.','existential_cover_projection':'Choose fresh minimum covers/canonical totalizers and exact actual witness/rank flags. Not every old auxiliary assignment extends. Prior reviewed RUP consequences persist under this valid reselection; new charge is mathematical, not RUP.','source_review':'Fresh-only output, hash-pinned parent/metadata pair must be in prior final review; source/math/review pins checked; full original clause bodies and old IDs preserved; no solver or active-file mutation.','producer_controls':controls['controls'],'children':children,'all10_portable_recipes_exact':True,'full_producer_exit0_logs_bound':True,'no_SAT_UNSAT_Lean_or_launch_claim':True,'seconds':time.monotonic()-started}
v.finish('PASS_FINAL_TEN_HITTING_INPUT_CHARGE_DELTAS_AND_CONTROLS','Exactsource58bc217a...33398/handoff88556b...91351/all89artifacts+20evidencecopies PASS. Independent4233-clause delta3f5cc4...6a5d=3366rawtriggers+408rank2+85rank3+374guards;221newbits11986..12206. All10parents/body/IDs preserved and10portable recipes exact;24/5minimalrankpatterns independentlyreproduced. Allsignedcounterweights/guardtruth tested; gate0rank3 explicitproper-support negativeflag, fullS exempt, ranks NOTadded. Existential minimum-cover reselection/priorRUPcompatibility retained; no oldaux-extension/newRUP/UNSAT/Lean claim. Exactchildhashes/fullcontrols/logs inreview; mainownsproduction admission, noS08launch.')
