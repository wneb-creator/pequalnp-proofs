# Mixed three-factor exact-support census

For independent review. This continues no-common-cover-relaxation.md using
all958 exact eligible supports, rather than minimum-cost representatives of
their382 rejection-pattern groups. It enumerates all pairs and intersects
24 bitsets to obtain every possible third support covering all MIS rows.
Distinct supports are enumerated once in increasing numeric order.

For each r=1,2,3 it first applies the necessary cone caps L<=18-r to no-CN
supports and L<=17-r to common-neighbor supports. It tests exact r, minimal
rejection cover and sorted output-position capacities15,16,17. The reviewed
joint charge L_i+z+d is applied only where the distinguished residual graph
is nonempty; the old theorem's restriction is preserved in this column.

The position test enumerates every distinct chronological output position
and every transitive chosen-ancestry relation. A no-CN output has no chosen
descendant. An ancestry transition needs an intervening unselected AND;
two selected ancestors require two spare gates. Each cone upper bound removes
earlier chosen nonancestors and the additional AND in a wholly outside
selected ancestry chain. Its lower bound uses the individual L and ancestor
owner charges, again only with nonempty residuals. These are the same reviewed
necessary conditions as the earlier three-common-factor position test, with
the additional proved no-CN ancestry prohibition. Optional raw-input charges
and antichain-cone-union bounds are omitted, making this a weaker relaxation.

Results:

|r|exact-r covers after cone caps|minimal/slot|joint pass|position pass|
|--|--:|--:|--:|--:|
|1|2046|2008|923|800|
|2|114|114|68|68|
|3|0|0|0|0|

Every passing family retains its exact supports, costs, owners, residual
counts and one concrete abstract position/ancestry witness. The computation
takes about3.9seconds on one CPU. There is no solver or circuit witness.

A separate exploratory column applies S04's proposed gamma-region outside
charge and extension to empty residuals. It changes no final decision here:
all no-CN factors in the868 position survivors have gamma exactly2. Three
of the800 r=1 survivors have an edgeless-residual factor; none of the68 r=2
survivors do. This column remains separately marked pending source/proof
review and is unnecessary for the800/68/0 counts above.

The first attempt stopped before any census because of a misspelled local
variable in the neighborhood comprehension. Its source and complete empty
stdout/error stderr are retained as initial-failed artifacts. The corrected
source completed all three cases; no failed run is treated as a result.
