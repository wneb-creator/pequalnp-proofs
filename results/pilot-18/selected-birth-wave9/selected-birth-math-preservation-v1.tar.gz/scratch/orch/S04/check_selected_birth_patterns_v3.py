from pathlib import Path
import collections,hashlib,itertools,json,time
O=Path(__file__).resolve().parent;I=O.parent/'S01';start=time.monotonic()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
p=O/'selected-birth-patterns-v3.json';data=json.loads(p.read_text());assert sha(p)=='2cda8c5b1a0bbdcb46fd4f372b3da88d756b60f0f6f9fc0a89ff5d1aae5e5645'
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)];N=[{v if u==x else u for u,v in E if x in (u,v)} for x in range(11)]
def verts(s):return {v for v in range(11) if s>>v&1}
def cn(s):return set.intersection(*(N[v] for v in verts(s)))
pairs=list(itertools.permutations(range(3),2))
def code(rel):return sum(1<<j for j,e in enumerate(pairs) if e in rel)
family_rows=[];poschecks=0;chosen_controls={}
for group in data['results']:
 r=group['r']
 for row in group['families']:
  S=row['supports'];sets=list(map(verts,S));L=row['individual_costs'];C=[cn(s) for s in S]
  essential=[s|{v for v in range(11) if N[v]-s} for s in sets]
  irrelevant=[{v for v in range(11) if v not in s and N[v]<=s} for s in sets]
  H={e for e in E if any(set(e).isdisjoint(s) for s in sets)}
  accepted={}
  # Different enumeration: chronological positions first, then seven
  # transitive forward relations, mapped back to original output labels.
  for pp in itertools.product(*(range(l-1,17) for l in L)):
   if len(set(pp))!=3:continue
   order=sorted(range(3),key=lambda i:pp[i]);forward=list(itertools.combinations(order,2));available=set(range(17))-set(pp)
   for bits in range(8):
    rel={e for j,e in enumerate(forward) if bits>>j&1}
    if any((a,c) not in rel for a,b in rel for bb,c in rel if b==bb):continue
    key=code(rel)
    if key in accepted:continue
    poschecks+=1
    if any(not C[a] for a,b in rel):continue
    if any(not any(pp[a]<t<pp[b] for t in available) for a,b in rel):continue
    ok=True
    for i in range(3):
     ancestors={a for a,b in rel if b==i}
     if len(ancestors)==2 and sum(min(pp[j] for j in ancestors)<t<pp[i] for t in available)<2:ok=False;break
     outside={j for j in range(3) if pp[j]<pp[i] and j not in ancestors}
     extra=int(any(a in outside and b in outside for a,b in rel))
     upper=pp[i]+1-len(outside)-extra
     owner_set=set().union(*(C[j] for j in ancestors)) if ancestors else set()
     charge=len(owner_set&sets[i]) if any(set(e).isdisjoint(sets[i]) for e in E) else 0
     if r==0:charge=max(charge,int(any(essential[j]&irrelevant[i] for j in ancestors)))
     subfamily=ancestors|{i}
     Bc={e for e in E if any(set(e).isdisjoint(sets[j]) for j in subfamily)}
     for j in ancestors:Bc|={tuple(sorted((u,v))) for u in C[j] for v in sets[j]}
     bonus=bool(Bc) and all(any(tuple(sorted((u,v))) not in Bc for v in sets[i]) for u in C[i])
     if max(L[i]+charge,len(Bc)+1+int(bonus))>upper:ok=False;break
    if ok:
     for mask in range(1,8):
      J={i for i in range(3) if mask>>i&1}
      TJ={i for i in J if not any(a==i and b in J for a,b in rel)}
      KJ={e for e in E if any(set(e).isdisjoint(sets[i]) for i in J)}
      for i in J-TJ:KJ|={tuple(sorted((u,v))) for u in C[i] for v in sets[i]}
      bonus=bool(KJ) and all(all(any(tuple(sorted((u,v))) not in KJ for v in sets[i]) for u in C[i]) for i in TJ)
      last=max(pp[j] for j in J)
      omitted={i for i in range(3) if i not in J and pp[i]<last and not any((i,j) in rel for j in J)}
      extra=int(any(a in omitted and b in omitted for a,b in rel))
      if len(KJ)+len(TJ)+int(bonus)>last+1-len(omitted)-extra:ok=False;break
    if ok:accepted[key]=rel
  old={code(set(map(tuple,c['ancestry']))):c for c in row['relation_cases']};assert set(accepted)==set(old)
  found=[]
  for key,rel in accepted.items():
   terminals={i for i in range(3) if not any(a==i for a,b in rel)}
   K=set(H)
   for i in set(range(3))-terminals:
    assert len(C[i])==1
    K|={tuple(sorted((u,v))) for u in C[i] for v in sets[i]}
   strict=bool(K) and all(all(any(tuple(sorted((u,v))) not in K for v in sets[i]) for u in C[i]) for i in terminals)
   bound=len(K)+len(terminals)+int(strict);c=old[key]
   assert set(map(tuple,c['forced_birth_edges']))==K and set(c['terminal'])==terminals and c['strict_guard']==strict and c['lower_bound']==bound and c['newly_rejected']==(bound>17)
   if bound<=17:found.append(key)
   chosen_controls.setdefault((r,key),(S,rel))
  assert row['excluded']==(not found) and row['remaining_relations']==len(found)
  family_rows.append({'r':r,'supports':S,'old_relations':sorted(accepted),'surviving_relations':sorted(found),'excluded':not found})
  assert time.monotonic()-start<30
summaries=[{'r':r,'input':sum(a['r']==r for a in family_rows),'excluded':sum(a['r']==r and a['excluded'] for a in family_rows),'remaining':sum(a['r']==r and not a['excluded'] for a in family_rows)} for r in [0,1]]
assert [a['excluded'] for a in summaries]==[99,230]

ALL=(1<<2048)-1;raw=[sum(1<<x for x in range(2048) if x>>v&1) for v in range(11)]+[0,ALL]
F=0
for u,v in E:F|=raw[u]&raw[v]
negative=ALL^F
controls=[]
for (r,key),(S,rel) in sorted(chosen_controls.items()):
 for aliases in [False,True]:
  gates=[];values=list(raw);supports=[1<<v for v in range(11)]+[0,2047];anc=[set() for _ in range(13)]
  def add(op,a,b):
   w=13+len(gates);gates.append([op,a,b]);values.append(values[a]&values[b] if op=='and' else values[a]|values[b]);supports.append(sum(1<<v for v in range(11) if values[w]>>(1<<v)&1));anc.append({w}|anc[a]|anc[b])
   if op=='and':assert supports[a] and supports[b] and not values[w]&negative
   return w
  def OR(ws):
   out=ws[0]
   for v in ws[1:]:out=add('or',out,v)
   return out
  add('or',12,12) # deliberately dead full-support/TRUE gate
  edge_cache={};outputs={};pending=set(range(3))
  while pending:
   i=min(j for j in pending if all(a in outputs for a,b in rel if b==j));pending.remove(i)
   parts=sorted(verts(S[i]))
   for e in E:
    if set(e).isdisjoint(verts(S[i])):
     if e not in edge_cache:edge_cache[e]=add('and',*e)
     parts.append(edge_cache[e])
   for a,b in sorted(rel):
    if b==i:parts.append(add('and',outputs[a],next(iter(cn(S[a])))))
   out=OR(parts)
   if aliases:out=add('or',add('or',out,11),out)
   outputs[i]=out
   expected=F
   for v in verts(S[i]):expected|=raw[v]
   assert values[out]==expected
  assert values[outputs[0]]&values[outputs[1]]&values[outputs[2]]==F
  actual={(a,b) for a,b in pairs if outputs[a] in anc[outputs[b]]};assert actual==rel
  T={i for i in range(3) if not any(a==i for a,b in rel)};live=set().union(*(anc[outputs[i]] for i in T));core=live-{outputs[i] for i in T}
  assert 13 not in live and all(outputs[i] in live for i in range(3))
  B=set();counted=0
  for w in core:
   op,a,b=gates[w-13]
   assert (a<13 or a in core) and (b<13 or b in core) and a!=12 and b!=12
   if op=='and':B|={tuple(sorted((u,v))) for u in verts(supports[a]) for v in verts(supports[b])};counted+=1
   elif supports[w].bit_count()>1:counted+=1
  H={e for e in E if any(set(e).isdisjoint(verts(s)) for s in S)};K=set(H)
  for i in set(range(3))-T:K|={tuple(sorted((u,v))) for u in cn(S[i]) for v in verts(S[i])}
  strict=bool(K) and all(all(any(tuple(sorted((u,v))) not in K for v in verts(S[i])) for u in cn(S[i])) for i in T)
  assert K<=B<=set(E) and len(B)<=counted<=len(core)
  assert len(live)>=len(K)+len(T)+int(strict)
  cone_checks=[]
  for i in range(3):
   chosen={j for j in range(3) if j==i or (j,i) in rel}
   Kc={e for e in E if any(set(e).isdisjoint(verts(S[j])) for j in chosen)}
   for j in chosen-{i}:Kc|={tuple(sorted((u,v))) for u in cn(S[j]) for v in verts(S[j])}
   bonus=bool(Kc) and all(any(tuple(sorted((u,v))) not in Kc for v in verts(S[i])) for u in cn(S[i]))
   corec=anc[outputs[i]]-{outputs[i]};Bc=set();countc=0
   for w in corec:
    op,a,b=gates[w-13]
    assert (a<13 or a in corec) and (b<13 or b in corec) and a!=12 and b!=12
    if op=='and':Bc|={tuple(sorted((u,v))) for u in verts(supports[a]) for v in verts(supports[b])};countc+=1
    elif supports[w].bit_count()>1:countc+=1
   assert Kc<=Bc and len(Bc)<=countc<=len(corec)
   assert len(anc[outputs[i]])>=len(Kc)+1+int(bonus)
   cone_checks.append({'output':i,'selected_subfamily':sorted(chosen),'K':sorted(Kc),'B':sorted(Bc),'strict_guard':bonus,'lower_bound':len(Kc)+1+int(bonus),'actual_cone_gates':len(anc[outputs[i]])})
  union_checks=[]
  for mask in range(1,8):
   J={i for i in range(3) if mask>>i&1};TJ={i for i in J if not any(a==i and b in J for a,b in rel)}
   KJ={e for e in E if any(set(e).isdisjoint(verts(S[j])) for j in J)}
   for j in J-TJ:KJ|={tuple(sorted((u,v))) for u in cn(S[j]) for v in verts(S[j])}
   bonus=bool(KJ) and all(all(any(tuple(sorted((u,v))) not in KJ for v in verts(S[j])) for u in cn(S[j])) for j in TJ)
   liveJ=set().union(*(anc[outputs[i]] for i in J));coreJ=liveJ-{outputs[i] for i in TJ};BJ=set();countJ=0
   for w in coreJ:
    op,a,b=gates[w-13]
    assert (a<13 or a in coreJ) and (b<13 or b in coreJ) and a!=12 and b!=12
    if op=='and':BJ|={tuple(sorted((u,v))) for u in verts(supports[a]) for v in verts(supports[b])};countJ+=1
    elif supports[w].bit_count()>1:countJ+=1
   assert KJ<=BJ and len(BJ)<=countJ<=len(coreJ) and len(liveJ)>=len(KJ)+len(TJ)+int(bonus)
   last=max(outputs[i] for i in J)
   omitted={i for i in range(3) if i not in J and outputs[i]<last and not any((i,j) in rel for j in J)}
   extra=int(any(a in omitted and b in omitted for a,b in rel))
   upper=last-13+1-len(omitted)-extra
   assert len(liveJ)<=upper
   union_checks.append({'selected_subfamily':sorted(J),'maxima':sorted(TJ),'K':sorted(KJ),'B':sorted(BJ),'strict_guard':bonus,'lower_bound':len(KJ)+len(TJ)+int(bonus),'actual_union_gates':len(liveJ),'position_upper_bound':upper})
  controls.append({'r':r,'supports':S,'ancestry':sorted(rel),'aliases_and_FALSE':aliases,'gates':gates,'outputs':[outputs[i] for i in range(3)],'terminal':sorted(T),'live_gates':len(live),'core_gates':len(core),'H':sorted(H),'K':sorted(K),'B':sorted(B),'strict_guard':strict,'lower_bound':len(K)+len(T)+int(strict),'full2048_functions_checked':True,'actual_relation_checked':True,'all_ANDs_clean_productive':True,'dead_TRUE_removed':True,'cone_checks':cone_checks,'all_subfamily_union_checks':union_checks})
out={'verdict':'SECOND_ENUMERATION_AND_DAG_CONTROLS_V3_PASS_SAME_GUARDED_BOUND_INSIDE_ALL_SUBFAMILY_UNIONS_AWAITS_PEER','source_sha256':sha(Path(__file__)),'producer_source_sha256':sha(O/'filter_selected_birth_patterns_v3.py'),'input_sha256':sha(p),'math_sha256':sha(O/'selected-ancestry-birth-bound.md'),'summaries':summaries,'position_relation_trials':poschecks,'families':family_rows,'actual_DAG_controls':controls,'controls_count':len(controls),'selected_output_truth_checks':len(controls)*3*2048,'seconds':time.monotonic()-start,'scope':'Separate scalar enumeration and actual DAG controls for new proposed math. No second-agent proof acceptance, actual CNF cut, Lean or global claim.'}
(O/'selected-birth-controls-v3.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['families','actual_DAG_controls']},indent=2))
