from pathlib import Path
import collections,functools,hashlib,itertools,json,time
O=Path(__file__).resolve().parent;I=O.parent/'S01';start=time.monotonic()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
forest=json.loads((O/'forest-sinks-review.json').read_text());mixed=json.loads((I/'mixed-triple-census.json').read_text());pos0=json.loads((I/'three-factor-position-classification.json').read_text())
assert sha(O/'forest-sinks-review.json')=='b57049af7a3c7e56f8bf964357e9ef5451876dd98483589be529be22599dad8c'
assert sha(I/'mixed-triple-census.json')=='c29dc5ced6304b3bbc60f6e319a88481f5c29036e79d53477b92f0e5367ccb45'
assert sha(I/'three-factor-position-classification.json')=='83e0d4e9c8ee73fbc2bd2480a5a3cb5dc8ffdb1fb6a577618d902ddfc8ee651d'
E=[(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),(4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)];EM=[(1<<u)|(1<<v) for u,v in E];N=[sum(1<<(v if u==x else u) for u,v in E if x in(u,v)) for x in range(11)]
@functools.lru_cache(None)
def tau(edges):
 if not edges:return 0
 return 1+min(tau(tuple(e for e in edges if not e>>v&1)) for v in range(11) if edges[0]>>v&1)
def cost(s):
 es=tuple(e for e in EM if not e&s);return s.bit_count()+len(es)+tau(es)-1
def owner(s):
 vs=[v for v in range(11) if N[v]&s==s];assert len(vs)<=1;return vs[0] if vs else None
pairs=list(itertools.permutations(range(3),2));rels=[]
for flags in range(64):
 rel={(a,b) for j,(a,b) in enumerate(pairs) if flags>>j&1}
 if any((b,a) in rel for a,b in rel):continue
 if any((a,c) not in rel for a,b in rel for bb,c in rel if b==bb):continue
 rels.append(rel)
assert len(rels)==19
position_trials=0

def one_position(S,L,owners,rel,r):
 global position_trials
 ancestors=[{j for j in range(3) if (j,i) in rel} for i in range(3)]
 if any(owners[j] is None for a in ancestors for j in a):return None
 rawessential=[sum(1<<v for v in range(11) if s>>v&1 or N[v]&~s) for s in S]
 rawirrelevant=[sum(1<<v for v in range(11) if not s>>v&1 and N[v]&~s==0) for s in S]
 ranges=[range(16,l-2,-1) for l in L]
 for p in itertools.product(*ranges):
  if len(set(p))<3 or any(p[a]>=p[b] for a,b in rel):continue
  position_trials+=1;occupied=set(p)
  if any(not any(t not in occupied for t in range(p[a]+1,p[b])) for a,b in rel):continue
  if any(len(a)>1 and sum(t not in occupied for t in range(min(p[j] for j in a)+1,p[i]))<len(a) for i,a in enumerate(ancestors)):continue
  bounds=[]
  for i in range(3):
   outside={j for j in range(3) if p[j]<p[i] and j not in ancestors[i]}
   excluded=int(any(a in outside and b in outside for a,b in rel))
   upper=p[i]+1-len(outside)-excluded
   o={owners[j] for j in ancestors[i]}
   charge=sum(bool(S[i]>>v&1) for v in o) if any(not e&S[i] for e in EM) else 0
   if r==0:charge=max(charge,int(any(rawessential[j]&rawirrelevant[i] for j in ancestors[i])))
   lower=L[i]+charge
   if lower>upper:break
   bounds.append([lower,upper])
  else:return {'positions':p,'bounds':bounds}
 return None

groups={0:[row for row in pos0['families'] if tuple(row['supports']) in {tuple(x['supports']) for x in forest['forest_results'][0]['families'] if not x['excluded']}],1:[row for row in mixed['results'][0]['families'] if row['position_witness'] is not None]}
assert {k:len(v) for k,v in groups.items()}=={0:258,1:800}
results=[]
for r,rows in groups.items():
 record=[]
 for old in rows:
  S=old['supports'];L=[cost(s) for s in S];owners=[owner(s) for s in S]
  assert L==old['individual_costs'] and owners==old['owners'] and sum(v is None for v in owners)==r
  H={j for j,e in enumerate(EM) if any(not e&s for s in S)}
  stars=[{j for j,e in enumerate(EM) if owners[i] is not None and e>>owners[i]&1 and bool(e&S[i])} for i in range(3)]
  assert all(len(stars[i])==S[i].bit_count() for i in range(3) if owners[i] is not None)
  relation_rows=[]
  for rel in rels:
   if any(owners[a] is None for a,b in rel):continue
   terminal=[i for i in range(3) if not any(a==i for a,b in rel)]
   nonterminal=[i for i in range(3) if i not in terminal]
   K=H|set().union(*(stars[i] for i in nonterminal)) if nonterminal else set(H)
   strict=bool(K) and all(owners[i] is None or not stars[i]<=K for i in terminal)
   bound=len(K)+len(terminal)+int(strict)
   # Every old feasible relation is checked, even when new inequality rejects.
   witness=one_position(S,L,owners,rel,r)
   if witness is None:continue
   relation_rows.append({'ancestry':sorted(rel),'terminal':terminal,'forced_birth_edges':[E[j] for j in sorted(K)],'forced_birth_count':len(K),'strict_guard':strict,'lower_bound':bound,'old_position_witness':witness,'newly_rejected':bound>17})
  assert relation_rows
  surviving=[d for d in relation_rows if not d['newly_rejected']]
  record.append({'supports':S,'individual_costs':L,'owners':owners,'original_H':[E[j] for j in sorted(H)],'relation_cases':relation_rows,'excluded':not surviving,'remaining_relations':len(surviving)})
  assert time.monotonic()-start<30
 summary={'r':r,'input':len(record),'excluded':sum(d['excluded'] for d in record),'remaining':sum(not d['excluded'] for d in record),'old_feasible_relation_count':sum(len(d['relation_cases']) for d in record),'surviving_relation_count':sum(d['remaining_relations'] for d in record)}
 results.append({**summary,'families':record});print(json.dumps(summary),flush=True)
out={'verdict':'PROPOSED_SELECTED_ANCESTRY_BIRTH_FILTER_PENDING_INDEPENDENT_REVIEW','source_sha256':sha(Path(__file__)),'inputs':{str(p):sha(p) for p in [O/'forest-sinks-review.json',I/'mixed-triple-census.json',I/'three-factor-position-classification.json']},'relation_types':len(rels),'position_trials':position_trials,'seconds':time.monotonic()-start,'results':results,'scope':'Necessary conditions for17-gate productive clean prefixes with minimal three-factor proper full-cover family. Includes nonterminal owner-star births, deletes only selected ancestry maxima, strict bonus requires nonempty forced graph and a missing terminal star edge for every possible owner. Mathematical proposal, no circuit/CNF/Lean/global claim.'}
(O/'selected-birth-patterns.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['results','inputs']},indent=2))
