from pathlib import Path
import datetime,hashlib,json,shutil,tarfile
O=Path(__file__).resolve().parent;I=O.parent/'S01';S=O.parents[1];R=Path('/workspace/pequalnp-proofs');ROOT=O/'selected-birth-math-preservation-v1';assert not ROOT.exists();ROOT.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):p.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
files={}
def take(p,digest=None):
 p=Path(p);assert p.is_file() and not p.is_symlink() and p.suffix not in ('.cnf','.drat','.lrat','.pyc')
 if digest:assert sha(p)==digest,(str(p),sha(p),digest)
 rel=Path('scratch')/p.relative_to(S) if p.is_relative_to(S) else Path('repo')/p.relative_to(R)
 dest=ROOT/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
 files[str(rel)]={'source':str(p),'sha256':sha(dest),'bytes':dest.stat().st_size}
new_names=['selected-ancestry-birth-bound.md','selected-birth-subfamily-corollary.md','preserve_selected_birth_review.py','selected-birth-v2-extra-families.json']
for version in ['', '_v2', '_v3']:
 suffix=version.replace('_','-')
 new_names+=['filter_selected_birth_patterns'+version+'.py','check_selected_birth_patterns'+version+'.py','selected-birth-patterns'+suffix+'.json','selected-birth-patterns'+suffix+'.stdout.log','selected-birth-patterns'+suffix+'.stderr.log','selected-birth-controls'+suffix+'.json','selected-birth-controls'+suffix+'.stdout.log','selected-birth-controls'+suffix+'.stderr.log']
new_names += [p.name for p in O.glob('*.initial-labels') if p.name.startswith(('filter_selected_birth_patterns_v2','selected-birth-patterns-v2'))]
for n in new_names:take(O/n)
for n in ['mixed-triple-census.json','three-factor-position-classification.json','three-factor-position-conditions.md','mixed-triple-census-math.md','joint-factor-cost.md','irrelevant-input-charge.md']:take(I/n)
for n in ['forest-sinks-review.json','forest-sinks-math-review.md','mixed-triple-review.json','forced-birth-math-review.md','forced-birth-review.json','birth-count-helper-readonly-snapshot.txt','forced-birth-math-preservation-handoff.json','forest-sinks-math-preservation-handoff.json','no-common-math-preservation-handoff.json']:take(O/n)
strong=json.loads((O/'selected-birth-patterns-v3.json').read_text());controls=json.loads((O/'selected-birth-controls-v3.json').read_text())
assert sha(O/'selected-birth-patterns-v3.json')=='2cda8c5b1a0bbdcb46fd4f372b3da88d756b60f0f6f9fc0a89ff5d1aae5e5645'
assert sha(O/'selected-birth-controls-v3.json')=='1b728b551ef741c20e7302eea7e5b7bee76b773774426e8d923bc1eccc0f4010'
summary=[{k:g[k] for k in ['r','input','excluded','remaining']} for g in strong['results']]
assert summary==controls['summaries']
report='''\n\n## 05:47 selected-ancestry birth progress, peer review pending\n\nNew general bound: for an arbitrary selected ancestry relation, delete only\nits t maximal selected OR outputs. Let K be the union of all edges missed by\nsome selected support and the owner stars of nonmaximal selected outputs.\nFirst-AND paths force these stars into the remaining birth graph, so m>=|K|+t.\nThe strict bonus requires K NONEMPTY and, for every selected maximum with an\nowner, at least one edge of its whole support star outside K. No unguarded\nempty-core argument is reused. Constants/copies/fan-out are included.\n\nApplying the same guarded lemma to every nonempty selected subfamily gives\na cone-union lower bound, compared with the previous position upper bound\nminus excluded selected gates and at most one excluded outside-chain AND.\nThree bounded scalar versions give r0/r1 remaining counts163/571,161/571,\nand finally159/570. The strongest version excludes99 of the258 previousr0\nsurvivors and230 of800 r1 survivors. This is NOT a whole-class closure.\n\nEvery version has a second scalar enumeration; strongest checks220517\nposition/relation choices, with50 actual shared DAG controls,307200 selected\ntruth checks,150 individual cones and350 subfamily unions. Full code, tables,\nproofs and stdout/stderr are retained. The existing triangle counterexample\nto the unguarded statement remains explicit.\n\nThe new generic lemma and union-upper corollary were sent to S01 via NOTES\nfor independent mathematical review. At archive freeze no second-agent PASS\nhad arrived; the count is therefore PROPOSED with S04 implementation/control\nchecks, not peer-accepted mathematics, a CNF cut, Lean theorem or global claim.\nStrongest source712f3bd35f26832f6900875a8f8fcf35fed9817dce8b19c3f234fe7c9aee23b2;\nresult2cda8c5b1a0bbdcb46fd4f372b3da88d756b60f0f6f9fc0a89ff5d1aae5e5645;\ncontrol1b728b551ef741c20e7302eea7e5b7bee76b773774426e8d923bc1eccc0f4010.\nNo solver, production worker, named Lean file, lease or Git write was used.\n'''
reportpath=R/'results/orch/lemmas/S04-redteam.md'
with reportpath.open('a') as f:f.write(report)
take(reportpath)
(ROOT/'README.md').write_text('''# Selected-ancestry birth mathematics: NEW proposed evidence

This archive contains only the new S04 result and the precise earlier input
snapshots needed to replay it. Older wave7 archives are not recopied.
No second-agent mathematical PASS had arrived at freeze. S01 review was
requested in shared NOTES. Do not treat these proposed counts as accepted
CNF cuts, Lean lemmas, SAT results or a global-shard refutation.

The general bound includes nonterminal owner stars, deletes only selected
ancestry maxima, and has an EXPLICIT nonempty forced-graph guard for the
strict bonus. The original empty-core triangle counterexample is included.
The corollary applies the same bound to all selected-subfamily cone unions.
Versions1/2/3 leave r0/r1:163/571,161/571,159/570 from inputs258/800.
Strongest version proposes99 r0 and230 r1 additional exclusions, not closure.

Full producer/checker sources, COMPLETE support/relation/position tables,
actual shared DAGs, proofs and stdout/stderr are preserved. Initial v2 field
labels were clarified; those historical initial-labels files are retained.
The strongest checker independently enumerates220517 choices and checks50
actual DAGs,307200 output rows,150 cones and350 subfamily unions. All strict
applications require nonemptyK and a missing terminal star edge.

Extract anywhere and run python verify_manifest.py. All payloads are ordinary
files and all original paths, hashes and sizes appear in manifest.json.

For scalar replay, first make a working copy of the extracted archive. From
scratch/orch/S04 run, in order:
  python check_selected_birth_patterns.py
  python check_selected_birth_patterns_v2.py
  python check_selected_birth_patterns_v3.py
These consume the pinned producer tables and overwrite ONLY the working-copy
review outputs. Their elapsed-time metadata changes, so regenerated output
hashes need not match; family decisions and DAG controls are deterministic.
Do not regenerate producer tables first, since the checkers intentionally pin
the historical exact producer bytes. Producer scripts are also included and
use only relative sibling paths for the archived S01 input snapshots.

All runs were bounded scalar operations; no solver/Lean/production/lease/Git
write and no named Lean-file change. Full diagnostics are preserved. Future
peer acceptance must be added as a separate dated addendum, not inferred.
''')
(ROOT/'verify_manifest.py').write_text('''from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
m=json.loads((r/'manifest.json').read_text())
for name,v in m['files'].items():
 p=r/name
 assert p.is_file() and not p.is_symlink()
 assert p.stat().st_size==v['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'],name
print('PASS',len(m['files']),'payloads; mathematical peer review remains pending')
''')
for n in ['README.md','verify_manifest.py']:files[n]={'source':'generated by preserve_selected_birth_review.py','sha256':sha(ROOT/n),'bytes':(ROOT/n).stat().st_size}
scope='NEW proposed guarded selected-ancestry/star and subfamily-cone mathematics; v3 proposes99/258r0 and230/800r1 exclusions,159/570 remain; two scalar implementations+actualDAG controls, second-agent proof review PENDING. No CNF/Lean/global claim.'
write(ROOT/'manifest.json',{'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':scope,'peer_math_review':'PENDING','files':files,'strongest_summary':summary,'raw_cnfs':0})
archive=O/(ROOT.name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as tf:
 for p in sorted(ROOT.rglob('*')):
  if p.is_file():tf.add(p,arcname=p.relative_to(ROOT),recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 members=tf.getmembers();assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
 assert set(m.name for m in members)==set(files)|{'manifest.json'}
 for m in members:
  data=tf.extractfile(m).read();assert data==(ROOT/m.name).read_bytes()
  if m.name!='manifest.json':assert len(data)==files[m.name]['bytes'] and hashlib.sha256(data).hexdigest()==files[m.name]['sha256']
handoff={'verdict':'PRESERVATION_HASH_PASS_NEW_MATH_PEER_REVIEW_PENDING','archive':str(archive),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'regular_members':len(members),'manifest_sha256':sha(ROOT/'manifest.json'),'strongest_summary':summary,'scope':scope,'proof_sha256':sha(O/'selected-ancestry-birth-bound.md'),'corollary_sha256':sha(O/'selected-birth-subfamily-corollary.md'),'strongest_source_sha256':sha(O/'filter_selected_birth_patterns_v3.py'),'strongest_result_sha256':sha(O/'selected-birth-patterns-v3.json'),'second_implementation_sha256':sha(O/'check_selected_birth_patterns_v3.py'),'controls_sha256':sha(O/'selected-birth-controls-v3.json')}
write(O/'selected-birth-math-preservation-handoff.json',handoff);print(json.dumps(handoff,indent=2))
