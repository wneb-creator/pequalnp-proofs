# Applying the guarded birth bound to selected subfamilies

This is a corollary of selected-ancestry-birth-bound.md, not an unguarded
replacement. All strict applications still require a NONEMPTY forced graph
and a missing star edge for each terminal's possible owner. The new proof
and finite claims remain pending S01's independent mathematical review.

For any nonempty subset J of the selected indices, let U_J be the union of
their gate ancestor cones. Retain that union in topological order. Let T_J
be the maximal selected indices within J under the actual ancestry relation.
The support assumptions remain true for this subfamily: full-cover, proper,
size at least2, incomparable. Its nonterminal outputs are exactly J minus T_J.
Thus the same proof gives

    |U_J| >= |K_J| + |T_J| + strict_bonus_J,

where K_J is the union of edges missed by some S_j, j in J, together with
the owner stars of J minus T_J. The bonus is one only when K_J is nonempty
and every terminal owner star has an edge outside K_J. Otherwise it is zero.
Selected outputs outside J are simply ordinary retained or absent gates;
they are not also subtracted from this lower count.

For three selected outputs at distinct gate positions p_i, let P=max(p_j:j
in J). Let O be the selected indices outside J that occur before P and are
not ancestors of ANY j in J. Their output gates lie outside U_J. If two
indices a,b in O satisfy a->b, one first AND on that path also lies outside
U_J, occurs before P, and is distinct from selected OR outputs. With three
selected outputs, there can be at most one such outside pair. Consequently

    |U_J| <= P+1-|O|-indicator(an ancestry pair exists inside O).

The additional AND cannot be in U_J: otherwise a would also be ancestral to
a selected j in J, contradicting the definition of O. Constants, copy gates
and overlaps do not change this distinct-gate subtraction. For |J|=2 there
is at most one outside selected output and therefore no additional AND term.
For |J|=3 there are no outside selected outputs. For |J|=1 this is the
previously reviewed individual-cone upper bound.

Version2 applies the lower bound to J={i and all its selected ancestors},
so U_J is exactly the cone of i and T_J={i}. It removes two additional r0
families, [69,772,1056] and[416,576,1152], leaving161 r0 and571 r1.

For example, v1 leaves only the selected chain772->69->1056 for the first
family. Its individual costs are13,15,15. Two intervening AND slots force
the positions12,14,16. The cone of69 then has at most15 gates. Applying the
guarded bound to the subfamily{772,69} instead requires16, a contradiction.
This is an actual conditional ancestor-cone argument, not just a new table
of individual support costs.

Version3 applies the same inequality to all seven nonempty J. It removes
two further r0 families[84,772,1056],[416,576,1160] and one r1 family
[100,768,1056]. No new mathematical principle beyond the general guarded
lemma and the union upper bound above is used.

|version|r0 new exclusions /258|r0 remaining|r1 new exclusions /800|r1 remaining|
|---|---:|---:|---:|---:|
|global selected maxima|95|163|229|571|
|also individual cones|97|161|229|571|
|all selected-subfamily unions|99|159|230|570|

Every version has a separate chronological-position enumeration that
recomputes all feasible labeled ancestry relations, all forced edges,
guards and family decisions. Version3 checks220517 position/relation choices
and reproduces every result. Its50 actual shared DAG controls retain307200
selected-output truth checks, verify all three individual cones and all
seven subfamily unions (350 union checks), and include FALSE, repeated
operands/copies and dead TRUE gates. All retained ANDs are clean/productive.
The controls do not fit17 gates and are not claimed as constructions at that
budget; they verify the pruning/birth/upper-bound identities on real DAGs.

The earlier strict triangle counterexample remains a required negative
control: H=K=empty does NOT receive the bonus. No unguarded lemma was reused.
Remaining relation/position patterns are abstract necessary-condition
witnesses, not circuits. No CNF cut, Lean theorem or whole-shard result is
claimed. Historical v1/v2 sources and results are frozen separately.
