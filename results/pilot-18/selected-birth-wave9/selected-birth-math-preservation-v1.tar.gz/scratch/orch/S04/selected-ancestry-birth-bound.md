# Birth count with nonterminal selected factors

S04 mathematical proposal for independent S01 review, 2026-11-24 05:40 UTC.
No Lean proof, CNF implementation, solver or whole-shard conclusion.

## Setting and explicit guards

Let G be a loopless C4-free graph. Consider an m-gate clean productive binary
AND/OR prefix and k selected proper full-cover factors W_i. Their singleton
supports S_i have size at least2 and are pairwise incomparable. Clean means
every AND evaluates FALSE on every independent input; productive means both
AND operand singleton supports are nonempty. Constants, repeated operands,
dead gates and arbitrary fan-out are allowed before pruning.

Let i<j in the selected ancestry relation mean that W_i is a syntactic
ancestor of W_j. This is an arbitrary strict partial order, not an assumed
antichain. Let T be its maximal elements and t=|T|. A selected support with
no common neighbor can only be maximal: a first AND descendant would need
a nonempty opposite operand contained in CN(S_i), which is impossible, and
an OR-only path to another selected output contradicts support incomparability.

Every S_i of size at least2 has at most one common neighbor in a C4-free
graph. Write c_i for that owner if it exists, and Star_i for all edges c_i-v
with v in S_i. Put

    H = {uv in E(G): some S_i misses both u and v},
    K = H union the Star_i for all nonmaximal selected i.

The proposed basic bound is m >= |K|+t. Its strict version requires BOTH:

    K is nonempty;
    for every i in T having an owner, Star_i is NOT a subset of K.

Under these guards the proposed bound is m >= |K|+t+1. The second guard is
vacuous for no-common-neighbor supports. More generally, with multiple possible
owners, it would require at least one missing star edge for EACH owner; the
fixed C4-free setting already makes owners unique.

## Forced births and the basic count

Prune to the ancestor union of selected maxima. Every selected output is
retained, since each selected element lies below some maximal element. The
t maximal outputs are terminal OR gates; delete only those t gates. All
ANDs and their complete operand computations remain in the core. Other
selected outputs remain ordinary OR gates in the core and are counted there.

An edge in H is accepted by some W_i despite neither endpoint belonging to
S_i. The edge-birth argument yields an AND cross-support birth in its cone,
hence in the core. For a nonmaximal i, take a path to any selected descendant.
Support incomparability forces a first AND q on that path. Its entering
operand contains S_i. The other operand is nonempty by productivity and
contained in CN(S_i) by cleanliness; since this is the singleton{c_i}, q
births EVERY edge c_i-v for v in S_i. Therefore K is contained in the graph B
of all core cross-support births. Stars may overlap H or each other; use a
set UNION, never a sum of their cardinalities.

The existing birth-count helper gives

    |K| <= |B| <= #core AND + #core OR with support size>1
                       <= #core gates <= m-t.

Free TRUE cannot feed any retained gate: its full support has no common
neighbor, so any path to a proper selected output cannot have a first
productive AND and cannot be all OR either. Drop unused TRUE and reindex
the retained topological graph before using the small-input hypothesis.
FALSE and duplicate operands are harmless. The helper requires no output
function, and its count applies with partial/full factor cones alike.

## Strict count

Assume |K|=m-t and the two strict guards. All inequalities above are equalities:
B=K and the retained core is nonempty. Every core gate must be ancestral to
an AND, counting each AND as its own ancestor. Otherwise pruning to the
ancestor union of all core ANDs keeps B but reduces the gate count, contradicting
the same counting helper. No output equations are needed in that second prune.

No core gate can have support exactly S_i for any terminal i. Such a gate
would have a first AND descendant. The same first-AND argument either
contradicts CN(S_i)=empty or births the whole Star_i. At least one of those
edges is outside K by the strict guard, contradicting B=K. This is why the
weaker condition Star_i not-subset K suffices: not every star edge must be
outside K.

Choose the last core gate. It must be AND, and its liveness forces it to feed
a selected terminal OR directly. Its own support is empty, so the other
operand has exact terminal support S_i. That operand is a core gate: the
support has size at least2, is proper, and no terminal can feed another.
This contradicts the previous paragraph. Thus equality cannot hold.

The nonempty-K guard is essential. The triangle and its three pairwise OR
factors give m=t=3, empty H=K/core, and would falsify an unguarded strict
statement. This counterexample is already archived; it is not reused as a
valid instance here. No minimum-size-circuit assumption is made.

## Finite application to the current k3/r0 and k3/r1 tables

The source filter_selected_birth_patterns.py pins the prior reviewed258
k3/r0 forest survivors and800 k3/r1 mixed survivors. It enumerates all19
labeled strict partial orders on three outputs, rejects no-CN ancestors,
and checks existence of a position tuple satisfying the previously reviewed
cone/slot/owner conditions. For r0 it also preserves the prior raw-input
charge. For r1 it preserves the prior convention omitting owner charge for
empty residuals; no stronger empty-residual premise is silently inserted.

For EACH previously feasible relation, the full K edge list, terminal list,
strict guard, resulting bound, and old feasible position witness are saved.
A family is excluded only if every old-feasible relation violates the new
bound. There are52883 position trials,4605 old-feasible relations and1989
surviving relations. The scalar run takes0.513 seconds and reports:

|class|input families|new exclusions|remaining|
|---|---:|---:|---:|
|k3/r0|258|95|163|
|k3/r1|800|229|571|

These counts and the new proof are PENDING a second agent's independent
review. Every surviving pattern is only a necessary-condition witness,
not a shared17-gate circuit. Other k/r classes are not enumerated here.
