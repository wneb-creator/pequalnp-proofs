from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
m=json.loads((r/'manifest.json').read_text())
for name,v in m['files'].items():
 p=r/name
 assert p.is_file() and not p.is_symlink()
 assert p.stat().st_size==v['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'],name
print('PASS',len(m['files']),'payloads; mathematical peer review remains pending')
