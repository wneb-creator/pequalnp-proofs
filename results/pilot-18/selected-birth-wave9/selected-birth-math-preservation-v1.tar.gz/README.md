# Selected-ancestry birth mathematics: NEW proposed evidence

This archive contains only the new S04 result and the precise earlier input
snapshots needed to replay it. Older wave7 archives are not recopied.
No second-agent mathematical PASS had arrived at freeze. S01 review was
requested in shared NOTES. Do not treat these proposed counts as accepted
CNF cuts, Lean lemmas, SAT results or a global-shard refutation.

The general bound includes nonterminal owner stars, deletes only selected
ancestry maxima, and has an EXPLICIT nonempty forced-graph guard for the
strict bonus. The original empty-core triangle counterexample is included.
The corollary applies the same bound to all selected-subfamily cone unions.
Versions1/2/3 leave r0/r1:163/571,161/571,159/570 from inputs258/800.
Strongest version proposes99 r0 and230 r1 additional exclusions, not closure.

Full producer/checker sources, COMPLETE support/relation/position tables,
actual shared DAGs, proofs and stdout/stderr are preserved. Initial v2 field
labels were clarified; those historical initial-labels files are retained.
The strongest checker independently enumerates220517 choices and checks50
actual DAGs,307200 output rows,150 cones and350 subfamily unions. All strict
applications require nonemptyK and a missing terminal star edge.

Extract anywhere and run python verify_manifest.py. All payloads are ordinary
files and all original paths, hashes and sizes appear in manifest.json.

For scalar replay, first make a working copy of the extracted archive. From
scratch/orch/S04 run, in order:
  python check_selected_birth_patterns.py
  python check_selected_birth_patterns_v2.py
  python check_selected_birth_patterns_v3.py
These consume the pinned producer tables and overwrite ONLY the working-copy
review outputs. Their elapsed-time metadata changes, so regenerated output
hashes need not match; family decisions and DAG controls are deterministic.
Do not regenerate producer tables first, since the checkers intentionally pin
the historical exact producer bytes. Producer scripts are also included and
use only relative sibling paths for the archived S01 input snapshots.

All runs were bounded scalar operations; no solver/Lean/production/lease/Git
write and no named Lean-file change. Full diagnostics are preserved. Future
peer acceptance must be added as a separate dated addendum, not inferred.
