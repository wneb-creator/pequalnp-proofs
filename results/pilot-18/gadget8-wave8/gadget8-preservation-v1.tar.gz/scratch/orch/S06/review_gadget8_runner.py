#!/usr/bin/env python3
"""Independent exact-delta audit and bounded fixture controls; no generic search."""
import copy
import datetime
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import shutil
import subprocess
import sys
import time
from types import SimpleNamespace

sys.dont_write_bytecode=True
ROOT=Path('/tmp/oec/pequalnp-pilot-18')
OWN=ROOT/'orch/S06'
MAIN=ROOT/'orch/MAIN/gadget8-runner-v1'
OUT=OWN/'gadget8-runner-controls'
RUNNER=MAIN/'offline_gadget8_cadical.py'
RUNNER_SHA='5c196750473896225cb414458a150bccfc5dff3d68ecbeceec2aaf1c7f088b34'
PARENT_SHA='aa5d13bb83ab79e47b9794809c3c06dc153544975cd1131afbdeaef7c18d484a'
VALIDATOR_SHA='60e877fd3bdb11d134633519482b67ca82478c55a00350e34a935ddd194054cb'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def record(p):return {'bytes':p.stat().st_size,'sha256':sha(p)}
def save(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def require(ok,msg):
    if not ok:raise AssertionError(msg)
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()

def source_audit():
    require(sha(RUNNER)==RUNNER_SHA,'runner pin')
    parent=OWN/'offline_checked_cadical.py'
    require(sha(parent)==PARENT_SHA,'parent pin')
    require(sha(OWN/'validate_gadget8.py')==VALIDATOR_SHA,'validator pin')
    substitutions=[
      ("(ROOT/'lean-setup/validate_sat_candidate.py','b807c1a580ce1fa49da51d859e6bc5d94bab2f9f0cd359c35cef35686f826529')", "(ROOT/'orch/S06/validate_gadget8.py','"+VALIDATOR_SHA+"')"),
      ('Exact input CNF only; normalization/preprocessing provenance and Lean acceptance remain separate.', 'Eight-input gadget CNF only. Gadget UNSAT does not refute the full gap; SAT requires full256/full2048 extension and at-most21 gates. Lean acceptance remains separate.'),
      ("'--unsat'", "'--sat'"),
      ("[sys.executable,str(args.pins['validator'][0]),str(snapshot),str(args.output/'solver.stdout')]", "[sys.executable,str(args.pins['validator'][0]),str(snapshot),str(args.output/'solver.stdout'),str(args.output/'gadget.validated.json'),'--cnf-sha256',args.cnf_sha256,'--metadata-sha256',args.metadata_sha256]"),
      ("json.loads(snapshot.with_suffix('.validated.json').read_text())", "json.loads((args.output/'gadget.validated.json').read_text())"),
      ("require(report.get('status')=='VALIDATED' and report.get('verified_inputs_per_circuit')==2048 and report.get('meets_posted_gate_limit') is True,'SAT candidate validation incomplete or exceeds21gates')", "require(report.get('status')=='VALIDATED_GADGET' and report.get('verified_inputs')==256 and report.get('full11_verified_inputs')==2048 and report.get('meets_gadget_12_gate_limit') is True and report.get('meets_full21_gate_limit') is True,'Gadget validation incomplete or extension exceeds21gates')"),
      ("require(report.get('provenance')=={'cnf_sha256':args.cnf_sha256,'metadata_sha256':args.metadata_sha256,'kissat_stdout_sha256':digest(args.output/'solver.stdout')},'SAT validation provenance mismatch')", "require(report.get('provenance')=={'cnf_sha256':args.cnf_sha256,'metadata_sha256':args.metadata_sha256,'solver_stdout_sha256':digest(args.output/'solver.stdout'),'validator_sha256':args.pins['validator'][1]},'Gadget validation provenance mismatch')"),
    ]
    expected=parent.read_text()
    for a,b in substitutions:
        require(expected.count(a)==1,'nonunique substitution '+a)
        expected=expected.replace(a,b)
    require(expected.encode()==RUNNER.read_bytes(),'unexpected source change')
    deriv=json.loads((MAIN/'derivation.json').read_text())
    require(deriv['parent_sha256']==PARENT_SHA and deriv['source_sha256']==RUNNER_SHA and deriv['literal_replacements']==7,'derivation disagreement')
    diff=''.join(difflib.unified_diff(parent.read_text().splitlines(True),RUNNER.read_text().splitlines(True),fromfile='offline_checked_cadical.py',tofile='offline_gadget8_cadical.py'))
    require(diff==(MAIN/'source.diff').read_text(),'diff disagreement')
    snap=OUT/'source';snap.mkdir()
    for src in [parent,RUNNER,MAIN/'source.diff',MAIN/'derivation.json',OWN/'validate_gadget8.py']:
        shutil.copyfile(src,snap/src.name)
    return {'status':'PASS_EXACT_SEVEN_LITERAL_REPLACEMENTS','source_sha256':RUNNER_SHA,'parent_sha256':PARENT_SHA,'validator_sha256':VALIDATOR_SHA,'substitutions':substitutions}

def check_logs(folder,result,phases):
    expected={name+ext for name in phases for ext in ['.stdout','.stderr']}
    require(set(result['logs'])==expected,'exact full log key set')
    for name in expected:require(result['logs'][name]==record(folder/name),'log bytes/hash '+name)
    require(result==json.loads((folder/'progress.json').read_text()),'final progress mismatch')
    require(result['source_sha256']==RUNNER_SHA and result['state']=='FINISHED','source/final state')
    require(sha(folder/'instance.cnf')==result['cnf_sha256'] and sha(folder/'instance.json')==result['metadata_sha256'],'snapshot binding')

def outer_limits():
    resource.setrlimit(resource.RLIMIT_CPU,(10,10))
    resource.setrlimit(resource.RLIMIT_AS,(4096*1024**2,4096*1024**2))
    resource.setrlimit(resource.RLIMIT_FSIZE,(64*1024**2,64*1024**2))

def real_control(name,cnf_hash,meta_hash,expect):
    cnf=OWN/'gadget8-v1'/(name+'.cnf')
    require(sha(cnf)==cnf_hash and sha(cnf.with_suffix('.json'))==meta_hash,'fixture binding')
    out=OUT/name
    cmd=[sys.executable,'-B',str(RUNNER),str(cnf),str(out),'--cnf-sha256',cnf_hash,'--metadata-sha256',meta_hash,'--solver-seconds','5','--checker-seconds','5','--proof-mib','8','--max-records','1000000','--min-free-mib','256','--abort-file',str(ROOT/'DESK_ERROR.response')]
    started=time.monotonic()
    with (OUT/(name+'.outer.stdout')).open('xb') as stdout,(OUT/(name+'.outer.stderr')).open('xb') as stderr:
        process=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,cwd=OWN,stdin=subprocess.DEVNULL,start_new_session=True,preexec_fn=outer_limits)
        try:code=process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            process.kill();process.wait();raise
    execution={'command':cmd,'exit_code':code,'wall_seconds':time.monotonic()-started,'outer_wall_seconds':15,'outer_cpu_seconds':10,'outer_address_space_mib':4096}
    save(OUT/(name+'.execution.json'),execution)
    result=json.loads((out/'result.json').read_text())
    require(code==expect and result['exit_code']==expect,'fixture runner exit')
    require(set(result['phases'])==({'solver','checker'} if expect==0 else {'solver','validator'}),'fixture phases')
    check_logs(out,result,result['phases'])
    require(result['pins']['validator']['sha256']==VALIDATOR_SHA,'fixture pinned validator')
    if expect==0:
        require(result['status']=='VERIFIED_UNSAT' and result['accepted_CNF_UNSAT'] is True and result['validated_SAT'] is False,'negative fixture verified')
        require(result['phases']['solver']['exit_code']==20 and result['solver_verdicts']==['s UNSATISFIABLE'],'solver UNSAT')
        require(result['phases']['checker']['exit_code']==0 and result['checker_verdicts']==['s VERIFIED UNSAT'],'checker verified')
        require(record(out/'proof.drat')=={k:result['proof'][k] for k in ['bytes','sha256']},'proof binding')
        require(result['retained_proof_file']['is_accepted_complete_certificate'] is True,'proof acceptance')
    else:
        require(result['status']=='UNKNOWN' and result['SAT_indication'] is True and result['accepted_CNF_UNSAT'] is False and result['validated_SAT'] is False,'positive overlimit rejected')
        require(result['phases']['solver']['exit_code']==10 and result['phases']['validator']['exit_code']==0,'real SAT/validator path')
        report=result['validation_report']
        require(report['status']=='VALIDATED_GADGET' and report['gate_count']==13 and report['full11_gate_count']==22,'positive gate counts')
        require(report['verified_inputs']==256 and report['full11_verified_inputs']==2048,'positive truth checks')
        require(report['meets_gadget_12_gate_limit'] is False and report['meets_full21_gate_limit'] is False,'positive overlimit flags')
        require(result['reason']=='ValueError: Gadget validation incomplete or extension exceeds21gates','exact overlimit rejection')
        require(report['provenance']=={'cnf_sha256':cnf_hash,'metadata_sha256':meta_hash,'solver_stdout_sha256':sha(out/'solver.stdout'),'validator_sha256':VALIDATOR_SHA},'positive real provenance')
    return {'status':'PASS','execution':execution,'result_sha256':sha(out/'result.json'),'outcome':result['status'],'reason':result['reason']}

def synthetic_controls():
    spec=importlib.util.spec_from_file_location('reviewed_gadget8_runner',RUNNER)
    runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
    real_phase=runner.phase
    cnf=OWN/'gadget8-v1/positive13-pinned.cnf'
    base=OUT/'synthetic';base.mkdir()
    (base/'README.md').write_text('Decision-path controls only. Solver phase is simulated; schema controls also simulate the validator report. Every control must reject. The incomplete-model control uses the real pinned validator. These outputs are not candidate searches or certificates.\n')
    cases=[('incomplete-model-real-validator','validator-failure'),('missing-status','schema'),('wrong-256','schema'),('wrong-2048','schema'),('missing-gadget-limit','schema'),('full-limit-false','schema'),('gadget-limit-int-one','schema'),('full-limit-int-one','schema'),('missing-provenance','provenance'),('extra-provenance','provenance'),('validator-exit2','validator-failure')]
    cases += [('wrong-'+key,'provenance') for key in ['cnf_sha256','metadata_sha256','solver_stdout_sha256','validator_sha256']]
    results=[]
    for label,kind in cases:
        args=SimpleNamespace(cnf=cnf,output=base/label,cnf_sha256=sha(cnf),metadata_sha256=sha(cnf.with_suffix('.json')),solver_seconds=5,checker_seconds=5,proof_bytes=8*1024**2,max_records=1000000,min_free_bytes=256*1024**2,abort_file=ROOT/'DESK_ERROR.response',pins=runner.PINNED)
        def fake_phase(a,name,command,seconds,memory_mb,stop,state,persist,proof=None):
            if name=='validator' and label=='incomplete-model-real-validator':return real_phase(a,name,command,seconds,memory_mb,stop,state,persist,proof)
            require(name in ['solver','validator'],'unexpected synthetic phase')
            stdout=a.output/(name+'.stdout');stderr=a.output/(name+'.stderr')
            stdout.write_text('s SATISFIABLE\nv 1 0\n' if name=='solver' else 'synthetic validation report for rejection control\n');stderr.write_text('')
            result={'command':command,'exit_code':10 if name=='solver' else (2 if label=='validator-exit2' else 0),'reason':None,'synthetic_control':True}
            state['phases'][name]=result;persist()
            if name=='validator':
                report={'status':'VALIDATED_GADGET','verified_inputs':256,'full11_verified_inputs':2048,'meets_gadget_12_gate_limit':True,'meets_full21_gate_limit':True,'provenance':{'cnf_sha256':a.cnf_sha256,'metadata_sha256':a.metadata_sha256,'solver_stdout_sha256':sha(a.output/'solver.stdout'),'validator_sha256':VALIDATOR_SHA}}
                if label=='missing-status':report.pop('status')
                elif label=='wrong-256':report['verified_inputs']=255
                elif label=='wrong-2048':report['full11_verified_inputs']=2047
                elif label=='missing-gadget-limit':report.pop('meets_gadget_12_gate_limit')
                elif label=='full-limit-false':report['meets_full21_gate_limit']=False
                elif label=='gadget-limit-int-one':report['meets_gadget_12_gate_limit']=1
                elif label=='full-limit-int-one':report['meets_full21_gate_limit']=1
                elif label=='missing-provenance':report.pop('provenance')
                elif label=='extra-provenance':report['provenance']['extra']='unexpected'
                elif label.startswith('wrong-'):report['provenance'][label[6:]]='0'*64
                save(a.output/'gadget.validated.json',report)
            return result
        runner.phase=fake_phase
        begin=time.monotonic();code=runner.run(args);elapsed=time.monotonic()-begin
        result=json.loads((args.output/'result.json').read_text())
        require(elapsed<15 and code==2 and result['status']=='UNKNOWN' and result['validated_SAT'] is False and result['accepted_CNF_UNSAT'] is False and result['SAT_indication'] is True,'synthetic rejection '+label)
        reason={'schema':'ValueError: Gadget validation incomplete or extension exceeds21gates','provenance':'ValueError: Gadget validation provenance mismatch','validator-failure':'ValueError: SAT validator failed or timed out'}[kind]
        require(result['reason']==reason,'wrong rejection path '+label)
        check_logs(args.output,result,['solver','validator'])
        if label=='incomplete-model-real-validator':
            invalid=json.loads((args.output/'gadget.validated.json').read_text())
            require(invalid=={'status':'INVALID','reason':'ValueError: incomplete model'},'real validator incomplete-model rejection')
        results.append({'name':label,'status':'PASS_REJECTED','reason':reason,'wall_seconds':elapsed,'result_sha256':sha(args.output/'result.json')})
    runner.phase=real_phase
    return results

def main():
    OUT.mkdir()
    audit=source_audit();save(OUT/'source-audit.json',audit)
    controls={
      'bad12-pinned':real_control('bad12-pinned','0b39eb1f59ceb336bd99edcb902d6216a9e189c19319376a64cb711c0325e1ab','d87690333106529e8c91c88c7fb0d9f789336528c58beaeee7255b10a8558eb3',0),
      'positive13-pinned':real_control('positive13-pinned','e3cf28df73e0e141d78745ab77b4607ffd8e25e4e4766210d5c03b9ff0deaf90','f29d7f8ed55ebecea956d80a4e5830258e5cb9534da3c8dd4695efdd10f605aa',2)}
    synthetic=synthetic_controls()
    require(sha(RUNNER)==RUNNER_SHA and sha(OWN/'offline_checked_cadical.py')==PARENT_SHA and sha(OWN/'validate_gadget8.py')==VALIDATOR_SHA,'final source pins')
    report={'status':'PASS_GADGET_RUNNER_EXACT_DELTA_AND_BOUNDED_CONTROLS','utc':utc(),'runner_sha256':RUNNER_SHA,'parent_sha256':PARENT_SHA,'validator_sha256':VALIDATOR_SHA,'review_source_sha256':sha(Path(__file__)),'exact_literal_replacements':7,'real_controls':controls,'synthetic_rejection_controls':synthetic,'scope':'Runner adaptation only. Two fully pinned fixture solver runs; no generic12 search. Pinned bad12 UNSAT applies only to that fixture. Positive13 is exact but its extension has22 gates and is rejected. Synthetic decision controls do not constitute searches or certificates. Main independent encoding review and production admission remain separate.'}
    save(OUT/'review.json',report)
    print(json.dumps({'status':report['status'],'runner_sha256':RUNNER_SHA,'real_controls':len(controls),'synthetic_rejections':len(synthetic),'review_sha256':sha(OUT/'review.json')}))

if __name__=='__main__':main()
