# Generic eight-input, twelve-gate construction target

The generic12 instance has996 variables and14093 clauses (189611bytes). It
allows arbitrary earlier-wire AND/OR gates, both free constants and repeated
operands. The only symmetry rule sorts each gate's two operands. There is no
first-junk/shard restriction, cleanliness assumption, liveness requirement,
fixed template, distance restriction or pinned seed in generic12. Every
circuit using at most12 gates can put its output last and pad with OR copies.
generic13 is the same generic encoding with13 gates.

The input vertices, in local bit order, are [0,2,4,5,6,8,9,10]. Local raw wires
are0..7; FALSE=8, TRUE=9, and gate g has wire10+g. The target is the OR of edges
09,25,48,58,59,89,010,210,410,610. The finite encoding uses the10 minimal
positive rows and7 maximal independent negative rows. Every positive input
contains a required edge; every negative input is below an encoded negative.
All AND/OR circuits are monotone, so these17 rows are equivalent to all256
inputs. row-completeness.json gives a witness for every input.

Sources are build_gadget8.py (generic encoder and explicit control circuits),
validate_gadget8.py (separate decoder/CNF/full256/full2048 validator), and
control_gadget8.py (scalar/BCP controls). The independent validator requires
exact supplied CNF/metadata hashes, a sole SAT verdict and a complete consistent
assignment of all variables. It checks every clause, selector, gate/internal
encoded-row value and all256 truth rows before constructing the full11 circuit.

The clean13-gate positive circuit consists of stars9(0+5+8),8(4+5),2*5 and
10(0+2+4+6), followed by three union gates. Its complete satisfying assignment
passes every pinned13 CNF clause and the independent full256 validator. Its
full11 extension has22 gates and is explicitly NOT accepted as a21-gate witness.

The pinned bad12 circuit is D7 OR10(0+2+4+6), where
D=(0+5+8)(9+(4+5)(2+8)). Independent checking finds exactly the wrong function
gadget_target OR x0*x2*x4. Its full11 extension has false positives21,29,85,149.
The pinned bad12 CNF is unit-propagation contradictory; bad12-pinned.rup has984
derived units and an empty clause. Pinned DSR replay returned exit0 and sole
`s VERIFIED UNSAT`, with full checker logs retained. This proves only the
fully pinned negative fixture is inconsistent; generic12 remains UNSOLVED.

Controls also check all16 Boolean gate-relation assignments,64 random unrestricted
circuits against the encoded clauses and full truth table, all256 row-coverage
witnesses, and malformed/incomplete/conflicting/wrong-status model rejection.
No production SAT solver has been run by S06.

A valid12-gate gadget extends to21 gates by adding the following8-gate remainder
and one final OR: 7*(3+6+9) OR3*6 OR1*(4+8). It covers exactly the six missing
edges14,18,36,37,67,79. The validator explicitly materializes and independently
checks all2048 full11 inputs. Any candidate still requires main's usual raw
validator/Lean workflow; this package does not claim a witness.

Reproduce all four instances and scalar controls by running control_gadget8.py
in a fresh owned workspace. For a fresh output name, build_gadget8.py accepts
an output-directory argument and generates generic12/generic13 and both pinned
fixtures. No solver is invoked by either command. Existing destinations are
refused. Full source and output hashes are in gadget8-handoff.json.

The unexecuted solver command in gadget8-search-plan.json is a command vector,
not a supervisor. Main must supply detached supervision, memory/file/wall caps,
abort handling, full logs and certificate checking as desired. The old
11-input validator in the existing retained runner is incompatible with this
metadata; use the supplied gadget validator command and require BOTH12-gate
and21-gate acceptance flags. Do not pass these files unchanged to the old
full11 runner. Generic gadget UNSAT would exclude only this decomposition,
not arbitrary21-gate circuits, the assigned shard or the global statement.
