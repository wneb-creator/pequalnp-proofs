#!/usr/bin/env python3
"""Exact generic monotone gadget synthesis CNF; no solver execution."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path

OWN=Path('/tmp/oec/pequalnp-pilot-18/orch/S06')
VERTICES=[0,2,4,5,6,8,9,10]
EDGES=[(0,9),(2,5),(4,8),(5,8),(5,9),(8,9),(0,10),(2,10),(4,10),(6,10)]
LOCAL=[(VERTICES.index(a),VERTICES.index(b)) for a,b in EDGES]


def digest(raw):return hashlib.sha256(raw).hexdigest()
def target(mask):return any(mask>>a&1 and mask>>b&1 for a,b in LOCAL)
def dump(p,value):p.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')


class CNF:
    def __init__(self):self.variables=0;self.clauses=[]
    def var(self):self.variables+=1;return self.variables
    def add(self,*literals):self.clauses.append(list(literals))
    def one(self,variables):
        self.add(*variables)
        for a,b in itertools.combinations(variables,2):self.add(-a,-b)
    def raw(self):
        return (f'p cnf {self.variables} {len(self.clauses)}\n'+''.join(' '.join(map(str,c))+' 0\n' for c in self.clauses)).encode()


def rows():
    positive=[(1<<a)|(1<<b) for a,b in LOCAL]
    negative=[m for m in range(256) if not target(m) and all(m>>v&1 or target(m|(1<<v)) for v in range(8))]
    assert len(set(positive))==10 and not set(positive)&set(negative)
    for m in range(256):
        assert (any((e&m)==e for e in positive))==target(m)
        assert (any((m&n)==m for n in negative))==(not target(m))
    return [{'mask':m,'target':True} for m in positive]+[{'mask':m,'target':False} for m in negative]


def build(k):
    assert type(k) is int and 1<=k<=13
    cnf=CNF();selected_rows=rows();records=[]
    for g in range(k):
        op=cnf.var();left=[cnf.var() for _ in range(10+g)];right=[cnf.var() for _ in range(10+g)]
        av=[cnf.var() for _ in selected_rows];bv=[cnf.var() for _ in selected_rows];yv=[cnf.var() for _ in selected_rows]
        cnf.one(left);cnf.one(right)
        # Commutativity only; repeated operands and both free constants remain allowed.
        for a in range(10+g):
            for b in range(a):cnf.add(-left[a],-right[b])
        for r,row in enumerate(selected_rows):
            for selectors,mux in [(left,av[r]),(right,bv[r])]:
                for wire,selector in enumerate(selectors):
                    if wire<8:source=bool(row['mask']>>wire&1)
                    elif wire<10:source=(wire==9)
                    else:source=records[wire-10]['outputs'][r]
                    if type(source) is bool:cnf.add(-selector,mux if source else -mux)
                    else:cnf.add(-selector,-mux,source);cnf.add(-selector,mux,-source)
            a,b,y=av[r],bv[r],yv[r]
            cnf.add(-op,-y,a);cnf.add(-op,-y,b);cnf.add(-op,y,-a,-b)
            cnf.add(op,y,-a);cnf.add(op,y,-b);cnf.add(op,-y,a,b)
        records.append({'op':op,'left':left,'right':right,'left_values':av,'right_values':bv,'outputs':yv})
    for r,row in enumerate(selected_rows):cnf.add(records[-1]['outputs'][r] if row['target'] else -records[-1]['outputs'][r])
    raw=cnf.raw()
    meta={'format':'s06-gadget8-v1','vertices':VERTICES,'edges':EDGES,'local_edges':LOCAL,
        'gate_count':k,'wire_offset':10,'false_wire':8,'true_wire':9,'output':10+k-1,
        'variables':cnf.variables,'clauses':len(cnf.clauses),'rows':selected_rows,'gate_records':records,
        'cnf_sha256':digest(raw),'generator_sha256':digest(Path(__file__).read_bytes()),
        'scope':'All monotone AND/OR circuits using at most k gates for this 8-input gadget; no first-junk, cleanliness, liveness, distance or template restriction.',
        'completeness':'Every positive row contains a required edge; every negative row is contained in an encoded maximal negative row. Monotonicity implies exactness on all256 inputs. At-most-k circuits can be topologically ordered with output last and padded by OR copies.',
        'operand_order':'left_wire<=right_wire by commutativity; duplicates allowed','SAT_validator_required':True}
    return cnf,meta


def circuit_controls():
    v={x:i for i,x in enumerate(VERTICES)}
    positive=[]
    def gate(out,op,a,b):
        out.append([op,min(a,b),max(a,b)]);return 10+len(out)-1
    a=gate(positive,'or',v[0],v[5]);a=gate(positive,'or',a,v[8]);s9=gate(positive,'and',a,v[9])
    a=gate(positive,'or',v[4],v[5]);s8=gate(positive,'and',a,v[8]);s2=gate(positive,'and',v[2],v[5])
    a=gate(positive,'or',v[0],v[2]);a=gate(positive,'or',a,v[4]);a=gate(positive,'or',a,v[6]);s10=gate(positive,'and',a,v[10])
    a=gate(positive,'or',s9,s8);a=gate(positive,'or',a,s2);gate(positive,'or',a,s10)
    bad=[]
    a=gate(bad,'or',v[0],v[5]);a=gate(bad,'or',a,v[8]);b=gate(bad,'or',v[4],v[5]);c=gate(bad,'or',v[2],v[8])
    bc=gate(bad,'and',b,c);q=gate(bad,'or',v[9],bc);d=gate(bad,'and',a,q)
    q=gate(bad,'or',v[0],v[2]);q=gate(bad,'or',q,v[4]);q=gate(bad,'or',q,v[6]);s10=gate(bad,'and',q,v[10]);gate(bad,'or',d,s10)
    assert len(positive)==13 and len(bad)==12
    return positive,bad


def pins(meta,gates):
    assert len(gates)==meta['gate_count'];units=[]
    for g,((op,a,b),record) in enumerate(zip(gates,meta['gate_records'])):
        assert op in ['and','or'] and 0<=a<=b<10+g
        units.append([record['op'] if op=='and' else -record['op']])
        units.extend([[x if w==a else -x] for w,x in enumerate(record['left'])])
        units.extend([[x if w==b else -x] for w,x in enumerate(record['right'])])
    return units


def prepare(output):
    output=output.absolute();assert output.parent.resolve().is_relative_to(OWN.resolve())
    assert not output.exists() and not output.is_symlink();output.mkdir(mode=0o700)
    positive,bad=circuit_controls();family=[]
    for name,k,circuit in [('generic12',12,None),('generic13',13,None),('positive13-pinned',13,positive),('bad12-pinned',12,bad)]:
        cnf,meta=build(k)
        if circuit is not None:
            units=pins(meta,circuit);cnf.clauses.extend(units)
            meta.update(pinned_circuit=circuit,pin_clause_count=len(units),scope='Fully pinned finite control only; not generic synthesis.')
        raw=cnf.raw();meta.update(clauses=len(cnf.clauses),cnf_sha256=digest(raw))
        (output/(name+'.cnf')).write_bytes(raw);dump(output/(name+'.json'),meta)
        family.append({'name':name,'variables':cnf.variables,'clauses':len(cnf.clauses),'rows':len(meta['rows']),
            'cnf_sha256':digest(raw),'metadata_sha256':digest((output/(name+'.json')).read_bytes()),'bytes':len(raw)})
    dump(output/'circuits.json',{'positive13':positive,'bad12':bad,'wire_offset':10,'vertices':VERTICES})
    dump(output/'family.json',{'status':'PREPARED_NO_SOLVER','family':family,'generator_sha256':digest(Path(__file__).read_bytes()),'no_global_UNSAT_scope':True})
    return family


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('output',type=Path);args=parser.parse_args()
    print(json.dumps(prepare(args.output),indent=2))
