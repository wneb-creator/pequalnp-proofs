#!/usr/bin/env python3
"""Retain bounded binary DRAT; check only a completed solver UNSAT result.

One child at a time: solver, then checker OR full SAT validator. No background
workers or network calls. Main owns admission/scheduling; keep a slot until exit.
Exit0 VERIFIED_UNSAT,10 VALIDATED_SAT,2 UNKNOWN (including failures/limits/abort).
"""
import argparse
import ctypes
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time
from types import SimpleNamespace

ROOT=Path('/tmp/oec/pequalnp-pilot-18')
OWN=ROOT/'orch/S06'
PINNED={
 'solver':(ROOT/'lean-4.36.0-linux/bin/cadical','2a0137451efde370d67b88aec26f1e902870f095b1204b07049a103bc6bbd647'),
 'checker':(ROOT/'solver/dsr-trim/bin/dsr-trim','e6894b5b74ac2c09b494344f397ec5111547aaa782cdb399f1a8b6835ecef84b'),
 'validator':(ROOT/'orch/S06/validate_gadget8.py','60e877fd3bdb11d134633519482b67ca82478c55a00350e34a935ddd194054cb'),
}


def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def require(ok,msg):
    if not ok:raise ValueError(msg)
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def atomic_json(path,value):
    tmp=path.with_suffix(path.suffix+'.tmp')
    with tmp.open('w') as f:
        json.dump(value,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
    os.replace(tmp,path)
def verdicts(path):
    if not path.exists():return []
    with path.open('rb') as f:return [x.decode('ascii',errors='replace').strip() for x in f if x.startswith(b's ')]
def verify_bindings(args):
    for name,(path,expected) in args.pins.items():
        require(path.is_file() and not path.is_symlink(),name+' must be regular nonsymlink file')
        require(digest(path)==expected,name+' SHA256 mismatch')
    require(digest(args.cnf)==args.cnf_sha256,'input CNF SHA256 mismatch')
    require(digest(args.cnf.with_suffix('.json'))==args.metadata_sha256,'input metadata SHA256 mismatch')
def child_setup(memory_mb,file_bytes,parent):
    def setup():
        resource.setrlimit(resource.RLIMIT_AS,(memory_mb*1024**2,memory_mb*1024**2))
        resource.setrlimit(resource.RLIMIT_FSIZE,(file_bytes,file_bytes))
        libc=ctypes.CDLL(None,use_errno=True)
        if libc.prctl(1,signal.SIGKILL,0,0,0)!=0 or os.getppid()!=parent:os._exit(125)
    return setup
def stop_child(p):
    if p.poll() is None:
        try:os.killpg(p.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        try:p.wait(timeout=1)
        except subprocess.TimeoutExpired:
            try:os.killpg(p.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            p.wait()
def rss(pid):
    try:
        for line in Path(f'/proc/{pid}/status').read_text().splitlines():
            if line.startswith('VmHWM:'):return int(line.split()[1])
    except OSError:pass
    return 0


def phase(args,name,command,seconds,memory_mb,stop,state,persist,proof=None):
    started=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
    result={'command':command,'started_utc':utc(),'wall_limit_seconds':seconds,'address_space_mib':memory_mb,'exit_code':None,'reason':None}
    state['phases'][name]=result;state['state']=name.upper();persist()
    p=None;peak=0;last=0
    with (args.output/(name+'.stdout')).open('xb') as out,(args.output/(name+'.stderr')).open('xb') as err:
        try:
            if stop[0] or args.abort_file.exists():
                result['reason']=stop[0] or 'external_abort_file';return result
            # Retain at most proof_bytes per solver file; post-process logs use64MiB.
            file_cap=args.proof_bytes if name=='solver' else 64*1024**2
            p=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=out,stderr=err,cwd=args.output,
                start_new_session=True,preexec_fn=child_setup(memory_mb,file_cap,os.getpid()))
            result['pid']=p.pid;persist()
            while p.poll() is None:
                now=time.monotonic();reason=stop[0]
                if args.abort_file.exists():reason=reason or 'external_abort_file'
                if now-started>=max(.01,seconds-1):reason=reason or 'wall_time_limit'
                if proof is not None and proof.exists() and proof.stat().st_size>=args.proof_bytes:reason=reason or 'proof_size_limit'
                if now-last>=.5:
                    peak=max(peak,rss(p.pid))
                    if shutil.disk_usage(args.output).free<args.min_free_bytes:reason=reason or 'low_disk_space'
                    result.update(elapsed_seconds=round(now-started,3),sampled_peak_rss_kib=peak)
                    if proof is not None and proof.exists():result['proof_bytes_so_far']=proof.stat().st_size
                    persist();last=now
                if reason:result['reason']=reason;break
                time.sleep(.05)
        finally:
            if p is not None:stop_child(p);result['exit_code']=p.returncode
            after=resource.getrusage(resource.RUSAGE_CHILDREN)
            result.update(finished_utc=utc(),elapsed_seconds=round(time.monotonic()-started,6),sampled_peak_rss_kib=peak,
                child_user_cpu_seconds=after.ru_utime-before.ru_utime,child_system_cpu_seconds=after.ru_stime-before.ru_stime)
            if result['exit_code']==-signal.SIGXFSZ:result['reason']=result['reason'] or 'file_size_limit'
            persist()
    return result


def proof_info(path,args,stop):
    h=hashlib.sha256();size=zeros=0;first=last=None
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):
            require(not stop[0] and not args.abort_file.exists(),'abort during proof scan')
            if first is None:first=b[0]
            last=b[-1];size+=len(b);zeros+=b.count(0);h.update(b)
            require(size<args.proof_bytes,'proof size guard reached')
            require(zeros<=args.max_records,'proof record guard reached')
    require(size==0 or (first in (ord('a'),ord('d')) and last==0),'binary DRAT framing mismatch')
    return {'bytes':size,'sha256':h.hexdigest(),'zero_bytes':zeros}


def run(args):
    args.output.mkdir(mode=0o700)  # Refuse existing directories/symlinks.
    stop=[None];handlers={}
    def handler(sig,_frame):stop[0]='signal_'+signal.Signals(sig).name
    for sig in [signal.SIGTERM,signal.SIGINT]:handlers[sig]=signal.signal(sig,handler)
    state={'started_utc':utc(),'state':'PREPARING','status':'UNKNOWN','accepted_CNF_UNSAT':False,'validated_SAT':False,
        'source_sha256':digest(Path(__file__)),'phases':{},'cnf_sha256':args.cnf_sha256,'metadata_sha256':args.metadata_sha256,
        'pins':{k:{'path':str(v[0]),'sha256':v[1]} for k,v in args.pins.items()},
        'limits':{'solver_wall_seconds':args.solver_seconds,'checker_wall_seconds':args.checker_seconds,'validator_wall_seconds':30,
          'solver_address_space_mib':1536,'checker_address_space_mib':3072,'proof_bytes':args.proof_bytes,
          'max_proof_zero_bytes':args.max_records,'min_free_bytes':args.min_free_bytes,'active_children_at_most':1},
        'scope':'Eight-input gadget CNF only. Gadget UNSAT does not refute the full gap; SAT requires full256/full2048 extension and at-most21 gates. Lean acceptance remains separate.'}
    def persist():atomic_json(args.output/'progress.json',state)
    snapshot=args.output/'instance.cnf';metadata=snapshot.with_suffix('.json');proof=args.output/'proof.drat';exit_code=2
    try:
        persist();verify_bindings(args)
        require(not stop[0] and not args.abort_file.exists(),'external_abort_file')
        require(shutil.disk_usage(args.output).free>=args.min_free_bytes+args.proof_bytes,'insufficient_disk_headroom')
        shutil.copyfile(args.cnf,snapshot);shutil.copyfile(args.cnf.with_suffix('.json'),metadata)
        snapshot.chmod(0o400);metadata.chmod(0o400)
        require(digest(snapshot)==args.cnf_sha256 and digest(metadata)==args.metadata_sha256,'snapshot copy mismatch')
        cmd=[str(args.pins['solver'][0]),'--sat','--binary=true','--no-color',str(snapshot),str(proof)]
        solver=phase(args,'solver',cmd,args.solver_seconds,1536,stop,state,persist,proof)
        state['solver_verdicts']=verdicts(args.output/'solver.stdout')
        verify_bindings(args)
        require(digest(snapshot)==args.cnf_sha256 and digest(metadata)==args.metadata_sha256,'snapshot changed')
        require(not stop[0] and not args.abort_file.exists(),'abort after solver')
        require(solver['reason'] is None,'solver '+str(solver['reason']))
        require(not proof.exists() or proof.stat().st_size<args.proof_bytes,'proof_size_limit')
        if solver['exit_code']==20 and state['solver_verdicts']==['s UNSATISFIABLE']:
            require(proof.is_file() and not proof.is_symlink(),'missing proof file')
            info=proof_info(proof,args,stop);state['proof']=dict(info,retained=True,producer_complete=True)
            proof.chmod(0o400);persist()
            cmd=[str(args.pins['checker'][0]),'--forward',str(snapshot),str(proof)]
            check=phase(args,'checker',cmd,args.checker_seconds,3072,stop,state,persist)
            state['checker_verdicts']=verdicts(args.output/'checker.stdout')
            verify_bindings(args)
            require(digest(snapshot)==args.cnf_sha256 and digest(metadata)==args.metadata_sha256,'snapshot changed during check')
            require(digest(proof)==info['sha256'] and proof.stat().st_size==info['bytes'],'proof changed during check')
            require(not stop[0] and not args.abort_file.exists(),'abort after checker')
            require(check['reason'] is None and check['exit_code']==0 and state['checker_verdicts']==['s VERIFIED UNSAT'],'checker did not verify UNSAT')
            state.update(status='VERIFIED_UNSAT',accepted_CNF_UNSAT=True,reason=None);exit_code=0
        elif solver['exit_code']==10 and state['solver_verdicts']==['s SATISFIABLE']:
            state['SAT_indication']=True
            cmd=[sys.executable,str(args.pins['validator'][0]),str(snapshot),str(args.output/'solver.stdout'),str(args.output/'gadget.validated.json'),'--cnf-sha256',args.cnf_sha256,'--metadata-sha256',args.metadata_sha256]
            check=phase(args,'validator',cmd,30,1536,stop,state,persist)
            require(check['reason'] is None and check['exit_code']==0,'SAT validator failed or timed out')
            report=json.loads((args.output/'gadget.validated.json').read_text());state['validation_report']=report
            require(report.get('status')=='VALIDATED_GADGET' and report.get('verified_inputs')==256 and report.get('full11_verified_inputs')==2048 and report.get('meets_gadget_12_gate_limit') is True and report.get('meets_full21_gate_limit') is True,'Gadget validation incomplete or extension exceeds21gates')
            require(report.get('provenance')=={'cnf_sha256':args.cnf_sha256,'metadata_sha256':args.metadata_sha256,'solver_stdout_sha256':digest(args.output/'solver.stdout'),'validator_sha256':args.pins['validator'][1]},'Gadget validation provenance mismatch')
            verify_bindings(args)
            require(digest(snapshot)==args.cnf_sha256 and digest(metadata)==args.metadata_sha256,'SAT snapshot changed')
            require(not stop[0] and not args.abort_file.exists(),'abort after validator')
            state.update(status='VALIDATED_SAT',validated_SAT=True,reason=None);exit_code=10
        else:
            state['reason']='solver_unknown_or_exit_verdict_mismatch'
    except Exception as error:
        state.update(status='UNKNOWN',accepted_CNF_UNSAT=False,validated_SAT=False,reason=type(error).__name__+': '+str(error));exit_code=2
    finally:
        # All children are reaped by phase() before any verdict is published.
        if proof.exists() and proof.is_file():
            state['retained_proof_file']={'bytes':proof.stat().st_size,'sha256':digest(proof),'is_accepted_complete_certificate':state['accepted_CNF_UNSAT']}
        state['logs']={p.name:{'bytes':p.stat().st_size,'sha256':digest(p)} for p in args.output.iterdir() if p.is_file() and p.suffix in ['.stdout','.stderr']}
        state.update(finished_utc=utc(),state='FINISHED',exit_code=exit_code)
        persist();atomic_json(args.output/'result.json',state)
        for sig,prior in handlers.items():signal.signal(sig,prior)
    return exit_code


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('cnf',type=Path);p.add_argument('output',type=Path)
    p.add_argument('--cnf-sha256',required=True);p.add_argument('--metadata-sha256',required=True)
    p.add_argument('--solver-seconds',type=float,default=600);p.add_argument('--checker-seconds',type=float,default=600)
    p.add_argument('--proof-mib',type=int,default=512);p.add_argument('--max-records',type=int,default=100000000)
    p.add_argument('--min-free-mib',type=int,default=1024);p.add_argument('--abort-file',type=Path,default=ROOT/'DESK_ERROR.response')
    p.add_argument('--preflight-only',action='store_true');a=p.parse_args()
    for name in ['cnf_sha256','metadata_sha256']:
        value=getattr(a,name);require(len(value)==64 and all(c in '0123456789abcdef' for c in value),'invalid SHA256')
    require(1<=a.solver_seconds<=600 and 1<=a.checker_seconds<=600,'wall limits must be1..600seconds')
    require(1<=a.proof_mib<=512 and 1<=a.max_records<=100000000 and a.min_free_mib>=256,'invalid resource guard')
    a.cnf=a.cnf.resolve(strict=True);a.output=a.output.absolute();a.abort_file=a.abort_file.absolute()
    require(a.cnf.is_relative_to(ROOT) or a.cnf.is_relative_to(Path('/workspace/pequalnp-proofs')),'input outside allowed workspace')
    require(a.output.parent.resolve().is_relative_to(OWN.resolve()),'output must be under S06 scratch')
    require(not a.output.exists() and not a.output.is_symlink(),'output must be fresh')
    a.proof_bytes=a.proof_mib*1024**2;a.min_free_bytes=a.min_free_mib*1024**2;a.pins=PINNED
    if a.preflight_only:
        verify_bindings(a);print(json.dumps({'status':'PREFLIGHT_PASS','solver_launched':False,'source_sha256':digest(Path(__file__)),'free_bytes':shutil.disk_usage(OWN).free}));return 0
    code=run(a);print(json.dumps({'exit_code':code,'result':str(a.output/'result.json')}));return code
if __name__=='__main__':sys.exit(main())
