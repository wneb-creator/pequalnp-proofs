# Eight-input gadget source and finite-control preservation

This package freezes the generic eight-input AND/OR construction encoder,
validator, four CNF recipes, all scalar/model/runner controls, complete fixture
RUP and binary DRAT certificates with checker logs, main encoder review, and
S06 independent runner-delta review. All original source and historical report
bytes remain unchanged. Historical "not launched" records refer to their own
timestamps. Main launched generic12 later; its runtime and launch record are
intentionally outside this package. No active production directory was read.

The generic12 target has996 variables,14093 clauses and17 exact boundary rows.
A valid12-gate gadget gives an explicit21-gate full11 circuit. Gadget UNSAT
would exclude only this construction route, never the full gap or shard.
Only the fully pinned bad12 fixture has checked UNSAT certificates here.
The exact positive13 fixture extends to22 gates and is correctly rejected by
the runner. All15 synthetic runner controls reject; their logs are explicitly
marked and are not searches or certificates.

After extracting into a fresh directory, run:

    python3 -B scratch/orch/S06/restore_gadget8_archive.py .

This verifies every payload, imports the byte-identical encoder, reconstructs
all four unique CNFs and their fixture/synthetic snapshot aliases, compares
every metadata byte, and rechecks all208 historical handoff bindings. It uses
only Python's standard library and runs no solver or checker. Source paths in
historical logs are provenance; archive-relative paths are in MANIFEST.json.
CNF_RECIPES.json binds every omitted CNF to its exact generation recipe.

No executable binaries are included. The preserved binary DRAT is certificate
data. Solver/checker binary SHA256 pins and exact commands occur in the runner
source and full result records; obtain those exact binaries separately for
optional replay. The4,198-byte DRAT was checked by the pinned DSR, and the
separate6,492-byte RUP was checked with --forward --rup-only. Full logs remain
byte-exact, including whitespace and intentionally empty stderr files.

The reviewed runner retains original absolute workspace/tool pins. Replaying
the original bounded controls requires recreating that workspace layout or a
separately reviewed relocation. Portable CNF restoration needs no relocation
of source code: it calls the encoder's pure build/pins APIs and leaves its
hard-coded CLI output-directory restriction untouched. No test reruns or
production are part of archive restoration. Lean acceptance remains separate.
