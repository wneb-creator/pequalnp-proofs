S01 copy-cover finite extensions, frozen2026-11-24 before06:02UTC.

Existing k3/r0,r1 math+finite review is PASS. NEW proposed conclusions:
all112 remaining k4/r0 (111direct+1tight), allpurek4/r4, allpurek5/r5.
Independent review of these NEW extensions is pending. Mixedk4/r1..3 and
k5/r1..4 remain OPEN. No solver, Lean theorem, full shard or proof claim.

Original/stronger/assembly intermediate survivor outputs are preserved as
historical relaxations, never circuit witnesses. Final purek5 result is
copy-cover-pure-assembly-slack2.json (all32 levels,58044recursivecalls,
15.1425sec; no timeout). Full stdout/stderr for allfour scalar probes included.

Portable rerun from extracted scratch/orch/S01:
python extend_copy_cover.py
python probe_pure_copy_assembly_slack2.py
These recreate output JSONs/fullconsole, so use an EXTRACTED copy only.
Each pure probe has an internal48second scalar budget; a slow machine may
produce TIME_LIMIT_UNKNOWN. No external tool, SAT solver or credentials.

The supplied forest census and prior S04 copy-cover review are copied at
their exact bytes. Earlier recursive review/census dependencies reside in
the separately preserved copy-cover archive878a7ddc709da2fa50c969ec00fed9a892ba01ff0185af3c27b497b91d01664d.
The external final handoff binds that prior artifact; this archive does not
pretend to be an independent recomputation of older census completeness.
