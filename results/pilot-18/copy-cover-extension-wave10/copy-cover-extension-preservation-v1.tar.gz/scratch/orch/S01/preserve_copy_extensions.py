#!/usr/bin/env python3
"""Freeze new scalar extension sources, proofs, inputs and complete logs."""
import hashlib
import json
import shutil
import tarfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
DEST=ROOT/'copy-cover-extension-preservation-v1'
assert not DEST.exists(), 'Never rewrite a frozen preservation tree'
names=[
 'copy-cover-extensions.md','pure-copy-assembly-bound.md','pure-copy-assembly-slack.md',
 'extend_copy_cover.py','extend_copy_cover_strong_pure.py',
 'probe_pure_copy_assembly.py','probe_pure_copy_assembly_slack2.py',
 'copy-cover-four-extension.json','copy-cover-pure-extension.json',
 'copy-cover-strong-four-extension.json','copy-cover-strong-pure-extension.json',
 'copy-cover-pure-assembly.json','copy-cover-pure-assembly-slack2.json',
 'copy-cover-extension.stdout.txt','copy-cover-extension.stderr.txt',
 'copy-cover-strong-extension.stdout.txt','copy-cover-strong-extension.stderr.txt',
 'copy-cover-pure-assembly.stdout.txt','copy-cover-pure-assembly.stderr.txt',
 'copy-cover-pure-assembly-slack2.stdout.txt','copy-cover-pure-assembly-slack2.stderr.txt',
 'two-spare-forest-filter.json','support-copy-cover-bound.md','support-copy-terminal-charge.md',
 'copy-cover-closure-handoff.json','copy-cover-preservation-handoff.json',
 'preserve_copy_extensions.py']
sources=[(ROOT/n,Path('scratch/orch/S01')/n) for n in names]
sources += [(ROOT.parent/'S04'/n,Path('scratch/orch/S04')/n)
            for n in ['copy-cover-math-review.md','copy-cover-closure-review.json']]
files=[]
for src,rel in sources:
    data=src.read_bytes();dest=DEST/rel;dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(data)
    files.append(dict(path=str(rel),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
readme='''S01 copy-cover finite extensions, frozen2026-11-24 before06:02UTC.

Existing k3/r0,r1 math+finite review is PASS. NEW proposed conclusions:
all112 remaining k4/r0 (111direct+1tight), allpurek4/r4, allpurek5/r5.
Independent review of these NEW extensions is pending. Mixedk4/r1..3 and
k5/r1..4 remain OPEN. No solver, Lean theorem, full shard or proof claim.

Original/stronger/assembly intermediate survivor outputs are preserved as
historical relaxations, never circuit witnesses. Final purek5 result is
copy-cover-pure-assembly-slack2.json (all32 levels,58044recursivecalls,
15.1425sec; no timeout). Full stdout/stderr for allfour scalar probes included.

Portable rerun from extracted scratch/orch/S01:
python extend_copy_cover.py
python probe_pure_copy_assembly_slack2.py
These recreate output JSONs/fullconsole, so use an EXTRACTED copy only.
Each pure probe has an internal48second scalar budget; a slow machine may
produce TIME_LIMIT_UNKNOWN. No external tool, SAT solver or credentials.

The supplied forest census and prior S04 copy-cover review are copied at
their exact bytes. Earlier recursive review/census dependencies reside in
the separately preserved copy-cover archive878a7ddc709da2fa50c969ec00fed9a892ba01ff0185af3c27b497b91d01664d.
The external final handoff binds that prior artifact; this archive does not
pretend to be an independent recomputation of older census completeness.
'''
(DEST/'README.md').write_text(readme)
files.append(dict(path='README.md',sha256=hashlib.sha256(readme.encode()).hexdigest(),bytes=len(readme.encode())))
manifest=dict(verdict='PRESERVED_NEW_EXTENSIONS_PENDING_INDEPENDENT_REVIEW',files=files)
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=ROOT/'copy-cover-extension-preservation-v1.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for p in sorted(DEST.rglob('*')):
        if p.is_file():tar.add(p,arcname=str(p.relative_to(DEST)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    members={m.name:m for m in tar.getmembers()}
    assert all(m.isfile() for m in members.values())
    assert set(members)=={f['path'] for f in files}|{'manifest.json'}
    for f in files:assert hashlib.sha256(tar.extractfile(members[f['path']]).read()).hexdigest()==f['sha256']
handoff=dict(verdict='ARCHIVE_HASH_ROUNDTRIP_PASS_MATH_EXTENSIONS_PENDING_REVIEW',
    archive=dict(path=str(archive),sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size),
    manifest=dict(path=str(DEST/'manifest.json'),sha256=hashlib.sha256((DEST/'manifest.json').read_bytes()).hexdigest()),
    payloads=len(files),regular_members=len(files)+1,
    prior_archive=dict(path=str(ROOT/'copy-cover-preservation-v1.tar.gz'),sha256=hashlib.sha256((ROOT/'copy-cover-preservation-v1.tar.gz').read_bytes()).hexdigest()),
    scope='No whole-shard claim. New k4/r0,purek4,purek5 proposals require independent review; mixedk4/k5 OPEN.')
(ROOT/'copy-cover-extension-preservation-handoff.json').write_text(json.dumps(handoff,indent=2)+'\n')
print(json.dumps(handoff,indent=2))
