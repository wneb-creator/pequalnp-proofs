# Bounded mixed-family copy-cover probe

This is an intentionally weak necessary relaxation of the already reviewed
terminal-copy charge. No new pure-support assembly lemma is used here.

For k selected minimal outputs, r have empty common-neighbor sets and hence
are selected sinks. Let T be the number of selected sinks, r<=T<=k. Assign
three tags: r no-CN terminals, T-r common-neighbor terminals, and k-T
common-neighbor nonterminals. Every common output cone excludes the r no-CN
selected outputs, so has at most17-r gates. Every no-CN cone excludes the
other r-1 such outputs, so has at most18-r gates. These give cost caps.

Let B contain the required birth edges: all residual edges and each
nonterminal selected support-owner star. The reviewed charge says

    |B| + T + t <=17,
    tau_i <= t+1 for terminals, tau_i<=t for nonterminals,

where t is the maximum of the actual terminal-adjusted cover demands,
clamped below by zero. Thus 0<=t<=7. For each T,t the probe pads B to the
maximum allowed size (capped at16), enumerates all such edge sets, and
constructs the eligible support pool for each tag. Enlarging B only admits
more residuals and owner stars, so this padding is a safe relaxation.

The24 rejected-MIS rows must be covered with AT MOST the three tagged
cardinality budgets. Exact cardinality, output partial orders, distinctness,
minimality and other circuit conditions are deliberately omitted. Rejection
mask containment is pruned only within a tag at fixed B,T,t; this is safe
for the resulting at-most-budget set-cover question.

Each of the seven mixed k4/k5 classes gets at most5 wall seconds. Timeout
means UNKNOWN; a found support family is only a relaxation survivor, never
a circuit witness. Only complete absence across all T,t,B would give a
new necessary-condition exclusion, still requiring independent review.
