#!/usr/bin/env python3
"""Bounded copy-cover extensions; no solver and no circuit-exhaustion claim."""
import hashlib
import itertools
import json
import time
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parent
START = time.monotonic()
E = [(0,9),(0,10),(1,4),(1,8),(2,5),(2,10),(3,6),(3,7),
     (4,8),(4,10),(5,8),(5,9),(6,7),(6,10),(7,9),(8,9)]
EM = [(1<<u)|(1<<v) for u,v in E]
N = [sum(1<<(v if u==x else u) for u,v in E if x in (u,v)) for x in range(11)]
CN = [sum(1<<v for v,n in enumerate(N) if s&n==s) for s in range(2048)]
MIS = [s for s in range(2048) if all(s&e != e for e in EM)
       and all(s>>v&1 or s&N[v] for v in range(11))]
assert len(MIS)==24
ALL = (1<<24)-1

@lru_cache(None)
def cover(es):
    if not es: return 0
    u,v=es[0]
    return 1+min(cover(tuple(e for e in es if u not in e)),
                 cover(tuple(e for e in es if v not in e)))

def data(s):
    es=tuple(e for e,em in zip(E,EM) if not s&em)
    tau=cover(es)
    return dict(s=s,cost=s.bit_count()+len(es)+tau-1,tau=tau,
                residual=sum(1<<j for j,em in enumerate(EM) if not s&em),
                z=sum(1<<j for j,m in enumerate(MIS) if not s&m),cn=CN[s])


# Conservative mixed extension of REVIEWED terminal copy charge only.
# Three tags: no-CN terminal, common terminal, common nonterminal.
# Allow <= tagged counts, duplicates and arbitrary ancestry: overapproximation.
D=[data(s) for s in range(1,2047)]
D=[d for d in D if d['z'] and d['s'].bit_count()>=2]
for d in D:
    d['star']=0
    if d['cn']:
        assert d['cn'].bit_count()==1
        v=d['cn'].bit_length()-1
        d['star']=sum(1<<j for j,(a,b) in enumerate(E)
                      if (a==v and d['s']>>b&1) or (b==v and d['s']>>a&1))
class Limit(Exception):pass

def probe(k,r):
    deadline=time.monotonic()+5
    queries=calls=0
    def checktime():
        if time.monotonic()>deadline:raise Limit
    try:
        for T in range(r,k+1):
            limits=(r,T-r,k-T)
            for t in range(8):
                size=min(16,17-T-t)
                if size<0:continue
                pools=[]
                for tag in range(3):
                    pools.append([d for d in D if bool(d['cn'])==(tag>0)
                      and d['cost']<=(18-r if tag==0 else 17-r)
                      and d['tau']<=t+int(tag<2)])
                for inds in itertools.combinations(range(16),size):
                    checktime();queries+=1;B=sum(1<<j for j in inds)
                    tagged=[]
                    for tag,ds in enumerate(pools):
                        if not limits[tag]:continue
                        masks={d['z']:d for d in ds if not d['residual']&~B
                               and (tag!=2 or not d['star']&~B)}
                        keep=[]
                        for z in sorted(masks,key=int.bit_count,reverse=True):
                            if not any(z&x==z for x in keep):keep.append(z)
                        tagged.extend((tag,z,masks[z]) for z in keep)
                    union=0
                    for tag,z,d in tagged:union|=z
                    if union!=ALL:continue
                    byrow=[[a for a in tagged if a[1]>>j&1] for j in range(24)]
                    @lru_cache(None)
                    def solve(covered,remaining):
                        nonlocal calls
                        calls+=1
                        if calls%128==0:checktime()
                        if covered==ALL:return ()
                        rem=ALL^covered
                        eligible=[a for a in tagged if remaining[a[0]]]
                        if not eligible:return None
                        gain=max((z&rem).bit_count() for tag,z,d in eligible)
                        if gain*sum(remaining)<rem.bit_count():return None
                        j=min((j for j in range(24) if rem>>j&1),
                              key=lambda j:sum(bool(remaining[a[0]]) for a in byrow[j]))
                        for tag,z,d in sorted(byrow[j],key=lambda a:(a[1]&rem).bit_count(),reverse=True):
                            if not remaining[tag]:continue
                            nxt=list(remaining);nxt[tag]-=1
                            ans=solve(covered|z,tuple(nxt))
                            if ans is not None:return ((tag,d['s']),)+ans
                        return None
                    ans=solve(0,limits)
                    if ans is not None:return dict(k=k,r=r,status='RELAXATION_SURVIVOR_NOT_A_CIRCUIT',
                         T=T,t=t,birth_budget=B,tagged_supports=ans,queries=queries,calls=calls)
        return dict(k=k,r=r,status='NECESSARY_RELAXATION_EXHAUSTED_PENDING_REVIEW',queries=queries,calls=calls)
    except Limit:return dict(k=k,r=r,status='TIME_LIMIT_UNKNOWN',queries=queries,calls=calls)
results=[]
for k in (4,5):
    for r in range(1,k):
        a=probe(k,r);results.append(a);print(json.dumps(a),flush=True)
out=dict(source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),results=results,
 elapsed_seconds=time.monotonic()-START,solver_run=False,Lean_proof=False,
 scope='Conservative mixed typed set-cover relaxation only,5sec/class; survivors are NOT circuits; source/math require independent review.')
(ROOT/'copy-cover-mixed-extension.json').write_text(json.dumps(out,indent=2)+'\n')
